# EthernovaClans — Technical Documentation (Part 2 of 2)

> **Module:** `src/` (main plugin)  
> **Scope:** All packages NOT covered in Part 1 — gui, listener, webmap, achievement, mission, skill, shop, fly, teleport, salary, shield, nation, outpost, blueprint, season, tax, spy, nametag, placeholder, hook, hologram, audit, scheduledevent, upgrade, message, util  

---

## Table of Contents

1. [GUI Framework (`gui/`)](#1-gui-framework)
2. [GUI Menus (`gui/menus/`)](#2-gui-menus)
3. [Listener System (`listener/`)](#3-listener-system)
4. [WebMap Server (`webmap/`)](#4-webmap-server)
5. [Achievement System (`achievement/`)](#5-achievement-system)
6. [Mission System (`mission/`)](#6-mission-system)
7. [Skill System (`skill/`)](#7-skill-system)
8. [Clan Shop (`shop/`)](#8-clan-shop)
9. [Fly System (`fly/`)](#9-fly-system)
10. [Teleport System (`teleport/`)](#10-teleport-system)
11. [Salary System (`salary/`)](#11-salary-system)
12. [Shield System (`shield/`)](#12-shield-system)
13. [Nation System (`nation/`)](#13-nation-system)
14. [Outpost System (`outpost/`)](#14-outpost-system)
15. [Blueprint System (`blueprint/`)](#15-blueprint-system)
16. [Season System (`season/`)](#16-season-system)
17. [Tax System (`tax/`)](#17-tax-system)
18. [Spy System (`spy/`)](#18-spy-system)
19. [Nametag System (`nametag/`)](#19-nametag-system)
20. [Placeholder Expansion (`placeholder/`)](#20-placeholder-expansion)
21. [Hook Layer (`hook/`)](#21-hook-layer)
22. [Hologram Integration (`hologram/`)](#22-hologram-integration)
23. [Audit System (`audit/`)](#23-audit-system)
24. [Scheduled Events (`scheduledevent/`)](#24-scheduled-events)
25. [Upgrade System (`upgrade/`)](#25-upgrade-system)
26. [Message System (`message/`)](#26-message-system)
27. [Utilities (`util/`)](#27-utilities)

---

## 1. GUI Framework

### `gui/AbstractGui.java` (852 lines)

Abstract base class for **all** YAML-configurable inventory GUIs. Every menu extends this.

#### Public / Protected API

| Method | Signature | Purpose |
|--------|-----------|---------|
| `open` | `void open()` | Creates Bukkit inventory, fills background, places config items, calls `populateItems()`, starts animation, opens for player |
| `handleClick` | `void handleClick(InventoryClickEvent)` | Click debounce (200ms), routes to `processAction()` or `handleCommonAction()` |
| `isOwnInventory` | `boolean isOwnInventory(Inventory)` | Checks if the Inventory belongs to this GUI instance |
| `stopAnimation` | `void stopAnimation()` | Cancels the rainbow glass border animation task |
| `onClose` | `void onClose()` | Cleanup hook called when inventory closes |
| `getInventory` | `Inventory getInventory()` | Returns the Bukkit Inventory |
| `getPlayer` | `Player getPlayer()` | Returns the viewing player |
| `fillBackground` | `protected void fillBackground()` | Fills all slots with configurable glass pane filler |
| `placeConfigItems` | `protected void placeConfigItems()` | Reads GUI YAML, builds items from config sections, respects requirements |
| `buildItemFromConfig` | `protected ItemStack buildItemFromConfig(ConfigurationSection)` | Builds ItemStack from YAML: material, name, lore, glow, skull-owner, custom-model-data |
| `checkRequirements` | `protected boolean checkRequirements(ConfigurationSection)` | Evaluates `requirements:` — role, level, permission |
| `setItem` | `protected void setItem(int, ItemStack)` | Sets item in slot, marks as occupied |
| `replacePlaceholders` | `protected String replacePlaceholders(String)` | Replaces 100+ `{placeholders}` with live clan data |
| `handleCommonAction` | `protected void handleCommonAction(String, int, InventoryClickEvent)` | Handles bracket actions: `[close]`, `[open]`, `[command]`, `[console]`, `[message]`, `[sound]`; legacy uppercase: `CLOSE`, `BACK`, `OPEN_GUI:xxx` |
| `startAnimation` | `protected void startAnimation()` | Rainbow glass border cycling at configurable speed |
| `msg` | `protected void msg(String, String...)` | Sends MiniMessage to player with replacements |
| **Abstract** `populateItems` | `protected abstract void populateItems()` | Subclasses populate dynamic items |
| **Abstract** `processAction` | `protected abstract boolean processAction(String, int, InventoryClickEvent)` | Subclasses handle custom action strings |

#### Key Features
- **Compound actions**: Multiple actions separated by `;;`
- **Click debounce**: 200ms cooldown between clicks
- **Placeholder system**: `{clan_name}`, `{clan_tag}`, `{clan_members}`, `{clan_power}`, `{clan_bank}`, `{clan_level}`, `{clan_kills}`, `{player_role}`, `{player_name}`, `{shield_status}`, `{war_count}`, etc. (~100+ placeholders)
- **Requirement gating**: Items conditionally visible based on `role:`, `level:`, `permission:`
- **Rainbow animation**: Configurable cycling glass border

---

### `gui/ConfigurableGUI.java` (350 lines)

Fully YAML-driven GUI system that requires **no Java subclass**. Loads 34 default GUI YML files.

| Method | Signature | Purpose |
|--------|-----------|---------|
| `loadAll` | `void loadAll()` | Saves 34 default GUI YMLs, loads all configs from `guis/` |
| `getConfig` | `FileConfiguration getConfig(String guiName)` | Returns the YAML config for a named GUI |
| `open` | `void open(Player, String guiName)` | Creates and opens a YAML-only GUI for a player |
| `handleClick` | `void handleClick(Player, String, InventoryClickEvent)` | Processes click actions for config-only GUIs |

**Supported action types**: `[close]`, `[open]`, `[command]`, `[console]`, `[message]`, `[sound]`, `[title]`  
**Supported conditions**: `has_clan`, `no_clan`, `is_leader`, `is_member`, `is_officer`, `is_co_leader`, `at_war`, `has_shield`, `in_combat`

---

### `gui/GUIManager.java` (324 lines)

Central routing hub for all GUI opens. Maps ~30 GUI name aliases to AbstractGui subclasses.

| Method | Signature | Purpose |
|--------|-----------|---------|
| `registerGui` | `void registerGui(Player, AbstractGui)` | Tracks an open AbstractGui |
| `registerConfigGUI` | `void registerConfigGUI(UUID, String, Inventory)` | Tracks a config-only GUI |
| `handleClick` | `void handleClick(InventoryClickEvent)` | Delegates click to correct menu |
| `handleClose` | `void handleClose(Player, Inventory)` | Cleanup on close |
| `isInMenu` | `boolean isInMenu(UUID)` | Check if player has an open menu |
| `openGui` | `void openGui(Player, String guiName)` | Routes name to correct GUI class |
| `registerAnvilInput` | `void registerAnvilInput(Player, Consumer<String>)` | Registers callback for next chat input |
| `consumeAnvilInput` | `Consumer<String> consumeAnvilInput(UUID)` | Consumes the registered callback |
| Individual openers | `openMainMenu`, `openMembers`, `openBank`, `openTerritory`, `openWars`, `openSettings`, `openTops`, `openUpgrades`, `openProgress`, `openDiplomacy`, `openColorPicker`, `openMissions`, `openAchievements`, `openBoosts`, `openPermissions`, `openAuditLog`, `openInvitations`, `openInvitePlayers`, `openAdminMenu`, `openAdminClanList`, `openAdminClan`, `openAdminPlayer`, `openClanSkills`, `openClanShop`, `openEventCalendar`, `openTrophies`, `openStats`, `openWarps`, `openIconSelector`, `openBlueprints`, `openBlueprintAdmin`, `openSeasons` | Each opens the corresponding GUI |

**Routing**: `switch` statement maps names like `"main-menu"`, `"bank"`, `"members"`, `"territory"`, `"wars"` to Java GUI classes. Unknown names fall back to `ConfigurableGUI`.

---

### `gui/GUIListener.java`

Bukkit `Listener` that delegates `InventoryClickEvent` → `GUIManager.handleClick()` and `InventoryCloseEvent` → `GUIManager.handleClose()`.

---

## 2. GUI Menus

All 32 GUI menus extend `AbstractGui`. Items and layout come from YAML configs in `guis/*.yml`; Java handles dynamic content and custom actions.

### `ClanMainGui.java`

Main clan dashboard. All items from `main-menu.yml`. Custom actions:

| Action | Behavior |
|--------|----------|
| `TOGGLE_CHAT` | Toggle clan chat mode |
| `TOGGLE_FLY` | Toggle territory flight |
| `INVITE_PLAYERS` | Opens InvitePlayersGui (requires `invite` permission) |
| `HOME_TP` | Teleports to clan home |
| `SET_HOME` | Sets clan home at current location (requires `sethq`) |
| `DELETE_HOME` | Removes clan home |
| `UNCLAIM_ALL` | Unclaims all territory (requires `claim`) |
| `SHOW_INFO` | Runs `/clan info` |
| `TOGGLE_OFFICER_CHAT` | Toggle officer chat (Officer+ only) |

### `BankGui.java` (473 lines)

Clan bank: deposits, withdrawals, payroll, tax rate control, transaction history.

**Layout**:
- Config items from `bank.yml`
- Slots 38-44: Transaction history (paginated, 7 items/page)
- Slots 36/44: History pagination arrows
- Slot 45: Page indicator

**Custom actions**: `DEPOSIT`, `WITHDRAW`, `DEPOSIT_ALL`, `WITHDRAW_ALL`, `BANK_PAY_ALL`, `BANK_PAY`, `TAX_INCREASE`, `TAX_DECREASE`, `HISTORY_PREV`, `HISTORY_NEXT`, `BANK_DEPOSIT_QUICK:<amount>`

### `MembersGui.java` (284 lines)

Paginated member list with sortable columns and rank-based actions.

**Layout**:
- Slots: 10-16, 19-25, 28-34 (3 rows × 7 = 21 member heads per page)
- Slot 45/53: Pagination arrows
- Slot 49: Sort toggle (role/kills/kd/power/name)

**Actions**: Click member head → Left=Promote, Right=Kick, Shift+Right=Demote (role-gated)

### `TerritoryMapGui.java` (363 lines)

Interactive 9×5 chunk map. Each slot represents one chunk with color coding.

**Layout**:
- Rows 0-4 (slots 0-44): 45-chunk territory map grid
- Slot 45: ↑ North | 46: ← West | 47: ⊕ Center | 48: → East | 49: ↓ South
- Slot 51: Claim Current | 52: Unclaim Current | 53: Back

**Color coding**:
- Gray glass = Wilderness (unclaimed)
- Lime glass = Own territory
- Yellow glass = HQ chunk
- Light blue = Allied territory
- Red = Rival territory
- Orange = Other clan
- White = Player position + wilderness

**Actions**: `NAV_NORTH/SOUTH/EAST/WEST` (±4 chunks), `NAV_CENTER`, `CLAIM_CURRENT`, `UNCLAIM_CURRENT`, `MAP_CLAIM:<slot>`, `MAP_UNCLAIM:<slot>`, `SET_HQ`

### `UpgradesGui.java`

Displays clan upgrades in 2 rows of 4 slots (10/12/14/16, 28/30/32/34). Shows progress bars, costs, and current/next values. Officer+ can purchase.

### `WarsGui.java` (214 lines)

Active wars display with live scores, timer countdown, and surrender option. Supports war declaration via anvil input.

### Other GUI Menus (Summary)

| GUI Class | Config | Purpose |
|-----------|--------|---------|
| `AchievementsGui` | `achievements.yml` | Shows achievement progress, unlock status |
| `AdminClanGui` | `admin-clan.yml` | Admin clan management (force-disband, force-kick, etc.) |
| `AdminClanListGui` | `admin-clan-list.yml` | Paginated list of all clans for admin |
| `AdminMainGui` | `admin-menu.yml` | Admin dashboard |
| `AdminPlayerGui` | — | Admin player management |
| `AuditLogGui` | — | Paginated audit log viewer |
| `BlueprintMenuGui` | — | Blueprint build/upgrade/demolish |
| `BlueprintAdminGui` | — | Admin blueprint management |
| `BoostsGui` | `boosts.yml` | Active boost status display |
| `ClanShopGui` | — | Internal clan marketplace |
| `ClanSkillsGui` | — | Skill tree viewer/upgrader |
| `ColorPickerGui` | `color-picker.yml` | Clan tag color selection |
| `DiplomacyGui` | `diplomacy.yml` | Alliance/rival management |
| `EventCalendarGui` | — | Scheduled event viewer |
| `IconSelectorGui` | — | Clan icon selection |
| `InvitationsGui` | `invitations.yml` | Pending invitation viewer |
| `InvitePlayersGui` | — | Player invite interface |
| `MissionsGui` | `missions.yml` | Daily/weekly mission progress |
| `PermissionsGui` | `permissions.yml` | Per-role permission management |
| `ProgressGui` | `progress.yml` | Level progress / XP display |
| `SeasonGui` | — | Season rankings and history |
| `SettingsGui` | `settings.yml` | Clan settings toggles |
| `StatsGui` | `stats.yml` | Clan statistics |
| `TopsGui` | `tops.yml` | Global leaderboards |
| `TrophiesGui` | — | Trophy/award display |
| `WarpsGui` | `warps.yml` | Clan warp management |

---

## 3. Listener System

### `PlayerListener.java`

| Event | Behavior |
|-------|----------|
| `PlayerJoinEvent` | Updates member online status, adds war context via CoreHook, applies level boosts, updates nametags, notifies clan, updates TAB, checks pending invites |
| `PlayerQuitEvent` | Cleans up war context, autoclaim, chat mode, teleport, power, fly, GUI state; marks offline, removes boosts, notifies clan, saves async |

### `TerritoryListener.java` (415 lines)

Comprehensive territory protection handling 16 Bukkit events.

| Event | Protection |
|-------|------------|
| `PlayerMoveEvent` | Autoclaim on chunk change, territory enter/exit titles + actionbar, chunk border particles, invasion alerts (30s cooldown per enemy) |
| `BlockBreakEvent` / `BlockPlaceEvent` | `canBuild()` check: bypass perm, own territory, ally build config, war build (HQ protected) |
| `EntityExplodeEvent` / `BlockExplodeEvent` | Checks `EXPLOSIONS` territory flag |
| `BlockIgniteEvent` | Checks `FIRE_SPREAD` flag |
| `PlayerInteractEvent` | Checks `CHEST_ACCESS` + `INTERACT` flags for containers/interactables |
| `CreatureSpawnEvent` | Checks `MOB_SPAWN` flag |
| `EntityDamageByEntityEvent` | Checks `ANIMAL_DAMAGE` flag for passive mobs |
| `PlayerTeleportEvent` | Checks `ENDERPEARL` and `CHORUS` flags |
| `BlockPistonExtendEvent` / `BlockPistonRetractEvent` | Prevents cross-territory piston mechanics |
| `BlockFromToEvent` | Prevents cross-territory liquid flow |
| `HangingBreakByEntityEvent` / `HangingPlaceEvent` | Territory protection for item frames/paintings |
| `PlayerInteractEntityEvent` | Territory protection for entity interactions |

**Territory Flags**: `EXPLOSIONS`, `FIRE_SPREAD`, `CHEST_ACCESS`, `INTERACT`, `MOB_SPAWN`, `ANIMAL_DAMAGE`, `ENDERPEARL`, `CHORUS`, `PVP`, `FLY`

### `PlayerDamageListener.java`

| Event | Behavior |
|-------|----------|
| `EntityDamageByEntityEvent` | Checks PVP flag in territory, tags combatants via CombatHook |
| `EntityDamageEvent` | Cancels pending teleports on any damage |

### `CombatListener.java`

| Event | Behavior |
|-------|----------|
| `EntityDamageByEntityEvent` | Friendly fire protection (same clan), allied PvP blocking |
| `PlayerDeathEvent` | 5-min kill cooldown (anti-farm), power gain/loss, war scoring, KD tracking, mission progress, fly disable on death |

### `ChatListener.java`

| Event | Behavior |
|-------|----------|
| `AsyncChatEvent` | Anvil input interception, chat mode routing (clan/ally/officer/nation), @mention sound notifications, global chat clan tag prefix |

### `PlayerChatListener.java`

Backup/duplicate chat handler using `HIGHEST` priority. Prefix-based (`!` for clan) or toggle-based clan chat.

### `ChatFormatListener.java`

Global chat tag formatting and tab list format via `AsyncChatEvent` and `PlayerJoinEvent`.

### `TerritoryFlyListener.java`

| Event | Behavior |
|-------|----------|
| `PlayerMoveEvent` | Auto-enable flight in own territory (if FLY flag set), auto-disable when leaving with grace period |
| `PlayerQuitEvent` | Cleanup fly state |

### `SkillEffectListener.java`

| Event | Behavior |
|-------|----------|
| `EntityDamageByEntityEvent` | Fortification (damage reduction in own territory), Sharpness (war damage bonus) |
| `PlayerMoveEvent` | Territory potion effects: Vitality (regeneration), Haste (fast dig), Swiftness (speed) |

### `OutpostListener.java`

| Event | Behavior |
|-------|----------|
| `BlockBreakEvent` | Prevents breaking outpost blocks (Officer+ only via command) |
| `EntityExplodeEvent` / `BlockExplodeEvent` | Explosion protection for outposts |
| `PlayerInteractEvent` | Right-click outpost → info display |
| `PlayerMoveEvent` | Watchtower enemy detection (30s cooldown per alert) |

### `AchievementListener.java`

Listens to 9 custom `ClanEvent` types and triggers achievement checks:
`ClanCreateEvent`, `ClanMemberJoinEvent`, `ClanPowerChangeEvent`, `ClanLevelUpEvent`, `ClanClaimEvent`, `ClanWarEndEvent`, `ClanAllyEvent`, `ClanBankEvent`, `ClanUpgradeEvent`

---

## 4. WebMap Server

### `webmap/WebMapServer.java` (2210 lines)

Embedded HTTP server (`com.sun.net.httpserver.HttpServer`) serving a real-time interactive territory map.

| Method | Signature | Purpose |
|--------|-----------|---------|
| `start` | `void start()` | Binds HTTP server to configured port, registers all route handlers |
| `stop` | `void stop()` | Stops HTTP server, cancels background tasks |
| `isEnabled` | `boolean isEnabled()` | WebMap enabled status |
| `getPort` | `int getPort()` | Configured port number |
| `getTerrainRenderer` | `TerrainRenderer getTerrainRenderer()` | Returns terrain tile renderer |
| `addChatMessage` | `void addChatMessage(String, String, String, String)` | Adds chat message to web buffer |

### Complete HTTP API (47 Endpoints)

#### Core Data

| Method | Route | Response | Description |
|--------|-------|----------|-------------|
| `GET` | `/` | HTML5 page | Interactive canvas-based map frontend |
| `GET` | `/api/clans` | `[{id, name, displayName, tag, leader, members, online, claims, power, maxPower, level, color}]` | All clans |
| `GET` | `/api/territory` | `[{world, x, z, clanId}]` | All claimed chunks |
| `GET` | `/api/wars` | `[{attacker, defender, tags, type, kills}]` | Active wars |
| `GET` | `/api/rankings` | `[{rank, id, name, tag, power, members, online, level, claims}]` | Top 50 clans by power |
| `GET` | `/api/nations` | `[{id, name, tag, clanCount, leaderClan}]` | All nations |
| `GET` | `/api/stats` | `{clans, claims, wars, online, version}` | Server stats summary |
| `GET` | `/api/config` | `{title, subtitle, icon}` | WebMap branding config |

#### Map Tiles

| Method | Route | Response | Description |
|--------|-------|----------|-------------|
| `GET` | `/api/tiles/list?world=X` | `[[x,z],...]` | Available terrain tile coordinates |
| `GET` | `/api/tiles/{world}/{rx}/{rz}.png` | PNG image (512×512) | Cached terrain tile (202 if not ready) |

#### Player Identification

| Method | Route | Response | Description |
|--------|-------|----------|-------------|
| `GET` | `/api/me` | `{identified, uuid, name, clanId, clanName, clanTag, isOp, power, role, kills, deaths}` | IP-based player identification (supports X-Forwarded-For) |

#### Clan Details

| Method | Route | Response | Description |
|--------|-------|----------|-------------|
| `GET` | `/api/clan/members?id=X` | `[{uuid, name, role, roleIcon, kills, deaths, kd, power, online, joinDate, lastSeen}]` | Clan members detail |
| `GET/POST/DELETE` | `/api/clan/logo?id=X&type=logo\|banner` | PNG/GIF or status | Clan logo/banner (max 2MB GIF, 512KB PNG, NSFW detection, LEADER-only upload/delete) |
| `GET/POST` | `/api/clan-theme` | JSON | Clan gradient themes (leader-only set) |

#### Admin

| Method | Route | Response | Description |
|--------|-------|----------|-------------|
| `POST/DELETE` | `/api/admin/logo?id=X&type=logo\|banner` | status | Admin logo management (OP-only) |

#### Leaderboards & Stats

| Method | Route | Response | Description |
|--------|-------|----------|-------------|
| `GET` | `/api/leaderboard` | `[{uuid, name, clan, clanColor, kills, deaths, kd, power, online}]` | Top 100 players by kills |
| `GET` | `/api/alliances` | `[{a, b, type}]` | Clan relationships (ally/enemy) |
| `GET` | `/api/activity` | `[{clan, player, action, details, icon, timestamp}]` | Last 50 audit entries |
| `GET` | `/api/recruitment` | `[{clanId, name, tag, color, leader, level, power, claims, members, maxMembers, spotsOpen, online}]` | Open clans with capacity |
| `GET` | `/api/hall-of-fame` | JSON | Server records (biggest clan, most powerful) |
| `GET` | `/api/achievements` | JSON | Computed achievement badges per clan |

#### Live Data

| Method | Route | Response | Description |
|--------|-------|----------|-------------|
| `GET` | `/api/power-history` | JSON | Hourly power snapshots (7 days, 168 entries) |
| `GET/POST` | `/api/chat` | `[{sender, tag, message, time}]` / status | GET: last 50 messages; POST: send from web to in-game |
| `GET` | `/api/server-stats` | `{tps, tps5, tps15, memoryUsed, memoryMax, uptimeMs, onlinePlayers, maxPlayers, clans, claims, wars, version}` | Server performance |
| `GET` | `/api/players/positions` | `[{uuid, name, x, z, world, clan, clanColor}]` | Online player map markers |
| `GET` | `/api/pvp-heatmap` | `[{x, z, killer, victim, timestamp}]` | Last 200 PvP kills |
| `GET` | `/api/world-info` | `{time, isDay, weather}` | World state |
| `GET` | `/api/notifications?since=ts` | `[{type, title, detail, timestamp}]` | Live notifications since timestamp |
| `GET` | `/api/activity-heatmap` | `[{x, z}]` | Player movement heatmap |

#### Territory History

| Method | Route | Response | Description |
|--------|-------|----------|-------------|
| `GET` | `/api/territory-history` | JSON | Territory snapshots for replay (30-min intervals, 24h) |
| `GET` | `/api/territory-growth` | JSON | Territory count per clan over time |
| `GET` | `/api/fog` | JSON | Fog-of-war per player (own + clan + ally discovered chunks) |

#### Interactive Features

| Method | Route | Response | Description |
|--------|-------|----------|-------------|
| `GET/POST/DELETE` | `/api/poi` | JSON | Points of Interest (leader-only CRUD) |
| `GET/POST/DELETE` | `/api/claim-planner` | JSON | Ghost claim planning per clan |
| `GET` | `/api/war-timeline` | JSON | Wars + kills timeline |
| `GET/POST/DELETE` | `/api/clan-votes` | JSON | Clan internal voting (officer+ create, members vote, 24h expiry) |
| `GET/POST` | `/api/diplomacy` | JSON | Diplomacy proposals (leader-only create) |
| `GET` | `/api/player-compare?a=uuid&b=uuid` | JSON | Compare two players |
| `GET` | `/api/discord-widget` | HTML | Embeddable HTML widget |
| `GET` | `/api/biomes` | JSON | Static biome type list |

#### Placeholder Endpoints (EmptyArrayHandler)

`/api/gallery`, `/api/blog`, `/api/trading`, `/api/announcements`, `/api/server-polls`, `/api/battle-replays`, `/api/mentors`, `/api/voice-rooms`, `/api/resource-heatmap`, `/api/structures`

`/api/reputation` → EmptyObjectHandler (`{}`)

#### Internal Data Buffers

| Buffer | Capacity | Retention |
|--------|----------|-----------|
| Chat messages | 50 | Rolling |
| PvP kills | 200 | Rolling |
| Power history | 168 snapshots | 7 days (hourly) |
| Territory history | 48 snapshots | 24h (30-min intervals) |
| Activity positions | 2000 | Rolling |
| Fog-of-war | Per player | Persistent (file) |
| POI / themes / claim-planner / votes / diplomacy | Per clan | File-based persistence |

### `webmap/TerrainRenderer.java` (608 lines)

Top-down terrain tile renderer.

- **Tile size**: 512×512 PNG, 1 pixel = 1 block, 1 tile = 32×32 chunks
- **Rendering**: Paper async `ChunkSnapshot` → block type mapping to RGB colors
- **Block colors**: 200+ `Material` → hex RGB mappings (stone, grass, water, lava, ores, etc.)
- **Cache**: Disk-cached at `plugins/EthernovaClans/webmap/tiles/{world}/r.{x}.{z}.png`

---

## 5. Achievement System

### `achievement/AchievementManager.java` (500 lines)

Persistent clan milestones loaded from `achievements.yml`.

| Method | Signature | Purpose |
|--------|-----------|---------|
| `loadDefinitions` | `void loadDefinitions()` | Loads achievement definitions from YAML |
| `checkAchievements` | `void checkAchievements(Clan)` | Checks all achievements for a clan |
| `checkAchievements` | `void checkAchievements(Clan, AchievementType)` | Checks specific type only |
| `isUnlocked` | `boolean isUnlocked(Clan, String)` | Whether a specific achievement is unlocked |
| `getUnlockedAchievements` | `Set<String> getUnlockedAchievements(Clan)` | All unlocked achievement IDs |
| `getUnlockedCount` | `int getUnlockedCount(Clan)` | Count of unlocked achievements |
| `getTotalCount` | `int getTotalCount()` | Total achievement definitions |
| `getAllDefinitions` | `Collection<AchievementDefinition> getAllDefinitions()` | All definitions |
| `getProgress` | `double getProgress(Clan, AchievementDefinition)` | Progress percentage (0.0-1.0) |
| `getCurrentProgress` | `int getCurrentProgress(Clan, AchievementDefinition)` | Current raw progress value |
| `trackMissionCompletion` | `void trackMissionCompletion(Clan)` | Track mission-type achievement |
| `trackUpgradePurchase` | `void trackUpgradePurchase(Clan)` | Track upgrade-type achievement |
| `loadAllFromDatabase` | `void loadAllFromDatabase()` | Load from SQL |
| `saveAllToDatabase` | `void saveAllToDatabase()` | Save to SQL |
| `cleanupClan` | `void cleanupClan(String)` | Remove data for disbanded clan |

**AchievementType enum**: `KILLS`, `DEATHS`, `MEMBERS`, `CLAIMS`, `POWER`, `LEVEL`, `BANK_BALANCE`, `WARS_WON`, `WARS_FOUGHT`, `ALLIES`, `UPGRADES`, `MISSIONS`, `DEPOSITS`

**AchievementDefinition record**: `id`, `name`, `description`, `type`, `target`, `icon`, `powerReward`, `moneyReward`, `xpReward`

**Rewards on unlock**: Power bonus, money (to clan bank), XP (as extra power)

---

## 6. Mission System

### `mission/MissionManager.java` (500 lines)

Daily/weekly clan missions with progress tracking and rewards.

| Method | Signature | Purpose |
|--------|-----------|---------|
| `loadMissions` | `void loadMissions()` | Loads mission definitions from `missions.yml` |
| `assignDailyMissions` | `void assignDailyMissions(Clan)` | Assigns random daily missions to a clan |
| `getActiveMissions` | `List<ActiveMission> getActiveMissions(Clan)` | Currently active missions |
| `updateProgress` | `void updateProgress(Clan, MissionType, int)` | Increments progress for a mission type |
| `getDefinition` | `MissionDefinition getDefinition(String)` | Get definition by ID |
| `getAllDefinitions` | `Collection<MissionDefinition> getAllDefinitions()` | All definitions |
| `loadAllFromDatabase` | `void loadAllFromDatabase()` | Load from SQL |
| `saveAllToDatabase` | `void saveAllToDatabase()` | Save to SQL |
| `cleanupClan` | `void cleanupClan(String)` | Cleanup for disbanded clan |

**MissionType enum**: `KILLS`, `DEATHS`, `DEPOSITS`, `WAR_WINS`, `CLAIMS`, `MEMBERS`, `POWER_GAIN`

**MissionDefinition record**: `id`, `displayName`, `description`, `type`, `target`, `category`, `powerReward`, `moneyReward`, `icon`

**ActiveMission class**: Tracks `definitionId`, `type`, `target`, `progress`, `expiresAt`, `completed` with methods `addProgress()`, `isCompleted()`, `isExpired()`, `getProgressPercent()`

---

## 7. Skill System

### `skill/ClanSkillManager.java` (300 lines)

Passive skill tree earned from leveling. 8 skills with SQL persistence.

| Method | Signature | Purpose |
|--------|-----------|---------|
| `getSkillLevel` | `int getSkillLevel(String clanId, String skillId)` | Current level of a skill |
| `getSkills` | `Map<String, Integer> getSkills(String)` | All skill levels for a clan |
| `getTotalSkillPoints` | `int getTotalSkillPoints(String)` | Total spent skill points |
| `getAvailablePoints` | `int getAvailablePoints(Clan)` | Unspent skill points (clan level - spent) |
| `getSkillValue` | `double getSkillValue(String, String)` | Computed value for a skill at current level |
| `upgradeSkill` | `boolean upgradeSkill(Clan, String)` | Spend a point to upgrade a skill |
| `resetSkills` | `void resetSkills(Clan)` | Reset all skills (refund points) |
| `loadAll` | `void loadAll()` | Load from `clan_skills` SQL table |
| `cleanupClan` | `void cleanupClan(String)` | Remove data on disband |

**Skill Definitions**:

| Skill | Effect | Max Level |
|-------|--------|-----------|
| `fortification` | Damage reduction in own territory | 5 |
| `sharpness` | War damage bonus | 5 |
| `treasury` | Bank interest bonus | 5 |
| `expansion` | Extra territory claims | 5 |
| `recruitment` | Extra member slots | 5 |
| `vitality` | Regeneration in own territory | 3 |
| `haste` | Fast digging in own territory | 3 |
| `swiftness` | Speed in own territory | 3 |

---

## 8. Clan Shop

### `shop/ClanShopManager.java` (300 lines)

Internal marketplace — officers list items, members buy with personal money, revenue to clan bank.

| Method | Signature | Purpose |
|--------|-----------|---------|
| `getShopItems` | `List<ShopItem> getShopItems(String clanId)` | All items listed by a clan |
| `getItem` | `ShopItem getItem(String clanId, String itemId)` | Get specific item |
| `addItem` | `String addItem(Clan, Player, Material, String, double, int)` | List new item (Officer+) |
| `removeItem` | `String removeItem(Clan, String)` | Remove listing |
| `buyItem` | `String buyItem(Clan, Player, String)` | Purchase item (Vault withdraw → bank deposit) |
| `restockItem` | `String restockItem(Clan, String, int)` | Restock item quantity |
| `loadAll` | `void loadAll()` | Load from `clan_shop` SQL table |
| `cleanupClan` | `void cleanupClan(String)` | Cleanup on disband |

**ShopItem record**: `id`, `clanId`, `material`, `displayName`, `price`, `stock`, `maxStock`, `addedBy`

---

## 9. Fly System

### `fly/FlyManager.java` (200 lines)

Territory-based flight permissions.

| Method | Signature | Purpose |
|--------|-----------|---------|
| `toggleFly` | `void toggleFly(Player)` | Toggle flight (requires clan level threshold) |
| `enableFly` | `void enableFly(Player)` | Enable flight |
| `disableFly` | `void disableFly(Player)` | Disable flight (safe landing, resets fall distance) |
| `checkFlyOnChunkChange` | `void checkFlyOnChunkChange(Player, String)` | Auto-enable/disable based on territory ownership |
| `removePlayer` | `void removePlayer(UUID)` | Cleanup on quit |
| `isFlying` | `boolean isFlying(UUID)` | Check fly state |

**Features**: Level requirement, own territory + allied territory support, grace period when leaving, safe fall distance reset.

---

## 10. Teleport System

### `teleport/TeleportManager.java` (308 lines)

Clan home teleportation with warmup, cooldown, and economy cost.

| Method | Signature | Purpose |
|--------|-----------|---------|
| `teleportHome` | `void teleportHome(Player, Clan)` | Teleport to clan home (validates home exists, cooldown, cost) |
| `teleportWithWarmup` | `void teleportWithWarmup(Player, Location, String)` | Generic warmup teleport with action bar countdown |
| `teleportWithWarmup` | `void teleportWithWarmup(Player, Location, String, Runnable)` | Warmup with completion callback |
| `setHome` | `void setHome(Player, Clan)` | Set clan home (must be in own territory) |
| `cancelTeleport` | `void cancelTeleport(UUID)` | Cancel pending teleport |
| `hasPendingTeleport` | `boolean hasPendingTeleport(UUID)` | Check for pending teleport |
| `cancelAllTeleports` | `void cancelAllTeleports()` | Cancel all pending teleports |
| `serializeLocation` | `static String serializeLocation(Location)` | `world:x:y:z:yaw:pitch` format |
| `parseLocation` | `static Location parseLocation(String)` | Deserialize location string |

**Features**: Movement cancellation during warmup, per-player cooldown, Vault economy cost, re-verification after warmup completes.

**TeleportRequest record**: `BukkitTask task`

---

## 11. Salary System

### `salary/SalaryManager.java` (210 lines)

Automatic salary payments from clan bank to members, configurable per role.

| Method | Signature | Purpose |
|--------|-----------|---------|
| `getSalary` | `double getSalary(String clanId, ClanRole role)` | Get salary amount for a role |
| `setSalary` | `void setSalary(String clanId, ClanRole role, double amount)` | Set salary amount |
| `getSalaryConfig` | `Map<String,Double> getSalaryConfig(String clanId)` | Full salary config for clan |
| `getTotalSalaryCost` | `double getTotalSalaryCost(Clan)` | Sum of all member salaries |
| `paySalaries` | `void paySalaries()` | Pay all clans (called on timer) |
| `payClanSalaries` | `void payClanSalaries(Clan)` | Pay single clan's online members |
| `loadAll` | `void loadAll()` | Load from `clan_salaries` SQL table |
| `cleanupClan` | `void cleanupClan(String)` | Cleanup on disband |

**Timer**: Runs every `salary.interval-minutes` (default 60min). Only pays **online** members. Checks bank balance before paying. Audit logged.

---

## 12. Shield System

### `shield/ShieldManager.java`

Post-war shields preventing war declarations for a period.

| Method | Signature | Purpose |
|--------|-----------|---------|
| `activateShield` | `void activateShield(String clanId, int hours)` | Activate shield for N hours |
| `hasActiveShield` | `boolean hasActiveShield(String clanId)` | Check if shield is active |
| `getRemainingMs` | `long getRemainingMs(String clanId)` | Remaining shield time in ms |
| `tick` | `void tick()` | Cleanup expired shields |
| `removeShield` | `void removeShield(String clanId)` | Force-remove shield |
| `getAllShields` | `Map<String,Long> getAllShields()` | All active shields (for persistence) |
| `loadShield` | `void loadShield(String clanId, long expiryMs)` | Load from storage |

---

## 13. Nation System

### `nation/Nation.java`

Data model for a "clan of clans".

| Field | Type | Description |
|-------|------|-------------|
| `id` | `String` | 8-char UUID |
| `name` | `String` | Nation name |
| `tag` | `String` | Short tag |
| `description` | `String` | Optional description |
| `leaderClanId` | `String` | Leading clan's ID |
| `memberClans` | `Map<String, NationRole>` | clanId → role |
| `createdAt` | `long` | Creation timestamp |

**NationRole enum**: `LEADER`, `OFFICER`, `MEMBER` (with `isAtLeast()`)

### `nation/NationManager.java` (382 lines)

| Method | Signature | Purpose |
|--------|-----------|---------|
| `createNation` | `Nation createNation(String name, String tag, Clan leaderClan)` | Create new nation |
| `disbandNation` | `void disbandNation(Nation)` | Disband nation |
| `inviteClan` | `String inviteClan(Nation, Clan)` | Invite a clan (returns error or null) |
| `acceptInvite` | `String acceptInvite(Clan)` | Accept pending invite |
| `denyInvite` | `void denyInvite(String clanId)` | Deny invite |
| `kickClan` | `String kickClan(Nation, String, String)` | Kick clan (rank-gated) |
| `leaveClan` | `String leaveClan(Nation, Clan)` | Leave nation (leader cannot) |
| `promoteClan` | `String promoteClan(Nation, String, String)` | Promote → Officer or transfer leadership |
| `demoteClan` | `String demoteClan(Nation, String, String)` | Demote → Member |
| `getNation` | `Nation getNation(String)` | Get by nation ID |
| `getNationByClan` | `Nation getNationByClan(String clanId)` | Get nation for a clan |
| `isInNation` | `boolean isInNation(String clanId)` | Check membership |
| `isNationAlly` | `boolean isNationAlly(String, String)` | Check if two clans share a nation |
| `getAllNations` | `Collection<Nation> getAllNations()` | All nations |
| `sendNationMessage` | `void sendNationMessage(Nation, Player, String)` | Nation chat broadcast |
| `broadcastNation` | `void broadcastNation(Nation, String)` | Broadcast MiniMessage to all nation members |
| `getTerritoryBonus` | `int getTerritoryBonus(String clanId)` | +2 claims per ally clan |
| `getPowerMultiplier` | `double getPowerMultiplier(String clanId)` | +5% per ally clan |
| `loadAll` | `void loadAll()` | Load from `clan_nations` + `clan_nation_members` SQL |
| `saveAsync` | `void saveAsync(Nation)` | Async SQL upsert |
| `saveAll` | `void saveAll()` | Save all nations |

**Config**: `nations.max-clans` (8), `nations.min-clans-to-create` (1), `nations.create-cost` (5000), `nations.tax-percent` (5.0)

---

## 14. Outpost System

### `outpost/OutpostType.java` (enum)

5 outpost structure types:

| Type | Icon | Cost | Max Level | Base HP | Resource/min | Effect |
|------|------|------|-----------|---------|--------------|--------|
| `NEXUS` | BEACON | $1000 | 5 | 100 | 0 | +10 max power per level |
| `WATCHTOWER` | END_ROD | $500 | 3 | 50 | 0 | Enemy detection (level×2 chunk radius) |
| `RESOURCE_EXTRACTOR` | BLAST_FURNACE | $750 | 5 | 80 | 10 | Passive income ($0.5/unit/min) |
| `WALL_GATE` | IRON_BLOCK | $300 | 3 | 150 | 0 | Visual chunk border protection |
| `WAR_CAMP` | RED_BED | $1500 | 1 | 30 | 0 | War respawn point in enemy territory |

### `outpost/Outpost.java`

Data model for a placed outpost. Fields: `id`, `clanId`, `type`, `level`, `health`, `maxHealth`, `location`, `placedAt`, `lastResourceGen`. Methods: `damage(int)→boolean`, `repair()`, `upgrade()→boolean`, `isDestroyed()`, `canUpgrade()`, `getResourceRate()`, `getHealthPercent()`.

### `outpost/OutpostManager.java` (455 lines)

| Method | Signature | Purpose |
|--------|-----------|---------|
| `placeOutpost` | `String placeOutpost(Player, OutpostType)` | Place outpost (validates territory, max limits, cost) |
| `removeOutpost` | `String removeOutpost(Player, Location)` | Remove outpost at location |
| `upgradeOutpost` | `String upgradeOutpost(Player, Location)` | Upgrade outpost (validates cost, max level) |
| `damageOutpost` | `boolean damageOutpost(Location, int, Player)` | Deal damage during war (returns true if destroyed) |
| `getOutpostAt` | `Outpost getOutpostAt(Location)` | Query outpost by location |
| `getClanOutposts` | `List<Outpost> getClanOutposts(String)` | All outposts for a clan |
| `getClanOutposts` | `List<Outpost> getClanOutposts(String, OutpostType)` | Filtered by type |
| `getOutpostCount` | `int getOutpostCount(String)` | Count for a clan |
| `getNexusPowerBonus` | `int getNexusPowerBonus(String)` | Sum of nexus level × 10 |
| `hasWatchtowerCoverage` | `boolean hasWatchtowerCoverage(String, Chunk)` | Check watchtower detection range |
| `isOutpostBlock` | `boolean isOutpostBlock(Location)` | Check if block is an outpost |
| `tickResources` | `void tickResources()` | Generate passive income for extractors (call every minute) |
| `loadAll` | `void loadAll()` | Load from `clan_outposts` SQL |
| `saveAll` | `void saveAll()` | Save all outposts |

**Config**: `outposts.max-per-clan` (10), `outposts.max-per-chunk` (2)

**Indexes**: `locationIndex` (location key → outpost ID), `clanOutposts` (clan ID → outpost IDs)

---

## 15. Blueprint System

### `blueprint/Blueprint.java`

Data model for blueprint type definitions. Contains `BlueprintLevel` inner class with `cost`, `materials` (Map<Material, Integer>), and `effects` (Map<String, Double>).

### `blueprint/ClanBlueprint.java`

Instance of a built blueprint: `blueprintId`, `clanId`, `chunkId`, `level`, `builtAt`.

### `blueprint/BlueprintManager.java` (480 lines)

| Method | Signature | Purpose |
|--------|-----------|---------|
| `loadConfig` | `void loadConfig()` | Loads from `blueprints.yml` |
| `build` | `boolean build(Clan, String, String, Player)` | Build blueprint (validates territory, max slots, cost, materials) |
| `upgrade` | `boolean upgrade(Clan, String, Player)` | Upgrade to next level |
| `demolish` | `boolean demolish(Clan, String, Player)` | Demolish (refunds 50% materials + money) |
| `removeAllForClan` | `void removeAllForClan(String)` | Remove all on disband |
| `removeInChunk` | `void removeInChunk(String clanId, String chunkId)` | Remove when chunk lost |
| `getTotalEffect` | `double getTotalEffect(String clanId, String effectKey)` | Sum effect value across all blueprints |
| `hasInChunk` | `boolean hasInChunk(String, String, String)` | Check for blueprint in chunk |
| `getBlueprints` | `List<ClanBlueprint> getBlueprints(String)` | All blueprints for clan |
| `getMaxSlots` | `int getMaxSlots(int clanLevel)` | Max blueprint slots by level |
| `getBlueprintTypes` | `Map<String,Blueprint> getBlueprintTypes()` | All type definitions |
| `loadAll` / `saveAll` | | SQL persistence in `clan_blueprints` table |

**Features**: Per-level cost + material requirements, configurable effects per level, hologram integration (stub), 50% demolition refund.

---

## 16. Season System

### `season/SeasonEntry.java`

Tracks clan performance: `clanId`, `clanName`, `season`, `kills`, `deaths`, `power`, `level`, `members`, `warsWon`, `territories`, `balance`, `score`, `rank`.

**Score formula**: `kills×2 + warsWon×50 + power + level×10 + territories×5`

### `season/SeasonManager.java` (359 lines)

| Method | Signature | Purpose |
|--------|-----------|---------|
| `updateSeasonData` | `void updateSeasonData()` | Snapshot all clan stats |
| `endSeason` | `void endSeason()` | End season: save history, distribute rewards, broadcast, start new |
| `getCurrentSeason` | `int getCurrentSeason()` | Current season number |
| `getSeasonStartTime` | `long getSeasonStartTime()` | Season start timestamp |
| `getTimeRemainingMs` | `long getTimeRemainingMs()` | Time until season ends |
| `getCurrentRankings` | `List<SeasonEntry> getCurrentRankings()` | Live rankings (sorted by score) |
| `getSeasonHistory` | `List<SeasonEntry> getSeasonHistory(int)` | Historical season data |
| `forceEndSeason` | `void forceEndSeason()` | Admin force-end |
| `saveCurrentEntries` | `void saveCurrentEntries()` | Save to `clan_season_entries` SQL |

**Config**: `seasons.enabled`, `seasons.duration-days` (30), `seasons.rewards.{1,2,3}.money`, `seasons.rewards.{1,2,3}.power-bonus`

**Rewards**: Top 3 clans receive configurable money (to bank) and power bonuses. Broadcast top 10 results with medals (🥇🥈🥉).

**Check interval**: Every hour via BukkitTask timer.

---

## 17. Tax System

### `tax/TaxManager.java` (200 lines)

Two-tier automatic taxation: Member → Clan bank, Clan → Nation treasury.

| Method | Signature | Purpose |
|--------|-----------|---------|
| `collectTaxes` | `void collectTaxes()` | Main tax cycle (both tiers) |
| `collectNow` | `void collectNow()` | Force immediate collection |
| `isEnabled` | `boolean isEnabled()` | Tax system enabled |
| `start` / `stop` / `shutdown` | | Lifecycle management |

**Config**:
- `taxes.enabled` (false)
- `taxes.member-tax-mode`: `"percent"`, `"flat"`, or `"both"`
- `taxes.member-tax-percent` (5.0)
- `taxes.member-tax-flat` (100.0)
- `taxes.interval-minutes` (60)
- `taxes.nation-tax-percent` (5.0)
- `taxes.notify-members` (true)
- `taxes.exempt-officers` (false)

**Tax flow**: Online members' Vault balance → clan bank. Clan bank % → nation leader clan's bank (if in nation).

---

## 18. Spy System

### `spy/SpyManager.java` (270 lines)

Espionage system with 3 features:

#### Admin Social Spy

| Method | Signature | Purpose |
|--------|-----------|---------|
| `toggleSocialSpy` | `boolean toggleSocialSpy(UUID)` | Toggle spy mode (returns new state) |
| `isSocialSpy` | `boolean isSocialSpy(UUID)` | Check if spy |
| `forwardToSpies` | `void forwardToSpies(String chatType, String clanTag, String sender, String msg)` | Forward all clan/ally/nation chat to spies |

#### Infiltration

| Method | Signature | Purpose |
|--------|-----------|---------|
| `startInfiltration` | `String startInfiltration(Player, Clan)` | Start spying on enemy clan chat (timed, costs money) |
| `stopInfiltration` | `void stopInfiltration(UUID)` | End infiltration |
| `isInfiltrating` | `boolean isInfiltrating(UUID, String)` | Check if infiltrating specific clan |
| `forwardToInfiltrators` | `void forwardToInfiltrators(String clanId, String sender, String tag, String msg)` | Forward clan chat to active infiltrators |

**Config**: `spy.infiltration-duration-seconds` (300), `spy.infiltration-cooldown-seconds` (600), `spy.infiltration-cost-per-minute` ($50)

#### Intel Reports

| Method | Signature | Purpose |
|--------|-----------|---------|
| `generateIntelReport` | `String generateIntelReport(Player, Clan)` | Generate detailed enemy intel (members, power, shield, threat level) |

**Threat assessment**: Computed from `(power/maxPower) × members`. Categories: EXTREMO (>50), ALTO (>30), MEDIO (>15), BAJO (≤15).

---

## 19. Nametag System

### `nametag/NametagManager.java`

Manages above-head and tab list nametags using Bukkit Scoreboard Teams.

| Method | Signature | Purpose |
|--------|-----------|---------|
| `initialize` | `void initialize()` | Initialize main scoreboard, cleanup old `ec_` teams |
| `updatePlayer` | `void updatePlayer(Player)` | Set nametag prefix with clan tag (from config format `{clan_tag}`) |
| `removePlayer` | `void removePlayer(Player)` | Remove from team, unregister empty teams |
| `updateAllPlayers` | `void updateAllPlayers()` | Update all online players |
| `updateClanMembers` | `void updateClanMembers(Clan)` | Update members of a specific clan |
| `shutdown` | `void shutdown()` | Cleanup all `ec_` teams |

**Team naming**: `ec_` + first 13 chars of UUID (max 16 chars for Bukkit). Updates both `displayName()` and `playerListName()`.

---

## 20. Placeholder Expansion

### `placeholder/ClanPlaceholderExpansion.java`

PlaceholderAPI expansion with prefix `%ethernova_clans_%`.

**Supported placeholders**:

| Placeholder | Output |
|-------------|--------|
| `has_clan` | `true`/`false` |
| `clan_name` | Clan name |
| `clan_display` | Display name |
| `clan_tag` | Tag text |
| `clan_desc` | Description |
| `clan_members` | Member count |
| `clan_online` | Online count |
| `clan_power` / `clan_max_power` | Power values |
| `player_power` / `player_max_power` | Player power |
| `clan_claims` / `clan_max_claims` | Claim counts |
| `clan_bank` | Formatted bank balance |
| `clan_level` / `clan_xp` | Level and XP |
| `clan_allies` | Ally count |
| `clan_leader` | Leader name |
| `at_war` | War status |
| `has_shield` | Shield status |
| `player_role` | Player's role display name |
| `total_clans` | Total clans on server |
| `clan_formatted` | `[TAG] ` prefix |
| `clan_warps` / `clan_max_warps` | Warp counts |
| `has_nation` / `nation_name` / `nation_tag` / `nation_role` / `nation_clans` / `nation_leader` | Nation data |
| `outpost_count` | Outpost count |

### `hook/PlaceholderHook.java`

Alternative expansion with prefix `%ethernova_%`. Provides additional placeholders:

| Placeholder | Output |
|-------------|--------|
| `clan_tag_colored` / `clan_tag_formatted` | MiniMessage → legacy §-codes conversion |
| `clan_id` | Clan UUID |
| `clan_level_name` | Level displayname |
| `clan_kills` / `clan_deaths` / `clan_kd` | Combat stats |
| `clan_wars_won` / `clan_wars_lost` | War record |
| `clan_balance_formatted` | `$1,234.56` format |
| `clan_max_allies` / `clan_rivals` | Diplomacy |
| `player_role_lower` | Lowercase role |
| `player_kills` / `player_deaths` / `player_kd` / `player_power_contributed` | Per-member stats |
| `clan_friendly_fire` / `clan_invite_mode` / `clan_war_participation` | Settings |
| `clan_color` / `clan_gradient_start` / `clan_gradient_end` / `clan_use_gradient` | Color config |

---

## 21. Hook Layer

All hooks use **reflection** to avoid compile-time dependencies (except VaultHook which uses API directly).

### `hook/CoreHook.java`

Integration with **EthernovaCore** companion plugin.

| Method | Purpose |
|--------|---------|
| `addContext(UUID, String)` / `removeContext` / `hasContext` | Player context management (e.g., "in_war") |
| `publishEvent(Object)` / `subscribeEvent(Class, Consumer)` | Cross-plugin event bus |
| `sendTitle(Player, String, String)` / `sendActionBar(Player, String)` | Visual effects via Core |
| `setCooldown(UUID, String, long)` / `hasCooldown` / `getRemainingFormatted` | Cooldown management |
| `getProfile(UUID)` | Player profile access |
| `register()` / `unregister()` | Plugin lifecycle registration |

### `hook/CombatHook.java`

Integration with **EthernovaCombat**.

| Method | Purpose |
|--------|---------|
| `isInCombat(Player/UUID)` | Check combat tag status |
| `tagForWar(Player, Player)` | Tag both players for war combat |
| `untag(Player)` | Remove combat tag |
| `getKillStreak(UUID)` | Get kill streak |
| `isNewbieProtected(UUID)` | Check newbie protection |

### `hook/VaultHook.java`

Direct Vault economy API. Methods: `getBalance`, `has`, `withdraw`, `deposit`, `format`, `isEnabled`.

### `hook/DynmapHook.java` (249 lines)

Dynmap/BlueMap territory overlay. Renders colored area markers for each clan's chunks with popup HTML info. Auto-detects Dynmap (full support) or BlueMap (stub). Updates every 5 minutes.

### `hook/TabHook.java`

TAB plugin integration. Forces placeholder refresh via reflection. TAB reads `%ethernova_clan_tag_colored%` automatically.

### `hook/WorldGuardHook.java`

WorldGuard 7 region protection. Methods: `isInProtectedRegion(Location)`, `canClaimChunk(Chunk)`, `canBuild(Player, Location)`. Prevents claiming in WG-protected regions.

### `hook/DecentHologramsHook.java`

DecentHolograms integration for ranking holograms. Methods: `updateTopHologram(category, location, topCount)`, `updateAllHolograms()`, `removeAll()`. Supports categories: power, kd, kills, level, balance.

---

## 22. Hologram Integration

### `hologram/HologramManager.java`

Lightweight wrapper around DecentHolograms DHAPI. Methods: `createBaseHologram(Clan, Location)`, `updateAll()`, `removeHologram(String)`, `removeAllHolograms()`. Creates holograms with format `&6&l⚑ {clan} &7Members: &f{count}`.

---

## 23. Audit System

### `audit/AuditAction.java` (enum)

23 action types: `CLAN_CREATED`, `CLAN_DISBANDED`, `MEMBER_JOINED`, `MEMBER_LEFT`, `MEMBER_KICKED`, `MEMBER_PROMOTED`, `MEMBER_DEMOTED`, `MEMBER_BANNED`, `MEMBER_UNBANNED`, `LEADERSHIP_TRANSFERRED`, `TERRITORY_CLAIMED`, `TERRITORY_UNCLAIMED`, `WAR_DECLARED`, `WAR_ENDED`, `ALLIANCE_FORMED`, `ALLIANCE_BROKEN`, `BANK_DEPOSIT`, `BANK_WITHDRAW`, `UPGRADE_PURCHASED`, `HOME_SET`, `DESCRIPTION_CHANGED`, `FLAG_CHANGED`, `LEVEL_UP`

### `audit/AuditManager.java` (300 lines)

In-memory + SQL audit log with pagination.

| Method | Signature | Purpose |
|--------|-----------|---------|
| `log` | `void log(Clan, Player, String action, String details)` | Log action (async SQL persist) |
| `getLog` | `List<AuditEntry> getLog(Clan, int page, int pageSize)` | Paginated log (in-memory or DB fallback) |
| `getTotalEntries` | `int getTotalEntries(Clan)` | Entry count |
| `getActionIcon` | `static String getActionIcon(String)` | Emoji icon per action type |
| `formatTimestamp` | `static String formatTimestamp(long)` | `dd/MM HH:mm` format |
| `removeClan` | `void removeClan(String)` | Cleanup on disband |

**AuditEntry record**: `UUID playerUuid`, `String playerName`, `String action`, `String details`, `long timestamp`

Max 100 entries per clan in memory.

### `audit/AuditLogger.java`

Direct SQL logger with its own `clan_audit_log` table creation. Methods: `log(clanId, UUID, playerName, AuditAction, details)`, `getRecentLogs(clanId, limit)`, `getRecentLogsAsync(clanId, limit, callback)`.

---

## 24. Scheduled Events

### `scheduledevent/EventScheduler.java` (421 lines)

Manages timed server events (Double Power, Double Money, KOTH, Happy Hour).

| Method | Signature | Purpose |
|--------|-----------|---------|
| `loadConfig` | `void loadConfig()` | Load event definitions from `scheduled-events.yml` |
| `start` | `void start()` | Start periodic check + restore active events from DB |
| `stop` | `void stop()` | Cancel check task, end all events |
| `activateEvent` | `boolean activateEvent(String eventId)` | Manually start an event |
| `endEvent` | `void endEvent(String eventId, boolean broadcast)` | End specific event |
| `endAllEvents` | `void endAllEvents()` | Force-end all |
| `getPowerMultiplier` | `double getPowerMultiplier()` | Current power multiplier from active events |
| `getMoneyMultiplier` | `double getMoneyMultiplier()` | Current money multiplier |
| `isKothActive` | `boolean isKothActive()` | KOTH event status |
| `getActiveEvents` | `Collection<ActiveEvent> getActiveEvents()` | Currently active events |
| `getAllDefinitions` | `Collection<EventDefinition> getAllDefinitions()` | All definitions |

**ClanEventType enum**: `DOUBLE_POWER`, `DOUBLE_MONEY`, `KOTH`, `HAPPY_HOUR`

**EventDefinition record**: `id`, `displayName`, `type`, `duration`, `cooldown`, `multiplier`, `broadcast`

**Activation**: Random activation on periodic check (configurable chance, default 15%). Respects per-event cooldowns. Events persist across restarts via DB.

---

## 25. Upgrade System

### `upgrade/UpgradeManager.java`

Config-driven clan upgrade purchasing.

| Method | Signature | Purpose |
|--------|-----------|---------|
| `getAllDefinitions` | `List<UpgradeDefinition> getAllDefinitions()` | All upgrade type definitions |
| `getDefinition` | `UpgradeDefinition getDefinition(String)` | Single definition |
| `getUpgradeValue` | `double getUpgradeValue(String, int level)` | Computed value: `base + increment × level` |
| `getAvailableUpgrades` | `List<String> getAvailableUpgrades()` | Upgrade IDs from config |
| `getUpgradeLevel` | `int getUpgradeLevel(Clan, String)` | Current level |
| `getMaxLevel` | `int getMaxLevel(String)` | Max level from config |
| `getUpgradeCost` | `double getUpgradeCost(String, int currentLevel)` | Cost: `baseCost × costMultiplier^level` |
| `purchaseUpgrade` | `boolean purchaseUpgrade(Clan, String)` | Purchase (tries bank first, falls back to leader wallet) |
| `getMemberSlotBonus` | `int getMemberSlotBonus(Clan)` | Bonus from `member-slots` upgrade + level bonus |
| `getMaxWarps` | `int getMaxWarps(Clan)` | Base warps + `warp-slots` upgrade bonus |
| `getTerritoryLimitBonus` | `int getTerritoryLimitBonus(Clan)` | Bonus from `territory-limit` upgrade |

**UpgradeDefinition record**: `id`, `displayName`, `description`, `icon`, `maxLevel`, `valueType`

---

## 26. Message System

### `message/MessageManager.java`

Multi-language message system with MiniMessage support.

| Method | Signature | Purpose |
|--------|-----------|---------|
| `load` | `void load()` | Loads language file based on `general.language` config. Saves defaults for 6 languages (es, en, pt, fr, de, zh) |
| `get` | `String get(String path, String... replacements)` | Get raw message with `{prefix}` and custom replacements. Cached. |
| `parse` | `Component parse(String miniMsg)` | Parse MiniMessage to Component |
| `sendMessage` | `void sendMessage(CommandSender, String path, String... replacements)` | Get + parse + send |
| `sendRaw` | `void sendRaw(CommandSender, String miniMsg)` | Send arbitrary MiniMessage |

**Supported languages**: Spanish (es), English (en), Portuguese (pt), French (fr), German (de), Chinese (zh)

---

## 27. Utilities

### `util/TextUtil.java` (206 lines)

MiniMessage text utilities.

| Method | Purpose |
|--------|---------|
| `parse(String)` → `Component` | Parse MiniMessage |
| `parse(String, String...)` → `Component` | Parse with `{placeholder}` replacements |
| `serialize(Component)` → `String` | Component to MiniMessage string |
| `plainText(Component)` → `String` | Strip all formatting |
| `stripFormatting(String)` → `String` | MiniMessage → plain text |
| `clickable(text, command, hover)` → `Component` | Clickable run-command component |
| `suggestCommand(text, command, hover)` → `Component` | Suggest-command component |
| `centerText(text, chatWidth)` → `String` | Approximately center text in chat |
| `formatNumber(long)` → `String` | Thousands separator (`1,234`) |
| `formatCurrency(double)` → `String` | Currency format (`$1,234.56`) |
| `truncate(text, maxLength)` → `String` | Truncate with ellipsis |
| `capitalize(text)` → `String` | First letter uppercase |
| `parseLore(List<String>)` → `List<Component>` | Parse lore lines |
| `progressBar(current, max, totalBars, filledColor, emptyColor, filledChar, emptyChar)` → `String` | Configurable progress bar |

### `util/ItemBuilder.java` (333 lines)

Fluent builder for `ItemStack` creation with MiniMessage support.

| Method | Purpose |
|--------|---------|
| `name(String miniMessage)` | Set display name (auto-prepends `<!i>` to remove italic) |
| `name(String, String... replacements)` | Name with replacements |
| `lore(List<String>)` | Set lore lines |
| `lore(List<String>, String... replacements)` | Lore with replacements |
| `addLore(String)` | Append lore line |
| `amount(int)` | Set stack size (1-64) |
| `glow()` | Enchantment glow effect |
| `glowIf(boolean)` | Conditional glow |
| `enchant(Enchantment, int)` | Add enchantment |
| `hideFlags()` | Hide all ItemFlags |
| `unbreakable()` | Set unbreakable |
| `customModelData(int)` | Set custom model data |
| `leatherColor(String hex)` | Leather armor color from hex |
| `skull(PlayerProfile)` | Set skull owner |
| `build()` → `ItemStack` | Build final item |
| Static: `filler(Material)` | Glass pane filler |
| Static: `navArrow(direction, name)` | Navigation arrow |
| Static: `backButton(name)` | Barrier back button |

### `util/TimeUtil.java`

Time parsing and formatting.

| Method | Purpose |
|--------|---------|
| `parseToMillis(String)` | Parse `"5m"`, `"2h"`, `"3d"`, `"1w"` to ms |
| `parseToSeconds(String)` | Parse to seconds |
| `parseToTicks(String)` | Parse to ticks (50ms each) |
| `formatDuration(long ms)` | `"2d 5h 30m"` format |
| `formatCompact(long ms)` | Two most significant units |
| `formatTimer(long seconds)` | `MM:SS` format |
| `formatRelative(long timestamp)` | `"5m ago"`, `"2h ago"`, `"3d ago"` |
| `hasExpired(long)` | Check if timestamp passed |
| `getRemaining(long)` | Time until expiry |

### `util/ColorUtil.java` (217 lines)

Color/gradient utilities for MiniMessage.

| Method | Purpose |
|--------|---------|
| `isValidHex(String)` | Validate `#RRGGBB` format |
| `normalizeHex(String)` | Ensure `#` prefix, uppercase |
| `solidColor(text, hex)` | `<color:#HEX>text</color>` |
| `gradient(text, start, end)` | `<gradient:#AAA:#BBB>text</gradient>` |
| `multiGradient(text, List<String>)` | Multi-point gradient |
| `formatClanTag(tag, color, gradStart, gradEnd, useGrad)` | Build formatted clan tag |
| `hexToColor(String)` → `java.awt.Color` | Convert hex string |
| `colorToHex(Color)` → `String` | Convert to hex string |
| `hexToTextColor(String)` → `TextColor` | Convert to Adventure TextColor |
| `PRESET_COLORS` | Color palette array for color picker GUI |

### `util/SoundUtil.java`

Configurable sound playback.

| Method | Purpose |
|--------|---------|
| `play(Player, ConfigurationSection, String key)` | Play from config path |
| `play(Player, String soundName)` | Play by name |
| `click(Player)` | `UI_BUTTON_CLICK` |
| `success(Player)` | `ENTITY_PLAYER_LEVELUP` |
| `error(Player)` | `ENTITY_VILLAGER_NO` |
| `notify(Player)` | `ENTITY_EXPERIENCE_ORB_PICKUP` |
| `playGuiSound(Player, ConfigurationSection)` | Play GUI item sound |
| `playForClan(plugin, Clan, configPath)` | Play for all online members |

### `util/ParticleUtil.java` (166 lines)

Particle effects for visual feedback.

| Method | Purpose |
|--------|---------|
| `showChunkBorder(Player, Chunk, Color)` | 4-edge chunk border with dust particles |
| `playerRing(Player, Particle, count)` | Ring of particles around player |
| `levelUpEffect(Player)` | Totem + villager happy particles |
| `missionCompleteEffect(Player)` | Villager happy + firework |
| `warStartEffect(Player)` | Flame + smoke |
| `claimEffect(Player)` | End rod particles |
| `upgradeEffect(Player)` | Enchant + villager happy |
| `memberJoinEffect(Player)` | Hearts + villager happy |
| `bankEffect(Player)` | Composter particles |
| `broadcastEffect(plugin, Clan, ClanEffect)` | Play effect for all online members |
| `broadcastSound(plugin, Clan, Sound, volume, pitch)` | Play sound for all members |

**ClanEffect enum**: `LEVEL_UP`, `WAR_START`, `MISSION_COMPLETE`, `MEMBER_JOIN`, `UPGRADE`

### `util/ConfirmationManager.java`

Dangerous action confirmation system. `requestConfirmation(Player, action, message, onConfirm)` → waits 15s for `/clan confirm`. `confirm(Player)` → executes callback.

### `util/UpdateChecker.java`

Plugin update checker via **GitHub Releases API** or **SpigotMC API**. Semantic version comparison. Notifies admins (`ethernova.clans.admin` permission) on join.

### `util/Metrics.java` / `util/MetricsLite.java`

bStats plugin metrics integration.

---

## SQL Tables Summary

| Table | Used By | Fields |
|-------|---------|--------|
| `clan_skills` | ClanSkillManager | `clan_id`, `skill_id`, `level` |
| `clan_shop` | ClanShopManager | `id`, `clan_id`, `material`, `display_name`, `price`, `stock`, `max_stock`, `added_by` |
| `clan_salaries` | SalaryManager | `clan_id`, `role_name`, `amount` |
| `clan_nations` | NationManager | `id`, `name`, `tag`, `description`, `leader_clan_id`, `created_at` |
| `clan_nation_members` | NationManager | `nation_id`, `clan_id`, `role` |
| `clan_outposts` | OutpostManager | `id`, `clan_id`, `type`, `world`, `x`, `y`, `z`, `level`, `health`, `placed_at`, `last_resource_gen` |
| `clan_blueprints` | BlueprintManager | `blueprint_id`, `clan_id`, `chunk_id`, `level`, `built_at` |
| `clan_season_entries` | SeasonManager | `clan_id`, `clan_name`, `season`, `kills`, `deaths`, `power`, `level`, `members`, `wars_won`, `territories` |
| `clan_season_history` | SeasonManager | Same + `score`, `rank`, `balance` |
| `clan_audit_log` | AuditLogger | `id`, `clan_id`, `player_uuid`, `player_name`, `action`, `details`, `timestamp` |

---

## Configuration Files Reference

### Main Resources (`src/main/resources/`)

| File | Purpose |
|------|---------|
| `config.yml` | Master config (all modules, flags, limits, economy, intervals) |
| `plugin.yml` | Bukkit plugin descriptor |
| `achievements.yml` | Achievement definitions (types, targets, rewards) |
| `blueprints.yml` | Blueprint structure types, levels, costs, materials, effects |
| `levels.yml` | Level definitions (XP thresholds, max members, max claims, max allies) |
| `missions.yml` | Mission definitions (types, targets, rewards) |
| `scheduled-events.yml` | Event definitions (types, durations, cooldowns, multipliers) |
| `messages_es.yml` | Spanish messages |
| `messages_en.yml` | English messages |
| `messages_pt.yml` | Portuguese messages |
| `messages_fr.yml` | French messages |
| `messages_de.yml` | German messages |
| `messages_zh.yml` | Chinese messages |

### GUI Configs (`src/main/resources/guis/`)

34 YAML files defining all GUI layouts:

| File | GUI |
|------|-----|
| `main-menu.yml` | Main clan dashboard |
| `bank.yml` | Bank interface |
| `members.yml` | Member list |
| `territory.yml` | Territory map |
| `wars.yml` | War management |
| `settings.yml` | Clan settings |
| `tops.yml` | Leaderboards |
| `upgrades.yml` | Upgrade shop |
| `progress.yml` | Level progress |
| `diplomacy.yml` | Alliances/rivals |
| `color-picker.yml` | Tag color picker |
| `missions.yml` | Mission board |
| `achievements.yml` | Achievement display |
| `boosts.yml` | Active boosts |
| `permissions.yml` | Role permissions |
| `invitations.yml` | Pending invites |
| `stats.yml` | Clan statistics |
| `warps.yml` | Clan warps |
| `admin-menu.yml` | Admin dashboard |
| `admin-clan-list.yml` | Admin clan browser |
| `admin-clan.yml` | Admin clan editor |
| + 13 more | Additional menus |

Each YAML follows the format:
```yaml
title: "<gradient:#color1:#color2>Title</gradient>"
size: 54  # 9, 18, 27, 36, 45, or 54
background: BLACK_STAINED_GLASS_PANE
animation: true
items:
  item_name:
    slot: 13
    material: DIAMOND
    name: "<gold>Display Name"
    lore:
      - "<gray>Line 1 {placeholder}"
    glow: true
    action: "ACTION_NAME"
    right-click-action: "OTHER_ACTION"
    sound: ENTITY_EXPERIENCE_ORB_PICKUP
    requirements:
      role: OFFICER
      level: 5
```

---

## Architecture Summary

```
┌─────────────────────────────────────────────────────────────────┐
│                    EthernovaClans Plugin                        │
├──────────┬──────────┬──────────┬──────────┬─────────────────────┤
│  GUI     │ Listener │  WebMap  │ Managers │   Hooks / Utils     │
│ Framework│  System  │  Server  │          │                     │
├──────────┼──────────┼──────────┼──────────┼─────────────────────┤
│AbstractGui│PlayerLis│WebMapSvr │AchievMgr │CoreHook (reflection)│
│ConfigGUI │TerritLis│TerrainRnd│MissionMgr│CombatHook (reflect) │
│GUIManager│CombatLis│47 HTTP   │SkillMgr  │VaultHook (direct)   │
│GUIListenr│ChatList  │endpoints │ShopMgr   │DynmapHook (reflect) │
│32 Menus  │DamageLis│          │FlyMgr    │WorldGuardHook       │
│          │OutpostLis│ Frontend │TeleprMgr │PlaceholderHook      │
│          │SkillLis │ Tiles    │SalaryMgr │TabHook              │
│          │FlyListen│ Chat     │ShieldMgr │DecentHoloHook       │
│          │AchievLis│ Auth(IP) │NationMgr │                     │
│          │ChatFmt  │          │OutpostMgr│TextUtil, ItemBuilder │
│          │         │          │BlueprtMgr│TimeUtil, ColorUtil   │
│          │         │          │SeasonMgr │SoundUtil, ParticleU  │
│          │         │          │TaxMgr    │ConfirmationMgr      │
│          │         │          │SpyMgr    │UpdateChecker         │
│          │         │          │NametagMgr│Metrics               │
│          │         │          │HoloMgr   │                     │
│          │         │          │AuditMgr  │                     │
│          │         │          │EventSched│                     │
│          │         │          │UpgradeMgr│                     │
│          │         │          │MessageMgr│                     │
└──────────┴──────────┴──────────┴──────────┴─────────────────────┘
                           │
                    ┌──────┴──────┐
                    │ SQL Storage │
                    │ (SQLite/    │
                    │  MySQL)     │
                    └─────────────┘
```

---

*Generated from source analysis of 153+ Java files and 58 YML resources in the `src/` module.*
