const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 8095;

// ═══════════════════ MOCK DATA ═══════════════════
const clans = [
  { id: 'phoenix', displayName: 'Phoenix Order', tag: 'PHX', color: '#ef4444', 
    members: 12, online: 5, power: 340, maxPower: 500, claims: 48, level: 8, leader: 'DragonFire',
    logoUrl: null, bannerUrl: null, membersData: [
      { uuid: 'a1', name: 'DragonFire', role: 'LEADER', online: true, kills: 156, deaths: 42, power: 45, kd: 3.71 },
      { uuid: 'a2', name: 'FlameShadow', role: 'CO_LEADER', online: true, kills: 98, deaths: 55, power: 38, kd: 1.78 },
      { uuid: 'a3', name: 'EmberWolf', role: 'OFFICER', online: false, kills: 67, deaths: 31, power: 30, kd: 2.16 },
      { uuid: 'a4', name: 'AshStorm', role: 'MEMBER', online: true, kills: 45, deaths: 60, power: 25, kd: 0.75 },
      { uuid: 'a5', name: 'BlazeNinja', role: 'MEMBER', online: true, kills: 33, deaths: 28, power: 22, kd: 1.18 }
    ]},
  { id: 'arctic', displayName: 'Arctic Wolves', tag: 'AWF', color: '#22d3ee',
    members: 9, online: 3, power: 260, maxPower: 400, claims: 35, level: 6, leader: 'FrostByte',
    logoUrl: null, bannerUrl: null, membersData: [
      { uuid: 'b1', name: 'FrostByte', role: 'LEADER', online: true, kills: 120, deaths: 38, power: 42, kd: 3.16 },
      { uuid: 'b2', name: 'IceVenom', role: 'OFFICER', online: true, kills: 89, deaths: 44, power: 35, kd: 2.02 },
      { uuid: 'b3', name: 'SnowCrafter', role: 'MEMBER', online: false, kills: 12, deaths: 8, power: 20, kd: 1.5 }
    ]},
  { id: 'shadow', displayName: 'Shadow Legion', tag: 'SHD', color: '#a855f7',
    members: 15, online: 7, power: 420, maxPower: 600, claims: 62, level: 10, leader: 'VoidWalker',
    logoUrl: null, bannerUrl: null, membersData: [
      { uuid: 'c1', name: 'VoidWalker', role: 'LEADER', online: true, kills: 234, deaths: 56, power: 50, kd: 4.18 },
      { uuid: 'c2', name: 'DarkMage', role: 'CO_LEADER', online: true, kills: 187, deaths: 72, power: 45, kd: 2.60 },
      { uuid: 'c3', name: 'NightBlade', role: 'OFFICER', online: true, kills: 145, deaths: 89, power: 40, kd: 1.63 }
    ]},
  { id: 'emerald', displayName: 'Emerald Guard', tag: 'EMR', color: '#22c55e',
    members: 8, online: 2, power: 180, maxPower: 320, claims: 28, level: 5, leader: 'GreenKnight',
    logoUrl: null, bannerUrl: null, membersData: [
      { uuid: 'd1', name: 'GreenKnight', role: 'LEADER', online: true, kills: 78, deaths: 45, power: 35, kd: 1.73 },
      { uuid: 'd2', name: 'ForestSage', role: 'OFFICER', online: false, kills: 34, deaths: 22, power: 28, kd: 1.55 }
    ]},
  { id: 'inferno', displayName: 'Inferno Reapers', tag: 'INF', color: '#f97316',
    members: 11, online: 4, power: 310, maxPower: 450, claims: 42, level: 7, leader: 'HellStrike',
    logoUrl: null, bannerUrl: null, membersData: [
      { uuid: 'e1', name: 'HellStrike', role: 'LEADER', online: true, kills: 201, deaths: 67, power: 48, kd: 3.0 },
      { uuid: 'e2', name: 'MagmaLord', role: 'CO_LEADER', online: true, kills: 156, deaths: 88, power: 42, kd: 1.77 }
    ]},
  { id: 'celestial', displayName: 'Celestial Dawn', tag: 'CLS', color: '#fbbf24',
    members: 6, online: 2, power: 150, maxPower: 250, claims: 20, level: 4, leader: 'StarWeaver',
    logoUrl: null, bannerUrl: null, membersData: [
      { uuid: 'f1', name: 'StarWeaver', role: 'LEADER', online: true, kills: 56, deaths: 30, power: 30, kd: 1.87 }
    ]}
];

// Generate territory
function genTerritory() {
  const territory = [];
  const bases = { phoenix: [5,5], arctic: [-10,-8], shadow: [12,-6], emerald: [-6,10], inferno: [0,-14], celestial: [14,12] };
  for (const [clanId, [bx, bz]] of Object.entries(bases)) {
    const count = clans.find(c=>c.id===clanId).claims;
    const filled = new Set();
    const queue = [[bx, bz]];
    while (filled.size < count && queue.length) {
      const idx = Math.floor(Math.random() * Math.min(3, queue.length));
      const [x, z] = queue.splice(idx, 1)[0];
      const key = x + ',' + z;
      if (filled.has(key)) continue;
      filled.add(key);
      territory.push({ clanId, x, z });
      const dirs = [[1,0],[-1,0],[0,1],[0,-1]];
      for (const [dx, dz] of dirs) {
        const nk = (x+dx) + ',' + (z+dz);
        if (!filled.has(nk) && Math.random() > 0.3) queue.push([x+dx, z+dz]);
      }
    }
  }
  return territory;
}
const territory = genTerritory();

const wars = [
  { type: 'DOMINATION', attacker: 'Phoenix Order', attackerTag: 'PHX', attackerClanId: 'phoenix', defender: 'Shadow Legion', defenderTag: 'SHD', defenderClanId: 'shadow', attackerKills: 12, defenderKills: 8. },
  { type: 'RAID', attacker: 'Inferno Reapers', attackerTag: 'INF', attackerClanId: 'inferno', defender: 'Arctic Wolves', defenderTag: 'AWF', defenderClanId: 'arctic', attackerKills: 5, defenderKills: 7 }
];

const alliances = [
  { clan1Id: 'phoenix', clan2Id: 'emerald', clan1Name: 'Phoenix Order', clan2Name: 'Emerald Guard' },
  { clan1Id: 'shadow', clan2Id: 'inferno', clan1Name: 'Shadow Legion', clan2Name: 'Inferno Reapers' }
];

const nations = [
  { name: 'Northern Alliance', tag: 'NA', clans: ['phoenix', 'emerald'], color: '#ef4444' },
  { name: 'Dark Pact', tag: 'DP', clans: ['shadow', 'inferno'], color: '#a855f7' }
];

const chatMessages = [
  { name: 'DragonFire', text: 'alguien vio el nuevo territorio de Shadow?', timestamp: Date.now() - 120000, clanColor: '#ef4444' },
  { name: 'VoidWalker', text: 'nos expandimos hacia el este', timestamp: Date.now() - 90000, clanColor: '#a855f7' },
  { name: 'FrostByte', text: 'cuidado con el border PvP', timestamp: Date.now() - 60000, clanColor: '#22d3ee' },
  { name: 'HellStrike', text: 'GG en la guerra, fue intensa', timestamp: Date.now() - 30000, clanColor: '#f97316' },
  { name: 'GreenKnight', text: 'alianza phoenix-emerald sigue fuerte 💪', timestamp: Date.now() - 10000, clanColor: '#22c55e' }
];

const activities = [
  { player: 'VoidWalker', action: 'claimed 3 chunks', icon: '🏴', timestamp: Date.now() - 300000, details: 'Shadow territory expansion' },
  { player: 'DragonFire', action: 'killed NightBlade', icon: '⚔️', timestamp: Date.now() - 600000, details: 'Border skirmish' },
  { player: 'FrostByte', action: 'joined Arctic Wolves', icon: '🐺', timestamp: Date.now() - 1200000, details: 'New member' },
  { player: 'HellStrike', action: 'started a war vs AWF', icon: '🔥', timestamp: Date.now() - 2400000, details: 'RAID war type' },
  { player: 'StarWeaver', action: 'leveled up clan to Lv.4', icon: '⭐', timestamp: Date.now() - 3600000, details: '+10 max power' }
];

const recruitBoard = [
  { name: 'Emerald Guard', tag: 'EMR', color: '#22c55e', level: 5, power: 180, spotsOpen: 4, online: 2, members: 8, maxMembers: 20, claims: 28, leader: 'GreenKnight' },
  { name: 'Celestial Dawn', tag: 'CLS', color: '#fbbf24', level: 4, power: 150, spotsOpen: 6, online: 2, members: 6, maxMembers: 15, claims: 20, leader: 'StarWeaver' }
];

const playerPositions = [
  { uuid: 'a1', name: 'DragonFire', x: 96, y: 74, z: 80, clanId: 'phoenix', clanColor: '#ef4444' },
  { uuid: 'a2', name: 'FlameShadow', x: 112, y: 68, z: 64, clanId: 'phoenix', clanColor: '#ef4444' },
  { uuid: 'b1', name: 'FrostByte', x: -144, y: 72, z: -128, clanId: 'arctic', clanColor: '#22d3ee' },
  { uuid: 'c1', name: 'VoidWalker', x: 208, y: 65, z: -80, clanId: 'shadow', clanColor: '#a855f7' },
  { uuid: 'c2', name: 'DarkMage', x: 192, y: 70, z: -96, clanId: 'shadow', clanColor: '#a855f7' },
  { uuid: 'e1', name: 'HellStrike', x: 16, y: 62, z: -224, clanId: 'inferno', clanColor: '#f97316' }
];

const pvpKills = [
  { killer: 'DragonFire', victim: 'NightBlade', x: 160, z: -32, timestamp: Date.now() - 180000 },
  { killer: 'VoidWalker', victim: 'AshStorm', x: 128, z: 0, timestamp: Date.now() - 360000 },
  { killer: 'HellStrike', victim: 'IceVenom', x: -48, z: -160, timestamp: Date.now() - 900000 },
  { killer: 'FrostByte', victim: 'MagmaLord', x: -80, z: -144, timestamp: Date.now() - 1800000 },
  { killer: 'DarkMage', victim: 'BlazeNinja', x: 176, z: -48, timestamp: Date.now() - 3600000 }
];

const notifications = [
  { type: 'war', title: 'Nueva Guerra!', detail: 'Phoenix Order vs Shadow Legion', timestamp: Date.now() - 5000 },
  { type: 'pvp', title: 'Kill!', detail: 'DragonFire eliminó a NightBlade', timestamp: Date.now() - 3000 },
  { type: 'territory', title: 'Expansión', detail: 'Shadow Legion +3 chunks', timestamp: Date.now() - 1000 }
];

const poiData = [
  { name: 'Base Phoenix', icon: '🏰', x: 80, z: 80, clanId: 'phoenix', creator: 'DragonFire' },
  { name: 'Farm XP', icon: '⚡', x: 96, z: 112, clanId: 'phoenix', creator: 'FlameShadow' },
  { name: 'Fortaleza Shadow', icon: '🏴', x: 192, z: -96, clanId: 'shadow', creator: 'VoidWalker' },
  { name: 'Puerto Ártico', icon: '❄️', x: -160, z: -112, clanId: 'arctic', creator: 'FrostByte' }
];

const achievements = clans.map(c => {
  const badges = [];
  if (wars.some(w => w.attackerClanId === c.id || w.defenderClanId === c.id)) badges.push('warrior');
  if (c.claims >= 40) badges.push('landlord');
  if (c.claims >= 10) badges.push('settler');
  if (c.level >= 7) badges.push('veteran');
  if (c.members >= 10) badges.push('popular');
  if (nations.some(n => n.clans.includes(c.id))) badges.push('diplomat');
  const totalKills = (c.membersData || []).reduce((s, m) => s + m.kills, 0);
  if (totalKills >= 200) badges.push('destroyer');
  if (totalKills >= 50) badges.push('fighter');
  return { clanId: c.id, name: c.displayName, badges };
});

const activityHeatmap = [];
for (let i = 0; i < 200; i++) {
  activityHeatmap.push({ x: Math.floor(Math.random() * 600 - 300), z: Math.floor(Math.random() * 600 - 300) });
}

const territoryGrowth = {};
clans.forEach(c => {
  const data = [];
  const now = Date.now();
  for (let i = 23; i >= 0; i--) {
    data.push([now - i * 3600000, Math.max(2, c.claims - Math.floor(Math.random() * i * 1.5))]);
  }
  territoryGrowth[c.id] = { name: c.displayName, data };
});

// ═══════════════════ NEW FEATURE MOCK DATA ═══════════════════
const galleryData = [
  { id: 'g1', url: '', thumbnail: '', caption: 'Base principal del Phoenix Order', author: 'DragonFire', x: 50, z: 30, timestamp: Date.now() - 86400000, likes: 24 },
  { id: 'g2', url: '', thumbnail: '', caption: 'Batalla épica en la frontera norte', author: 'VoidWalker', x: -100, z: 200, timestamp: Date.now() - 172800000, likes: 42 },
  { id: 'g3', url: '', thumbnail: '', caption: 'Puesta de sol desde la torre', author: 'FrostByte', x: 180, z: -50, timestamp: Date.now() - 259200000, likes: 18 },
  { id: 'g4', url: '', thumbnail: '', caption: 'El nuevo muro defensivo', author: 'EmeraldKing', x: -200, z: 100, timestamp: Date.now() - 345600000, likes: 31 },
  { id: 'g5', url: '', thumbnail: '', caption: 'Nether portal decorado', author: 'NightBlade', x: 0, z: -150, timestamp: Date.now() - 432000000, likes: 15 },
  { id: 'g6', url: '', thumbnail: '', caption: 'Arena PvP de la Shadow Legion', author: 'DarkMage', x: -80, z: -80, timestamp: Date.now() - 518400000, likes: 37 }
];
const blogPosts = [
  { id: 'b1', title: 'La Gran Guerra del Norte', author: 'VoidWalker', clan: 'Shadow Legion', clanColor: '#a855f7', content: 'Hoy comenzamos nuestra campaña para reclamar las tierras del norte. Tres clanes se han aliado contra nosotros, pero no caeremos...', timestamp: Date.now() - 3600000, reactions: { '🔥': 12, '⚔️': 8, '💀': 3 } },
  { id: 'b2', title: 'Guía de Defensa de Base', author: 'DragonFire', clan: 'Phoenix Order', clanColor: '#ef4444', content: 'Después de meses de experiencia, comparto mis mejores técnicas para proteger tu base contra raids enemigos. Lo primero es...', timestamp: Date.now() - 86400000, reactions: { '👍': 24, '🏰': 15 } },
  { id: 'b3', title: 'Ceremonia de Alianza', author: 'FrostByte', clan: 'Arctic Wolves', clanColor: '#22d3ee', content: 'Hoy firmamos una alianza histórica con Celestial Dawn. Juntos seremos imparables en las guerras del oeste...', timestamp: Date.now() - 172800000, reactions: { '🤝': 20, '🌟': 11 } },
  { id: 'b4', title: 'Actualización de la Fortaleza', author: 'EmeraldKing', clan: 'Emerald Guard', clanColor: '#22c55e', content: 'Completamos la expansión del muro exterior. Ahora nuestro territorio está protegido por tres capas de obsidiana...', timestamp: Date.now() - 259200000, reactions: { '🏗️': 8, '💪': 14 } }
];
const tradeListings = [
  { id: 't1', seller: 'DragonFire', clan: 'Phoenix Order', item: 'Diamantes', icon: '💎', quantity: 64, price: '32 esmeraldas', timestamp: Date.now() - 1800000 },
  { id: 't2', seller: 'FrostByte', clan: 'Arctic Wolves', item: 'Netherite Ingot', icon: '🔥', quantity: 4, price: '128 diamantes', timestamp: Date.now() - 3600000 },
  { id: 't3', seller: 'EmeraldKing', clan: 'Emerald Guard', item: 'XP Bottles', icon: '🧪', quantity: 256, price: '16 diamantes', timestamp: Date.now() - 7200000 },
  { id: 't4', seller: 'VoidWalker', clan: 'Shadow Legion', item: 'Wither Skulls', icon: '💀', quantity: 3, price: '96 diamantes', timestamp: Date.now() - 14400000 },
  { id: 't5', seller: 'NightBlade', clan: 'Shadow Legion', item: 'Enchanted Books', icon: '📖', quantity: 8, price: '48 esmeraldas', timestamp: Date.now() - 21600000 },
  { id: 't6', seller: 'SnowCrafter', clan: 'Arctic Wolves', item: 'Tridents', icon: '🔱', quantity: 2, price: '64 diamantes', timestamp: Date.now() - 28800000 }
];
const announcementsData = [
  { id: 'ann1', title: 'Evento de PvP este sábado', message: 'Torneo de clanes con premios. ¡Inscríbanse!', priority: 'high', author: 'Admin', timestamp: Date.now() - 3600000 },
  { id: 'ann2', title: 'Mantenimiento programado', message: 'El servidor estará offline mañana de 3:00 a 5:00 AM', priority: 'medium', author: 'Admin', timestamp: Date.now() - 86400000 },
  { id: 'ann3', title: 'Nuevo bioma desbloqueado', message: 'El End ha sido habilitado. ¡Cuidado con el dragón!', priority: 'low', author: 'Admin', timestamp: Date.now() - 172800000 }
];
const serverPollsData = [
  { id: 'sp1', question: '¿Qué evento quieren para el fin de semana?', options: [
    { label: 'Torneo PvP 1v1', votes: 28 }, { label: 'Raid a la torre del End', votes: 35 },
    { label: 'Construcción colaborativa', votes: 12 }, { label: 'Búsqueda del tesoro', votes: 22 }
  ], total: 97, myVote: null, endTime: Date.now() + 172800000 },
  { id: 'sp2', question: '¿Aumentar límite de miembros por clan?', options: [
    { label: 'Sí, a 20', votes: 45 }, { label: 'Sí, a 25', votes: 18 },
    { label: 'No, mantener en 15', votes: 30 }
  ], total: 93, myVote: 0, endTime: Date.now() + 86400000 }
];
const battleReplays = [
  { id: 'br1', title: 'Phoenix vs Shadow — Batalla del Valle', attacker: 'Phoenix Order', defender: 'Shadow Legion',
    attackerColor: '#ef4444', defenderColor: '#a855f7', winner: 'Shadow Legion', duration: 1200000,
    timestamp: Date.now() - 7200000, kills: 18, events: [
      { time: 0, type: 'start', text: '¡La batalla comienza!' },
      { time: 45000, type: 'kill', text: 'VoidWalker eliminó a AshStorm' },
      { time: 120000, type: 'kill', text: 'DragonFire eliminó a NightBlade' },
      { time: 300000, type: 'capture', text: 'Shadow Legion capturó una torre' },
      { time: 600000, type: 'kill', text: 'DarkMage eliminó a FlameShadow' },
      { time: 900000, type: 'kill', text: 'VoidWalker eliminó a DragonFire' },
      { time: 1200000, type: 'end', text: 'Shadow Legion gana la batalla' }
    ] },
  { id: 'br2', title: 'Arctic Wolves vs Inferno — Asedio Helado', attacker: 'Arctic Wolves', defender: 'Inferno Reapers',
    attackerColor: '#22d3ee', defenderColor: '#f97316', winner: 'Arctic Wolves', duration: 900000,
    timestamp: Date.now() - 86400000, kills: 12, events: [
      { time: 0, type: 'start', text: '¡Comienza el asedio!' },
      { time: 60000, type: 'kill', text: 'FrostByte eliminó a BlazeLord' },
      { time: 180000, type: 'capture', text: 'Arctic Wolves rompió la puerta' },
      { time: 450000, type: 'kill', text: 'IceVenom hizo triple kill' },
      { time: 900000, type: 'end', text: 'Arctic Wolves conquista la base' }
    ] }
];
const mentorsData = [
  { mentorUuid: 'a1', mentorName: 'DragonFire', studentUuid: 'a4', studentName: 'AshStorm', progress: 72, started: Date.now() - 604800000, tasks: 8, completed: 6 },
  { mentorUuid: 'c1', mentorName: 'VoidWalker', studentUuid: 'c3', studentName: 'NightBlade', progress: 45, started: Date.now() - 432000000, tasks: 10, completed: 5 },
  { mentorUuid: 'b1', mentorName: 'FrostByte', studentUuid: 'b3', studentName: 'SnowCrafter', progress: 90, started: Date.now() - 1209600000, tasks: 12, completed: 11 }
];
const hallOfFameData = [
  { category: 'Más Kills', icon: '⚔️', holder: 'VoidWalker', value: '234', clan: 'Shadow Legion' },
  { category: 'Mejor K/D', icon: '🎯', holder: 'VoidWalker', value: '4.18', clan: 'Shadow Legion' },
  { category: 'Más Territorio', icon: '🗺️', holder: 'Shadow Legion', value: '62 chunks', clan: '' },
  { category: 'Clan Más Poderoso', icon: '⚡', holder: 'Shadow Legion', value: '420 poder', clan: '' },
  { category: 'Más Tiempo Online', icon: '⏰', holder: 'DragonFire', value: '342h', clan: 'Phoenix Order' },
  { category: 'Mayor Racha de Kills', icon: '🔥', holder: 'DarkMage', value: '12 seguidas', clan: 'Shadow Legion' },
  { category: 'Mejor Constructor', icon: '🏗️', holder: 'SnowCrafter', value: '89 builds', clan: 'Arctic Wolves' },
  { category: 'Más Alianzas', icon: '🤝', holder: 'FrostByte', value: '5 tratados', clan: 'Arctic Wolves' }
];
const voiceRoomsMock = [
  { id: 'vr1', name: 'General', maxUsers: 20, users: [
    { uuid: 'a1', name: 'DragonFire', speaking: true },
    { uuid: 'c1', name: 'VoidWalker', speaking: false },
    { uuid: 'b1', name: 'FrostByte', speaking: false }
  ]},
  { id: 'vr2', name: 'Estrategia - Phoenix', maxUsers: 10, users: [
    { uuid: 'a2', name: 'FlameShadow', speaking: true },
    { uuid: 'a5', name: 'BlazeNinja', speaking: false }
  ]},
  { id: 'vr3', name: 'AFK Chill', maxUsers: 10, users: [] }
];
const reputationData = {};
clans.forEach(c => (c.membersData || []).forEach(m => {
  reputationData[m.uuid] = {
    score: Math.floor(Math.random() * 200 - 30),
    helpful: Math.floor(Math.random() * 50),
    toxic: Math.floor(Math.random() * 10),
    badges: ['warrior', 'builder', 'diplomat', 'trader', 'veteran'].filter(() => Math.random() > 0.5)
  };
}));
const resourceHeatmapMock = [];
for (let i = 0; i < 60; i++) {
  resourceHeatmapMock.push({
    x: Math.floor(Math.random() * 500 - 250),
    z: Math.floor(Math.random() * 500 - 250),
    type: ['diamond', 'netherite', 'spawner', 'emerald'][Math.floor(Math.random() * 4)],
    density: Math.random()
  });
}
const structuresMock = [
  { x: 50, z: 30, type: 'castle', icon: '🏰', name: 'Ciudadela Fénix', clan: 'Phoenix Order' },
  { x: -100, z: 200, type: 'tower', icon: '🗼', name: 'Torre Sombría', clan: 'Shadow Legion' },
  { x: 180, z: -50, type: 'wall', icon: '🧱', name: 'Muralla de Hielo', clan: 'Arctic Wolves' },
  { x: -200, z: 100, type: 'farm', icon: '🌾', name: 'Granja Esmeralda', clan: 'Emerald Guard' },
  { x: 0, z: 0, type: 'arena', icon: '⚔️', name: 'Arena Central', clan: 'Neutral' },
  { x: 120, z: 120, type: 'portal', icon: '🌀', name: 'Portal del Nether', clan: 'Inferno Reapers' },
  { x: -150, z: -150, type: 'temple', icon: '⛪', name: 'Templo Celestial', clan: 'Celestial Dawn' }
];
const biomesMock = [
  { id: 'plains', name: 'Llanuras', color: '#7cfc00' },
  { id: 'forest', name: 'Bosque', color: '#228b22' },
  { id: 'desert', name: 'Desierto', color: '#edc9af' },
  { id: 'taiga', name: 'Taiga', color: '#4a7a5a' },
  { id: 'ocean', name: 'Océano', color: '#1e90ff' },
  { id: 'mountains', name: 'Montañas', color: '#808080' },
  { id: 'swamp', name: 'Pantano', color: '#5c7a3a' },
  { id: 'nether', name: 'Nether Wastes', color: '#a02020' }
];

let leaderboard = [];
clans.forEach(c => (c.membersData || []).forEach(m => leaderboard.push(m)));
leaderboard.sort((a, b) => b.kills - a.kills);

const rankings = clans.map((c, i) => ({ ...c, name: c.displayName, rank: i + 1 })).sort((a, b) => b.power - a.power).map((c, i) => ({ ...c, rank: i + 1 }));

const worldInfo = { time: 6000, weather: 'CLEAR', isDay: true };

const terrSnapshots = [];
for (let i = 0; i < 48; i++) {
  terrSnapshots.push({ timestamp: Date.now() - (47 - i) * 1800000, claims: territory.slice(0, Math.max(10, territory.length - (47 - i) * 2)) });
}

const fogData = { fogEnabled: true, chunks: territory.filter(() => Math.random() > 0.3).map(t => t.x + ',' + t.z) };

const me = { identified: true, uuid: 'a1', name: 'DragonFire', clanId: 'phoenix', role: 'LEADER', isOp: true };

const powerHistory = {};
clans.forEach(c => {
  const labels = [], data = [];
  for (let i = 23; i >= 0; i--) {
    const d = new Date(Date.now() - i * 3600000);
    labels.push(d.getHours() + ':00');
    data.push(Math.max(50, c.power - Math.floor(Math.random() * i * 8)));
  }
  powerHistory[c.id] = { name: c.displayName, color: c.color, labels, data };
});

// Tile generation - generate procedural terrain tiles
function generateTile(rx, rz) {
  // We'll generate a simple colored terrain tile
  // Create a minimal BMP-like structure or return a basic PNG
  // For simplicity, use an in-memory canvas via pure math to create noise
  const size = 512;
  const pixels = Buffer.alloc(size * size * 4);
  
  for (let z = 0; z < size; z++) {
    for (let x = 0; x < size; x++) {
      const worldX = rx * 512 + x;
      const worldZ = rz * 512 + z;
      
      // Simple procedural noise
      const n1 = Math.sin(worldX * 0.02) * Math.cos(worldZ * 0.02);
      const n2 = Math.sin(worldX * 0.05 + 1.3) * Math.cos(worldZ * 0.03 + 0.7);
      const n3 = Math.sin(worldX * 0.01) * Math.sin(worldZ * 0.01);
      const height = (n1 + n2 * 0.5 + n3 * 2) / 3.5;
      
      let r, g, b;
      if (height < -0.3) {
        // Deep water
        r = 20; g = 40 + Math.floor(height * 20); b = 120 + Math.floor(Math.abs(height) * 40);
      } else if (height < -0.1) {
        // Shallow water
        r = 30; g = 70; b = 140;
      } else if (height < 0.0) {
        // Sand/beach
        r = 180 + Math.floor(Math.random() * 10); g = 160 + Math.floor(Math.random() * 10); b = 100;
      } else if (height < 0.4) {
        // Grass with variation
        const shade = Math.floor(height * 80);
        r = 40 + shade; g = 90 + Math.floor(height * 60) + Math.floor(Math.random() * 8); b = 30 + shade / 2;
      } else if (height < 0.65) {
        // Forest / dark grass
        r = 25 + Math.floor(Math.random() * 10); g = 60 + Math.floor(Math.random() * 15); b = 20;
      } else {
        // Mountain/stone
        const shade = Math.floor(height * 60);
        r = 90 + shade; g = 85 + shade; b = 80 + shade;
      }
      
      const idx = (z * size + x) * 4;
      pixels[idx] = Math.max(0, Math.min(255, r));
      pixels[idx + 1] = Math.max(0, Math.min(255, g));
      pixels[idx + 2] = Math.max(0, Math.min(255, b));
      pixels[idx + 3] = 255;
    }
  }
  
  // Create a minimal PNG
  return createPNG(size, size, pixels);
}

// Minimal PNG encoder
function createPNG(width, height, pixels) {
  const crc32Table = new Int32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let j = 0; j < 8; j++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    crc32Table[i] = c;
  }
  function crc32(buf, start, end) {
    let c = 0xFFFFFFFF;
    for (let i = start; i < end; i++) c = crc32Table[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
    return (c ^ 0xFFFFFFFF) >>> 0;
  }
  
  // We'll create a simpler approach: raw uncompressed IDAT via zlib stored blocks
  const rawSize = (width * 3 + 1) * height; // filter byte + RGB per row
  const rawData = Buffer.alloc(rawSize);
  let pos = 0;
  for (let y = 0; y < height; y++) {
    rawData[pos++] = 0; // filter: none
    for (let x = 0; x < width; x++) {
      const idx = (y * width + x) * 4;
      rawData[pos++] = pixels[idx];
      rawData[pos++] = pixels[idx + 1];
      rawData[pos++] = pixels[idx + 2];
    }
  }
  
  // Use zlib deflate
  const zlib = require('zlib');
  const compressed = zlib.deflateSync(rawData, { level: 1 });
  
  // Build PNG
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  
  function makeChunk(type, data) {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length, 0);
    const typeB = Buffer.from(type, 'ascii');
    const combined = Buffer.concat([typeB, data]);
    const crcVal = crc32(combined, 0, combined.length);
    const crcB = Buffer.alloc(4);
    crcB.writeUInt32BE(crcVal, 0);
    return Buffer.concat([len, combined, crcB]);
  }
  
  // IHDR
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 2; // color type: RGB
  ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  
  const ihdrChunk = makeChunk('IHDR', ihdr);
  const idatChunk = makeChunk('IDAT', compressed);
  const iendChunk = makeChunk('IEND', Buffer.alloc(0));
  
  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

// Cache tiles
const tileCache = {};

// ═══════════════════ ROUTES ═══════════════════
function handleRequest(req, res) {
  const url = new URL(req.url, 'http://localhost');
  const pathname = url.pathname;
  
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  
  if (req.method === 'OPTIONS') { res.writeHead(200); res.end(); return; }
  
  // Static files
  if (pathname === '/' || pathname === '/index.html') {
    const htmlPath = path.join(__dirname, 'src', 'main', 'resources', 'webmap', 'index.html');
    const html = fs.readFileSync(htmlPath, 'utf8');
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(html);
    return;
  }
  
  // API routes
  const json = (data) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(data)); };
  
  if (pathname === '/api/clans') return json(clans);
  if (pathname === '/api/territory') return json(territory);
  if (pathname === '/api/wars') return json(wars);
  if (pathname === '/api/rankings') return json(rankings);
  if (pathname === '/api/nations') return json(nations);
  if (pathname === '/api/alliances') return json(alliances);
  if (pathname === '/api/stats') return json({ clans: clans.length, claims: territory.length, wars: wars.length, online: playerPositions.length });
  if (pathname === '/api/config') return json({ title: 'Mi Servidor MC', subtitle: 'Mapa del Mundo', icon: '\u2694' });
  if (pathname === '/api/me') return json(me);
  if (pathname === '/api/leaderboard') return json(leaderboard);
  if (pathname === '/api/activity') return json(activities);
  if (pathname === '/api/chat') {
    if (req.method === 'POST') {
      let body = '';
      req.on('data', c => body += c);
      req.on('end', () => {
        try {
          const msg = JSON.parse(body);
          chatMessages.push({ name: me.name, text: msg.message, timestamp: Date.now(), clanColor: '#ef4444' });
          if (chatMessages.length > 50) chatMessages.shift();
        } catch(e) {}
        json({ success: true });
      });
      return;
    }
    return json(chatMessages);
  }
  if (pathname === '/api/recruitment') return json(recruitBoard);
  if (pathname === '/api/players/positions') return json(playerPositions);
  if (pathname === '/api/pvp-heatmap') return json(pvpKills);
  if (pathname === '/api/world-info') return json(worldInfo);
  if (pathname === '/api/fog') return json(fogData);
  if (pathname === '/api/power-history') return json(powerHistory);
  if (pathname === '/api/territory-snapshots') return json(terrSnapshots);
  if (pathname === '/api/notifications') {
    const since = parseInt(url.searchParams.get('since') || '0');
    return json(notifications.filter(n => n.timestamp > since));
  }
  if (pathname === '/api/poi') return json(poiData);
  if (pathname === '/api/claim-planner') return json([]);
  if (pathname === '/api/war-timeline') return json({ wars, kills: pvpKills });
  if (pathname === '/api/achievements') return json(achievements);
  if (pathname === '/api/activity-heatmap') return json(activityHeatmap);
  if (pathname === '/api/territory-growth') return json(territoryGrowth);
  if (pathname === '/api/player-compare') {
    const a = url.searchParams.get('a'), b = url.searchParams.get('b');
    const pa = leaderboard.find(p => p.uuid === a), pb = leaderboard.find(p => p.uuid === b);
    if (pa && pb) return json({ players: [
      { ...pa, clan: clans.find(c => c.membersData?.some(m => m.uuid === a))?.displayName || '' },
      { ...pb, clan: clans.find(c => c.membersData?.some(m => m.uuid === b))?.displayName || '' }
    ]});
    return json({ players: [] });
  }
  if (pathname === '/api/clan-theme') return json({});
  if (pathname === '/api/clan-votes') return json([
    { id: 'v1', question: '¿Atacar Shadow Legion?', options: [
      { label: 'Sí, guerra total', count: 5 },
      { label: 'No, mantener la paz', count: 3 },
      { label: 'Solo si tenemos aliados', count: 4 }
    ], total: 12, myVote: 0, expires: Date.now() + 86400000 },
    { id: 'v2', question: '¿Nuevo nombre para la base?', options: [
      { label: 'Fortaleza del Fénix', count: 8 },
      { label: 'Nido de Dragones', count: 6 },
      { label: 'Torre Escarlata', count: 2 }
    ], total: 16, myVote: null, expires: Date.now() + 43200000 }
  ]);
  if (pathname === '/api/diplomacy') return json([
    { type: 'alliance', fromName: 'Phoenix Order', toName: 'Celestial Dawn', message: 'Unámonos contra la oscuridad', status: 'pending', timestamp: Date.now() - 7200000 },
    { type: 'trade', fromName: 'Arctic Wolves', toName: 'Emerald Guard', message: 'Intercambio de recursos fronterizos', status: 'accepted', timestamp: Date.now() - 14400000 },
    { type: 'peace', fromName: 'Inferno Reapers', toName: 'Arctic Wolves', message: 'Alto al fuego temporal', status: 'pending', timestamp: Date.now() - 3600000 }
  ]);
  if (pathname === '/api/discord-widget') {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end('<html><body style="background:#0c0c14;color:#e8e8f0;font-family:Inter">Discord Widget</body></html>');
    return;
  }
  if (pathname === '/api/server-stats') return json({ tps: 19.8, tps5: 19.6, tps15: 19.4, memoryUsed: 2048, memoryMax: 4096, uptimeMs: 345600000, onlinePlayers: 6, maxPlayers: 50, version: '1.21.4' });
  
  // ═══════ NEW FEATURE ENDPOINTS ═══════
  if (pathname === '/api/gallery') return json(galleryData);
  if (pathname === '/api/blog') return json(blogPosts);
  if (pathname === '/api/trading') {
    if (req.method === 'POST') {
      let body = '';
      req.on('data', c => body += c);
      req.on('end', () => { try { tradeListings.unshift({ id: 't' + Date.now(), ...JSON.parse(body), seller: me.name, timestamp: Date.now() }); } catch(e) {} json({ success: true }); });
      return;
    }
    return json(tradeListings);
  }
  if (pathname === '/api/announcements') return json(announcementsData);
  if (pathname === '/api/server-polls') {
    if (req.method === 'POST') {
      let body = '';
      req.on('data', c => body += c);
      req.on('end', () => {
        try {
          const { pollId, option } = JSON.parse(body);
          const poll = serverPollsData.find(p => p.id === pollId);
          if (poll && poll.options[option]) { poll.options[option].votes++; poll.total++; poll.myVote = option; }
        } catch(e) {}
        json({ success: true });
      });
      return;
    }
    return json(serverPollsData);
  }
  if (pathname === '/api/battle-replays') return json(battleReplays);
  if (pathname === '/api/mentors') return json(mentorsData);
  if (pathname === '/api/hall-of-fame') return json(hallOfFameData);
  if (pathname === '/api/voice-rooms') return json(voiceRoomsMock);
  if (pathname === '/api/reputation') return json(reputationData);
  if (pathname === '/api/resource-heatmap') return json(resourceHeatmapMock);
  if (pathname === '/api/structures') return json(structuresMock);
  if (pathname === '/api/biomes') return json(biomesMock);
  
  // Tiles
  if (pathname === '/api/tiles/list') {
    const tiles = [];
    for (let rx = -2; rx <= 2; rx++) {
      for (let rz = -2; rz <= 2; rz++) {
        tiles.push(rx + ',' + rz);
      }
    }
    return json(tiles);
  }
  
  const tileMatch = pathname.match(/^\/api\/tiles\/world\/(-?\d+)\/(-?\d+)\.png$/);
  if (tileMatch) {
    const rx = parseInt(tileMatch[1]), rz = parseInt(tileMatch[2]);
    const key = rx + ',' + rz;
    if (!tileCache[key]) {
      tileCache[key] = generateTile(rx, rz);
    }
    res.writeHead(200, { 'Content-Type': 'image/png', 'Cache-Control': 'max-age=3600' });
    res.end(tileCache[key]);
    return;
  }
  
  // Clan member data
  // Support both /api/clan/{id}/members AND /api/clan/members?id={id}
  const clanMatch = pathname.match(/^\/api\/clan\/(.+)\/members$/);
  if (clanMatch) {
    const clan = clans.find(c => c.id === clanMatch[1]);
    return json(clan?.membersData || []);
  }
  if (pathname === '/api/clan/members') {
    const clanId = url.searchParams.get('id');
    const clan = clans.find(c => c.id === clanId);
    return json(clan?.membersData || []);
  }
  
  // Fallback
  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'Not found: ' + pathname }));
}

const server = http.createServer(handleRequest);
server.listen(PORT, () => {
  console.log('');
  console.log('  ╔══════════════════════════════════════════╗');
  console.log('  ║   EthernovaClans WebMap Preview Server   ║');
  console.log('  ╠══════════════════════════════════════════╣');
  console.log('  ║                                          ║');
  console.log('  ║   URL: http://localhost:' + PORT + '            ║');
  console.log('  ║                                          ║');
  console.log('  ║   6 clans · ' + territory.length + ' claims · 2 wars       ║');
  console.log('  ║   6 players online · Procedural terrain  ║');
  console.log('  ║   All 49 API endpoints with mock data    ║');
  console.log('  ║                                          ║');
  console.log('  ╚══════════════════════════════════════════╝');
  console.log('');
});
