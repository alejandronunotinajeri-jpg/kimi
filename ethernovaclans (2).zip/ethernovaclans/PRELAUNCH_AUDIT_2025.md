# EthernovaClans — Pre-Production Audit Report

**Date:** 2025-01-28  
**Auditor:** Automated Deep Code Review  
**Scope:** Full source tree under `src/main/java/com/ethernova/clans/` (~60+ Java files)  
**Platform:** Paper 1.21.4 / Java 21  
**Build Status:** ✅ `mvn clean package -DskipTests` passes (exit 0)

---

## Executive Summary

The codebase is well-structured with proper concurrency primitives (ConcurrentHashMap, volatile, ReentrantLock, synchronized ClanBank, atomic ClanBankManager.compute()). Prepared statements are used throughout StorageManager (no SQL injection). The bidirectional bank sync via `registerBankSync()` in `ClanManager.registerClan()` is correctly wired for all clans.

**0 CRITICAL** · **1 HIGH** · **5 MEDIUM** · **8 LOW** issues found.

No issues are outright crash-inducing or data-destroying. The HIGH issue is an input-sanitization gap in the spy system. The MEDIUM issues affect correctness under specific conditions. All are fixable without architectural changes.

---

## HIGH Severity

### H-1 · MiniMessage Tag Injection in SpyManager Chat Forwarding

| Field | Value |
|-------|-------|
| **File** | `src/main/java/com/ethernova/clans/spy/SpyManager.java` |
| **Lines** | 81, 151 |
| **Category** | Input Sanitization / Exploit Vector |

**Description:**  
`forwardToSpies()` and `forwardToInfiltrators()` insert raw player chat text directly into `MiniMessage.deserialize()` strings:

```java
// Line 81 — forwardToSpies:
var formatted = MINI.deserialize(
    "<dark_gray>[SPY] ... " + senderName + ": <white>" + message + "</white></dark_gray>");

// Line 151 — forwardToInfiltrators:
var formatted = MINI.deserialize(
    "... " + senderName + ": <italic><gray>" + message + "</gray></italic>");
```

`MiniMessage.miniMessage()` parses **all** tags by default, including `<click:run_command:...>` and `<hover:show_text:...>`. A player in a clan could send:

```
<click:run_command:/clan disband confirm>Free rewards! Click here!</click>
```

Any infiltrator or social spy viewing the message would see a clickable component that, when clicked, executes `/clan disband confirm` **as the viewing player**. Since infiltration is available to regular players (not just admins), this is exploitable.

**Fix:**  
Escape the `message` parameter before inserting it into MiniMessage format strings:

```java
// Option A: Escape MiniMessage tags
String safe = net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
    .escapeTags(message);

// Option B: Use Component.text() for the message part
Component msg = Component.text(message);
Component formatted = MINI.deserialize("... prefix ...").append(msg);
```

---

## MEDIUM Severity

### M-1 · `unclaimRandom()` Is Not Actually Random

| Field | Value |
|-------|-------|
| **File** | `src/main/java/com/ethernova/clans/territory/TerritoryManager.java` |
| **Lines** | 88–100 |
| **Category** | Logic Error |

**Description:**  
When a clan can't pay territory tax, `ClanBankManager.applyTerritoryTax()` calls `unclaimRandom(clanId, N)`. The implementation uses:

```java
var toRemove = claims.entrySet().stream()
    .filter(e -> e.getValue().equals(clanId))
    .limit(count)  // ← takes first N in iteration order
    .map(Map.Entry::getKey)
    .toList();
```

`ConcurrentHashMap` iteration order is deterministic within a JVM session (governed by internal hash buckets). This means the same chunks are always removed first — potentially including the clan's headquarters or strategically important chunks. The method name implies randomness that isn't delivered.

**Fix:**

```java
public void unclaimRandom(String clanId, int count) {
    List<String> candidates = claims.entrySet().stream()
        .filter(e -> e.getValue().equals(clanId))
        .map(Map.Entry::getKey)
        .collect(Collectors.toCollection(ArrayList::new));
    Collections.shuffle(candidates);
    List<String> toRemove = candidates.subList(0, Math.min(count, candidates.size()));
    for (String chunkId : toRemove) {
        claims.remove(chunkId);
    }
    if (!toRemove.isEmpty()) {
        claimCountCache.merge(clanId, -toRemove.size(), Integer::sum);
    }
}
```

---

### M-2 · AchievementManager Mission Completion Counter Resets on Server Restart

| Field | Value |
|-------|-------|
| **File** | `src/main/java/com/ethernova/clans/achievement/AchievementManager.java` |
| **Lines** | 38, 162 |
| **Category** | Data Loss / State Management |

**Description:**  
The `missionCompletions` counter is stored in a plain in-memory `ConcurrentHashMap<String, Integer>`:

```java
private final Map<String, Integer> missionCompletions = new ConcurrentHashMap<>();
```

This counter is incremented by `trackMissionCompletion()` and read by `getCurrentValue()` for `MISSIONS`-type achievements. On server restart, all counts reset to 0. Clans that were close to unlocking a mission-count achievement (e.g., "Complete 50 missions") lose all progress.

The same issue affects `upgradePurchases` (line 41).

**Fix:**  
Either:
- Persist these counters to the database alongside unlocked achievements, or
- Compute them at startup by counting completed mission records and total upgrade levels from the clan data.

---

### M-3 · SalaryManager TOCTOU Race Between Balance Check and Individual Withdrawals

| Field | Value |
|-------|-------|
| **File** | `src/main/java/com/ethernova/clans/salary/SalaryManager.java` |
| **Lines** | 107–128 |
| **Category** | Race Condition |

**Description:**  
`payClanSalaries()` first checks if the bank can cover all salaries:

```java
if (clan.getBank().getBalance() < totalCost) { /* insufficient funds */ return; }
```

Then it iterates members and calls `clan.getBank().withdraw(salary, null)` individually. Between the pre-check and the individual withdrawals, the balance can change from:
- Territory tax deduction (`ClanBankManager.applyTerritoryTax()`)
- Player deposits or other salary cycles
- Mission/achievement reward deposits

While individual withdrawals are safe (ClanBank.withdraw is synchronized, uses `Math.min(amount, balance)`), the last members in the iteration will silently receive $0 salary because the pre-check passed but the balance was drained by intermediate operations.

**Fix:**  
Remove the totalCost pre-check and handle per-member failures gracefully:

```java
// Instead of pre-checking, attempt each withdrawal and notify on failure
double withdrawn = clan.getBank().withdraw(salary, null);
if (withdrawn < salary) {
    // Notify member they received partial/no salary
    ...
}
```

Or perform all withdrawals atomically inside a single synchronized block on ClanBank.

---

### M-4 · UpgradeManager Redundant `setBalance()` Can Create Stale-Write Race

| Field | Value |
|-------|-------|
| **File** | `src/main/java/com/ethernova/clans/upgrade/UpgradeManager.java` |
| **Lines** | 89–92 |
| **Category** | Race Condition |

**Description:**

```java
double withdrawn = clan.getBank().withdraw(cost, null);
if (withdrawn >= cost) {
    // Sync with ClanBankManager to keep both systems in sync
    plugin.getBankManager().setBalance(clan.getId(), clan.getBank().getBalance());
    clan.setUpgradeLevel(name, level + 1);
    return true;
}
```

The `withdraw()` call already fires `notifyBalanceChange()` inside ClanBank (synchronized), which updates `ClanBankManager.balances` via the registered `BalanceChangeListener`. The subsequent `plugin.getBankManager().setBalance(...)` is redundant and reads `clan.getBank().getBalance()` OUTSIDE the ClanBank's synchronized block.

Between `withdraw()` completing and `getBalance()` being called, another thread (e.g., auto-save timer, tax cycle) could modify the balance. The `setBalance()` would then write a stale value to ClanBankManager, overwriting the newer balance.

The same pattern appears in `MissionManager.completeMission()` (line ~176) and `AchievementManager.grantReward()` (line ~183).

**Fix:**  
Remove the redundant `setBalance()` calls. The `BalanceChangeListener` wired via `registerBankSync()` already handles this:

```java
double withdrawn = clan.getBank().withdraw(cost, null);
if (withdrawn >= cost) {
    // Balance sync already handled by BalanceChangeListener
    clan.setUpgradeLevel(name, level + 1);
    return true;
}
```

Apply the same fix in `MissionManager.completeMission()` and `AchievementManager.grantReward()`.

---

### M-5 · SpyManager Intel Report `atWar` Check Is Wrong

| Field | Value |
|-------|-------|
| **File** | `src/main/java/com/ethernova/clans/spy/SpyManager.java` |
| **Line** | ~200 (inside `generateIntelReport`) |
| **Category** | Logic Error |

**Description:**

```java
boolean atWar = plugin.getWarManager().getActiveWarCount() > 0; // simplified
```

This checks if **any** war exists on the server — not whether the **target** clan is at war. The variable `atWar` is computed but (while currently unused in the output), the incorrect check indicates a logic error. If it's added to the report display later, it will always show `true` when any clan on the server is at war.

**Fix:**

```java
boolean atWar = plugin.getWarManager().isAtWar(targetClan);
```

---

## LOW Severity

### L-1 · ClanShopManager.buyItem() Synchronizes on Entire Manager

| Field | Value |
|-------|-------|
| **File** | `src/main/java/com/ethernova/clans/shop/ClanShopManager.java` |
| **Line** | 95 |
| **Category** | Performance |

**Description:**  
`buyItem()` is `public synchronized boolean buyItem(...)` — locking on the singleton ClanShopManager. All purchases across all clans serialize against each other. On a busy server with many concurrent shop interactions, this is a bottleneck.

Additionally, `addItem()`, `removeItem()`, and `restockItem()` are NOT synchronized and mutate the same `ArrayList` values — although in practice all are called from the main thread via commands.

**Fix:**  
Synchronize per-clan (e.g., synchronize on the per-clan list object) instead of the global manager.

---

### L-2 · WebMapServer HttpServer ExecutorService Not Explicitly Shut Down

| Field | Value |
|-------|-------|
| **File** | `src/main/java/com/ethernova/clans/webmap/WebMapServer.java` |
| **Lines** | 300, 435 |
| **Category** | Resource Leak |

**Description:**  
`start()` creates `Executors.newFixedThreadPool(4)` and passes it to the HttpServer. In `stop()`, only `server.stop(0)` is called. The JDK does not guarantee the executor service is shut down when HttpServer stops. The 4 threads may linger.

**Fix:**

```java
private java.util.concurrent.ExecutorService httpExecutor;

// In start():
httpExecutor = Executors.newFixedThreadPool(4);
server.setExecutor(httpExecutor);

// In stop():
server.stop(0);
if (httpExecutor != null) httpExecutor.shutdownNow();
```

---

### L-3 · PowerManager removePlayer Memory Leak Prevention Is Weak

| Field | Value |
|-------|-------|
| **File** | `src/main/java/com/ethernova/clans/power/PowerManager.java` |
| **Category** | Memory Leak |

**Description:**  
`removePlayer()` only evicts entries from the player power map if the map exceeds 10,000 entries AND the player is not in a clan. Below 10,000 players, the map grows without bound across player joins over weeks/months. For long-running servers, this wastes memory for players who joined once and never returned.

**Fix:**  
Always evict offline players who are not in any clan, regardless of map size. Or implement a TTL-based eviction using a scheduled task.

---

### L-4 · WebMapServer JSON Builder Missing Full Control Character Escaping

| Field | Value |
|-------|-------|
| **File** | `src/main/java/com/ethernova/clans/webmap/WebMapServer.java` |
| **Category** | Data Integrity |

**Description:**  
`escapeJson()` handles `\`, `"`, `<`, `>`, `&`, `\n`, `\r`, `\t` but does not escape other ASCII control chars (U+0000–U+001F). If clan names or descriptions contain stray control characters (from DB migration, corrupted data, or copy-paste), the JSON output will be malformed, breaking the web map frontend parser.

**Fix:**  
Add a catch-all for remaining control characters:

```java
for (int i = 0; i < s.length(); i++) {
    char c = s.charAt(i);
    if (c < 0x20 && c != '\n' && c != '\r' && c != '\t') {
        sb.append(String.format("\\u%04x", (int) c));
    }
}
```

---

### L-5 · ClanAdminCommand `setlevel` Accepts Negative XP

| Field | Value |
|-------|-------|
| **File** | `src/main/java/com/ethernova/clans/command/ClanAdminCommand.java` |
| **Line** | 153 |
| **Category** | Input Validation |

**Description:**

```java
long xp = Long.parseLong(args[2]);
plugin.getLevelManager().loadXP(clan.getId(), xp);
```

No validation that `xp >= 0`. Negative XP could produce undefined behavior in the leveling math (negative levels, integer underflow in XP-to-level calculations).

**Fix:**

```java
long xp = Long.parseLong(args[2]);
if (xp < 0) { plugin.getMessageManager().sendMessage(sender, "error.invalid-number"); return true; }
```

---

### L-6 · War Tie Penalty Scales with Clan Size (Potentially Unfair)

| Field | Value |
|-------|-------|
| **File** | `src/main/java/com/ethernova/clans/war/WarManager.java` |
| **Category** | Game Balance / Logic |

**Description:**  
When a war ends in a tie, each member of **both** clans receives the full `tiePenalty` power loss. A 20-member clan loses 20× the penalty of a 1-member clan. This creates a disproportionate disadvantage for large clans in ties.

If intentional, this should be documented in config comments. If not:

**Fix:**  
Divide the penalty:

```java
int adjustedPenalty = tiePenalty / Math.max(1, clan.getMembers().size());
for (ClanMember m : clan.getMembers()) {
    plugin.getPowerManager().removePower(m.getUuid(), adjustedPenalty);
}
```

---

### L-7 · WebMapServer `/api/me` IP-Based Auth Leaks Data on Shared Networks

| Field | Value |
|-------|-------|
| **File** | `src/main/java/com/ethernova/clans/webmap/WebMapServer.java` |
| **Lines** | 841–885 |
| **Category** | Information Disclosure |

**Description:**  
The `/api/me` endpoint falls back to IP-based player identification:

```java
PlayerSnapshot snap = resolvePlayer(exchange); // session → IP fallback
```

On shared networks (NAT, university, internet cafes), multiple users share the same public IP. A non-player accessing the web map from the same network as a player would see that player's data (UUID, clan, `isOp` status, power, kills/deaths).

The `isOp` field is particularly sensitive — leaking OP status to external web visitors is an information disclosure.

**Fix:**  
- Remove `isOp` from the public `/api/me` response (only include it for authenticated sessions).
- Add a config option to disable IP-based identification entirely.
- When `trust-proxy: true`, validate the `X-Forwarded-For` header against a whitelist of trusted proxy IPs to prevent header spoofing.

---

### L-8 · `SeasonManager.currentSeason` Is Not Volatile

| Field | Value |
|-------|-------|
| **File** | `src/main/java/com/ethernova/clans/season/SeasonManager.java` |
| **Line** | 30 |
| **Category** | Thread Safety |

**Description:**

```java
private int currentSeason;
private long seasonStartTime;
```

These fields are read by the WebMapServer (HTTP thread pool) via `getCurrentSeason()` and `getTimeRemainingMs()`, and written by the main-thread timer task in `endSeason()`. Without `volatile`, HTTP threads may see stale values due to CPU caching.

**Fix:**

```java
private volatile int currentSeason;
private volatile long seasonStartTime;
```

---

## Items Verified as NOT Issues

| Concern | Verdict |
|---------|---------|
| SQL Injection in StorageManager | ✅ All queries use PreparedStatement |
| ClanBank ↔ ClanBankManager desync | ✅ `registerBankSync()` correctly wired in `ClanManager.registerClan()` for all clans |
| `ClanAdminCommand setbank` negative values | ✅ `ClanBankManager.setBalance()` clamps to `Math.max(0, amount)` |
| `onDisable` saves after scheduler cancelled | ✅ Sync saves used throughout; missions saved before `cancelTasks()` |
| NationManager.saveAll() async in onDisable | ✅ `saveSync()` is used in the onDisable loop, not `saveAll()` |
| ClanBank.withdraw going negative | ✅ Uses `Math.min(amount, balance)` inside synchronized block |
| SchemaManager migration idempotency | ✅ Catches "already exists"/"duplicate column" errors gracefully |
| Clan object access from async auto-save | ✅ Fields use volatile/ConcurrentHashMap; standard eventual-consistency pattern |
| WebMap XSS via JSON | ✅ `escapeJson()` escapes `<`, `>`, `&` preventing HTML injection in JSON context |
| WebMap auth brute force | ✅ Rate limiter (5 attempts/5 minutes per IP) + PBKDF2 (65,536 iterations) |
| WebMap path traversal | ✅ Custom HTML path is hardcoded to `webmap/index.html`, not user-controlled |

---

## Summary Action Plan

| Priority | Count | Effort | Pre-Launch? |
|----------|-------|--------|-------------|
| HIGH     | 1     | ~15 min| **Yes — must fix** |
| MEDIUM   | 5     | ~1 hour| Recommended |
| LOW      | 8     | ~2 hours| Can ship; fix in next patch |

**Minimum for launch:** Fix **H-1** (MiniMessage injection in spy system). The rest are correctness improvements that won't cause crashes or data loss but should be addressed in the first post-launch patch.
