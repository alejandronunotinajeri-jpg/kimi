package com.ethernova.progression.level;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for the XP formula methods in LevelManager.
 * Since getXPForLevel and getTotalXPForLevel are pure math,
 * we test them via a simple test wrapper that mimics the formula.
 */
class LevelFormulaTest {

    // Exact copy of LevelManager formula: 100 * n * (1 + n/10)
    static long getXPForLevel(int level) {
        return (long) (100.0 * level * (1.0 + level / 10.0));
    }

    static long getTotalXPForLevel(int level) {
        long total = 0;
        for (int i = 1; i < level; i++) {
            total += getXPForLevel(i);
        }
        return total;
    }

    @Nested
    @DisplayName("getXPForLevel() — formula: 100 * n * (1 + n/10)")
    class XPForLevelTests {
        @Test void level1() { assertEquals(110, getXPForLevel(1)); }
        @Test void level2() { assertEquals(240, getXPForLevel(2)); }
        @Test void level5() { assertEquals(750, getXPForLevel(5)); }
        @Test void level10() { assertEquals(2000, getXPForLevel(10)); }
        @Test void level50() { assertEquals(30000, getXPForLevel(50)); }
        @Test void level100() { assertEquals(110000, getXPForLevel(100)); }

        @Test
        void increasesMonotonically() {
            long prev = 0;
            for (int i = 1; i <= 100; i++) {
                long current = getXPForLevel(i);
                assertTrue(current > prev, "Level " + i + " should require more XP than " + (i - 1));
                prev = current;
            }
        }
    }

    @Nested
    @DisplayName("getTotalXPForLevel()")
    class TotalXPTests {
        @Test void level1TotalIs0() { assertEquals(0, getTotalXPForLevel(1)); }
        @Test void level2TotalIsLevel1XP() { assertEquals(110, getTotalXPForLevel(2)); }
        @Test void level3IsSum() { assertEquals(110 + 240, getTotalXPForLevel(3)); }

        @Test
        void totalIncreasesMonotonically() {
            long prev = 0;
            for (int i = 2; i <= 50; i++) {
                long current = getTotalXPForLevel(i);
                assertTrue(current > prev);
                prev = current;
            }
        }
    }

    @Nested
    @DisplayName("Progress calculation")
    class ProgressTests {
        static double getProgress(long currentXP, int level) {
            long required = getXPForLevel(level);
            if (required <= 0) return 1.0;
            long currentInLevel = currentXP - getTotalXPForLevel(level);
            return Math.min(1.0, Math.max(0.0, (double) currentInLevel / required));
        }

        @Test void zeroProgressAtStart() { assertEquals(0.0, getProgress(0, 1), 0.01); }
        @Test void halfProgress() {
            long half = getXPForLevel(1) / 2;
            assertEquals(0.5, getProgress(half, 1), 0.01);
        }
        @Test void fullProgress() {
            long full = getXPForLevel(1);
            assertEquals(1.0, getProgress(full, 1), 0.01);
        }
        @Test void clampedAbove() {
            assertEquals(1.0, getProgress(9999999, 1), 0.01);
        }
    }
}
