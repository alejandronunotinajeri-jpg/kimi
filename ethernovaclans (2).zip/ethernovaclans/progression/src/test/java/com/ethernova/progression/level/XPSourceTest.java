package com.ethernova.progression.level;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import static org.junit.jupiter.api.Assertions.*;

class XPSourceTest {

    @ParameterizedTest
    @EnumSource(XPSource.class)
    @DisplayName("Every source has a config key")
    void configKeyNotNull(XPSource source) {
        assertNotNull(source.getConfigKey());
        assertFalse(source.getConfigKey().isEmpty());
    }

    @ParameterizedTest
    @EnumSource(XPSource.class)
    @DisplayName("Every source has non-negative base XP (except ADMIN)")
    void baseXPNonNegative(XPSource source) {
        assertTrue(source.getBaseXP() >= 0);
    }

    @Nested
    @DisplayName("Specific values")
    class SpecificValueTests {
        @Test void killXP() { assertEquals(50, XPSource.KILL.getBaseXP()); }
        @Test void achievementXP() { assertEquals(200, XPSource.ACHIEVEMENT.getBaseXP()); }
        @Test void adminZeroXP() { assertEquals(0, XPSource.ADMIN.getBaseXP()); }
        @Test void playtimeXP() { assertEquals(5, XPSource.PLAYTIME.getBaseXP()); }
        @Test void questXP() { assertEquals(100, XPSource.QUEST.getBaseXP()); }
        @Test void voteXP() { assertEquals(75, XPSource.VOTE.getBaseXP()); }
    }

    @Test
    @DisplayName("Eight XP sources exist")
    void eightSources() {
        assertEquals(8, XPSource.values().length);
    }

    @Test
    @DisplayName("Config keys follow expected pattern")
    void configKeyPattern() {
        for (XPSource source : XPSource.values()) {
            assertTrue(source.getConfigKey().startsWith("xp-multipliers."),
                    source.name() + " config key should start with xp-multipliers.");
        }
    }
}
