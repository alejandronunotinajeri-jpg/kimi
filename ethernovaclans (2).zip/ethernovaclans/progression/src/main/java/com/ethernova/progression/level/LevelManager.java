package com.ethernova.progression.level;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.event.LevelUpEvent;
import com.ethernova.core.profile.PlayerProfile;
import com.ethernova.progression.EthernovaProgression;
import com.ethernova.progression.message.MessageManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * Core leveling logic. Handles XP calculation, level-up detection,
 * BossBar XP display, and event publishing for the progression system.
 */
public class LevelManager {

    private final EthernovaProgression plugin;
    private final EthernovaCore core;
    private final MiniMessage mini = MiniMessage.miniMessage();
    private final Logger logger;

    private int maxLevel;

    // ══════════════════════════════════════════
    //            BOSSBAR XP SYSTEM
    // ══════════════════════════════════════════
    private final Map<UUID, BossBar> xpBars = new ConcurrentHashMap<>();

    public LevelManager(EthernovaProgression plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
        this.logger = plugin.getLogger();
        this.maxLevel = plugin.getProgressionConfig().getInt("leveling.max-level", 100);
    }

    private MessageManager mm() { return plugin.getMessageManager(); }

    /**
     * XP required TO COMPLETE a given level: 100 * n * (1 + n/10).
     * i.e., to go from level n to n+1, you need this much XP.
     */
    public long getXPForLevel(int level) {
        return (long) (100.0 * level * (1.0 + level / 10.0));
    }

    /**
     * Total XP accumulated from level 1 to the given level.
     */
    public long getTotalXPForLevel(int level) {
        long total = 0;
        for (int i = 1; i < level; i++) {
            total += getXPForLevel(i);
        }
        return total;
    }

    /**
     * XP needed from current XP to reach the next level.
     */
    public long getXPForNextLevel(PlayerProfile profile) {
        long required = getXPForLevel(profile.getLevel());
        long currentInLevel = profile.getXP() - getTotalXPForLevel(profile.getLevel());
        return Math.max(0, required - currentInLevel);
    }

    /**
     * Returns progress toward the next level as 0.0 to 1.0.
     */
    public double getProgress(PlayerProfile profile) {
        long required = getXPForLevel(profile.getLevel());
        if (required <= 0) return 1.0;
        long currentInLevel = profile.getXP() - getTotalXPForLevel(profile.getLevel());
        return Math.min(1.0, Math.max(0.0, (double) currentInLevel / required));
    }

    /**
     * Add XP to a player with boost multiplier, prestige multiplier,
     * and source multiplier auto-applied. Handles multi-level ups.
     *
     * @param player The online player
     * @param amount Base XP amount before multipliers
     * @param source The source of XP
     */
    public void addXP(Player player, long amount, XPSource source) {
        if (amount <= 0) return;
        PlayerProfile profile = core.getProfileManager().getProfile(player.getUniqueId());
        if (profile == null) return;

        int currentLevel = profile.getLevel();
        if (currentLevel >= maxLevel) return; // At max level, no more XP

        // Apply source multiplier from config
        double sourceMultiplier = plugin.getProgressionConfig()
                .getDouble(source.getConfigKey(), 1.0);

        // Apply global boost multiplier
        double boostMultiplier = core.getBoostManager().getMultiplier("xp");

        // Apply prestige multiplier
        double prestigeMultiplier = plugin.getPrestigeManager().getMultiplier(profile.getPrestige());

        long finalXP = Math.round(amount * sourceMultiplier * boostMultiplier * prestigeMultiplier);
        if (finalXP <= 0) return;

        profile.addXP(finalXP);

        // Check for multi-level ups
        int oldLevel = currentLevel;
        int newLevel = oldLevel;

        while (newLevel < maxLevel) {
            long totalXPRequired = getTotalXPForLevel(newLevel + 1);
            if (profile.getXP() >= totalXPRequired) {
                newLevel++;
            } else {
                break;
            }
        }

        if (newLevel > oldLevel) {
            profile.setLevel(newLevel);

            final int finalOldLevel = oldLevel;
            final int finalNewLevel = newLevel;

            // Publish event for each level gained
            core.getEventBus().publish(new LevelUpEvent(
                    player.getUniqueId(), player.getName(), finalOldLevel, finalNewLevel));

            // Play sound and send messages on the main thread
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (!player.isOnline()) return;

                core.getSoundManager().play(player, "level_up");

                // Send title
                player.showTitle(Title.title(
                        mini.deserialize(mm().get("level.up-title", "{level}", String.valueOf(finalNewLevel))),
                        mini.deserialize(mm().get("level.up-subtitle")),
                        Title.Times.times(Duration.ofMillis(200), Duration.ofSeconds(2), Duration.ofMillis(500))
                ));

                // Send chat message
                player.sendMessage(mini.deserialize(
                        mm().get("level.up-chat",
                                "{old_level}", String.valueOf(finalOldLevel),
                                "{new_level}", String.valueOf(finalNewLevel),
                                "{xp}", String.valueOf(finalXP))
                ));

                // Broadcast if configured
                if (plugin.getProgressionConfig().getBoolean("leveling.broadcast-level-up", true) && finalNewLevel % 10 == 0) {
                    Bukkit.broadcast(mini.deserialize(
                            mm().get("level.up-broadcast",
                                    "{player}", player.getName(),
                                    "{level}", String.valueOf(finalNewLevel))
                    ));
                }
            });
        }

        // Send XP gain action bar
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (player.isOnline()) {
                player.sendActionBar(mini.deserialize(
                        mm().get("level.xp-actionbar",
                                "{xp}", String.valueOf(finalXP),
                                "{source}", source.name().toLowerCase().replace("_", " "))
                ));
                // Update BossBar
                PlayerProfile refreshedProfile = core.getProfileManager().getProfile(player.getUniqueId());
                if (refreshedProfile != null) updateXPBar(player, refreshedProfile);
            }
        });
    }

    /**
     * Add raw XP without multipliers (for admin/special cases).
     */
    public void addRawXP(Player player, long amount) {
        if (amount <= 0) return;
        PlayerProfile profile = core.getProfileManager().getProfile(player.getUniqueId());
        if (profile == null) return;

        int oldLevel = profile.getLevel();
        profile.addXP(amount);

        int newLevel = oldLevel;
        while (newLevel < maxLevel) {
            long totalXPRequired = getTotalXPForLevel(newLevel + 1);
            if (profile.getXP() >= totalXPRequired) {
                newLevel++;
            } else {
                break;
            }
        }

        if (newLevel > oldLevel) {
            profile.setLevel(newLevel);
            core.getEventBus().publish(new LevelUpEvent(
                    player.getUniqueId(), player.getName(), oldLevel, newLevel));

            int levelFinal = newLevel;
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (player.isOnline()) {
                    core.getSoundManager().play(player, "level_up");
                    player.showTitle(Title.title(
                            mini.deserialize(mm().get("level.up-title", "{level}", String.valueOf(levelFinal))),
                            mini.deserialize(mm().get("level.up-subtitle")),
                            Title.Times.times(Duration.ofMillis(200), Duration.ofSeconds(2), Duration.ofMillis(500))
                    ));
                }
            });
        }
    }

    public int getMaxLevel() { return maxLevel; }

    public void setMaxLevel(int maxLevel) { this.maxLevel = maxLevel; }

    // ══════════════════════════════════════════
    //            BOSSBAR XP DISPLAY
    // ══════════════════════════════════════════

    /**
     * Show the XP BossBar for a player.
     */
    public void showXPBar(Player player) {
        UUID uuid = player.getUniqueId();
        PlayerProfile profile = core.getProfileManager().getProfile(uuid);
        if (profile == null) return;

        if (xpBars.containsKey(uuid)) {
            updateXPBar(player, profile);
            return;
        }

        BossBar bar = Bukkit.createBossBar(
            formatBarTitle(profile),
            getBarColor(profile.getLevel()),
            BarStyle.SEGMENTED_10
        );
        bar.addPlayer(player);
        bar.setProgress(getProgress(profile));
        xpBars.put(uuid, bar);
    }

    /**
     * Hide the XP BossBar for a player.
     */
    public void hideXPBar(Player player) {
        BossBar bar = xpBars.remove(player.getUniqueId());
        if (bar != null) bar.removeAll();
    }

    /**
     * Update the BossBar after XP gain.
     */
    private void updateXPBar(Player player, PlayerProfile profile) {
        BossBar bar = xpBars.get(player.getUniqueId());
        if (bar == null) return;
        bar.setTitle(formatBarTitle(profile));
        bar.setProgress(getProgress(profile));
        bar.setColor(getBarColor(profile.getLevel()));
    }

    private String formatBarTitle(PlayerProfile profile) {
        int level = profile.getLevel();
        String color = getLevelColor(level);
        if (level >= maxLevel) {
            return color + "§l★ NIVEL " + level + " §7— §d§lMÁXIMO";
        }
        long needed = getXPForLevel(level);
        long currentInLevel = profile.getXP() - getTotalXPForLevel(level);
        return color + "§lNivel " + level + " §8| §7XP: §a" + currentInLevel + "§7/§a" + needed
            + " §8| " + color + "§l" + getLevelTag(level);
    }

    private BarColor getBarColor(int level) {
        if (level >= 75) return BarColor.PURPLE;
        if (level >= 50) return BarColor.YELLOW;
        if (level >= 25) return BarColor.GREEN;
        return BarColor.BLUE;
    }

    /**
     * Get level color code.
     */
    public String getLevelColor(int level) {
        if (level >= 90) return "§d";
        if (level >= 75) return "§6";
        if (level >= 50) return "§c";
        if (level >= 25) return "§e";
        if (level >= 10) return "§a";
        return "§7";
    }

    /**
     * Get level tag name.
     */
    public String getLevelTag(int level) {
        if (level >= 100) return "§d§lLEYENDA";
        if (level >= 90) return "§d§lMAESTRO";
        if (level >= 75) return "§6§lÉLITE";
        if (level >= 60) return "§c§lEXPERTO";
        if (level >= 50) return "§c§lVETERANO";
        if (level >= 40) return "§e§lGUERRERO";
        if (level >= 30) return "§e§lLUCHADOR";
        if (level >= 20) return "§a§lSOLDADO";
        if (level >= 10) return "§a§lRECLUTA";
        if (level >= 5) return "§7§lNOVATO";
        return "§7§lPRINCIPIANTE";
    }

    /**
     * Handle join — show BossBar.
     */
    public void handleJoin(Player player) {
        showXPBar(player);
    }

    /**
     * Handle quit — hide BossBar.
     */
    public void handleQuit(Player player) {
        hideXPBar(player);
    }

    /**
     * Check if BossBar is active for player.
     */
    public boolean hasXPBar(UUID uuid) {
        return xpBars.containsKey(uuid);
    }

    /**
     * Toggle BossBar on/off.
     */
    public void toggleXPBar(Player player) {
        if (hasXPBar(player.getUniqueId())) {
            hideXPBar(player);
            player.sendMessage("§c§l✗ §cBarra de XP ocultada");
        } else {
            showXPBar(player);
            player.sendMessage("§a§l✓ §aBarra de XP activada");
        }
    }
}
