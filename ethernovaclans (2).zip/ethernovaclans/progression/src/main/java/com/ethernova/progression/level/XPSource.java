package com.ethernova.progression.level;

/**
 * Sources of XP in the progression system.
 * Each source has a base XP amount and a configurable multiplier key.
 */
public enum XPSource {

    KILL(50, "xp-multipliers.kill"),
    DEATH_AVOIDED(30, "xp-multipliers.death-avoided"),
    PLAYTIME(5, "xp-multipliers.playtime"),
    MINING(3, "xp-multipliers.mining"),
    QUEST(100, "xp-multipliers.quest"),
    ACHIEVEMENT(200, "xp-multipliers.achievement"),
    VOTE(75, "xp-multipliers.vote"),
    ADMIN(0, "xp-multipliers.admin");

    private final int baseXP;
    private final String configKey;

    XPSource(int baseXP, String configKey) {
        this.baseXP = baseXP;
        this.configKey = configKey;
    }

    public int getBaseXP() { return baseXP; }
    public String getConfigKey() { return configKey; }
}
