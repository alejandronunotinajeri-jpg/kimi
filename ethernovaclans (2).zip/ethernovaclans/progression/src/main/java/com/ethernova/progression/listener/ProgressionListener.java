package com.ethernova.progression.listener;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.event.EthernovaPlayerKillEvent;
import com.ethernova.core.profile.PlayerProfile;
import com.ethernova.core.service.ServiceRegistry;
import com.ethernova.progression.EthernovaProgression;
import com.ethernova.progression.daily.DailyRewardManager;
import com.ethernova.progression.level.XPSource;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;

/**
 * Listens to Bukkit events and EventBus events for progression tracking.
 * Updates mission/achievement progress on kills, block breaks, movement.
 */
public class ProgressionListener implements Listener {

    private final EthernovaProgression plugin;
    private final EthernovaCore core;

    /** Track player last locations for distance calculation. */
    private final Map<UUID, Location> lastLocations = new ConcurrentHashMap<>();

    /** Track cumulative distance for batching. */
    private final Map<UUID, Double> pendingDistance = new ConcurrentHashMap<>();

    /** Track damage dealt for missions. */
    private final Map<UUID, Double> pendingDamage = new ConcurrentHashMap<>();

    /** Track alive time (seconds) for survive missions. */
    private final Map<UUID, Long> aliveTimestamp = new ConcurrentHashMap<>();

    /** Track killstreaks for streak achievements. */
    private final Map<UUID, Integer> killStreaks = new ConcurrentHashMap<>();

    /** Track recent kill timestamps for multikill detection. */
    private final Map<UUID, Deque<Long>> recentKillTimes = new ConcurrentHashMap<>();

    /** Track join timestamp for velocista achievement. */
    private final Map<UUID, Long> joinTimestamp = new ConcurrentHashMap<>();

    /** Track death count for temerario achievement. */
    private final Map<UUID, Integer> deathCount = new ConcurrentHashMap<>();

    /** Cooldown for survivor achievement to prevent double-counting from rapid hits. */
    private final Map<UUID, Long> lastSurvivorCheck = new ConcurrentHashMap<>();

    /** Set of ore materials for mining tracking. */
    private static final Set<Material> ORES = Set.of(
            Material.COAL_ORE, Material.DEEPSLATE_COAL_ORE,
            Material.IRON_ORE, Material.DEEPSLATE_IRON_ORE,
            Material.GOLD_ORE, Material.DEEPSLATE_GOLD_ORE,
            Material.DIAMOND_ORE, Material.DEEPSLATE_DIAMOND_ORE,
            Material.EMERALD_ORE, Material.DEEPSLATE_EMERALD_ORE,
            Material.LAPIS_ORE, Material.DEEPSLATE_LAPIS_ORE,
            Material.REDSTONE_ORE, Material.DEEPSLATE_REDSTONE_ORE,
            Material.COPPER_ORE, Material.DEEPSLATE_COPPER_ORE,
            Material.NETHER_GOLD_ORE, Material.NETHER_QUARTZ_ORE,
            Material.ANCIENT_DEBRIS
    );

    public ProgressionListener(EthernovaProgression plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
        registerEventBusListeners();
    }

    private void registerEventBusListeners() {
        // Subscribe to kill events via EventBus
        core.getEventBus().subscribe(EthernovaPlayerKillEvent.class, this::onPlayerKill);
    }

    /**
     * Handle player kills from the EventBus.
     */
    private void onPlayerKill(EthernovaPlayerKillEvent event) {
        Player killer = Bukkit.getPlayer(event.killerUuid());
        if (killer == null || !killer.isOnline()) return;

        // XP for kill
        Bukkit.getScheduler().runTask(plugin, () -> {
            plugin.getLevelManager().addXP(killer, XPSource.KILL.getBaseXP(), XPSource.KILL);

            // Battle pass XP
            plugin.getBattlePassManager().addXP(killer, 25);

            UUID killerUuid = killer.getUniqueId();
            var am = plugin.getAchievementManager();

            // Achievement: kill tracking (first_blood, warrior, legend_slayer, genocida)
            PlayerProfile profile = core.getProfileManager().getProfile(killerUuid);
            if (profile != null) {
                int kills = profile.getKills();
                am.checkProgress(killer, "first_blood", 1);
                am.setProgress(killer, "warrior", kills);
                am.setProgress(killer, "legend_slayer", kills);
                am.setProgress(killer, "genocida", kills);
            }

            // Achievement: killstreak tracking (streak_5, streak_10, dios_rachas)
            int streak = killStreaks.merge(killerUuid, 1, Integer::sum);
            am.setProgress(killer, "streak_5", streak);
            am.setProgress(killer, "streak_10", streak);
            am.setProgress(killer, "dios_rachas", streak);

            // Achievement: clutch_master — kill while at less than 1 heart (2 hp)
            if (killer.getHealth() <= 2.0) {
                am.checkProgress(killer, "clutch_master", 1);
            }

            // Achievement: velocista — kill within 10 seconds of joining/respawning
            Long joinTime = joinTimestamp.get(killerUuid);
            if (joinTime != null && (System.currentTimeMillis() - joinTime) <= 10_000) {
                am.checkProgress(killer, "velocista", 1);
            }

            // Achievement: multikill — 3 kills within 5 seconds
            long now = System.currentTimeMillis();
            Deque<Long> times = recentKillTimes.computeIfAbsent(killerUuid, k -> new ConcurrentLinkedDeque<>());
            times.addLast(now);
            // Remove kills older than 5 seconds
            while (!times.isEmpty() && (now - times.peekFirst()) > 5_000) {
                times.pollFirst();
            }
            if (times.size() >= 3) {
                am.checkProgress(killer, "multikill", 1);
                times.clear(); // Reset after triggering
            }

            // Achievement: rompe_rachas — check if victim had a streak BEFORE resetting
            int victimStreak = killStreaks.getOrDefault(event.victimUuid(), 0);
            if (victimStreak >= 5) {
                am.checkProgress(killer, "rompe_rachas", 1);
            }

            // Reset victim's streak on death
            killStreaks.put(event.victimUuid(), 0);

            // Mission: kill missions
            plugin.getMissionManager().addProgress(killer, "KILLER", 1);
            plugin.getMissionManager().addProgress(killer, "ARENA_DOMINATOR", 1);
            plugin.getMissionManager().addProgress(killer, "CRITICAL_HIT", 1);
        });
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();

        lastLocations.put(uuid, player.getLocation().clone());
        aliveTimestamp.put(uuid, System.currentTimeMillis());
        joinTimestamp.put(uuid, System.currentTimeMillis());
        killStreaks.put(uuid, 0);

        // Load progression data async
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            plugin.getAchievementManager().loadPlayer(uuid);
            plugin.getMissionManager().loadPlayer(uuid);
            plugin.getBattlePassManager().loadPlayer(uuid);
        });

        // Check level/prestige/economy achievements after a brief delay
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) return;
            PlayerProfile profile = core.getProfileManager().getProfile(uuid);
            if (profile == null) return;

            var am = plugin.getAchievementManager();
            int level = profile.getLevel();
            int prestige = profile.getPrestige();

            // Level achievements (all levels)
            am.setProgress(player, "level_10", level);
            am.setProgress(player, "level_25", level);
            am.setProgress(player, "level_50", level);
            am.setProgress(player, "level_75", level);
            am.setProgress(player, "level_100", level);
            am.setProgress(player, "leyenda", level);

            // Prestige achievements (all prestiges)
            am.setProgress(player, "prestige_1", prestige);
            am.setProgress(player, "prestige_5", prestige);
            am.setProgress(player, "prestige_10", prestige);
            am.setProgress(player, "mitico", prestige);

            // Playtime achievements (in minutes)
            long playMinutes = profile.getPlayTime() / 60000;
            am.setProgress(player, "playtime_10h", (int) playMinutes);
            am.setProgress(player, "playtime_100h", (int) playMinutes);

            // Economy achievements — coins currently held
            double coins = profile.getCoins();
            am.setProgress(player, "primer_sueldo", (int) coins);
            am.setProgress(player, "ahorrista", (int) coins);
            am.setProgress(player, "primer_millon", (int) Math.min(coins, Integer.MAX_VALUE));
            am.setProgress(player, "magnate", (int) Math.min(coins, Integer.MAX_VALUE));

            // Kill-based achievements (cumulative check)
            int kills = profile.getKills();
            am.setProgress(player, "warrior", kills);
            am.setProgress(player, "legend_slayer", kills);
            am.setProgress(player, "genocida", kills);

            // Cosmetic count achievements via CosmeticsAPI
            checkCosmeticCountAchievements(player);
        }, 40L);
    }

    /**
     * Check cosmetic unlock count achievements via CosmeticsAPI.
     */
    private void checkCosmeticCountAchievements(Player player) {
        try {
            Object cosmeticsApi = ServiceRegistry.get(
                    Class.forName("com.ethernova.cosmetics.api.CosmeticsAPI"));
            if (cosmeticsApi == null) return;
            Method getAllUnlocked = cosmeticsApi.getClass().getMethod("getAllUnlocked", UUID.class);
            @SuppressWarnings("unchecked")
            Set<String> unlocked = (Set<String>) getAllUnlocked.invoke(cosmeticsApi, player.getUniqueId());
            if (unlocked != null) {
                int count = unlocked.size();
                plugin.getAchievementManager().setProgress(player, "coleccionista", count);
                plugin.getAchievementManager().setProgress(player, "coleccion_total", count);
            }
        } catch (Exception ignored) {
            // CosmeticsAPI not available
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerQuit(PlayerQuitEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        lastLocations.remove(uuid);
        pendingDistance.remove(uuid);
        pendingDamage.remove(uuid);
        aliveTimestamp.remove(uuid);
        killStreaks.remove(uuid);
        recentKillTimes.remove(uuid);
        joinTimestamp.remove(uuid);
        deathCount.remove(uuid);
        lastSurvivorCheck.remove(uuid);

        // Hide XP BossBar to prevent leak
        plugin.getLevelManager().hideXPBar(event.getPlayer());

        // Save & unload progression data
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            plugin.getAchievementManager().unloadPlayer(uuid);
            plugin.getMissionManager().unloadPlayer(uuid);
            plugin.getBattlePassManager().unloadPlayer(uuid);
            plugin.getDailyRewardManager().unloadPlayer(uuid);
        });
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Material type = event.getBlock().getType();

        // Mining XP for ores
        if (ORES.contains(type)) {
            plugin.getLevelManager().addXP(player, XPSource.MINING.getBaseXP(), XPSource.MINING);
        }

        // Mission: mining/exploration progress
        plugin.getMissionManager().addProgress(player, "EXPLORER", 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerMove(PlayerMoveEvent event) {
        // Only track actual movement (not just looking around)
        Location from = event.getFrom();
        Location to = event.getTo();
        if (to == null) return;
        if (from.getBlockX() == to.getBlockX() && from.getBlockY() == to.getBlockY() && from.getBlockZ() == to.getBlockZ()) {
            return;
        }

        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();

        Location lastLoc = lastLocations.get(uuid);
        if (lastLoc == null || !java.util.Objects.equals(lastLoc.getWorld(), to.getWorld())) {
            lastLocations.put(uuid, to.clone());
            return;
        }

        double distance = lastLoc.distance(to);
        lastLocations.put(uuid, to.clone());

        // Batch distance tracking to avoid excessive updates
        double pending = pendingDistance.merge(uuid, distance, Double::sum);
        if (pending >= 100) { // Process every 100 blocks
            int blocks = (int) pending;
            pendingDistance.put(uuid, pending - blocks);

            // Mission: travel / exploration
            plugin.getMissionManager().addProgress(player, "ARENA_VISITOR", blocks);
            plugin.getMissionManager().addProgress(player, "EXPLORER", blocks);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        if (!(event.getEntity() instanceof Player)) return;

        double damage = event.getFinalDamage();

        // Mission: damage dealt + critical hits
        plugin.getMissionManager().addProgress(player, "CRITICAL_HIT", (int) damage);

        // Death avoidance check - if victim survived with low health
        Player victim = (Player) event.getEntity();
        double healthAfter = victim.getHealth() - damage;
        if (healthAfter > 0 && healthAfter <= 4.0) { // 2 hearts or less
            // Victim survived with low health — cooldown to prevent double-counting from rapid hits
            UUID victimUuid = victim.getUniqueId();
            long now = System.currentTimeMillis();
            Long lastCheck = lastSurvivorCheck.get(victimUuid);
            if (lastCheck != null && (now - lastCheck) < 5_000) return; // 5s cooldown
            lastSurvivorCheck.put(victimUuid, now);

            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (victim.isOnline() && victim.getHealth() > 0 && victim.getHealth() <= 4.0) {
                    plugin.getLevelManager().addXP(victim, XPSource.DEATH_AVOIDED.getBaseXP(), XPSource.DEATH_AVOIDED);
                    plugin.getAchievementManager().checkProgress(victim, "survivor", 1);
                }
            }, 20L); // Check 1 second later to confirm survival
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        UUID uuid = player.getUniqueId();

        // Achievement: temerario — death count
        plugin.getAchievementManager().checkProgress(player, "temerario", 1);

        // Reset killstreak on death
        killStreaks.put(uuid, 0);

        // Reset alive timestamp for inmortal tracking
        aliveTimestamp.put(uuid, System.currentTimeMillis());

        // Reset join timestamp for velocista (respawn = new life)
        joinTimestamp.put(uuid, System.currentTimeMillis());
    }

    /**
     * Process playtime XP (called from timer task).
     */
    public void processPlaytimeXP() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            plugin.getLevelManager().addXP(player, XPSource.PLAYTIME.getBaseXP(), XPSource.PLAYTIME);

            // Mission: playtime + survival
            plugin.getMissionManager().addProgress(player, "TIME_PLAYER", 1);
            plugin.getMissionManager().addProgress(player, "DAILY_LOGIN", 1);

            // Battle pass passive XP
            plugin.getBattlePassManager().addXP(player, 5);
        }
    }

    /**
     * Process alive-time tracking for survive missions.
     */
    public void processAliveTime() {
        long now = System.currentTimeMillis();
        for (Player player : Bukkit.getOnlinePlayers()) {
            UUID uuid = player.getUniqueId();
            Long start = aliveTimestamp.get(uuid);
            if (start == null) continue;

            long aliveSeconds = (now - start) / 1000;

            // Achievement: inmortal — survive 30 minutes without dying
            plugin.getAchievementManager().setProgress(player, "inmortal", (int) aliveSeconds);

            // Update playtime achievements
            PlayerProfile profile = core.getProfileManager().getProfile(uuid);
            if (profile != null) {
                long totalMinutes = profile.getPlayTime() / 60000;
                plugin.getAchievementManager().setProgress(player, "playtime_10h", (int) totalMinutes);
                plugin.getAchievementManager().setProgress(player, "playtime_100h", (int) totalMinutes);

                // Periodically update economy achievements
                double coins = profile.getCoins();
                plugin.getAchievementManager().setProgress(player, "primer_sueldo", (int) coins);
                plugin.getAchievementManager().setProgress(player, "ahorrista", (int) coins);
                plugin.getAchievementManager().setProgress(player, "primer_millon", (int) Math.min(coins, Integer.MAX_VALUE));
                plugin.getAchievementManager().setProgress(player, "magnate", (int) Math.min(coins, Integer.MAX_VALUE));
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //              CALENDAR GUI CLICK HANDLER
    // ═══════════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGH)
    public void onCalendarClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        String title = event.getView().getTitle();
        if (title == null) return;
        String stripped = ChatColor.stripColor(title);
        if (!stripped.contains("CALENDARIO")) return;

        event.setCancelled(true);

        int slot = event.getRawSlot();
        if (slot < 0 || slot >= 45) return;

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR) return;

        DailyRewardManager drm = plugin.getDailyRewardManager();
        if (drm == null) return;

        // Back button (slot 40) → close
        if (slot == 40 && clicked.getType() == Material.ARROW) {
            player.closeInventory();
            return;
        }

        // Day slots 10-16: CHEST_MINECART = available to claim
        if (slot >= 10 && slot <= 16 && clicked.getType() == Material.CHEST_MINECART) {
            boolean success = drm.claimReward(player);
            if (success) {
                // Reopen GUI to show updated state
                Bukkit.getScheduler().runTaskLater(plugin, () -> drm.openGui(player), 2L);
            }
        }
    }
}
