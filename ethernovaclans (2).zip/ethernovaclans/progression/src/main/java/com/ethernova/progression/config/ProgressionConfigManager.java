package com.ethernova.progression.config;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.logging.Level;

/**
 * Configuration manager for EthernovaProgression with smart merge support.
 * Loads config.yml and merges new default keys without overwriting existing values.
 */
public class ProgressionConfigManager {

    private final JavaPlugin plugin;
    private volatile FileConfiguration config;

    public ProgressionConfigManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Load all configuration files. Creates defaults if they don't exist,
     * and merges new keys from defaults into existing config.
     */
    public void loadAll() {
        File configFile = new File(plugin.getDataFolder(), "config.yml");
        boolean existed = configFile.exists();

        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        config = plugin.getConfig();

        if (existed) {
            plugin.getLogger().info("config.yml existente cargado (no se sobreescribió)");
            mergeDefaults(configFile);
        } else {
            plugin.getLogger().info("config.yml creado por primera vez con valores por defecto");
        }
    }

    /**
     * Merge default config values into the existing config file.
     * Only adds keys that don't already exist — never overwrites user values.
     */
    private void mergeDefaults(File configFile) {
        try (InputStream defStream = plugin.getResource("config.yml")) {
            if (defStream == null) return;
            YamlConfiguration defaults = YamlConfiguration.loadConfiguration(
                    new InputStreamReader(defStream, StandardCharsets.UTF_8));

            Set<String> allDefaultKeys = defaults.getKeys(true);
            int added = 0;
            for (String key : allDefaultKeys) {
                if (!config.contains(key)) {
                    config.set(key, defaults.get(key));
                    added++;
                }
            }
            if (added > 0) {
                plugin.saveConfig();
                plugin.reloadConfig();
                config = plugin.getConfig();
                plugin.getLogger().info("config.yml actualizado: " + added + " clave(s) nueva(s) añadida(s)");
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error al hacer merge de config defaults", e);
        }
    }

    /** Reload the configuration from disk. */
    public void reload() {
        loadAll();
    }

    public FileConfiguration getConfig() { return config; }
    public String getString(String path, String def) { return config.getString(path, def); }
    public int getInt(String path, int def) { return config.getInt(path, def); }
    public double getDouble(String path, double def) { return config.getDouble(path, def); }
    public boolean getBoolean(String path, boolean def) { return config.getBoolean(path, def); }
    public long getLong(String path, long def) { return config.getLong(path, def); }

    /**
     * Get a message with the progression prefix prepended.
     */
    public String getMessage(String key) {
        String prefix = config.getString("messages.prefix",
                "<gradient:#00d2ff:#3a7bd5>✦ Progresión</gradient> <dark_gray>»</dark_gray> ");
        String msg = config.getString("messages." + key, "<red>Mensaje no encontrado: " + key);
        return prefix + msg;
    }

    /**
     * Get a raw message without prefix.
     */
    public String getRawMessage(String key) {
        return config.getString("messages." + key, "<red>Mensaje no encontrado: " + key);
    }
}
