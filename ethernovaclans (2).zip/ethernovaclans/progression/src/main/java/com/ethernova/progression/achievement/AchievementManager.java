package com.ethernova.progression.achievement;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.profile.PlayerProfile;
import com.ethernova.core.service.ServiceRegistry;
import com.ethernova.core.storage.MigrationManager;
import com.ethernova.progression.EthernovaProgression;
import com.ethernova.progression.level.XPSource;
import com.ethernova.progression.message.MessageManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Manages achievements: registration, progress tracking, rewards.
 * Progress is stored in ethernova_achievements table.
 */
public class AchievementManager {

    private final EthernovaProgression plugin;
    private final EthernovaCore core;
    private final MiniMessage mini = MiniMessage.miniMessage();

    private MessageManager mm() { return plugin.getMessageManager(); }

    /** All registered achievements by id. */
    private final Map<String, Achievement> achievements = new LinkedHashMap<>();

    /** Player UUID -> achievement ID -> current progress. */
    private final Map<UUID, Map<String, Integer>> playerProgress = new ConcurrentHashMap<>();

    /** Player UUID -> set of completed achievement IDs. */
    private final Map<UUID, Set<String>> completedAchievements = new ConcurrentHashMap<>();

    public AchievementManager(EthernovaProgression plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
        runMigrations();
        registerDefaultAchievements();
    }

    private void runMigrations() {
        new MigrationManager(core.getStorageManager(), plugin.getLogger(), "ethernova_achievements")
                .addMigration(1,
                        """
                        CREATE TABLE IF NOT EXISTS ethernova_achievements (
                            uuid VARCHAR(36) NOT NULL,
                            achievement_id VARCHAR(64) NOT NULL,
                            progress INT DEFAULT 0,
                            completed INTEGER DEFAULT 0,
                            completed_at BIGINT DEFAULT 0,
                            claimed INTEGER DEFAULT 0,
                            PRIMARY KEY (uuid, achievement_id)
                        )
                        """)
                .migrate();
    }

    private void registerDefaultAchievements() {
        // ═══ COMBAT (15 achievements) ═══
        register(new Achievement("first_blood", "Primera Sangre", "Consigue tu primera kill", Material.IRON_SWORD, AchievementCategory.COMBAT, 1, 50, 100));
        register(new Achievement("warrior", "Guerrero", "Consigue 50 kills", Material.DIAMOND_SWORD, AchievementCategory.COMBAT, 50, 200, 500, "title_warrior"));
        register(new Achievement("legend_slayer", "Asesino Legendario", "Consigue 500 kills", Material.NETHERITE_SWORD, AchievementCategory.COMBAT, 500, 1000, 2500, "trail_flame"));
        register(new Achievement("genocida", "Genocida", "Consigue 1,000 kills", Material.WITHER_SKELETON_SKULL, AchievementCategory.COMBAT, 1000, 3000, 5000, "hit_dragon"));
        register(new Achievement("streak_5", "Racha Mortal", "Logra una racha de 5 kills", Material.BLAZE_POWDER, AchievementCategory.COMBAT, 5, 150, 300));
        register(new Achievement("streak_10", "Imparable", "Logra una racha de 10 kills", Material.FIRE_CHARGE, AchievementCategory.COMBAT, 10, 500, 1000, "hit_lightning"));
        register(new Achievement("dios_rachas", "Dios de las Rachas", "Logra una racha de 20 kills", Material.NETHER_STAR, AchievementCategory.COMBAT, 20, 2000, 4000, "finisher_tornado"));
        register(new Achievement("duelista", "Duelista", "Gana 10 duelos", Material.WOODEN_SWORD, AchievementCategory.COMBAT, 10, 300, 600));
        register(new Achievement("maestro_duelos", "Maestro de Duelos", "Gana 50 duelos", Material.GOLDEN_SWORD, AchievementCategory.COMBAT, 50, 1500, 3000, "finisher_execution"));
        register(new Achievement("invicto", "Invicto", "Gana 10 partidas consecutivas", Material.SHIELD, AchievementCategory.COMBAT, 10, 2000, 4000));
        register(new Achievement("survivor", "Superviviente", "Sobrevive con menos de 2 corazones 10 veces", Material.GOLDEN_APPLE, AchievementCategory.COMBAT, 10, 300, 600));
        register(new Achievement("clutch_master", "Clutch Master", "Mata al oponente con menos de 1 corazón 10 veces", Material.ENCHANTED_GOLDEN_APPLE, AchievementCategory.COMBAT, 10, 1000, 2000, "hit_critical"));
        register(new Achievement("cazador", "Cazador de Recompensas", "Cobra 25 recompensas", Material.ZOMBIE_HEAD, AchievementCategory.COMBAT, 25, 1500, 3000));
        register(new Achievement("rompe_rachas", "Rompe Rachas", "Rompe 50 rachas enemigas", Material.CHAIN, AchievementCategory.COMBAT, 50, 1000, 2000));
        register(new Achievement("arena_master", "Maestro de Arena", "Gana 100 combates en arenas", Material.IRON_CHESTPLATE, AchievementCategory.COMBAT, 100, 3000, 5000, "title_champion"));

        // ═══ ECONOMY (10 achievements) ═══
        register(new Achievement("primer_sueldo", "Primer Sueldo", "Consigue 1,000 monedas", Material.GOLD_NUGGET, AchievementCategory.EXPLORATION, 1000, 100, 200));
        register(new Achievement("ahorrista", "Ahorrista", "Acumula 10,000 monedas", Material.GOLD_INGOT, AchievementCategory.EXPLORATION, 10000, 500, 1000));
        register(new Achievement("primer_millon", "Primer Millón", "Acumula 1,000,000 monedas", Material.GOLD_BLOCK, AchievementCategory.EXPLORATION, 1000000, 5000, 10000, "trail_gold"));
        register(new Achievement("magnate", "Magnate", "Acumula 10,000,000 monedas", Material.RAW_GOLD_BLOCK, AchievementCategory.EXPLORATION, 10000000, 20000, 50000, "trail_emerald"));
        register(new Achievement("comprador", "Primer Comprador", "Compra un item de la tienda", Material.CHEST, AchievementCategory.EXPLORATION, 1, 50, 100));
        register(new Achievement("shopaholic", "Shopaholic", "Compra 50 items de la tienda", Material.ENDER_CHEST, AchievementCategory.EXPLORATION, 50, 1000, 2000));
        register(new Achievement("coleccionista", "Coleccionista", "Desbloquea 10 cosméticos", Material.ARMOR_STAND, AchievementCategory.EXPLORATION, 10, 500, 1000));
        register(new Achievement("coleccion_total", "Colección Total", "Desbloquea 50 cosméticos", Material.PAINTING, AchievementCategory.EXPLORATION, 50, 3000, 5000, "pet_warden"));
        register(new Achievement("generoso", "Generoso", "Dona 10,000 monedas a otros", Material.FLOWER_BANNER_PATTERN, AchievementCategory.EXPLORATION, 10000, 1000, 2000));
        register(new Achievement("inversor", "Inversor", "Compra 10 boosts", Material.BREWING_STAND, AchievementCategory.EXPLORATION, 10, 800, 1500));

        // ═══ PROGRESSION (10 achievements) ═══
        register(new Achievement("level_10", "Novato Avanzado", "Alcanza nivel 10", Material.EXPERIENCE_BOTTLE, AchievementCategory.PROGRESSION, 10, 100, 200));
        register(new Achievement("level_25", "Aprendiz", "Alcanza nivel 25", Material.EXPERIENCE_BOTTLE, AchievementCategory.PROGRESSION, 25, 250, 500));
        register(new Achievement("level_50", "Veterano", "Alcanza nivel 50", Material.EXPERIENCE_BOTTLE, AchievementCategory.PROGRESSION, 50, 500, 1500, "trail_enchant"));
        register(new Achievement("level_75", "Élite", "Alcanza nivel 75", Material.EXPERIENCE_BOTTLE, AchievementCategory.PROGRESSION, 75, 1000, 3000));
        register(new Achievement("level_100", "Maestro", "Alcanza nivel 100", Material.EXPERIENCE_BOTTLE, AchievementCategory.PROGRESSION, 100, 2000, 5000, "title_legend"));
        register(new Achievement("leyenda", "Leyenda", "Alcanza nivel 200", Material.DRAGON_EGG, AchievementCategory.PROGRESSION, 200, 10000, 25000, "elytra_rainbow"));
        register(new Achievement("prestige_1", "Primer Prestigio", "Alcanza Prestigio I", Material.GOLD_INGOT, AchievementCategory.PROGRESSION, 1, 1000, 3000));
        register(new Achievement("prestige_5", "Prestigio V", "Alcanza Prestigio V", Material.DIAMOND, AchievementCategory.PROGRESSION, 5, 5000, 10000, "title_frost"));
        register(new Achievement("prestige_10", "Prestigio X", "Alcanza Prestigio X", Material.EMERALD, AchievementCategory.PROGRESSION, 10, 15000, 30000, "title_shadow"));
        register(new Achievement("mitico", "Mítico", "Alcanza Prestigio XX", Material.NETHER_STAR, AchievementCategory.PROGRESSION, 20, 50000, 100000, "title_king"));

        // ═══ SOCIAL (5 achievements) ═══
        register(new Achievement("voter", "Votante Fiel", "Vota 10 veces", Material.EMERALD, AchievementCategory.SOCIAL, 10, 300, 500));
        register(new Achievement("voter_50", "Soporte Máximo", "Vota 50 veces", Material.EMERALD_BLOCK, AchievementCategory.SOCIAL, 50, 1000, 2000));
        register(new Achievement("party_leader", "Líder Natural", "Crea 5 parties", Material.PLAYER_HEAD, AchievementCategory.SOCIAL, 5, 200, 400));
        register(new Achievement("socializer", "Sociable", "Juega con 25 jugadores diferentes", Material.CAKE, AchievementCategory.SOCIAL, 25, 500, 1000));
        register(new Achievement("clan_founder", "Fundador de Clan", "Crea o lidera un clan", Material.WHITE_BANNER, AchievementCategory.SOCIAL, 1, 500, 1000));

        // ═══ SPECIAL (10 achievements) ═══
        register(new Achievement("playtime_10h", "Dedicado", "Juega 10 horas", Material.CLOCK, AchievementCategory.SPECIAL, 600, 300, 500));
        register(new Achievement("playtime_100h", "Eterno", "Juega 100 horas", Material.CLOCK, AchievementCategory.SPECIAL, 6000, 2000, 5000, "title_angel"));
        register(new Achievement("mission_master", "Maestro de Misiones", "Completa 50 misiones", Material.WRITABLE_BOOK, AchievementCategory.SPECIAL, 50, 800, 2000, "trail_magic"));
        register(new Achievement("temerario", "Temerario", "Muere 100 veces", Material.SKELETON_SKULL, AchievementCategory.SPECIAL, 100, 500, 1000));
        register(new Achievement("combo_dios", "Combo Dios", "Logra un combo de 10 golpes", Material.BLAZE_ROD, AchievementCategory.SPECIAL, 10, 1000, 2000, "hit_explosion"));
        register(new Achievement("multikill", "Multikill", "Mata 3 jugadores en 5 segundos", Material.TNT, AchievementCategory.SPECIAL, 3, 1500, 3000));
        register(new Achievement("comeback", "Comeback King", "Gana después de estar perdiendo", Material.TOTEM_OF_UNDYING, AchievementCategory.SPECIAL, 5, 1000, 2000));
        register(new Achievement("evento_master", "Maestro de Eventos", "Participa en 25 eventos", Material.FIREWORK_ROCKET, AchievementCategory.SPECIAL, 25, 2000, 4000, "trail_rainbow"));
        register(new Achievement("velocista", "Velocista", "Mata a un jugador en menos de 10 segundos de entrar", Material.SUGAR, AchievementCategory.SPECIAL, 10, 800, 1500));
        register(new Achievement("inmortal", "Inmortal", "Sobrevive 30 minutos sin morir", Material.BEACON, AchievementCategory.SPECIAL, 1800, 3000, 5000, "title_demon"));
    }

    public void register(Achievement achievement) {
        achievements.put(achievement.id(), achievement);
    }

    /**
     * Load achievement progress for a player from database.
     * Should be called from an async context (this method runs synchronously).
     */
    public void loadPlayer(UUID uuid) {
        Map<String, Integer> progress = new HashMap<>();
        Set<String> completed = ConcurrentHashMap.newKeySet();

        try (Connection conn = core.getStorageManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT achievement_id, progress, completed FROM ethernova_achievements WHERE uuid = ?")) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String id = rs.getString("achievement_id");
                    progress.put(id, rs.getInt("progress"));
                    if (rs.getBoolean("completed")) {
                        completed.add(id);
                    }
                }
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error loading achievements for " + uuid, e);
        }

        playerProgress.put(uuid, new ConcurrentHashMap<>(progress));
        completedAchievements.put(uuid, completed);
    }

    /**
     * Unload a player's data.
     */
    public void unloadPlayer(UUID uuid) {
        playerProgress.remove(uuid);
        completedAchievements.remove(uuid);
    }

    /**
     * Increment achievement progress and check for completion.
     */
    public void checkProgress(Player player, String achievementId, int amount) {
        UUID uuid = player.getUniqueId();
        Achievement achievement = achievements.get(achievementId);
        if (achievement == null) return;

        Set<String> completed = completedAchievements.computeIfAbsent(uuid, k -> ConcurrentHashMap.newKeySet());
        if (completed.contains(achievementId)) return;

        Map<String, Integer> progress = playerProgress.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>());
        int newProgress = progress.merge(achievementId, amount, Integer::sum);

        // Save progress async
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> saveProgress(uuid, achievementId, newProgress, false));

        // Check completion
        if (newProgress >= achievement.target()) {
            complete(player, achievement);
        }
    }

    /**
     * Set achievement progress to a specific value (for level/prestige tracking).
     */
    public void setProgress(Player player, String achievementId, int value) {
        UUID uuid = player.getUniqueId();
        Achievement achievement = achievements.get(achievementId);
        if (achievement == null) return;

        Set<String> completed = completedAchievements.computeIfAbsent(uuid, k -> ConcurrentHashMap.newKeySet());
        if (completed.contains(achievementId)) return;

        Map<String, Integer> progress = playerProgress.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>());
        progress.put(achievementId, value);

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> saveProgress(uuid, achievementId, value, false));

        if (value >= achievement.target()) {
            complete(player, achievement);
        }
    }

    private void complete(Player player, Achievement achievement) {
        UUID uuid = player.getUniqueId();
        Set<String> completed = completedAchievements.computeIfAbsent(uuid, k -> ConcurrentHashMap.newKeySet());
        if (!completed.add(achievement.id())) return; // Already completed

        // Save completion async
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () ->
                saveProgress(uuid, achievement.id(), achievement.target(), true));

        // Grant rewards
        PlayerProfile profile = core.getProfileManager().getProfile(uuid);
        if (profile != null) {
            profile.addCoins(achievement.coinReward());
        }
        // XP reward is independent of profile
        plugin.getLevelManager().addXP(player, achievement.xpReward(), XPSource.ACHIEVEMENT);

        // Grant cosmetic reward if present
        if (achievement.cosmeticReward() != null && !achievement.cosmeticReward().isEmpty()) {
            unlockCosmeticReward(uuid, achievement.cosmeticReward());
        }

        // Visual feedback on main thread
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!player.isOnline()) return;

            core.getSoundManager().play(player, "success");

            String achName = mm().get("achievement.name." + achievement.id());
            String achDesc = mm().get("achievement.desc." + achievement.id());

            String cosmeticInfo = "";
            if (achievement.cosmeticReward() != null && !achievement.cosmeticReward().isEmpty()) {
                cosmeticInfo = " <gradient:#a855f7:#ec4899>+ Cosmético desbloqueado!</gradient>";
            }

            mm().sendMessage(player, "achievement.complete",
                    "{name}", achName,
                    "{description}", achDesc,
                    "{coins}", String.format("%.0f", achievement.coinReward()),
                    "{xp}", String.valueOf(achievement.xpReward()));

            if (!cosmeticInfo.isEmpty()) {
                player.sendMessage(mini.deserialize(cosmeticInfo));
            }

            // Broadcast
            Bukkit.broadcast(mm().parse(mm().get("achievement.broadcast",
                    "{player}", player.getName(),
                    "{name}", achName)));
        });
    }

    /**
     * Unlock a cosmetic reward via CosmeticsAPI (ServiceRegistry).
     * Uses reflection-style ServiceRegistry lookup to avoid hard dependency.
     */
    private void unlockCosmeticReward(UUID uuid, String cosmeticId) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                Object cosmeticsApi = ServiceRegistry.get(
                        Class.forName("com.ethernova.cosmetics.api.CosmeticsAPI"));
                if (cosmeticsApi == null) {
                    plugin.getLogger().fine("CosmeticsAPI not available, skipping cosmetic reward: " + cosmeticId);
                    return;
                }
                Method unlockMethod = cosmeticsApi.getClass().getMethod("unlock", UUID.class, String.class);
                unlockMethod.invoke(cosmeticsApi, uuid, cosmeticId);
                plugin.getLogger().info("Achievement cosmetic reward unlocked: " + cosmeticId + " for " + uuid);
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Error unlocking cosmetic reward " + cosmeticId, e);
            }
        });
    }

    /**
     * Synchronously save all achievement data for a player (for use during shutdown).
     */
    public void savePlayerSync(UUID uuid) {
        Map<String, Integer> progress = playerProgress.get(uuid);
        if (progress == null) return;
        Set<String> completed = completedAchievements.getOrDefault(uuid, Collections.emptySet());
        for (Map.Entry<String, Integer> entry : progress.entrySet()) {
            saveProgress(uuid, entry.getKey(), entry.getValue(), completed.contains(entry.getKey()));
        }
    }

    private void saveProgress(UUID uuid, String achievementId, int progress, boolean completed) {
        String sql = core.getStorageManager().isMySQL()
                ? "INSERT INTO ethernova_achievements (uuid, achievement_id, progress, completed, completed_at) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE progress=VALUES(progress), completed=VALUES(completed), completed_at=VALUES(completed_at)"
                : "INSERT INTO ethernova_achievements (uuid, achievement_id, progress, completed, completed_at) VALUES (?, ?, ?, ?, ?) ON CONFLICT(uuid, achievement_id) DO UPDATE SET progress=excluded.progress, completed=excluded.completed, completed_at=excluded.completed_at";

        try (Connection conn = core.getStorageManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.setString(2, achievementId);
            ps.setInt(3, progress);
            ps.setBoolean(4, completed);
            ps.setLong(5, completed ? System.currentTimeMillis() : 0);
            ps.executeUpdate();
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error saving achievement progress", e);
        }
    }

    /**
     * Check if an achievement is completed by a player.
     */
    public boolean isCompleted(UUID uuid, String achievementId) {
        Set<String> completed = completedAchievements.get(uuid);
        return completed != null && completed.contains(achievementId);
    }

    /**
     * Get a player's progress for an achievement.
     */
    public int getProgress(UUID uuid, String achievementId) {
        Map<String, Integer> progress = playerProgress.get(uuid);
        return progress != null ? progress.getOrDefault(achievementId, 0) : 0;
    }

    /**
     * Get all achievements.
     */
    public Collection<Achievement> getAllAchievements() {
        return Collections.unmodifiableCollection(achievements.values());
    }

    /**
     * Get achievements by category.
     */
    public List<Achievement> getByCategory(AchievementCategory category) {
        return achievements.values().stream()
                .filter(a -> a.category() == category)
                .toList();
    }

    /**
     * Get an achievement by id.
     */
    public Achievement getAchievement(String id) {
        return achievements.get(id);
    }

    /**
     * Count completed achievements for a player.
     */
    public int getCompletedCount(UUID uuid) {
        Set<String> completed = completedAchievements.get(uuid);
        return completed != null ? completed.size() : 0;
    }

    public int getTotalCount() {
        return achievements.size();
    }
}
