package com.ethernova.progression.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.CoreGui;
import com.ethernova.core.profile.PlayerProfile;
import com.ethernova.progression.EthernovaProgression;
import com.ethernova.progression.message.MessageManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/**
 * Shows level progress, XP bar visual, prestige info, and navigation to other GUIs.
 */
public class LevelGui extends CoreGui {

    private final EthernovaProgression progression;

    public LevelGui(EthernovaCore core, EthernovaProgression progression, Player player) {
        super(core, player);
        this.progression = progression;
    }

    private MessageManager mm() { return progression.getMessageManager(); }

    public void open() {
        openInventory(mm().get("gui.level.title", "{player}", player.getName()), 54);
    }

    @Override
    protected void populateItems() {
        PlayerProfile profile = core.getProfileManager().getProfile(player.getUniqueId());
        if (profile == null) return;

        int level = profile.getLevel();
        int prestige = profile.getPrestige();
        long xp = profile.getXP();
        double progress = progression.getLevelManager().getProgress(profile);
        long xpForNext = progression.getLevelManager().getXPForNextLevel(profile);
        int maxLevel = progression.getLevelManager().getMaxLevel();
        String progressStr = String.format("%.1f", progress * 100);

        // Level info item (center)
        setItem(13, createItem(Material.EXPERIENCE_BOTTLE,
                mm().get("gui.level.level-name", "{level}", String.valueOf(level)),
                List.of(
                        "",
                        mm().get("gui.level.xp-total", "{xp}", String.format("%,d", xp)),
                        mm().get("gui.level.xp-next", "{xp}", String.format("%,d", xpForNext)),
                        mm().get("gui.level.progress-line", "{progress}", progressStr),
                        "",
                        mm().get("gui.level.max-level", "{max}", String.valueOf(maxLevel))
                )
        ));

        // Prestige info
        String prestigeDisplay = progression.getPrestigeManager().getPrestigeDisplay(prestige);
        double prestigeMulti = progression.getPrestigeManager().getMultiplier(prestige);
        boolean canPrestige = progression.getPrestigeManager().canPrestige(profile);

        setItem(11, createItem(canPrestige ? Material.NETHER_STAR : Material.GOLD_INGOT,
                prestigeDisplay,
                List.of(
                        "",
                        mm().get("gui.level.prestige-multiplier", "{multiplier}", String.format("%.2f", prestigeMulti)),
                        mm().get("gui.level.prestige-current",
                                "{current}", String.valueOf(prestige),
                                "{max}", String.valueOf(progression.getPrestigeManager().getMaxPrestige())),
                        "",
                        canPrestige
                                ? mm().get("gui.level.prestige-click")
                                : mm().get("gui.level.prestige-requirement", "{max}", String.valueOf(maxLevel))
                )
        ));
        slotActions.put(11, "PRESTIGE");

        // XP bar visualization (slots 19-25)
        int filledSlots = (int) (progress * 7);
        for (int i = 0; i < 7; i++) {
            int slot = 19 + i;
            if (i < filledSlots) {
                setItem(slot, createItem(Material.LIME_STAINED_GLASS_PANE,
                        mm().get("gui.level.xp-bar-filled", "{progress}", progressStr)));
            } else if (i == filledSlots) {
                setItem(slot, createItem(Material.YELLOW_STAINED_GLASS_PANE,
                        mm().get("gui.level.xp-bar-current", "{progress}", progressStr)));
            } else {
                setItem(slot, createItem(Material.RED_STAINED_GLASS_PANE,
                        mm().get("gui.level.xp-bar-empty", "{progress}", progressStr)));
            }
        }

        // Boost info
        double boostMulti = core.getBoostManager().getMultiplier("xp");
        Material boostIcon = boostMulti > 1.0 ? Material.BEACON : Material.GLASS;
        setItem(15, createItem(boostIcon,
                boostMulti > 1.0
                        ? mm().get("gui.level.boost-active")
                        : mm().get("gui.level.boost-none"),
                List.of(
                        "",
                        mm().get("gui.level.boost-multiplier", "{multiplier}", String.format("%.1fx", boostMulti)),
                        boostMulti > 1.0
                                ? mm().get("gui.level.boost-remaining", "{time}", core.getConfigManager().formatTime(core.getBoostManager().getRemainingMs("xp")))
                                : ""
                )
        ));

        // Navigation buttons
        setItem(29, createItem(Material.DIAMOND_SWORD,
                mm().get("gui.level.achievements-btn"),
                List.of("", mm().get("gui.level.achievements-desc"))));
        slotActions.put(29, "ACHIEVEMENTS");

        setItem(31, createItem(Material.WRITABLE_BOOK,
                mm().get("gui.level.missions-btn"),
                List.of("", mm().get("gui.level.missions-desc"))));
        slotActions.put(31, "MISSIONS");

        setItem(33, createItem(Material.GOLDEN_APPLE,
                mm().get("gui.level.battlepass-btn"),
                List.of("", mm().get("gui.level.battlepass-desc"))));
        slotActions.put(33, "BATTLEPASS");

        // Stats summary
        setItem(40, createItem(Material.PAPER,
                mm().get("gui.level.stats-name"),
                List.of(
                        "",
                        mm().get("gui.level.stats-kills", "{kills}", String.valueOf(profile.getKills())),
                        mm().get("gui.level.stats-deaths", "{deaths}", String.valueOf(profile.getDeaths())),
                        mm().get("gui.level.stats-kdr", "{kdr}", String.format("%.2f", profile.getKDR())),
                        mm().get("gui.level.stats-coins", "{coins}", String.format("%.0f", profile.getCoins())),
                        mm().get("gui.level.stats-achievements",
                                "{completed}", String.valueOf(progression.getAchievementManager().getCompletedCount(player.getUniqueId())),
                                "{total}", String.valueOf(progression.getAchievementManager().getTotalCount()))
                )
        ));

        // Back button
        setItem(49, createItem(Material.ARROW, mm().get("gui.level.close")));
        slotActions.put(49, "BACK");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        return switch (action) {
            case "PRESTIGE" -> {
                playSound("click");
                player.closeInventory();
                progression.getPrestigeManager().prestige(player);
                yield true;
            }
            case "ACHIEVEMENTS" -> {
                playSound("click");
                AchievementGui gui = new AchievementGui(core, progression, player);
                core.getGuiManager().registerGui(player, gui);
                gui.open();
                yield true;
            }
            case "MISSIONS" -> {
                playSound("click");
                MissionGui gui = new MissionGui(core, progression, player);
                core.getGuiManager().registerGui(player, gui);
                gui.open();
                yield true;
            }
            case "BATTLEPASS" -> {
                playSound("click");
                BattlePassGui gui = new BattlePassGui(core, progression, player);
                core.getGuiManager().registerGui(player, gui);
                gui.open();
                yield true;
            }
            case "BACK" -> {
                playSound("click");
                player.closeInventory();
                yield true;
            }
            default -> false;
        };
    }
}
