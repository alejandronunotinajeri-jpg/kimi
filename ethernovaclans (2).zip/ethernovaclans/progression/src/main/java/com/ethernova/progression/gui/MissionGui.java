package com.ethernova.progression.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.CoreGui;
import com.ethernova.progression.EthernovaProgression;
import com.ethernova.progression.mission.Mission;
import com.ethernova.progression.mission.MissionManager;
import com.ethernova.progression.mission.MissionType;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

/**
 * Shows active daily and weekly missions with their progress, streaks, and difficulty.
 * Faithfully recreates the original UltimateFFA missions GUI layout.
 */
public class MissionGui extends CoreGui {

    private final EthernovaProgression progression;

    public MissionGui(EthernovaCore core, EthernovaProgression progression, Player player) {
        super(core, player);
        this.progression = progression;
    }

    public void open() {
        MissionManager mm = progression.getMissionManager();
        String title = mm.getGuiTitle().replace("{player}", player.getName());
        openInventory(title, mm.getGuiSize());
    }

    @Override
    protected void populateItems() {
        UUID uuid = player.getUniqueId();
        MissionManager mm = progression.getMissionManager();

        // ═══════════════ Fill all empty slots with glass ═══════════════
        ItemStack fill = createItem(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < mm.getGuiSize(); i++) {
            setItem(i, fill);
        }

        // ═══════════════ Row 0: Daily Section Header ═══════════════
        List<Mission> dailyList = mm.getActiveMissions(uuid, MissionType.DAILY);
        long dailyCompleted = dailyList.stream().filter(Mission::isCompleted).count();

        // Yellow accent glass around daily header
        ItemStack yellowGlass = createItem(Material.YELLOW_STAINED_GLASS_PANE, "<yellow>━━━");
        setItem(mm.getInfoDailySlot() - 2, yellowGlass);
        setItem(mm.getInfoDailySlot() - 1, yellowGlass);
        setItem(mm.getInfoDailySlot() + 1, yellowGlass);
        setItem(mm.getInfoDailySlot() + 2, yellowGlass);

        setItem(mm.getInfoDailySlot(), createItem(Material.CLOCK,
                "<yellow><bold>⏰ MISIONES DIARIAS",
                List.of(
                        "",
                        "<gray>Se resetean cada <yellow>24 horas",
                        "",
                        "<gray>Completadas: <yellow>" + dailyCompleted + "<gray>/<yellow>" + dailyList.size(),
                        "",
                        "<dark_gray>Completa todas para ganar racha"
                )));

        // ═══════════════ Row 1: Daily Missions (centered) ═══════════════
        int[] dailySlots = mm.getDailySlots();
        for (int i = 0; i < dailySlots.length && i < dailyList.size(); i++) {
            Mission mission = dailyList.get(i);
            setItem(dailySlots[i], createMissionItem(mission, false));
        }

        // ═══════════════ Row 2: Streak (centered with separators) ═══════════════
        int streak = mm.getStreak(uuid);
        List<String> streakLore = new ArrayList<>();
        streakLore.add("");
        streakLore.add("<gray>Próximas recompensas:");
        streakLore.add("");

        Map<Integer, MissionManager.StreakMilestone> milestones = mm.getStreakMilestones();
        List<Integer> sortedDays = new ArrayList<>(milestones.keySet());
        Collections.sort(sortedDays);
        for (int days : sortedDays) {
            MissionManager.StreakMilestone sm = milestones.get(days);
            String check = streak >= days ? "<green>✓" : "<dark_gray>○";
            String money = sm.money > 0 ? " <gold>$" + String.format("%,d", sm.money) : "";
            String bonus = sm.bonusPercentage > 0 ? " <yellow>+" + sm.bonusPercentage + "%" : "";
            streakLore.add(check + " <yellow>" + days + " días:" + money + bonus);
        }
        streakLore.add("");
        streakLore.add("<gray>¡No pierdas tu racha!");

        setItem(mm.getStreakSlot(), createItem(Material.FIRE_CHARGE,
                "<gold><bold>🔥 RACHA: <white>" + streak + " días",
                streakLore));

        // Orange accent glass around streak
        ItemStack orangeGlass = createItem(Material.ORANGE_STAINED_GLASS_PANE, "<gold>━━━");
        setItem(mm.getStreakSlot() - 2, orangeGlass);
        setItem(mm.getStreakSlot() - 1, orangeGlass);
        setItem(mm.getStreakSlot() + 1, orangeGlass);
        setItem(mm.getStreakSlot() + 2, orangeGlass);

        // ═══════════════ Row 3: Weekly Section Header ═══════════════
        List<Mission> weeklyList = mm.getActiveMissions(uuid, MissionType.WEEKLY);
        long weeklyCompleted = weeklyList.stream().filter(Mission::isCompleted).count();

        // Magenta accent glass around weekly header
        ItemStack magentaGlass = createItem(Material.MAGENTA_STAINED_GLASS_PANE, "<light_purple>━━━");
        setItem(mm.getInfoWeeklySlot() - 2, magentaGlass);
        setItem(mm.getInfoWeeklySlot() - 1, magentaGlass);
        setItem(mm.getInfoWeeklySlot() + 1, magentaGlass);
        setItem(mm.getInfoWeeklySlot() + 2, magentaGlass);

        setItem(mm.getInfoWeeklySlot(), createItem(Material.COMPASS,
                "<light_purple><bold>📅 MISIONES SEMANALES",
                List.of(
                        "",
                        "<gray>Más difíciles, mejores premios",
                        "",
                        "<gray>Completadas: <light_purple>" + weeklyCompleted + "<gray>/<light_purple>" + weeklyList.size()
                )));

        // ═══════════════ Row 4: Weekly Missions (centered) ═══════════════
        int[] weeklySlots = mm.getWeeklySlots();
        for (int i = 0; i < weeklySlots.length && i < weeklyList.size(); i++) {
            Mission mission = weeklyList.get(i);
            setItem(weeklySlots[i], createMissionItem(mission, true));
        }

        // ═══════════════ Row 5: Close button ═══════════════
        setItem(mm.getCloseSlot(), createItem(Material.ARROW, "<red>← Volver"));
        slotActions.put(mm.getCloseSlot(), "BACK");
    }

    private ItemStack createMissionItem(Mission mission, boolean isWeekly) {
        // Determine icon using category
        MissionManager.CategoryData cat = progression.getMissionManager().getCategories().get(mission.category());
        Material material = cat != null ? cat.icon : mission.icon();

        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        // Title: status + difficulty/SEMANAL + name
        String statusSymbol = mission.isCompleted() ? "<green>✓ " : (isWeekly ? "<light_purple>● " : "<yellow>● ");
        String prefix = isWeekly ? "<light_purple><bold>SEMANAL</bold></light_purple>" : mission.difficultyDisplayName();
        meta.displayName(deserializeText(statusSymbol + prefix + " <dark_gray>» <white>" + mission.name()));

        // Progress bar
        double progressPercent = mission.getProgress();
        int barLen = 10;
        int filled = (int) (progressPercent * barLen);
        StringBuilder bar = new StringBuilder("<dark_gray>[");
        for (int i = 0; i < barLen; i++) bar.append(i < filled ? "<green>█" : "<gray>█");
        bar.append("<dark_gray>]");

        // Lore
        List<String> lore = new ArrayList<>();
        lore.add("");
        lore.add("<gray>" + mission.description());
        lore.add("");
        lore.add("<gray>Progreso: " + bar);
        lore.add("<yellow>" + mission.current() + "<gray>/<yellow>" + mission.goal()
                + " <dark_gray>(" + (int) (progressPercent * 100) + "%)");
        lore.add("");
        lore.add("<gold><bold>Recompensa:</bold></gold> <yellow>$" + String.format("%,d", mission.reward()));
        lore.add("");

        if (mission.isCompleted()) {
            lore.add("<green><bold>✓ ¡COMPLETADA!</bold></green>");
        } else {
            if (cat != null) {
                lore.add("<gray>Categoría: " + cat.displayName);
            }
        }

        meta.lore(lore.stream().map(this::deserializeText).toList());

        // Enchant glow for completed missions
        if (mission.isCompleted()) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }

        item.setItemMeta(meta);
        return item;
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if ("BACK".equals(action)) {
            playSound("click");
            player.closeInventory();
            return true;
        }
        return false;
    }
}
