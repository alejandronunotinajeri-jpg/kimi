package com.ethernova.progression.achievement;

import org.bukkit.Material;

/**
 * Categories for achievements.
 */
public enum AchievementCategory {

    COMBAT("Combate", Material.DIAMOND_SWORD),
    EXPLORATION("Exploración", Material.COMPASS),
    SOCIAL("Social", Material.PLAYER_HEAD),
    PROGRESSION("Progresión", Material.EXPERIENCE_BOTTLE),
    SPECIAL("Especial", Material.NETHER_STAR);

    private final String displayName;
    private final Material icon;

    AchievementCategory(String displayName, Material icon) {
        this.displayName = displayName;
        this.icon = icon;
    }

    public String getDisplayName() { return displayName; }
    public Material getIcon() { return icon; }
}
