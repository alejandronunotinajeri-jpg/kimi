package com.ethernova.progression.mission;

import org.bukkit.Material;

/**
 * Represents a generated mission instance assigned to a player.
 * Mirrors the original UltimateFFA Mission class with difficulty/category support.
 */
public class Mission {

    // ═══════════════ Type & Difficulty data ═══════════════

    private final String typeId;
    private final String typeName;
    private final String typeDescription;
    private final String category;
    private final Material icon;

    private final String difficultyId;
    private final String difficultyDisplayName;
    private final String difficultyColor;

    private final MissionType missionType; // DAILY or WEEKLY

    // ═══════════════ Generated values ═══════════════

    private final int goal;
    private final int reward;
    private int current;

    public Mission(String typeId, String typeName, String typeDescription, String category,
                   Material icon, String difficultyId, String difficultyDisplayName,
                   String difficultyColor, MissionType missionType, int goal, int reward) {
        this.typeId = typeId;
        this.typeName = typeName;
        this.typeDescription = typeDescription;
        this.category = category;
        this.icon = icon;
        this.difficultyId = difficultyId;
        this.difficultyDisplayName = difficultyDisplayName;
        this.difficultyColor = difficultyColor;
        this.missionType = missionType;
        this.goal = goal;
        this.reward = reward;
        this.current = 0;
    }

    // ═══════════════ Progress ═══════════════

    public boolean isCompleted() { return current >= goal; }

    public double getProgress() { return goal > 0 ? (double) current / goal : 0; }

    public void addProgress(int amount) { current = Math.min(current + amount, goal); }

    // ═══════════════ Accessors (compatible with old Mission record API) ═══════════════

    /** Unique ID = typeId (e.g. "KILLER"). Used for DB storage and lookup. */
    public String id() { return typeId; }

    public String name() { return typeName; }

    public String description() { return typeDescription.replace("{goal}", String.valueOf(goal)); }

    public String rawDescription() { return typeDescription; }

    public MissionType type() { return missionType; }

    public int target() { return goal; }

    public double coinReward() { return reward; }

    public long xpReward() { return (long) (reward * 0.5); } // XP = 50% of coin reward

    public String category() { return category; }

    public Material icon() { return icon; }

    public String difficultyId() { return difficultyId; }

    public String difficultyDisplayName() { return difficultyDisplayName; }

    public String difficultyColor() { return difficultyColor; }

    public int current() { return current; }

    public void setCurrent(int current) { this.current = current; }

    public int goal() { return goal; }

    public int reward() { return reward; }
}
