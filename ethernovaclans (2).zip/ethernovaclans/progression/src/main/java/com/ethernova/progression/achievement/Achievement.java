package com.ethernova.progression.achievement;

import org.bukkit.Material;

/**
 * Represents a single achievement definition.
 *
 * @param cosmeticReward nullable cosmetic ID to unlock on completion (e.g. "trail_fire", "aura_holy")
 */
public record Achievement(
        String id,
        String name,
        String description,
        Material icon,
        AchievementCategory category,
        int target,
        double coinReward,
        long xpReward,
        String cosmeticReward
) {
    /** Backwards-compatible constructor without cosmetic reward. */
    public Achievement(String id, String name, String description, Material icon,
                       AchievementCategory category, int target, double coinReward, long xpReward) {
        this(id, name, description, icon, category, target, coinReward, xpReward, null);
    }
}
