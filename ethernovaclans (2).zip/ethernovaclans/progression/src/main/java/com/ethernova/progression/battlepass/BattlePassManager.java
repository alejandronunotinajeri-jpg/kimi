package com.ethernova.progression.battlepass;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.profile.PlayerProfile;
import com.ethernova.core.storage.MigrationManager;
import com.ethernova.progression.EthernovaProgression;
import com.ethernova.progression.message.MessageManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Season-based battle pass with 50 tiers, free and premium tracks.
 * XP-based progression. Data stored in ethernova_battlepass table.
 */
public class BattlePassManager {

    private final EthernovaProgression plugin;
    private final EthernovaCore core;
    private final MiniMessage mini = MiniMessage.miniMessage();

    private MessageManager mm() { return plugin.getMessageManager(); }

    /** Tier definitions. */
    private final List<BattlePassTier> tiers = new ArrayList<>();

    /** Player UUID -> current BP XP. */
    private final Map<UUID, Long> playerXP = new ConcurrentHashMap<>();

    /** Player UUID -> premium flag. */
    private final Map<UUID, Boolean> premiumPlayers = new ConcurrentHashMap<>();

    /** Player UUID -> set of claimed tier numbers. */
    private final Map<UUID, Set<Integer>> claimedFreeRewards = new ConcurrentHashMap<>();
    private final Map<UUID, Set<Integer>> claimedPremiumRewards = new ConcurrentHashMap<>();

    private String seasonName;
    private int seasonNumber;

    public BattlePassManager(EthernovaProgression plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
        runMigrations();
        loadConfig();
        generateTiers();
    }

    private void runMigrations() {
        new MigrationManager(core.getStorageManager(), plugin.getLogger(), "ethernova_battlepass")
                .addMigration(1,
                        """
                        CREATE TABLE IF NOT EXISTS ethernova_battlepass (
                            uuid VARCHAR(36) NOT NULL,
                            season INT NOT NULL,
                            xp BIGINT DEFAULT 0,
                            premium INTEGER DEFAULT 0,
                            claimed_free TEXT DEFAULT '',
                            claimed_premium TEXT DEFAULT '',
                            PRIMARY KEY (uuid, season)
                        )
                        """)
                .migrate();
    }

    private void loadConfig() {
        var config = plugin.getProgressionConfig().getConfig();
        seasonName = config.getString("battlepass.season-name", "Temporada Eclipse");
        seasonNumber = config.getInt("battlepass.season-number", 1);
    }

    private void generateTiers() {
        tiers.clear();
        var config = plugin.getProgressionConfig().getConfig();

        for (int i = 1; i <= 50; i++) {
            double xpRequired = config.getDouble("battlepass.base-xp-per-tier", 500) * i *
                    (1.0 + (i - 1) * config.getDouble("battlepass.tier-scaling", 0.05));

            String freeReward;
            String premiumReward;

            if (i % 10 == 0) {
                // Milestone tiers
                freeReward = "coins:" + (500 * (i / 10));
                premiumReward = "cosmetic:bp_s" + seasonNumber + "_tier" + i;
            } else if (i % 5 == 0) {
                // Every 5 tiers
                freeReward = "coins:" + (200 * (i / 5));
                premiumReward = "title:bp_s" + seasonNumber + "_t" + i;
            } else {
                // Regular tiers
                freeReward = "coins:" + (50 + i * 10);
                premiumReward = "coins:" + (100 + i * 20);
            }

            // Config overrides if present
            String configFree = config.getString("battlepass.tiers." + i + ".free-reward");
            String configPremium = config.getString("battlepass.tiers." + i + ".premium-reward");
            if (configFree != null) freeReward = configFree;
            if (configPremium != null) premiumReward = configPremium;

            tiers.add(new BattlePassTier(i, xpRequired, freeReward, premiumReward));
        }
    }

    /**
     * Load battle pass data for a player.
     */
    public void loadPlayer(UUID uuid) {
        try (Connection conn = core.getStorageManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT xp, premium, claimed_free, claimed_premium FROM ethernova_battlepass WHERE uuid = ? AND season = ?")) {
            ps.setString(1, uuid.toString());
            ps.setInt(2, seasonNumber);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    playerXP.put(uuid, rs.getLong("xp"));
                    premiumPlayers.put(uuid, rs.getBoolean("premium"));
                    claimedFreeRewards.put(uuid, parseTierSet(rs.getString("claimed_free")));
                    claimedPremiumRewards.put(uuid, parseTierSet(rs.getString("claimed_premium")));
                } else {
                    // New entry
                    playerXP.put(uuid, 0L);
                    premiumPlayers.put(uuid, false);
                    claimedFreeRewards.put(uuid, ConcurrentHashMap.newKeySet());
                    claimedPremiumRewards.put(uuid, ConcurrentHashMap.newKeySet());
                }
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error loading battle pass for " + uuid, e);
            playerXP.put(uuid, 0L);
            premiumPlayers.put(uuid, false);
            claimedFreeRewards.put(uuid, ConcurrentHashMap.newKeySet());
            claimedPremiumRewards.put(uuid, ConcurrentHashMap.newKeySet());
        }
    }

    public void unloadPlayer(UUID uuid) {
        savePlayer(uuid);
        playerXP.remove(uuid);
        premiumPlayers.remove(uuid);
        claimedFreeRewards.remove(uuid);
        claimedPremiumRewards.remove(uuid);
    }

    /**
     * Save battle pass data for a player (async).
     */
    public void savePlayer(UUID uuid) {
        long xp = playerXP.getOrDefault(uuid, 0L);
        boolean premium = premiumPlayers.getOrDefault(uuid, false);
        String claimedFree = serializeTierSet(claimedFreeRewards.get(uuid));
        String claimedPremium = serializeTierSet(claimedPremiumRewards.get(uuid));

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () ->
                doSavePlayer(uuid, xp, premium, claimedFree, claimedPremium));
    }

    /**
     * Save battle pass data synchronously (for use during onDisable).
     */
    public void savePlayerSync(UUID uuid) {
        long xp = playerXP.getOrDefault(uuid, 0L);
        boolean premium = premiumPlayers.getOrDefault(uuid, false);
        String claimedFree = serializeTierSet(claimedFreeRewards.get(uuid));
        String claimedPremium = serializeTierSet(claimedPremiumRewards.get(uuid));
        doSavePlayer(uuid, xp, premium, claimedFree, claimedPremium);
    }

    private void doSavePlayer(UUID uuid, long xp, boolean premium, String claimedFree, String claimedPremium) {
        String sql = core.getStorageManager().isMySQL()
                ? "INSERT INTO ethernova_battlepass (uuid, season, xp, premium, claimed_free, claimed_premium) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE xp=VALUES(xp), premium=VALUES(premium), claimed_free=VALUES(claimed_free), claimed_premium=VALUES(claimed_premium)"
                : "INSERT INTO ethernova_battlepass (uuid, season, xp, premium, claimed_free, claimed_premium) VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT(uuid, season) DO UPDATE SET xp=excluded.xp, premium=excluded.premium, claimed_free=excluded.claimed_free, claimed_premium=excluded.claimed_premium";

        try (Connection conn = core.getStorageManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.setInt(2, seasonNumber);
            ps.setLong(3, xp);
            ps.setBoolean(4, premium);
            ps.setString(5, claimedFree);
            ps.setString(6, claimedPremium);
            ps.executeUpdate();
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error saving battle pass for " + uuid, e);
        }
    }

    /**
     * Get the current tier for a player (1-based, 0 means not started).
     */
    public int getTier(UUID uuid) {
        long xp = playerXP.getOrDefault(uuid, 0L);
        int tier = 0;
        double totalXP = 0;

        for (BattlePassTier t : tiers) {
            totalXP += t.xpRequired();
            if (xp >= totalXP) {
                tier = t.tier();
            } else {
                break;
            }
        }
        return tier;
    }

    /**
     * Get the total XP accumulated by a player.
     */
    public long getXP(UUID uuid) {
        return playerXP.getOrDefault(uuid, 0L);
    }

    /**
     * Add XP to a player's battle pass.
     */
    public void addXP(Player player, long amount) {
        if (amount <= 0) return;
        UUID uuid = player.getUniqueId();
        int oldTier = getTier(uuid);

        playerXP.merge(uuid, amount, Long::sum);

        int newTier = getTier(uuid);

        if (newTier > oldTier) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (!player.isOnline()) return;
                core.getSoundManager().play(player, "reward");
                mm().sendMessage(player, "battlepass.tier-up",
                        "{tier}", String.valueOf(newTier),
                        "{season}", seasonName);
            });
        }

        // Auto-save periodically - save is triggered on unload
    }

    /**
     * Claim a free reward for a tier.
     * @return the reward string, or null if already claimed or not unlocked
     */
    public String claimFreeReward(Player player, int tier) {
        UUID uuid = player.getUniqueId();
        if (tier < 1 || tier > tiers.size()) return null;
        if (getTier(uuid) < tier) return null;

        Set<Integer> claimed = claimedFreeRewards.computeIfAbsent(uuid, k -> ConcurrentHashMap.newKeySet());
        if (!claimed.add(tier)) return null;

        BattlePassTier bpTier = tiers.get(tier - 1);
        grantReward(player, bpTier.freeReward());
        savePlayer(uuid);
        return bpTier.freeReward();
    }

    /**
     * Claim a premium reward for a tier.
     * @return the reward string, or null if not premium, already claimed, or not unlocked
     */
    public String claimPremiumReward(Player player, int tier) {
        UUID uuid = player.getUniqueId();
        if (!isPremium(uuid)) return null;
        if (tier < 1 || tier > tiers.size()) return null;
        if (getTier(uuid) < tier) return null;

        Set<Integer> claimed = claimedPremiumRewards.computeIfAbsent(uuid, k -> ConcurrentHashMap.newKeySet());
        if (!claimed.add(tier)) return null;

        BattlePassTier bpTier = tiers.get(tier - 1);
        grantReward(player, bpTier.premiumReward());
        savePlayer(uuid);
        return bpTier.premiumReward();
    }

    private void grantReward(Player player, String reward) {
        if (reward == null || reward.isEmpty()) return;

        String[] parts = reward.split(":", 2);
        String type = parts[0];
        String value = parts.length > 1 ? parts[1] : "";

        PlayerProfile profile = core.getProfileManager().getProfile(player.getUniqueId());
        if (profile == null) return;

        switch (type) {
            case "coins" -> {
                try {
                    double coins = Double.parseDouble(value);
                    profile.addCoins(coins);
                    mm().sendMessage(player, "battlepass.reward-coins",
                            "{amount}", String.valueOf((int) coins));
                } catch (NumberFormatException ignored) {}
            }
            case "cosmetic" -> {
                // Store cosmetic unlock in profile custom data
                profile.setCustom("bp_cosmetic_" + value, "true");
                mm().sendMessage(player, "battlepass.reward-cosmetic",
                        "{name}", value);
            }
            case "title" -> {
                profile.setCustom("bp_title_" + value, "true");
                mm().sendMessage(player, "battlepass.reward-title",
                        "{name}", value);
            }
        }

        core.getSoundManager().play(player, "reward");
    }

    public boolean isPremium(UUID uuid) {
        return premiumPlayers.getOrDefault(uuid, false);
    }

    public void setPremium(UUID uuid, boolean premium) {
        premiumPlayers.put(uuid, premium);
        savePlayer(uuid);
    }

    public boolean hasClaimedFreeReward(UUID uuid, int tier) {
        Set<Integer> claimed = claimedFreeRewards.get(uuid);
        return claimed != null && claimed.contains(tier);
    }

    public boolean hasClaimedPremiumReward(UUID uuid, int tier) {
        Set<Integer> claimed = claimedPremiumRewards.get(uuid);
        return claimed != null && claimed.contains(tier);
    }

    /**
     * Get XP progress within the current tier (0.0 - 1.0).
     */
    public double getTierProgress(UUID uuid) {
        long xp = playerXP.getOrDefault(uuid, 0L);
        double totalXP = 0;

        for (BattlePassTier t : tiers) {
            if (xp < totalXP + t.xpRequired()) {
                double inTier = xp - totalXP;
                return Math.max(0.0, Math.min(1.0, inTier / t.xpRequired()));
            }
            totalXP += t.xpRequired();
        }
        return 1.0; // maxed out
    }

    public List<BattlePassTier> getTiers() { return Collections.unmodifiableList(tiers); }
    public String getSeasonName() { return seasonName; }
    public int getSeasonNumber() { return seasonNumber; }

    private Set<Integer> parseTierSet(String data) {
        Set<Integer> set = ConcurrentHashMap.newKeySet();
        if (data == null || data.isBlank()) return set;
        for (String s : data.split(",")) {
            try {
                set.add(Integer.parseInt(s.trim()));
            } catch (NumberFormatException ignored) {}
        }
        return set;
    }

    private String serializeTierSet(Set<Integer> set) {
        if (set == null || set.isEmpty()) return "";
        return String.join(",", set.stream().sorted().map(String::valueOf).toList());
    }
}
