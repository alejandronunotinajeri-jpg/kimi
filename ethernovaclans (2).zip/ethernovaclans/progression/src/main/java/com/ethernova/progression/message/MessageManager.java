package com.ethernova.progression.message;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Manages multi-language messages for EthernovaProgression.
 * Loads messages from YAML language files (messages_es.yml, messages_en.yml, etc.)
 * with placeholder replacement and MiniMessage parsing.
 */
public class MessageManager {

    private final JavaPlugin plugin;
    private final MiniMessage mini = MiniMessage.miniMessage();
    private YamlConfiguration messages;
    private String prefix;
    private final Map<String, String> cache = new ConcurrentHashMap<>();

    public MessageManager(JavaPlugin plugin) {
        this.plugin = plugin;
        load();
    }

    /**
     * Load or reload message files. Saves all bundled defaults, then loads
     * the language selected in config.yml (general.language, default "es").
     */
    public void load() {
        cache.clear();

        // Save all bundled language files
        for (String lang : new String[]{"es", "en"}) {
            saveDefault("messages_" + lang + ".yml");
        }

        String lang = plugin.getConfig().getString("general.language", "es");
        String fileName = "messages_" + lang + ".yml";
        File file = new File(plugin.getDataFolder(), fileName);
        if (!file.exists()) {
            fileName = "messages_es.yml";
            file = new File(plugin.getDataFolder(), fileName);
        }

        messages = YamlConfiguration.loadConfiguration(file);
        try (InputStream def = plugin.getResource(fileName)) {
            if (def != null) {
                messages.setDefaults(YamlConfiguration.loadConfiguration(
                        new InputStreamReader(def, StandardCharsets.UTF_8)));
            }
        } catch (java.io.IOException ignored) {}

        prefix = messages.getString("general.prefix",
                "<gradient:#00d2ff:#3a7bd5>✦ Progresión</gradient> <dark_gray>»</dark_gray> ");
    }

    /**
     * Get a raw message string with placeholder replacements applied.
     * Replacements are pairs: "{key}", "value", "{key2}", "value2", ...
     */
    public String get(String path, String... replacements) {
        String raw = cache.computeIfAbsent(path, p -> {
            String val = messages.getString(p);
            return val != null ? val : "<red>[Missing: " + p + "]</red>";
        });
        raw = raw.replace("{prefix}", prefix);
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            raw = raw.replace(replacements[i], replacements[i + 1]);
        }
        return raw;
    }

    /**
     * Parse a MiniMessage string into a Component.
     */
    public Component parse(String miniMsg) {
        return mini.deserialize(miniMsg);
    }

    /**
     * Get a message, apply replacements, parse to Component, and send to a CommandSender.
     */
    public void sendMessage(CommandSender sender, String path, String... replacements) {
        sender.sendMessage(mini.deserialize(get(path, replacements)));
    }

    /**
     * Send a raw MiniMessage string (with prefix replacement) to a sender.
     */
    public void sendRaw(CommandSender sender, String miniMsg) {
        sender.sendMessage(mini.deserialize(miniMsg.replace("{prefix}", prefix)));
    }

    /**
     * Get the configured prefix.
     */
    public String getPrefix() {
        return prefix;
    }

    private void saveDefault(String name) {
        File f = new File(plugin.getDataFolder(), name);
        if (!f.exists()) {
            f.getParentFile().mkdirs();
            try {
                plugin.saveResource(name, false);
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Could not save default resource " + name, e);
            }
        }
    }
}
