package com.ethernova.progression;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.service.ServiceRegistry;
import com.ethernova.progression.achievement.AchievementManager;
import com.ethernova.progression.api.ProgressionAPI;
import com.ethernova.progression.api.ProgressionAPIImpl;
import com.ethernova.progression.battlepass.BattlePassManager;
import com.ethernova.progression.command.ProgressionCommand;
import com.ethernova.progression.config.ProgressionConfigManager;
import com.ethernova.progression.daily.DailyRewardManager;
import com.ethernova.progression.level.LevelManager;
import com.ethernova.progression.listener.ProgressionListener;
import com.ethernova.progression.message.MessageManager;
import com.ethernova.progression.mission.MissionManager;
import com.ethernova.progression.placeholder.ProgressionPlaceholders;
import com.ethernova.progression.prestige.PrestigeManager;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.UUID;

import java.util.logging.Level;

/**
 * Main plugin class for EthernovaProgression.
 * Manages leveling, prestige, achievements, missions, and battle pass systems.
 */
public class EthernovaProgression extends JavaPlugin {

    private static volatile EthernovaProgression instance;

    private EthernovaCore core;
    private ProgressionConfigManager configManager;
    private MessageManager messageManager;
    private LevelManager levelManager;
    private PrestigeManager prestigeManager;
    private AchievementManager achievementManager;
    private MissionManager missionManager;
    private BattlePassManager battlePassManager;
    private DailyRewardManager dailyRewardManager;
    private ProgressionListener progressionListener;
    private BukkitTask playtimeTask;
    private BukkitTask aliveTimeTask;
    private BukkitTask autoSaveTask;

    @Override
    public void onEnable() {
        instance = this;
        long start = System.currentTimeMillis();

        getLogger().info("═══════════════════════════════════════════");
        getLogger().info("  EthernovaProgression v" + getDescription().getVersion());
        getLogger().info("═══════════════════════════════════════════");

        try {
            // Phase 1: Core dependency
            core = (EthernovaCore) Bukkit.getPluginManager().getPlugin("EthernovaCore");
            if (core == null) {
                getLogger().severe("EthernovaCore no encontrado! Deshabilitando...");
                Bukkit.getPluginManager().disablePlugin(this);
                return;
            }
            core.registerPlugin("EthernovaProgression");

            // Phase 2: Configuration
            configManager = new ProgressionConfigManager(this);
            configManager.loadAll();

            // Phase 2.5: Message manager (i18n)
            messageManager = new MessageManager(this);

            // Phase 3: Level manager (needed by prestige)
            levelManager = new LevelManager(this, core);

            // Phase 4: Prestige manager (needed by level for multiplier)
            prestigeManager = new PrestigeManager(this, core);

            // Phase 5: Achievement manager (creates DB tables)
            achievementManager = new AchievementManager(this, core);

            // Phase 6: Mission manager (creates DB tables)
            missionManager = new MissionManager(this, core);

            // Phase 7: Battle pass manager (creates DB tables)
            battlePassManager = new BattlePassManager(this, core);

            // Phase 7.5: Daily reward manager
            dailyRewardManager = new DailyRewardManager(this, core);

            // Phase 8: Listener (registers EventBus + Bukkit listeners)
            progressionListener = new ProgressionListener(this, core);
            Bukkit.getPluginManager().registerEvents(progressionListener, this);

            // Phase 9: Commands
            registerCommands();

            // Phase 10: PlaceholderAPI
            if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
                new ProgressionPlaceholders(this, core).register();
                getLogger().info("PlaceholderAPI expansion registrada");
            }

            // Phase 11: Timer tasks
            startTimerTasks();

            // Phase 12: Load data for already-online players (for /reload support)
            for (var player : Bukkit.getOnlinePlayers()) {
                Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
                    achievementManager.loadPlayer(player.getUniqueId());
                    missionManager.loadPlayer(player.getUniqueId());
                    battlePassManager.loadPlayer(player.getUniqueId());
                    dailyRewardManager.loadPlayer(player.getUniqueId());
                });
            }

            // Phase 13: Public API
            ServiceRegistry.register(ProgressionAPI.class, new ProgressionAPIImpl(this));
            getLogger().info("✔ ProgressionAPI registrada en ServiceRegistry");

            long elapsed = System.currentTimeMillis() - start;
            getLogger().info("═══════════════════════════════════════════");
            getLogger().info("  EthernovaProgression habilitado en " + elapsed + "ms");
            getLogger().info("  Logros: " + achievementManager.getTotalCount());
            getLogger().info("  Nivel máximo: " + levelManager.getMaxLevel());
            getLogger().info("═══════════════════════════════════════════");

        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Error habilitando EthernovaProgression", e);
            Bukkit.getPluginManager().disablePlugin(this);
        }
    }

    @Override
    public void onDisable() {
        // Cancel tasks
        if (playtimeTask != null) playtimeTask.cancel();
        if (aliveTimeTask != null) aliveTimeTask.cancel();
        if (autoSaveTask != null) autoSaveTask.cancel();

        // Save all online players synchronously (async tasks may not run during shutdown)
        for (var player : Bukkit.getOnlinePlayers()) {
            UUID uuid = player.getUniqueId();
            if (battlePassManager != null) battlePassManager.savePlayerSync(uuid);
            if (missionManager != null) missionManager.savePlayerSync(uuid);
            if (achievementManager != null) achievementManager.savePlayerSync(uuid);
        }

        // Unregister API
        ServiceRegistry.unregister(ProgressionAPI.class);

        // Unregister from core
        if (core != null) {
            core.unregisterPlugin("EthernovaProgression");
        }

        instance = null;
        getLogger().info("EthernovaProgression deshabilitado");
    }

    private void registerCommands() {
        ProgressionCommand handler = new ProgressionCommand(this, core);

        String[] commands = {"level", "prestige", "achievements", "missions", "battlepass", "daily"};
        for (String cmd : commands) {
            var command = getCommand(cmd);
            if (command != null) {
                command.setExecutor(handler);
                command.setTabCompleter(handler);
            }
        }
    }

    private void startTimerTasks() {
        // Playtime XP: every 60 seconds (1200 ticks)
        int playtimeInterval = configManager.getInt("timers.playtime-xp-interval", 60) * 20;
        playtimeTask = Bukkit.getScheduler().runTaskTimer(this,
                () -> progressionListener.processPlaytimeXP(),
                playtimeInterval, playtimeInterval);

        // Alive time tracking: every 5 minutes
        aliveTimeTask = Bukkit.getScheduler().runTaskTimer(this,
                () -> progressionListener.processAliveTime(),
                6000L, 6000L);

        // Auto-save battle pass data: every 5 minutes
        // Collect players on main thread, then save async
        autoSaveTask = Bukkit.getScheduler().runTaskTimer(this, () -> {
            java.util.List<java.util.UUID> uuids = new java.util.ArrayList<>();
            for (var player : Bukkit.getOnlinePlayers()) {
                uuids.add(player.getUniqueId());
            }
            Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
                for (java.util.UUID uuid : uuids) {
                    battlePassManager.savePlayer(uuid);
                }
            });
        }, 6000L, 6000L);
    }

    // --- Getters ---
    public static EthernovaProgression getInstance() { return instance; }
    public EthernovaCore getCore() { return core; }
    public ProgressionConfigManager getProgressionConfig() { return configManager; }
    public MessageManager getMessageManager() { return messageManager; }
    public LevelManager getLevelManager() { return levelManager; }
    public PrestigeManager getPrestigeManager() { return prestigeManager; }
    public AchievementManager getAchievementManager() { return achievementManager; }
    public MissionManager getMissionManager() { return missionManager; }
    public BattlePassManager getBattlePassManager() { return battlePassManager; }
    public DailyRewardManager getDailyRewardManager() { return dailyRewardManager; }
}
