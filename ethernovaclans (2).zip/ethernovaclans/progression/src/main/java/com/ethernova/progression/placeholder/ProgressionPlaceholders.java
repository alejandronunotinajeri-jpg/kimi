package com.ethernova.progression.placeholder;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.profile.PlayerProfile;
import com.ethernova.progression.EthernovaProgression;
import com.ethernova.progression.message.MessageManager;
import com.ethernova.progression.mission.MissionType;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * PlaceholderAPI expansion for EthernovaProgression.
 * Placeholders:
 *   %progression_level%
 *   %progression_xp%
 *   %progression_prestige%
 *   %progression_next_level_xp%
 *   %progression_progress%
 *   %progression_daily_missions%
 *   %progression_weekly_missions%
 *   %progression_bp_tier%
 *   %progression_bp_season%
 *   %progression_bp_premium%
 *   %progression_bp_xp%
 *   %progression_bp_progress%
 *   %progression_prestige_display%
 *   %progression_prestige_multiplier%
 *   %progression_prestige_max%
 *   %progression_achievements%
 *   %progression_achievements_total%
 *   %progression_max_level%
 *   %progression_playtime_formatted%
 */
public class ProgressionPlaceholders extends PlaceholderExpansion {

    private final EthernovaProgression plugin;
    private final EthernovaCore core;

    public ProgressionPlaceholders(EthernovaProgression plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
    }

    private MessageManager mm() { return plugin.getMessageManager(); }

    @Override
    public @NotNull String getIdentifier() {
        return "progression";
    }

    @Override
    public @NotNull String getAuthor() {
        return "Ethernova";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public @Nullable String onRequest(OfflinePlayer offlinePlayer, @NotNull String params) {
        if (offlinePlayer == null) return "";
        UUID uuid = offlinePlayer.getUniqueId();

        PlayerProfile profile = core.getProfileManager().getProfile(uuid);
        if (profile == null) return "";

        return switch (params.toLowerCase()) {
            case "level" -> String.valueOf(profile.getLevel());

            case "xp" -> String.format("%,d", profile.getXP());

            case "prestige" -> String.valueOf(profile.getPrestige());

            case "prestige_display" -> plugin.getPrestigeManager().getPrestigeDisplay(profile.getPrestige());

            case "prestige_multiplier" -> String.format("%.2f", plugin.getPrestigeManager().getMultiplier(profile.getPrestige()));

            case "prestige_max" -> String.valueOf(plugin.getProgressionConfig().getInt("prestige.max-prestige", 5));

            case "next_level_xp" -> String.format("%,d", plugin.getLevelManager().getXPForNextLevel(profile));

            case "progress" -> String.format("%.1f%%", plugin.getLevelManager().getProgress(profile) * 100);

            case "daily_missions" -> String.valueOf(
                    plugin.getMissionManager().getCompletedDailyCount(uuid));

            case "daily_streak" -> String.valueOf(
                    plugin.getMissionManager().getStreak(uuid));

            case "weekly_missions" -> {
                long weeklyActive = plugin.getMissionManager().getActiveMissions(uuid, MissionType.WEEKLY).size();
                long weeklyCompleted = plugin.getMissionManager().getActiveMissions(uuid, MissionType.WEEKLY).stream()
                        .filter(m -> plugin.getMissionManager().isCompleted(uuid, m.id()))
                        .count();
                yield weeklyCompleted + "/" + weeklyActive;
            }

            case "bp_tier" -> String.valueOf(
                    plugin.getBattlePassManager().getTier(uuid));

            case "bp_season" -> plugin.getBattlePassManager().getSeasonName();

            case "bp_premium" -> plugin.getBattlePassManager().isPremium(uuid)
                    ? mm().get("placeholder.yes") : mm().get("placeholder.no");

            case "bp_xp" -> String.format("%,d", plugin.getBattlePassManager().getXP(uuid));

            case "bp_progress" -> String.format("%.1f%%", plugin.getBattlePassManager().getTierProgress(uuid) * 100);

            case "achievements" -> String.valueOf(
                    plugin.getAchievementManager().getCompletedCount(uuid));

            case "achievements_total" -> String.valueOf(
                    plugin.getAchievementManager().getTotalCount());

            case "max_level" -> String.valueOf(plugin.getLevelManager().getMaxLevel());

            case "playtime_formatted" -> {
                long totalSeconds = profile.getPlayTime() / 1000;
                long hours = totalSeconds / 3600;
                long mins = (totalSeconds % 3600) / 60;
                yield hours + "h " + mins + "m";
            }

            default -> null;
        };
    }
}
