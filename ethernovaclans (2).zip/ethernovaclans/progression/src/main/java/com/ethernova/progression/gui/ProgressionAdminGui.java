package com.ethernova.progression.gui;

import com.ethernova.core.gui.CoreGui;
import com.ethernova.progression.EthernovaProgression;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/**
 * Admin GUI for EthernovaProgression — full in-game configuration.
 * Permission: progression.admin
 */
public class ProgressionAdminGui extends CoreGui {

    private final EthernovaProgression plugin;
    private int page = 0;
    private static final int MAX_PAGES = 2;

    public ProgressionAdminGui(EthernovaProgression plugin, Player player) {
        super(plugin.getCore(), player);
        this.plugin = plugin;
    }

    public void open() {
        openInventory("<gradient:#11998E:#38EF7D>⚙ Progression Admin</gradient> <gray>(Pág. " + (page + 1) + "/" + MAX_PAGES + ")", 54);
    }

    @Override
    protected void populateItems() {
        // ── Back ──
        setItem(48, createItem(Material.ARROW, "<gray>← Volver"));
        slotActions.put(48, "BACK");

        if (page == 0) populatePage1();
        else populatePage2();

        // ═══ Navigation ═══
        if (page > 0) {
            setItem(45, createItem(Material.ARROW, "<yellow>← Página Anterior"));
            slotActions.put(45, "PREV_PAGE");
        }
        if (page < MAX_PAGES - 1) {
            setItem(53, createItem(Material.ARROW, "<yellow>Página Siguiente →"));
            slotActions.put(53, "NEXT_PAGE");
        }

        setItem(49, createItem(Material.COMMAND_BLOCK,
                "<green>⟳ Recargar Config", List.of("<gray>Recarga config.yml y mensajes")));
        slotActions.put(49, "RELOAD");
    }

    private void populatePage1() {
        setItem(4, createItem(Material.EXPERIENCE_BOTTLE,
                "<gold><bold>⚙ Progression Config",
                List.of("<gray>Página 1: Niveles, Prestige y Misiones")));

        // ═══ Row 1: Leveling ═══
        setItem(10, createItem(Material.GREEN_STAINED_GLASS_PANE, "<green><bold>Leveling"));

        setItem(11, numberItem(Material.DIAMOND, "Nivel Máximo", "leveling.max-level", ""));
        slotActions.put(11, "INT:leveling.max-level:1:1000");

        setItem(12, toggleItem("Broadcast Level Up", "leveling.broadcast-level-up"));
        slotActions.put(12, "TOGGLE:leveling.broadcast-level-up");

        setItem(13, numberItem(Material.BELL, "Broadcast Interval", "leveling.broadcast-interval", "niveles"));
        slotActions.put(13, "INT:leveling.broadcast-interval:1:50");

        // ═══ Row 1 continued: Prestige ═══
        setItem(15, createItem(Material.YELLOW_STAINED_GLASS_PANE, "<yellow><bold>Prestige"));

        setItem(16, numberItem(Material.NETHER_STAR, "Max Prestige", "prestige.max-prestige", ""));
        slotActions.put(16, "INT:prestige.max-prestige:0:100");

        // ═══ Row 2: Missions ═══
        setItem(19, createItem(Material.CYAN_STAINED_GLASS_PANE, "<aqua><bold>Misiones"));

        setItem(20, numberItem(Material.MAP, "Misiones Diarias", "missions.daily-count", ""));
        slotActions.put(20, "INT:missions.daily-count:0:20");

        setItem(21, numberItem(Material.FILLED_MAP, "Misiones Semanales", "missions.weekly-count", ""));
        slotActions.put(21, "INT:missions.weekly-count:0:20");

        // ═══ Row 2 continued: Battle Pass ═══
        setItem(23, createItem(Material.MAGENTA_STAINED_GLASS_PANE, "<light_purple><bold>Battle Pass"));

        setItem(24, numberItem(Material.GOLD_INGOT, "Season Number", "battlepass.season-number", ""));
        slotActions.put(24, "INT:battlepass.season-number:1:100");

        setItem(25, numberItem(Material.EXPERIENCE_BOTTLE, "Base XP/Tier", "battlepass.base-xp-per-tier", "XP"));
        slotActions.put(25, "INT:battlepass.base-xp-per-tier:100:10000");

        // ═══ Row 3: Battle Pass continued + Timers ═══
        setItem(28, doubleItem(Material.REPEATER, "Tier Scaling", "battlepass.tier-scaling", ""));
        slotActions.put(28, "DOUBLE:battlepass.tier-scaling:0.0:1.0");

        setItem(30, createItem(Material.RED_STAINED_GLASS_PANE, "<red><bold>Timers"));

        setItem(31, numberItem(Material.CLOCK, "Playtime XP", "timers.playtime-xp-interval", "seg"));
        slotActions.put(31, "INT:timers.playtime-xp-interval:10:600");

        // ═══ Row 3 continued: Language ═══
        setItem(33, createItem(Material.WRITABLE_BOOK,
                "<yellow>Idioma: <white>" + plugin.getConfig().getString("general.language", "es"),
                List.of("<yellow>Click para cambiar")));
        slotActions.put(33, "CYCLE_LANG");
    }

    private void populatePage2() {
        setItem(4, createItem(Material.EXPERIENCE_BOTTLE,
                "<gold><bold>⚙ Progression Config",
                List.of("<gray>Página 2: Multiplicadores XP")));

        // ═══ Row 1: XP Multipliers ═══
        setItem(10, createItem(Material.ORANGE_STAINED_GLASS_PANE, "<gold><bold>Multiplicadores XP"));

        setItem(11, doubleItem(Material.IRON_SWORD, "Kill XP", "xp-multipliers.kill", "x"));
        slotActions.put(11, "DOUBLE:xp-multipliers.kill:0.0:10.0");

        setItem(12, doubleItem(Material.SHIELD, "Death Avoided XP", "xp-multipliers.death-avoided", "x"));
        slotActions.put(12, "DOUBLE:xp-multipliers.death-avoided:0.0:10.0");

        setItem(13, doubleItem(Material.CLOCK, "Playtime XP", "xp-multipliers.playtime", "x"));
        slotActions.put(13, "DOUBLE:xp-multipliers.playtime:0.0:10.0");

        setItem(14, doubleItem(Material.DIAMOND_PICKAXE, "Mining XP", "xp-multipliers.mining", "x"));
        slotActions.put(14, "DOUBLE:xp-multipliers.mining:0.0:10.0");

        setItem(15, doubleItem(Material.WRITABLE_BOOK, "Quest XP", "xp-multipliers.quest", "x"));
        slotActions.put(15, "DOUBLE:xp-multipliers.quest:0.0:10.0");

        setItem(16, doubleItem(Material.GOLD_INGOT, "Achievement XP", "xp-multipliers.achievement", "x"));
        slotActions.put(16, "DOUBLE:xp-multipliers.achievement:0.0:10.0");

        // ═══ Row 2: More multipliers ═══
        setItem(20, doubleItem(Material.EMERALD, "Vote XP", "xp-multipliers.vote", "x"));
        slotActions.put(20, "DOUBLE:xp-multipliers.vote:0.0:10.0");

        setItem(21, doubleItem(Material.COMMAND_BLOCK, "Admin XP", "xp-multipliers.admin", "x"));
        slotActions.put(21, "DOUBLE:xp-multipliers.admin:0.0:10.0");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.startsWith("TOGGLE:")) {
            String path = action.substring(7);
            plugin.getConfig().set(path, !plugin.getConfig().getBoolean(path, false));
            plugin.saveConfig();
            refresh();
            return true;
        }
        if (action.startsWith("INT:")) {
            String[] parts = action.substring(4).split(":");
            adjustInt(parts[0], event, Integer.parseInt(parts[1]), Integer.parseInt(parts[2]));
            return true;
        }
        if (action.startsWith("DOUBLE:")) {
            String[] parts = action.substring(7).split(":");
            adjustDouble(parts[0], event, Double.parseDouble(parts[1]), Double.parseDouble(parts[2]));
            return true;
        }
        return switch (action) {
            case "PREV_PAGE" -> { page = Math.max(0, page - 1); refresh(); yield true; }
            case "NEXT_PAGE" -> { page = Math.min(MAX_PAGES - 1, page + 1); refresh(); yield true; }
            case "CYCLE_LANG" -> {
                String current = plugin.getConfig().getString("general.language", "es");
                plugin.getConfig().set("general.language", "es".equals(current) ? "en" : "es");
                plugin.saveConfig();
                refresh();
                yield true;
            }
            case "RELOAD" -> {
                plugin.getProgressionConfig().reload();
                plugin.getMessageManager().load();
                playSound("success");
                player.closeInventory();
                player.sendMessage(mini.deserialize("<green>✔ Configuración de Progression recargada."));
                yield true;
            }
            case "BACK" -> {
                playSound("click");
                player.closeInventory();
                Bukkit.getScheduler().runTaskLater(core, () -> player.performCommand("ethernova admin"), 2L);
                yield true;
            }
            default -> false;
        };
    }

    // ═══════════════ Helpers ═══════════════

    private void adjustInt(String path, InventoryClickEvent event, int min, int max) {
        int current = plugin.getConfig().getInt(path, 0);
        int delta = event.isShiftClick() ? 10 : 1;
        if (event.isRightClick()) delta = -delta;
        plugin.getConfig().set(path, Math.max(min, Math.min(max, current + delta)));
        plugin.saveConfig();
        refresh();
    }

    private void adjustDouble(String path, InventoryClickEvent event, double min, double max) {
        double current = plugin.getConfig().getDouble(path, 0);
        double delta = event.isShiftClick() ? 1.0 : 0.1;
        if (event.isRightClick()) delta = -delta;
        double newVal = Math.round(Math.max(min, Math.min(max, current + delta)) * 100.0) / 100.0;
        plugin.getConfig().set(path, newVal);
        plugin.saveConfig();
        refresh();
    }

    private void refresh() {
        playSound("click");
        player.closeInventory();
        Bukkit.getScheduler().runTaskLater(core, this::open, 1L);
    }

    private ItemStack toggleItem(String name, String path) {
        boolean val = plugin.getConfig().getBoolean(path, false);
        return createItem(val ? Material.LIME_DYE : Material.GRAY_DYE,
                (val ? "<green>✔ " : "<red>✘ ") + name,
                List.of("<gray>Estado: " + (val ? "<green>Activado" : "<red>Desactivado"),
                        "", "<yellow>Click para " + (val ? "desactivar" : "activar")));
    }

    private ItemStack numberItem(Material mat, String name, String path, String unit) {
        int val = plugin.getConfig().getInt(path, 0);
        String suffix = unit.isEmpty() ? "" : " " + unit;
        return createItem(mat, "<gold>" + name + ": <white>" + val + suffix,
                List.of("<gray>Click izq: <green>+1", "<gray>Click der: <red>-1",
                        "<gray>Shift+Click: <yellow>±10"));
    }

    private ItemStack doubleItem(Material mat, String name, String path, String unit) {
        double val = plugin.getConfig().getDouble(path, 0);
        String suffix = unit.isEmpty() ? "" : " " + unit;
        return createItem(mat, "<gold>" + name + ": <white>" + String.format("%.2f", val) + suffix,
                List.of("<gray>Click izq: <green>+0.1", "<gray>Click der: <red>-0.1",
                        "<gray>Shift+Click: <yellow>±1.0"));
    }
}
