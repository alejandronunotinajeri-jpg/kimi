package com.ethernova.progression.mission;

/**
 * Types of missions with their reset intervals.
 */
public enum MissionType {

    DAILY(86_400_000L),     // 24 hours
    WEEKLY(604_800_000L),   // 7 days
    EVENT(0L);              // No auto-reset

    private final long resetIntervalMs;

    MissionType(long resetIntervalMs) {
        this.resetIntervalMs = resetIntervalMs;
    }

    public long getResetIntervalMs() { return resetIntervalMs; }
}
