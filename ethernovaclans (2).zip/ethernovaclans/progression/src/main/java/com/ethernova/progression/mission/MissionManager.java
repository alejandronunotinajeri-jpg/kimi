package com.ethernova.progression.mission;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.profile.PlayerProfile;
import com.ethernova.core.storage.MigrationManager;
import com.ethernova.progression.EthernovaProgression;
import com.ethernova.progression.level.XPSource;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;

/**
 * Sistema de Misiones v2 — 100% configurable desde missions.yml
 * Port fiel del MissionsManager original de UltimateFFA con mejoras SQL.
 * Soporta: 30 tipos, 4 dificultades, 5 categorías, rachas, notificaciones.
 */
public class MissionManager {

    private final EthernovaProgression plugin;
    private final EthernovaCore core;
    private final MiniMessage mini = MiniMessage.miniMessage();

    // ═══════════════ Per-Player Data ═══════════════

    /** Player UUID → list of active daily missions. */
    private final Map<UUID, List<Mission>> dailyMissions = new ConcurrentHashMap<>();
    /** Player UUID → list of active weekly missions. */
    private final Map<UUID, List<Mission>> weeklyMissions = new ConcurrentHashMap<>();
    /** Player UUID → daily streak count. */
    private final Map<UUID, Integer> dailyStreak = new ConcurrentHashMap<>();
    /** Player UUID → last daily reset timestamp. */
    private final Map<UUID, Long> lastDailyReset = new ConcurrentHashMap<>();
    /** Player UUID → last weekly reset timestamp. */
    private final Map<UUID, Long> lastWeeklyReset = new ConcurrentHashMap<>();

    // ═══════════════ Config ═══════════════

    private FileConfiguration missionsConfig;

    private int dailyCount = 4;
    private int epicChance = 20;
    private boolean weeklyEnabled = true;
    private int weeklyCount = 3;
    private double weeklyGoalMultiplier = 3.5;
    private int weeklyRewardMin = 10000;
    private int weeklyRewardMax = 20000;
    private long dailyResetMs = 86_400_000L;
    private boolean streaksEnabled = true;
    private boolean notificationsEnabled = true;
    private int[] notificationIntervals = {25, 50, 75, 100};

    // ═══════════════ Loaded Templates ═══════════════

    private final Map<String, MissionTypeData> missionTypes = new LinkedHashMap<>();
    private final Map<String, DifficultyData> difficulties = new LinkedHashMap<>();
    private final Map<String, CategoryData> categories = new LinkedHashMap<>();
    private final Map<Integer, StreakMilestone> streakMilestones = new LinkedHashMap<>();

    // ═══════════════ GUI Config ═══════════════

    private String guiTitle = "<aqua><bold>MISIONES</bold></aqua> <dark_gray>- <gray>{player}";
    private int guiSize = 54;
    private int[] dailySlots = {11, 12, 13, 14};
    private int[] weeklySlotsCfg = {39, 40, 41};
    private int streakSlot = 22;
    private int infoDailySlot = 4;
    private int infoWeeklySlot = 31;
    private int closeSlot = 49;

    // ═══════════════ Data Classes ═══════════════

    public static class MissionTypeData {
        public String id, name, description, category;
        public int baseGoal;
        public Material icon;

        public String getDescription(int goal) { return description.replace("{goal}", String.valueOf(goal)); }
    }

    public static class DifficultyData {
        public String id, displayName, color;
        public int rewardMin, rewardMax;
        public double goalMultMin, goalMultMax;

        public DifficultyData() {}

        public DifficultyData(String id, String displayName, String color, int rMin, int rMax, double gMin, double gMax) {
            this.id = id; this.displayName = displayName; this.color = color;
            this.rewardMin = rMin; this.rewardMax = rMax; this.goalMultMin = gMin; this.goalMultMax = gMax;
        }

        public int getReward(Random r) {
            if (rewardMax <= rewardMin) return rewardMin;
            return rewardMin + r.nextInt(rewardMax - rewardMin + 1);
        }

        public int getGoal(int baseGoal, Random r) {
            double mult = goalMultMin + (r.nextDouble() * (goalMultMax - goalMultMin));
            return Math.max(1, (int) (baseGoal * mult));
        }
    }

    public static class CategoryData {
        public String id, displayName;
        public Material icon;

        public CategoryData() {}

        public CategoryData(String id, String displayName, Material icon) {
            this.id = id; this.displayName = displayName; this.icon = icon;
        }
    }

    public static class StreakMilestone {
        public int days, bonusPercentage, money;
        public String message;

        public StreakMilestone() {}

        public StreakMilestone(int days, int bonus, int money, String msg) {
            this.days = days; this.bonusPercentage = bonus; this.money = money; this.message = msg;
        }
    }

    // ═══════════════ Constructor ═══════════════

    public MissionManager(EthernovaProgression plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
        runMigrations();
        loadConfig();
        startResetTask();
    }

    // ═══════════════ CONFIG LOADING ═══════════════

    private void loadConfig() {
        File missionsFile = new File(plugin.getDataFolder(), "missions.yml");
        if (!missionsFile.exists()) {
            plugin.saveResource("missions.yml", false);
        }
        missionsConfig = YamlConfiguration.loadConfiguration(missionsFile);

        // Merge defaults from JAR
        try (InputStream defStream = plugin.getResource("missions.yml")) {
            if (defStream != null) {
                YamlConfiguration defaults = YamlConfiguration.loadConfiguration(
                        new InputStreamReader(defStream, StandardCharsets.UTF_8));
                for (String key : defaults.getKeys(true)) {
                    if (!missionsConfig.contains(key)) {
                        missionsConfig.set(key, defaults.get(key));
                    }
                }
            }
        } catch (Exception e) {
            plugin.getLogger().warning("[Missions] Error loading mission config defaults: " + e.getMessage());
        }

        // Global settings
        dailyCount = missionsConfig.getInt("daily.count", 4);
        epicChance = missionsConfig.getInt("daily.epic-chance", 20);
        weeklyEnabled = missionsConfig.getBoolean("weekly.enabled", true);
        weeklyCount = missionsConfig.getInt("weekly.count", 3);
        weeklyGoalMultiplier = missionsConfig.getDouble("weekly.goal-multiplier", 3.5);
        weeklyRewardMin = missionsConfig.getInt("weekly.reward-min", 10000);
        weeklyRewardMax = missionsConfig.getInt("weekly.reward-max", 20000);
        dailyResetMs = missionsConfig.getLong("auto-reset.daily-hours", 24) * 60 * 60 * 1000L;
        streaksEnabled = missionsConfig.getBoolean("streaks.enabled", true);
        notificationsEnabled = missionsConfig.getBoolean("notifications.enabled", true);
        List<Integer> intervals = missionsConfig.getIntegerList("notifications.intervals");
        if (!intervals.isEmpty()) notificationIntervals = intervals.stream().mapToInt(Integer::intValue).toArray();

        // Difficulties
        difficulties.clear();
        ConfigurationSection diffSection = missionsConfig.getConfigurationSection("difficulties");
        if (diffSection != null) {
            for (String key : diffSection.getKeys(false)) {
                ConfigurationSection d = diffSection.getConfigurationSection(key);
                if (d == null) continue;
                DifficultyData dd = new DifficultyData();
                dd.id = key;
                dd.displayName = legacyToMiniMessage(d.getString("display-name", key));
                dd.color = d.getString("color", "&7");
                dd.rewardMin = d.getInt("reward-min", 100);
                dd.rewardMax = d.getInt("reward-max", 500);
                dd.goalMultMin = d.getDouble("goal-multiplier-min", 1.0);
                dd.goalMultMax = d.getDouble("goal-multiplier-max", 1.5);
                difficulties.put(key, dd);
            }
        }
        if (difficulties.isEmpty()) {
            difficulties.put("EASY", new DifficultyData("EASY", "<green><bold>Fácil", "&a", 300, 500, 1.0, 1.5));
            difficulties.put("MEDIUM", new DifficultyData("MEDIUM", "<yellow><bold>Media", "&e", 800, 1500, 1.5, 3.0));
            difficulties.put("HARD", new DifficultyData("HARD", "<red><bold>Difícil", "&c", 2000, 4000, 3.0, 6.0));
            difficulties.put("EPIC", new DifficultyData("EPIC", "<light_purple><bold>ÉPICA", "&d", 10000, 20000, 6.0, 12.0));
        }

        // Categories
        categories.clear();
        ConfigurationSection catSection = missionsConfig.getConfigurationSection("categories");
        if (catSection != null) {
            for (String key : catSection.getKeys(false)) {
                ConfigurationSection c = catSection.getConfigurationSection(key);
                if (c == null) continue;
                CategoryData cd = new CategoryData();
                cd.id = key;
                cd.displayName = legacyToMiniMessage(c.getString("display-name", key));
                try { cd.icon = Material.valueOf(c.getString("icon", "PAPER")); } catch (Exception e) { cd.icon = Material.PAPER; }
                categories.put(key, cd);
            }
        }
        if (categories.isEmpty()) {
            categories.put("PVP", new CategoryData("PVP", "<red><bold>PVP", Material.DIAMOND_SWORD));
            categories.put("ECONOMY", new CategoryData("ECONOMY", "<gold><bold>Economía", Material.GOLD_INGOT));
            categories.put("SOCIAL", new CategoryData("SOCIAL", "<green><bold>Social", Material.PLAYER_HEAD));
            categories.put("EXPLORATION", new CategoryData("EXPLORATION", "<aqua><bold>Exploración", Material.COMPASS));
            categories.put("SPECIAL", new CategoryData("SPECIAL", "<light_purple><bold>Especial", Material.NETHER_STAR));
        }

        // Mission types
        missionTypes.clear();
        ConfigurationSection typesSection = missionsConfig.getConfigurationSection("mission-types");
        if (typesSection != null) {
            for (String key : typesSection.getKeys(false)) {
                ConfigurationSection t = typesSection.getConfigurationSection(key);
                if (t == null) continue;
                MissionTypeData mt = new MissionTypeData();
                mt.id = key;
                mt.name = t.getString("name", key);
                mt.description = t.getString("description", "Completa {goal}");
                mt.category = t.getString("category", "PVP");
                mt.baseGoal = t.getInt("base-goal", 5);
                try { mt.icon = Material.valueOf(t.getString("icon", "PAPER")); } catch (Exception e) { mt.icon = Material.PAPER; }
                missionTypes.put(key, mt);
            }
        }

        // Streak milestones
        streakMilestones.clear();
        ConfigurationSection streakSection = missionsConfig.getConfigurationSection("streaks.milestones");
        if (streakSection != null) {
            for (String key : streakSection.getKeys(false)) {
                try {
                    int days = Integer.parseInt(key);
                    ConfigurationSection s = streakSection.getConfigurationSection(key);
                    if (s == null) continue;
                    StreakMilestone sm = new StreakMilestone();
                    sm.days = days;
                    sm.bonusPercentage = s.getInt("bonus-percentage", 0);
                    sm.money = s.getInt("money", 0);
                    sm.message = ChatColor.translateAlternateColorCodes('&', s.getString("message", ""));
                    streakMilestones.put(days, sm);
                } catch (NumberFormatException ignored) {}
            }
        }
        if (streakMilestones.isEmpty()) {
            streakMilestones.put(3, new StreakMilestone(3, 10, 1000, "§e§l¡RACHA! §7+3 días §8» §6+$1,000"));
            streakMilestones.put(7, new StreakMilestone(7, 0, 5000, "§e§l¡RACHA SEMANAL! §7+7 días §8» §6+$5,000"));
            streakMilestones.put(30, new StreakMilestone(30, 0, 25000, "§6§l¡RACHA LEGENDARIA! §7+30 días §8» §6+$25,000"));
        }

        // GUI config
        ConfigurationSection guiSection = missionsConfig.getConfigurationSection("gui");
        if (guiSection != null) {
            guiTitle = legacyToMiniMessage(guiSection.getString("title", guiTitle));
            guiSize = guiSection.getInt("size", 54);
            List<Integer> ds = guiSection.getIntegerList("daily-slots");
            if (!ds.isEmpty()) dailySlots = ds.stream().mapToInt(Integer::intValue).toArray();
            List<Integer> ws = guiSection.getIntegerList("weekly-slots");
            if (!ws.isEmpty()) weeklySlotsCfg = ws.stream().mapToInt(Integer::intValue).toArray();
            streakSlot = guiSection.getInt("streak-slot", 22);
            infoDailySlot = guiSection.getInt("info-daily-slot", 10);
            infoWeeklySlot = guiSection.getInt("info-weekly-slot", 28);
            closeSlot = guiSection.getInt("close-slot", 49);
        }

        plugin.getLogger().info("§a[Missions] Cargados " + missionTypes.size() + " tipos, "
                + difficulties.size() + " dificultades, " + categories.size() + " categorías");
    }

    // ═══════════════ LEGACY → MINIMESSAGE CONVERTER ═══════════════

    /**
     * Convert legacy &-code / §-code color strings to MiniMessage format.
     * This ensures display names work correctly in MiniMessage-based GUIs.
     */
    private static String legacyToMiniMessage(String text) {
        if (text == null || text.isEmpty()) return "";
        // If it already looks like MiniMessage, return as-is
        if (text.contains("<") && text.contains(">") && !text.contains("§") && !text.contains("&")) return text;
        // Normalize § to & first
        text = text.replace("§", "&");
        // Replace color codes
        text = text.replace("&0", "<black>").replace("&1", "<dark_blue>")
                .replace("&2", "<dark_green>").replace("&3", "<dark_aqua>")
                .replace("&4", "<dark_red>").replace("&5", "<dark_purple>")
                .replace("&6", "<gold>").replace("&7", "<gray>")
                .replace("&8", "<dark_gray>").replace("&9", "<blue>")
                .replace("&a", "<green>").replace("&b", "<aqua>")
                .replace("&c", "<red>").replace("&d", "<light_purple>")
                .replace("&e", "<yellow>").replace("&f", "<white>");
        // Replace formatting codes
        text = text.replace("&l", "<bold>").replace("&o", "<italic>")
                .replace("&n", "<underlined>").replace("&m", "<strikethrough>")
                .replace("&k", "<obfuscated>").replace("&r", "<reset>");
        return text;
    }

    // ═══════════════ DB MIGRATIONS ═══════════════

    private void runMigrations() {
        new MigrationManager(core.getStorageManager(), plugin.getLogger(), "ethernova_missions")
                .addMigration(1,
                        """
                        CREATE TABLE IF NOT EXISTS ethernova_missions (
                            uuid VARCHAR(36) NOT NULL,
                            mission_id VARCHAR(64) NOT NULL,
                            progress INT DEFAULT 0,
                            completed INTEGER DEFAULT 0,
                            claimed INTEGER DEFAULT 0,
                            assigned_at BIGINT DEFAULT 0,
                            mission_type VARCHAR(16) NOT NULL,
                            PRIMARY KEY (uuid, mission_id, assigned_at)
                        )
                        """,
                        """
                        CREATE TABLE IF NOT EXISTS ethernova_mission_resets (
                            uuid VARCHAR(36) NOT NULL,
                            reset_type VARCHAR(16) NOT NULL,
                            last_reset BIGINT DEFAULT 0,
                            PRIMARY KEY (uuid, reset_type)
                        )
                        """)
                .addMigration(2,
                        """
                        CREATE TABLE IF NOT EXISTS ethernova_missions_v2 (
                            uuid VARCHAR(36) NOT NULL,
                            type_id VARCHAR(64) NOT NULL,
                            difficulty_id VARCHAR(16) NOT NULL,
                            goal INT NOT NULL,
                            reward INT NOT NULL,
                            progress INT DEFAULT 0,
                            completed INTEGER DEFAULT 0,
                            assigned_at BIGINT DEFAULT 0,
                            mission_type VARCHAR(16) NOT NULL,
                            PRIMARY KEY (uuid, type_id, assigned_at)
                        )
                        """,
                        """
                        CREATE TABLE IF NOT EXISTS ethernova_mission_streaks (
                            uuid VARCHAR(36) PRIMARY KEY,
                            streak INT DEFAULT 0,
                            last_all_complete BIGINT DEFAULT 0
                        )
                        """)
                .addMigration(3,
                        "CREATE INDEX IF NOT EXISTS idx_missions_v2_uuid ON ethernova_missions_v2 (uuid)",
                        "CREATE INDEX IF NOT EXISTS idx_mission_resets_uuid ON ethernova_mission_resets (uuid)")
                .migrate();
    }

    // ═══════════════ PLAYER LOAD / UNLOAD ═══════════════

    public void loadPlayer(UUID uuid) {
        loadResetTimestamps(uuid);
        loadStreak(uuid);

        boolean needsDailyReset = needsReset(uuid, MissionType.DAILY);
        boolean needsWeeklyReset = needsReset(uuid, MissionType.WEEKLY);

        if (needsDailyReset) {
            clearMissionsOfType(uuid, MissionType.DAILY);
            saveResetTimestamp(uuid, "DAILY", System.currentTimeMillis());
            lastDailyReset.put(uuid, System.currentTimeMillis());
        }
        if (needsWeeklyReset) {
            clearMissionsOfType(uuid, MissionType.WEEKLY);
            saveResetTimestamp(uuid, "WEEKLY", System.currentTimeMillis());
            lastWeeklyReset.put(uuid, System.currentTimeMillis());
        }

        // Load existing missions from DB
        loadMissionsFromDB(uuid);

        // Generate new missions if needed
        List<Mission> daily = dailyMissions.computeIfAbsent(uuid, k -> new CopyOnWriteArrayList<>());
        List<Mission> weekly = weeklyMissions.computeIfAbsent(uuid, k -> new CopyOnWriteArrayList<>());

        if (daily.size() < dailyCount) {
            generateDailyMissions(uuid, dailyCount - daily.size());
        }
        if (weeklyEnabled && weekly.size() < weeklyCount) {
            generateWeeklyMissions(uuid, weeklyCount - weekly.size());
        }

        // Notify player of new missions
        Player player = Bukkit.getPlayer(uuid);
        if (player != null && needsDailyReset) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (player.isOnline()) {
                    player.sendMessage("§b§l[!] §aNuevas misiones diarias disponibles! §e/missions");
                    player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.5f);
                }
            });
        }
    }

    public void unloadPlayer(UUID uuid) {
        dailyMissions.remove(uuid);
        weeklyMissions.remove(uuid);
        dailyStreak.remove(uuid);
        lastDailyReset.remove(uuid);
        lastWeeklyReset.remove(uuid);
    }

    // ═══════════════ GENERATE MISSIONS ═══════════════

    private void generateDailyMissions(UUID uuid, int count) {
        if (missionTypes.isEmpty()) {
            plugin.getLogger().warning("[Missions] No hay tipos de misión configurados en missions.yml");
            return;
        }

        List<Mission> missions = dailyMissions.computeIfAbsent(uuid, k -> new CopyOnWriteArrayList<>());
        Random random = new Random();
        Set<String> usedTypes = new HashSet<>();
        for (Mission m : missions) usedTypes.add(m.id());

        // Build difficulty order: 1×EASY, (count-2)×MEDIUM, 1×HARD or EPIC(20%)
        List<DifficultyData> diffOrder = new ArrayList<>();
        DifficultyData easy = difficulties.getOrDefault("EASY", difficulties.values().iterator().next());
        DifficultyData medium = difficulties.getOrDefault("MEDIUM", easy);
        DifficultyData hard = difficulties.getOrDefault("HARD", medium);
        DifficultyData epic = difficulties.get("EPIC");

        diffOrder.add(easy);
        for (int i = 0; i < count - 2; i++) diffOrder.add(medium);
        if (epic != null && random.nextInt(100) < epicChance) {
            diffOrder.add(epic);
        } else {
            diffOrder.add(hard);
        }

        List<String> typeKeys = new ArrayList<>(missionTypes.keySet());
        int streak = dailyStreak.getOrDefault(uuid, 0);
        long now = System.currentTimeMillis();

        for (int i = 0; i < Math.min(diffOrder.size(), count); i++) {
            DifficultyData diff = diffOrder.get(i);
            MissionTypeData selected = pickRandomType(typeKeys, usedTypes, random);
            if (selected == null) continue;

            int goal = diff.getGoal(selected.baseGoal, random);
            int reward = diff.getReward(random);

            // Streak bonus
            int bonusPercent = getStreakBonus(streak);
            if (bonusPercent > 0) reward = (int) (reward * (1.0 + bonusPercent / 100.0));

            CategoryData cat = categories.get(selected.category);
            Mission mission = new Mission(
                    selected.id, selected.name, selected.description,
                    selected.category, cat != null ? cat.icon : selected.icon,
                    diff.id, diff.displayName, diff.color,
                    MissionType.DAILY, goal, reward
            );
            missions.add(mission);
            saveMissionToDB(uuid, mission, now);
        }
    }

    private void generateWeeklyMissions(UUID uuid, int count) {
        if (missionTypes.isEmpty()) return;

        List<Mission> missions = weeklyMissions.computeIfAbsent(uuid, k -> new CopyOnWriteArrayList<>());
        Random random = new Random();
        Set<String> usedTypes = new HashSet<>();
        for (Mission m : missions) usedTypes.add(m.id());

        DifficultyData hardDiff = difficulties.getOrDefault("HARD", difficulties.values().iterator().next());
        List<String> typeKeys = new ArrayList<>(missionTypes.keySet());
        long now = System.currentTimeMillis();

        for (int i = 0; i < count; i++) {
            MissionTypeData selected = pickRandomType(typeKeys, usedTypes, random);
            if (selected == null) continue;

            int goal = Math.max(1, (int) (selected.baseGoal * weeklyGoalMultiplier));
            int reward = weeklyRewardMin + random.nextInt(Math.max(1, weeklyRewardMax - weeklyRewardMin + 1));

            CategoryData cat = categories.get(selected.category);
            Mission mission = new Mission(
                    selected.id, selected.name, selected.description,
                    selected.category, cat != null ? cat.icon : selected.icon,
                    hardDiff.id, hardDiff.displayName, hardDiff.color,
                    MissionType.WEEKLY, goal, reward
            );
            missions.add(mission);
            saveMissionToDB(uuid, mission, now);
        }
    }

    private MissionTypeData pickRandomType(List<String> typeKeys, Set<String> usedTypes, Random random) {
        for (int attempts = 0; attempts < 30; attempts++) {
            String typeKey = typeKeys.get(random.nextInt(typeKeys.size()));
            if (!usedTypes.contains(typeKey)) {
                usedTypes.add(typeKey);
                return missionTypes.get(typeKey);
            }
        }
        return null;
    }

    private int getStreakBonus(int streak) {
        int bonus = 0;
        for (Map.Entry<Integer, StreakMilestone> entry : streakMilestones.entrySet()) {
            if (streak >= entry.getKey() && entry.getValue().bonusPercentage > bonus) {
                bonus = entry.getValue().bonusPercentage;
            }
        }
        return bonus;
    }

    // ═══════════════ PROGRESS TRACKING ═══════════════

    /**
     * Add progress towards missions matching the given type ID.
     * This is the primary method: typeId matches mission-types keys from missions.yml
     * (e.g. "KILLER", "STREAK_MASTER", "DUELIST", etc.)
     */
    public void addProgress(Player player, String typeId, int amount) {
        UUID uuid = player.getUniqueId();
        addProgressToList(player, dailyMissions.get(uuid), typeId, amount);
        addProgressToList(player, weeklyMissions.get(uuid), typeId, amount);
    }

    private void addProgressToList(Player player, List<Mission> missions, String typeId, int amount) {
        if (missions == null) return;
        for (Mission mission : missions) {
            if (mission.id().equals(typeId) && !mission.isCompleted()) {
                int oldProgress = mission.current();
                mission.addProgress(amount);
                int newProgress = mission.current();

                // Progress notifications at configured intervals
                if (notificationsEnabled) {
                    double oldPercent = (double) oldProgress / mission.goal();
                    double newPercent = (double) newProgress / mission.goal();
                    for (int interval : notificationIntervals) {
                        double threshold = interval / 100.0;
                        if (oldPercent < threshold && newPercent >= threshold && interval < 100) {
                            String bar = getProgressBar(mission);
                            player.sendMessage("§7§l[MISIÓN] §f" + mission.name() + " §8» " + bar
                                    + " §e" + newProgress + "§7/§e" + mission.goal());
                            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5f, 1.5f);
                            break;
                        }
                    }
                }

                // Check completion
                if (mission.isCompleted() && oldProgress < mission.goal()) {
                    completeMission(player, mission);
                }

                // Save async
                Bukkit.getScheduler().runTaskAsynchronously(plugin, () ->
                        updateMissionProgress(player.getUniqueId(), mission));
            }
        }
    }

    /**
     * Backwards-compatible: increment progress matching missions by ID prefix.
     * Also checks if the pattern matches a type ID directly.
     */
    public void incrementByPattern(Player player, String pattern, int amount) {
        UUID uuid = player.getUniqueId();
        Set<String> matched = new HashSet<>();

        // Check daily missions
        List<Mission> daily = dailyMissions.get(uuid);
        if (daily != null) {
            for (Mission m : daily) {
                if ((m.id().startsWith(pattern) || m.id().equalsIgnoreCase(pattern)) && !matched.contains(m.id())) {
                    matched.add(m.id());
                }
            }
        }

        // Check weekly missions
        List<Mission> weekly = weeklyMissions.get(uuid);
        if (weekly != null) {
            for (Mission m : weekly) {
                if ((m.id().startsWith(pattern) || m.id().equalsIgnoreCase(pattern)) && !matched.contains(m.id())) {
                    matched.add(m.id());
                }
            }
        }

        for (String typeId : matched) {
            addProgress(player, typeId, amount);
        }
    }

    /**
     * Backwards-compatible: increment progress for a specific mission by ID.
     */
    public void incrementProgress(Player player, String missionId, int amount) {
        addProgress(player, missionId, amount);
    }

    private void completeMission(Player player, Mission mission) {
        UUID uuid = player.getUniqueId();

        // Grant rewards
        PlayerProfile profile = core.getProfileManager().getProfile(uuid);
        if (profile != null) {
            profile.addCoins(mission.coinReward());
        }
        if (plugin.getLevelManager() != null) {
            plugin.getLevelManager().addXP(player, mission.xpReward(), XPSource.QUEST);
        }

        // Track missions completed for achievement
        plugin.getAchievementManager().checkProgress(player, "mission_master", 1);

        // Fancy completion message (matching original)
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!player.isOnline()) return;
            player.sendMessage("");
            player.sendMessage("§6§l§m                                                    ");
            player.sendMessage("§a§l          ✓ MISIÓN COMPLETADA ✓");
            player.sendMessage("");
            player.sendMessage("  §f" + mission.name());
            player.sendMessage("  §7" + mission.description());
            player.sendMessage("");
            player.sendMessage("  §e§lRECOMPENSA: §6$" + String.format("%,d", mission.reward()));
            player.sendMessage("§6§l§m                                                    ");
            player.sendMessage("");
            player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
            try {
                player.spawnParticle(Particle.TOTEM_OF_UNDYING, player.getLocation().add(0, 1, 0), 50, 0.5, 0.5, 0.5, 0.1);
            } catch (Exception e) {
                try { player.spawnParticle(Particle.valueOf("TOTEM"), player.getLocation().add(0, 1, 0), 50, 0.5, 0.5, 0.5, 0.1); }
                catch (Exception ignored) {}
            }
        });

        checkAllDailyComplete(player);
    }

    private void checkAllDailyComplete(Player player) {
        UUID uuid = player.getUniqueId();
        List<Mission> daily = dailyMissions.get(uuid);
        if (daily == null) return;
        for (Mission m : daily) { if (!m.isCompleted()) return; }
        if (streaksEnabled) updateDailyStreak(player);
    }

    private void updateDailyStreak(Player player) {
        UUID uuid = player.getUniqueId();
        int currentStreak = dailyStreak.getOrDefault(uuid, 0) + 1;
        dailyStreak.put(uuid, currentStreak);

        // Save streak async
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> saveStreak(uuid, currentStreak));

        StreakMilestone milestone = streakMilestones.get(currentStreak);
        if (milestone != null) {
            if (milestone.money > 0) {
                PlayerProfile profile = core.getProfileManager().getProfile(uuid);
                if (profile != null) profile.addCoins(milestone.money);
            }
            if (!milestone.message.isEmpty()) {
                player.sendMessage(milestone.message);
            }
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        }
    }

    private String getProgressBar(Mission mission) {
        double progress = mission.getProgress();
        int bars = 10;
        int filled = (int) (progress * bars);
        StringBuilder bar = new StringBuilder("§8[");
        for (int i = 0; i < bars; i++) bar.append(i < filled ? "§a█" : "§7█");
        bar.append("§8]");
        return bar.toString();
    }

    // ═══════════════ SCOREBOARD HELPER ═══════════════

    /**
     * Get the most relevant active mission line for scoreboard display.
     */
    public String getActiveMissionLine(Player player) {
        UUID uuid = player.getUniqueId();
        List<Mission> daily = dailyMissions.get(uuid);
        if (daily == null) return "§7Sin Misión";
        for (Mission m : daily) {
            if (!m.isCompleted()) {
                return "§a" + m.name() + " §7(" + m.current() + "/" + m.goal() + ")";
            }
        }
        return "§a¡Todo Completado!";
    }

    // ═══════════════ PUBLIC GETTERS ═══════════════

    /**
     * Get all active missions for a player (daily + weekly combined).
     */
    public List<Mission> getActiveMissions(UUID uuid) {
        List<Mission> result = new ArrayList<>();
        List<Mission> daily = dailyMissions.get(uuid);
        if (daily != null) result.addAll(daily);
        List<Mission> weekly = weeklyMissions.get(uuid);
        if (weekly != null) result.addAll(weekly);
        return result;
    }

    /**
     * Get active missions of a specific type.
     */
    public List<Mission> getActiveMissions(UUID uuid, MissionType type) {
        if (type == MissionType.DAILY) {
            List<Mission> daily = dailyMissions.get(uuid);
            return daily != null ? new ArrayList<>(daily) : Collections.emptyList();
        } else if (type == MissionType.WEEKLY) {
            List<Mission> weekly = weeklyMissions.get(uuid);
            return weekly != null ? new ArrayList<>(weekly) : Collections.emptyList();
        }
        return Collections.emptyList();
    }

    /**
     * Get progress for a mission (by type ID).
     */
    public int getProgress(UUID uuid, String missionId) {
        List<Mission> all = getActiveMissions(uuid);
        for (Mission m : all) {
            if (m.id().equals(missionId)) return m.current();
        }
        return 0;
    }

    /**
     * Check if a mission is completed.
     */
    public boolean isCompleted(UUID uuid, String missionId) {
        List<Mission> all = getActiveMissions(uuid);
        for (Mission m : all) {
            if (m.id().equals(missionId)) return m.isCompleted();
        }
        return false;
    }

    /**
     * Count completed daily missions.
     */
    public int getCompletedDailyCount(UUID uuid) {
        List<Mission> daily = dailyMissions.get(uuid);
        if (daily == null) return 0;
        return (int) daily.stream().filter(Mission::isCompleted).count();
    }

    /**
     * Get the daily streak for a player.
     */
    public int getStreak(UUID uuid) {
        return dailyStreak.getOrDefault(uuid, 0);
    }

    /**
     * Get a mission by looking through a player's active missions.
     * Kept for backwards compatibility with GUI code.
     */
    public Mission getMissionById(String id) {
        // Search all cached players
        for (List<Mission> list : dailyMissions.values()) {
            for (Mission m : list) { if (m.id().equals(id)) return m; }
        }
        for (List<Mission> list : weeklyMissions.values()) {
            for (Mission m : list) { if (m.id().equals(id)) return m; }
        }
        return null;
    }

    /** Expose loaded mission types for GUI. */
    public Map<String, MissionTypeData> getMissionTypes() { return Collections.unmodifiableMap(missionTypes); }
    public Map<String, CategoryData> getCategories() { return Collections.unmodifiableMap(categories); }
    public Map<Integer, StreakMilestone> getStreakMilestones() { return Collections.unmodifiableMap(streakMilestones); }
    public String getGuiTitle() { return guiTitle; }
    public int getGuiSize() { return guiSize; }
    public int[] getDailySlots() { return dailySlots; }
    public int[] getWeeklySlots() { return weeklySlotsCfg; }
    public int getStreakSlot() { return streakSlot; }
    public int getInfoDailySlot() { return infoDailySlot; }
    public int getInfoWeeklySlot() { return infoWeeklySlot; }
    public int getCloseSlot() { return closeSlot; }

    // ═══════════════ DB PERSISTENCE ═══════════════

    private void saveMissionToDB(UUID uuid, Mission mission, long assignedAt) {
        String sql = core.getStorageManager().isMySQL()
                ? "INSERT INTO ethernova_missions_v2 (uuid, type_id, difficulty_id, goal, reward, progress, completed, assigned_at, mission_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE goal=VALUES(goal), reward=VALUES(reward)"
                : "INSERT INTO ethernova_missions_v2 (uuid, type_id, difficulty_id, goal, reward, progress, completed, assigned_at, mission_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(uuid, type_id, assigned_at) DO UPDATE SET goal=excluded.goal, reward=excluded.reward";
        try (Connection conn = core.getStorageManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.setString(2, mission.id());
            ps.setString(3, mission.difficultyId());
            ps.setInt(4, mission.goal());
            ps.setInt(5, mission.reward());
            ps.setInt(6, mission.current());
            ps.setBoolean(7, mission.isCompleted());
            ps.setLong(8, assignedAt);
            ps.setString(9, mission.type().name());
            ps.executeUpdate();
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error saving mission " + mission.id() + " for " + uuid, e);
        }
    }

    private void updateMissionProgress(UUID uuid, Mission mission) {
        try (Connection conn = core.getStorageManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "UPDATE ethernova_missions_v2 SET progress=?, completed=? WHERE uuid=? AND type_id=?")) {
            ps.setInt(1, mission.current());
            ps.setBoolean(2, mission.isCompleted());
            ps.setString(3, uuid.toString());
            ps.setString(4, mission.id());
            ps.executeUpdate();
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error updating mission progress", e);
        }
    }

    private void loadMissionsFromDB(UUID uuid) {
        List<Mission> daily = new CopyOnWriteArrayList<>();
        List<Mission> weekly = new CopyOnWriteArrayList<>();

        try (Connection conn = core.getStorageManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT type_id, difficulty_id, goal, reward, progress, completed, mission_type FROM ethernova_missions_v2 WHERE uuid = ? ORDER BY assigned_at DESC")) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String typeId = rs.getString("type_id");
                    String diffId = rs.getString("difficulty_id");
                    int goal = rs.getInt("goal");
                    int reward = rs.getInt("reward");
                    int progress = rs.getInt("progress");
                    boolean completed = rs.getBoolean("completed");
                    String mTypeStr = rs.getString("mission_type");

                    MissionTypeData typeData = missionTypes.get(typeId);
                    DifficultyData diffData = difficulties.get(diffId);
                    if (typeData == null || diffData == null) continue;

                    MissionType mType = "WEEKLY".equals(mTypeStr) ? MissionType.WEEKLY : MissionType.DAILY;
                    CategoryData cat = categories.get(typeData.category);

                    Mission mission = new Mission(
                            typeData.id, typeData.name, typeData.description,
                            typeData.category, cat != null ? cat.icon : typeData.icon,
                            diffData.id, diffData.displayName, diffData.color,
                            mType, goal, reward
                    );
                    mission.setCurrent(progress);

                    if (mType == MissionType.DAILY) {
                        if (daily.stream().noneMatch(m -> m.id().equals(typeId))) daily.add(mission);
                    } else {
                        if (weekly.stream().noneMatch(m -> m.id().equals(typeId))) weekly.add(mission);
                    }
                }
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error loading missions_v2 for " + uuid, e);
        }

        dailyMissions.put(uuid, daily);
        weeklyMissions.put(uuid, weekly);
    }

    private void clearMissionsOfType(UUID uuid, MissionType type) {
        try (Connection conn = core.getStorageManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "DELETE FROM ethernova_missions_v2 WHERE uuid = ? AND mission_type = ?")) {
            ps.setString(1, uuid.toString());
            ps.setString(2, type.name());
            ps.executeUpdate();
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error clearing missions_v2", e);
        }

        if (type == MissionType.DAILY) dailyMissions.remove(uuid);
        else weeklyMissions.remove(uuid);
    }

    private boolean needsReset(UUID uuid, MissionType type) {
        long lastReset = type == MissionType.DAILY
                ? lastDailyReset.getOrDefault(uuid, 0L)
                : lastWeeklyReset.getOrDefault(uuid, 0L);
        return System.currentTimeMillis() - lastReset >= type.getResetIntervalMs();
    }

    private void loadResetTimestamps(UUID uuid) {
        try (Connection conn = core.getStorageManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT reset_type, last_reset FROM ethernova_mission_resets WHERE uuid = ?")) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String type = rs.getString("reset_type");
                    long ts = rs.getLong("last_reset");
                    if ("DAILY".equals(type)) lastDailyReset.put(uuid, ts);
                    else if ("WEEKLY".equals(type)) lastWeeklyReset.put(uuid, ts);
                }
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error loading mission resets for " + uuid, e);
        }
    }

    private void saveResetTimestamp(UUID uuid, String type, long timestamp) {
        String sql = core.getStorageManager().isMySQL()
                ? "INSERT INTO ethernova_mission_resets (uuid, reset_type, last_reset) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE last_reset=VALUES(last_reset)"
                : "INSERT INTO ethernova_mission_resets (uuid, reset_type, last_reset) VALUES (?, ?, ?) ON CONFLICT(uuid, reset_type) DO UPDATE SET last_reset=excluded.last_reset";
        try (Connection conn = core.getStorageManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.setString(2, type);
            ps.setLong(3, timestamp);
            ps.executeUpdate();
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error saving reset timestamp", e);
        }
    }

    private void loadStreak(UUID uuid) {
        try (Connection conn = core.getStorageManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT streak FROM ethernova_mission_streaks WHERE uuid = ?")) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    dailyStreak.put(uuid, rs.getInt("streak"));
                } else {
                    dailyStreak.put(uuid, 0);
                }
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error loading streak for " + uuid, e);
            dailyStreak.put(uuid, 0);
        }
    }

    private void saveStreak(UUID uuid, int streak) {
        String sql = core.getStorageManager().isMySQL()
                ? "INSERT INTO ethernova_mission_streaks (uuid, streak) VALUES (?, ?) ON DUPLICATE KEY UPDATE streak=VALUES(streak)"
                : "INSERT INTO ethernova_mission_streaks (uuid, streak) VALUES (?, ?) ON CONFLICT(uuid) DO UPDATE SET streak=excluded.streak";
        try (Connection conn = core.getStorageManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.setInt(2, streak);
            ps.executeUpdate();
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error saving streak for " + uuid, e);
        }
    }

    /**
     * Save all mission data for a player synchronously (for shutdown).
     */
    public void savePlayerSync(UUID uuid) {
        List<Mission> daily = dailyMissions.get(uuid);
        if (daily != null) {
            for (Mission m : daily) updateMissionProgress(uuid, m);
        }
        List<Mission> weekly = weeklyMissions.get(uuid);
        if (weekly != null) {
            for (Mission m : weekly) updateMissionProgress(uuid, m);
        }
        int streak = dailyStreak.getOrDefault(uuid, 0);
        saveStreak(uuid, streak);
    }

    // ═══════════════ AUTO RESET TASK ═══════════════

    private void startResetTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                long now = System.currentTimeMillis();
                for (UUID uuid : new HashSet<>(lastDailyReset.keySet())) {
                    Player p = Bukkit.getPlayer(uuid);
                    if (p == null || !p.isOnline()) continue;
                    long lastDaily = lastDailyReset.getOrDefault(uuid, 0L);
                    if (now - lastDaily >= dailyResetMs) {
                        loadPlayer(uuid); // Will trigger reset and regeneration
                    }
                    if (weeklyEnabled) {
                        long lastWeekly = lastWeeklyReset.getOrDefault(uuid, 0L);
                        if (now - lastWeekly >= MissionType.WEEKLY.getResetIntervalMs()) {
                            loadPlayer(uuid);
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 20L * 60, 20L * 60); // Check every minute
    }
}
