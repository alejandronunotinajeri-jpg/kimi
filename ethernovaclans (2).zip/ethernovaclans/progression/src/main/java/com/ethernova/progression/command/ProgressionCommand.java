package com.ethernova.progression.command;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.profile.PlayerProfile;
import com.ethernova.progression.EthernovaProgression;
import com.ethernova.progression.gui.AchievementGui;
import com.ethernova.progression.gui.BattlePassGui;
import com.ethernova.progression.gui.LevelGui;
import com.ethernova.progression.gui.MissionGui;
import com.ethernova.progression.gui.ProgressionAdminGui;
import com.ethernova.progression.message.MessageManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Handles all progression-related commands:
 * /level (nivel) - show level info, /level top - leaderboard, admin subcommands
 * /prestige (prestigio) - prestige, admin subcommands
 * /achievements (logros) - achievements GUI, admin subcommands
 * /missions (misiones) - missions GUI, admin subcommands
 * /battlepass (pase) - battle pass GUI, admin subcommands
 */
public class ProgressionCommand implements CommandExecutor, TabCompleter {

    private final EthernovaProgression plugin;
    private final EthernovaCore core;
    private final MiniMessage mini = MiniMessage.miniMessage();

    public ProgressionCommand(EthernovaProgression plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
    }

    private MessageManager mm() { return plugin.getMessageManager(); }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        String cmd = command.getName().toLowerCase();

        return switch (cmd) {
            case "level", "nivel" -> handleLevel(sender, args);
            case "prestige", "prestigio" -> handlePrestige(sender, args);
            case "achievements", "logros" -> handleAchievements(sender, args);
            case "missions", "misiones" -> handleMissions(sender, args);
            case "battlepass", "pase" -> handleBattlePass(sender, args);
            case "daily", "diario" -> handleDaily(sender);
            default -> false;
        };
    }

    // ═══════════════════ LEVEL ═══════════════════

    private boolean handleLevel(CommandSender sender, String[] args) {
        if (args.length > 0) {
            String sub = args[0].toLowerCase();
            switch (sub) {
                case "top" -> { return handleLevelTop(sender); }
                case "addxp" -> { return handleLevelAddXP(sender, args); }
                case "setlevel" -> { return handleLevelSetLevel(sender, args); }
                case "info" -> { return handleLevelInfo(sender, args); }
                case "help" -> { return handleLevelHelp(sender); }
                case "reload" -> { return handleReload(sender); }
                case "admin" -> {
                    if (!(sender instanceof Player p) || !sender.hasPermission("progression.admin")) {
                        mm().sendMessage(sender, "general.no-permission");
                        return true;
                    }
                    new ProgressionAdminGui(plugin, p).open();
                    return true;
                }
            }
        }

        // Default: open GUI
        if (!(sender instanceof Player player)) {
            mm().sendMessage(sender, "general.only-players");
            return true;
        }

        LevelGui gui = new LevelGui(core, plugin, player);
        core.getGuiManager().registerGui(player, gui);
        gui.open();
        return true;
    }

    private boolean handleLevelTop(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            mm().sendMessage(sender, "general.only-players");
            return true;
        }

        showLeaderboard(player);
        return true;
    }

    private boolean handleLevelInfo(CommandSender sender, String[] args) {
        if (args.length >= 2 && sender.hasPermission("progression.admin")) {
            // /level info <player>
            Player target = Bukkit.getPlayer(args[1]);
            if (target == null) {
                mm().sendMessage(sender, "general.player-not-found");
                return true;
            }
            PlayerProfile profile = core.getProfileManager().getProfile(target.getUniqueId());
            if (profile == null) {
                mm().sendMessage(sender, "general.player-not-found");
                return true;
            }
            mm().sendMessage(sender, "level.info-other",
                    "{player}", target.getName(),
                    "{level}", String.valueOf(profile.getLevel()),
                    "{xp}", String.format("%,d", profile.getXP()),
                    "{prestige}", String.valueOf(profile.getPrestige()));
            return true;
        }
        // Self info
        if (!(sender instanceof Player player)) {
            mm().sendMessage(sender, "general.only-players");
            return true;
        }
        PlayerProfile profile = core.getProfileManager().getProfile(player.getUniqueId());
        if (profile == null) return true;
        mm().sendMessage(sender, "level.info-self",
                "{level}", String.valueOf(profile.getLevel()),
                "{xp}", String.format("%,d", profile.getXP()),
                "{prestige}", String.valueOf(profile.getPrestige()));
        return true;
    }

    private boolean handleLevelAddXP(CommandSender sender, String[] args) {
        if (!sender.hasPermission("progression.admin")) {
            mm().sendMessage(sender, "general.no-permission");
            return true;
        }
        if (args.length < 3) {
            mm().sendMessage(sender, "general.usage", "{usage}", mm().get("level.addxp-usage"));
            return true;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            mm().sendMessage(sender, "general.player-not-found");
            return true;
        }
        try {
            long amount = Long.parseLong(args[2]);
            plugin.getLevelManager().addRawXP(target, amount);
            mm().sendMessage(sender, "level.addxp-success",
                    "{amount}", String.valueOf(amount), "{player}", target.getName());
        } catch (NumberFormatException e) {
            mm().sendMessage(sender, "general.invalid-number");
        }
        return true;
    }

    private boolean handleLevelSetLevel(CommandSender sender, String[] args) {
        if (!sender.hasPermission("progression.admin")) {
            mm().sendMessage(sender, "general.no-permission");
            return true;
        }
        if (args.length < 3) {
            mm().sendMessage(sender, "general.usage", "{usage}", mm().get("level.setlevel-usage"));
            return true;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            mm().sendMessage(sender, "general.player-not-found");
            return true;
        }
        try {
            int level = Integer.parseInt(args[2]);
            PlayerProfile profile = core.getProfileManager().getProfile(target.getUniqueId());
            if (profile != null) {
                profile.setLevel(level);
                profile.setXP(plugin.getLevelManager().getTotalXPForLevel(level));
                mm().sendMessage(sender, "level.setlevel-success",
                        "{player}", target.getName(), "{level}", String.valueOf(level));
            }
        } catch (NumberFormatException e) {
            mm().sendMessage(sender, "general.invalid-number");
        }
        return true;
    }

    private boolean handleLevelHelp(CommandSender sender) {
        String[] keys = {"help.level-header", "help.level-gui", "help.level-top", "help.level-info"};
        for (String key : keys) mm().sendMessage(sender, key);
        if (sender.hasPermission("progression.admin")) {
            mm().sendMessage(sender, "help.level-addxp");
            mm().sendMessage(sender, "help.level-setlevel");
            mm().sendMessage(sender, "help.level-reload");
        }
        return true;
    }

    private boolean handleReload(CommandSender sender) {
        if (!sender.hasPermission("progression.admin")) {
            mm().sendMessage(sender, "general.no-permission");
            return true;
        }
        plugin.getProgressionConfig().reload();
        plugin.getMessageManager().load();
        mm().sendMessage(sender, "general.reload-success");
        return true;
    }

    private void showLeaderboard(Player player) {
        player.sendMessage(mini.deserialize(""));
        mm().sendMessage(player, "leaderboard.header");
        player.sendMessage(mini.deserialize(""));

        // Fetch leaderboard async
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            List<String> entries = new ArrayList<>();
            try (var conn = core.getStorageManager().getConnection();
                 var ps = conn.prepareStatement(
                         "SELECT name, level, prestige, xp FROM ethernova_profiles ORDER BY prestige DESC, level DESC, xp DESC LIMIT 10");
                 var rs = ps.executeQuery()) {

                int rank = 1;
                while (rs.next()) {
                    String name = rs.getString("name");
                    int level = rs.getInt("level");
                    int prestige = rs.getInt("prestige");
                    long xp = rs.getLong("xp");

                    String prestigeTag = prestige > 0
                            ? plugin.getPrestigeManager().getPrestigeColor(prestige) + "[P" + prestige + "]</gradient> "
                            : "";

                    String entryKey = switch (rank) {
                        case 1 -> "leaderboard.entry-first";
                        case 2 -> "leaderboard.entry-second";
                        case 3 -> "leaderboard.entry-third";
                        default -> "leaderboard.entry-other";
                    };

                    entries.add(mm().get(entryKey,
                            "{rank}", String.valueOf(rank),
                            "{prestige_tag}", prestigeTag,
                            "{player}", name,
                            "{level}", String.valueOf(level),
                            "{xp}", String.format("%,d", xp)));
                    rank++;
                }
            } catch (Exception e) {
                plugin.getLogger().log(java.util.logging.Level.WARNING, "Error loading leaderboard", e);
            }

            Bukkit.getScheduler().runTask(plugin, () -> {
                if (!player.isOnline()) return;
                if (entries.isEmpty()) {
                    mm().sendMessage(player, "leaderboard.no-data");
                } else {
                    entries.forEach(e -> player.sendMessage(mini.deserialize(e)));
                }
                player.sendMessage(mini.deserialize(""));
                mm().sendMessage(player, "leaderboard.footer");
            });
        });
    }

    // ═══════════════════ PRESTIGE ═══════════════════

    private boolean handlePrestige(CommandSender sender, String[] args) {
        if (args.length > 0) {
            String sub = args[0].toLowerCase();
            switch (sub) {
                case "set" -> { return handlePrestigeSet(sender, args); }
                case "help" -> { return handlePrestigeHelp(sender); }
            }
        }

        if (!(sender instanceof Player player)) {
            mm().sendMessage(sender, "general.only-players");
            return true;
        }

        plugin.getPrestigeManager().prestige(player);
        return true;
    }

    private boolean handlePrestigeSet(CommandSender sender, String[] args) {
        if (!sender.hasPermission("progression.admin")) {
            mm().sendMessage(sender, "general.no-permission");
            return true;
        }
        if (args.length < 3) {
            mm().sendMessage(sender, "general.usage", "{usage}", mm().get("prestige.setprestige-usage"));
            return true;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            mm().sendMessage(sender, "general.player-not-found");
            return true;
        }
        try {
            int prestige = Integer.parseInt(args[2]);
            PlayerProfile profile = core.getProfileManager().getProfile(target.getUniqueId());
            if (profile != null) {
                profile.setPrestige(prestige);
                mm().sendMessage(sender, "prestige.setprestige-success",
                        "{player}", target.getName(), "{prestige}", String.valueOf(prestige));
            }
        } catch (NumberFormatException e) {
            mm().sendMessage(sender, "general.invalid-number");
        }
        return true;
    }

    private boolean handlePrestigeHelp(CommandSender sender) {
        mm().sendMessage(sender, "help.prestige-header");
        mm().sendMessage(sender, "help.prestige-use");
        if (sender.hasPermission("progression.admin")) {
            mm().sendMessage(sender, "help.prestige-set");
        }
        return true;
    }

    // ═══════════════════ ACHIEVEMENTS ═══════════════════

    private boolean handleAchievements(CommandSender sender, String[] args) {
        if (args.length > 0) {
            String sub = args[0].toLowerCase();
            switch (sub) {
                case "give" -> { return handleAchievementGive(sender, args); }
                case "help" -> { return handleAchievementHelp(sender); }
            }
        }

        if (!(sender instanceof Player player)) {
            mm().sendMessage(sender, "general.only-players");
            return true;
        }

        AchievementGui gui = new AchievementGui(core, plugin, player);
        core.getGuiManager().registerGui(player, gui);
        gui.open();
        return true;
    }

    private boolean handleAchievementGive(CommandSender sender, String[] args) {
        if (!sender.hasPermission("progression.admin")) {
            mm().sendMessage(sender, "general.no-permission");
            return true;
        }
        if (args.length < 3) {
            mm().sendMessage(sender, "general.usage", "{usage}", mm().get("help.achievements-give"));
            return true;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            mm().sendMessage(sender, "general.player-not-found");
            return true;
        }
        String achievementId = args[2];
        var achievement = plugin.getAchievementManager().getAchievement(achievementId);
        if (achievement == null) {
            mm().sendMessage(sender, "general.player-not-found"); // reuse for "not found"
            return true;
        }
        plugin.getAchievementManager().setProgress(target, achievementId, achievement.target());
        return true;
    }

    private boolean handleAchievementHelp(CommandSender sender) {
        mm().sendMessage(sender, "help.achievements-header");
        mm().sendMessage(sender, "help.achievements-use");
        if (sender.hasPermission("progression.admin")) {
            mm().sendMessage(sender, "help.achievements-give");
        }
        return true;
    }

    // ═══════════════════ MISSIONS ═══════════════════

    private boolean handleMissions(CommandSender sender, String[] args) {
        if (args.length > 0) {
            String sub = args[0].toLowerCase();
            switch (sub) {
                case "reset" -> { return handleMissionReset(sender, args); }
                case "help" -> { return handleMissionHelp(sender); }
            }
        }

        if (!(sender instanceof Player player)) {
            mm().sendMessage(sender, "general.only-players");
            return true;
        }

        MissionGui gui = new MissionGui(core, plugin, player);
        core.getGuiManager().registerGui(player, gui);
        gui.open();
        return true;
    }

    private boolean handleMissionReset(CommandSender sender, String[] args) {
        if (!sender.hasPermission("progression.admin")) {
            mm().sendMessage(sender, "general.no-permission");
            return true;
        }
        if (args.length < 2) {
            mm().sendMessage(sender, "general.usage", "{usage}", mm().get("help.missions-reset"));
            return true;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            mm().sendMessage(sender, "general.player-not-found");
            return true;
        }
        plugin.getMissionManager().unloadPlayer(target.getUniqueId());
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            plugin.getMissionManager().loadPlayer(target.getUniqueId());
        });
        mm().sendMessage(sender, "general.reload-success");
        return true;
    }

    private boolean handleMissionHelp(CommandSender sender) {
        mm().sendMessage(sender, "help.missions-header");
        mm().sendMessage(sender, "help.missions-use");
        if (sender.hasPermission("progression.admin")) {
            mm().sendMessage(sender, "help.missions-reset");
        }
        return true;
    }

    // ═══════════════════ BATTLEPASS ═══════════════════

    private boolean handleBattlePass(CommandSender sender, String[] args) {
        if (args.length > 0) {
            String sub = args[0].toLowerCase();
            switch (sub) {
                case "setpremium" -> { return handleBPSetPremium(sender, args); }
                case "addxp" -> { return handleBPAddXP(sender, args); }
                case "help" -> { return handleBPHelp(sender); }
            }
        }

        if (!(sender instanceof Player player)) {
            mm().sendMessage(sender, "general.only-players");
            return true;
        }

        BattlePassGui gui = new BattlePassGui(core, plugin, player);
        core.getGuiManager().registerGui(player, gui);
        gui.open();
        return true;
    }

    private boolean handleBPSetPremium(CommandSender sender, String[] args) {
        if (!sender.hasPermission("progression.admin")) {
            mm().sendMessage(sender, "general.no-permission");
            return true;
        }
        if (args.length < 2) {
            mm().sendMessage(sender, "general.usage", "{usage}", mm().get("battlepass.setpremium-usage"));
            return true;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            mm().sendMessage(sender, "general.player-not-found");
            return true;
        }
        plugin.getBattlePassManager().setPremium(target.getUniqueId(), true);
        mm().sendMessage(sender, "battlepass.setpremium-success", "{player}", target.getName());
        return true;
    }

    private boolean handleBPAddXP(CommandSender sender, String[] args) {
        if (!sender.hasPermission("progression.admin")) {
            mm().sendMessage(sender, "general.no-permission");
            return true;
        }
        if (args.length < 3) {
            mm().sendMessage(sender, "general.usage", "{usage}", mm().get("battlepass.addxp-usage"));
            return true;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            mm().sendMessage(sender, "general.player-not-found");
            return true;
        }
        try {
            long amount = Long.parseLong(args[2]);
            plugin.getBattlePassManager().addXP(target, amount);
            mm().sendMessage(sender, "battlepass.addxp-success",
                    "{amount}", String.valueOf(amount), "{player}", target.getName());
        } catch (NumberFormatException e) {
            mm().sendMessage(sender, "general.invalid-number");
        }
        return true;
    }

    private boolean handleBPHelp(CommandSender sender) {
        mm().sendMessage(sender, "help.battlepass-header");
        mm().sendMessage(sender, "help.battlepass-use");
        if (sender.hasPermission("progression.admin")) {
            mm().sendMessage(sender, "help.battlepass-premium");
            mm().sendMessage(sender, "help.battlepass-addxp");
        }
        return true;
    }

    // ═══════════════════ DAILY REWARDS ═══════════════════

    private boolean handleDaily(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            mm().sendMessage(sender, "general.only-players");
            return true;
        }

        var dailyManager = plugin.getDailyRewardManager();
        if (dailyManager == null) {
            player.sendMessage(MiniMessage.miniMessage().deserialize(
                    "<red>El sistema de recompensas diarias no está disponible."));
            return true;
        }

        dailyManager.openGui(player);
        return true;
    }

    // ═══════════════════ TAB COMPLETION ═══════════════════

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        String cmd = command.getName().toLowerCase();

        return switch (cmd) {
            case "level", "nivel" -> tabLevel(sender, args);
            case "prestige", "prestigio" -> tabPrestige(sender, args);
            case "achievements", "logros" -> tabAchievements(sender, args);
            case "missions", "misiones" -> tabMissions(sender, args);
            case "battlepass", "pase" -> tabBattlePass(sender, args);
            case "daily", "diario" -> Collections.emptyList();
            default -> Collections.emptyList();
        };
    }

    private List<String> tabLevel(CommandSender sender, String[] args) {
        if (args.length == 1) {
            List<String> completions = new ArrayList<>(List.of("top", "info", "help"));
            if (sender.hasPermission("progression.admin")) {
                completions.addAll(List.of("addxp", "setlevel", "reload", "admin"));
            }
            return filter(completions, args[0]);
        }
        if (args.length == 2 && List.of("addxp", "setlevel", "info").contains(args[0].toLowerCase())) {
            return filterPlayers(args[1]);
        }
        if (args.length == 3 && "setlevel".equalsIgnoreCase(args[0])) {
            return List.of("1", "10", "25", "50", "100");
        }
        if (args.length == 3 && "addxp".equalsIgnoreCase(args[0])) {
            return List.of("100", "500", "1000", "5000", "10000");
        }
        return Collections.emptyList();
    }

    private List<String> tabPrestige(CommandSender sender, String[] args) {
        if (args.length == 1) {
            List<String> completions = new ArrayList<>(List.of("help"));
            if (sender.hasPermission("progression.admin")) {
                completions.add("set");
            }
            return filter(completions, args[0]);
        }
        if (args.length == 2 && "set".equalsIgnoreCase(args[0])) {
            return filterPlayers(args[1]);
        }
        if (args.length == 3 && "set".equalsIgnoreCase(args[0])) {
            return List.of("0", "1", "2", "3", "4", "5");
        }
        return Collections.emptyList();
    }

    private List<String> tabAchievements(CommandSender sender, String[] args) {
        if (args.length == 1) {
            List<String> completions = new ArrayList<>(List.of("help"));
            if (sender.hasPermission("progression.admin")) {
                completions.add("give");
            }
            return filter(completions, args[0]);
        }
        if (args.length == 2 && "give".equalsIgnoreCase(args[0])) {
            return filterPlayers(args[1]);
        }
        if (args.length == 3 && "give".equalsIgnoreCase(args[0])) {
            return filter(
                    plugin.getAchievementManager().getAllAchievements().stream()
                            .map(a -> a.id()).collect(Collectors.toList()),
                    args[2]);
        }
        return Collections.emptyList();
    }

    private List<String> tabMissions(CommandSender sender, String[] args) {
        if (args.length == 1) {
            List<String> completions = new ArrayList<>(List.of("help"));
            if (sender.hasPermission("progression.admin")) {
                completions.add("reset");
            }
            return filter(completions, args[0]);
        }
        if (args.length == 2 && "reset".equalsIgnoreCase(args[0])) {
            return filterPlayers(args[1]);
        }
        return Collections.emptyList();
    }

    private List<String> tabBattlePass(CommandSender sender, String[] args) {
        if (args.length == 1) {
            List<String> completions = new ArrayList<>(List.of("help"));
            if (sender.hasPermission("progression.admin")) {
                completions.addAll(List.of("setpremium", "addxp"));
            }
            return filter(completions, args[0]);
        }
        if (args.length == 2 && List.of("setpremium", "addxp").contains(args[0].toLowerCase())) {
            return filterPlayers(args[1]);
        }
        if (args.length == 3 && "addxp".equalsIgnoreCase(args[0])) {
            return List.of("100", "500", "1000", "5000");
        }
        return Collections.emptyList();
    }

    private List<String> filter(List<String> options, String input) {
        return options.stream()
                .filter(s -> s.toLowerCase().startsWith(input.toLowerCase()))
                .collect(Collectors.toList());
    }

    private List<String> filterPlayers(String input) {
        return Bukkit.getOnlinePlayers().stream()
                .map(Player::getName)
                .filter(n -> n.toLowerCase().startsWith(input.toLowerCase()))
                .collect(Collectors.toList());
    }
}
