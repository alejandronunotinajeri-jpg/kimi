package com.ethernova.progression.battlepass;

/**
 * Represents a single tier in the battle pass.
 */
public record BattlePassTier(
        int tier,
        double xpRequired,
        String freeReward,
        String premiumReward
) {}
