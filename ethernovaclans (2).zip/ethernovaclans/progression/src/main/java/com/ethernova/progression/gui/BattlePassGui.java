package com.ethernova.progression.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.PaginatedGui;
import com.ethernova.progression.EthernovaProgression;
import com.ethernova.progression.battlepass.BattlePassTier;
import com.ethernova.progression.message.MessageManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Paginated battle pass GUI showing tiers with claim buttons.
 */
public class BattlePassGui extends PaginatedGui {

    private final EthernovaProgression progression;

    public BattlePassGui(EthernovaCore core, EthernovaProgression progression, Player player) {
        super(core, player);
        this.progression = progression;
    }

    private MessageManager mm() { return progression.getMessageManager(); }

    public void open() {
        openPaginated(getTitle(), 0);
    }

    @Override
    protected String getTitle() {
        String season = progression.getBattlePassManager().getSeasonName();
        return mm().get("gui.battlepass.title", "{season}", season);
    }

    @Override
    protected List<PageItem> getPageItems() {
        UUID uuid = player.getUniqueId();
        int currentTier = progression.getBattlePassManager().getTier(uuid);
        boolean premium = progression.getBattlePassManager().isPremium(uuid);
        List<BattlePassTier> tiers = progression.getBattlePassManager().getTiers();
        List<PageItem> items = new ArrayList<>();

        for (BattlePassTier tier : tiers) {
            boolean unlocked = currentTier >= tier.tier();
            boolean freeClaimed = progression.getBattlePassManager().hasClaimedFreeReward(uuid, tier.tier());
            boolean premiumClaimed = progression.getBattlePassManager().hasClaimedPremiumReward(uuid, tier.tier());

            Material icon;
            String nameColor;

            if (!unlocked) {
                icon = Material.GRAY_DYE;
                nameColor = "<dark_gray>";
            } else if (freeClaimed && (!premium || premiumClaimed)) {
                icon = Material.LIME_DYE;
                nameColor = "<green>";
            } else {
                icon = Material.YELLOW_DYE;
                nameColor = "<yellow>";
            }

            // Milestone tiers get special icons
            if (tier.tier() % 10 == 0) {
                icon = unlocked ? Material.DIAMOND : Material.COAL;
            } else if (tier.tier() % 5 == 0) {
                icon = unlocked ? Material.GOLD_INGOT : Material.IRON_NUGGET;
            }

            List<String> lore = new ArrayList<>();
            lore.add("");
            lore.add(unlocked ? mm().get("gui.battlepass.unlocked") : mm().get("gui.battlepass.locked"));
            lore.add("");

            // Free reward
            String freeStatus;
            if (freeClaimed) {
                freeStatus = mm().get("gui.battlepass.claimed");
            } else if (unlocked) {
                freeStatus = mm().get("gui.battlepass.claim-click");
            } else {
                freeStatus = mm().get("gui.battlepass.blocked");
            }
            lore.add(mm().get("gui.battlepass.free-reward") + " " + formatReward(tier.freeReward()));
            lore.add("  " + freeStatus);

            // Premium reward
            String premiumStatus;
            if (!premium) {
                premiumStatus = mm().get("gui.battlepass.premium-required");
            } else if (premiumClaimed) {
                premiumStatus = mm().get("gui.battlepass.claimed");
            } else if (unlocked) {
                premiumStatus = mm().get("gui.battlepass.claim-click");
            } else {
                premiumStatus = mm().get("gui.battlepass.blocked");
            }
            lore.add("");
            lore.add(mm().get("gui.battlepass.premium-reward") + " " + formatReward(tier.premiumReward()));
            lore.add("  " + premiumStatus);

            lore.add("");
            lore.add(mm().get("gui.battlepass.xp-required",
                    "{xp}", String.format("%.0f", tier.xpRequired())));

            ItemStack item = createItem(icon,
                    nameColor + mm().get("gui.battlepass.tier-name", "{tier}", String.valueOf(tier.tier()))
                            + "</" + nameColor.substring(1),
                    lore);

            if (unlocked && freeClaimed && (!premium || premiumClaimed)) {
                ItemMeta meta = item.getItemMeta();
                if (meta != null) {
                    meta.setEnchantmentGlintOverride(true);
                    item.setItemMeta(meta);
                }
            }

            items.add(new PageItem(item, "TIER_" + tier.tier()));
        }

        return items;
    }

    @Override
    protected boolean onItemClick(String action, int slot, InventoryClickEvent event) {
        if (action.startsWith("TIER_")) {
            try {
                int tier = Integer.parseInt(action.substring(5));
                UUID uuid = player.getUniqueId();
                int currentTier = progression.getBattlePassManager().getTier(uuid);

                if (currentTier < tier) {
                    playSound("error");
                    mm().sendMessage(player, "battlepass.tier-locked",
                            "{tier}", String.valueOf(tier));
                    return true;
                }

                // Try to claim free reward first
                boolean freeClaimed = progression.getBattlePassManager().hasClaimedFreeReward(uuid, tier);
                if (!freeClaimed) {
                    String reward = progression.getBattlePassManager().claimFreeReward(player, tier);
                    if (reward != null) {
                        playSound("success");
                        openPaginated(getTitle(), currentPage);
                        return true;
                    }
                }

                // Try premium reward
                boolean premiumClaimed = progression.getBattlePassManager().hasClaimedPremiumReward(uuid, tier);
                if (!premiumClaimed && progression.getBattlePassManager().isPremium(uuid)) {
                    String reward = progression.getBattlePassManager().claimPremiumReward(player, tier);
                    if (reward != null) {
                        playSound("success");
                        openPaginated(getTitle(), currentPage);
                        return true;
                    }
                }

                // Already all claimed
                playSound("click");
            } catch (NumberFormatException ignored) {}
            return true;
        }
        return false;
    }

    @Override
    protected void onBack() {
        LevelGui gui = new LevelGui(core, progression, player);
        core.getGuiManager().registerGui(player, gui);
        gui.open();
    }

    private String formatReward(String reward) {
        if (reward == null || reward.isEmpty()) return "<gray>-</gray>";
        String[] parts = reward.split(":", 2);
        String type = parts[0];
        String value = parts.length > 1 ? parts[1] : "";

        return switch (type) {
            case "coins" -> mm().get("gui.battlepass.reward-type.coins", "{value}", value);
            case "cosmetic" -> mm().get("gui.battlepass.reward-type.cosmetic", "{value}", value);
            case "title" -> mm().get("gui.battlepass.reward-type.title", "{value}", value);
            default -> "<gray>" + reward + "</gray>";
        };
    }
}
