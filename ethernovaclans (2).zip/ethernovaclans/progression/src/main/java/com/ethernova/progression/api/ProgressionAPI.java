package com.ethernova.progression.api;

import com.ethernova.progression.achievement.Achievement;
import com.ethernova.progression.mission.Mission;
import org.bukkit.entity.Player;

import java.util.Collection;
import java.util.List;
import java.util.UUID;

/**
 * Public API interface for EthernovaProgression.
 *
 * <p>Provides methods for leveling, prestige, achievements, missions,
 * and the battle pass system.</p>
 *
 * <p>Obtain an instance via {@code ServiceRegistry.get(ProgressionAPI.class)}.</p>
 *
 * <p>All methods are thread-safe. Write operations (addXP, incrementAchievement, etc.)
 * should be called from the main server thread when a {@link Player} parameter is required.</p>
 */
public interface ProgressionAPI {

    // ═══════════════ Leveling ═══════════════

    /**
     * Get the XP required to complete a specific level.
     *
     * @param level the level number (1-based)
     * @return the XP required to advance past this level
     */
    long getXPForLevel(int level);

    /**
     * Get the total cumulative XP needed to reach a level from level 0.
     *
     * @param level the target level
     * @return the total XP required from the start
     */
    long getTotalXPForLevel(int level);

    /**
     * Get the maximum level cap.
     *
     * @return the highest achievable level
     */
    int getMaxLevel();

    /**
     * Add XP to a player with multipliers and level-up handling.
     *
     * @param player the player to grant XP to
     * @param amount the base XP amount to add (before multipliers)
     */
    void addXP(Player player, long amount);

    // ═══════════════ Prestige ═══════════════

    /**
     * Get the XP multiplier for a given prestige tier.
     *
     * @param prestige the prestige tier number
     * @return the XP multiplier (e.g., {@code 1.5} for 50% bonus)
     */
    double getPrestigeMultiplier(int prestige);

    /**
     * Get the display name for a prestige tier.
     *
     * @param prestige the prestige tier number
     * @return the formatted display name with color codes
     */
    String getPrestigeDisplay(int prestige);

    /**
     * Get the maximum prestige level.
     *
     * @return the highest achievable prestige tier
     */
    int getMaxPrestige();

    // ═══════════════ Achievements ═══════════════

    /**
     * Check if a player has completed an achievement.
     *
     * @param uuid          the UUID of the player
     * @param achievementId the achievement identifier
     * @return {@code true} if the achievement is completed
     */
    boolean isAchievementCompleted(UUID uuid, String achievementId);

    /**
     * Get the current progress value for an achievement.
     *
     * @param uuid          the UUID of the player
     * @param achievementId the achievement identifier
     * @return the current progress count
     */
    int getAchievementProgress(UUID uuid, String achievementId);

    /**
     * Increment achievement progress for a player.
     *
     * @param player        the player to update
     * @param achievementId the achievement identifier
     * @param amount        the amount to increment by
     */
    void incrementAchievement(Player player, String achievementId, int amount);

    /**
     * Get the number of completed achievements for a player.
     *
     * @param uuid the UUID of the player
     * @return the count of completed achievements
     */
    int getCompletedAchievementCount(UUID uuid);

    /**
     * Get the total number of registered achievements.
     *
     * @return the total achievement count
     */
    int getTotalAchievementCount();

    /**
     * Get all registered achievements.
     *
     * @return an unmodifiable collection of all {@link Achievement} definitions
     */
    Collection<Achievement> getAllAchievements();

    // ═══════════════ Missions ═══════════════

    /**
     * Get all active missions for a player.
     *
     * @param uuid the UUID of the player
     * @return a list of currently active {@link Mission} instances
     */
    List<Mission> getActiveMissions(UUID uuid);

    /**
     * Get the current progress for a specific mission.
     *
     * @param uuid      the UUID of the player
     * @param missionId the mission identifier
     * @return the current progress count
     */
    int getMissionProgress(UUID uuid, String missionId);

    /**
     * Check if a mission is completed by a player.
     *
     * @param uuid      the UUID of the player
     * @param missionId the mission identifier
     * @return {@code true} if the mission is completed
     */
    boolean isMissionCompleted(UUID uuid, String missionId);

    /**
     * Increment mission progress for a player.
     *
     * @param player    the player to update
     * @param missionId the mission identifier
     * @param amount    the amount to increment by
     */
    void incrementMission(Player player, String missionId, int amount);

    /**
     * Get the count of completed daily missions for a player.
     *
     * @param uuid the UUID of the player
     * @return the number of daily missions completed today
     */
    int getCompletedDailyMissionCount(UUID uuid);

    // ═══════════════ Battle Pass ═══════════════

    /**
     * Get the current battle pass tier for a player.
     *
     * @param uuid the UUID of the player
     * @return the current tier (0 means not started)
     */
    int getBattlePassTier(UUID uuid);

    /**
     * Get the total battle pass XP accumulated by a player.
     *
     * @param uuid the UUID of the player
     * @return the total battle pass XP
     */
    long getBattlePassXP(UUID uuid);

    /**
     * Add XP to a player's battle pass.
     *
     * @param player the player to grant battle pass XP to
     * @param amount the amount of XP to add
     */
    void addBattlePassXP(Player player, long amount);

    /**
     * Check if a player has a premium battle pass.
     *
     * @param uuid the UUID of the player
     * @return {@code true} if the player owns the premium battle pass
     */
    boolean isBattlePassPremium(UUID uuid);

    /**
     * Get the progress within the current battle pass tier.
     *
     * @param uuid the UUID of the player
     * @return progress as a value between {@code 0.0} (start) and {@code 1.0} (complete)
     */
    double getBattlePassProgress(UUID uuid);

    /**
     * Get the current battle pass season name.
     *
     * @return the display name of the active season
     */
    String getBattlePassSeasonName();
}
