package com.ethernova.progression.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.PaginatedGui;
import com.ethernova.progression.EthernovaProgression;
import com.ethernova.progression.achievement.Achievement;
import com.ethernova.progression.achievement.AchievementCategory;
import com.ethernova.progression.message.MessageManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Paginated achievements GUI showing progress by category.
 */
public class AchievementGui extends PaginatedGui {

    private final EthernovaProgression progression;
    private AchievementCategory selectedCategory;

    public AchievementGui(EthernovaCore core, EthernovaProgression progression, Player player) {
        super(core, player);
        this.progression = progression;
        this.selectedCategory = null; // Show all categories first
    }

    private MessageManager mm() { return progression.getMessageManager(); }

    public void open() {
        if (selectedCategory == null) {
            openCategorySelection();
        } else {
            openPaginated(getTitle(), 0);
        }
    }

    private void openCategorySelection() {
        openInventory(mm().get("gui.achievement.title-categories"), 45);
    }

    @Override
    protected void populateItems() {
        UUID uuid = player.getUniqueId();
        int totalCompleted = progression.getAchievementManager().getCompletedCount(uuid);
        int totalAchievements = progression.getAchievementManager().getTotalCount();

        // Summary item
        setItem(4, createItem(Material.GOLDEN_APPLE,
                mm().get("gui.achievement.summary-name"),
                List.of(
                        "",
                        mm().get("gui.achievement.summary-completed",
                                "{completed}", String.valueOf(totalCompleted),
                                "{total}", String.valueOf(totalAchievements)),
                        mm().get("gui.achievement.summary-progress",
                                "{progress}", totalAchievements > 0
                                        ? String.format("%.1f", (double) totalCompleted / totalAchievements * 100)
                                        : "0")
                )
        ));

        // Category buttons
        int[] categorySlots = {20, 21, 22, 23, 24};
        AchievementCategory[] categories = AchievementCategory.values();
        for (int i = 0; i < categories.length && i < categorySlots.length; i++) {
            AchievementCategory cat = categories[i];
            List<Achievement> catAchievements = progression.getAchievementManager().getByCategory(cat);
            long completed = catAchievements.stream()
                    .filter(a -> progression.getAchievementManager().isCompleted(uuid, a.id()))
                    .count();

            String catDisplayName = mm().get("achievement.category." + cat.name().toLowerCase());

            setItem(categorySlots[i], createItem(cat.getIcon(),
                    "<yellow>" + catDisplayName + "</yellow>",
                    List.of(
                            "",
                            mm().get("gui.achievement.category-count",
                                    "{completed}", String.valueOf(completed),
                                    "{total}", String.valueOf(catAchievements.size())),
                            "",
                            mm().get("gui.achievement.category-click")
                    )
            ));
            slotActions.put(categorySlots[i], "CAT_" + cat.name());
        }

        // Back to LevelGui
        setItem(40, createItem(Material.ARROW, mm().get("gui.achievement.close")));
        slotActions.put(40, "BACK");
    }

    @Override
    protected String getTitle() {
        if (selectedCategory == null) {
            return mm().get("gui.achievement.title-categories");
        }
        String catName = mm().get("achievement.category." + selectedCategory.name().toLowerCase());
        return mm().get("gui.achievement.title-category", "{category}", catName);
    }

    @Override
    protected List<PageItem> getPageItems() {
        if (selectedCategory == null) return List.of();

        UUID uuid = player.getUniqueId();
        List<Achievement> categoryAchievements = progression.getAchievementManager().getByCategory(selectedCategory);
        List<PageItem> items = new ArrayList<>();

        for (Achievement achievement : categoryAchievements) {
            boolean completed = progression.getAchievementManager().isCompleted(uuid, achievement.id());
            int progress = progression.getAchievementManager().getProgress(uuid, achievement.id());
            double progressPercent = achievement.target() > 0 ? (double) progress / achievement.target() * 100 : 0;
            progressPercent = Math.min(100, progressPercent);

            // Build progress bar
            int barLength = 20;
            int filled = (int) (progressPercent / 100 * barLength);
            StringBuilder bar = new StringBuilder();
            for (int j = 0; j < barLength; j++) {
                if (j < filled) bar.append("<green>█</green>");
                else bar.append("<dark_gray>░</dark_gray>");
            }

            Material icon = completed ? Material.LIME_DYE : achievement.icon();
            String achName = mm().get("achievement.name." + achievement.id());
            String achDesc = mm().get("achievement.desc." + achievement.id());
            String nameColor = completed ? "<green>" : "<yellow>";
            String statusLine = completed
                    ? mm().get("gui.achievement.completed-label")
                    : mm().get("gui.achievement.progress-label",
                            "{current}", String.valueOf(progress),
                            "{target}", String.valueOf(achievement.target()),
                            "{progress}", String.format("%.1f", progressPercent));

            List<String> lore = new ArrayList<>();
            lore.add("");
            lore.add("<gray>" + achDesc + "</gray>");
            lore.add("");
            lore.add(bar.toString());
            lore.add(statusLine);
            lore.add("");
            lore.add(mm().get("gui.achievement.reward-label",
                    "{coins}", String.format("%.0f", achievement.coinReward()),
                    "{xp}", String.valueOf(achievement.xpReward())));
            if (achievement.cosmeticReward() != null && !achievement.cosmeticReward().isEmpty()) {
                lore.add("<gradient:#a855f7:#ec4899>🎁 Cosmético exclusivo: " + achievement.cosmeticReward() + "</gradient>");
            }

            ItemStack item = createItem(icon, nameColor + achName + "</" + nameColor.substring(1), lore);
            if (completed) {
                ItemMeta meta = item.getItemMeta();
                if (meta != null) {
                    meta.setEnchantmentGlintOverride(true);
                    item.setItemMeta(meta);
                }
            }

            items.add(new PageItem(item, "ACH_" + achievement.id()));
        }

        return items;
    }

    @Override
    protected boolean onItemClick(String action, int slot, InventoryClickEvent event) {
        if (action.startsWith("ACH_")) {
            playSound("click");
            return true;
        }
        return false;
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.startsWith("CAT_")) {
            playSound("click");
            String catName = action.substring(4);
            try {
                selectedCategory = AchievementCategory.valueOf(catName);
                openPaginated(getTitle(), 0);
            } catch (IllegalArgumentException ignored) {}
            return true;
        }

        return super.processAction(action, slot, event);
    }

    @Override
    protected void onBack() {
        if (selectedCategory != null) {
            selectedCategory = null;
            openCategorySelection();
        } else {
            LevelGui gui = new LevelGui(core, progression, player);
            core.getGuiManager().registerGui(player, gui);
            gui.open();
        }
    }
}
