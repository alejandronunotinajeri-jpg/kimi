package com.ethernova.progression.api;

import com.ethernova.progression.EthernovaProgression;
import com.ethernova.progression.achievement.Achievement;
import com.ethernova.progression.level.XPSource;
import com.ethernova.progression.mission.Mission;
import org.bukkit.entity.Player;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 * Implementation of ProgressionAPI. Registered with ServiceRegistry on enable.
 */
public class ProgressionAPIImpl implements ProgressionAPI {

    private final EthernovaProgression plugin;

    public ProgressionAPIImpl(EthernovaProgression plugin) {
        this.plugin = plugin;
    }

    // ═══════════════ Leveling ═══════════════

    @Override
    public long getXPForLevel(int level) {
        return plugin.getLevelManager().getXPForLevel(level);
    }

    @Override
    public long getTotalXPForLevel(int level) {
        return plugin.getLevelManager().getTotalXPForLevel(level);
    }

    @Override
    public int getMaxLevel() {
        return plugin.getLevelManager().getMaxLevel();
    }

    @Override
    public void addXP(Player player, long amount) {
        plugin.getLevelManager().addXP(player, amount, XPSource.ADMIN);
    }

    // ═══════════════ Prestige ═══════════════

    @Override
    public double getPrestigeMultiplier(int prestige) {
        return plugin.getPrestigeManager().getMultiplier(prestige);
    }

    @Override
    public String getPrestigeDisplay(int prestige) {
        return plugin.getPrestigeManager().getPrestigeDisplay(prestige);
    }

    @Override
    public int getMaxPrestige() {
        return plugin.getPrestigeManager().getMaxPrestige();
    }

    // ═══════════════ Achievements ═══════════════

    @Override
    public boolean isAchievementCompleted(UUID uuid, String achievementId) {
        return plugin.getAchievementManager().isCompleted(uuid, achievementId);
    }

    @Override
    public int getAchievementProgress(UUID uuid, String achievementId) {
        return plugin.getAchievementManager().getProgress(uuid, achievementId);
    }

    @Override
    public void incrementAchievement(Player player, String achievementId, int amount) {
        plugin.getAchievementManager().checkProgress(player, achievementId, amount);
    }

    @Override
    public int getCompletedAchievementCount(UUID uuid) {
        return plugin.getAchievementManager().getCompletedCount(uuid);
    }

    @Override
    public int getTotalAchievementCount() {
        return plugin.getAchievementManager().getTotalCount();
    }

    @Override
    public Collection<Achievement> getAllAchievements() {
        return plugin.getAchievementManager().getAllAchievements();
    }

    // ═══════════════ Missions ═══════════════

    @Override
    public List<Mission> getActiveMissions(UUID uuid) {
        return plugin.getMissionManager().getActiveMissions(uuid);
    }

    @Override
    public int getMissionProgress(UUID uuid, String missionId) {
        return plugin.getMissionManager().getProgress(uuid, missionId);
    }

    @Override
    public boolean isMissionCompleted(UUID uuid, String missionId) {
        return plugin.getMissionManager().isCompleted(uuid, missionId);
    }

    @Override
    public void incrementMission(Player player, String missionId, int amount) {
        plugin.getMissionManager().incrementProgress(player, missionId, amount);
    }

    @Override
    public int getCompletedDailyMissionCount(UUID uuid) {
        return plugin.getMissionManager().getCompletedDailyCount(uuid);
    }

    // ═══════════════ Battle Pass ═══════════════

    @Override
    public int getBattlePassTier(UUID uuid) {
        return plugin.getBattlePassManager().getTier(uuid);
    }

    @Override
    public long getBattlePassXP(UUID uuid) {
        return plugin.getBattlePassManager().getXP(uuid);
    }

    @Override
    public void addBattlePassXP(Player player, long amount) {
        plugin.getBattlePassManager().addXP(player, amount);
    }

    @Override
    public boolean isBattlePassPremium(UUID uuid) {
        return plugin.getBattlePassManager().isPremium(uuid);
    }

    @Override
    public double getBattlePassProgress(UUID uuid) {
        return plugin.getBattlePassManager().getTierProgress(uuid);
    }

    @Override
    public String getBattlePassSeasonName() {
        return plugin.getBattlePassManager().getSeasonName();
    }
}
