package com.ethernova.progression.prestige;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.event.PrestigeEvent;
import com.ethernova.core.profile.PlayerProfile;
import com.ethernova.progression.EthernovaProgression;
import com.ethernova.progression.message.MessageManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Prestige system — 10 prestige tiers with kills + money requirements.
 * Ported faithfully from original UltimateFFA PrestigeManager.
 *
 * Each tier requires: kills threshold, money cost.
 * Each tier grants: money reward, money bonus %, shop discount %, visual effects.
 */
public class PrestigeManager {

    private final EthernovaProgression plugin;
    private final EthernovaCore core;
    private final MiniMessage mini = MiniMessage.miniMessage();

    private int maxPrestige;

    /** Prestige tier data: [killsReq, moneyCost, moneyReward, moneyBonusPct, shopDiscountPct] */
    private int[][] prestigeData;

    private String[] prestigePrefixes;

    /** Hardcoded defaults used when config section is missing. */
    private static final int[][] DEFAULT_PRESTIGE_DATA = {
        {   100,        0,      5000,      5,      5 },
        {   250,    25000,     10000,     10,      7 },
        {   500,    75000,     25000,     15,     10 },
        {   750,   150000,     50000,     20,     12 },
        {  1000,   300000,     75000,     25,     15 },
        {  2000,   500000,    100000,     35,     17 },
        {  3000,   800000,    150000,     50,     18 },
        {  4000,  1500000,    250000,     75,     19 },
        {  5000,  2500000,    500000,     90,     20 },
        {  7500,  3000000,   2500000,    100,     20 },
    };

    private static final String[] DEFAULT_PRESTIGE_PREFIXES = {
        "§e★", "§e★★", "§e★★★", "§b✦", "§b✦✦",
        "§d♦", "§c♦ Veterano ♦", "§c✦ Elite ✦", "§6✦ Leyenda ✦", "§d✦ Mítico ✦"
    };

    /** XP multiplier per prestige level (kept for compatibility with LevelManager). */
    private final Map<Integer, Double> prestigeMultipliers = new ConcurrentHashMap<>();

    public PrestigeManager(EthernovaProgression plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
        loadTiersFromConfig();
        loadMultipliers();
    }

    private MessageManager mm() { return plugin.getMessageManager(); }

    /**
     * Load tier definitions from config.yml, falling back to hardcoded defaults.
     */
    private void loadTiersFromConfig() {
        var config = plugin.getProgressionConfig();
        maxPrestige = config.getInt("prestige.max-prestige", 10);

        prestigeData = new int[maxPrestige][5];
        prestigePrefixes = new String[maxPrestige];

        var tiersSection = config.getConfig().getConfigurationSection("prestige.tiers");
        for (int i = 1; i <= maxPrestige; i++) {
            int[] defaults = (i <= DEFAULT_PRESTIGE_DATA.length) ? DEFAULT_PRESTIGE_DATA[i - 1] : new int[]{i * 1000, i * 100000, i * 50000, 10 * i, 5};
            String defaultPrefix = (i <= DEFAULT_PRESTIGE_PREFIXES.length) ? DEFAULT_PRESTIGE_PREFIXES[i - 1] : "§e★" + i;

            if (tiersSection != null && tiersSection.contains(String.valueOf(i))) {
                var tier = tiersSection.getConfigurationSection(String.valueOf(i));
                prestigeData[i - 1] = new int[]{
                    tier.getInt("kills", defaults[0]),
                    tier.getInt("cost", defaults[1]),
                    tier.getInt("reward", defaults[2]),
                    tier.getInt("bonus-pct", defaults[3]),
                    tier.getInt("discount-pct", defaults[4])
                };
                String cfgPrefix = tier.getString("prefix", null);
                if (cfgPrefix != null) {
                    // Convert MiniMessage prefix to legacy for compatibility
                    prestigePrefixes[i - 1] = LegacyComponentSerializer.legacySection()
                            .serialize(mini.deserialize(cfgPrefix));
                } else {
                    prestigePrefixes[i - 1] = defaultPrefix;
                }
            } else {
                prestigeData[i - 1] = defaults;
                prestigePrefixes[i - 1] = defaultPrefix;
            }
        }
    }

    private void loadMultipliers() {
        prestigeMultipliers.put(0, 1.0);
        var config = plugin.getProgressionConfig();
        for (int i = 1; i <= maxPrestige; i++) {
            double configValue = config.getDouble("prestige.multipliers." + i, -1);
            if (configValue > 0) {
                prestigeMultipliers.put(i, configValue);
            } else {
                double bonus = prestigeData[i - 1][3];
                prestigeMultipliers.put(i, 1.0 + (bonus / 100.0));
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //                 PRESTIGE CHECK & EXECUTE
    // ═══════════════════════════════════════════════════════════════

    /**
     * Attempt to prestige a player (called from confirmation GUI).
     */
    public boolean prestige(Player player) {
        PlayerProfile profile = core.getProfileManager().getProfile(player.getUniqueId());
        if (profile == null) return false;

        int currentPrestige = profile.getPrestige();
        if (currentPrestige >= maxPrestige) {
            player.sendMessage("§c§l✖ §cYa estás en el prestigio máximo §d✦ Mítico ✦");
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return false;
        }

        int nextTier = currentPrestige + 1;
        int[] data = prestigeData[currentPrestige]; // 0-indexed
        int killsReq = data[0];
        int moneyCost = data[1];
        int moneyReward = data[2];

        // Check kills
        if (profile.getKills() < killsReq) {
            player.sendMessage("§c§l✖ §cNecesitas §e" + killsReq + " kills §cpara prestigiar. Tienes: §e" + profile.getKills());
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return false;
        }

        // Check money (via Vault)
        if (moneyCost > 0) {
            var econ = core.getEconomyHook();
            if (!econ.has(player, moneyCost)) {
                player.sendMessage("§c§l✖ §cNecesitas §6$" + String.format("%,d", moneyCost) + " §cpara prestigiar.");
                player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                return false;
            }
            econ.withdraw(player, moneyCost);
        }

        // Grant reward
        if (moneyReward > 0) {
            core.getEconomyHook().deposit(player, moneyReward);
        }

        int oldPrestige = currentPrestige;
        profile.setPrestige(nextTier);
        profile.setLevel(1);
        profile.setXP(0);

        // Publish event
        core.getEventBus().publish(new PrestigeEvent(
                player.getUniqueId(), player.getName(), oldPrestige, nextTier));

        // Visual feedback
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!player.isOnline()) return;

            core.getSoundManager().play(player, "prestige");
            player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);

            // Title
            player.showTitle(Title.title(
                    mini.deserialize("<gold><bold>★ PRESTIGIO " + getRomanNumeral(nextTier) + " ★</bold></gold>"),
                    LegacyComponentSerializer.legacySection().deserialize("§e" + prestigePrefixes[nextTier - 1] + " §7| Bonus: §a+" + data[3] + "%"),
                    Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(3), Duration.ofMillis(800))
            ));

            // Message
            player.sendMessage("");
            player.sendMessage("§8§m--------------------------------------");
            player.sendMessage("   §6§l★ ¡PRESTIGIO " + getRomanNumeral(nextTier) + "! ★");
            player.sendMessage("   §fRango: " + prestigePrefixes[nextTier - 1]);
            if (moneyCost > 0) player.sendMessage("   §fCosto: §c-$" + String.format("%,d", moneyCost));
            if (moneyReward > 0) player.sendMessage("   §fRecompensa: §a+$" + String.format("%,d", moneyReward));
            player.sendMessage("   §fBonus de dinero: §a+" + data[3] + "%");
            player.sendMessage("   §fDescuento en tienda: §a" + data[4] + "%");
            player.sendMessage("§8§m--------------------------------------");

            // Broadcast
            Bukkit.broadcast(mini.deserialize(
                    "<gold>★</gold> <yellow><bold>" + player.getName() + "</bold></yellow> <gold>ha alcanzado Prestigio " +
                    getRomanNumeral(nextTier) + "!</gold> <gray>" + prestigePrefixes[nextTier - 1]));

            // Visual effects per tier
            playPrestigeEffects(player, nextTier);
        });

        return true;
    }

    // ═══════════════════════════════════════════════════════════════
    //                  CONFIRMATION GUI
    // ═══════════════════════════════════════════════════════════════

    /**
     * Open the prestige confirmation GUI.
     */
    public void openConfirmationGUI(Player player) {
        PlayerProfile profile = core.getProfileManager().getProfile(player.getUniqueId());
        if (profile == null) return;

        int currentPrestige = profile.getPrestige();
        if (currentPrestige >= maxPrestige) {
            player.sendMessage("§c§l✖ §cYa estás en el prestigio máximo.");
            return;
        }

        int nextTier = currentPrestige + 1;
        int[] data = prestigeData[currentPrestige];

        Inventory inv = Bukkit.createInventory(null, 27, "§c§l¿CONFIRMAR PRESTIGIO?");

        // Fill with glass
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fm = filler.getItemMeta();
        fm.setDisplayName(" ");
        filler.setItemMeta(fm);
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);

        // Confirm button (slot 11)
        ItemStack confirm = new ItemStack(Material.LIME_CONCRETE);
        ItemMeta confirmMeta = confirm.getItemMeta();
        confirmMeta.setDisplayName("§a§l✓ CONFIRMAR");
        List<String> confirmLore = new ArrayList<>();
        confirmLore.add("");
        confirmLore.add("§7Prestigio: " + prestigePrefixes[nextTier - 1]);
        confirmLore.add("");
        confirmLore.add("§7Requisitos:");
        confirmLore.add("  §fKills: §e" + data[0] + " §7(Tienes: §e" + profile.getKills() + "§7)");
        if (data[1] > 0) confirmLore.add("  §fCosto: §6$" + String.format("%,d", data[1]));
        confirmLore.add("");
        confirmLore.add("§7Recompensas:");
        if (data[2] > 0) confirmLore.add("  §fDinero: §a+$" + String.format("%,d", data[2]));
        confirmLore.add("  §fBonus de dinero: §a+" + data[3] + "%");
        confirmLore.add("  §fDescuento tienda: §a" + data[4] + "%");
        confirmLore.add("");
        confirmLore.add("§c⚠ Tu nivel se reiniciará a 1");
        confirmLore.add("");
        confirmLore.add("§e► Clic para confirmar");
        confirmMeta.setLore(confirmLore);
        confirm.setItemMeta(confirmMeta);
        inv.setItem(11, confirm);

        // Cancel button (slot 15)
        ItemStack cancel = new ItemStack(Material.RED_CONCRETE);
        ItemMeta cancelMeta = cancel.getItemMeta();
        cancelMeta.setDisplayName("§c§l✗ CANCELAR");
        List<String> cancelLore = new ArrayList<>();
        cancelLore.add("");
        cancelLore.add("§7Volver sin cambios");
        cancelMeta.setLore(cancelLore);
        cancel.setItemMeta(cancelMeta);
        inv.setItem(15, cancel);

        player.openInventory(inv);
    }

    // ═══════════════════════════════════════════════════════════════
    //                    VISUAL EFFECTS
    // ═══════════════════════════════════════════════════════════════

    private void playPrestigeEffects(Player player, int tier) {
        org.bukkit.Location loc = player.getLocation();
        switch (tier) {
            case 1, 2, 3 -> {
                // Yellow/gold particles
                Particle.DustOptions gold = new Particle.DustOptions(org.bukkit.Color.fromRGB(255, 215, 0), 1.5f);
                loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 2, 0), 50, 1, 1, 1, 0, gold);
            }
            case 4, 5 -> {
                // Rainbow particles
                for (int i = 0; i < 7; i++) {
                    org.bukkit.Color c = org.bukkit.Color.fromRGB(
                            (int)(Math.random() * 255), (int)(Math.random() * 255), (int)(Math.random() * 255));
                    Particle.DustOptions dust = new Particle.DustOptions(c, 1.5f);
                    loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 2, 0), 20, 1.5, 1.5, 1.5, 0, dust);
                }
            }
            case 6 -> {
                // Purple aura
                Particle.DustOptions purple = new Particle.DustOptions(org.bukkit.Color.fromRGB(170, 0, 255), 2.0f);
                loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 2, 0), 60, 1.5, 1.5, 1.5, 0, purple);
                loc.getWorld().spawnParticle(Particle.WITCH, loc.clone().add(0, 1.5, 0), 30, 1, 1, 1, 0);
            }
            case 7 -> {
                // Fire aura
                loc.getWorld().spawnParticle(Particle.FLAME, loc.clone().add(0, 1, 0), 60, 1.5, 1.5, 1.5, 0.05);
                loc.getWorld().spawnParticle(Particle.LAVA, loc, 20, 1, 0.5, 1, 0);
            }
            case 8 -> {
                // Red flames
                loc.getWorld().spawnParticle(Particle.FLAME, loc.clone().add(0, 1.5, 0), 80, 2, 2, 2, 0.05);
                Particle.DustOptions red = new Particle.DustOptions(org.bukkit.Color.RED, 2.0f);
                loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 2, 0), 50, 1.5, 1.5, 1.5, 0, red);
            }
            case 9 -> {
                // Epic gold trail
                loc.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, loc.clone().add(0, 1, 0), 100, 2, 2, 2, 0.3);
                loc.getWorld().strikeLightningEffect(loc);
            }
            case 10 -> {
                // Mythic aura — everything
                loc.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, loc.clone().add(0, 1, 0), 150, 3, 3, 3, 0.5);
                loc.getWorld().spawnParticle(Particle.END_ROD, loc.clone().add(0, 2, 0), 80, 2, 2, 2, 0.1);
                loc.getWorld().strikeLightningEffect(loc);
                loc.getWorld().strikeLightningEffect(loc.clone().add(2, 0, 0));
                loc.getWorld().strikeLightningEffect(loc.clone().add(-2, 0, 0));
                loc.getWorld().strikeLightningEffect(loc.clone().add(0, 0, 2));
                loc.getWorld().strikeLightningEffect(loc.clone().add(0, 0, -2));
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //                    GETTERS / UTILITIES
    // ═══════════════════════════════════════════════════════════════

    public double getMultiplier(int prestige) {
        return prestigeMultipliers.getOrDefault(prestige, 1.0);
    }

    public int getMoneyBonusPercent(int prestige) {
        if (prestige <= 0 || prestige > maxPrestige) return 0;
        return prestigeData[prestige - 1][3];
    }

    public int getShopDiscountPercent(int prestige) {
        if (prestige <= 0 || prestige > maxPrestige) return 0;
        return prestigeData[prestige - 1][4];
    }

    public String getPrestigePrefix(int prestige) {
        if (prestige <= 0 || prestige > maxPrestige) return "";
        return prestigePrefixes[prestige - 1];
    }

    public String getPrestigeDisplay(int prestige) {
        if (prestige <= 0) return mm().get("prestige.display.none");
        return prestigePrefixes[prestige - 1];
    }

    public String getPrestigeColor(int prestige) {
        return mm().get("prestige.color." + prestige);
    }

    public int getMaxPrestige() { return maxPrestige; }

    public boolean canPrestige(PlayerProfile profile) {
        int current = profile.getPrestige();
        if (current >= maxPrestige) return false;
        int[] data = prestigeData[current];
        return profile.getKills() >= data[0];
    }

    /**
     * Handle click in prestige confirmation GUI.
     */
    public void handleConfirmClick(Player player, int slot) {
        if (slot == 11) {
            player.closeInventory();
            prestige(player);
        } else if (slot == 15) {
            player.closeInventory();
            player.sendMessage("§7Prestigio cancelado.");
        }
    }

    private String getRomanNumeral(int num) {
        return switch (num) {
            case 1 -> "I"; case 2 -> "II"; case 3 -> "III"; case 4 -> "IV";
            case 5 -> "V"; case 6 -> "VI"; case 7 -> "VII"; case 8 -> "VIII";
            case 9 -> "IX"; case 10 -> "X";
            default -> String.valueOf(num);
        };
    }
}
