package com.ethernova.progression.daily;

import com.ethernova.core.EthernovaCore;
import com.ethernova.progression.EthernovaProgression;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.stream.Collectors;

/**
 * Manages the 7-day daily reward cycle from the original UltimateFFA.
 * Players can claim one reward per day, cycling through 7 reward tiers.
 * Consecutive daily claims increase the reward tier; missing a day resets to day 1.
 */
public class DailyRewardManager {

    private final EthernovaProgression plugin;
    private final EthernovaCore core;
    private final MiniMessage mini = MiniMessage.miniMessage();

    // Cached daily reward state per player
    private final Map<UUID, DailyRewardState> stateCache = new ConcurrentHashMap<>();

    public record DailyRewardState(int currentDay, long lastClaimEpoch, int totalClaims) {}

    // 7-day reward cycle configuration
    private final List<DayReward> dayRewards;

    public record DayReward(int day, String name, double coins, int xp, Material icon, String description) {}

    public DailyRewardManager(EthernovaProgression plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
        this.dayRewards = loadRewardConfig();
        createTable();
    }

    private List<DayReward> loadRewardConfig() {
        var config = plugin.getConfig();
        var section = config.getConfigurationSection("daily-rewards.rewards");
        List<DayReward> rewards = new ArrayList<>();

        if (section != null) {
            for (String key : section.getKeys(false)) {
                var ds = section.getConfigurationSection(key);
                if (ds == null) continue;
                // Parse day number from key like "day1", "day2", etc.
                int day;
                try { day = Integer.parseInt(key.replaceAll("[^0-9]", "")); }
                catch (NumberFormatException e) { continue; }
                rewards.add(new DayReward(
                        day,
                        ds.getString("name", "Día " + day),
                        ds.getDouble("coins", 100.0 * day),
                        ds.getInt("xp", 50 * day),
                        parseMaterial(ds.getString("icon", "CHEST_MINECART")),
                        ds.getString("description", "Recompensa del día " + day)
                ));
            }
        }

        // If no config, generate defaults matching original UltimateFFA
        if (rewards.isEmpty()) {
            int[] defaultCoins = {100, 250, 500, 1000, 2000, 3500, 5000};
            int[] defaultXP = {50, 75, 100, 150, 200, 250, 350};
            for (int i = 1; i <= 7; i++) {
                rewards.add(new DayReward(i, "Día " + i,
                        defaultCoins[i - 1], defaultXP[i - 1], Material.CHEST_MINECART,
                        "Reclama tu recompensa del día " + i));
            }
        }

        rewards.sort(Comparator.comparingInt(DayReward::day));
        return rewards;
    }

    private void createTable() {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (Connection conn = core.getStorageManager().getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "CREATE TABLE IF NOT EXISTS ethernova_daily_rewards (" +
                                 "uuid VARCHAR(36) PRIMARY KEY, " +
                                 "current_day INT DEFAULT 1, " +
                                 "last_claim BIGINT DEFAULT 0, " +
                                 "total_claims INT DEFAULT 0)")) {
                ps.executeUpdate();
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Error creating daily rewards table", e);
            }
        });
    }

    /**
     * Load player daily reward state from DB.
     */
    public void loadPlayer(UUID uuid) {
        try (Connection conn = core.getStorageManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT current_day, last_claim, total_claims FROM ethernova_daily_rewards WHERE uuid = ?")) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    stateCache.put(uuid, new DailyRewardState(
                            rs.getInt("current_day"),
                            rs.getLong("last_claim"),
                            rs.getInt("total_claims")));
                } else {
                    stateCache.put(uuid, new DailyRewardState(1, 0, 0));
                }
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error loading daily rewards for " + uuid, e);
            stateCache.put(uuid, new DailyRewardState(1, 0, 0));
        }
    }

    /**
     * Unload player state.
     */
    public void unloadPlayer(UUID uuid) {
        stateCache.remove(uuid);
    }

    /**
     * Check if the player can claim today's reward.
     */
    public boolean canClaim(UUID uuid) {
        DailyRewardState state = stateCache.get(uuid);
        if (state == null) return false;
        if (state.lastClaimEpoch == 0) return true;

        LocalDate lastClaim = Instant.ofEpochMilli(state.lastClaimEpoch)
                .atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate today = LocalDate.now();
        return !lastClaim.equals(today);
    }

    /**
     * Get the current day the player is on (1-7).
     */
    public int getCurrentDay(UUID uuid) {
        DailyRewardState state = stateCache.get(uuid);
        if (state == null) return 1;

        // If they missed a day (more than 48h since last claim), reset to day 1
        if (state.lastClaimEpoch > 0) {
            long hoursSinceClaim = (System.currentTimeMillis() - state.lastClaimEpoch) / (1000L * 60 * 60);
            if (hoursSinceClaim > 48) {
                return 1; // Reset streak
            }
        }
        return Math.min(state.currentDay, dayRewards.size());
    }

    /**
     * Claim the daily reward and advance to next day.
     */
    public boolean claimReward(Player player) {
        UUID uuid = player.getUniqueId();
        if (!canClaim(uuid)) return false;

        int day = getCurrentDay(uuid);
        DayReward reward = dayRewards.stream()
                .filter(r -> r.day == day)
                .findFirst()
                .orElse(dayRewards.getFirst());

        // Give rewards
        core.getProfileManager().addCoins(uuid, reward.coins());
        Player onlinePlayer = Bukkit.getPlayer(uuid);
        if (plugin.getLevelManager() != null && onlinePlayer != null) {
            plugin.getLevelManager().addXP(onlinePlayer, reward.xp(),
                    com.ethernova.progression.level.XPSource.QUEST);
        }

        // Advance day (cycle back to 1 after day 7)
        int nextDay = day >= dayRewards.size() ? 1 : day + 1;
        DailyRewardState oldState = stateCache.getOrDefault(uuid, new DailyRewardState(1, 0, 0));
        DailyRewardState newState = new DailyRewardState(nextDay, System.currentTimeMillis(), oldState.totalClaims + 1);
        stateCache.put(uuid, newState);

        // Save async
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> savePlayer(uuid, newState));

        // Feedback
        player.sendMessage(mini.deserialize(
                "<green>✔ <gold>¡Recompensa del <yellow>" + reward.name() +
                        "</yellow> reclamada! <white>+" + String.format("%.0f", reward.coins()) +
                        " monedas, +" + reward.xp() + " XP"));
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.5f);

        return true;
    }

    /** GUI title used to identify the calendar inventory in click handlers. */
    public static final String GUI_TITLE = "<gold><bold>CALENDARIO</bold> <dark_gray>» <white>Premios";

    /**
     * Open the daily rewards GUI matching the original UltimateFFA layout.
     * 45 slots, MINECART/CHEST_MINECART/BARRIER materials, disco glass, back button.
     */
    public void openGui(Player player) {
        UUID uuid = player.getUniqueId();
        int currentDay = getCurrentDay(uuid);
        boolean canClaimNow = canClaim(uuid);

        Inventory inv = Bukkit.createInventory(null, 45, mini.deserialize(GUI_TITLE));

        // Fill disco glass borders (randomized stained glass panes like original)
        fillDiscoGlass(inv, 45);

        // Place 7 day rewards in slots 10-16
        int[] slots = {10, 11, 12, 13, 14, 15, 16};
        for (int i = 0; i < dayRewards.size() && i < 7; i++) {
            DayReward reward = dayRewards.get(i);
            int slot = slots[i];

            boolean claimed = reward.day() < currentDay ||
                    (reward.day() == currentDay && !canClaimNow);
            boolean available = reward.day() == currentDay && canClaimNow;

            Material mat;
            String status;
            if (claimed) {
                mat = Material.MINECART;
                status = "<red>¡YA RECLAMADO!";
            } else if (available) {
                mat = Material.CHEST_MINECART;
                status = "<green>¡HAZ CLIC PARA RECLAMAR!";
            } else {
                mat = Material.BARRIER;
                status = "<gray>BLOQUEADO";
            }

            ItemStack item = new ItemStack(mat);
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                meta.displayName(mini.deserialize("<gold><bold>Día " + reward.day()));
                List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
                lore.add(mini.deserialize("<gray>Premio: <green>$" + String.format("%,.0f", reward.coins())));
                if (reward.xp() > 0) {
                    lore.add(mini.deserialize("<gray>XP: <aqua>+" + reward.xp()));
                }
                lore.add(mini.deserialize(" "));
                lore.add(mini.deserialize(status));
                meta.lore(lore);
                item.setItemMeta(meta);
            }
            inv.setItem(slot, item);
        }

        // Back button at slot 40 (same as original)
        ItemStack back = new ItemStack(Material.ARROW);
        ItemMeta backMeta = back.getItemMeta();
        if (backMeta != null) {
            backMeta.displayName(mini.deserialize("<red>← Volver"));
            back.setItemMeta(backMeta);
        }
        inv.setItem(40, back);

        player.openInventory(inv);
    }

    /**
     * Fill empty slots with randomized stained glass panes (disco glass like original).
     */
    private void fillDiscoGlass(Inventory inv, int size) {
        Material[] glassColors = {
                Material.RED_STAINED_GLASS_PANE, Material.ORANGE_STAINED_GLASS_PANE,
                Material.YELLOW_STAINED_GLASS_PANE, Material.LIME_STAINED_GLASS_PANE,
                Material.LIGHT_BLUE_STAINED_GLASS_PANE, Material.BLUE_STAINED_GLASS_PANE,
                Material.MAGENTA_STAINED_GLASS_PANE, Material.PINK_STAINED_GLASS_PANE,
                Material.PURPLE_STAINED_GLASS_PANE, Material.CYAN_STAINED_GLASS_PANE
        };
        Random rng = new Random();
        for (int i = 0; i < size; i++) {
            if (inv.getItem(i) == null) {
                ItemStack glass = new ItemStack(glassColors[rng.nextInt(glassColors.length)]);
                ItemMeta gm = glass.getItemMeta();
                if (gm != null) {
                    gm.displayName(mini.deserialize(" "));
                    glass.setItemMeta(gm);
                }
                inv.setItem(i, glass);
            }
        }
    }

    private void savePlayer(UUID uuid, DailyRewardState state) {
        boolean mysql = core.getStorageManager().isMySQL();
        String sql = mysql
                ? "INSERT INTO ethernova_daily_rewards (uuid, current_day, last_claim, total_claims) " +
                  "VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE current_day=VALUES(current_day), last_claim=VALUES(last_claim), total_claims=VALUES(total_claims)"
                : "INSERT INTO ethernova_daily_rewards (uuid, current_day, last_claim, total_claims) " +
                  "VALUES (?, ?, ?, ?) ON CONFLICT(uuid) DO UPDATE SET current_day=excluded.current_day, last_claim=excluded.last_claim, total_claims=excluded.total_claims";
        try (Connection conn = core.getStorageManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.setInt(2, state.currentDay());
            ps.setLong(3, state.lastClaimEpoch());
            ps.setInt(4, state.totalClaims());
            ps.executeUpdate();
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error saving daily rewards for " + uuid, e);
        }
    }

    public List<DayReward> getDayRewards() {
        return Collections.unmodifiableList(dayRewards);
    }

    public DailyRewardState getState(UUID uuid) {
        return stateCache.get(uuid);
    }

    private Material parseMaterial(String name) {
        try { return Material.valueOf(name.toUpperCase()); }
        catch (IllegalArgumentException e) { return Material.CHEST; }
    }
}
