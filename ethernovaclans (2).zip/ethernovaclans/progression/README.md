# EthernovaProgression

> Sistema de progresión: niveles, prestigio, logros, misiones y pase de batalla.

## Características

- **Niveles** — XP con fórmula exponencial, nivel máximo configurable
- **Prestigio** — Reset de nivel por multiplicadores permanentes
- **Logros** — Logros por categoría (Combate, Exploración, Social, Progresión, Especial)
- **Misiones** — Diarias, semanales y de eventos con recompensas
- **Pase de Batalla** — Tiers con recompensas gratuitas y premium, temporadas
- **Multiplicadores** — XP multiplicado por prestigio, boosts y buffs de party
- **Tiempo de juego** — XP por permanecer conectado

## API

```java
ProgressionAPI api = ServiceRegistry.get(ProgressionAPI.class);
api.addXP(player, 500);
api.getMaxLevel();
api.isAchievementCompleted(uuid, "first_blood");
api.getAchievementProgress(uuid, "kill_100");
api.getActiveMissions(uuid);
api.getBattlePassTier(uuid);
api.isBattlePassPremium(uuid);
api.getPrestigeDisplay(3);
```

## Comandos

| Comando | Descripción |
|---------|-------------|
| `/level` | Ver nivel y progreso |
| `/prestige` | Prestigiar |
| `/achievements` | Ver logros |
| `/missions` | Ver misiones activas |
| `/battlepass` | Abrir pase de batalla |

## Placeholders

| Placeholder | Descripción |
|-------------|-------------|
| `%progression_level%` | Nivel actual |
| `%progression_xp%` | XP actual |
| `%progression_prestige%` | Nivel de prestigio |
| `%progression_achievements%` | Logros completados |
| `%progression_bp_tier%` | Tier del pase de batalla |
