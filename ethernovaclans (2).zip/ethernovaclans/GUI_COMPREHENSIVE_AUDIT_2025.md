# 🎨 EthernovaClans — Comprehensive GUI Audit Report (2025)

**Date:** 2025  
**Scope:** ALL GUI files across all 10 modules (76+ files)  
**Focus:** Aesthetic issues, organizational problems, layout consistency, navigation patterns, formatting, and color scheme coherence.

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [GUI Frameworks Overview](#2-gui-frameworks-overview)
3. [Cross-Cutting Issues (Project-Wide)](#3-cross-cutting-issues-project-wide)
4. [Module: Core](#4-module-core)
5. [Module: Duels](#5-module-duels)
6. [Module: FFA](#6-module-ffa)
7. [Module: Ranked](#7-module-ranked)
8. [Module: Party](#8-module-party)
9. [Module: Progression](#9-module-progression)
10. [Module: Cosmetics](#10-module-cosmetics)
11. [Module: Combat](#11-module-combat)
12. [Module: Clans](#12-module-clans)
13. [Summary of All Issues](#13-summary-of-all-issues)
14. [Priority Recommendations](#14-priority-recommendations)

---

## 1. Executive Summary

The EthernovaClans project contains **76+ GUI screens** distributed across 10 modules, built on **4 different GUI frameworks**:

| Framework | Modules Using It | Animation | Formatting |
|-----------|-----------------|-----------|------------|
| `CoreGui` (54-slot, rainbow border) | core, duels, ffa, ranked, party, progression, cosmetics (admin GUIs) | ✅ Rainbow animated | MiniMessage |
| `PaginatedGui` (extends CoreGui) | core, ffa, ranked, party, progression, cosmetics (list GUIs) | ✅ Rainbow animated | MiniMessage |
| `AbstractGui` / `ConfigurableGUI` (YAML-driven) | clans (~32 GUIs) | ✅ Rainbow animated | MiniMessage |
| Raw `Bukkit.createInventory` | combat, cosmetics (aura/title/trim), progression (prestige/daily) | ❌/Partial | **Legacy §-codes** |

### Critical Findings

- **16 GUIs** use `inventory.setItem()` instead of `setItem()`, bypassing border animation protection
- **~20 GUIs** use legacy `§`-codes while the rest use MiniMessage — visual inconsistency
- **4+ GUIs** are missing back buttons, creating navigation dead-ends
- **3 different GUI frameworks** create inconsistent UX across modules
- **Non-standard navigation slots** across paginated GUIs
- **Slot conflicts** where items overwrite each other in at least 2 GUIs

---

## 2. GUI Frameworks Overview

### 2.1 CoreGui (Base Framework)
**File:** `core/src/main/java/com/ethernova/core/gui/CoreGui.java`

- Creates a chest inventory with configurable size
- `fillBorders()` calculates border slots dynamically
- `startAnimation()` cycles `RAINBOW_PANES` materials on non-protected slots every 5 ticks
- `setItem(slot, item)` → adds slot to `protectedSlots` (immune to animation)
- `inventory.setItem(slot, item)` → **does NOT protect** from animation overwrite

**Standard Border Layout (54 slots):**
```
Row 0: [0  1  2  3  4  5  6  7  8 ] ← ALL BORDER
Row 1: [9  10 11 12 13 14 15 16 17] ← 9,17 border | 10-16 CONTENT
Row 2: [18 19 20 21 22 23 24 25 26] ← 18,26 border | 19-25 CONTENT
Row 3: [27 28 29 30 31 32 33 34 35] ← 27,35 border | 28-34 CONTENT
Row 4: [36 37 38 39 40 41 42 43 44] ← 36,44 border | 37-43 CONTENT
Row 5: [45 46 47 48 49 50 51 52 53] ← ALL BORDER (nav)
```

### 2.2 PaginatedGui
**File:** `core/src/main/java/com/ethernova/core/gui/PaginatedGui.java`

- Always 54 slots
- `CONTENT_SLOTS` = {10-16, 19-25, 28-34, 37-43} = **28 items per page**
- Navigation: **slot 45** (prev page), **slot 48** (back), **slot 49** (page info), **slot 53** (next page)
- `onPostRender()` hook for extra items after pagination

### 2.3 AbstractGui (Clans)
**File:** `src/main/java/com/ethernova/clans/gui/AbstractGui.java`

- Loads layout from YAML configuration files
- Same `RAINBOW_PANES` array and animation system
- `occupiedSlots` set prevents animation from overwriting content items
- `setItem()` method properly tracks occupied slots

### 2.4 Raw Bukkit.createInventory
- Used by combat module (AdminGUIManager, DeathRecapManager, BountyManager)
- Used by cosmetics (AuraGUIManager, TitleManager, ArmorTrimManager)
- Used by progression (PrestigeManager, DailyRewardManager)
- **No shared framework** — each implements its own border/fill logic

---

## 3. Cross-Cutting Issues (Project-Wide)

### 🔴 CRITICAL: `inventory.setItem()` vs `setItem()` — Border Animation Overwrite

**Every admin GUI** and several other GUIs use `inventory.setItem()` directly instead of the framework's `setItem()` method. Items placed this way are NOT added to `protectedSlots` and **will be overwritten by the rainbow border animation** on border slots.

**Affected GUIs:**
| GUI | Module | Slots Affected |
|-----|--------|---------------|
| `AdminGui` | core | Row 1 (10-16) — server info items |
| `DuelsAdminGui` | duels | Row 1 (10-14) — module info items |
| `FFAAdminGui` | ffa | Rows 1-4 (10-42) — **ALL content** |
| `RankedAdminGui` | ranked | Most content items |
| `PartyAdminGui` | party | Most content items |
| `ProgressionAdminGui` | progression | Most content items |
| `CosmeticsAdminGui` | cosmetics | Most content items |

**Impact:** Content items on non-border slots will still display correctly (animation only runs on border slots). However, any items placed on border-adjacent slots or if the fillBorders logic is recalculated, these items could be lost.

**Fix:** Replace all `inventory.setItem(slot, item)` calls with `setItem(slot, item)` to register items as protected.

---

### 🔴 CRITICAL: Legacy §-Codes vs MiniMessage Inconsistency

The project uses **two incompatible text formatting systems** side-by-side:

| System | Used By |
|--------|---------|
| **MiniMessage** (`<red>`, `<gradient:...>`) | CoreGui, PaginatedGui, AbstractGui, all core/duels/ffa/ranked/party/progression/cosmetics GUI classes |
| **Legacy §-codes** (`§c`, `§l`, `§6§l✦`) | AuraGUIManager (9 GUIs), TitleManager, ArmorTrimManager, DeathRecapManager, BountyManager, PrestigeManager, MissionGui (partial) |

**Impact:**
- Titles created with `§` codes display differently than MiniMessage titles
- Font rendering differences between legacy and MiniMessage
- Maintenance burden — two formatting syntaxes to maintain
- MissionGui mixes both systems in the same GUI

**Fix:** Migrate all legacy §-code GUIs to MiniMessage formatting for consistency.

---

### 🟡 MEDIUM: Inconsistent Inventory Sizes

GUIs use 5 different inventory sizes with no clear rationale:

| Size | GUIs |
|------|------|
| **54** (6 rows) | Most GUIs — standard for CoreGui/PaginatedGui |
| **45** (5 rows) | MainMenuGui, KitEditorGui, DuelMenuGui, DuelStatsGui, FFAStatsGui, FFAKitGui, PlayerStatsGui, PlayerSettingsGui, RankedGui, PartySettingsGui, DailyRewardManager |
| **36** (4 rows) | DuelGui, QueueKitGui, ArmorTrimManager (1 GUI) |
| **27** (3 rows) | ConfirmationGui, PrestigeManager |
| **Variable** | MissionGui (from config) |

**Issue:** 45-slot GUIs still use CoreGui's animated border, but 36-slot GUIs place headers at slot 4 which **is in the border row** and gets animated over. 27-slot GUIs have different content areas.

---

### 🟡 MEDIUM: Navigation Slot Inconsistencies

Different GUIs place navigation buttons at different slots:

| Navigation Element | Standard (PaginatedGui) | Deviations |
|-------------------|------------------------|------------|
| Previous page | Slot 45 | — |
| Back button | Slot 48 | PartySettingsGui: **slot 36** (border!) |
| Page info | Slot 49 | — |
| Next page | Slot 53 | DuelInviteGui: **slot 50**, Combat GUIs: **slot 50** |
| Close button | Slot 49 (admin) | Various: 40, 49, 53 |

**Impact:** Players experience inconsistent muscle memory; buttons appear at different positions depending on the menu.

---

### 🟡 MEDIUM: Missing Back Buttons — Navigation Dead Ends

| GUI | Module | Expected Back Target | Has Back? |
|-----|--------|---------------------|-----------|
| `DuelStatsGui` | duels | DuelMenuGui | ❌ Only close |
| `FFAStatsGui` | ffa | Main menu or FFA hub | ❌ Only close |
| `FFAKitGui` | ffa | Main menu or FFA hub | ❌ Only close |
| `RankedGui` | ranked | Main menu | ❌ Only close |

---

## 4. Module: Core

### 4.1 MainMenuGui
**Size:** 45 slots | **Framework:** CoreGui

**Layout:**
```
Row 0: [border border border border border border border border border]
Row 1: [border FFA    .     Duels  .     Ranked .     Clans  border]  (10,12,14,16)
Row 2: [border Party  .     Shop   Daily Cosm   .     BPass  border]  (19,21,22,23,25)
Row 3: [border Missn  .     Achiev Stats Rankng .     Settngs border] (28,30,31,32,34)
Row 4: [border .      .     .      Close .      .     .      border]  (40)
```

**Issues:**
- ✅ Well organized — logical grouping by category
- ✅ Good use of slot spacing for visual clarity
- 🟡 Row 2 uses 5 items (19,21,22,23,25) with asymmetric spacing — slots 22-23 are adjacent while others have gaps

---

### 4.2 AdminGui
**Size:** 54 slots | **Framework:** CoreGui

**Issues:**
- 🔴 **Rows 1-3 use `inventory.setItem()`** instead of `setItem()` — items not protected from border animation
- ✅ Good layout — 4 rows of content with clear categories
- ✅ Row 4 module links are properly centered

---

### 4.3 ConfirmationGui
**Size:** 27 slots | **Framework:** CoreGui

**Layout:** Slot 11 (confirm) | Slot 13 (question) | Slot 15 (deny)

**Issues:**
- ✅ Simple, clear yes/no layout
- ✅ Uses LIME_WOOL / RED_WOOL for intuitive color coding

---

### 4.4 KitEditorGui
**Size:** 45 slots | **Framework:** CoreGui

**Issues:**
- 🟡 Kit items use slots 10-16 (7 items) + 19-20 (2 items) — **row 2 only fills 2 of 7 content slots**, leaving a visual imbalance
- ✅ Action buttons (Reset/Save/Back) at 29,31,33 are well-spaced

---

### 4.5 PlayerSettingsGui
**Size:** 54 slots | **Framework:** CoreGui

**Issues:**
- ✅ Excellent organization — 4 categories with labeled dividers
- ✅ 20 toggle settings well-distributed across 4 rows
- ✅ Enchant glow for enabled items provides clear visual feedback
- ✅ Proper navigation (back/info/reset at 45/49/53)

---

### 4.6 PlayerStatsGui
**Size:** 45 slots | **Framework:** CoreGui

**Issues:**
- 🟡 **Duplicate "Tiempo Jugado"** — appears at both slot 16 (row 1) and slot 23 (row 2)
- ✅ Player head at slot 4 is a nice visual anchor

---

### 4.7 RankingsGui
**Size:** 54 slots | **Framework:** CoreGui

**Issues:**
- 🟡 Top 10 entries use formula `19 + i + (i >= 7 ? 2 : 0)` → slots 19-25 then 28-30 — **row 3 has only 3 entries** while row 2 is full, creating visual imbalance
- ✅ Category selectors at row 1 (10-16) are well-organized

---

## 5. Module: Duels

### 5.1 DuelMenuGui
**Size:** 45 slots | **Framework:** CoreGui

**Layout:** Header (4) | Matchmaking/Invite/Stats at (20,22,24) | Info (31) | Close (40)

**Issues:**
- ✅ Clean, simple 3-option layout
- ✅ Good use of center row for main actions

---

### 5.2 DuelInviteGui
**Size:** 54 slots | **Framework:** CoreGui (manual pagination)

**Issues:**
- 🔴 **Next page at slot 50** instead of standard slot 53 — breaks navigation consistency
- 🟡 Manual pagination reimplements PaginatedGui logic — should use PaginatedGui
- ✅ Content area (slots 10-16, 19-25, 28-34 = 21 per page) is correct

---

### 5.3 DuelGui (Kit Selection)
**Size:** 36 slots | **Framework:** CoreGui

**Issues:**
- 🟡 **36-slot inventory** — slot 4 (header) is in the **top border row** and may be animated over if not properly protected
- 🟡 Only 7 kit slots (10-16) — limited if more kits are added
- ✅ Simple functional layout

---

### 5.4 DuelStatsGui
**Size:** 45 slots | **Framework:** CoreGui

**Issues:**
- 🔴 **No back button** — only close at slot 40; player can't return to DuelMenuGui
- ✅ Async stats loading is good practice

---

### 5.5 DuelsAdminGui
**Size:** 54 slots | **Framework:** CoreGui

**Issues:**
- 🔴 **Uses `inventory.setItem()`** for row 1 (10-14) — unprotected from animation
- ✅ Standard admin layout with proper back (45) and close (49)

---

### 5.6 DuelsArenaListGui / DuelsKitListGui
**Size:** 54 slots | **Framework:** CoreGui (manual pagination)

**Issues:**
- 🟡 Reimplements pagination manually instead of using PaginatedGui
- ✅ Consistent layout between arena and kit lists

---

### 5.7 QueueKitGui
**Size:** 36 slots | **Framework:** CoreGui

**Issues:**
- 🟡 Same 36-slot issue as DuelGui — slot 4 header in border row
- ✅ Simple functional layout

---

## 6. Module: FFA

### 6.1 FFAAdminGui
**Size:** 54 slots | **Framework:** CoreGui (2 pages)

**Issues:**
- 🔴 **Uses `inventory.setItem()` extensively** (slots 10-42) — ALL content items unprotected
- 🟡 Page navigation overrides back button at slot 45 on page > 0
- ✅ Reload button at slot 49

---

### 6.2 FFAStatsGui
**Size:** 45 slots | **Framework:** CoreGui

**Issues:**
- 🔴 **No back button** — only close at slot 40
- ✅ Async population
- ✅ Good stats layout (main at 13, details at 20,22,24,30,32)

---

### 6.3 FFALeaderboardGui
**Size:** 54 slots | **Framework:** PaginatedGui

**Issues:**
- ✅ Properly uses PaginatedGui framework
- ✅ Back button navigates to MainMenuGui
- ✅ Async loading with player heads

---

### 6.4 FFAKitGui (Player Kit Selection)
**Size:** 45 slots | **Framework:** CoreGui

**Issues:**
- 🔴 **No back button** — only close at slot 40
- 🟡 Uses slots 10-16, 19-25 (14 slots) but no indication of what to do with remaining content slots

---

### 6.5 FFAArenaListGui / FFAKitListGui
**Size:** 54 slots | **Framework:** CoreGui (manual pagination)

**Issues:**
- 🟡 Same manual pagination pattern as duels counterparts — should use PaginatedGui

---

## 7. Module: Ranked

### 7.1 RankedGui
**Size:** 45 slots | **Framework:** CoreGui

**Issues:**
- 🔴 **Slot conflict** — Progress bar items at slots 28-32 **overwrite** streak info (slot 30) and season info (slot 32) that were set earlier
- 🔴 **No back button** — only close at slot 40; player can't return to main menu
- 🟡 Mixed content types in same row (stats + progress bar + buttons)

**Slot Conflict Detail:**
```java
// First, these are set:
setItem(30, streakItem);    // Streak info
setItem(32, seasonItem);    // Season info
// Then, progress bar overwrites them:
for (int i = 0; i < 5; i++) {
    setItem(28 + i, progressBarItem);  // Sets 28,29,30,31,32 ← OVERWRITES 30 and 32!
}
```

---

### 7.2 RankedAdminGui
**Size:** 54 slots | **Framework:** CoreGui

**Issues:**
- 🔴 **Uses `inventory.setItem()`** for most content items — unprotected
- ✅ Standard admin layout

---

### 7.3 LeaderboardGui
**Size:** 54 slots | **Framework:** PaginatedGui

**Issues:**
- ✅ Properly uses PaginatedGui
- ✅ Back navigates to RankedGui
- ✅ Async loading

---

## 8. Module: Party

### 8.1 PartyGui
**Size:** 54 slots | **Framework:** CoreGui

**Issues:**
- ✅ **Well organized** — party info (4), members (19-25, 28-34), actions (37-43), close (49)
- ✅ Good capacity (14 member skulls max)

---

### 8.2 PartySettingsGui
**Size:** 45 slots | **Framework:** CoreGui

**Issues:**
- 🟡 **Back button at slot 36** — this is a **border slot** in a 45-slot inventory. While `setItem()` is used (so it's protected from animation), visually it sits in the border row, which is unconventional
- ✅ Settings at 10,12,14,16,28 are well-spaced

---

### 8.3 PartyAdminGui
**Size:** 54 slots | **Framework:** CoreGui (2 pages)

**Issues:**
- 🔴 **Uses `inventory.setItem()`** — content unprotected from animation
- ✅ Page navigation at 45/53

---

### 8.4 PartyListGui
**Size:** 54 slots | **Framework:** PaginatedGui

**Issues:**
- ✅ Properly uses PaginatedGui
- ✅ Context-aware back button

---

## 9. Module: Progression

### 9.1 LevelGui
**Size:** 54 slots | **Framework:** CoreGui

**Issues:**
- ✅ **Well organized** — level info (13), prestige (11), XP bar (19-25), boost (15), navigation (29,31,33), stats (40), back (49)
- ✅ XP bar visualization across row 2 is creative

---

### 9.2 MissionGui
**Size:** Variable (from config) | **Framework:** Custom (raw inventory)

**Issues:**
- 🔴 **Uses legacy §-codes** (`§e§l⏰ MISIONES DIARIAS`, `§7`, etc.) — inconsistent with rest of project's MiniMessage usage
- 🟡 Variable size from config makes layout unpredictable
- 🟡 Not using CoreGui framework — no rainbow borders, no animation

---

### 9.3 BattlePassGui
**Size:** 54 slots | **Framework:** PaginatedGui

**Issues:**
- ✅ Properly uses PaginatedGui
- ✅ Tier items with claim functionality
- ✅ Back navigates to LevelGui

---

### 9.4 AchievementGui
**Size:** 45 → 54 slots | **Framework:** CoreGui + PaginatedGui (dual mode)

**Issues:**
- ✅ Creative dual-mode design: 45-slot category view → paginated achievement list
- ✅ Categories at 20-24 are well-centered
- ✅ Back toggles between category view and LevelGui

---

### 9.5 ProgressionAdminGui
**Size:** 54 slots | **Framework:** CoreGui (2 pages)

**Issues:**
- 🔴 **Uses `inventory.setItem()`** — content unprotected
- ✅ Standard 2-page admin pattern

---

### 9.6 PrestigeManager (Confirmation GUI)
**Size:** 27 slots | **Framework:** Raw `Bukkit.createInventory`

**Issues:**
- 🔴 **Uses §-codes** for title (`§c§l¿CONFIRMAR PRESTIGIO?`)
- 🟡 No rainbow borders — visually different from CoreGui-based GUIs
- ✅ Simple confirmation dialog

---

### 9.7 DailyRewardManager
**Size:** 45 slots | **Framework:** Raw `Bukkit.createInventory`

**Issues:**
- 🟡 Uses MiniMessage for title (good) but separate framework from CoreGui
- 🟡 No rainbow borders — visually inconsistent

---

## 10. Module: Cosmetics

### 10.1 CosmeticsMainGui
**Size:** 54 slots | **Framework:** PaginatedGui

**Issues:**
- ✅ Well-organized hub linking to types/shop/boxes/collection/trims/auras
- ✅ Back navigates to MainMenuGui

---

### 10.2 CosmeticTypeGui
**Size:** 54 slots | **Framework:** PaginatedGui

**Issues:**
- ✅ Excellent item rendering with owned/equipped/locked states
- ✅ Unequip button at slot 50 via `onPostRender()`
- ✅ Right-click preview functionality

---

### 10.3 CosmeticShopGui
**Size:** 54 slots | **Framework:** PaginatedGui

**Issues:**
- ✅ Properly uses PaginatedGui
- ✅ Buy-on-click with coin check

---

### 10.4 CollectionGui
**Size:** 54 slots | **Framework:** PaginatedGui

**Issues:**
- ✅ Progress bars per type and rarity — informative
- ✅ Click on type opens CosmeticTypeGui

---

### 10.5 MysteryBoxGui / MysteryBoxPreviewGui
**Size:** 54 slots | **Framework:** PaginatedGui

**Issues:**
- ✅ Well-designed box system with probability display
- ✅ Preview shows rarity headers as separators
- ✅ Probability distribution bar at slot 50 via `onPostRender()`
- ✅ Back navigates correctly (Preview → Box, Box → Main)

---

### 10.6 PetVariantGui
**Size:** 54 slots | **Framework:** PaginatedGui

**Issues:**
- ✅ Good variant display with equip/unequip/preview
- ✅ Head/floor toggle at list start
- ✅ Back navigates to CosmeticTypeGui(PET)

---

### 10.7 CosmeticsAdminGui
**Size:** 54 slots | **Framework:** CoreGui

**Issues:**
- 🔴 **Uses `inventory.setItem()`** — content unprotected
- ✅ Standard admin layout

---

### 10.8 AuraGUIManager (9+ GUIs)
**Size:** 54 slots each | **Framework:** Raw `Bukkit.createInventory`

**GUIs:** Tier Selection, Tier Auras, Patterns, Fusions, Slots, Slot Aura Selector, Slot Pattern Selector, Advanced Config, Aura Settings

**Issues:**
- 🔴 **ALL titles use legacy §-codes** (`§6§l✦ SELECCIONAR TIER ✦`, `§5§l⚗ FUSIÓN DE AURAS ⚗`, etc.)
- 🔴 **ALL lore uses legacy §-codes** — completely inconsistent with MiniMessage GUIs
- 🟡 `fillBorder()` fills ALL slots with rainbow panes, then content is placed on top — different from CoreGui which only fills border positions
- 🟡 Has its own border animation system (`startBorderAnimation()`) separate from CoreGui's
- 🟡 Back button at **slot 36** (border slot) in Tiers GUI — same issue as PartySettingsGui
- 🟡 Nav buttons scattered: slot 49 (back), slot 45 (prev page), slot 53 (next page) — mostly consistent but some variations
- ✅ Rich feature set with tier/fusion/config/slot management
- ✅ Has its own `RAINBOW_PANES` array matching CoreGui's palette

---

### 10.9 TitleManager
**Size:** 54 slots | **Framework:** Raw `Bukkit.createInventory`

**Issues:**
- 🔴 **Title uses §-codes** (`§8» §6§lTítulos §7(Pág X/Y)`)
- 🟡 Manual pagination separate from PaginatedGui
- 🟡 No rainbow borders

---

### 10.10 ArmorTrimManager (3+ GUIs)
**Size:** 54, 45, 45, 36 | **Framework:** Raw `Bukkit.createInventory`

**Issues:**
- 🔴 **Uses §-codes** for titles
- 🟡 Multiple inventory sizes (54, 45, 36) across related GUIs
- 🟡 No shared framework or rainbow borders

---

## 11. Module: Combat

### 11.1 AdminGUIManager (13 GUI screens)
**Size:** 54 slots each | **Framework:** Raw `Bukkit.createInventory` + `GUIHelper`

**GUIs:** Main Menu, World List, World Settings (3 tabs: General, Restrictions, Visual), Module List, Detection Settings, Suspect List, Log Viewer, Global Config (3 tabs: Combat, Visual, NPC), Active Combats

**Issues:**
- 🟡 `fillBorder()` in `GUIHelper` fills **ALL slots** with rainbow panes, then places content on top — content items overwrite filler, but if not placed, filler remains in content area
- 🟡 Navigation inconsistency: next page at **slot 50** instead of PaginatedGui's slot 53
- ✅ **Uses MiniMessage** for titles (unlike other raw inventory GUIs) — good
- ✅ **Tabbed interface** for World Settings and Global Config — sophisticated design
- ✅ `GUIHelper` utility provides consistent item builders (toggle, numberItem, cycleItem, etc.)
- ✅ Auto-refresh on Active Combats dashboard
- ✅ Tab switching with visual indicators (LIME_DYE active, colored DYE inactive)
- 🟡 Items in **tab bar use slots 2, 4, 6** which are in the **top border row** — they are placed after fillBorder so they work, but semantically sit in border area

---

### 11.2 DeathRecapManager
**Size:** 54 slots | **Framework:** Raw `Bukkit.createInventory`

**Issues:**
- 🔴 **ALL text uses §-codes** (`§c§l☠`, `§7HP restante:`, etc.)
- 🟡 Uses gray glass pane fill (`fillBorderGlass`) instead of rainbow — visually inconsistent with other GUIs
- 🟡 Damage timeline fills rows 1-4 (slots 9-44) sequentially without content slot filtering — items placed in border slots (9, 17, 18, 26, 27, 35, 36, 44) will stack awkwardly on the sides
- ✅ Stats summary at slot 49, back at slot 45

---

### 11.3 BountyManager
**Size:** 54 slots | **Framework:** Raw `Bukkit.createInventory`

**Issues:**
- 🔴 **ALL text uses §-codes** (`§6§l☠ Sistema de Bounties`, etc.)
- 🟡 `fillDiscoGlass()` uses **random** rainbow pane placement instead of sequential — different visual style from all other GUIs
- 🟡 Content slots hardcoded: `{10,11,12,13,14,15,16, 19,20,21,22,23,24,25, 28,29,30,31,32,33,34}` — correct but not using shared constant
- ✅ Info at slot 4, back at slot 45, player's own bounty at slot 49

---

## 12. Module: Clans

### 12.1 AbstractGui / ConfigurableGUI Framework
**Files:** `src/main/java/com/ethernova/clans/gui/AbstractGui.java`, `ConfigurableGUI.java`

The clans module has its own **YAML-driven GUI framework** that's separate from CoreGui but shares the same design principles:

- Same `RAINBOW_PANES` array as CoreGui
- Same animation system (cycling panes on non-occupied slots)
- `occupiedSlots` set properly protects content from animation
- Layout, items, actions, conditions all loaded from YAML config files
- Supports placeholders (`{clan_name}`, `{members}`, `{power}`, etc.)
- Bracket-style actions: `[close]`, `[open] gui-name`, `[command] cmd`, `[message] msg`

**Issues:**
- 🟡 **Separate framework** from CoreGui — code duplication of animation, border, and item building logic
- 🟡 `ConfigurableGUI.java` (354 lines) is a simpler version that doesn't extend AbstractGui — **two systems** for the same module
- ✅ YAML-driven design is very maintainable — layout changes don't require code changes
- ✅ Extensive placeholder system (100+ replacements)
- ✅ Condition system (has_clan, is_leader, is_officer, etc.)

### 12.2 Clans GUIs (~32 files)

All clans GUIs extend `AbstractGui` and follow a consistent pattern:
- Layout loaded from YAML
- `populateItems()` adds dynamic content
- `processAction()` handles custom actions
- Navigation through `[open]` actions

**Files:**
AchievementsGui, AdminClanGui, AdminClanListGui, AdminMainGui, AdminPlayerGui, AuditLogGui, BankGui, BlueprintAdminGui, BlueprintMenuGui, BoostsGui, ClanMainGui, ClanShopGui, ClanSkillsGui, ColorPickerGui, DiplomacyGui, EventCalendarGui, IconSelectorGui, InvitationsGui, InvitePlayersGui, MembersGui, MissionsGui, PermissionsGui, ProgressGui, SeasonGui, SettingsGui, StatsGui, TerritoryMapGui, TopsGui, TrophiesGui, UpgradesGui, WarpsGui, WarsGui

**Notable:**
- `TerritoryMapGui` uses a 9x5 grid (45 map slots) + action bar — requires minimum 54 slots
- All GUIs share consistent rainbow borders from AbstractGui
- All use MiniMessage formatting
- Navigation between GUIs is YAML-driven — highly configurable

**Issues:**
- 🟡 Since layouts are YAML-driven, actual slot inconsistencies depend on the YAML files (not auditable from Java code alone)
- ✅ Framework is well-designed and consistent within itself

---

## 13. Summary of All Issues

### 🔴 Critical (Should Fix)

| # | Issue | Affected GUIs | Impact |
|---|-------|---------------|--------|
| 1 | `inventory.setItem()` bypasses animation protection | AdminGui, DuelsAdminGui, FFAAdminGui, RankedAdminGui, PartyAdminGui, ProgressionAdminGui, CosmeticsAdminGui | Items may not be protected from border animation |
| 2 | Legacy §-codes in MiniMessage project | AuraGUIManager (9 GUIs), TitleManager, ArmorTrimManager, DeathRecapManager, BountyManager, PrestigeManager, MissionGui | Visual inconsistency, maintenance burden |
| 3 | RankedGui slot conflict — progress bar overwrites streak/season | RankedGui | Player loses access to streak/season info |
| 4 | Missing back buttons — navigation dead ends | DuelStatsGui, FFAStatsGui, FFAKitGui, RankedGui | Player forced to close and reopen menus |

### 🟡 Medium (Should Improve)

| # | Issue | Affected GUIs | Impact |
|---|-------|---------------|--------|
| 5 | Non-standard next page slot (50 vs 53) | DuelInviteGui, all Combat Admin GUIs | Inconsistent navigation |
| 6 | Back button at border slot 36 | PartySettingsGui, AuraGUIManager(Tiers) | Visually in border row |
| 7 | 36-slot GUIs with header at slot 4 (border) | DuelGui, QueueKitGui | Header in border row |
| 8 | Duplicate "Tiempo Jugado" | PlayerStatsGui | Redundant information |
| 9 | Manual pagination instead of PaginatedGui | DuelInviteGui, DuelsArenaListGui, DuelsKitListGui, FFAArenaListGui, FFAKitListGui | Code duplication |
| 10 | Three separate GUI frameworks | All modules | Inconsistent UX, code duplication |
| 11 | Different border fill strategies | CoreGui (border only), Combat GUIHelper (all slots), AuraGUI (all slots) | Different visual behavior |
| 12 | Random disco glass in BountyManager | BountyManager | Different visual style from rest |
| 13 | Gray glass fill in DeathRecapManager | DeathRecapManager | No rainbow borders |
| 14 | Damage timeline fills border slots | DeathRecapManager | Items on slots 9,17,18,26,27,35,36,44 |
| 15 | No rainbow borders on raw GUIs | PrestigeManager, DailyRewardManager, TitleManager, ArmorTrimManager | Visual inconsistency |

### 🟢 Low (Nice to Have)

| # | Issue | Affected GUIs | Impact |
|---|-------|---------------|--------|
| 16 | KitEditorGui row 2 only uses 2 of 7 content slots | KitEditorGui | Visual imbalance |
| 17 | RankingsGui row 3 only has 3 of 7 entries | RankingsGui | Visual imbalance |
| 18 | MainMenuGui row 2 asymmetric spacing | MainMenuGui | Minor visual quirk |

---

## 14. Priority Recommendations

### P0 — Fix Immediately

1. **Fix `inventory.setItem()` → `setItem()`** in all admin GUIs
   - Files: AdminGui, DuelsAdminGui, FFAAdminGui, RankedAdminGui, PartyAdminGui, ProgressionAdminGui, CosmeticsAdminGui
   - Effort: Low (find-and-replace)

2. **Fix RankedGui slot conflict** — move streak/season items to non-conflicting slots or adjust progress bar positioning
   - File: RankedGui.java
   - Effort: Low

3. **Add back buttons** to DuelStatsGui, FFAStatsGui, FFAKitGui, RankedGui
   - Effort: Low

### P1 — Fix Soon

4. **Standardize next page button to slot 53** in DuelInviteGui and Combat Admin GUIs
   - Effort: Low

5. **Migrate MissionGui from §-codes to MiniMessage**
   - Effort: Medium (MissionGui is within MiniMessage framework, just uses wrong formatting)

6. **Convert DuelInviteGui, DuelsArenaListGui, DuelsKitListGui, FFAArenaListGui, FFAKitListGui** to use PaginatedGui
   - Effort: Medium (refactor to use framework instead of manual pagination)

### P2 — Planned Improvement

7. **Migrate AuraGUIManager** (9 GUIs) to CoreGui/PaginatedGui framework with MiniMessage
   - Effort: High (1038 lines, 9 GUI screens)

8. **Migrate DeathRecapManager and BountyManager** to CoreGui framework
   - Effort: Medium

9. **Migrate TitleManager and ArmorTrimManager** to PaginatedGui framework
   - Effort: Medium

10. **Migrate PrestigeManager and DailyRewardManager** to CoreGui framework
    - Effort: Low (simple GUIs)

### P3 — Long-term Architecture

11. **Unify GUI frameworks** — consider moving clans' AbstractGui to extend CoreGui, or vice versa, to create a single animation/border system
    - Effort: High (architectural refactor)

12. **Create a `NavigationConstants` class** with standard slot positions for prev/back/info/next across all GUIs
    - Effort: Low

---

*Report generated from analysis of 76+ GUI files across 10 modules.*
