# ORIGINAL vs MODULAR — Full Comparative Audit Report

> **Generated:** 2025 | **Original:** `UltimateFFA` (monolithic) | **Modular:** `EthernovaClans` (multi-module)
> 
> This report compares ALL 11 requested systems line-by-line, listing exact IDs, counts, and what is **MISSING** or **DIFFERENT** in the modular rewrite.

---

## Table of Contents

1. [Pets](#1-pets)
2. [Trails (Walking)](#2-trails-walking)
3. [Elytra Trails](#3-elytra-trails)
4. [Hit / Kill Effects](#4-hit--kill-effects)
5. [Crates / Mystery Boxes](#5-crates--mystery-boxes)
6. [Prestige](#6-prestige)
7. [Missions](#7-missions)
8. [Weekly Calendar / Daily Rewards](#8-weekly-calendar--daily-rewards)
9. [Party](#9-party)
10. [Finishers](#10-finishers)
11. [Death Sounds](#11-death-sounds)
12. [Summary Matrix](#12-summary-matrix)

---

## 1. PETS

### Original (32 pet types + variant systems)

**Source:** `CosmeticEnums.PetCategory` (lines ~213–244), `PetManager.java` (591 lines)

| # | ID | Cost | Implementation |
|---|-----|------|----------------|
| 1 | NONE | 0 | — |
| 2 | CHICKEN | 2000 | Real `EntityType.CHICKEN` |
| 3 | PIG | 2500 | Real `EntityType.PIG` |
| 4 | COW | 3000 | Real `EntityType.COW` |
| 5 | SHEEP | 3500 | Real `EntityType.SHEEP` |
| 6 | RABBIT | 4000 | Real `EntityType.RABBIT` (7 variants) |
| 7 | SLIME | 5000 | Real `EntityType.SLIME` |
| 8 | FROG | 5500 | Real `EntityType.FROG` (3 variants) |
| 9 | BEE | 6000 | Real `EntityType.BEE` |
| 10 | TURTLE | 6500 | Real `EntityType.TURTLE` |
| 11 | CAT | 7000 | Real `EntityType.CAT` (11 variants) |
| 12 | PARROT | 7500 | Real `EntityType.PARROT` (5 variants) |
| 13 | WOLF | 8000 | Real `EntityType.WOLF` |
| 14 | FOX | 8500 | Real `EntityType.FOX` (2 variants) |
| 15 | PANDA | 9000 | Real `EntityType.PANDA` (7 variants) |
| 16 | POLAR_BEAR | 9500 | Real `EntityType.POLAR_BEAR` |
| 17 | LLAMA | 10000 | Real `EntityType.LLAMA` (4 variants) |
| 18 | AXOLOTL | 11000 | Real `EntityType.AXOLOTL` (5 variants) |
| 19 | ALLAY | 12000 | Real `EntityType.ALLAY` |
| 20 | VEX | 13000 | Real `EntityType.VEX` |
| 21 | SNOWMAN | 14000 | Real `EntityType.SNOWMAN` |
| 22 | ZOMBIE | 15000 | Real `EntityType.ZOMBIE` (3 styles: Normal/Gold/Diamond) |
| 23 | SKELETON | 16000 | Real `EntityType.SKELETON` |
| 24 | STRIDER | 17000 | Real `EntityType.STRIDER` |
| 25 | CAMEL | 18000 | Real `EntityType.CAMEL` |
| 26 | SNIFFER | 20000 | Real `EntityType.SNIFFER` |
| 27 | PHANTOM | 25000 | Real `EntityType.PHANTOM` |
| 28 | IRON_GOLEM | 30000 | Real `EntityType.IRON_GOLEM` |
| 29 | RAVAGER | 35000 | Real `EntityType.RAVAGER` |
| 30 | WARDEN | 50000 | Real `EntityType.WARDEN` |
| 31 | WITHER | 75000 | Real `EntityType.WITHER` (2 styles: Normal/Charged) |
| 32 | GIANT | 100000 | Real `EntityType.GIANT` (AI disabled) |

**Features:** Pet-on-head toggle, baby variants (`SimpleAgeVariant`), follow with AI enabled, invulnerable/silent, scoreboard tag `"ffa_pet"`, `setPersistent(false)`, `setCollidable(false)`, variant selection GUIs.

### Modular (8 pet types, ArmorStand-based)

**Source:** `cosmetics.yml` (lines ~497–555), `PetManager.java` (158 lines)

| # | ID | Price | Implementation |
|---|-----|-------|----------------|
| 1 | pet_wolf | 600 | Invisible ArmorStand + HEART particles |
| 2 | pet_dragon | 5000 | Invisible ArmorStand + DRAGON_BREATH particles |
| 3 | pet_blaze | 1500 | Invisible ArmorStand + FLAME particles |
| 4 | pet_phantom | 2000 | Invisible ArmorStand + PORTAL particles |
| 5 | pet_golem | 1000 | Invisible ArmorStand + BLOCK_CRUMBLE particles |
| 6 | pet_cat | 400 | Invisible ArmorStand + COMPOSTER particles |
| 7 | pet_parrot | 800 | Invisible ArmorStand + NOTE particles |
| 8 | pet_enderman | 2500 | Invisible ArmorStand + REVERSE_PORTAL particles |

### ❌ MISSING (24 pets)

All non-implemented original pets: CHICKEN, PIG, COW, SHEEP, RABBIT, SLIME, FROG, BEE, TURTLE, FOX, PANDA, POLAR_BEAR, LLAMA, AXOLOTL, ALLAY, VEX, SNOWMAN, ZOMBIE, SKELETON, STRIDER, CAMEL, SNIFFER, RAVAGER, WARDEN, WITHER, GIANT.

### ⚠️ FUNDAMENTAL DIFFERENCE

| Aspect | Original | Modular |
|--------|----------|---------|
| Entity type | **Real mobs** (Chicken, Wolf, etc.) | **Invisible ArmorStands** with particles only |
| Variants | 11 variant systems (Cat×11, Rabbit×7, Axolotl×5, etc.) | None |
| Pet on head | ✅ Toggle to ride player's head | ❌ Not implemented |
| Baby toggle | ✅ Adult/Baby per pet | ❌ Not implemented |
| Follow behavior | AI-enabled mobs walking toward player | ArmorStand teleported toward player |
| Scoreboard tagging | ✅ `"ffa_pet"` tag | ❌ Uses metadata instead |
| Pet count | **32** | **8** (75% reduction) |

---

## 2. TRAILS (Walking)

### Original (27 trail types)

**Source:** `CosmeticEnums.ProjectileTrail` (lines ~131–158) — same enum shared with projectile trails and elytra trails.

| # | ID | Cost | VIP |
|---|-----|------|-----|
| 1 | NONE | 0 | — |
| 2 | SMOKE | 2000 | No |
| 3 | WATER | 2500 | No |
| 4 | SLIME | 3000 | No |
| 5 | FIRE | 3500 | No |
| 6 | LAVA | 4000 | No |
| 7 | SNOW | 4500 | No |
| 8 | ASH | 5000 | No |
| 9 | SPARK | 5500 | No |
| 10 | CLOUD | 6000 | No |
| 11 | NOTE | 6500 | No |
| 12 | CRIT | 7000 | No |
| 13 | GLOW | 7500 | No |
| 14 | INK | 8000 | No |
| 15 | LOVE | 8500 | No |
| 16 | MAGIC | 9000 | No |
| 17 | TOTEM | 9500 | No |
| 18 | WITCH | 10000 | No |
| 19 | SOUL | 11000 | No |
| 20 | CHERRY | 12000 | No |
| 21 | HEARTBREAK | 13000 | No |
| 22 | VOID | 14000 | No |
| 23 | END | 15000 | No |
| 24 | ARCTIC | 18000 | No |
| 25 | GOLD | 20000 | No |
| 26 | EMERALD | 22000 | No |
| 27 | RAINBOW | 25000 | No |

### Modular (11 walking trail types)

**Source:** `cosmetics.yml` (lines ~158–210), `TrailHandler.java` (235 lines)

| # | ID | Price | Rarity |
|---|-----|-------|--------|
| 1 | trail_flame | 350 | COMMON |
| 2 | trail_heart | 400 | RARE |
| 3 | trail_note | 350 | COMMON |
| 4 | trail_enchant | 500 | RARE |
| 5 | trail_smoke | 200 | COMMON |
| 6 | trail_drip | 450 | RARE |
| 7 | trail_rainbow | 1500 | LEGENDARY |
| 8 | trail_redstone | 300 | COMMON |
| 9 | trail_nether | 600 | EPIC |
| 10 | trail_cherry | 550 | RARE |
| 11 | trail_void | 2000 | MYTHIC |

### ❌ MISSING (16+ trails)

WATER, SLIME, LAVA, SNOW, ASH, SPARK, CLOUD, CRIT, GLOW, INK, LOVE/HEARTBREAK, MAGIC, TOTEM, WITCH, SOUL, END, ARCTIC, GOLD, EMERALD.

### ⚠️ DIFFERENCES

| Aspect | Original | Modular |
|--------|----------|---------|
| Trail count | **27** (incl. NONE) | **11** (59% reduction) |
| Enum-based | Yes (hardcoded in `ProjectileTrail` enum) | YAML-config in `cosmetics.yml` |
| Rarity system | ✅ via VIP boolean | ✅ via CosmeticRarity enum (COMMON→MYTHIC) |
| Sneaking/stationary check | Partial | ✅ Full (velocity < 0.001 skipped) |
| New trails not in original | — | trail_drip, trail_enchant, trail_redstone |

---

## 3. ELYTRA TRAILS

### Original (27 types — same ProjectileTrail enum)

Uses the exact same `ProjectileTrail` enum as walking trails. Stored with `"elytra"` prefix. Preview system equips elytra, launches player, spawns particles while gliding, and auto-restores chestplate after 60 ticks.

### Modular (22 elytra trail types)

**Source:** `cosmetics.yml` (lines ~660–850), `ElytraTrailHandler.java` (139 lines)

| # | ID | Price | Rarity |
|---|-----|-------|--------|
| 1 | elytra_rainbow | 2000 | LEGENDARY |
| 2 | elytra_fire | 800 | RARE |
| 3 | elytra_ice | 800 | RARE |
| 4 | elytra_dragon | 3000 | MYTHIC |
| 5 | elytra_starfield | 1500 | EPIC |
| 6 | elytra_toxic | 600 | COMMON |
| 7 | elytra_portal | 1200 | EPIC |
| 8 | elytra_smoke | 400 | COMMON |
| 9 | elytra_cherry | 600 | RARE |
| 10 | elytra_soul | 1000 | EPIC |
| 11 | elytra_electric | 1200 | EPIC |
| 12 | elytra_void | 4000 | MYTHIC |
| 13 | elytra_lava | 900 | RARE |
| 14 | elytra_enchant | 500 | COMMON |
| 15 | elytra_heart | 700 | RARE |
| 16 | elytra_note | 700 | RARE |
| 17 | elytra_firework | 1000 | EPIC |
| 18 | elytra_sculk | — | (handler only) |
| 19 | elytra_warden | — | (handler only) |
| 20 | elytra_nether | 800 | RARE |
| 21 | elytra_water | 500 | COMMON |
| 22 | elytra_wither | 2500 | LEGENDARY |
| 23 | elytra_redstone | 400 | COMMON |

### ✅ IMPROVED

The modular version has elytra trails as a **separate `CosmeticType.ELYTRA_TRAIL`** with its own dedicated handler. The original reused the same enum and particle-mapping code for both projectile and elytra trails.

### ❌ MISSING FEATURES

| Feature | Original | Modular |
|---------|----------|---------|
| Preview system (launch + elytra equip) | ✅ Full preview: equip elytra, launch upward, restore chestplate after 60 ticks | ❌ Not implemented |
| Separate count | 27 (shared with trail enum) | 22 (dedicated) |

---

## 4. HIT / KILL EFFECTS

### 4A. KILL EFFECTS (on-death effects)

#### Original (21 kill effects)

**Source:** `CosmeticEnums.KillEffect` (lines ~74–95)

| # | ID | Cost |
|---|-----|------|
| 1 | NONE | 0 |
| 2 | BLOOD | 1000 |
| 3 | TNT | 2000 |
| 4 | THIEF | 3000 |
| 5 | GHOST | 4000 |
| 6 | LIGHTNING | 5000 |
| 7 | SQUID | 5500 |
| 8 | FIREWORK | 6000 |
| 9 | VORTEX | 7000 |
| 10 | METEOR | 8000 |
| 11 | ICE_SHATTER | 9000 |
| 12 | ZEUS | 10000 |
| 13 | HOLY_RAY | 11000 |
| 14 | PINATA | 12000 |
| 15 | LAUNCH | 13000 |
| 16 | TORNADO | 14000 |
| 17 | SCULK_EXPLOSION | 15000 |
| 18 | WARDEN_SOUL | 16000 |
| 19 | BLACK_HOLE | 20000 |
| 20 | ALIEN | 25000 |
| 21 | GRAVITY | 30000 |

#### Modular (7 kill effects)

**Source:** `cosmetics.yml` (lines ~21–85), `KillEffectHandler.java` (215 lines)

| # | ID | Price | Rarity |
|---|-----|-------|--------|
| 1 | lightning_strike | 500 | RARE |
| 2 | fire_burst | 300 | COMMON |
| 3 | soul_burst | 800 | EPIC |
| 4 | blood_splash | 200 | COMMON |
| 5 | ender_burst | 1000 | LEGENDARY |
| 6 | wither_storm | 1200 | LEGENDARY |
| 7 | ice_shatter | 700 | EPIC |

#### ❌ MISSING (14 kill effects)

TNT, THIEF, GHOST, SQUID, FIREWORK, VORTEX, METEOR, ZEUS, HOLY_RAY, PINATA, LAUNCH, TORNADO, SCULK_EXPLOSION, WARDEN_SOUL, BLACK_HOLE, ALIEN, GRAVITY.

### 4B. HIT EFFECTS (on-attack particle effects)

#### Original (15 hit effects — SEPARATE SYSTEM)

**Source:** `HitEffectsManager.java` (568 lines) — completely separate from kill effects

| # | ID | Price | Particle | Sound |
|---|-----|-------|----------|-------|
| 1 | blood | 3000 | DAMAGE_INDICATOR | HURT |
| 2 | lightning | 8000 | ELECTRIC_SPARK | THUNDER |
| 3 | explosion | 6000 | EXPLOSION | EXPLODE |
| 4 | freeze | 5000 | SNOWFLAKE | GLASS_BREAK |
| 5 | fire | 4000 | FLAME | BLAZE_SHOOT |
| 6 | poison | 4500 | ITEM_SLIME | WITCH_DRINK |
| 7 | ender | 7000 | PORTAL | ENDERMAN_TELEPORT |
| 8 | hearts | 3500 | HEART | VILLAGER_YES |
| 9 | critical | 5500 | CRIT_MAGIC | ATTACK_CRIT |
| 10 | slime | 4000 | ITEM_SLIME | SLIME_SQUISH |
| 11 | witch | 6000 | SPELL_WITCH | WITCH_THROW |
| 12 | dragon | 10000 | DRAGON_BREATH | DRAGON_GROWL |
| 13 | star | 7500 | END_ROD | TOTEM_USE |
| 14 | smoke | 2000 | LARGE_SMOKE | FIRE_EXTINGUISH |
| 15 | magic | 8500 | ENCHANTMENT_TABLE | ENCHANT |

Features: Preview with zombie dummy entity, own YAML persistence (`hit_effects_data.yml`), GUI with 45-slot inventory.

#### Modular: ❌ COMPLETELY MISSING

No `HitEffect` type in `CosmeticType.java`. No handler file. No YAML config entries. The entire on-attack hit effects system does not exist in the modular rewrite.

---

## 5. CRATES / MYSTERY BOXES

### Original

**Source:** `CosmeticsManager.java` (lines ~1540–1700)

- **1 mystery box type** (cost configurable from `shop.yml`, default $1000)
- Rarity weights: COMMON=45, RARE=30, EPIC=18, LEGENDARY=6, MYTHIC=1
- Duplicate refund: $200 (configurable)
- Pool: ALL cosmetic categories (KillEffects, Auras, Trails, DeathSounds, Pets, etc.)
- Opening animation: 10-tick note particle + pitch-increasing sound
- **Preview GUI:** Paginated (28 items/page), sorted by rarity, shows probability percentages

### Modular

**Source:** `cosmetics.yml` (lines ~1002–1043), `MysteryBoxManager.java` (186 lines), `CosmeticRegistry.java`

- **3 mystery box types:**

| Box | Price | COMMON | RARE | EPIC | LEGENDARY | MYTHIC |
|-----|-------|--------|------|------|-----------|--------|
| basic | 200 | 60 | 30 | 8 | 2 | 0 |
| premium | 500 | 20 | 35 | 30 | 12 | 3 |
| mythic | 1500 | 0 | 0 | 50 | 35 | 15 |

- Weighted random rarity selection with ownership filtering
- Anti-double-open protection (`opening` Set)
- Animated reveal: 8 suspense ticks with increasing speed
- Rarity-based reveal sound (MYTHIC gets dragon growl + challenge complete)
- Broadcast for LEGENDARY+ pulls
- Unlocks BEFORE animation (prevents disconnect issues)

### ✅ IMPROVED in Modular

| Feature | Original | Modular |
|---------|----------|---------|
| Box tiers | 1 | **3** (basic/premium/mythic) |
| Configuration | YAML weights | YAML-driven with multiple boxes |
| Anti-double-open | Not explicit | ✅ `opening` Set |
| Safe unlock timing | After animation | **Before animation** (disconnect-safe) |
| Broadcast threshold | Not specified | LEGENDARY+ |

### ❌ MISSING in Modular

| Feature | Status |
|---------|--------|
| Duplicate refund system ($200 on dupe) | ❌ Missing — returns `null` / "all owned" instead |
| Paginated preview GUI (28 items/page, rarity sorting, probability %) | ❌ Missing |

---

## 6. PRESTIGE

### Original (10 prestige levels)

**Source:** `PrestigeManager.java` (lines ~39–49)

| Level | Kills Required | Money Cost | Money Reward | Money Bonus | Shop Discount |
|-------|---------------|------------|--------------|-------------|---------------|
| P1 | 100 | $0 | $5,000 | +5% | 5% |
| P2 | 250 | $25,000 | $10,000 | +10% | 7% |
| P3 | 500 | $75,000 | $25,000 | +15% | 10% |
| P4 | 750 | $150,000 | $50,000 | +20% | 12% |
| P5 | 1,000 | $300,000 | $75,000 | +25% | 15% |
| P6 | 2,000 | $500,000 | $100,000 | +35% | 17% |
| P7 | 3,000 | $800,000 | $150,000 | +50% | 18% |
| P8 | 4,000 | $1,500,000 | $250,000 | +75% | 19% |
| P9 | 5,000 | $2,500,000 | $500,000 | +90% | 20% |
| P10 | 7,500 | $3,000,000 | $2,500,000 | +100% | 20% |

Features: Confirmation GUI, global broadcast, TOTEM + END_ROD particles, scoreboard update, chat prefix per level. Does **NOT** reset kills or level.

### Modular (5 prestige levels)

**Source:** `PrestigeManager.java` (149 lines)

| Level | Requirement | XP Multiplier |
|-------|-------------|---------------|
| P0 | — | 1.0× |
| P1 | Max Level | 1.1× |
| P2 | Max Level | 1.25× |
| P3 | Max Level | 1.5× |
| P4 | Max Level | 2.0× |
| P5 | Max Level | 3.0× |

Mechanic: **Resets level to 1 and XP to 0** on prestige. Grants permanent XP multiplier. Global broadcast, title display, sound feedback.

### ⚠️ FUNDAMENTALLY DIFFERENT SYSTEM

| Aspect | Original | Modular |
|--------|----------|---------|
| Max prestige | **10** | **5** |
| Prestige cost | Money ($0–$3M) + Kill count | Reaching max level only |
| Reset on prestige | ❌ Nothing resets | ✅ **Level + XP reset to 0** |
| Money bonus per prestige | ✅ +5% to +100% | ❌ Not implemented |
| Shop discount per prestige | ✅ 5%–20% | ❌ Not implemented |
| Money reward on prestige | ✅ $5K–$2.5M | ❌ Not implemented |
| Kill requirement | ✅ 100–7,500 kills | ❌ Level-based only |
| Confirmation GUI | ✅ Yes | ❌ No (direct command) |
| Chat prefix | ✅ Per-level prefix | ❌ Via message config |
| Visual particles | ✅ TOTEM + END_ROD | Sound only |

### ❌ MISSING

- 5 prestige levels (P6–P10)
- Money cost system
- Kill requirements
- Money bonus % per prestige
- Shop discount % per prestige
- Money rewards on prestige
- Confirmation GUI
- Visual particle effects on prestige

---

## 7. MISSIONS

### Original (30+ mission types)

**Source:** `MissionsManager.java` (888 lines)

- **4 difficulty levels:** EASY (reward $300–$500), MEDIUM ($800–$1,500), HARD ($2,000–$4,000), EPIC ($10,000–$20,000)
- **5 categories:** PVP, ECONOMY, SOCIAL, EXPLORATION, SPECIAL
- **Daily missions:** configurable count (default 4), distribution: 1 EASY + (count-2) MEDIUM + 1 HARD/EPIC
- **Weekly missions:** enabled, count=3, goal multiplier 3.5×, reward $10,000–$20,000
- **Streak milestones:** day 3 (+10% bonus, $1,000), day 7 ($5,000), day 30 ($25,000)
- **GUI:** 54-slot inventory with daily slots [10,11,12,13], weekly slots [28,29,30], streak display slot 4
- **Auto-reset task:** Runs every minute, checks 24h daily / 168h weekly timers
- **Storage:** `missions_data.yml` (YAML-based)

### Modular (22 mission types)

**Source:** `MissionManager.java` (477 lines), `Mission.java`, `MissionType.java`

**14 Daily Missions:**

| ID | Name | Target | Coins | XP |
|----|------|--------|-------|-----|
| kill_5 | Cazador Novato | 5 kills | 100 | 150 |
| kill_10 | Cazador Experto | 10 kills | 200 | 300 |
| kill_20 | Máquina de Matar | 20 kills | 400 | 600 |
| damage_500 | Daño Brutal | 500 dmg | 150 | 200 |
| damage_2000 | Destructor | 2000 dmg | 350 | 500 |
| mine_50 | Minero Diario | 50 blocks | 80 | 120 |
| mine_200 | Minero Intenso | 200 blocks | 200 | 300 |
| survive_10m | Superviviente | 10 min | 120 | 180 |
| survive_30m | Inmortal | 30 min | 300 | 500 |
| streak_3 | Racha Rápida | 3 killstreak | 200 | 250 |
| streak_5 | Racha Mortal | 5 killstreak | 350 | 400 |
| travel_1000 | Caminante | 1000 blocks | 100 | 150 |
| travel_5000 | Maratón | 5000 blocks | 250 | 350 |
| play_30m | Jugador Activo | 30 min | 100 | 150 |

**8 Weekly Missions:**

| ID | Name | Target | Coins | XP |
|----|------|--------|-------|-----|
| kill_100_w | Carnicero Semanal | 100 kills | 800 | 1500 |
| mine_1000_w | Excavador Semanal | 1000 blocks | 600 | 1000 |
| travel_50k_w | Explorador Semanal | 50000 blocks | 700 | 1200 |
| damage_10k_w | Guerrero Semanal | 10000 dmg | 900 | 1500 |
| play_5h_w | Dedicación Semanal | 5 hours | 500 | 800 |
| streak_10_w | Racha Legendaria | 10 killstreak | 1000 | 2000 |
| win_duels_5_w | Duelista | 5 duel wins | 600 | 1000 |
| missions_5_w | Multitarea | 5 daily missions | 500 | 800 |

### ✅ IMPROVED in Modular

| Feature | Original | Modular |
|---------|----------|---------|
| Storage | YAML file | **SQL database** (ethernova_missions + ethernova_mission_resets) |
| XP rewards | ❌ Money only | ✅ **Coins + XP** |
| Mission struct | Config-driven | **Java record** + SQL |
| EVENT mission type | ❌ | ✅ `MissionType.EVENT` (no auto-reset) |
| Pattern-based progress | ❌ | ✅ `incrementByPattern()` |
| Achievement integration | ❌ | ✅ `mission_master` achievement tracking |

### ❌ MISSING in Modular

| Feature | Status |
|---------|--------|
| Difficulty classification (EASY/MEDIUM/HARD/EPIC) | ❌ All missions are flat — no difficulty tiers |
| Category system (PVP/ECONOMY/SOCIAL/EXPLORATION/SPECIAL) | ❌ No categorization |
| Difficulty-based reward scaling | ❌ Fixed per-mission |
| Streak milestones (day 3/7/30 bonuses: $1K/$5K/$25K) | ❌ No streak system |
| Mission GUI (54-slot inventory) | ❌ No GUI (MissionGui.java exists as file but not shown in manager) |
| Difficulty distribution in assignment (1 EASY + N MEDIUM + 1 HARD) | ❌ Pure random from pool |
| Weekly goal multiplier (3.5×) | ❌ Fixed targets per mission |
| Config-driven mission definitions | ❌ **Hardcoded** in Java (original was YAML-driven) |

---

## 8. WEEKLY CALENDAR / DAILY REWARDS

### Original

**Source:** `CosmeticsManager.java` (lines ~86–90, ~596–610)

- **7-day cycle:** day1=$100, day2=$250, day3=$500, day4=$1,000, day5=$2,000, day6=$3,500, day7=$5,000
- Cooldown: 86,400,000ms (24h), configurable from `shop.yml`
- Tracked via storageProvider: `daily_streak` counter + `last_claim` timestamp
- Calendar GUI handling in `handleShopClick`

### Modular

**Source:** `DailyRewardManager.java` (305 lines)

- **7-day cycle** (config-driven, defaults if no config):

| Day | Name | Default Coins | Default XP | Icon |
|-----|------|---------------|------------|------|
| 1 | Día 1 | 100 | 50 | IRON_INGOT |
| 2 | Día 2 | 200 | 100 | GOLD_INGOT |
| 3 | Día 3 | 300 | 150 | DIAMOND |
| 4 | Día 4 | 400 | 200 | EMERALD |
| 5 | Día 5 | 500 | 250 | LAPIS_LAZULI |
| 6 | Día 6 | 600 | 300 | AMETHYST_SHARD |
| 7 | Día 7 | 700 | 350 | NETHER_STAR |

- **GUI:** 27-slot inventory with 7 reward slots (10–16), border panes, status indicators (✔ Reclamado / Click para reclamar / Disponible en X día(s))
- **Streak logic:** >48h since last claim = reset to day 1
- **Storage:** SQL table `ethernova_daily_rewards` (uuid, current_day, last_claim, total_claims)

### ✅ IMPROVED in Modular

| Feature | Original | Modular |
|---------|----------|---------|
| Storage | YAML | **SQL database** |
| XP rewards | ❌ Money only | ✅ **Coins + XP** |
| GUI | Basic | ✅ **27-slot with status indicators** |
| Config-driven | Partial | ✅ Fully configurable rewards from YAML |
| Streak reset | 24h cooldown | **48h grace period** with streak reset |
| Total claims tracking | ❌ | ✅ `total_claims` counter |

### ⚠️ DIFFERENT

| Aspect | Original | Modular |
|--------|----------|---------|
| Day 7 reward | **$5,000** | **700 coins** (86% lower) |
| Reward scaling | Exponential ($100→$5,000) | Linear ($100→$700) |
| Overall value | $12,350 per cycle | $2,800 per cycle + 1,400 XP |

---

## 9. PARTY

### Original

**Source:** `PartyManager.java` (1,226 lines), `PartyGamesManager.java` (1,964 lines)

**PartyManager features:**
- Create/disband/invite/accept/deny/kick/leave
- Transfer leadership
- Party chat toggle
- Friendly fire toggle
- Public/private toggle
- Max members configurable
- Auto-expire invites (30s)
- Clickable accept/deny buttons (TextComponent)
- Inner `Party` class tracking: leader UUID, members Set, friendlyFire, isPublic, createdTime, totalKills, totalDeaths

### Modular

**Source:** `PartyManager.java` (894 lines), `Party.java` (231 lines), `PartyRole.java`, `PartySettings.java`

**Features:**
- Create/disband/invite/accept/decline/kick/leave
- Role system: LEADER (★), MODERATOR (◆), MEMBER (●)
- PartySettings: friendlyFire, autoAcceptFriends, isPublic, maxSize, allowModeratorInvite, partyChat
- DB persistence via PartyStorageManager
- EventBus integration (PartyCreateEvent, PartyDisbandEvent, PartyJoinEvent, PartyLeaveEvent)
- Clickable accept (ClickEvent.runCommand)
- Configurable invite timeout (default 60s)
- Dirty tracking for efficient DB saves
- Thread-safe ConcurrentHashMap storage
- Teleport cooldowns
- Buff system integration (PartyBuffManager)
- Ready-check system (PartyReadyCheckManager)

### ✅ IMPROVED in Modular

| Feature | Original | Modular |
|---------|----------|---------|
| Role system | Leader/Member (2 roles) | **Leader/Moderator/Member** (3 roles) |
| Persistence | In-memory only | **SQL database** |
| Event system | ❌ | ✅ EventBus with 5 event types |
| Settings object | Inline booleans | **PartySettings** class (JSON-serializable) |
| Moderator permissions | ❌ | ✅ Configurable (canInvite, canKick, canTeleport) |
| Auto-accept friends | ❌ | ✅ Setting |
| Buff system | ❌ | ✅ PartyBuffManager integration |
| Ready-check | ❌ | ✅ PartyReadyCheckManager |
| Dirty tracking | ❌ | ✅ Efficient saves |
| Invite timeout | 30s fixed | 60s configurable |

### ❌ MISSING in Modular

| Feature | Status |
|---------|--------|
| Total kills/deaths tracking per party | ❌ Not in Party model |
| Transfer leadership (as standalone action) | Handled via `promote()` but no explicit "transfer" command found in read portion |

---

## 10. FINISHERS

### Original (8 finisher types)

**Source:** `FinishersManager.java` (670 lines)

| # | ID | Features |
|---|-----|----------|
| 1 | execution | Animated particle sequence |
| 2 | lightning | Lightning + electric particles |
| 3 | implosion | Inward-pulling particles |
| 4 | explosion | Outward blast |
| 5 | ascension | Soul rising upward |
| 6 | disintegrate | Body dissolving |
| 7 | freeze | Ice crystal formation |
| 8 | inferno | Fire engulf |

Additional features: Cooldown system, chance-based trigger, visibility radius broadcast, preview system, rarity system (COMMON/RARE/EPIC/LEGENDARY from config), persistence in `finishers_data.yml`.

### Modular (8 finisher types)

**Source:** `cosmetics.yml` (lines ~409–494), `FinisherHandler.java` (175 lines)

| # | ID | Price | Rarity | Mapped Original |
|---|-----|-------|--------|-----------------|
| 1 | finisher_lightning_slam | 800 | RARE | lightning |
| 2 | finisher_tornado | 1200 | EPIC | implosion (?) |
| 3 | finisher_execution | 1000 | EPIC | execution |
| 4 | finisher_explosion | 1500 | LEGENDARY | explosion |
| 5 | finisher_freeze | 900 | RARE | freeze |
| 6 | finisher_disintegrate | 2000 | LEGENDARY | disintegrate |
| 7 | finisher_ascend | 1800 | LEGENDARY | ascension |
| 8 | finisher_void_consume | 3000 | MYTHIC | (NEW — replaces inferno?) |

### ⚠️ DIFFERENCES

| Aspect | Original | Modular |
|--------|----------|---------|
| Count | **8** | **8** ✅ |
| Cooldown system | ✅ Per-player cooldown | ❌ Not implemented |
| Chance-based trigger | ✅ Configurable % | ❌ Always triggers |
| Visibility radius | ✅ Broadcast to nearby | ❌ No radius check |
| Preview system | ✅ Preview in GUI | ❌ Not implemented |
| Persistence | `finishers_data.yml` | Via `PlayerCosmeticManager` (unified) |
| IDs changed | `inferno` | → `void_consume` (NEW) |
| IDs changed | `implosion` | → `tornado` (different effect) |

### ❌ MISSING

- Cooldown system
- Chance-based trigger
- Visibility radius broadcast
- Preview system
- `inferno` finisher (replaced by `void_consume`)
- `implosion` finisher (replaced by `tornado`)

---

## 11. DEATH SOUNDS

### Original (11 death sounds)

**Source:** `CosmeticEnums.DeathSound` (lines ~160–171)

| # | ID | Cost | Icon | Sound |
|---|-----|------|------|-------|
| 1 | NONE | 0 | — | — |
| 2 | ANVIL | 1000 | ANVIL | BLOCK_ANVIL_LAND |
| 3 | VILLAGER | 1000 | VILLAGER_SPAWN_EGG | VILLAGER_NO |
| 4 | BURP | 1500 | HONEY_BOTTLE | ENTITY_PLAYER_BURP |
| 5 | BELL | 2000 | BELL | BLOCK_BELL_USE |
| 6 | CAT | 3000 | CAT_SPAWN_EGG | ENTITY_CAT_AMBIENT |
| 7 | GLASS | 3500 | GLASS | BLOCK_GLASS_BREAK |
| 8 | LEVEL_UP | 4000 | EXPERIENCE_BOTTLE | ENTITY_PLAYER_LEVELUP |
| 9 | EXPLODE | 5000 | TNT | ENTITY_GENERIC_EXPLODE |
| 10 | ENDERMAN | 6000 | ENDER_PEARL | ENTITY_ENDERMAN_TELEPORT |
| 11 | GOAT | 8000 | GOAT_SPAWN_EGG | ENTITY_GOAT_SCREAMING_AMBIENT |

### Modular (10 death sounds)

**Source:** `cosmetics.yml` (lines ~851–940), `DeathSoundHandler.java` (62 lines)

| # | ID | Price | Rarity | Original Match |
|---|-----|-------|--------|----------------|
| 1 | dsound_pling | 200 | COMMON | **NEW** |
| 2 | dsound_anvil | 300 | COMMON | ✅ ANVIL |
| 3 | dsound_dragon | 1500 | LEGENDARY | **NEW** |
| 4 | dsound_wither | 1200 | EPIC | **NEW** |
| 5 | dsound_totem | 800 | RARE | **NEW** |
| 6 | dsound_bell | 400 | COMMON | ✅ BELL |
| 7 | dsound_thunder | 600 | RARE | **NEW** |
| 8 | dsound_horn | 1000 | EPIC | **NEW** |
| 9 | dsound_explosion | 500 | RARE | ✅ EXPLODE |
| 10 | dsound_levelup | 300 | COMMON | ✅ LEVEL_UP |

### ❌ MISSING from Original

| Sound | Status |
|-------|--------|
| VILLAGER | ❌ Not in modular |
| BURP | ❌ Not in modular |
| CAT | ❌ Not in modular |
| GLASS | ❌ Not in modular |
| ENDERMAN | ❌ Not in modular |
| GOAT | ❌ Not in modular |

### ✅ NEW in Modular (not in original)

dsound_pling, dsound_dragon, dsound_wither, dsound_totem, dsound_thunder, dsound_horn (6 new sounds).

### Summary

- Original: 11 sounds (incl. NONE). Modular: 10 sounds.
- **4 sounds match** (ANVIL, BELL, EXPLODE, LEVEL_UP)
- **6 original sounds missing** (VILLAGER, BURP, CAT, GLASS, ENDERMAN, GOAT)
- **6 new sounds added** (pling, dragon, wither, totem, thunder, horn)

---

## 12. SUMMARY MATRIX

| System | Original Count | Modular Count | % Coverage | Status |
|--------|---------------|---------------|------------|--------|
| **Pets** | 32 types + variants | 8 types | 25% | ❌ Major gap + different implementation |
| **Trails (Walking)** | 27 types | 11 types | 41% | ❌ Large gap |
| **Elytra Trails** | 27 types (shared) | 22 types (dedicated) | 81% | ⚠️ Good coverage, different arch |
| **Kill Effects** | 21 types | 7 types | 33% | ❌ Major gap |
| **Hit Effects** | 15 types | 0 types | 0% | ❌ **COMPLETELY MISSING** |
| **Mystery Boxes** | 1 box | 3 boxes | ✅ Improved | ✅ Better (but missing preview GUI) |
| **Prestige** | 10 levels | 5 levels | 50% | ⚠️ Fundamentally different mechanic |
| **Missions** | 30+ (config) | 22 (hardcoded) | 73% | ⚠️ Missing difficulty/categories/streaks |
| **Daily Rewards** | 7-day ($12,350) | 7-day ($2,800+XP) | ✅ Feature-complete | ✅ Better arch, lower values |
| **Party** | Basic (2 roles) | Enhanced (3 roles) | ✅ Improved | ✅ Better (DB, events, buffs) |
| **Party Games** | 7 modes + challenges | 7 modes | 90% | ⚠️ Missing challenge subtypes/rounds |
| **Finishers** | 8 types + extras | 8 types | 100% | ⚠️ Missing cooldown/chance/preview |
| **Death Sounds** | 11 types | 10 types | 36% (4 match) | ⚠️ Mostly replaced with different sounds |

### Critical Missing Systems

1. **Hit Effects (on-attack)** — 15 effects, entire system absent
2. **24 Pet types** — 75% of original pets missing + variant systems + real mob entities
3. **14 Kill Effects** — 67% of original effects missing
4. **16 Walking Trails** — 59% of original trails missing
5. **Mission difficulty/category/streak systems** — structural features absent
6. **Prestige money cost + kill requirements + shop discounts** — different philosophy

### Architectural Improvements in Modular

1. **YAML-driven cosmetic registry** — all cosmetics configurable without code changes
2. **SQL database** for missions, daily rewards, party (vs YAML files)
3. **CosmeticRarity enum** with 5 tiers and color codes
4. **Modular architecture** — separate plugins per subsystem
5. **EventBus** for cross-plugin communication
6. **Thread-safe** ConcurrentHashMap usage throughout
7. **MiniMessage** formatting (vs legacy ChatColor)
8. **Record types** for immutable data (Mission, Cosmetic, etc.)
9. **Multiple mystery box tiers** with configurable weights
10. **Party role system** (Leader/Moderator/Member) with granular permissions
