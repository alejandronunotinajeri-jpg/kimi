# 🌐 Ethernova — Ecosistema de Plugins para Minecraft

> Suite modular de plugins PvP/Clanes para Paper 1.21.4 · Java 21

[![Build](https://img.shields.io/badge/build-Maven-blue)](#compilación)
[![Java](https://img.shields.io/badge/Java-21-orange)](#requisitos)
[![Paper](https://img.shields.io/badge/Paper-1.21.4-green)](#requisitos)

---

## 📋 Módulos

| Módulo | Descripción | API |
|--------|------------|-----|
| **EthernovaCore** | Núcleo: perfiles, economía, XP, cooldowns, scoreboards, métricas | `CoreAPI` |
| **EthernovaClans** | Clanes completos: territorios, guerras, alianzas, naciones, diplomacia | `ClanAPI` |
| **EthernovaCombat** | Sistema de combate: tags, killstreaks, NPCs, bounties, anti-cheat | `CombatAPI` |
| **EthernovaCosmetics** | Cosméticos: trails, efectos de muerte/kill/victoria, cajas misteriosas | `CosmeticsAPI` |
| **EthernovaParty** | Grupos: invitaciones, buffs, ready checks, chat de party | `PartyAPI` |
| **EthernovaProgression** | Progresión: niveles, prestigio, logros, misiones, pase de batalla | `ProgressionAPI` |
| **EthernovaRanked** | Ranked: ELO, rangos, temporadas, leaderboards | `RankedAPI` |
| **EthernovaDuels** | Duelos 1v1: kits, arenas, apuestas, estadísticas | `DuelsAPI` |
| **EthernovaFFA** | Free-For-All: arenas, kits, protección de spawn, estadísticas | `FFAAPI` |

---

## 🏗️ Arquitectura

```
ethernova-parent (Maven multi-module)
├── core/           → EthernovaCore (dependencia obligatoria de todos)
├── combat/         → EthernovaCombat
├── src/            → EthernovaClans
├── cosmetics/      → EthernovaCosmetics
├── party/          → EthernovaParty
├── progression/    → EthernovaProgression
├── ranked/         → EthernovaRanked
├── duels/          → EthernovaDuels
└── ffa/            → EthernovaFFA
```

### Comunicación entre plugins

- **ServiceRegistry** — Patrón Service Locator para APIs tipadas
- **EventBus** — Sistema de eventos publish/subscribe (en Core)
- **CrossServerMessenger** — Mensajería cross-server vía Plugin Messaging

```java
// Proveedor (en onEnable):
ServiceRegistry.register(MyAPI.class, new MyAPIImpl());

// Consumidor (desde cualquier plugin):
MyAPI api = ServiceRegistry.get(MyAPI.class);
if (api != null) { api.doSomething(); }
```

---

## 📦 Requisitos

- **Java** 21+
- **Paper** 1.21.4+
- **Vault** (economía)
- **PlaceholderAPI** (placeholders)
- **DecentHolograms** (hologramas, opcional)

---

## 🔨 Compilación

```bash
# Compilar todo el ecosistema
mvn clean package -DskipTests

# Ejecutar tests
mvn test

# Solo un módulo
mvn clean package -pl core -DskipTests
```

Los JARs resultantes estarán en `{modulo}/target/`.

---

## 🔌 API Pública

Cada módulo expone una API pública a través del `ServiceRegistry` de Core.

### Ejemplo: Verificar si un jugador está en combate

```java
import com.ethernova.combat.api.CombatAPI;
import com.ethernova.core.service.ServiceRegistry;

CombatAPI combat = ServiceRegistry.get(CombatAPI.class);
if (combat != null && combat.isInCombat(player.getUniqueId())) {
    // Jugador en combate
}
```

### Ejemplo: Obtener el clan de un jugador

```java
import com.ethernova.clans.api.ClanAPI;
import com.ethernova.core.service.ServiceRegistry;

ClanAPI clans = ServiceRegistry.get(ClanAPI.class);
if (clans != null) {
    Clan clan = clans.getPlayerClan(player.getUniqueId());
}
```

### APIs disponibles

| Clase | Módulo | Métodos principales |
|-------|--------|---------------------|
| `CoreAPI` | Core | `getProfile`, `addCoins`, `addXP`, `getMessage`, `playSound`, `setCooldown` |
| `ClanAPI` | Clans | `getPlayerClan`, `isInClan`, `getAllClans`, `getClanPower`, `isAlly` |
| `CombatAPI` | Combat | `isInCombat`, `tag`, `untag`, `getKillStreak`, `isNewbieProtected` |
| `CosmeticsAPI` | Cosmetics | `isUnlocked`, `equip`, `getEquipped`, `triggerKillEffect`, `hasActiveTrail` |
| `PartyAPI` | Party | `getParty`, `isInParty`, `areInSameParty`, `shouldCancelDamage`, `getXPMultiplier` |
| `ProgressionAPI` | Progression | `addXP`, `getMaxLevel`, `isAchievementCompleted`, `getBattlePassTier` |
| `RankedAPI` | Ranked | `getElo`, `getRank`, `getWins`, `processResult`, `getCurrentSeason` |
| `DuelsAPI` | Duels | `isInDuel`, `getMatch`, `getDuelWins`, `getDetailedStats`, `kitExists` |
| `FFAAPI` | FFA | `isInFFA`, `getPlayerArena`, `getPlayerCount`, `getFFAKills`, `getKDR` |

---

## 📊 Métricas (bStats)

EthernovaCore recopila métricas anónimas centralizadas para todo el ecosistema:
- Módulos activos
- Tipo de almacenamiento
- Modo de servidor
- Idioma configurado

Desactivar en `core/config.yml`:
```yaml
metrics:
  enabled: false
```

---

## 🧪 Tests

El proyecto usa **JUnit 5** + **Mockito** para tests unitarios.

```bash
mvn test
```

Tests incluidos:
- `EloCalculatorTest` — Cálculos de ELO, K-factors, previews
- `ServiceRegistryTest` — Registro, obtención, limpieza de servicios
- `CooldownManagerTest` — Cooldowns, expiración, formato

---

## 📁 Estructura de configuración

Cada plugin genera su propia carpeta de configuración:
```
plugins/
├── EthernovaCore/
│   ├── config.yml          (configuración principal + scoreboards)
│   └── messages_es.yml     (mensajes i18n)
├── EthernovaClans/
│   ├── config.yml
│   ├── messages_es.yml
│   └── arenas.yml
├── EthernovaCombat/
│   ├── config.yml
│   └── messages.yml
└── ...
```

---

## 📝 Licencia

Código propietario — © Ethernova Network. Todos los derechos reservados.
