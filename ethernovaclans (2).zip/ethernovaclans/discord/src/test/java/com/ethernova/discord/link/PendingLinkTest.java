package com.ethernova.discord.link;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class PendingLinkTest {

    @Nested
    @DisplayName("PendingLink record")
    class PendingLinkTests {
        @Test
        void fieldsAccessible() {
            UUID uuid = UUID.randomUUID();
            var link = new LinkManager.PendingLink(uuid, "Steve", System.currentTimeMillis() + 60_000);
            assertEquals(uuid, link.mcUuid());
            assertEquals("Steve", link.mcName());
        }

        @Test
        void notExpiredWhenFuture() {
            var link = new LinkManager.PendingLink(UUID.randomUUID(), "Steve",
                    System.currentTimeMillis() + 60_000);
            assertFalse(link.isExpired());
        }

        @Test
        void expiredWhenPast() {
            var link = new LinkManager.PendingLink(UUID.randomUUID(), "Steve",
                    System.currentTimeMillis() - 1000);
            assertTrue(link.isExpired());
        }

        @Test
        void expiredWhenTimeHasPassed() {
            // isExpired() returns true when currentTimeMillis() > expiresAt
            var link = new LinkManager.PendingLink(UUID.randomUUID(), "Steve",
                    System.currentTimeMillis() - 100);
            assertTrue(link.isExpired());
        }
    }
}
