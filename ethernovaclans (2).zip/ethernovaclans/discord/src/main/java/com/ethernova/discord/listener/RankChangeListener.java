package com.ethernova.discord.listener;

import com.ethernova.core.service.ServiceRegistry;
import com.ethernova.discord.EthernovaDiscord;
import com.ethernova.ranked.api.RankedAPI;
import com.ethernova.ranked.model.Rank;
import com.ethernova.ranked.model.RankedProfile;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Escucha eventos de cambio de rango del sistema de ELO.
 * Cuando un jugador sube o baja de rango, actualiza sus roles en Discord.
 * También sincroniza al conectarse al servidor.
 */
public class RankChangeListener implements Listener {

    private final EthernovaDiscord plugin;
    /** Caché del último rango conocido por jugador para detectar cambios. */
    private final Map<UUID, String> lastKnownRank = new ConcurrentHashMap<>();

    public RankChangeListener(EthernovaDiscord plugin) {
        this.plugin = plugin;

        // Collect player list on main thread, then check ranks async
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            Map<UUID, String> onlinePlayers = new HashMap<>();
            for (Player p : Bukkit.getOnlinePlayers()) {
                onlinePlayers.put(p.getUniqueId(), p.getName());
            }
            if (!onlinePlayers.isEmpty()) {
                Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> checkRankChanges(onlinePlayers));
            }
        }, 200L, 200L);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        // Sincronizar roles al conectarse (con delay para que se cargue el perfil)
        Bukkit.getScheduler().runTaskLaterAsynchronously(plugin, () -> {
            RankedAPI api = ServiceRegistry.get(RankedAPI.class);
            if (api == null) return;

            Rank rank = api.getRank(player.getUniqueId());
            int elo = api.getElo(player.getUniqueId());

            lastKnownRank.put(player.getUniqueId(), rank.getId());
            plugin.getRoleSyncManager().syncPlayer(player.getUniqueId(), player.getName(), rank, elo);
        }, 60L); // 3 segundos para que se cargue el perfil
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerQuit(PlayerQuitEvent event) {
        lastKnownRank.remove(event.getPlayer().getUniqueId());
    }

    /**
     * Revisa periódicamente si algún jugador online cambió de rango.
     * Runs on async thread. Player map collected on main thread.
     */
    private void checkRankChanges(Map<UUID, String> onlinePlayers) {
        RankedAPI api = ServiceRegistry.get(RankedAPI.class);
        if (api == null) return;

        for (Map.Entry<UUID, String> entry : onlinePlayers.entrySet()) {
            UUID uuid = entry.getKey();
            String playerName = entry.getValue();
            Rank currentRank = api.getRank(uuid);
            int elo = api.getElo(uuid);
            String previousRankId = lastKnownRank.get(uuid);

            if (previousRankId != null && !previousRankId.equals(currentRank.getId())) {
                // ¡Cambio de rango detectado!
                Rank previousRank = Rank.fromElo(0); // fallback
                for (Rank r : Rank.values()) {
                    if (r.getId().equals(previousRankId)) {
                        previousRank = r;
                        break;
                    }
                }

                boolean isPromotion = currentRank.getOrdinal() > previousRank.getOrdinal();

                // Sincronizar roles
                plugin.getRoleSyncManager().syncPlayer(uuid, playerName, currentRank, elo);

                // Anunciar en Discord
                if (plugin.getBot() != null && plugin.getBot().isReady()) {
                    plugin.getBot().sendRankChangeAnnouncement(
                            playerName,
                            previousRank.getDisplayName(),
                            currentRank.getDisplayName(),
                            elo,
                            isPromotion
                    );
                }
            }

            lastKnownRank.put(uuid, currentRank.getId());
        }
    }
}
