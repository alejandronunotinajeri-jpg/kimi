package com.ethernova.discord.command;

import com.ethernova.discord.EthernovaDiscord;
import com.ethernova.discord.link.LinkManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Comando in-game /discord — Gestión de vinculación MC↔Discord.
 *
 * Subcomandos:
 *   /discord link     — Genera un código para vincular tu cuenta
 *   /discord unlink   — Desvincula tu cuenta de Discord
 *   /discord status   — Muestra el estado de tu vinculación
 *   /discord info     — Muestra info del bot
 */
public class DiscordCommand implements CommandExecutor, TabCompleter {

    private final EthernovaDiscord plugin;

    public DiscordCommand(EthernovaDiscord plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        String sub = args[0].toLowerCase();
        return switch (sub) {
            case "link" -> handleLink(sender);
            case "unlink" -> handleUnlink(sender);
            case "status" -> handleStatus(sender);
            case "info" -> handleInfo(sender);
            default -> {
                sendHelp(sender);
                yield true;
            }
        };
    }

    private boolean handleLink(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cEste comando solo puede ser ejecutado por un jugador.");
            return true;
        }

        LinkManager linkManager = plugin.getLinkManager();
        UUID uuid = player.getUniqueId();

        // Verificar si ya está vinculado
        if (linkManager.isLinked(uuid)) {
            linkManager.getDiscordId(uuid).ifPresent(discordId ->
                    player.sendMessage("§c§lDISCORD §8» §cYa tienes una cuenta vinculada. " +
                            "Usa §e/discord unlink §cpara desvincular primero."));
            return true;
        }

        // Generar código
        String code = linkManager.generateLinkCode(uuid, player.getName());
        int expiry = plugin.getConfig().getInt("link.code-expiry-seconds", 300);
        int minutes = expiry / 60;

        player.sendMessage("");
        player.sendMessage("§d§lDISCORD §8» §7Vinculación de cuenta");
        player.sendMessage("");
        player.sendMessage("§7Tu código de vinculación es:");
        player.sendMessage("§b§l  " + code);
        player.sendMessage("");
        player.sendMessage("§7Envía §e/link " + code + " §7en el bot de Discord.");
        player.sendMessage("§7El código expira en §e" + minutes + " minutos§7.");
        player.sendMessage("");

        return true;
    }

    private boolean handleUnlink(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cEste comando solo puede ser ejecutado por un jugador.");
            return true;
        }

        LinkManager linkManager = plugin.getLinkManager();
        UUID uuid = player.getUniqueId();

        if (!linkManager.isLinked(uuid)) {
            player.sendMessage("§d§lDISCORD §8» §cNo tienes ninguna cuenta de Discord vinculada.");
            return true;
        }

        // Capture discordId BEFORE unlink removes it from the cache
        String discordId = linkManager.getDiscordId(uuid).orElse(null);

        linkManager.unlink(uuid).thenAccept(success -> {
            if (success) {
                player.sendMessage("§d§lDISCORD §8» §aCuenta de Discord desvinculada exitosamente.");
                // Remove Discord roles asynchronously using the pre-captured discordId
                if (plugin.getBot() != null && discordId != null) {
                    plugin.getRoleSyncManager().removeAllRankRolesForDiscord(discordId);
                }
            } else {
                player.sendMessage("§d§lDISCORD §8» §cError al desvincular. Inténtalo de nuevo.");
            }
        });

        return true;
    }

    private boolean handleStatus(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cEste comando solo puede ser ejecutado por un jugador.");
            return true;
        }

        LinkManager linkManager = plugin.getLinkManager();
        UUID uuid = player.getUniqueId();

        if (linkManager.isLinked(uuid)) {
            linkManager.getDiscordId(uuid).ifPresent(discordId -> {
                player.sendMessage("§d§lDISCORD §8» §7Estado de vinculación:");
                player.sendMessage("  §7Estado: §a✔ Vinculada");
                player.sendMessage("  §7Discord ID: §b" + discordId);

                boolean botOnline = plugin.getBot() != null && plugin.getBot().isReady();
                player.sendMessage("  §7Bot: " + (botOnline ? "§a✔ En línea" : "§c✘ Desconectado"));
            });
        } else {
            player.sendMessage("§d§lDISCORD §8» §7Estado de vinculación:");
            player.sendMessage("  §7Estado: §c✘ No vinculada");
            player.sendMessage("  §7Usa §e/discord link §7para vincular.");
        }

        return true;
    }

    private boolean handleInfo(CommandSender sender) {
        boolean botOnline = plugin.getBot() != null && plugin.getBot().isReady();
        int links = plugin.getLinkManager().getLinkCount();

        sender.sendMessage("§d§lDISCORD §8» §7Información del bot:");
        sender.sendMessage("  §7Bot: " + (botOnline ? "§a✔ En línea" : "§c✘ Desconectado"));
        sender.sendMessage("  §7Cuentas vinculadas: §b" + links);
        sender.sendMessage("  §7Sincronización de roles: " +
                (plugin.getConfig().getBoolean("role-sync.enabled", true) ? "§a✔" : "§c✘"));

        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage("§d§lDISCORD §8» §7Comandos disponibles:");
        sender.sendMessage("  §e/discord link §8- §7Vincula tu cuenta de MC con Discord");
        sender.sendMessage("  §e/discord unlink §8- §7Desvincula tu cuenta");
        sender.sendMessage("  §e/discord status §8- §7Muestra el estado de tu vinculación");
        sender.sendMessage("  §e/discord info §8- §7Información del bot");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> subs = new ArrayList<>(List.of("link", "unlink", "status", "info"));
            String input = args[0].toLowerCase();
            subs.removeIf(s -> !s.startsWith(input));
            return subs;
        }
        return List.of();
    }
}
