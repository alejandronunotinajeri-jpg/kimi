package com.ethernova.discord.bot.command;

import com.ethernova.discord.EthernovaDiscord;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

/**
 * Slash command /link — Vincular cuenta de MC con Discord.
 * El jugador ejecuta /discord link en MC, recibe un código, y lo pega aquí.
 * Uso: /link <código>
 */
public class LinkSlashCommand extends ListenerAdapter {

    private final EthernovaDiscord plugin;

    public LinkSlashCommand(EthernovaDiscord plugin) {
        this.plugin = plugin;
    }

    @Override
    public void onSlashCommandInteraction(SlashCommandInteractionEvent event) {
        if (!event.getName().equals("link")) return;

        var codeOption = event.getOption("codigo");
        if (codeOption == null) {
            event.reply("❌ Debes proporcionar un código. Usa `/discord link` en Minecraft para obtenerlo.")
                    .setEphemeral(true).queue();
            return;
        }

        String code = codeOption.getAsString().toUpperCase().trim();
        String discordId = event.getUser().getId();

        // Verificar si ya está vinculado
        if (plugin.getLinkManager().isDiscordLinked(discordId)) {
            event.reply("⚠️ Ya tienes una cuenta de Minecraft vinculada. Usa `/discord unlink` en el servidor para desvincularla primero.")
                    .setEphemeral(true).queue();
            return;
        }

        event.deferReply(true).queue();

        plugin.getLinkManager().redeemCode(code, discordId).thenAccept(result -> {
            if (result.isPresent()) {
                String mcName = result.get();
                event.getHook().editOriginal("✅ ¡Cuenta vinculada exitosamente!\n" +
                        "**Minecraft:** " + mcName + "\n" +
                        "**Discord:** " + event.getUser().getEffectiveName() + "\n\n" +
                        "Tus roles se sincronizarán automáticamente con tu rango.").queue();

                // Trigger initial sync
                plugin.getLinkManager().getMcUuid(discordId).ifPresent(uuid -> {
                    var rankedPlugin = (com.ethernova.ranked.EthernovaRanked)
                            plugin.getServer().getPluginManager().getPlugin("EthernovaRanked");
                    if (rankedPlugin != null) {
                        var rank = rankedPlugin.getRankedManager().getRank(uuid);
                        var profile = rankedPlugin.getRankedManager().getProfile(uuid);
                        int elo = profile != null ? profile.getElo() : 0;
                        plugin.getRoleSyncManager().syncPlayer(uuid, mcName, rank, elo);
                    }
                });
            } else {
                event.getHook().editOriginal("❌ Código inválido o expirado. Genera uno nuevo con `/discord link` en Minecraft.").queue();
            }
        });
    }
}
