package com.ethernova.discord.bot.command;

import com.ethernova.discord.EthernovaDiscord;
import com.ethernova.ranked.model.Rank;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import org.bukkit.Bukkit;

import java.awt.*;
import java.time.Instant;

/**
 * Slash command /top — Muestra el leaderboard de ELO.
 * Uso: /top [cantidad]
 */
public class TopSlashCommand extends ListenerAdapter {

    private final EthernovaDiscord plugin;

    public TopSlashCommand(EthernovaDiscord plugin) {
        this.plugin = plugin;
    }

    @Override
    public void onSlashCommandInteraction(SlashCommandInteractionEvent event) {
        if (!event.getName().equals("top")) return;

        event.deferReply().queue();

        try {
        var rankedPlugin = (com.ethernova.ranked.EthernovaRanked)
                Bukkit.getPluginManager().getPlugin("EthernovaRanked");
        if (rankedPlugin == null) {
            event.getHook().editOriginal("❌ El sistema de ranking no está disponible.").queue();
            return;
        }

        var countOption = event.getOption("cantidad");
        int count = countOption != null ? (int) Math.min(25, Math.max(5, countOption.getAsLong())) : 10;

        rankedPlugin.getRankedManager().getLeaderboard(count).thenAccept(entries -> {
            EmbedBuilder embed = new EmbedBuilder()
                    .setTitle("🏆 Top " + count + " — " + rankedPlugin.getSeasonManager().getSeasonDisplayName())
                    .setColor(new Color(255, 215, 0))
                    .setTimestamp(Instant.now());

            if (entries.isEmpty()) {
                embed.setDescription("No hay datos de clasificación aún.");
            } else {
                StringBuilder sb = new StringBuilder();
                for (var entry : entries) {
                    String medal = switch (entry.position()) {
                        case 1 -> "🥇";
                        case 2 -> "🥈";
                        case 3 -> "🥉";
                        default -> "`#" + String.format("%-2d", entry.position()) + "`";
                    };

                    String rankName = stripColor(entry.rank().getDisplayName());
                    double wr = entry.totalGames() > 0 ? (double) entry.wins() / entry.totalGames() * 100 : 0;

                    sb.append(medal)
                      .append(" **").append(entry.name()).append("**")
                      .append(" — `").append(entry.elo()).append(" ELO`")
                      .append(" (").append(rankName).append(")")
                      .append(" | ").append(entry.wins()).append("V/").append(entry.losses()).append("D")
                      .append(" (").append(String.format("%.0f%%", wr)).append(")")
                      .append("\n");
                }
                embed.setDescription(sb.toString());
            }

            event.getHook().editOriginalEmbeds(embed.build()).queue();
        });
        } catch (Exception ex) {
            plugin.getLogger().log(java.util.logging.Level.SEVERE, "Error en /top", ex);
            event.getHook().editOriginal("❌ Error interno al procesar el comando.").queue();
        }
    }

    private String stripColor(String input) {
        return input != null ? input.replaceAll("<[^>]+>", "") : "";
    }
}
