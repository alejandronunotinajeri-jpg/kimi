package com.ethernova.discord.link;

import com.ethernova.core.storage.CoreStorageManager;
import com.ethernova.discord.EthernovaDiscord;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Gestiona la vinculación entre cuentas de Minecraft y Discord.
 * Almacena en tabla ethernova_discord_links.
 * Usa códigos temporales para el proceso de vinculación.
 */
public class LinkManager {

    private final EthernovaDiscord plugin;
    private final CoreStorageManager storage;

    /** Cache: MC UUID → Discord ID */
    private final ConcurrentHashMap<UUID, String> mcToDiscord = new ConcurrentHashMap<>();
    /** Cache: Discord ID → MC UUID */
    private final ConcurrentHashMap<String, UUID> discordToMc = new ConcurrentHashMap<>();
    /** Pending link codes: code → PendingLink */
    private final ConcurrentHashMap<String, PendingLink> pendingLinks = new ConcurrentHashMap<>();

    public record PendingLink(UUID mcUuid, String mcName, long expiresAt) {
        public boolean isExpired() { return System.currentTimeMillis() > expiresAt; }
    }

    public LinkManager(EthernovaDiscord plugin, CoreStorageManager storage) {
        this.plugin = plugin;
        this.storage = storage;
        createTable();
        loadAllLinks();
    }

    private void createTable() {
        String sql;
        if (storage.isMySQL()) {
            sql = """
                CREATE TABLE IF NOT EXISTS ethernova_discord_links (
                    mc_uuid VARCHAR(36) NOT NULL PRIMARY KEY,
                    discord_id VARCHAR(20) NOT NULL UNIQUE,
                    mc_name VARCHAR(16) NOT NULL,
                    linked_at BIGINT NOT NULL
                )
            """;
        } else {
            sql = """
                CREATE TABLE IF NOT EXISTS ethernova_discord_links (
                    mc_uuid TEXT NOT NULL PRIMARY KEY,
                    discord_id TEXT NOT NULL UNIQUE,
                    mc_name TEXT NOT NULL,
                    linked_at INTEGER NOT NULL
                )
            """;
        }

        try (Connection conn = storage.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().log(Level.SEVERE, "Error creando tabla discord_links", e);
        }
    }

    private void loadAllLinks() {
        try (Connection conn = storage.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT mc_uuid, discord_id FROM ethernova_discord_links")) {
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    UUID mcUuid = UUID.fromString(rs.getString("mc_uuid"));
                    String discordId = rs.getString("discord_id");
                    mcToDiscord.put(mcUuid, discordId);
                    discordToMc.put(discordId, mcUuid);
                }
            }
            plugin.getLogger().info("✔ Cargadas " + mcToDiscord.size() + " vinculaciones MC↔Discord");
        } catch (SQLException e) {
            plugin.getLogger().log(Level.SEVERE, "Error cargando vinculaciones", e);
        }
    }

    // ═══════════════ Códigos de vinculación ═══════════════

    /**
     * Genera un código de vinculación para un jugador de MC.
     * El jugador luego envía este código en Discord para completar la vinculación.
     *
     * @return El código de 6 caracteres generado
     */
    public String generateLinkCode(UUID mcUuid, String mcName) {
        // Limpiar códigos expirados
        pendingLinks.entrySet().removeIf(e -> e.getValue().isExpired());

        // Remover código previo del mismo jugador
        pendingLinks.entrySet().removeIf(e -> e.getValue().mcUuid().equals(mcUuid));

        // Generar nuevo código
        String code = generateCode();
        int expiry = plugin.getConfig().getInt("link.code-expiry-seconds", 300);
        pendingLinks.put(code, new PendingLink(mcUuid, mcName, System.currentTimeMillis() + expiry * 1000L));
        return code;
    }

    /**
     * Intenta completar una vinculación usando un código.
     *
     * @param code      El código de vinculación
     * @param discordId El ID del usuario de Discord
     * @return Optional con el nombre del jugador MC si fue exitoso
     */
    public CompletableFuture<Optional<String>> redeemCode(String code, String discordId) {
        PendingLink pending = pendingLinks.remove(code.toUpperCase());
        if (pending == null || pending.isExpired()) {
            return CompletableFuture.completedFuture(Optional.empty());
        }

        // Verificar que el Discord no esté ya vinculado a otro MC
        if (discordToMc.containsKey(discordId)) {
            return CompletableFuture.completedFuture(Optional.empty());
        }

        // Verificar que el MC no esté ya vinculado a otro Discord
        if (mcToDiscord.containsKey(pending.mcUuid())) {
            // Desvincular el anterior primero
            String oldDiscord = mcToDiscord.get(pending.mcUuid());
            discordToMc.remove(oldDiscord);
        }

        return CompletableFuture.supplyAsync(() -> {
            try (Connection conn = storage.getConnection()) {
                String sql;
                if (storage.isMySQL()) {
                    sql = "INSERT INTO ethernova_discord_links (mc_uuid, discord_id, mc_name, linked_at) " +
                          "VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE discord_id = VALUES(discord_id), " +
                          "mc_name = VALUES(mc_name), linked_at = VALUES(linked_at)";
                } else {
                    sql = "INSERT INTO ethernova_discord_links (mc_uuid, discord_id, mc_name, linked_at) " +
                          "VALUES (?, ?, ?, ?) ON CONFLICT(mc_uuid) DO UPDATE SET discord_id = excluded.discord_id, " +
                          "mc_name = excluded.mc_name, linked_at = excluded.linked_at";
                }

                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, pending.mcUuid().toString());
                    ps.setString(2, discordId);
                    ps.setString(3, pending.mcName());
                    ps.setLong(4, System.currentTimeMillis());
                    ps.executeUpdate();
                }

                mcToDiscord.put(pending.mcUuid(), discordId);
                discordToMc.put(discordId, pending.mcUuid());
                return Optional.of(pending.mcName());

            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Error guardando vinculación", e);
                return Optional.empty();
            }
        });
    }

    /**
     * Desvincula una cuenta MC de Discord.
     */
    public CompletableFuture<Boolean> unlink(UUID mcUuid) {
        String discordId = mcToDiscord.remove(mcUuid);
        if (discordId != null) {
            discordToMc.remove(discordId);
        }

        return CompletableFuture.supplyAsync(() -> {
            try (Connection conn = storage.getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "DELETE FROM ethernova_discord_links WHERE mc_uuid = ?")) {
                ps.setString(1, mcUuid.toString());
                return ps.executeUpdate() > 0;
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Error desvinculando", e);
                return false;
            }
        });
    }

    // ═══════════════ Queries ═══════════════

    public Optional<String> getDiscordId(UUID mcUuid) {
        return Optional.ofNullable(mcToDiscord.get(mcUuid));
    }

    public Optional<UUID> getMcUuid(String discordId) {
        return Optional.ofNullable(discordToMc.get(discordId));
    }

    public boolean isLinked(UUID mcUuid) {
        return mcToDiscord.containsKey(mcUuid);
    }

    public boolean isDiscordLinked(String discordId) {
        return discordToMc.containsKey(discordId);
    }

    public Map<UUID, String> getAllLinks() {
        return Map.copyOf(mcToDiscord);
    }

    public int getLinkCount() {
        return mcToDiscord.size();
    }

    // ═══════════════ Utilidades ═══════════════

    private String generateCode() {
        String chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // Sin I, O, 0, 1 para evitar confusión
        StringBuilder sb = new StringBuilder(6);
        java.util.concurrent.ThreadLocalRandom rng = java.util.concurrent.ThreadLocalRandom.current();
        for (int i = 0; i < 6; i++) {
            sb.append(chars.charAt(rng.nextInt(chars.length())));
        }
        return sb.toString();
    }
}
