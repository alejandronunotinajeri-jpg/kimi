package com.ethernova.discord.bot.command;

import com.ethernova.discord.EthernovaDiscord;
import com.ethernova.ranked.EthernovaRanked;
import com.ethernova.ranked.model.RankedProfile;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

import java.awt.*;
import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

/**
 * Slash command /stats — Estadísticas detalladas con Glicko-2.
 * Muestra: Rating, RD, Volatilidad, Intervalo de confianza, racha, winrate, KDR, etc.
 * Uso: /stats [jugador]
 */
public class StatsSlashCommand extends ListenerAdapter {

    private final EthernovaDiscord plugin;

    public StatsSlashCommand(EthernovaDiscord plugin) {
        this.plugin = plugin;
    }

    @Override
    public void onSlashCommandInteraction(SlashCommandInteractionEvent event) {
        if (!event.getName().equals("stats")) return;

        event.deferReply().queue();

        try {
        var rankedPlugin = (EthernovaRanked)
                plugin.getServer().getPluginManager().getPlugin("EthernovaRanked");
        if (rankedPlugin == null) {
            event.getHook().editOriginal("❌ El sistema de ranked no está disponible.").queue();
            return;
        }

        var manager = rankedPlugin.getRankedManager();
        UUID targetUuid = null;
        String targetName = null;

        // Si se proporciona un jugador, buscar por nombre MC
        var userOption = event.getOption("usuario");
        var playerOption = event.getOption("jugador");

        if (userOption != null) {
            // Buscar por usuario de Discord vinculado
            String discordId = userOption.getAsUser().getId();
            Optional<UUID> linked = plugin.getLinkManager().getMcUuid(discordId);
            if (linked.isPresent()) {
                targetUuid = linked.get();
                var player = plugin.getServer().getOfflinePlayer(targetUuid);
                targetName = player.getName() != null ? player.getName() : userOption.getAsUser().getEffectiveName();
            }
        } else if (playerOption != null) {
            targetName = playerOption.getAsString();
            var player = plugin.getServer().getOfflinePlayer(targetName);
            if (player.hasPlayedBefore() || player.isOnline()) {
                targetUuid = player.getUniqueId();
                targetName = player.getName();
            }
        } else {
            // Si no, intentar por vincular Discord
            String discordId = event.getUser().getId();
            Optional<UUID> linked = plugin.getLinkManager().getMcUuid(discordId);
            if (linked.isPresent()) {
                targetUuid = linked.get();
                var player = plugin.getServer().getOfflinePlayer(targetUuid);
                targetName = player.getName() != null ? player.getName() : targetUuid.toString().substring(0, 8);
            }
        }

        if (targetUuid == null) {
            event.getHook().editOriginal("❌ No se encontró el jugador. Vincula tu cuenta con `/link <codigo>` o especifica un nombre.").queue();
            return;
        }

        RankedProfile profile = manager.getProfile(targetUuid);
        if (profile == null) {
            event.getHook().editOriginal("❌ **" + targetName + "** no tiene perfil de ranked.").queue();
            return;
        }

        var rank = profile.getCurrentRank();
        int elo = profile.getElo();
        double rd = profile.getRd();
        double volatility = profile.getVolatility();
        int wins = profile.getWins();
        int losses = profile.getLosses();
        int total = wins + losses;
        double winrate = total > 0 ? (wins * 100.0 / total) : 0;
        int streak = profile.getWinStreak();
        int bestStreak = profile.getBestWinStreak();

        // Intervalo de confianza 95%
        double lowerBound = Math.max(0, elo - (1.96 * rd));
        double upperBound = elo + (1.96 * rd);

        // Confianza como porcentaje (menor RD = mayor confianza)
        double confidence = Math.max(0, Math.min(100, 100 - ((rd - 30) / (350 - 30) * 100)));

        // Color según rango
        Color color = getRankColor(rank.getId());

        // Emoji de racha
        String streakEmoji = streak > 0 ? "🔥" : (streak < 0 ? "❄️" : "➖");
        String streakText = streak > 0 ? "+" + streak + " victorias" :
                            streak < 0 ? Math.abs(streak) + " derrotas" : "Sin racha";

        // Volatilidad descriptiva
        String volDesc = volatility < 0.04 ? "🟢 Muy estable" :
                         volatility < 0.06 ? "🟡 Estable" :
                         volatility < 0.08 ? "🟠 Variable" : "🔴 Muy variable";

        // RD descriptivo
        String rdDesc = rd < 50 ? "🟢 Muy preciso" :
                        rd < 100 ? "🟡 Preciso" :
                        rd < 200 ? "🟠 Moderado" : "🔴 Incierto";

        EmbedBuilder embed = new EmbedBuilder()
                .setTitle("📊 Estadísticas — " + targetName)
                .setColor(color)
                .setThumbnail("https://mc-heads.net/avatar/" + targetUuid + "/128")
                .setTimestamp(Instant.now());

        // Rango y ELO principal
        embed.addField("🏅 Rango", rank.getDisplayName(), true);
        embed.addField("⭐ ELO", String.valueOf(elo), true);
        embed.addField("📈 Temporada", profile.getSeason(), true);

        // Glicko-2 técnico
        embed.addField("📐 Rating Deviation (RD)",
                String.format("%.1f — %s", rd, rdDesc), false);
        embed.addField("🌀 Volatilidad",
                String.format("%.6f — %s", volatility, volDesc), false);
        embed.addField("📏 Intervalo de Confianza (95%)",
                String.format("**%.0f** — **%.0f** (%.1f%% confianza)", lowerBound, upperBound, confidence), false);

        // Estadísticas de partidas
        embed.addField("⚔️ Partidas", String.valueOf(total), true);
        embed.addField("✅ Victorias", String.valueOf(wins), true);
        embed.addField("❌ Derrotas", String.valueOf(losses), true);

        embed.addField("📊 Winrate",
                String.format("%.1f%%", winrate), true);
        embed.addField(streakEmoji + " Racha Actual", streakText, true);
        embed.addField("🏆 Mejor Racha", bestStreak + " victorias", true);

        // Barra de progreso al siguiente rango
        var nextRank = rank.next();
        if (nextRank != null) {
            int minElo = rank.getMinElo();
            int maxElo = nextRank.getMinElo();
            int progress = Math.max(0, Math.min(100,
                    (int) ((double)(elo - minElo) / (maxElo - minElo) * 100)));
            String progressBar = buildProgressBar(progress);
            embed.addField("📶 Progreso → " + nextRank.getDisplayName(),
                    progressBar + " " + progress + "%\n" +
                    "Faltan **" + (maxElo - elo) + "** puntos", false);
        } else {
            embed.addField("👑 Rango Máximo",
                    "Has alcanzado el rango más alto. ¡Sigue compitiendo!", false);
        }

        embed.setFooter("Glicko-2 Rating System • EtherNova Clans");

        event.getHook().editOriginalEmbeds(embed.build()).queue();
        } catch (Exception ex) {
            plugin.getLogger().log(java.util.logging.Level.SEVERE, "Error en /stats", ex);
            event.getHook().editOriginal("❌ Error interno al procesar el comando.").queue();
        }
    }

    private String buildProgressBar(int percent) {
        int filled = percent / 10;
        int empty = 10 - filled;
        StringBuilder bar = new StringBuilder();
        for (int i = 0; i < filled; i++) bar.append("▰");
        for (int i = 0; i < empty; i++) bar.append("▱");
        return bar.toString();
    }

    private Color getRankColor(String rankId) {
        return switch (rankId.toLowerCase()) {
            case "iron", "hierro" -> new Color(169, 169, 169);
            case "bronze", "bronce" -> new Color(205, 127, 50);
            case "silver", "plata" -> new Color(192, 192, 192);
            case "gold", "oro" -> new Color(255, 215, 0);
            case "platinum", "platino" -> new Color(0, 200, 200);
            case "diamond", "diamante" -> new Color(0, 191, 255);
            case "master", "maestro" -> new Color(148, 0, 211);
            case "grandmaster", "gran_maestro" -> new Color(255, 50, 50);
            case "challenger", "aspirante" -> new Color(255, 223, 0);
            default -> new Color(128, 128, 128);
        };
    }
}
