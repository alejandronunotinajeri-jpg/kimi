package com.ethernova.discord.bot.command;

import com.ethernova.core.service.ServiceRegistry;
import com.ethernova.discord.EthernovaDiscord;
import com.ethernova.ranked.api.RankedAPI;
import com.ethernova.ranked.model.Rank;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

import java.awt.*;
import java.util.UUID;

/**
 * Slash command /elo — Muestra el ELO de un jugador vinculado.
 * Uso: /elo [usuario] [jugador]
 */
public class EloSlashCommand extends ListenerAdapter {

    private final EthernovaDiscord plugin;

    public EloSlashCommand(EthernovaDiscord plugin) {
        this.plugin = plugin;
    }

    @Override
    public void onSlashCommandInteraction(SlashCommandInteractionEvent event) {
        if (!event.getName().equals("elo")) return;

        event.deferReply().queue();

        try {
        RankedAPI api = ServiceRegistry.get(RankedAPI.class);
        if (api == null) {
            event.getHook().editOriginal("❌ El sistema de ranking no está disponible.").queue();
            return;
        }

        // Determinar qué jugador consultar
        var userOption = event.getOption("usuario");
        var playerOption = event.getOption("jugador");

        if (userOption != null) {
            // Buscar por usuario de Discord
            String discordId = userOption.getAsUser().getId();
            var mcUuid = plugin.getLinkManager().getMcUuid(discordId);
            if (mcUuid.isEmpty()) {
                event.getHook().editOriginal("❌ Ese usuario no tiene su cuenta vinculada.").queue();
                return;
            }
            sendEloEmbed(event, mcUuid.get(), api, userOption.getAsUser().getEffectiveName());

        } else if (playerOption != null) {
            // Buscar por nombre de MC (necesitamos buscar en la DB)
            event.getHook().editOriginal("❌ Busca por usuario de Discord con la opción `usuario`.").queue();

        } else {
            // Consultar al propio usuario que ejecutó el comando
            String discordId = event.getUser().getId();
            var mcUuid = plugin.getLinkManager().getMcUuid(discordId);
            if (mcUuid.isEmpty()) {
                event.getHook().editOriginal("❌ No tienes tu cuenta vinculada. Usa `/link` para vincularla.").queue();
                return;
            }
            sendEloEmbed(event, mcUuid.get(), api, event.getUser().getEffectiveName());
        }
        } catch (Exception ex) {
            plugin.getLogger().log(java.util.logging.Level.SEVERE, "Error en /elo", ex);
            event.getHook().editOriginal("❌ Error interno al procesar el comando.").queue();
        }
    }

    private void sendEloEmbed(SlashCommandInteractionEvent event, UUID mcUuid, RankedAPI api, String discordName) {
        int elo = api.getElo(mcUuid);
        Rank rank = api.getRank(mcUuid);
        int wins = api.getWins(mcUuid);
        int losses = api.getLosses(mcUuid);
        int winStreak = api.getWinStreak(mcUuid);
        String confidence = api.getConfidenceInterval(mcUuid);

        String rankName = stripColor(rank.getDisplayName());
        double winRate = (wins + losses) > 0 ? (double) wins / (wins + losses) * 100 : 0;

        EmbedBuilder embed = new EmbedBuilder()
                .setTitle("⚔️ " + discordName)
                .setColor(getRankColor(rank))
                .addField("Rango", rankName, true)
                .addField("ELO", String.valueOf(elo), true)
                .addField("Confianza", confidence, true)
                .addField("V/D", wins + "/" + losses + " (" + String.format("%.1f%%", winRate) + ")", true)
                .addField("Racha", "\uD83D\uDD25 " + winStreak, true);

        event.getHook().editOriginalEmbeds(embed.build()).queue();
    }

    private Color getRankColor(Rank rank) {
        return switch (rank.getId()) {
            case "bronze" -> new Color(205, 127, 50);
            case "silver" -> new Color(192, 192, 192);
            case "gold" -> new Color(255, 215, 0);
            case "platinum" -> new Color(0, 200, 200);
            case "diamond" -> new Color(0, 100, 255);
            case "master" -> new Color(170, 0, 255);
            case "grandmaster" -> new Color(255, 50, 50);
            case "challenger" -> new Color(255, 165, 0);
            default -> new Color(128, 128, 128);
        };
    }

    private String stripColor(String input) {
        return input != null ? input.replaceAll("<[^>]+>", "") : "";
    }
}
