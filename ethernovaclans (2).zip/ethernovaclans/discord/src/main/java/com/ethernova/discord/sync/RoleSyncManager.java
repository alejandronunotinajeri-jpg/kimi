package com.ethernova.discord.sync;

import com.ethernova.core.service.ServiceRegistry;
import com.ethernova.discord.EthernovaDiscord;
import com.ethernova.discord.bot.DiscordBot;
import com.ethernova.ranked.api.RankedAPI;
import com.ethernova.ranked.model.Rank;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Role;

import java.util.*;
import java.util.logging.Level;

/**
 * Sincroniza roles de Discord con los rangos de ELO del servidor de Minecraft.
 * Asigna/remueve roles automáticamente cuando un jugador sube o baja de rango.
 * También actualiza nicknames opcionalmente.
 */
public class RoleSyncManager {

    private final EthernovaDiscord plugin;

    public RoleSyncManager(EthernovaDiscord plugin) {
        this.plugin = plugin;
    }

    /**
     * Sincroniza los roles de un jugador específico por su UUID de MC.
     * Busca su vinculación Discord, calcula su rango, y actualiza roles + nickname.
     *
     * @param mcUuid     UUID del jugador MC
     * @param mcName     Nombre del jugador MC
     * @param newRank    Nuevo rango del jugador
     * @param elo        ELO actual
     */
    public void syncPlayer(UUID mcUuid, String mcName, Rank newRank, int elo) {
        if (!plugin.getConfig().getBoolean("role-sync.enabled", true)) return;

        DiscordBot bot = plugin.getBot();
        if (bot == null || !bot.isReady()) return;

        plugin.getLinkManager().getDiscordId(mcUuid).ifPresent(discordId -> {
            Guild guild = bot.getGuild();
            if (guild == null) return;

            guild.retrieveMemberById(discordId).queue(member -> {
                if (member == null) return;

                // Sincronizar roles
                syncRoles(guild, member, newRank);

                // Actualizar nickname
                String nickFormat = plugin.getConfig().getString("role-sync.nickname-format", "");
                if (!nickFormat.isEmpty()) {
                    updateNickname(guild, member, mcName, newRank, elo, nickFormat);
                }

            }, err -> plugin.getLogger().log(Level.FINE, "No se encontró member Discord: " + discordId, err));
        });
    }

    /**
     * Sincronización masiva: actualiza todos los jugadores vinculados.
     */
    public void bulkSync() {
        if (!plugin.getConfig().getBoolean("role-sync.enabled", true)) return;

        DiscordBot bot = plugin.getBot();
        if (bot == null || !bot.isReady()) return;

        RankedAPI api = ServiceRegistry.get(RankedAPI.class);
        if (api == null) return;

        Guild guild = bot.getGuild();
        if (guild == null) return;

        var links = plugin.getLinkManager().getAllLinks();
        int synced = 0;
        int failed = 0;

        for (var entry : links.entrySet()) {
            UUID mcUuid = entry.getKey();
            String discordId = entry.getValue();

            // Only sync players whose profiles are currently loaded (online)
            // Offline players' profiles are unloaded — api.getRank() would return lowest rank
            Rank rank = api.getRank(mcUuid);
            int elo = api.getElo(mcUuid);
            if (elo == 0 && org.bukkit.Bukkit.getPlayer(mcUuid) == null) continue; // Skip offline players

            try {
                guild.retrieveMemberById(discordId).queue(member -> {
                    if (member != null) {
                        syncRoles(guild, member, rank);

                        String nickFormat = plugin.getConfig().getString("role-sync.nickname-format", "");
                        if (!nickFormat.isEmpty()) {
                            // Need MC name — we'll get it from the profile data
                            String mcName = getMcNameFromDiscord(member);
                            if (mcName != null) {
                                updateNickname(guild, member, mcName, rank, elo, nickFormat);
                            }
                        }
                    }
                }, err -> {
                    plugin.getLogger().log(java.util.logging.Level.WARNING,
                            "Failed to retrieve Discord member " + discordId + " during bulk sync", err);
                });
                synced++;
            } catch (Exception e) {
                plugin.getLogger().log(java.util.logging.Level.WARNING,
                        "Error syncing Discord roles for " + discordId, e);
                failed++;
            }
        }

        plugin.getLogger().info("Bulk sync completado: " + synced + "/" + links.size()
                + " jugadores procesados" + (failed > 0 ? " (" + failed + " errores)" : ""));
    }

    // ═══════════════ Roles ═══════════════

    /**
     * Sincroniza los roles de un member: asigna el rol del rango actual,
     * remueve todos los demás roles de rango.
     */
    private void syncRoles(Guild guild, Member member, Rank rank) {
        var roleConfig = plugin.getConfig().getConfigurationSection("role-sync.roles");
        if (roleConfig == null) return;

        String targetRoleId = roleConfig.getString(rank.getId(), "");
        Set<String> allRankRoleIds = new HashSet<>();
        for (String key : roleConfig.getKeys(false)) {
            String roleId = roleConfig.getString(key, "");
            if (!roleId.isEmpty() && !"000000000000000000".equals(roleId)) {
                allRankRoleIds.add(roleId);
            }
        }

        // Recopilar roles a añadir y remover
        List<Role> toAdd = new ArrayList<>();
        List<Role> toRemove = new ArrayList<>();

        for (String roleId : allRankRoleIds) {
            Role role = guild.getRoleById(roleId);
            if (role == null) continue;

            if (roleId.equals(targetRoleId)) {
                if (!member.getRoles().contains(role)) {
                    toAdd.add(role);
                }
            } else {
                if (member.getRoles().contains(role)) {
                    toRemove.add(role);
                }
            }
        }

        // Aplicar cambios
        if (!toAdd.isEmpty() || !toRemove.isEmpty()) {
            guild.modifyMemberRoles(member, toAdd, toRemove).queue(
                    success -> {},
                    err -> plugin.getLogger().log(Level.WARNING,
                            "Error sincronizando roles para " + member.getEffectiveName(), err)
            );
        }
    }

    // ═══════════════ Nicknames ═══════════════

    /**
     * Actualiza el nickname del member en Discord según el formato configurado.
     */
    private void updateNickname(Guild guild, Member member, String mcName, Rank rank, int elo, String format) {
        // No modificar al dueño del server
        if (member.isOwner()) return;

        String rankName = stripColor(rank.getDisplayName());
        String nickname = format
                .replace("{rank}", rankName)
                .replace("{name}", mcName)
                .replace("{elo}", String.valueOf(elo));

        // Discord limita nicknames a 32 chars
        if (nickname.length() > 32) {
            nickname = nickname.substring(0, 32);
        }

        if (!nickname.equals(member.getNickname())) {
            String finalNick = nickname;
            guild.modifyNickname(member, finalNick).queue(
                    success -> {},
                    err -> plugin.getLogger().log(Level.FINE,
                            "No se pudo cambiar nickname de " + member.getEffectiveName(), err)
            );
        }
    }

    /**
     * Remueve todos los roles de rango de un jugador (usado al desvincular).
     */
    public void removeAllRankRoles(UUID mcUuid) {
        DiscordBot bot = plugin.getBot();
        if (bot == null || !bot.isReady()) return;

        plugin.getLinkManager().getDiscordId(mcUuid).ifPresent(discordId -> {
            Guild guild = bot.getGuild();
            if (guild == null) return;

            guild.retrieveMemberById(discordId).queue(member -> {
                if (member == null) return;

                var roleConfig = plugin.getConfig().getConfigurationSection("role-sync.roles");
                if (roleConfig == null) return;

                List<Role> toRemove = new ArrayList<>();
                for (String key : roleConfig.getKeys(false)) {
                    String roleId = roleConfig.getString(key, "");
                    if (!roleId.isEmpty() && !"000000000000000000".equals(roleId)) {
                        Role role = guild.getRoleById(roleId);
                        if (role != null && member.getRoles().contains(role)) {
                            toRemove.add(role);
                        }
                    }
                }

                if (!toRemove.isEmpty()) {
                    guild.modifyMemberRoles(member, Collections.emptyList(), toRemove).queue();
                }

                // Reset nickname
                if (member.getNickname() != null && !member.isOwner()) {
                    guild.modifyNickname(member, null).queue(s -> {}, e -> {});
                }
            }, err -> {});
        });
    }

    /**
     * Removes all rank roles for a discordId directly (used when unlinking, since cache is already cleared).
     */
    public void removeAllRankRolesForDiscord(String discordId) {
        DiscordBot bot = plugin.getBot();
        if (bot == null || !bot.isReady()) return;

        Guild guild = bot.getGuild();
        if (guild == null) return;

        guild.retrieveMemberById(discordId).queue(member -> {
            if (member == null) return;

            var roleConfig = plugin.getConfig().getConfigurationSection("role-sync.roles");
            if (roleConfig == null) return;

            List<Role> toRemove = new ArrayList<>();
            for (String key : roleConfig.getKeys(false)) {
                String roleId = roleConfig.getString(key, "");
                if (!roleId.isEmpty() && !"000000000000000000".equals(roleId)) {
                    Role role = guild.getRoleById(roleId);
                    if (role != null && member.getRoles().contains(role)) {
                        toRemove.add(role);
                    }
                }
            }

            if (!toRemove.isEmpty()) {
                guild.modifyMemberRoles(member, Collections.emptyList(), toRemove).queue();
            }

            // Reset nickname
            if (member.getNickname() != null && !member.isOwner()) {
                guild.modifyNickname(member, null).queue(s -> {}, e -> {});
            }
        }, err -> {});
    }

    private String stripColor(String input) {
        return input != null ? input.replaceAll("<[^>]+>", "") : "";
    }

    /**
     * Intenta obtener el nombre MC de un member. Extrae del nickname si tiene formato.
     */
    private String getMcNameFromDiscord(Member member) {
        String nick = member.getNickname();
        if (nick != null && nick.contains("|")) {
            String[] parts = nick.split("\\|");
            if (parts.length >= 2) {
                return parts[1].trim();
            }
        }
        return member.getEffectiveName();
    }
}
