package com.ethernova.discord.bot;

import com.ethernova.core.service.ServiceRegistry;
import com.ethernova.discord.EthernovaDiscord;
import com.ethernova.discord.bot.command.EloSlashCommand;
import com.ethernova.discord.bot.command.LinkSlashCommand;
import com.ethernova.discord.bot.command.StatsSlashCommand;
import com.ethernova.discord.bot.command.TopSlashCommand;
import com.ethernova.ranked.api.RankedAPI;
import com.ethernova.ranked.model.Rank;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.OnlineStatus;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.requests.GatewayIntent;
import net.dv8tion.jda.api.utils.MemberCachePolicy;

import java.awt.*;
import java.time.Instant;
import java.util.*;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;

/**
 * Gestiona la conexión JDA al bot de Discord.
 * Inicializa el bot, registra slash commands, y expone métodos para
 * enviar mensajes y actualizar roles/nicknames.
 */
public class DiscordBot {

    private final EthernovaDiscord plugin;
    private JDA jda;
    private volatile boolean ready = false;

    public DiscordBot(EthernovaDiscord plugin) {
        this.plugin = plugin;
    }

    /**
     * Inicia el bot de Discord con JDA.
     */
    public void start() {
        CompletableFuture.runAsync(() -> {
            try {
                String token = plugin.getConfig().getString("bot.token", "");

                jda = JDABuilder.createDefault(token)
                        .setStatus(OnlineStatus.ONLINE)
                        .enableIntents(
                                GatewayIntent.GUILD_MEMBERS,
                                GatewayIntent.GUILD_MESSAGES,
                                GatewayIntent.MESSAGE_CONTENT
                        )
                        .setMemberCachePolicy(MemberCachePolicy.ALL)
                        .build();

                jda.awaitReady();
                ready = true;

                // Configurar actividad
                String activityType = plugin.getConfig().getString("bot.activity-type", "WATCHING");
                String activityText = plugin.getConfig().getString("bot.activity-text", "ELO Rankings");
                setActivity(activityType, activityText);

                // Registrar slash commands
                registerSlashCommands();

                // Registrar event listeners
                jda.addEventListener(new LinkSlashCommand(plugin));
                jda.addEventListener(new EloSlashCommand(plugin));
                jda.addEventListener(new TopSlashCommand(plugin));
                jda.addEventListener(new StatsSlashCommand(plugin));

                plugin.getLogger().info("✔ Bot de Discord conectado como: " + jda.getSelfUser().getName());
                plugin.getLogger().info("  Guild configurada: " + getGuildName());

            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Error iniciando el bot de Discord", e);
                plugin.getLogger().severe("Verifica que el token sea correcto en config.yml");
            }
        }).exceptionally(ex -> {
            plugin.getLogger().log(Level.SEVERE, "Unhandled error starting Discord bot", ex);
            return null;
        });
    }

    /**
     * Registra los slash commands en Discord.
     */
    private void registerSlashCommands() {
        Guild guild = getGuild();
        if (guild == null) {
            plugin.getLogger().warning("Guild no encontrada! Verifica guild-id en config.yml");
            return;
        }

        guild.updateCommands().addCommands(
                net.dv8tion.jda.api.interactions.commands.build.Commands.slash("elo", "Ver el ELO de un jugador")
                        .addOption(net.dv8tion.jda.api.interactions.commands.OptionType.USER, "usuario", "Usuario de Discord (opcional)", false)
                        .addOption(net.dv8tion.jda.api.interactions.commands.OptionType.STRING, "jugador", "Nombre de MC (opcional)", false),
                net.dv8tion.jda.api.interactions.commands.build.Commands.slash("top", "Ver el leaderboard de ELO")
                        .addOption(net.dv8tion.jda.api.interactions.commands.OptionType.INTEGER, "cantidad", "Cantidad de jugadores a mostrar", false),
                net.dv8tion.jda.api.interactions.commands.build.Commands.slash("link", "Vincular tu cuenta de Minecraft")
                        .addOption(net.dv8tion.jda.api.interactions.commands.OptionType.STRING, "codigo", "Código de vinculación (obtenido con /discord link en MC)", true),
                net.dv8tion.jda.api.interactions.commands.build.Commands.slash("stats", "Ver estadísticas detalladas de un jugador")
                        .addOption(net.dv8tion.jda.api.interactions.commands.OptionType.USER, "usuario", "Usuario de Discord", false)
                        .addOption(net.dv8tion.jda.api.interactions.commands.OptionType.STRING, "jugador", "Nombre de MC", false)
        ).queue(
                cmds -> plugin.getLogger().info("✔ " + cmds.size() + " slash commands registrados en Discord"),
                err -> plugin.getLogger().log(Level.SEVERE, "Error registrando slash commands", err)
        );
    }

    /**
     * Apaga el bot.
     */
    public void shutdown() {
        ready = false; // Prevent async tasks from submitting new work
        if (jda != null) {
            jda.shutdown();
            try {
                if (!jda.awaitShutdown(java.time.Duration.ofSeconds(5))) {
                    jda.shutdownNow();
                }
            } catch (InterruptedException e) {
                jda.shutdownNow();
                Thread.currentThread().interrupt();
            }
            plugin.getLogger().info("Bot de Discord desconectado.");
        }
    }

    // ═══════════════ Utilidades ═══════════════

    public JDA getJda() { return jda; }
    public boolean isReady() { return ready && jda != null; }

    public Guild getGuild() {
        if (jda == null) return null;
        String guildId = plugin.getConfig().getString("bot.guild-id", "");
        return jda.getGuildById(guildId);
    }

    private String getGuildName() {
        Guild guild = getGuild();
        return guild != null ? guild.getName() : "No encontrada";
    }

    private void setActivity(String type, String text) {
        Activity activity = switch (type.toUpperCase()) {
            case "PLAYING" -> Activity.playing(text);
            case "LISTENING" -> Activity.listening(text);
            case "COMPETING" -> Activity.competing(text);
            default -> Activity.watching(text);
        };
        jda.getPresence().setActivity(activity);
    }

    // ═══════════════ Embeds ═══════════════

    /**
     * Actualiza el embed de leaderboard en el canal configurado.
     */
    public void updateLeaderboardEmbed() {
        if (!isReady()) return;

        String channelId = plugin.getConfig().getString("channels.leaderboard-channel-id", "");
        if (channelId.isEmpty() || "000000000000000000".equals(channelId)) return;

        Guild guild = getGuild();
        if (guild == null) return;

        TextChannel channel = guild.getTextChannelById(channelId);
        if (channel == null) return;

        RankedAPI api = ServiceRegistry.get(RankedAPI.class);
        if (api == null) return;

        int topCount = plugin.getConfig().getInt("channels.leaderboard-top-count", 20);

        // Build the embed from leaderboard data
        // We'll use the RankedManager directly through the ranked plugin
        try {
            var rankedPlugin = (com.ethernova.ranked.EthernovaRanked)
                    plugin.getServer().getPluginManager().getPlugin("EthernovaRanked");
            if (rankedPlugin == null) return;

            rankedPlugin.getRankedManager().getLeaderboard(topCount).thenAccept(entries -> {
                EmbedBuilder embed = new EmbedBuilder()
                        .setTitle("🏆 Leaderboard — " + rankedPlugin.getSeasonManager().getSeasonDisplayName())
                        .setColor(new Color(255, 215, 0))
                        .setTimestamp(Instant.now())
                        .setFooter("Actualizado automáticamente");

                StringBuilder sb = new StringBuilder();
                for (var entry : entries) {
                    String medal = switch (entry.position()) {
                        case 1 -> "🥇";
                        case 2 -> "🥈";
                        case 3 -> "🥉";
                        default -> "**#" + entry.position() + "**";
                    };
                    sb.append(medal)
                      .append(" **").append(entry.name()).append("** — ")
                      .append(entry.elo()).append(" ELO (")
                      .append(stripColor(entry.rank().getDisplayName())).append(")\n");
                }

                if (sb.isEmpty()) sb.append("No hay datos de clasificación aún.");
                embed.setDescription(sb.toString());

                // Try to edit last message, else send new
                channel.getHistory().retrievePast(1).queue(messages -> {
                    if (!messages.isEmpty() && messages.get(0).getAuthor().equals(jda.getSelfUser())) {
                        messages.get(0).editMessageEmbeds(embed.build()).queue();
                    } else {
                        channel.sendMessageEmbeds(embed.build()).queue();
                    }
                });
            });
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error actualizando embed de leaderboard", e);
        }
    }

    /**
     * Envía un anuncio de cambio de rango al canal configurado.
     */
    public void sendRankChangeAnnouncement(String playerName, String oldRank, String newRank, int elo, boolean isPromotion) {
        if (!isReady()) return;

        String channelId = plugin.getConfig().getString("channels.rank-up-channel-id", "");
        if (channelId.isEmpty() || "000000000000000000".equals(channelId)) return;

        Guild guild = getGuild();
        if (guild == null) return;

        TextChannel channel = guild.getTextChannelById(channelId);
        if (channel == null) return;

        String emoji = isPromotion ? "⬆️" : "⬇️";
        Color color = isPromotion ? new Color(0, 200, 83) : new Color(244, 67, 54);
        String title = isPromotion ? "¡Promoción!" : "Descenso";

        EmbedBuilder embed = new EmbedBuilder()
                .setTitle(emoji + " " + title)
                .setDescription("**" + playerName + "** " +
                        (isPromotion ? "ha subido" : "ha bajado") +
                        " de rango!")
                .addField("Anterior", stripColor(oldRank), true)
                .addField("Nuevo", stripColor(newRank), true)
                .addField("ELO", String.valueOf(elo), true)
                .setColor(color)
                .setTimestamp(Instant.now());

        channel.sendMessageEmbeds(embed.build()).queue();
    }

    /** Limpia tags MiniMessage de un string. */
    private String stripColor(String input) {
        if (input == null) return "";
        return input.replaceAll("<[^>]+>", "");
    }
}
