package com.ethernova.discord;

import com.ethernova.core.EthernovaCore;
import com.ethernova.discord.bot.DiscordBot;
import com.ethernova.discord.command.DiscordCommand;
import com.ethernova.discord.link.LinkManager;
import com.ethernova.discord.listener.RankChangeListener;
import com.ethernova.discord.sync.RoleSyncManager;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.logging.Level;

/**
 * EthernovaDiscord — Bot de Discord integrado para el ecosistema Ethernova.
 * Proporciona vinculación MC↔Discord, sincronización automática de roles
 * basados en ELO/rango, slash commands, y anuncios de ranking.
 */
public class EthernovaDiscord extends JavaPlugin {

    private static volatile EthernovaDiscord instance;
    private EthernovaCore core;
    private DiscordBot bot;
    private LinkManager linkManager;
    private RoleSyncManager roleSyncManager;
    private RankChangeListener rankChangeListener;

    @Override
    public void onEnable() {
        instance = this;
        long start = System.currentTimeMillis();

        getLogger().info("═══════════════════════════════════════════");
        getLogger().info("  EthernovaDiscord v" + getDescription().getVersion());
        getLogger().info("═══════════════════════════════════════════");

        try {
            // Fase 1: Core
            core = (EthernovaCore) Bukkit.getPluginManager().getPlugin("EthernovaCore");
            if (core == null) {
                getLogger().severe("EthernovaCore no encontrado! Deshabilitando...");
                Bukkit.getPluginManager().disablePlugin(this);
                return;
            }
            core.registerPlugin("EthernovaDiscord");

            // Fase 2: Config
            saveDefaultConfig();
            reloadConfig();

            // Fase 3: LinkManager (DB table for MC↔Discord links)
            linkManager = new LinkManager(this, core.getStorageManager());

            // Fase 4: RoleSyncManager
            roleSyncManager = new RoleSyncManager(this);

            // Fase 5: Discord Bot (JDA)
            String token = getConfig().getString("bot.token", "");
            if (token.isEmpty() || "TU_TOKEN_AQUI".equals(token)) {
                getLogger().warning("⚠ Token de Discord no configurado en config.yml!");
                getLogger().warning("  Configura bot.token y reinicia para activar el bot.");
            } else {
                bot = new DiscordBot(this);
                bot.start();
            }

            // Fase 6: Rank change listener (Bukkit events → Discord updates)
            if (Bukkit.getPluginManager().getPlugin("EthernovaRanked") != null) {
                rankChangeListener = new RankChangeListener(this);
                getServer().getPluginManager().registerEvents(rankChangeListener, this);
                getLogger().info("✔ EthernovaRanked detectado: sincronización de rangos activa.");
            } else {
                getLogger().warning("⚠ EthernovaRanked no encontrado. Solo funciones básicas disponibles.");
            }

            // Fase 7: Comando in-game /discord
            var cmd = getCommand("discord");
            if (cmd != null) {
                var executor = new DiscordCommand(this);
                cmd.setExecutor(executor);
                cmd.setTabCompleter(executor);
            }

            // Fase 8: Bulk sync task
            if (bot != null && getConfig().getBoolean("role-sync.enabled", true)) {
                int interval = getConfig().getInt("role-sync.bulk-sync-interval-minutes", 30);
                if (interval > 0) {
                    long ticks = interval * 60L * 20L;
                    Bukkit.getScheduler().runTaskTimerAsynchronously(this,
                            () -> roleSyncManager.bulkSync(), ticks, ticks);
                }
            }

            // Fase 9: Leaderboard auto-update
            if (bot != null) {
                String lbChannel = getConfig().getString("channels.leaderboard-channel-id", "");
                int lbInterval = getConfig().getInt("channels.leaderboard-update-minutes", 15);
                if (!lbChannel.isEmpty() && !"000000000000000000".equals(lbChannel) && lbInterval > 0) {
                    long ticks = lbInterval * 60L * 20L;
                    Bukkit.getScheduler().runTaskTimerAsynchronously(this,
                            () -> bot.updateLeaderboardEmbed(), ticks, ticks);
                }
            }

            long elapsed = System.currentTimeMillis() - start;
            getLogger().info("EthernovaDiscord habilitado en " + elapsed + "ms");

        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Error habilitando EthernovaDiscord", e);
            Bukkit.getPluginManager().disablePlugin(this);
        }
    }

    @Override
    public void onDisable() {
        if (bot != null) {
            bot.shutdown();
        }
        getLogger().info("EthernovaDiscord deshabilitado.");
    }

    public static EthernovaDiscord getInstance() { return instance; }
    public EthernovaCore getCore() { return core; }
    public DiscordBot getBot() { return bot; }
    public LinkManager getLinkManager() { return linkManager; }
    public RoleSyncManager getRoleSyncManager() { return roleSyncManager; }
}
