# DEEP AUDIT REPORT — EthernovaClans Ecosystem
### Paper 1.21.4 · Java 21 · Maven Multi-Module (11 modules) · 448 Java Files

---

## TABLE OF CONTENTS

1. [Executive Summary](#executive-summary)
2. [Methodology](#methodology)
3. [Findings by Severity](#findings-by-severity)
   - [CRITICAL](#critical-findings)
   - [HIGH](#high-findings)
   - [MEDIUM](#medium-findings)
   - [LOW](#low-findings)
4. [Findings by Category](#findings-by-category)
5. [Module Scorecards](#module-scorecards)
6. [Remediation Priority Matrix](#remediation-priority-matrix)

---

## Executive Summary

| Severity | Count |
|----------|-------|
| 🔴 CRITICAL | 6 |
| 🟠 HIGH | 18 |
| 🟡 MEDIUM | 14 |
| 🔵 LOW | 10 |
| **Total** | **48** |

**Overall assessment:** The codebase is well-structured with good separation of concerns across modules. Service registry pattern, HikariCP pooling, and ConcurrentHashMap usage demonstrate solid architectural decisions. However, systemic issues in error handling (50+ silently swallowed exceptions), missing database indexes, race conditions in async save-then-remove patterns, and memory leaks from uncleaned player maps significantly reduce production reliability.

---

## Methodology

Systematic search across all 448 Java files using pattern matching for:
- `catch (Exception ignored) {}` — silent error swallowing
- `ServiceRegistry.get()` — null-safety at 43 call sites
- `getConnection()` — resource management at 50+ sites
- `HashMap<UUID` / `ConcurrentHashMap` — thread safety and cleanup
- `PlayerQuitEvent` — memory leak prevention (26 handlers)
- `CREATE TABLE` / `CREATE INDEX` — DB schema quality
- `CompletableFuture.runAsync` — executor specification (15 sites)
- `Integer.MAX_VALUE` — permanent potion effects (20 matches)
- `broadcastMessage` — hardcoded strings (30+ matches)
- `hasPermission` — authorization checks (30+ matches)

---

## Findings by Severity

---

### CRITICAL Findings

---

#### C-01: Race Condition — Async Save + Immediate Map Removal
**Files:** `combat/src/.../stats/AdvancedStatsManager.java` (line 308), `ffa/src/.../kit/CustomKitsManager.java` (line 213)
**Category:** Concurrency

```java
// AdvancedStatsManager.unloadPlayer()
public void unloadPlayer(UUID uuid) {
    savePlayer(uuid);           // Returns CompletableFuture — async
    playerStats.remove(uuid);   // Removes data IMMEDIATELY — before save completes
    activeSessions.remove(uuid);
}
```

`savePlayer()` returns a `CompletableFuture` that runs on `dbExecutor`. The map entry is removed immediately, so if the async save reads from `playerStats.get(uuid)` after the remove, it gets `null` and saves nothing. **Data loss on every player quit.**

The same pattern exists in `CustomKitsManager.unloadPlayer()` which removes from `playerKits` immediately while no async save is even attempted.

**Impact:** Silent data loss for weapon stats and custom kits on every player disconnect.

---

#### C-02: 50+ Silently Swallowed Exceptions Across All Modules
**Files:** 25+ files across core, combat, cosmetics, clans, progression
**Category:** Error Handling & Resilience

A systematic search found **50+ instances** of `catch (Exception ignored) {}` with no logging. Critical locations include:

| File | Lines | Context |
|------|-------|---------|
| `cosmetics/.../PetManager.java` | 202, 218, 235, 255, 267, 280, 292 | **7 instances** — pet spawning, removal, effects all silently fail |
| `core/.../ReferralManager.java` | 286 | DB load for referral data — player silently gets no referral info |
| `clans/.../hook/CoreHook.java` | 26, 60, 69, 125, 131 | **5 instances** — cross-plugin integration silently fails |
| `clans/.../hook/CombatHook.java` | 29, 48, 54 | Combat tag checks silently fail — players may PvP-log freely |
| `clans/.../gui/AbstractGui.java` | 642, 806 | GUI rendering errors invisible to developers |
| `clans/.../gui/ConfigurableGUI.java` | 81, 92, 330, 349 | **4 instances** — config-driven GUI breaks silently |
| `clans/.../HologramManager.java` | 28, 37, 44 | Hologram operations fail without indication |
| `clans/.../TerritoryFlagManager.java` | 61 | Territory flag parsing fails silently |
| `progression/.../MissionManager.java` | 175, 635 | Mission progress may silently fail to track |
| `core/.../EthernovaScoreboardManager.java` | 232, 265 | Scoreboard updates fail without logging |
| `clans/.../webmap/WebMapServer.java` | 531, 1957 | HTTP request handling errors invisible |

**Impact:** Bugs become undetectable in production. Players experience broken features with no server-side indication for operators to diagnose.

---

#### C-03: WebMapServer — Unbounded Per-Player Data Growth
**File:** `src/src/.../webmap/WebMapServer.java` (2587 lines)
**Category:** Memory Leaks

```java
// playerDiscoveredChunks grows per player and per chunk — never cleaned on quit
private final Map<UUID, Set<String>> playerDiscoveredChunks = new ConcurrentHashMap<>();
```

Each online player accumulates chunk keys (`"x,z"` strings) as they explore. A single player exploring 1000 chunks adds ~1000 strings to their Set. With UUID overhead, this grows to **~50KB per active player**. On a server with 100 players over a session, this can reach **5+ MB** of uncollectable heap. Since there's no cleanup on `PlayerQuitEvent`, entries persist across player sessions until server restart.

Additionally, the following WebMapServer data structures grow per-clan without bounds:
- `poiData` — Points of Interest per clan
- `claimPlannerData` — Claim planner data per clan
- `clanThemes` — Theme preferences per clan
- `clanVotes` — Voting data per clan

**Impact:** Gradual heap exhaustion causing GC pressure and eventual OutOfMemoryError on long-running servers.

---

#### C-04: WebMapServer — Unauthenticated Chat Injection
**File:** `src/src/.../webmap/WebMapServer.java` (line 1561)
**Category:** Security

```java
org.bukkit.Bukkit.broadcastMessage("§7[Web] §f" + pName + (pTag.isEmpty() ? "" : " §7[" + pTag + "]") + " §f" + finalMsg);
```

The WebMap HTTP server allows authenticated web users to broadcast messages directly into the Minecraft server chat. While authentication exists (PBKDF2), the message content is inserted directly into `Bukkit.broadcastMessage()` without sanitization. A compromised web session or MITM attack could inject arbitrary color-coded messages impersonating system messages or staff.

**Impact:** Chat spoofing, social engineering attacks, potential command injection if any chat-processing plugin interprets §-codes as commands.

---

#### C-05: FFAEventsManager — Unsynchronized ArrayList in Multi-Threaded Context
**File:** `ffa/src/.../event/FFAEventsManager.java`
**Category:** Concurrency

```java
private final List<Entity> spawnedEntities = new ArrayList<>(); // NOT synchronized
```

`spawnedEntities` is modified by the Bukkit scheduler (async timer tasks) and the event system simultaneously. `ArrayList` is not thread-safe — concurrent add/remove causes `ConcurrentModificationException` or silent data corruption. Boss entities from events may never be cleaned up, persisting in the world.

**Impact:** Server crash from `ConcurrentModificationException`, or leaked entities consuming server ticks indefinitely.

---

#### C-06: Integer.MAX_VALUE Potion Effects Never Cleared on Crash
**Files:** `combat/.../KillStreakManager.java` (lines 157, 175, 192, 199, 200, 260), `ffa/.../FFAEventsManager.java` (lines 348-350), `ranked/` (multiple)
**Category:** Player Experience / Resilience

```java
killer.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1));
```

Found **20 instances** across combat, ffa, and ranked modules. If the plugin crashes, is force-stopped, or the server crashes while a player has these effects, the effects persist through server restart (saved in player data). There's no startup cleanup to remove stale permanent effects.

**Impact:** Players permanently stuck with Speed III, Resistance, Strength, etc. after a crash. Requires manual NBT editing or admin intervention per player.

---

### HIGH Findings

---

#### H-01: Missing Database Indexes — Clans Module (17+ Tables)
**File:** `src/src/.../storage/StorageManager.java`
**Category:** Performance / SQL & Database

The clans module creates **17+ tables** with zero indexes beyond primary keys. Critical missing indexes:

| Table | Missing Index | Impact |
|-------|---------------|--------|
| `clan_members` | `clan_id` | Every member lookup by clan scans full table |
| `clan_territories` | `clan_id` | Territory queries for 1 clan scan ALL territories |
| `clan_audit_log` | `(clan_id, timestamp)` | Audit log queries for a clan are O(n) |
| `clan_missions` | `clan_id` | Mission lookups on every progress event |
| `clan_achievements` | `clan_id` | Achievement checks scan full table |
| `clan_warps` | `clan_id` | Warp listing scans all warps |
| `clan_flags` | `clan_id` | Flag checks scan all flags |
| `clan_scheduled_events` | `clan_id` | Event queries scan all events |

By contrast, the **ranked module** correctly creates indexes on `ethernova_ranked_profiles(rating)` and `ethernova_ranked_matches(winner_uuid, loser_uuid)`.

**Impact:** Query performance degrades proportionally with data volume. With 100 clans × 50 members = 5000 rows, every member lookup is 50× slower than necessary.

---

#### H-02: Missing Database Indexes — Progression, FFA, Combat Modules
**Files:** `progression/.../MissionManager.java`, `ffa/.../CustomKitsManager.java`, `combat/.../AdvancedStatsManager.java`
**Category:** Performance / SQL & Database

| Table | Module | Missing Index |
|-------|--------|---------------|
| `ethernova_missions` | progression | `uuid` — every mission load scans all missions |
| `ethernova_missions_v2` | progression | `uuid` — same issue |
| `ethernova_mission_streaks` | progression | `uuid` |
| `ethernova_custom_kits` | ffa | `uuid` — kit loading per player |
| `ethernova_weapon_stats` | combat | `uuid` — stat loading per player |
| `ethernova_referrals` | core | `referrer_uuid` — referral count queries |
| `ethernova_referral_codes` | core | `uuid` — code lookup |

**Impact:** Every player join triggers multiple full table scans.

---

#### H-03: KillStreakManager — Massive Hardcoded Spanish Strings
**File:** `combat/src/.../killstreak/KillStreakManager.java` (602 lines)
**Category:** Code Quality / Player Experience

Lines 155-221 contain **20+ hardcoded Spanish strings** using legacy `§` formatting:

```java
Bukkit.broadcastMessage("§e§lRACHA §8» §b" + killer.getName() + " §7tiene §a5 §7bajas.");
Bukkit.broadcastMessage("§4§l☠☠ RACHA §8» §b" + killer.getName() + " §7es una §4§l§nMÁQUINA DE MATAR §7con §440 §7bajas!");
```

Also hardcodes money amounts: `500, 2000, 4000, 8000, 16000, 32000` — no config file.

**Issues:**
- Not localizable — Spanish-only
- Uses legacy `§` codes while other modules use Adventure/MiniMessage
- Money values and kill thresholds not configurable
- 20+ broadcast messages with no way to customize

**Impact:** Cannot change language, adjust kill reward curve, or modify messages without recompiling.

---

#### H-04: RankChangeListener — Memory Leak
**File:** `discord/src/.../listener/RankChangeListener.java`
**Category:** Memory Leaks

```java
private final Map<UUID, String> lastKnownRank; // never cleaned on PlayerQuitEvent
```

The `lastKnownRank` map stores the last known rank for every player who has ever logged in during the server's lifetime. No quit cleanup, no periodic eviction. On a server with 1000+ unique daily players, this accumulates indefinitely.

**Impact:** Gradual memory growth proportional to unique player count.

---

#### H-05: AuraGUIManager — HashMap Never Cleaned
**File:** `cosmetics/src/.../aura/AuraGUIManager.java` (line 24)
**Category:** Memory Leaks

```java
private final Map<UUID, Integer> configGUIPage = new HashMap<>();
```

No cleanup on `PlayerQuitEvent`. Every player who opens the aura config GUI gets an entry that persists until restart. Additionally uses `HashMap` (not `ConcurrentHashMap`) despite being potentially accessed from async GUI events.

**Impact:** Memory leak + potential thread safety issue.

---

#### H-06: BountyManager — YAML File Persistence for Active Game Data
**File:** `combat/src/.../bounty/BountyManager.java` (575 lines)
**Category:** Performance / SQL & Database

Bounties are stored in `bounties.yml` using Bukkit's YAML API. Every bounty placement/collection triggers a full file write. With 50 active bounties, this writes the entire YAML file to disk on every operation.

Additionally contains hardcoded Spanish strings throughout (lines 96-130) and no permission validation in `placeBounty()` itself (relies entirely on command executor).

**Impact:** Disk I/O bottleneck under load; data loss if server crashes mid-write (YAML is not atomic).

---

#### H-07: WebMapServer — 2587-Line Monolith with Manual JSON Building
**File:** `src/src/.../webmap/WebMapServer.java`
**Category:** Code Quality

A single 2587-line file handles: HTTP server lifecycle, authentication, session management, terrain rendering proxying, chat messaging, POI management, clan data serialization, territory history, voting, claim planning, and activity tracking.

JSON is built via string concatenation throughout — no JSON library (Gson/Jackson):
```java
// Hundreds of manual JSON constructions like:
sb.append("{\"name\":\"").append(escapeJson(name)).append("\",\"x\":").append(x).append("}");
```

While `escapeJson()` exists, manual JSON building is fragile and error-prone.

**Impact:** Extremely difficult to maintain, test, or extend. High risk of JSON encoding bugs.

---

#### H-08: CompletableFutures Without Exception Handlers
**Files:** Multiple across core, combat, ffa modules
**Category:** Error Handling & Resilience

Several `CompletableFuture.runAsync()` calls lack `.exceptionally()` handlers:

| File | Line | Context |
|------|------|---------|
| `core/.../ReferralManager.java` | 278 | Player referral load — exception vanishes |
| `ffa/.../CustomKitsManager.java` | 213, 233 | Kit persistence and deletion |
| `ranked/.../RankedManager.java` | 585 | Match history logging |
| `discord/.../DiscordBot.java` | 47 | Discord bot startup |

By contrast, `RankedManager.saveProfile()` (line 325) and `DuelStatsManager` correctly chain `.exceptionally()`. The inconsistency means some async failures are logged and some vanish into `ForkJoinPool`'s uncaught exception handler.

**Impact:** Async failures become invisible, making production debugging extremely difficult.

---

#### H-09: Mixed Formatting Systems — Legacy §-codes vs MiniMessage
**Files:** `combat/` module (§-codes), `ffa/`, `progression/`, `clans/` modules (MiniMessage)
**Category:** Code Quality

The combat module exclusively uses legacy `§` color codes (`§e§lRACHA`, `§4§l☠`), while newer modules use Adventure MiniMessage (`<yellow>`, `<gold>`). The FFA module uses both — MiniMessage in `FFAEventsManager.broadcast()` but legacy codes in some places.

**Impact:** Inconsistent player-facing formatting. Future Paper versions may deprecate legacy formatting.

---

#### H-10: PlayerProfileManager — Manual Connection Management
**File:** `core/src/.../profile/PlayerProfileManager.java` (line 172)
**Category:** SQL & Database

```java
// saveAll() — manual connection management instead of try-with-resources
Connection conn = null;
try {
    conn = storage.getConnection();
    // ... batch operations ...
} finally {
    if (conn != null) try { conn.close(); } catch (Exception ignored) {}
}
```

All other managers use `try-with-resources` consistently. This is the only file with manual connection management, creating a code consistency issue and a higher risk of connection leaks if the code path is modified.

**Impact:** Risk of connection pool exhaustion if exception handling is altered.

---

#### H-11: PetManager — 7 Silent Exception Catches in Entity Operations
**File:** `cosmetics/src/.../effect/PetManager.java` (lines 202-292)
**Category:** Error Handling & Resilience

Seven distinct entity operations (spawn, remove, teleport, set properties, etc.) each wrapped in `catch (Exception ignored) {}`. Pet entities are living Bukkit entities that consume server ticks. If spawning succeeds but tracking fails (silently), orphaned entities persist in the world.

**Impact:** Orphaned entities accumulating in worlds, consuming server performance with no diagnostic capability.

---

#### H-12: CoreHook — 5 Silent Catches in Cross-Plugin Integration
**File:** `src/src/.../hook/CoreHook.java` (lines 26, 60, 69, 125, 131)
**Category:** Error Handling & Resilience

CoreHook bridges the clans module with EthernovaCore. Five critical operations silently swallow exceptions:
- Getting player balance
- Checking VIP status
- Getting player level
- Formatting currency
- Getting display names

**Impact:** Clan features dependent on core data (bank operations, VIP perks, level requirements) silently malfunction.

---

#### H-13: CombatHook — Silent Combat Tag Check Failures
**File:** `src/src/.../hook/CombatHook.java` (lines 29, 48, 54)
**Category:** Error Handling & Security

```java
public static boolean isInCombat(Player p) {
    try { /* check combat tag */ }
    catch (Exception ignored) {} // silently returns false — player not in combat
}
```

If the combat API check fails, `isInCombat()` returns `false`, allowing players to teleport, open GUIs, or log out during combat. This is an exploitable PvP-log vulnerability.

**Impact:** Players can exploit combat-tag bypass by triggering the exception path.

---

#### H-14: AdvancedStatsManager — `markClean()` Before Batch Execute
**File:** `combat/src/.../stats/AdvancedStatsManager.java` (line 295)
**Category:** Concurrency / Data Integrity

```java
for (Map.Entry<String, WeaponStats> entry : stats.entrySet()) {
    // ... prepare batch ...
    ps.addBatch();
    ws.markClean();  // Marked clean BEFORE executeBatch()
}
ps.executeBatch();  // If this fails, data is marked clean but never saved
```

If `executeBatch()` throws an exception, all stats are already marked clean and will never be retried.

**Impact:** Silent, permanent data loss for weapon statistics on any DB error.

---

#### H-15: No Graceful Degradation for ServiceRegistry Dependencies
**Files:** All modules calling `ServiceRegistry.get()`
**Category:** Error Handling & Resilience

While most callers null-check ServiceRegistry results (good), the degradation is typically silent — features just don't work without any player-facing indication or admin logging:

```java
CombatAPI combatAPI = ServiceRegistry.get(CombatAPI.class);
if (combatAPI != null) {
    // Feature works
} else {
    // Nothing — feature silently disabled
}
```

No startup warnings are logged when expected services aren't available.

**Impact:** Operators may not realize features are disabled due to missing module dependencies.

---

#### H-16: No Transaction Rollback on Partial Batch Failures
**Files:** `core/.../PlayerProfileManager.java`, `combat/.../AdvancedStatsManager.java`
**Category:** SQL & Database

Batch operations in `saveAll()` don't use database transactions. If a batch of 100 player saves fails at row 50, the first 49 are committed and the rest lost, leaving the database in an inconsistent state.

**Impact:** Partial data corruption on batch save failures during shutdown.

---

#### H-17: DecentHologramsHook — HashMap for Active Holograms
**File:** `src/src/.../hook/DecentHologramsHook.java` (line 23)
**Category:** Memory Leaks / Thread Safety

```java
private final Map<String, Hologram> activeHolograms = new HashMap<>();
```

Plain `HashMap` for tracking active holograms. If accessed from async contexts (e.g., territory claim events from DB callbacks), concurrent modification is possible. No cleanup mechanism for disbanded clans' holograms.

**Impact:** Thread-safety violations; hologram entries for disbanded clans never cleaned.

---

#### H-18: StorageManager.deleteClan() — Dynamic Table Names in SQL
**File:** `src/src/.../storage/StorageManager.java` (line ~420)
**Category:** SQL & Database / Security

```java
String[][] targets = {{"clan_members","clan_id"}, {"clan_territories","clan_id"}, ...};
for (String[] t : targets) {
    stmt.executeUpdate("DELETE FROM " + t[0] + " WHERE " + t[1] + " = ?");
}
```

While table/column names come from hardcoded string arrays (not user input), this pattern prevents use of prepared statement parameter binding for identifier names. If future developers add user-influenced values to the arrays, SQL injection becomes possible. The values are parameterized with `?` for the actual data, which is correct.

**Impact:** Low immediate risk, but sets a dangerous pattern for future maintenance.

---

### MEDIUM Findings

---

#### M-01: AdminGUIManager — Plain HashMap for Player GUI State
**File:** `combat/src/.../gui/AdminGUIManager.java` (lines 33-37)
**Category:** Thread Safety

```java
private final Map<UUID, ?> openGUIs = new HashMap<>();
private final Map<UUID, ?> worldContext = new HashMap<>();
private final Map<UUID, ?> pageContext = new HashMap<>();
```

Three player-keyed HashMaps without synchronization. While Bukkit GUI events are typically main-thread, async scheduler callbacks or API calls from other modules could cause `ConcurrentModificationException`.

**Impact:** Potential GUI corruption under concurrent access.

---

#### M-02: WarManager — Defensive HashMap Copies for Iteration
**File:** `src/src/.../war/WarManager.java` (lines 175, 265)
**Category:** Performance

```java
for (var entry : new HashMap<>(activeWars).entrySet()) { ... }
```

Creates full copies of the `activeWars` map for safe iteration. This is a defensive pattern but indicates the underlying map should be a `ConcurrentHashMap` instead.

**Impact:** Unnecessary memory allocation on every tick of the war check scheduler.

---

#### M-03: EventScheduler — HashMap Copies + Silent Exception
**File:** `src/src/.../scheduledevent/EventScheduler.java` (lines 110, 121, 330)
**Category:** Concurrency / Error Handling

Same defensive copy pattern as WarManager, plus a silent exception catch during event execution. If a scheduled event throws, it's silently swallowed and the event appears to have run successfully.

**Impact:** Scheduled events can fail without any indication to players or operators.

---

#### M-04: Inconsistent Executor Usage for CompletableFuture
**Files:** Multiple
**Category:** Concurrency

Some modules correctly specify `core.getDbExecutor()`:
- ✅ `RankedManager`, `DuelStatsManager`, `FFAStatsManager`, `PartyStorageManager`, `CustomKitsManager`, `AdvancedStatsManager`

Others use the default `ForkJoinPool.commonPool()`:
- ❌ `DiscordBot.start()` (line 47) — JDA startup on common pool
- ❌ `RankedManager.logMatchHistory()` (line 585) — DB operation on common pool

Using `ForkJoinPool.commonPool()` for blocking DB operations can starve the pool, affecting all CompletableFuture operations JVM-wide.

**Impact:** Potential thread starvation under high load.

---

#### M-05: TerrainRenderer — Static HashMap for Block Colors
**File:** `src/src/.../webmap/TerrainRenderer.java` (line 30)
**Category:** Code Quality

```java
private static final Map<String, Integer> BLOCK_COLORS = new HashMap<>();
```

Static mutable HashMap initialized in a static block. While effectively single-threaded in use, a `Map.of()` or `Collections.unmodifiableMap()` would be safer and more intentional.

**Impact:** Minor — could be modified accidentally at runtime.

---

#### M-06: SoundUtil — Silent Exception on Sound Playback
**File:** `src/src/.../util/SoundUtil.java` (lines 42, 59)
**Category:** Error Handling

Two `catch (Exception ignored) {}` blocks in utility methods that could mask invalid sound names from configuration. Players hear nothing, operators see nothing.

**Impact:** Sound configuration errors become invisible.

---

#### M-07: TeleportManager — Silent Exception on Core Operations
**File:** `src/src/.../teleport/TeleportManager.java` (lines 185, 246)
**Category:** Error Handling

Teleportation countdown and execution have silent catches. If teleportation fails, the player's cooldown is consumed but they don't teleport.

**Impact:** Players lose teleport cooldowns without actually teleporting.

---

#### M-08: BlueprintManager — Silent Exception in Deserialization
**File:** `src/src/.../blueprint/BlueprintManager.java` (line 103)
**Category:** Error Handling

Blueprint block deserialization silently catches exceptions. A corrupted blueprint entry causes the entire blueprint to render with missing blocks, with no indication of which blocks failed.

**Impact:** Partial blueprint rendering with no diagnostic capability.

---

#### M-09: InvitationsGui — Silent Exception
**File:** `src/src/.../gui/menus/InvitationsGui.java` (line 223)
**Category:** Error Handling

Invitation GUI rendering silently catches exceptions. A single malformed invitation entry could crash the GUI for a player with no logged error.

**Impact:** GUI display issues with no diagnostic trail.

---

#### M-10: MembersGui — Silent Exception
**File:** `src/src/.../gui/menus/MembersGui.java` (line 161)
**Category:** Error Handling

Same pattern as InvitationsGui — member list GUI rendering has a silent catch block.

**Impact:** Member management GUI breaks silently if any member data is malformed.

---

#### M-11: Metrics/MetricsLite — Silent Exception on Data Collection
**Files:** `src/src/.../util/Metrics.java` (lines 58, 158), `src/src/.../util/MetricsLite.java`
**Category:** Error Handling

Analytics data collection silently swallows exceptions. While less critical than gameplay features, this means server operators can't rely on metrics accuracy.

**Impact:** Inaccurate server analytics.

---

#### M-12: Progression LevelManager — Broadcast Without Permission Filter
**File:** `progression/src/.../level/LevelManager.java` (line 164)
**Category:** Player Experience

```java
Bukkit.broadcast(mini.deserialize("..."));
```

Level-up broadcasts go to ALL online players. On servers with 100+ players, frequent level-ups create chat spam.

**Impact:** Chat spam for all players on busy servers.

---

#### M-13: PrestigeManager — Same Broadcast Pattern
**File:** `progression/src/.../prestige/PrestigeManager.java` (line 169)
**Category:** Player Experience

Prestige broadcasts to all players, same issue as LevelManager.

**Impact:** Additional chat spam source.

---

#### M-14: RankingsGui — Silent Exception in Ranking Display
**File:** `core/src/.../gui/RankingsGui.java` (line 82)
**Category:** Error Handling

Ranking GUI entries that fail to render are silently skipped. Players see an incomplete leaderboard with no indication of errors.

**Impact:** Misleading leaderboard data.

---

### LOW Findings

---

#### L-01: Cosmetics Module — DeathEffectManager Silent Catch
**File:** `combat/src/.../death/DeathEffectManager.java` (line 32)
**Category:** Error Handling

Single silent catch in death effect rendering. Minor — death effects are purely cosmetic.

---

#### L-02: ArmorTrimManager — Silent Exception
**File:** `cosmetics/src/.../armortrim/ArmorTrimManager.java` (line 182)
**Category:** Error Handling

Silent catch in armor trim application. Cosmetic-only impact.

---

#### L-03: TitleManager — Silent Exception
**File:** `cosmetics/src/.../effect/TitleManager.java` (line 278)
**Category:** Error Handling

Silent catch in title display. Minor cosmetic feature.

---

#### L-04: AdvancedAurasManager — Non-Thread-Safe Config Maps
**File:** `cosmetics/src/.../aura/AdvancedAurasManager.java` (lines 55-56)
**Category:** Thread Safety

```java
private final Map<String, Sound> auraSounds = new HashMap<>();
private final Map<String, Float> auraSoundPitch = new HashMap<>();
```

Config data stored in plain HashMaps. Loaded once on startup and read-only afterward — low risk but using `Map.of()` would be safer.

---

#### L-05: PartyGamesManager — Plain HashMap for Game State
**File:** `party/src/.../games/PartyGamesManager.java` (lines 143-160)
**Category:** Thread Safety

```java
private final Map<UUID, Integer> roundWins = new HashMap<>();
private final Map<UUID, Integer> parkourProgress = new HashMap<>();
private final Map<UUID, Integer> teamAssignment = new HashMap<>();
```

Game state stored in plain HashMaps within `GameSession` inner class. Likely main-thread only, but if party games trigger async events, race conditions are possible.

---

#### L-06: SalaryManager — Defensive HashMap Copy
**File:** `src/src/.../salary/SalaryManager.java` (lines 64, 168)
**Category:** Code Quality

Defensive copies of salary config maps on every access. Minor performance overhead.

---

#### L-07: ClanSkillManager — Defensive HashMap Copy
**File:** `src/src/.../skill/ClanSkillManager.java` (line 116)
**Category:** Code Quality

Same defensive copy pattern for skill data access.

---

#### L-08: EthernovaScoreboardManager — Two Silent Catches
**File:** `core/src/.../scoreboard/EthernovaScoreboardManager.java` (lines 232, 265)
**Category:** Error Handling

Scoreboard update errors silently swallowed. Scoreboard may display stale data.

---

#### L-09: SchemaManager — No Version Tracking for Module Schemas
**File:** `src/src/.../storage/SchemaManager.java`
**Category:** SQL & Database

`SchemaManager` tracks schema versions for the clans module's additional tables but other modules (combat, ffa, progression) use their own migration systems (`MigrationManager`). The inconsistency makes global schema management difficult.

---

#### L-10: EthernovaMetrics — Two Silent Catches in Analytics
**File:** `core/src/.../metrics/EthernovaMetrics.java` (lines 53, 175)
**Category:** Error Handling

Analytics collection errors silently swallowed. Non-critical for gameplay.

---

## Findings by Category

### 1. Error Handling & Resilience (15 findings)
- C-02, H-08, H-11, H-12, H-13, H-15, M-03, M-06, M-07, M-08, M-09, M-10, M-11, M-14, L-01/L-02/L-03/L-08/L-10

### 2. SQL & Database (5 findings)
- H-01, H-02, H-06, H-10, H-16, H-18, L-09

### 3. Concurrency (6 findings)
- C-01, C-05, H-14, M-01, M-02, M-04

### 4. Memory Leaks (4 findings)
- C-03, H-04, H-05, H-17

### 5. Code Quality (4 findings)
- H-03, H-07, H-09, M-05, L-06, L-07

### 6. Security (2 findings)
- C-04, H-13

### 7. Player Experience (3 findings)
- C-06, M-12, M-13

### 8. Performance (2 findings)
- H-01, H-02

### 9. Thread Safety (4 findings)
- M-01, L-04, L-05, H-17

---

## Module Scorecards

| Module | Files | Critical | High | Medium | Low | Grade |
|--------|-------|----------|------|--------|-----|-------|
| **combat** | ~45 | 2 (C-01,C-06) | 4 (H-03,H-08,H-11,H-14) | 0 | 1 | **D** |
| **core** | ~40 | 1 (C-02) | 3 (H-08,H-10,H-12,H-15) | 0 | 2 | **C** |
| **src (clans)** | ~120 | 2 (C-03,C-04) | 3 (H-01,H-07,H-18) | 8 | 0 | **D** |
| **cosmetics** | ~35 | 1 (C-02) | 2 (H-05,H-11) | 0 | 3 | **C** |
| **ffa** | ~25 | 2 (C-05,C-06) | 1 (H-02) | 0 | 0 | **C-** |
| **ranked** | ~20 | 1 (C-06) | 0 | 1 (M-04) | 0 | **B** |
| **discord** | ~15 | 0 | 1 (H-04) | 1 (M-04) | 0 | **B** |
| **party** | ~20 | 0 | 0 | 0 | 1 | **A-** |
| **duels** | ~15 | 0 | 0 | 0 | 0 | **A** |
| **progression** | ~25 | 1 (C-02) | 1 (H-02) | 1 (M-12) | 0 | **C** |

---

## Remediation Priority Matrix

### Immediate (Week 1) — Critical Fixes
| ID | Fix | Effort | Risk |
|----|-----|--------|------|
| C-01 | Chain `.thenRun(() -> map.remove(uuid))` instead of immediate remove | 1h | Data loss |
| C-02 | Replace top-50 `catch (Exception ignored) {}` with `logger.log(Level.WARNING, ...)` | 4h | Silent failures |
| C-05 | Replace `ArrayList` with `CopyOnWriteArrayList` or synchronize | 30min | Server crash |
| H-14 | Move `markClean()` after `executeBatch()` succeeds | 30min | Data loss |

### Short-Term (Week 2-3) — High Priority
| ID | Fix | Effort |
|----|-----|--------|
| C-03 | Add `playerDiscoveredChunks.remove(uuid)` in `PlayerQuitEvent` handler | 1h |
| C-04 | Sanitize web chat messages — strip §-codes, limit length, rate-limit | 2h |
| C-06 | Add startup task to clear all `Integer.MAX_VALUE` potion effects from online players | 2h |
| H-01/H-02 | Add `CREATE INDEX` statements for all identified tables | 3h |
| H-04 | Add `lastKnownRank.remove(uuid)` in quit handler or use `Cache<UUID,String>` with TTL | 1h |
| H-05 | Add quit cleanup for `configGUIPage` + switch to `ConcurrentHashMap` | 1h |
| H-08 | Add `.exceptionally(ex -> { logger.severe(...); return null; })` to all CompletableFutures | 2h |

### Medium-Term (Month 1) — Code Quality
| ID | Fix | Effort |
|----|-----|--------|
| H-03 | Extract all KillStreakManager messages to `messages.yml`, implement MiniMessage formatting | 8h |
| H-07 | Refactor WebMapServer into 5-6 handler classes, add Gson for JSON | 16h |
| H-09 | Migrate all legacy §-codes in combat module to MiniMessage | 6h |
| H-06 | Migrate BountyManager from YAML to database storage | 4h |
| M-04 | Audit all `CompletableFuture.runAsync()` calls — ensure DB operations use `dbExecutor` | 2h |

### Long-Term (Month 2+) — Architecture
| ID | Fix | Effort |
|----|-----|--------|
| H-15 | Add ServiceRegistry lifecycle logging — warn on missing expected services | 4h |
| H-16 | Implement proper transaction management with rollback for batch saves | 8h |
| M-12/M-13 | Add configurable broadcast toggles and permission-based filtering | 4h |

---

*Report generated by deep codebase analysis — 448 files examined, 25+ files read in detail, 20+ pattern searches executed.*
