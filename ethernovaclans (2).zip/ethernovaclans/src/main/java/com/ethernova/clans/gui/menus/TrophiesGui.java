package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.SoundUtil;
import com.ethernova.clans.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Trophies & Hall of Fame GUI.
 * Shows server-wide clan rankings across multiple categories & individual trophies.
 */
public class TrophiesGui extends AbstractGui {

    private int selectedCategory = 0;

    private static final String[] CATEGORIES = {
            "general", "pvp", "territory", "economy", "level"
    };
    private static final String[] CATEGORY_NAMES = {
            "🏆 General", "⚔ PvP", "🗺 Territorio", "💰 Economía", "⭐ Nivel"
    };
    private static final Material[] CATEGORY_ICONS = {
            Material.GOLD_BLOCK, Material.DIAMOND_SWORD, Material.FILLED_MAP,
            Material.GOLD_INGOT, Material.EXPERIENCE_BOTTLE
    };

    public TrophiesGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "trophies");
    }

    @Override
    protected void populateItems() {
        // ── Header ──
        setItem(4, new ItemBuilder(Material.DRAGON_HEAD)
                .name("<gradient:#FFD700:#FF4500>🏆 Salón de la Fama</gradient>")
                .lore(List.of(
                        "",
                        "<gray>Los mejores clanes del servidor",
                        "<gray>clasificados por categoría.",
                        "",
                        "<yellow>Selecciona una categoría abajo."
                ))
                .build());

        // ── Category tabs (row 2) ──
        int[] tabSlots = {11, 12, 13, 14, 15};
        for (int i = 0; i < CATEGORIES.length && i < tabSlots.length; i++) {
            boolean selected = (i == selectedCategory);
            int finalI = i;
            setItem(tabSlots[i], new ItemBuilder(CATEGORY_ICONS[i])
                    .name((selected ? "<green>▶ " : "<gray>") + CATEGORY_NAMES[i])
                    .lore(List.of(
                            selected ? "<green>Seleccionado" : "<yellow>Click para ver"
                    ))
                    .glowIf(selected)
                    .build());
            slotActions.put(tabSlots[i], "TAB:" + i);
        }

        // ── Ranking ──
        List<Clan> clans = new ArrayList<>(plugin.getClanManager().getAllClans());
        sortByCategory(clans, CATEGORIES[selectedCategory]);

        // Podium (top 3)
        int[] podiumSlots = {22, 21, 23}; // 1st center, 2nd left, 3rd right
        Material[] podiumBlocks = {Material.GOLD_BLOCK, Material.IRON_BLOCK, Material.COPPER_BLOCK};
        String[] medals = {"🥇", "🥈", "🥉"};
        String[] podiumColors = {"<gold>", "<gray>", "<#CD7F32>"};

        for (int i = 0; i < 3 && i < clans.size(); i++) {
            Clan clan = clans.get(i);
            String value = getValueForCategory(clan, CATEGORIES[selectedCategory]);

            setItem(podiumSlots[i], new ItemBuilder(podiumBlocks[i])
                    .name(podiumColors[i] + medals[i] + " #" + (i + 1) + " " + clan.getName())
                    .lore(List.of(
                            "",
                            "<gray>Tag: <white>[" + clan.getTag() + "]",
                            "<gray>Valor: <yellow>" + value,
                            "<gray>Miembros: <white>" + clan.getMembers().size(),
                            "<gray>Nivel: <aqua>" + clan.getLevel(),
                            ""
                    ))
                    .glowIf(i == 0)
                    .build());
        }

        // ── Ranking list (positions 4-14) ──
        int[] listSlots = {28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40};
        for (int i = 3; i < 14 && i < clans.size(); i++) {
            Clan clan = clans.get(i);
            int listIdx = i - 3;
            if (listIdx >= listSlots.length) break;
            String value = getValueForCategory(clan, CATEGORIES[selectedCategory]);

            setItem(listSlots[listIdx], new ItemBuilder(Material.PAPER)
                    .name("<white>#" + (i + 1) + " " + clan.getName())
                    .lore(List.of(
                            "<gray>Tag: [" + clan.getTag() + "]",
                            "<gray>Valor: <yellow>" + value
                    ))
                    .build());
        }

        // ── Player's clan position ──
        Clan playerClan = plugin.getClanManager().getClanByPlayer(player);
        if (playerClan != null) {
            int rank = clans.indexOf(playerClan) + 1;
            String value = getValueForCategory(playerClan, CATEGORIES[selectedCategory]);
            setItem(49, new ItemBuilder(Material.PLAYER_HEAD)
                    .name("<aqua>Tu Clan: " + playerClan.getName())
                    .lore(List.of(
                            "",
                            "<gray>Posición: <yellow>#" + rank + " de " + clans.size(),
                            "<gray>Valor: <white>" + value,
                            "<gray>Nivel: <aqua>" + playerClan.getLevel()
                    ))
                    .build());
        }
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.startsWith("TAB:")) {
            int tab = Integer.parseInt(action.substring("TAB:".length()));
            if (tab >= 0 && tab < CATEGORIES.length) {
                selectedCategory = tab;
                SoundUtil.click(player);
                refreshGui();
            }
            return true;
        }
        return false;
    }

    private void sortByCategory(List<Clan> clans, String category) {
        clans.sort((a, b) -> {
            double valA = getNumericValue(a, category);
            double valB = getNumericValue(b, category);
            return Double.compare(valB, valA); // Descending
        });
    }

    private double getNumericValue(Clan clan, String category) {
        return switch (category) {
            case "pvp" -> clan.getTotalKills();
            case "territory" -> plugin.getTerritoryManager().getClanClaims(clan.getId()).size();
            case "economy" -> clan.getBank().getBalance();
            case "level" -> clan.getLevel() * 1000.0 + plugin.getLevelManager().getXP(clan.getId());
            default -> // general: combined score
                    (clan.getLevel() * 500.0) +
                    (clan.getTotalKills() * 10.0) +
                    (plugin.getTerritoryManager().getClanClaims(clan.getId()).size() * 50.0) +
                    (clan.getBank().getBalance() * 0.1) +
                    (clan.getMembers().size() * 100.0);
        };
    }

    private String getValueForCategory(Clan clan, String category) {
        return switch (category) {
            case "pvp" -> clan.getTotalKills() + " kills / " + clan.getTotalDeaths() + " deaths";
            case "territory" -> plugin.getTerritoryManager().getClanClaims(clan.getId()).size() + " chunks";
            case "economy" -> "$" + String.format("%.2f", clan.getBank().getBalance());
            case "level" -> "Nivel " + clan.getLevel() + " (" + plugin.getLevelManager().getXP(clan.getId()) + " XP)";
            default -> String.format("%.0f pts", getNumericValue(clan, category));
        };
    }

    private void refreshGui() {
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            occupiedSlots.clear();
            slotActions.clear();
            rightClickActions.clear();
            slotConfigs.clear();
            fillBackground();
            placeConfigItems();
            populateItems();
        });
    }
}
