package com.ethernova.clans.hook;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.util.TextUtil;
import eu.decentsoftware.holograms.api.DHAPI;
import eu.decentsoftware.holograms.api.holograms.Hologram;
import org.bukkit.Bukkit;
import org.bukkit.Location;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

/**
 * DecentHolograms integration for clan ranking holograms.
 */
public class DecentHologramsHook {

    private final EthernovaClans plugin;
    private final Map<String, Hologram> activeHolograms = new ConcurrentHashMap<>();
    private boolean enabled;

    public DecentHologramsHook(EthernovaClans plugin) {
        this.plugin = plugin;
        this.enabled = Bukkit.getPluginManager().getPlugin("DecentHolograms") != null;
    }

    public boolean isEnabled() {
        return enabled;
    }

    // ══════════════════════════════════════════════════════════
    //  HOLOGRAM MANAGEMENT
    // ══════════════════════════════════════════════════════════

    /**
     * Create or update a top clans hologram.
     */
    public void updateTopHologram(String category, Location location, int topCount) {
        if (!enabled) return;

        String holoId = "ethernova_top_" + category;

        try {
            // Remove existing
            if (activeHolograms.containsKey(holoId)) {
                DHAPI.removeHologram(holoId);
                activeHolograms.remove(holoId);
            }

            // Build lines
            List<String> lines = new ArrayList<>();
            lines.add("&6&l═══ Top Clans (" + TextUtil.capitalize(category) + ") ═══");
            lines.add("");

            List<Clan> topClans = plugin.getClanManager().getTopClans(category, topCount);
            for (int i = 0; i < topClans.size(); i++) {
                Clan clan = topClans.get(i);
                String rank = switch (i) {
                    case 0 -> "&6#1 ";
                    case 1 -> "&7#2 ";
                    case 2 -> "&c#3 ";
                    default -> "&f#" + (i + 1) + " ";
                };
                lines.add(rank + "&f" + clan.getTag() + " " + clan.getName() +
                        " &7- &e" + getTopValue(clan, category));
            }

            // Fill empty slots
            for (int i = topClans.size(); i < topCount; i++) {
                lines.add("&8#" + (i + 1) + " ---");
            }

            lines.add("");
            lines.add("&7Updated periodically");

            // Create hologram
            Hologram hologram = DHAPI.createHologram(holoId, location, lines);
            activeHolograms.put(holoId, hologram);

        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Failed to update hologram " + holoId, e);
        }
    }

    /**
     * Update all configured top holograms.
     */
    public void updateAllHolograms() {
        if (!enabled) return;

        var config = plugin.getConfigManager();
        var holoSection = config.getConfig().getConfigurationSection("tops.holograms");
        if (holoSection == null || !holoSection.getBoolean("enabled", false)) return;

        var locations = holoSection.getConfigurationSection("locations");
        if (locations == null) return;

        for (String category : locations.getKeys(false)) {
            var locSection = locations.getConfigurationSection(category);
            if (locSection == null) continue;

            String worldName = locSection.getString("world", "world");
            var world = Bukkit.getWorld(worldName);
            if (world == null) continue;

            double x = locSection.getDouble("x");
            double y = locSection.getDouble("y");
            double z = locSection.getDouble("z");
            int topCount = holoSection.getInt("top-count", 10);

            Location loc = new Location(world, x, y, z);
            updateTopHologram(category, loc, topCount);
        }
    }

    /**
     * Remove all clan holograms.
     */
    public void removeAll() {
        if (!enabled) return;
        for (String holoId : activeHolograms.keySet()) {
            try {
                DHAPI.removeHologram(holoId);
            } catch (Exception e) {
                plugin.getLogger().warning("Failed to remove hologram '" + holoId + "': " + e.getMessage());
            }
        }
        activeHolograms.clear();
    }

    private String getTopValue(Clan clan, String category) {
        return switch (category) {
            case "power" -> String.valueOf(clan.getPower());
            case "kd" -> String.format("%.2f", clan.getKD());
            case "kills" -> String.valueOf(clan.getKills());
            case "level" -> String.valueOf(clan.getLevel());
            case "balance" -> TextUtil.formatCurrency(clan.getBank().getBalance());
            default -> "???";
        };
    }
}
