package com.ethernova.clans.event;

import com.ethernova.clans.clan.Clan;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

/**
 * Fired when clan power changes (gain or loss).
 */
public class ClanPowerChangeEvent extends Event implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();
    private boolean cancelled = false;

    private final Clan clan;
    private int amount;
    private final String reason;
    private final boolean gain; // true = gain, false = loss

    public ClanPowerChangeEvent(Clan clan, int amount, String reason, boolean gain) {
        this.clan = clan;
        this.amount = amount;
        this.reason = reason;
        this.gain = gain;
    }

    public Clan getClan() { return clan; }
    public int getAmount() { return amount; }
    public void setAmount(int amount) { this.amount = amount; }
    public String getReason() { return reason; }
    public boolean isGain() { return gain; }

    @Override public boolean isCancelled() { return cancelled; }
    @Override public void setCancelled(boolean cancel) { this.cancelled = cancel; }
    @Override public @NotNull HandlerList getHandlers() { return HANDLERS; }
    public static HandlerList getHandlerList() { return HANDLERS; }
}
