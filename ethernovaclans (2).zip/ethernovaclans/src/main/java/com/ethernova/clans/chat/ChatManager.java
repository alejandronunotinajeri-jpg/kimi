package com.ethernova.clans.chat;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanMember;
import com.ethernova.clans.util.TextUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages clan chat channels (clan, alliance, war).
 */
public class ChatManager {

    private final EthernovaClans plugin;

    /** Players in clan chat mode */
    private final Set<UUID> clanChatPlayers = ConcurrentHashMap.newKeySet();

    /** Players in alliance chat mode */
    private final Set<UUID> allianceChatPlayers = ConcurrentHashMap.newKeySet();

    public ChatManager(EthernovaClans plugin) {
        this.plugin = plugin;
    }

    // ══════════════════════════════════════════════════════════
    //  CLAN CHAT
    // ══════════════════════════════════════════════════════════

    /**
     * Toggle clan chat mode for a player.
     */
    public void toggleClanChat(Player player) {
        if (clanChatPlayers.contains(player.getUniqueId())) {
            clanChatPlayers.remove(player.getUniqueId());
            allianceChatPlayers.remove(player.getUniqueId());
            player.sendMessage(plugin.getConfigManager().getMessage("chat-messages.toggled-clan",
                    "status", plugin.getConfigManager().getRawMessage("general.disabled")));
        } else {
            clanChatPlayers.add(player.getUniqueId());
            allianceChatPlayers.remove(player.getUniqueId());
            player.sendMessage(plugin.getConfigManager().getMessage("chat-messages.toggled-clan",
                    "status", plugin.getConfigManager().getRawMessage("general.enabled")));
        }
    }

    /**
     * Toggle alliance chat mode for a player.
     */
    public void toggleAllianceChat(Player player) {
        if (allianceChatPlayers.contains(player.getUniqueId())) {
            allianceChatPlayers.remove(player.getUniqueId());
            player.sendMessage(plugin.getConfigManager().getMessage("chat-messages.toggled-alliance",
                    "status", plugin.getConfigManager().getRawMessage("general.disabled")));
        } else {
            allianceChatPlayers.add(player.getUniqueId());
            clanChatPlayers.remove(player.getUniqueId());
            player.sendMessage(plugin.getConfigManager().getMessage("chat-messages.toggled-alliance",
                    "status", plugin.getConfigManager().getRawMessage("general.enabled")));
        }
    }

    public boolean isInClanChat(Player player) {
        return clanChatPlayers.contains(player.getUniqueId());
    }

    public boolean isInAllianceChat(Player player) {
        return allianceChatPlayers.contains(player.getUniqueId());
    }

    public void removeFromClanChat(Player player) {
        clanChatPlayers.remove(player.getUniqueId());
        allianceChatPlayers.remove(player.getUniqueId());
    }

    /**
     * Send a message to all clan members.
     */
    public void sendClanMessage(Player sender, Clan clan, String message) {
        if (!clan.isClanChatEnabled()) {
            sender.sendMessage(plugin.getConfigManager().getMessage("chat-messages.clan-chat-disabled"));
            return;
        }

        String format = plugin.getConfigManager().getString("chat.clan.format",
                "<dark_aqua>[Clan]</dark_aqua> {clan_tag} {role_color}{player_name}<gray>:</gray> <white>{message}</white>");

        ClanMember member = clan.getMember(sender.getUniqueId());
        String roleName = member != null ? member.getRole().name() : "MEMBER";
        String roleColor = getRoleColor(member);

        Component formatted = TextUtil.parse(format,
                "clan_tag", clan.getFormattedTag(),
                "clan_name", clan.getName(),
                "player_name", sender.getName(),
                "role_color", roleColor,
                "role", roleName,
                "message", MiniMessage.miniMessage().escapeTags(message));

        for (ClanMember m : clan.getMembers()) {
            Player p = Bukkit.getPlayer(m.getUuid());
            if (p != null && p.isOnline()) {
                p.sendMessage(formatted);
            }
        }

        // Spy: admins with permission see all clan chats
        if (plugin.getConfigManager().getBoolean("chat.spy.enabled", true)) {
            Component spyFormat = TextUtil.parse(
                    "<dark_gray>[Spy] " + format,
                    "clan_tag", clan.getFormattedTag(),
                    "clan_name", clan.getName(),
                    "player_name", sender.getName(),
                    "role_color", roleColor,
                    "role", roleName,
                    "message", MiniMessage.miniMessage().escapeTags(message));

            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.hasPermission("ethernova.admin.spy") && !clan.isMember(p.getUniqueId())) {
                    p.sendMessage(spyFormat);
                }
            }
        }
    }

    /**
     * Get MiniMessage color tag for a member's role.
     */
    private String getRoleColor(ClanMember member) {
        if (member == null) return "<gray>";
        return switch (member.getRole()) {
            case LEADER -> "<gold>";
            case CO_LEADER -> "<yellow>";
            case OFFICER -> "<aqua>";
            case MEMBER -> "<gray>";
            case RECRUIT -> "<dark_gray>";
        };
    }

    /**
     * Send a message to all allied clans.
     */
    public void sendAllianceMessage(Player sender, Clan clan, String message) {
        String format = plugin.getConfigManager().getString("chat.alliance.format",
                "<green>[Alliance]</green> {clan_tag} {player_name}<gray>:</gray> <white>{message}</white>");

        Component formatted = TextUtil.parse(format,
                "clan_tag", clan.getFormattedTag(),
                "clan_name", clan.getName(),
                "player_name", sender.getName(),
                "message", MiniMessage.miniMessage().escapeTags(message));

        // Send to own clan
        for (ClanMember m : clan.getMembers()) {
            Player p = Bukkit.getPlayer(m.getUuid());
            if (p != null) p.sendMessage(formatted);
        }

        // Send to allied clans
        for (String allyId : clan.getAllies()) {
            Clan ally = plugin.getClanManager().getClan(allyId);
            if (ally == null) continue;

            for (ClanMember m : ally.getMembers()) {
                Player p = Bukkit.getPlayer(m.getUuid());
                if (p != null) p.sendMessage(formatted);
            }
        }

        // Send to admin spy
        if (plugin.getConfigManager().getBoolean("chat.spy", true)) {
            String spyAllyFmt = plugin.getConfigManager().getRawMessage("chat.spy-ally-format");
            Component spyFormat = TextUtil.parse(spyAllyFmt,
                    "clan_tag", clan.getFormattedTag(),
                    "player_name", sender.getName(),
                    "message", net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().escapeTags(message));

            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.hasPermission("ethernova.admin.spy") && !clan.isMember(p.getUniqueId())) {
                    // Don't double-send to allied clan members
                    boolean isAllyMember = false;
                    for (String aId : clan.getAllies()) {
                        Clan a = plugin.getClanManager().getClan(aId);
                        if (a != null && a.isMember(p.getUniqueId())) {
                            isAllyMember = true;
                            break;
                        }
                    }
                    if (!isAllyMember) {
                        p.sendMessage(spyFormat);
                    }
                }
            }
        }
    }
}
