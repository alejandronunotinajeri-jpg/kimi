package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanBank;
import com.ethernova.clans.clan.ClanMember;
import com.ethernova.clans.event.ClanBankEvent;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.gui.GUIManager;
import com.ethernova.clans.mission.MissionManager;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.SoundUtil;
import com.ethernova.clans.util.TextUtil;
import com.ethernova.clans.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Bank GUI for deposits, withdrawals, payroll, and transaction history.
 */
public class BankGui extends AbstractGui {

    private int historyPage = 0;
    /** History slots: row 5, center 6 slots (44 reserved for nav arrow) */
    private static final int[] HISTORY_SLOTS = {38, 39, 40, 41, 42, 43};

    public BankGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "bank");
    }

    @Override
    protected void populateItems() {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return;
        ClanBank bank = clan.getBank();

        // Transaction history
        var transactions = bank.getRecentTransactions(50);
        int start = historyPage * HISTORY_SLOTS.length;
        int end = Math.min(start + HISTORY_SLOTS.length, transactions.size());

        for (int i = 0; i < HISTORY_SLOTS.length; i++) {
            int index = start + i;
            if (index >= end) {
                inventory.setItem(HISTORY_SLOTS[i], null);
                continue;
            }

            ClanBank.BankTransaction tx = transactions.get(index);
            Material icon = switch (tx.type()) {
                case DEPOSIT -> Material.GOLD_INGOT;
                case WITHDRAW -> Material.REDSTONE;
                case PAY_MEMBER, PAY_ALL -> Material.EMERALD;
                case TAX -> Material.GOLD_NUGGET;
                case INTEREST -> Material.DIAMOND;
                case WAR_REWARD -> Material.NETHERITE_INGOT;
                case WAR_COST, ALLIANCE_COST -> Material.IRON_INGOT;
                case ADMIN -> Material.COMMAND_BLOCK;
            };

            String color = switch (tx.type()) {
                case DEPOSIT, INTEREST, WAR_REWARD -> "<green>+";
                case WITHDRAW, WAR_COST, ALLIANCE_COST, PAY_MEMBER, PAY_ALL, TAX -> "<red>-";
                default -> "<yellow>";
            };
            setItem(HISTORY_SLOTS[i], new ItemBuilder(icon)
                    .name(color + TextUtil.formatCurrency(tx.amount()))
                    .lore(List.of(
                            "<gray>Type: <white>" + TextUtil.capitalize(tx.type().name()),
                            "<gray>Time: <white>" + TimeUtil.formatRelative(tx.timestamp().toEpochMilli()),
                            "<gray>By: <white>" + (tx.actor() != null ? resolvePlayerName(tx.actor()) : "System")
                    ))
                    .build());
        }

        // History pagination arrows
        int totalHistoryPages = Math.max(1, (int) Math.ceil((double) transactions.size() / HISTORY_SLOTS.length));

        if (historyPage > 0) {
            setItem(36, new ItemBuilder(Material.ARROW)
                    .name("<yellow>← Historial anterior")
                    .lore(List.of("<gray>Página " + historyPage + "/" + totalHistoryPages))
                    .build());
            slotActions.put(36, "HISTORY_PREV");
        }

        if (historyPage < totalHistoryPages - 1) {
            setItem(44, new ItemBuilder(Material.ARROW)
                    .name("<yellow>Historial siguiente →")
                    .lore(List.of("<gray>Página " + (historyPage + 2) + "/" + totalHistoryPages))
                    .build());
            slotActions.put(44, "HISTORY_NEXT");
        }

        if (totalHistoryPages > 1) {
            setItem(45, new ItemBuilder(Material.PAPER)
                    .name("<yellow>📜 Historial " + (historyPage + 1) + "/" + totalHistoryPages)
                    .lore(List.of("<gray>Total: <white>" + transactions.size() + " transacciones"))
                    .build());
        }
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return false;

        String upper = action.toUpperCase();

        // Handle BANK_DEPOSIT_QUICK:<amount> prefix
        if (upper.startsWith("BANK_DEPOSIT_QUICK:")) {
            try {
                double amount = Double.parseDouble(upper.substring("BANK_DEPOSIT_QUICK:".length()));
                if (amount > 0 && Double.isFinite(amount)) {
                    performDeposit(clan, amount);
                }
            } catch (NumberFormatException ignored) {
            }
            return true;
        }

        return switch (upper) {
            case "DEPOSIT", "BANK_DEPOSIT" -> {
                promptAmount("deposit");
                yield true;
            }
            case "WITHDRAW", "BANK_WITHDRAW" -> {
                promptAmount("withdraw");
                yield true;
            }
            case "DEPOSIT_ALL", "BANK_DEPOSIT_ALL" -> {
                double balance = getPlayerBalance();
                if (balance > 0) {
                    performDeposit(clan, balance);
                }
                yield true;
            }
            case "WITHDRAW_ALL", "BANK_WITHDRAW_ALL" -> {
                double bankBal = clan.getBank().getBalance();
                if (bankBal > 0) {
                    performWithdraw(clan, bankBal);
                }
                yield true;
            }
            case "BANK_PAY_ALL" -> {
                performPayAll(clan);
                yield true;
            }
            case "BANK_PAY" -> {
                promptAmount("pay");
                yield true;
            }
            case "TAX_INCREASE" -> {
                var taxMember = clan.getMember(player.getUniqueId());
                if (taxMember == null || !taxMember.getRole().isAtLeast(com.ethernova.clans.clan.ClanRole.CO_LEADER)) {
                    player.sendMessage(plugin.getConfigManager().getMessage("general.no-permission"));
                    SoundUtil.error(player);
                    yield true;
                }
                double increment = event.isShiftClick() ? 5 : 1;
                double newRate = Math.min(50, clan.getBank().getTaxRate() + increment);
                clan.getBank().setTaxRate(newRate);
                SoundUtil.success(player);
                refreshGui();
                yield true;
            }
            case "TAX_DECREASE" -> {
                var taxMember2 = clan.getMember(player.getUniqueId());
                if (taxMember2 == null || !taxMember2.getRole().isAtLeast(com.ethernova.clans.clan.ClanRole.CO_LEADER)) {
                    player.sendMessage(plugin.getConfigManager().getMessage("general.no-permission"));
                    SoundUtil.error(player);
                    yield true;
                }
                double decrement = event.isShiftClick() ? 5 : 1;
                double newRate = Math.max(0, clan.getBank().getTaxRate() - decrement);
                clan.getBank().setTaxRate(newRate);
                SoundUtil.success(player);
                refreshGui();
                yield true;
            }
            case "HISTORY_PREV" -> {
                if (historyPage > 0) {
                    historyPage--;
                    refreshGui();
                }
                yield true;
            }
            case "HISTORY_NEXT" -> {
                var txs = clan.getBank().getRecentTransactions(50);
                int totalPages = (int) Math.ceil(txs.size() / (double) HISTORY_SLOTS.length);
                if (historyPage < totalPages - 1) {
                    historyPage++;
                    refreshGui();
                }
                yield true;
            }
            default -> false;
        };
    }

    private void promptAmount(String operation) {
        player.closeInventory();
        player.sendMessage(plugin.getConfigManager().getMessage("bank.enter-amount",
                "operation", operation));

        plugin.getGuiManager().registerAnvilInput(player, input -> {
            Clan clan = plugin.getClanManager().getClanByPlayer(player);
            if (clan == null) return;

            try {
                double amount = Double.parseDouble(input.replace(",", "").replace("$", ""));
                if (amount <= 0 || !Double.isFinite(amount)) {
                    player.sendMessage(plugin.getConfigManager().getMessage("bank.invalid-amount"));
                    return;
                }

                if (operation.equals("deposit")) {
                    performDeposit(clan, amount);
                } else if (operation.equals("pay")) {
                    promptPayTarget(clan, amount);
                } else {
                    performWithdraw(clan, amount);
                }
            } catch (NumberFormatException e) {
                player.sendMessage(plugin.getConfigManager().getMessage("bank.invalid-amount"));
            }

            // Reopen bank GUI
            plugin.getServer().getScheduler().runTask(plugin, () ->
                    plugin.getGuiManager().openBank(player));
        });
    }

    private void promptPayTarget(Clan clan, double amount) {
        player.sendMessage(plugin.getConfigManager().getMessage("bank.enter-player-name"));

        plugin.getGuiManager().registerAnvilInput(player, input -> {
            Clan c = plugin.getClanManager().getClanByPlayer(player);
            if (c == null) return;

            ClanMember target = null;
            for (ClanMember m : c.getMembers()) {
                if (m.getName() != null && m.getName().equalsIgnoreCase(input.trim())) {
                    target = m;
                    break;
                }
            }

            if (target == null) {
                player.sendMessage(plugin.getConfigManager().getMessage("bank.player-not-found"));
                return;
            }

            if (target.getUuid().equals(player.getUniqueId())) {
                player.sendMessage(plugin.getConfigManager().getMessage("bank.cannot-pay-self"));
                return;
            }

            if (!c.getBank().pay(amount, player.getUniqueId(), target.getUuid())) {
                player.sendMessage(plugin.getConfigManager().getMessage("bank.insufficient-bank-funds"));
                return;
            }

            OfflinePlayer targetPlayer = Bukkit.getOfflinePlayer(target.getUuid());
            if (plugin.getVaultHook() != null) {
                plugin.getVaultHook().deposit(targetPlayer, amount);
            }

            player.sendMessage(plugin.getConfigManager().getMessage("bank.paid-member",
                    "amount", TextUtil.formatCurrency(amount),
                    "player", targetPlayer.getName() != null ? targetPlayer.getName() : "Unknown"));
            SoundUtil.success(player);

            plugin.getServer().getScheduler().runTask(plugin, () ->
                    plugin.getGuiManager().openBank(player));
        });
    }

    private void performDeposit(Clan clan, double amount) {
        // Check min deposit
        double minAmount = plugin.getConfigManager().getDouble("bank.deposit.min-amount", 10.0);
        if (amount < minAmount) {
            player.sendMessage(plugin.getConfigManager().getMessage("bank.min-deposit",
                    "min", TextUtil.formatCurrency(minAmount)));
            return;
        }
        // Check deposit limits
        double maxDeposit = plugin.getConfigManager().getDouble("bank.deposit.max-amount", 50000);
        if (amount > maxDeposit) {
            player.sendMessage(plugin.getConfigManager().getMessage("bank.max-deposit",
                    "max", TextUtil.formatCurrency(maxDeposit)));
            return;
        }

        double maxBalance = plugin.getConfigManager().getDouble(
                "bank.max-balance-per-level." + clan.getLevel(), 50000);
        if (clan.getBank().getBalance() + amount > maxBalance) {
            player.sendMessage(plugin.getConfigManager().getMessage("bank.max-balance",
                    "max", TextUtil.formatCurrency(maxBalance)));
            return;
        }

        // Check player has money
        if (!withdrawFromPlayer(amount)) {
            player.sendMessage(plugin.getConfigManager().getMessage("bank.insufficient-funds"));
            return;
        }

        double actual = clan.getBank().deposit(amount, maxBalance, player.getUniqueId());
        // If bank couldn't accept the full amount (race condition), refund the difference
        if (actual < amount) {
            double refund = amount - actual;
            depositToPlayer(refund);
        }
        if (actual <= 0) {
            depositToPlayer(amount); // Refund entirely
            player.sendMessage(plugin.getConfigManager().getMessage("bank.max-balance",
                    "max", TextUtil.formatCurrency(maxBalance)));
            return;
        }
        player.sendMessage(plugin.getConfigManager().getMessage("bank.deposited",
                "amount", TextUtil.formatCurrency(actual),
                "balance", TextUtil.formatCurrency(clan.getBank().getBalance())));
        SoundUtil.success(player);

        // Mission progress - deposits (track dollar amount)
        if (plugin.getMissionManager() != null) {
            plugin.getMissionManager().updateProgress(clan,
                    com.ethernova.clans.mission.MissionManager.MissionType.DEPOSITS, (int) amount);
        }
        // Fire bank event for achievements
        Bukkit.getPluginManager().callEvent(
                new com.ethernova.clans.event.ClanBankEvent(clan, player, amount,
                        com.ethernova.clans.event.ClanBankEvent.BankAction.DEPOSIT));
    }

    private void performWithdraw(Clan clan, double amount) {
        // Check permissions
        if (!plugin.getClanManager().hasPermission(clan, player.getUniqueId(), "bank-withdraw")) {
            player.sendMessage(plugin.getConfigManager().getMessage("general.no-permission"));
            return;
        }

        double minAmount = plugin.getConfigManager().getDouble("bank.withdraw.min-amount", 10.0);
        if (amount < minAmount) {
            player.sendMessage(plugin.getConfigManager().getMessage("bank.min-withdraw",
                    "min", TextUtil.formatCurrency(minAmount)));
            return;
        }

        double maxWithdraw = plugin.getConfigManager().getDouble("bank.withdraw.max-amount", 50000);
        if (amount > maxWithdraw) {
            player.sendMessage(plugin.getConfigManager().getMessage("bank.max-withdraw",
                    "max", TextUtil.formatCurrency(maxWithdraw)));
            return;
        }

        // Atomic withdraw — use actual amount returned (guards against race conditions)
        double actual = clan.getBank().withdraw(amount, player.getUniqueId());
        if (actual <= 0) {
            player.sendMessage(plugin.getConfigManager().getMessage("bank.insufficient-bank-funds"));
            return;
        }

        depositToPlayer(actual);
        player.sendMessage(plugin.getConfigManager().getMessage("bank.withdrawn",
                "amount", TextUtil.formatCurrency(actual),
                "balance", TextUtil.formatCurrency(clan.getBank().getBalance())));
        SoundUtil.success(player);

        // Fire bank event for achievements
        Bukkit.getPluginManager().callEvent(
                new com.ethernova.clans.event.ClanBankEvent(clan, player, actual,
                        com.ethernova.clans.event.ClanBankEvent.BankAction.WITHDRAW));
    }

    private double getPlayerBalance() {
        if (plugin.getVaultHook() != null) {
            return plugin.getVaultHook().getBalance(player);
        }
        return 0;
    }

    private boolean withdrawFromPlayer(double amount) {
        if (plugin.getVaultHook() != null) {
            return plugin.getVaultHook().withdraw(player, amount);
        }
        return false;
    }

    private void depositToPlayer(double amount) {
        if (plugin.getVaultHook() != null) {
            plugin.getVaultHook().deposit(player, amount);
        }
    }

    private void performPayAll(Clan clan) {
        if (!plugin.getClanManager().hasPermission(clan, player.getUniqueId(), "bank-pay")) {
            player.sendMessage(plugin.getConfigManager().getMessage("general.no-permission"));
            return;
        }

        var members = clan.getMembers();
        if (members.isEmpty()) return;

        double perMember = Math.floor(clan.getBank().getBalance() / members.size() * 100) / 100.0;
        if (perMember <= 0) {
            player.sendMessage(plugin.getConfigManager().getMessage("bank.insufficient-bank-funds"));
            return;
        }

        // Withdraw total needed atomically first to prevent race conditions
        double totalNeeded = perMember * members.size();
        double actualWithdrawn = clan.getBank().withdraw(totalNeeded, player.getUniqueId());
        if (actualWithdrawn <= 0) {
            player.sendMessage(plugin.getConfigManager().getMessage("bank.insufficient-bank-funds"));
            return;
        }

        // Recalculate per-member based on actual withdrawn amount
        perMember = Math.floor(actualWithdrawn / members.size() * 100) / 100.0;

        int paid = 0;
        for (ClanMember member : members) {
            OfflinePlayer target = Bukkit.getOfflinePlayer(member.getUuid());
            if (plugin.getVaultHook() != null) {
                plugin.getVaultHook().deposit(target, perMember);
            }
            paid++;
        }

        // Log transactions for each payment
        // (Note: the single withdraw was already logged; individual pay records are implicit)

        // Refund any remainder due to rounding
        double totalPaid = perMember * paid;
        double remainder = actualWithdrawn - totalPaid;
        if (remainder > 0.01) {
            clan.getBank().deposit(remainder, Double.MAX_VALUE, player.getUniqueId());
        }

        player.sendMessage(plugin.getConfigManager().getMessage("bank.paid-all",
                "amount", TextUtil.formatCurrency(perMember),
                "count", String.valueOf(paid),
                "balance", TextUtil.formatCurrency(clan.getBank().getBalance())));
        SoundUtil.success(player);
        refreshGui();
    }

    private void refreshGui() {
        occupiedSlots.clear();
        slotActions.clear();
        rightClickActions.clear();
        slotConfigs.clear();
        fillBackground();
        placeConfigItems();
        populateItems();
    }

    private String resolvePlayerName(UUID uuid) {
        OfflinePlayer op = Bukkit.getOfflinePlayer(uuid);
        String name = op.getName();
        return name != null ? name : uuid.toString().substring(0, 8);
    }
}
