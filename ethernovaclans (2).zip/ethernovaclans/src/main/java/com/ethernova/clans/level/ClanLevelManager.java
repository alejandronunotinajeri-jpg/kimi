package com.ethernova.clans.level;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ClanLevelManager {

    private final EthernovaClans plugin;
    private final Map<String, Long> xpMap = new ConcurrentHashMap<>();

    /** Level data record for AbstractGui placeholder replacement. */
    public record LevelData(String name, int powerRequired, int maxMembers, int maxClaims, int maxAllies) {}

    public ClanLevelManager(EthernovaClans plugin) {
        this.plugin = plugin;
    }

    // ── Level Data Lookups ───────────────────────────────────

    public int getMaxLevel() {
        return plugin.getConfigManager().getConfig().getInt("levels.max-level", 10);
    }

    public LevelData getLevelData(int level) {
        var config = plugin.getConfigManager().getConfig();
        String name = config.getString("levels.names." + level, "Nivel " + level);
        int power = config.getInt("levels.power-required." + level, level * 100);
        int members = config.getInt("levels.max-members." + level, 10 + level * 2);
        int claims = config.getInt("levels.max-claims." + level, 5 + level * 3);
        int allies = config.getInt("levels.max-allies." + level, 2 + level);
        return new LevelData(name, power, members, claims, allies);
    }

    public String getLevelName(int level) {
        return plugin.getConfigManager().getConfig().getString("levels.names." + level, "Nivel " + level);
    }

    public int getMaxMembers(int level) {
        return plugin.getConfigManager().getConfig().getInt("levels.max-members." + level, 10 + level * 2);
    }

    /**
     * Get max members including skill bonus for a specific clan.
     */
    public int getMaxMembersWithSkill(String clanId) {
        int base = getMaxMembers(getLevel(clanId));
        int skillBonus = (plugin.getSkillManager() != null)
                ? (int) plugin.getSkillManager().getSkillValue(clanId, "recruitment") : 0;
        return base + skillBonus;
    }

    public int getMaxClaims(int level) {
        return plugin.getConfigManager().getConfig().getInt("levels.max-claims." + level, 5 + level * 3);
    }

    public int getMaxAllies(int level) {
        return plugin.getConfigManager().getConfig().getInt("levels.max-allies." + level, 2 + level);
    }

    public long getXP(String clanId) {
        return xpMap.getOrDefault(clanId, 0L);
    }

    public int getLevel(String clanId) {
        long xp = getXP(clanId);
        double base = plugin.getConfigManager().getConfig().getDouble("levels.base-xp", 1000);
        double mult = plugin.getConfigManager().getConfig().getDouble("levels.xp-multiplier", 1.5);
        int level = 0;
        long required = (long) base;
        while (xp >= required) {
            xp -= required;
            level++;
            required = (long) (base * Math.pow(mult, level));
        }
        return level;
    }

    public long getXPForNextLevel(String clanId) {
        int level = getLevel(clanId);
        double base = plugin.getConfigManager().getConfig().getDouble("levels.base-xp", 1000);
        double mult = plugin.getConfigManager().getConfig().getDouble("levels.xp-multiplier", 1.5);
        return (long) (base * Math.pow(mult, level));
    }

    public long getCurrentLevelXP(String clanId) {
        long totalXP = getXP(clanId);
        double base = plugin.getConfigManager().getConfig().getDouble("levels.base-xp", 1000);
        double mult = plugin.getConfigManager().getConfig().getDouble("levels.xp-multiplier", 1.5);
        int level = 0;
        long required = (long) base;
        while (totalXP >= required) {
            totalXP -= required;
            level++;
            required = (long) (base * Math.pow(mult, level));
        }
        return totalXP;
    }

    public double getLevelProgress(String clanId) {
        long current = getCurrentLevelXP(clanId);
        long needed = getXPForNextLevel(clanId);
        return needed > 0 ? (double) current / needed : 1.0;
    }

    public void addXP(String clanId, long amount) {
        long oldLevel = getLevel(clanId);
        xpMap.merge(clanId, amount, Long::sum);
        long newLevel = getLevel(clanId);

        // Fire onLevelUp for EACH intermediate level, not just the final one
        if (newLevel > oldLevel) {
            for (long lvl = oldLevel + 1; lvl <= newLevel; lvl++) {
                onLevelUp(clanId, (int) lvl);
            }
        }
    }

    /**
     * Award XP for common actions.
     */
    public void onKill(String clanId) {
        addXP(clanId, plugin.getConfigManager().getConfig().getLong("levels.xp-per-kill", 50));
    }

    public void onClaim(String clanId) {
        addXP(clanId, plugin.getConfigManager().getConfig().getLong("levels.xp-per-claim", 25));
    }

    public void onWarWin(String clanId) {
        addXP(clanId, plugin.getConfigManager().getConfig().getLong("levels.xp-per-war-win", 500));
    }

    public void onAllyFormed(String clanId) {
        addXP(clanId, plugin.getConfigManager().getConfig().getLong("levels.xp-per-ally", 100));
    }

    public void onMemberJoin(String clanId) {
        addXP(clanId, plugin.getConfigManager().getConfig().getLong("levels.xp-per-member", 30));
    }

    private void onLevelUp(String clanId, int newLevel) {
        Clan clan = plugin.getClanManager().getClan(clanId);
        if (clan == null) return;

        // Sync the Clan object's level field so getLevel() returns the correct value
        clan.setLevel(newLevel);

        for (Player m : plugin.getClanManager().getOnlineMembers(clan)) {
            plugin.getMessageManager().sendMessage(m, "level.up",
                    "{level}", String.valueOf(newLevel), "{clan}", clan.getDisplayName());
            if (plugin.getCoreHook().isAvailable()) {
                plugin.getCoreHook().sendTitle(m,
                        "<gold><bold>⬆ Nivel " + newLevel + "</bold></gold>",
                        "<yellow>" + clan.getDisplayName() + "</yellow>");
            }
        }

        // Level perks
        var config = plugin.getConfigManager().getConfig();
        var sec = config.getConfigurationSection("levels.perks." + newLevel);
        if (sec != null) {
            int extraMembers = sec.getInt("extra-members", 0);
            double extraPower = sec.getDouble("extra-max-power", 0);
            int extraClaims = sec.getInt("extra-claims", 0);

            // These are applied via getLevel checks in PowerManager/UpgradeManager
            plugin.getLogger().info("Clan " + clan.getName() + " reached level " + newLevel +
                    " — perks applied: +" + extraMembers + " members, +" + extraPower + " power, +" + extraClaims + " claims");
        }

        // Discord notification
        if (plugin.getDiscordWebhook() != null) plugin.getDiscordWebhook().sendLevelUp(clan, newLevel);
    }

    public int getMaxMembersBonus(String clanId) {
        int level = getLevel(clanId);
        int bonus = 0;
        var config = plugin.getConfigManager().getConfig();
        for (int i = 1; i <= level; i++) {
            bonus += config.getInt("levels.perks." + i + ".extra-members", 0);
        }
        return bonus;
    }

    public int getExtraClaimsBonus(String clanId) {
        int level = getLevel(clanId);
        int bonus = 0;
        var config = plugin.getConfigManager().getConfig();
        for (int i = 1; i <= level; i++) {
            bonus += config.getInt("levels.perks." + i + ".extra-claims", 0);
        }
        return bonus;
    }

    // Persistence
    public void loadXP(String clanId, long xp) { xpMap.put(clanId, xp); }
    public Map<String, Long> getAllXP() { return Map.copyOf(xpMap); }
    public void removeXP(String clanId) { xpMap.remove(clanId); }

    /** Admin: set a clan's level directly. Updates both the Clan object and the XP map. */
    public void setLevel(Clan clan, int level) {
        clan.setLevel(level);
        // Calculate total XP required to reach this level and set it in xpMap
        double base = plugin.getConfigManager().getConfig().getDouble("levels.base-xp", 1000);
        double mult = plugin.getConfigManager().getConfig().getDouble("levels.xp-multiplier", 1.5);
        long totalXP = 0;
        for (int i = 0; i < level; i++) {
            totalXP += (long) (base * Math.pow(mult, i));
        }
        xpMap.put(clan.getId(), totalXP);
    }

    /** Reload level configuration (levels are read dynamically from config). */
    public void loadLevels() {
        // Level data is read dynamically from config, no preload needed
    }

    private static final String BOOST_TAG = "ethernova_clan_boost";

    /** Apply level-based boosts (potions, etc.) to a player based on their clan's level. */
    public void applyBoosts(Player player, Clan clan) {
        if (player == null || clan == null) return;
        int level = getLevel(clan.getId());
        var config = plugin.getConfigManager().getConfig();

        // Iterate through all perk tiers up to the clan's current level
        for (int tier = 1; tier <= level; tier++) {
            ConfigurationSection boosts = config.getConfigurationSection("levels.perks." + tier + ".boosts");
            if (boosts == null) continue;
            for (String effectName : boosts.getKeys(false)) {
                int amplifier = boosts.getInt(effectName, 0);
                PotionEffectType type = PotionEffectType.getByName(effectName.toUpperCase());
                if (type == null) {
                    plugin.getLogger().warning("[Levels] Unknown potion effect: " + effectName);
                    continue;
                }
                // Apply infinite duration effect, overwriting weaker ones
                PotionEffect existing = player.getPotionEffect(type);
                if (existing == null || existing.getAmplifier() < amplifier) {
                    player.addPotionEffect(new PotionEffect(type, PotionEffect.INFINITE_DURATION, amplifier, true, false, true));
                }
            }
        }
    }

    /** Remove level-based boosts from a player. */
    public void removeBoosts(Player player, Clan clan) {
        if (player == null || clan == null) return;
        int level = getLevel(clan.getId());
        var config = plugin.getConfigManager().getConfig();

        for (int tier = 1; tier <= level; tier++) {
            ConfigurationSection boosts = config.getConfigurationSection("levels.perks." + tier + ".boosts");
            if (boosts == null) continue;
            for (String effectName : boosts.getKeys(false)) {
                PotionEffectType type = PotionEffectType.getByName(effectName.toUpperCase());
                if (type != null) {
                    player.removePotionEffect(type);
                }
            }
        }
    }
}
