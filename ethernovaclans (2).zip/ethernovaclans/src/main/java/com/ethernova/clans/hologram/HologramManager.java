package com.ethernova.clans.hologram;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import org.bukkit.Bukkit;
import org.bukkit.Location;

import java.util.*;

public class HologramManager {

    private final EthernovaClans plugin;
    private final boolean available;
    private final Set<String> ids = new HashSet<>();

    public HologramManager(EthernovaClans plugin) {
        this.plugin = plugin;
        this.available = Bukkit.getPluginManager().getPlugin("DecentHolograms") != null;
    }

    public void createBaseHologram(Clan clan, Location location) {
        if (!available) return;
        try {
            String id = "clan_" + clan.getId();
            eu.decentsoftware.holograms.api.DHAPI.createHologram(id, location, false,
                    List.of("&6&l⚑ " + clan.getName(), "&7Miembros: &f" + clan.getMembers().size()));
            ids.add(id);
        } catch (Exception ignored) {}
    }

    public void updateAll() {
        // Update existing holograms
    }

    public void removeHologram(String clanId) {
        if (!available) return;
        try { eu.decentsoftware.holograms.api.DHAPI.removeHologram("clan_" + clanId); } catch (Exception ignored) {}
        ids.remove("clan_" + clanId);
    }

    public void removeAllHolograms() {
        if (!available) return;
        for (String id : ids) {
            try { eu.decentsoftware.holograms.api.DHAPI.removeHologram(id); } catch (Exception ignored) {}
        }
        ids.clear();
    }
}
