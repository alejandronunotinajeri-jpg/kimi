package com.ethernova.clans.command.sub;

import com.ethernova.clans.EthernovaClans;
import org.bukkit.entity.Player;

import java.util.List;

/**
 * Interface for modular clan subcommands.
 * Each subcommand handler implements this interface.
 */
public interface SubCommand {

    /**
     * Get the name of this subcommand (primary name used in switch).
     */
    String getName();

    /**
     * Get alternative aliases for this subcommand.
     */
    default List<String> getAliases() {
        return List.of();
    }

    /**
     * Get the permission required to use this subcommand.
     * Return null if no specific permission is needed.
     */
    default String getPermission() {
        return null;
    }

    /**
     * Get a brief description of this subcommand for help text.
     */
    String getDescription();

    /**
     * Get the usage format (e.g., "/clan create <nombre> <tag>").
     */
    String getUsage();

    /**
     * Whether this subcommand requires the player to be in a clan.
     */
    default boolean requiresClan() {
        return true;
    }

    /**
     * Execute the subcommand.
     * @param plugin the plugin instance
     * @param player the player executing the command
     * @param args all command arguments (including the subcommand name at args[0])
     */
    void execute(EthernovaClans plugin, Player player, String[] args);

    /**
     * Provide tab completions for this subcommand.
     * @param plugin the plugin instance
     * @param player the player typing the command
     * @param args all command arguments
     * @return list of suggestions, or empty list
     */
    default List<String> tabComplete(EthernovaClans plugin, Player player, String[] args) {
        return List.of();
    }
}
