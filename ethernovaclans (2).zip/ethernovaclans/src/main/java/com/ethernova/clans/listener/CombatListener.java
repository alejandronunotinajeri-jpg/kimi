package com.ethernova.clans.listener;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.mission.MissionManager;
import org.bukkit.entity.Player;
import org.bukkit.entity.Tameable;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Handles PvP kills and deaths for power, KD, war scoring, and anti-abuse.
 * Also cancels friendly fire damage between clan members.
 */
public class CombatListener implements Listener {

    private final EthernovaClans plugin;

    /** Kill cooldown for war scoring & missions (prevents kill farming) */
    private final Map<String, Long> killCooldowns = new ConcurrentHashMap<>();
    private static final long KILL_COOLDOWN_MS = 5 * 60 * 1000; // 5 minutes

    public CombatListener(EthernovaClans plugin) {
        this.plugin = plugin;
        // Periodically purge expired cooldowns to prevent unbounded growth
        org.bukkit.Bukkit.getScheduler().runTaskTimerAsynchronously(plugin,
                () -> killCooldowns.values().removeIf(v -> System.currentTimeMillis() >= v),
                20L * 60 * 10, 20L * 60 * 10); // every 10 minutes
    }

    // ══════════════════════════════════════════════════════════
    //  FRIENDLY FIRE PROTECTION
    // ══════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        // Skip friendly fire protection in non-territory modes (e.g. FFA, PRACTICE)
        if (!plugin.getCoreHook().hasTerritory()) return;
        if (!(event.getEntity() instanceof Player victim)) return;

        // Resolve damager (direct, projectile, or tamed entity)
        Player attacker = null;
        if (event.getDamager() instanceof Player p) {
            attacker = p;
        } else if (event.getDamager() instanceof org.bukkit.entity.Projectile proj
                && proj.getShooter() instanceof Player p) {
            attacker = p;
        } else if (event.getDamager() instanceof Tameable tameable
                && tameable.isTamed() && tameable.getOwner() instanceof Player p) {
            attacker = p;
        }
        if (attacker == null || attacker.equals(victim)) return;

        Clan attackerClan = plugin.getClanManager().getClanByPlayer(attacker);
        Clan victimClan = plugin.getClanManager().getClanByPlayer(victim);

        if (attackerClan == null || victimClan == null) return;

        // Same clan — check friendly fire setting
        if (attackerClan.getId().equals(victimClan.getId())) {
            if (!attackerClan.isFriendlyFire()) {
                event.setCancelled(true);
                return;
            }
        }

        // Allied clans — block PvP if configured
        if (attackerClan.isAlly(victimClan.getId())) {
            if (plugin.getConfigManager().getBoolean("alliances.benefits.pvp-off", true)) {
                // Only block if not at war with each other
                boolean atWar = plugin.getWarManager() != null &&
                        plugin.getWarManager().isAtWar(attackerClan, victimClan);
                if (!atWar) {
                    event.setCancelled(true);
                }
            }
        }
    }

    // ══════════════════════════════════════════════════════════
    //  PVP KILL / DEATH PROCESSING
    // ══════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        // Only process PvP kills
        if (killer == null || killer.equals(victim)) return;

        Clan killerClan = plugin.getClanManager().getClanByPlayer(killer);
        Clan victimClan = plugin.getClanManager().getClanByPlayer(victim);

        // Both must be in a clan for power changes (prevents free power from clanless victims)
        if (killerClan == null || victimClan == null) return;

        // Check if clans are at war
        boolean isWar = false;
        if (plugin.getWarManager() != null) {
            isWar = plugin.getWarManager().isAtWar(killerClan, victimClan);
        }

        // Same clan — no power exchange
        if (killerClan.getId().equals(victimClan.getId())) {
            return;
        }

        // Allied clans — no power exchange unless in war
        if (killerClan.isAlly(victimClan.getId())) {
            if (!isWar) return;
        }

        // Anti-abuse: cooldown gates ALL rewards (power, K/D stats, war scoring, missions)
        // Use bidirectional key to prevent A↔B alternating kill farming
        String pair = killerClan.getId().compareTo(victimClan.getId()) < 0
                ? killer.getUniqueId() + ":" + victim.getUniqueId()
                : victim.getUniqueId() + ":" + killer.getUniqueId();
        String cdKey = pair;
        Long expiry = killCooldowns.get(cdKey);
        boolean onCooldown = expiry != null && System.currentTimeMillis() < expiry;
        if (onCooldown) {
            // On cooldown — skip ALL rewards; only clean up fly state
            if (plugin.getFlyManager() != null) {
                if (victim.getGameMode() == org.bukkit.GameMode.SURVIVAL
                        || victim.getGameMode() == org.bukkit.GameMode.ADVENTURE) {
                    plugin.getFlyManager().disableFly(victim);
                }
            }
            return;
        }
        killCooldowns.put(cdKey, System.currentTimeMillis() + KILL_COOLDOWN_MS);

        // Process kill for killer's clan
        plugin.getPowerManager().onKill(killer.getUniqueId());
        plugin.getLevelManager().onKill(killerClan.getId());
        killerClan.addKill();
        if (plugin.getMissionManager() != null) {
            plugin.getMissionManager().updateProgress(killerClan,
                    MissionManager.MissionType.KILLS, 1);
        }

        // Process death for victim's clan
        plugin.getPowerManager().onDeath(victim.getUniqueId());
        victimClan.addDeath();
        if (plugin.getMissionManager() != null) {
            plugin.getMissionManager().updateProgress(victimClan,
                    MissionManager.MissionType.DEATHS, 1);
        }

        // Clean up fly state on death
        if (plugin.getFlyManager() != null) {
            // Only disable fly for survival/adventure mode (not creative/spectator)
            if (victim.getGameMode() == org.bukkit.GameMode.SURVIVAL
                    || victim.getGameMode() == org.bukkit.GameMode.ADVENTURE) {
                plugin.getFlyManager().disableFly(victim);
            }
        }

        // War scoring (cooldown already checked above — if we reach here, it's valid)
        if (isWar) {
            plugin.getWarManager().handleKill(killer.getUniqueId(), victim.getUniqueId(), "pvp");
        }
    }
}
