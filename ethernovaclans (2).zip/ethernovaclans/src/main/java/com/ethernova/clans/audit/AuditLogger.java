package com.ethernova.clans.audit;

import com.ethernova.clans.EthernovaClans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class AuditLogger {

    private final EthernovaClans plugin;

    public AuditLogger(EthernovaClans plugin) {
        this.plugin = plugin;
        createTable();
    }

    private void createTable() {
        try (Connection conn = plugin.getStorageManager().getConnection();
             java.sql.Statement stmt = conn.createStatement()) {
            boolean mysql = plugin.getStorageManager().isMySQL();
            String autoInc = mysql ? "AUTO_INCREMENT" : "AUTOINCREMENT";
            String idType = mysql ? "INT" : "INTEGER";
            stmt.executeUpdate(
                "CREATE TABLE IF NOT EXISTS clan_audit_log (" +
                    "id " + idType + " PRIMARY KEY " + autoInc + "," +
                    "clan_id VARCHAR(8) NOT NULL," +
                    "player_uuid VARCHAR(36)," +
                    "player_name VARCHAR(16)," +
                    "action VARCHAR(32) NOT NULL," +
                    "details TEXT," +
                    "timestamp BIGINT NOT NULL" +
                ")"
            );
        } catch (Exception e) {
            plugin.getLogger().log(java.util.logging.Level.WARNING, "Failed to create audit table", e);
        }
    }

    public void log(String clanId, UUID playerUuid, String playerName, AuditAction action, String details) {
        org.bukkit.Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (Connection conn = plugin.getStorageManager().getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "INSERT INTO clan_audit_log (clan_id, player_uuid, player_name, action, details, timestamp) VALUES (?, ?, ?, ?, ?, ?)")) {
                ps.setString(1, clanId);
                ps.setString(2, playerUuid != null ? playerUuid.toString() : null);
                ps.setString(3, playerName);
                ps.setString(4, action.name());
                ps.setString(5, details);
                ps.setLong(6, System.currentTimeMillis());
                ps.executeUpdate();
            } catch (Exception e) {
                plugin.getLogger().log(java.util.logging.Level.WARNING, "Audit log error", e);
            }
        });
    }

    public List<String> getRecentLogs(String clanId, int limit) {
        List<String> logs = new ArrayList<>();
        try (Connection conn = plugin.getStorageManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT * FROM clan_audit_log WHERE clan_id = ? ORDER BY timestamp DESC LIMIT ?")) {
            ps.setString(1, clanId);
            ps.setInt(2, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    long time = rs.getLong("timestamp");
                    String timeStr = formatTime(System.currentTimeMillis() - time);
                    String player = rs.getString("player_name");
                    String action = rs.getString("action");
                    String details = rs.getString("details");
                    logs.add("<gray>" + timeStr + "</gray> <yellow>" + (player != null ? player : "Sistema") +
                            "</yellow> <white>" + action + "</white>" +
                            (details != null && !details.isBlank() ? " <dark_gray>(" + details + ")</dark_gray>" : ""));
                }
            }
        } catch (Exception e) {
            plugin.getLogger().log(java.util.logging.Level.WARNING, "Audit read error", e);
        }
        return logs;
    }

    /**
     * Async version of getRecentLogs — runs SQL off main thread, delivers results on main thread.
     */
    public void getRecentLogsAsync(String clanId, int limit, java.util.function.Consumer<List<String>> callback) {
        org.bukkit.Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            List<String> logs = getRecentLogs(clanId, limit);
            org.bukkit.Bukkit.getScheduler().runTask(plugin, () -> callback.accept(logs));
        });
    }

    private String formatTime(long ms) {
        long s = ms / 1000;
        if (s < 60) return s + "s";
        if (s < 3600) return (s / 60) + "m";
        if (s < 86400) return (s / 3600) + "h";
        return (s / 86400) + "d";
    }

    public Connection getConnection() throws Exception {
        return plugin.getStorageManager().getConnection();
    }
}
