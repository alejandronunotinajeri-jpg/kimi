package com.ethernova.clans.event;

import com.ethernova.clans.clan.Clan;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

/**
 * Fired when a player is invited to a clan.
 * Cancellable to prevent the invitation.
 */
public class ClanInviteEvent extends Event implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();
    private boolean cancelled = false;

    private final Clan clan;
    private final Player inviter;
    private final Player invited;

    public ClanInviteEvent(@NotNull Clan clan, @NotNull Player inviter, @NotNull Player invited) {
        this.clan = clan;
        this.inviter = inviter;
        this.invited = invited;
    }

    public @NotNull Clan getClan() { return clan; }
    public @NotNull Player getInviter() { return inviter; }
    public @NotNull Player getInvited() { return invited; }

    @Override public boolean isCancelled() { return cancelled; }
    @Override public void setCancelled(boolean cancel) { this.cancelled = cancel; }
    @Override public @NotNull HandlerList getHandlers() { return HANDLERS; }
    public static HandlerList getHandlerList() { return HANDLERS; }
}
