package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanRole;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.SoundUtil;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * GUI showing clan warps with teleport on click and management options.
 */
public class WarpsGui extends AbstractGui {

    private final List<String> warpNames = new ArrayList<>();

    public WarpsGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "warps");
    }

    @Override
    protected int getMinimumSize() {
        return 27;
    }

    @Override
    protected void populateItems() {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return;

        Map<String, Location> warps = clan.getWarps();
        int maxWarps = plugin.getUpgradeManager() != null
                ? plugin.getUpgradeManager().getMaxWarps(clan)
                : 3;

        // Header
        setItem(4, new ItemBuilder(Material.ENDER_PEARL)
                .name("<gradient:#A855F7:#6366F1>\u2728 Clan Warps</gradient>")
                .lore(List.of(
                        "",
                        "<gray>Warps: <yellow>" + warps.size() + "</yellow><dark_gray>/</dark_gray><gray>" + maxWarps + "</gray>",
                        "",
                        "<gray>Click en un warp para teleportarte.",
                        "<red>Click derecho para eliminar (Oficiales+).</red>"
                ))
                .glow()
                .build());

        // Warp items
        warpNames.clear();
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};
        int i = 0;

        for (var entry : warps.entrySet()) {
            if (i >= slots.length) break;
            String name = entry.getKey();
            Location loc = entry.getValue();
            warpNames.add(name);

            String world = loc.getWorld() != null ? loc.getWorld().getName() : "unknown";

            setItem(slots[i], new ItemBuilder(Material.ENDER_EYE)
                    .name("<light_purple>\u2726 " + name)
                    .lore(List.of(
                            "",
                            "<gray>Mundo: <white>" + world,
                            "<gray>Coords: <white>" + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ(),
                            "",
                            "<green>\u25b6 Click izquierdo = Teleportarse",
                            "<red>\u25b6 Click derecho = Eliminar"
                    ))
                    .build());
            i++;
        }

        // Empty slots placeholder
        for (int j = i; j < Math.min(maxWarps, slots.length); j++) {
            setItem(slots[j], new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE)
                    .name("<dark_gray>Warp vac\u00edo")
                    .lore(List.of("", "<gray>Usa <yellow>/clan setwarp <nombre></yellow>", "<gray>para crear un nuevo warp."))
                    .build());
        }

        // Back button (slot 18 — left corner of last row, avoids warp slot conflict)
        setItem(18, new ItemBuilder(Material.ARROW)
                .name("<gray>\u25c0 Volver al men\u00fa")
                .build());
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        return false;
    }

    @Override
    protected void onClick(int slot, InventoryClickEvent event) {
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};
        for (int i = 0; i < slots.length; i++) {
            if (slots[i] == slot && i < warpNames.size()) {
                String warpName = warpNames.get(i);
                Clan clan = plugin.getClanManager().getClanByPlayer(player);
                if (clan == null) return;

                if (event.isRightClick()) {
                    // Delete warp — require officer+
                    var member = clan.getMember(player.getUniqueId());
                    if (member == null || !member.getRole().isAtLeast(ClanRole.OFFICER)) {
                        plugin.getMessageManager().sendMessage(player, "error.no-permission");
                        SoundUtil.error(player);
                        return;
                    }
                    if (clan.removeWarp(warpName)) {
                        plugin.getClanManager().saveClan(clan);
                        plugin.getMessageManager().sendMessage(player, "warp.deleted", "{name}", warpName);
                        SoundUtil.success(player);
                        // Refresh
                        plugin.getServer().getScheduler().runTask(plugin, () -> {
                            occupiedSlots.clear();
                            slotActions.clear();
                            rightClickActions.clear();
                            slotConfigs.clear();
                            fillBackground();
                            placeConfigItems();
                            populateItems();
                        });
                    }
                } else {
                    // Teleport
                    Location loc = clan.getWarp(warpName);
                    if (loc == null) {
                        plugin.getMessageManager().sendMessage(player, "warp.not-found");
                        SoundUtil.error(player);
                        return;
                    }
                    player.closeInventory();
                    if (plugin.getTeleportManager() != null) {
                        plugin.getTeleportManager().teleportWithWarmup(player, loc, "warp.teleported");
                    } else {
                        player.teleport(loc);
                    }
                }
                return;
            }
        }

        // Back button
        if (slot == 18) {
            plugin.getServer().getScheduler().runTask(plugin, () ->
                    plugin.getGuiManager().openMainMenu(player));
        }
    }
}
