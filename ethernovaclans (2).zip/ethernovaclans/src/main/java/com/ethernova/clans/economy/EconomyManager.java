package com.ethernova.clans.economy;

import com.ethernova.clans.EthernovaClans;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

public class EconomyManager {

    private volatile Economy economy;
    private volatile boolean enabled;
    private volatile boolean initialized;

    public EconomyManager(EthernovaClans plugin) {
        tryInit();
    }

    private void tryInit() {
        if (initialized) return;
        if (Bukkit.getPluginManager().getPlugin("Vault") != null) {
            RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
            if (rsp != null) { economy = rsp.getProvider(); enabled = true; initialized = true; }
        }
    }

    private void ensureInit() { if (!initialized) tryInit(); }

    public boolean isEnabled() { ensureInit(); return enabled; }
    public double getBalance(Player p) { ensureInit(); return enabled ? economy.getBalance(p) : 0; }
    public boolean has(Player p, double amount) { ensureInit(); return enabled && economy.has(p, amount); }
    public boolean withdraw(Player p, double amount) { ensureInit(); if (amount <= 0 || !Double.isFinite(amount)) return false; return enabled && economy.withdrawPlayer(p, amount).transactionSuccess(); }
    public boolean deposit(Player p, double amount) { ensureInit(); if (amount <= 0 || !Double.isFinite(amount)) return false; return enabled && economy.depositPlayer(p, amount).transactionSuccess(); }

    /** Overload: deposit for OfflinePlayer. */
    public boolean deposit(org.bukkit.OfflinePlayer p, double amount) { ensureInit(); if (amount <= 0 || !Double.isFinite(amount)) return false; return enabled && economy.depositPlayer(p, amount).transactionSuccess(); }

    /** Overload: withdraw for OfflinePlayer. */
    public boolean withdraw(org.bukkit.OfflinePlayer p, double amount) { ensureInit(); if (amount <= 0 || !Double.isFinite(amount)) return false; return enabled && economy.withdrawPlayer(p, amount).transactionSuccess(); }

    /** Overload: getBalance for OfflinePlayer. */
    public double getBalance(org.bukkit.OfflinePlayer p) { ensureInit(); return enabled ? economy.getBalance(p) : 0; }

    public String format(double amount) { ensureInit(); return enabled ? economy.format(amount) : "$" + String.format("%.2f", amount); }
}
