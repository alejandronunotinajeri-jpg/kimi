package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanMember;
import com.ethernova.clans.clan.ClanRole;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.SoundUtil;
import com.ethernova.clans.util.TextUtil;
import com.ethernova.clans.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Members list GUI with pagination, sorting, kick/promote/demote actions.
 */
public class MembersGui extends AbstractGui {

    private int page = 0;
    private List<ClanMember> sortedMembers;
    private String sortMode = "role"; // role, kills, kd, power, name
    private static final int[] MEMBER_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34
    };

    public MembersGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "members");
    }

    @Override
    protected String replacePlaceholders(String text) {
        text = super.replacePlaceholders(text);
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        int totalPages = 1;
        if (clan != null) {
            int memberCount = clan.getMembers().size();
            totalPages = Math.max(1, (int) Math.ceil((double) memberCount / MEMBER_SLOTS.length));
        }
        text = text.replace("{page}", String.valueOf(page + 1))
                   .replace("{max_page}", String.valueOf(totalPages));
        return text;
    }

    @Override
    protected void populateItems() {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return;

        sortedMembers = sortMembers(clan);
        int start = page * MEMBER_SLOTS.length;
        int end = Math.min(start + MEMBER_SLOTS.length, sortedMembers.size());

        for (int i = 0; i < MEMBER_SLOTS.length; i++) {
            int index = start + i;
            if (index >= end) {
                // Empty slot
                inventory.setItem(MEMBER_SLOTS[i], null);
                continue;
            }

            ClanMember member = sortedMembers.get(index);
            ItemStack head = buildMemberHead(member, clan);
            setItem(MEMBER_SLOTS[i], head);
            slotActions.put(MEMBER_SLOTS[i], "MEMBER_CLICK:" + member.getUuid().toString());
        }

        // Page info
        int totalPages = (int) Math.ceil((double) sortedMembers.size() / MEMBER_SLOTS.length);
        if (totalPages > 1) {
            // Previous page
            if (page > 0) {
                setItem(45, new ItemBuilder(Material.ARROW)
                        .name("<yellow>« Previous Page")
                        .lore(List.of("<gray>Page " + page + "/" + totalPages))
                        .build());
                slotActions.put(45, "PREV_PAGE");
            }
            // Next page
            if (page < totalPages - 1) {
                setItem(53, new ItemBuilder(Material.ARROW)
                        .name("<yellow>Next Page »")
                        .lore(List.of("<gray>Page " + (page + 2) + "/" + totalPages))
                        .build());
                slotActions.put(53, "NEXT_PAGE");
            }
        }

        // Member count
        setItem(49, new ItemBuilder(Material.NAME_TAG)
                .name("<gold>Members <gray>(" + clan.getMembers().size() + "/" +
                        plugin.getLevelManager().getMaxMembers(clan.getLevel()) + ")")
                .lore(List.of(
                        "<gray>Sort: <white>" + TextUtil.capitalize(sortMode),
                        "<yellow>Click to change sort"
                ))
                .build());
        slotActions.put(49, "CYCLE_SORT");
    }

    private org.bukkit.inventory.ItemStack buildMemberHead(ClanMember member, Clan clan) {
        boolean online = member.isOnline();
        String roleColor = switch (member.getRole()) {
            case LEADER -> "<gold>";
            case CO_LEADER -> "<yellow>";
            case OFFICER -> "<aqua>";
            case MEMBER -> "<gray>";
            case RECRUIT -> "<dark_gray>";
        };
        String roleIcon = switch (member.getRole()) {
            case LEADER -> "★";
            case CO_LEADER -> "◆";
            case OFFICER -> "◆";
            case MEMBER -> "●";
            case RECRUIT -> "○";
        };
        String statusColor = online ? "<green>" : "<red>";
        String status = online ? "Online" : "Offline";

        List<String> lore = new ArrayList<>(List.of(
                "",
                roleColor + roleIcon + " " + member.getRole().name(),
                "",
                "<gray>Kills: <white>" + member.getKills(),
                "<gray>Deaths: <white>" + member.getDeaths(),
                "<gray>K/D: <white>" + String.format("%.2f", member.getKD()),
                "<gray>Power: <white>" + member.getPowerContributed(),
                "",
                "<gray>Status: " + statusColor + status,
                "<gray>Joined: <white>" + (member.getJoinDate() != null ? TimeUtil.formatRelative(member.getJoinDate().toEpochMilli()) : "N/A")
        ));

        // Add action hints based on viewer's role
        ClanMember viewer = clan.getMember(player.getUniqueId());
        if (viewer != null && viewer.getRole().isHigherThan(member.getRole()) &&
                !member.getUuid().equals(player.getUniqueId())) {
            lore.add("");
            lore.add("<yellow>Left-click to promote");
            lore.add("<red>Right-click to kick");
            if (member.getRole() != ClanRole.MEMBER) {
                lore.add("<gold>Shift+Right-click to demote");
            }
        }

        var builder = new ItemBuilder(Material.PLAYER_HEAD)
                .name(roleColor + member.getName())
                .lore(lore);

        // Set skull owner
        try {
            var profile = Bukkit.createPlayerProfile(member.getUuid(), member.getName());
            builder.skull(profile);
        } catch (Exception ignored) {}

        return builder.build();
    }

    private List<ClanMember> sortMembers(Clan clan) {
        List<ClanMember> members = new ArrayList<>(clan.getMembers());
        switch (sortMode) {
            case "role" -> members.sort(Comparator.comparingInt((ClanMember m) -> m.getRole().getPriority()).reversed()
                    .thenComparing(ClanMember::getName));
            case "kills" -> members.sort(Comparator.comparingInt(ClanMember::getKills).reversed());
            case "kd" -> members.sort(Comparator.comparingDouble(ClanMember::getKD).reversed());
            case "power" -> members.sort(Comparator.comparingInt(ClanMember::getPowerContributed).reversed());
            case "name" -> members.sort(Comparator.comparing(ClanMember::getName));
        }
        return members;
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.startsWith("SORT:")) {
            String mode = action.substring("SORT:".length());
            sortMode = mode;
            page = 0;
            refreshGui();
            return true;
        }
        if (action.equals("NEXT_PAGE")) {
            int totalPages = Math.max(1, (int) Math.ceil((double) sortedMembers.size() / MEMBER_SLOTS.length));
            if (page < totalPages - 1) {
                page++;
                refreshGui();
            }
            return true;
        }
        if (action.equals("PREV_PAGE") || action.equals("PREVIOUS_PAGE")) {
            page = Math.max(0, page - 1);
            refreshGui();
            return true;
        }
        if (action.equals("CYCLE_SORT")) {
            sortMode = switch (sortMode) {
                case "role" -> "kills";
                case "kills" -> "kd";
                case "kd" -> "power";
                case "power" -> "name";
                default -> "role";
            };
            page = 0;
            refreshGui();
            return true;
        }
        if (action.equals("OPEN_GUI:invite-selector") || action.equals("INVITE_PLAYERS")) {
            Clan clan = plugin.getClanManager().getClanByPlayer(player);
            if (clan != null && plugin.getClanManager().hasPermission(clan, player.getUniqueId(), "invite")) {
                plugin.getServer().getScheduler().runTask(plugin, () ->
                        plugin.getGuiManager().openInvitePlayers(player));
            } else {
                player.sendMessage(plugin.getConfigManager().getMessage("general.no-permission"));
                com.ethernova.clans.util.SoundUtil.error(player);
            }
            return true;
        }
        if (action.startsWith("MEMBER_CLICK:")) {
            String uuidStr = action.substring("MEMBER_CLICK:".length());
            UUID targetUuid;
            try {
                targetUuid = UUID.fromString(uuidStr);
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("Invalid UUID in MEMBER_CLICK action: " + uuidStr);
                return true;
            }
            handleMemberClick(targetUuid, event);
            return true;
        }
        return false;
    }

    private void handleMemberClick(UUID targetUuid, InventoryClickEvent event) {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return;

        ClanMember viewer = clan.getMember(player.getUniqueId());
        ClanMember target = clan.getMember(targetUuid);
        if (viewer == null || target == null) return;

        // Can't interact with self or higher roles
        if (targetUuid.equals(player.getUniqueId())) return;
        if (!viewer.getRole().isHigherThan(target.getRole())) return;

        if (event.isLeftClick()) {
            // Promote
            plugin.getClanManager().promoteMember(clan, target.getUuid(), player);
            refreshGui();
        } else if (event.getClick() == org.bukkit.event.inventory.ClickType.SHIFT_RIGHT) {
            // Demote
            plugin.getClanManager().demoteMember(clan, target.getUuid(), player);
            refreshGui();
        } else if (event.isRightClick()) {
            // Kick
            plugin.getClanManager().removeMember(clan, targetUuid, true);
            Player targetPlayer = Bukkit.getPlayer(targetUuid);
            if (targetPlayer != null) {
                targetPlayer.sendMessage(plugin.getConfigManager().getMessage("clan.kicked",
                        "clan", clan.getName(), "player", player.getName()));
            }
            player.sendMessage(plugin.getConfigManager().getMessage("clan.kicked-player",
                    "player", target.getName()));
            refreshGui();

        }
    }

    private void refreshGui() {
        occupiedSlots.clear();
        slotActions.clear();
        rightClickActions.clear();
        slotConfigs.clear();
        fillBackground();
        placeConfigItems();
        populateItems();
    }
}
