package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.SoundUtil;
import com.ethernova.clans.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.List;

/**
 * Admin main panel GUI — central hub for all administrative operations.
 * Requires permission: ethernova.clans.admin
 */
public class AdminMainGui extends AbstractGui {

    public AdminMainGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "admin-menu");
    }

    @Override
    protected void populateItems() {
        // All items driven by YAML config + placeholders
    }

    @Override
    protected String replacePlaceholders(String text) {
        text = super.replacePlaceholders(text);

        // Admin-specific placeholders
        int totalClans = plugin.getClanManager().getAllClans().size();
        int totalPlayers = plugin.getClanManager().getAllClans().stream()
                .mapToInt(c -> c.getMembers().size()).sum();
        int activeWars = plugin.getWarManager() != null ? plugin.getWarManager().getActiveWarCount() : 0;

        Runtime rt = Runtime.getRuntime();
        long usedMB = (rt.totalMemory() - rt.freeMemory()) / 1024 / 1024;
        long maxMB = rt.maxMemory() / 1024 / 1024;

        text = text.replace("{total_clans}", String.valueOf(totalClans))
                .replace("{total_players_in_clans}", String.valueOf(totalPlayers))
                .replace("{active_wars_count}", String.valueOf(activeWars))
                .replace("{vault_status}", plugin.getVaultHook() != null ? "<green>✔ Connected" : "<red>✘ Not found")
                .replace("{papi_status}", plugin.getPlaceholderHook() != null ? "<green>✔ Connected" : "<red>✘ Not found")
                .replace("{dh_status}", plugin.getHologramHook() != null ? "<green>✔ Connected" : "<red>✘ Not found")
                .replace("{storage_type}", plugin.getConfigManager().getString("storage.type", "sqlite"))
                .replace("{language}", plugin.getConfigManager().getString("general.language", "es"))
                .replace("{debug_mode}", String.valueOf(plugin.getConfigManager().getBoolean("general.debug", false)))
                .replace("{memory_used}", String.valueOf(usedMB))
                .replace("{memory_max}", String.valueOf(maxMB));

        return text;
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        return switch (action.toUpperCase()) {
            case "ADMIN_OPEN_CLAN_LIST" -> {
                plugin.getGuiManager().openGui(player, "admin-clan-list");
                yield true;
            }
            case "ADMIN_SEARCH_PLAYER" -> {
                player.closeInventory();
                player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.enter-player"));
                plugin.getGuiManager().registerAnvilInput(player, input -> {
                    Player target = Bukkit.getPlayer(input);
                    if (target == null) {
                        player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.player-not-found",
                                "input", input));
                        plugin.getServer().getScheduler().runTask(plugin, () ->
                                plugin.getGuiManager().openGui(player, "admin-menu"));
                        return;
                    }
                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        AdminPlayerGui gui = new AdminPlayerGui(plugin, player, target);
                        gui.open();
                    });
                });
                yield true;
            }
            case "ADMIN_SEARCH_CLAN" -> {
                player.closeInventory();
                player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.enter-clan"));
                plugin.getGuiManager().registerAnvilInput(player, input -> {
                    Clan clan = plugin.getClanManager().getClanByName(input);
                    if (clan == null) clan = plugin.getClanManager().getClanByTag(input);
                    if (clan == null) {
                        player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.clan-not-found",
                                "input", input));
                        plugin.getServer().getScheduler().runTask(plugin, () ->
                                plugin.getGuiManager().openGui(player, "admin-menu"));
                        return;
                    }
                    Clan foundClan = clan;
                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        AdminClanGui gui = new AdminClanGui(plugin, player, foundClan);
                        gui.open();
                    });
                });
                yield true;
            }
            case "ADMIN_RELOAD" -> {
                long start = System.currentTimeMillis();
                plugin.getConfigManager().loadAllConfigs();
                plugin.getLevelManager().loadLevels();
                if (plugin.getMissionManager() != null) {
                    plugin.getMissionManager().loadMissions();
                }
                long elapsed = System.currentTimeMillis() - start;
                player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.reloading"));
                SoundUtil.success(player);
                yield true;
            }
            case "ADMIN_SAVE" -> {
                player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.saving"));
                List<Clan> snapshot = new java.util.ArrayList<>(plugin.getClanManager().getAllClans());
                Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
                    long start = System.currentTimeMillis();
                    for (Clan c : snapshot) {
                        plugin.getStorageManager().saveClan(c);
                    }
                    long elapsed = System.currentTimeMillis() - start;
                    Bukkit.getScheduler().runTask(plugin, () -> {
                        player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.save-complete"));
                        SoundUtil.success(player);
                    });
                });
                yield true;
            }
            case "ADMIN_TOGGLE_DEBUG" -> {
                boolean current = plugin.getConfigManager().getBoolean("general.debug", false);
                plugin.getConfigManager().set("general.debug", !current);
                player.sendMessage(plugin.getConfigManager().getMessage(
                        !current ? "general.enabled" : "general.disabled"));
                SoundUtil.click(player);
                // Re-open to refresh placeholders
                plugin.getServer().getScheduler().runTask(plugin, () ->
                        plugin.getGuiManager().openGui(player, "admin-menu"));
                yield true;
            }
            case "ADMIN_END_ALL_WARS" -> {
                if (plugin.getWarManager() != null) {
                    int count = 0;
                    for (Clan c : plugin.getClanManager().getAllClans()) {
                        if (!plugin.getWarManager().getActiveWars(c).isEmpty()) {
                            plugin.getWarManager().forceEndAllWars(c);
                            count++;
                        }
                    }
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.war-resolved"));
                } else {
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.war-unavailable"));
                }
                SoundUtil.success(player);
                yield true;
            }
            case "ADMIN_PURGE_INACTIVE" -> {
                if (!event.isShiftClick()) {
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.disband-confirm"));
                    yield true;
                }
                int purged = 0;
                long thirtyDaysMs = 30L * 24 * 60 * 60 * 1000;
                for (Clan c : new java.util.ArrayList<>(plugin.getClanManager().getAllClans())) {
                    boolean allInactive = c.getMembers().stream().allMatch(m -> {
                        if (m.isOnline()) return false;
                        if (m.getLastSeen() == null) return true;
                        return System.currentTimeMillis() - m.getLastSeen().toEpochMilli() > thirtyDaysMs;
                    });
                    if (allInactive && c.getMembers().size() > 0) {
                        plugin.getClanManager().adminDisband(c);
                        purged++;
                    }
                }
                player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.status"));
                SoundUtil.success(player);
                yield true;
            }
            case "ADMIN_CREATE_CLAN" -> {
                player.closeInventory();
                player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.enter-name"));
                plugin.getGuiManager().registerAnvilInput(player, nameInput -> {
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.enter-tag"));
                    plugin.getGuiManager().registerAnvilInput(player, tagInput -> {
                        plugin.getServer().getScheduler().runTask(plugin, () -> {
                            Clan created = plugin.getClanManager().createClan(player, nameInput, tagInput);
                            if (created != null) {
                                player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.name-changed",
                                        "name", nameInput + " [" + tagInput + "]"));
                            }
                            plugin.getGuiManager().openGui(player, "admin-menu");
                        });
                    });
                });
                yield true;
            }
            default -> false;
        };
    }
}
