package com.ethernova.clans.clan;

import org.bukkit.Bukkit;
import org.bukkit.Location;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.Optional;

public class Clan {

    private final String id;
    private String name;
    private String displayName;
    private String tag;
    private String description;
    private UUID leaderUuid;
    private String leaderName;
    private volatile Location home;
    private long createdAt;
    private final Map<UUID, ClanMember> members = new ConcurrentHashMap<>();
    private final Map<String, Integer> upgrades = new ConcurrentHashMap<>();
    private final Set<UUID> banned = ConcurrentHashMap.newKeySet();
    private final Map<String, org.bukkit.Location> warps = new ConcurrentHashMap<>();
    private final Map<String, ClanRank> ranks = new ConcurrentHashMap<>();

    // ── Stats ────────────────────────────────────────────────
    private final AtomicInteger totalKills = new AtomicInteger();
    private final AtomicInteger totalDeaths = new AtomicInteger();
    private final AtomicInteger warsWon = new AtomicInteger();
    private final AtomicInteger warsLost = new AtomicInteger();
    private volatile int claimCount;
    private volatile int level;
    private volatile double power;
    private final Set<String> allies = ConcurrentHashMap.newKeySet();
    private final ClanBank bank;

    // ── Cooldowns ────────────────────────────────────────────
    private final Map<String, Long> cooldowns = new ConcurrentHashMap<>();

    public Clan(String id, String name, String tag, UUID leaderUuid, String leaderName) {
        this.id = id;
        this.name = name;
        this.displayName = name;
        this.tag = tag;
        this.leaderUuid = leaderUuid;
        this.leaderName = leaderName;
        this.createdAt = System.currentTimeMillis();
        this.bank = new ClanBank(UUID.nameUUIDFromBytes(id.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
        // Initialize default ranks
        for (ClanRank rank : ClanRank.createDefaults()) {
            ranks.put(rank.getId(), rank);
        }
    }

    // ── Members ──────────────────────────────────────────────
    public void addMember(ClanMember member) {
        members.put(member.getUuid(), member);
    }
    public void removeMember(UUID uuid) {
        members.remove(uuid);
    }
    public ClanMember getMember(UUID uuid) {
        return members.get(uuid);
    }
    public ClanMember getMemberByName(String name) {
        return members.values().stream()
                .filter(m -> m.getName().equalsIgnoreCase(name))
                .findFirst().orElse(null);
    }
    public boolean isMember(UUID uuid) {
        return members.containsKey(uuid);
    }
    public Collection<ClanMember> getMembers() {
        return Collections.unmodifiableCollection(members.values());
    }
    public Collection<ClanMember> getOnlineMembers() {
        return members.values().stream()
                .filter(m -> Bukkit.getPlayer(m.getUuid()) != null)
                .toList();
    }

    // ── Upgrades ─────────────────────────────────────────────
    public int getUpgradeLevel(String upgrade) {
        return upgrades.getOrDefault(upgrade, 0);
    }
    public void setUpgradeLevel(String upgrade, int level) {
        upgrades.put(upgrade, level);
    }

    // ── Warps ────────────────────────────────────────────────
    public void setWarp(String name, org.bukkit.Location loc) { warps.put(name, loc); }
    public org.bukkit.Location getWarp(String name) { return warps.get(name); }
    public boolean removeWarp(String name) { return warps.remove(name) != null; }
    public Map<String, org.bukkit.Location> getWarps() { return Map.copyOf(warps); }

    // ── Ranks ────────────────────────────────────────────────
    public ClanRank getRank(String rankId) {
        return rankId != null ? ranks.get(rankId) : null;
    }
    public Map<String, ClanRank> getRanks() { return Map.copyOf(ranks); }
    public void addRank(ClanRank rank) { ranks.put(rank.getId(), rank); }
    public boolean removeRank(String rankId) { return ranks.remove(rankId) != null; }
    public ClanRank getDefaultRank() {
        return ranks.values().stream().filter(ClanRank::isDefault).findFirst()
                .orElseGet(() -> {
                    ClanRank recruit = ranks.get("recruit");
                    if (recruit != null) return recruit;
                    // Fallback: create a minimal default rank and persist it in the map
                    ClanRank fallback = new ClanRank("recruit", "Recluta", 0);
                    fallback.setDefault(true);
                    ranks.put(fallback.getId(), fallback);
                    return fallback;
                });
    }
    /** Get the ClanRank for a member, falling back to default. */
    public ClanRank getMemberRank(ClanMember member) {
        ClanRank rank = getRank(member.getRankId());
        return rank != null ? rank : getDefaultRank();
    }

    // ── Home (Location + String adapters) ────────────────────
    public Location getHome() { return home; }
    public void setHome(Location home) { this.home = home; }

    public String getHomeLocation() {
        if (home == null) return null;
        if (home.getWorld() == null) return null;
        return home.getWorld().getName() + ":" + home.getX() + ":" + home.getY() + ":" +
                home.getZ() + ":" + home.getYaw() + ":" + home.getPitch();
    }

    public void setHomeLocation(String locStr) {
        if (locStr == null || locStr.isEmpty()) { this.home = null; return; }
        try {
            String[] p = locStr.split(":");
            org.bukkit.World w = Bukkit.getWorld(p[0]);
            if (w == null) return;
            this.home = new Location(w,
                    Double.parseDouble(p[1]), Double.parseDouble(p[2]), Double.parseDouble(p[3]),
                    p.length > 4 ? Float.parseFloat(p[4]) : 0, p.length > 5 ? Float.parseFloat(p[5]) : 0);
        } catch (Exception e) {
            org.bukkit.Bukkit.getLogger().log(java.util.logging.Level.WARNING, "Failed to parse home location: " + locStr, e);
        }
    }

    // ── Cooldowns ────────────────────────────────────────────
    public boolean isOnCooldown(String key) {
        Long expiresAt = cooldowns.get(key);
        if (expiresAt == null) return false;
        if (System.currentTimeMillis() >= expiresAt) { cooldowns.remove(key); return false; }
        return true;
    }

    public long getCooldownRemaining(String key) {
        Long expiresAt = cooldowns.get(key);
        if (expiresAt == null) return 0;
        long remaining = expiresAt - System.currentTimeMillis();
        return Math.max(0, remaining);
    }

    public void setCooldown(String key, long durationMs) {
        cooldowns.put(key, System.currentTimeMillis() + durationMs);
    }

    /** Remove all expired cooldown entries to prevent unbounded map growth. */
    public void purgeExpiredCooldowns() {
        long now = System.currentTimeMillis();
        cooldowns.entrySet().removeIf(e -> now >= e.getValue());
    }

    // ── Stats getters/setters ────────────────────────────────
    public int getTotalKills() { return totalKills.get(); }
    public void setTotalKills(int totalKills) { this.totalKills.set(totalKills); }
    public void addKill() { this.totalKills.incrementAndGet(); }

    public int getTotalDeaths() { return totalDeaths.get(); }
    public void setTotalDeaths(int totalDeaths) { this.totalDeaths.set(totalDeaths); }
    public void addDeath() { this.totalDeaths.incrementAndGet(); }

    public int getWarsWon() { return warsWon.get(); }
    public void setWarsWon(int warsWon) { this.warsWon.set(warsWon); }
    public void addWarWon() { this.warsWon.incrementAndGet(); }

    public int getWarsLost() { return warsLost.get(); }
    public void setWarsLost(int warsLost) { this.warsLost.set(warsLost); }
    public void addWarLost() { this.warsLost.incrementAndGet(); }

    public int getClaimCount() { return claimCount; }
    public void setClaimCount(int claimCount) { this.claimCount = claimCount; }

    public int getLevel() { return level; }
    public void setLevel(int level) { this.level = level; }

    public double getPower() { return power; }
    public void setPower(double power) { this.power = power; }

    public ClanBank getBank() { return bank; }

    public Set<String> getAllies() { return Collections.unmodifiableSet(allies); }
    public void addAlly(String clanId) { allies.add(clanId); }
    public void removeAlly(String clanId) { allies.remove(clanId); }
    public void clearAllies() { allies.clear(); }
    public boolean isAlly(String clanId) { return allies.contains(clanId); }

    // getFormattedTag() defined below with color support

    /** Alias methods for backward compatibility */
    public int getKills() { return totalKills.get(); }
    public int getDeaths() { return totalDeaths.get(); }
    public double getKD() {
        int d = totalDeaths.get();
        return d == 0 ? totalKills.get() : (double) totalKills.get() / d;
    }

    /** Claimed chunks — delegates to TerritoryManager for consistent data.
     *  Returns empty set if called before plugin is fully loaded. */
    public Set<String> getClaimedChunks() {
        var plugin = org.bukkit.Bukkit.getPluginManager().getPlugin("EthernovaClans");
        if (plugin instanceof com.ethernova.clans.EthernovaClans ec && ec.getTerritoryManager() != null) {
            return ec.getTerritoryManager().getClanClaims(id);
        }
        return Set.of();
    }

    /** Chat toggle */
    private volatile boolean clanChatEnabled = true;
    public boolean isClanChatEnabled() { return clanChatEnabled; }
    public void setClanChatEnabled(boolean enabled) { this.clanChatEnabled = enabled; }

    /** Settings fields (volatile for cross-thread visibility) */
    private volatile boolean friendlyFire = false;
    private volatile String inviteMode = "invite";
    private volatile boolean warParticipation = true;

    public boolean isFriendlyFire() { return friendlyFire; }
    public void setFriendlyFire(boolean friendlyFire) { this.friendlyFire = friendlyFire; }

    public String getInviteMode() { return inviteMode; }
    public void setInviteMode(String inviteMode) { this.inviteMode = inviteMode; }

    public boolean isWarParticipation() { return warParticipation; }
    public void setWarParticipation(boolean warParticipation) { this.warParticipation = warParticipation; }

    /** Online member count */
    public int getOnlineMemberCount() { return getOnlineMembers().size(); }

    /** Rivals — tracked externally but Clan provides a convenience accessor */
    private final Set<String> rivals = ConcurrentHashMap.newKeySet();
    public Set<String> getRivals() { return Collections.unmodifiableSet(rivals); }
    public void addRival(String clanId) { rivals.add(clanId); }
    public void removeRival(String clanId) { rivals.remove(clanId); }
    public boolean isRival(String clanId) { return rivals.contains(clanId); }

    /** Created date formatted as dd/MM/yyyy HH:mm */
    public String getCreatedDate() {
        if (createdAt <= 0) return null;
        java.time.Instant instant = java.time.Instant.ofEpochMilli(createdAt);
        java.time.LocalDateTime ldt = java.time.LocalDateTime.ofInstant(instant, java.time.ZoneId.systemDefault());
        return ldt.format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
    }

    /** Headquarters chunk — null if not set */
    private String headquartersChunk;
    public String getHeadquartersChunk() { return headquartersChunk; }
    public void setHeadquartersChunk(String chunkId) { this.headquartersChunk = chunkId; }

    /** Pending ally requests — tracked in AllianceManager, stub here */
    public Set<String> getPendingAllyRequests() { return Set.of(); }

    /** Banned players */
    public Set<UUID> getBanned() { return Collections.unmodifiableSet(banned); }
    public void addBanned(UUID uuid) { banned.add(uuid); }
    public void removeBanned(UUID uuid) { banned.remove(uuid); }
    public boolean isBanned(UUID uuid) { return banned.contains(uuid); }

    // ── Getters/Setters ──────────────────────────────────────
    public String getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDisplayName() { return displayName != null ? displayName : name; }
    public void setDisplayName(String displayName) { this.displayName = displayName; }
    public String getTag() { return tag; }
    public void setTag(String tag) { this.tag = tag; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public UUID getLeaderUuid() { return leaderUuid; }
    public void setLeaderUuid(UUID leaderUuid) { this.leaderUuid = leaderUuid; }
    public String getLeaderName() { return leaderName; }
    public void setLeaderName(String leaderName) { this.leaderName = leaderName; }
    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }
    public Map<String, Integer> getUpgrades() { return Map.copyOf(upgrades); }

    // ── Tag Color System ─────────────────────────────────────
    private String tagColor;
    private String gradientStart;
    private String gradientEnd;
    private boolean useGradient;

    public String getIdString() { return id; }

    public Optional<ClanMember> getLeader() {
        return members.values().stream()
                .filter(m -> m.getRole() == ClanRole.LEADER)
                .findFirst();
    }

    public int getMemberCount() { return members.size(); }

    public Map<UUID, ClanMember> getMembersMap() { return Collections.unmodifiableMap(members); }

    public String getFormattedTag() {
        if (useGradient && gradientStart != null && gradientEnd != null) {
            return "<gradient:" + gradientStart + ":" + gradientEnd + ">[" + tag + "]</gradient>";
        } else if (tagColor != null) {
            return "<color:" + tagColor + ">[" + tag + "]</color>";
        }
        return "<gray>[" + tag + "]</gray>";
    }

    public String getTagColor() { return tagColor; }
    public void setTagColor(String tagColor) { this.tagColor = tagColor; }
    public String getGradientStart() { return gradientStart; }
    public void setGradientStart(String gradientStart) { this.gradientStart = gradientStart; }
    public String getGradientEnd() { return gradientEnd; }
    public void setGradientEnd(String gradientEnd) { this.gradientEnd = gradientEnd; }
    public boolean isUseGradient() { return useGradient; }
    public void setUseGradient(boolean useGradient) { this.useGradient = useGradient; }
    public void setTagColorStart(String hex) { this.tagColor = hex; this.gradientStart = hex; }
    public void setTagColorEnd(String hex) { this.gradientEnd = hex; }
    public void setTagUseGradient(boolean v) { this.useGradient = v; }
    public boolean isTagUseGradient() { return useGradient; }

    // ── Icon ──
    private String icon;
    public String getIcon() { return icon; }
    public void setIcon(String icon) { this.icon = icon; }

    // ── Invite Open Convenience ──
    public boolean isInviteOpen() { return "open".equals(inviteMode); }

    // ── Invitation Tracking ──────────────────────────────────
    private final Map<UUID, java.time.Instant> pendingInvites = new ConcurrentHashMap<>();

    public boolean hasInvite(UUID uuid) {
        java.time.Instant expiry = pendingInvites.get(uuid);
        if (expiry == null) return false;
        if (expiry.isBefore(java.time.Instant.now())) { pendingInvites.remove(uuid); return false; }
        return true;
    }

    public Map<UUID, java.time.Instant> getPendingInvites() { return Map.copyOf(pendingInvites); }
    public void addInvite(UUID uuid, java.time.Instant expiry) { pendingInvites.put(uuid, expiry); }
    public void removeInvite(UUID uuid) { pendingInvites.remove(uuid); }
}
