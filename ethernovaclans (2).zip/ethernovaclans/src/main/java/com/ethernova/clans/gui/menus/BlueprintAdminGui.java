package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.blueprint.Blueprint;
import com.ethernova.clans.blueprint.BlueprintManager;
import com.ethernova.clans.blueprint.ClanBlueprint;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.*;

/**
 * Admin GUI for managing blueprints across all clans.
 */
public class BlueprintAdminGui extends AbstractGui {

    private static final int[] CLAN_SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};

    public BlueprintAdminGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "blueprints-admin");
    }

    @Override
    protected void populateItems() {
        BlueprintManager bm = plugin.getBlueprintManager();
        if (bm == null || !bm.isEnabled()) return;

        int totalBuilt = bm.getTotalBuilt();
        int clansWithBp = bm.getClansWithBlueprints();
        int totalClans = plugin.getClanManager().getAllClans().size();

        // Stats header
        setItem(4, new ItemBuilder(Material.KNOWLEDGE_BOOK)
                .name("<gradient:#FF0000:#FFD700>🛠 Admin Blueprints</gradient>")
                .lore(List.of(
                        "",
                        "<gray>Total construidas: <white>" + totalBuilt,
                        "<gray>Clanes con blueprints: <white>" + clansWithBp + "/" + totalClans,
                        "<gray>Tipos disponibles: <white>" + bm.getBlueprintTypes().size()
                ))
                .build());

        // Reload button
        setItem(0, new ItemBuilder(Material.REDSTONE)
                .name("<red>🔄 Reload Config")
                .lore(List.of("<gray>Recarga blueprints.yml"))
                .build());

        // List clans with blueprints
        Map<String, List<ClanBlueprint>> allBp = bm.getAllBlueprints();
        int idx = 0;
        for (var entry : allBp.entrySet()) {
            if (idx >= CLAN_SLOTS.length) break;
            String clanId = entry.getKey();
            Clan clan = plugin.getClanManager().getClan(clanId);
            if (clan == null) continue;

            List<ClanBlueprint> blueprints = entry.getValue();
            int maxSlots = bm.getMaxSlots(clan.getLevel());

            List<String> lore = new ArrayList<>();
            lore.add("<gray>Estructuras: <white>" + blueprints.size() + "/" + maxSlots);
            lore.add("");
            for (ClanBlueprint cb : blueprints) {
                Blueprint type = bm.getBlueprintType(cb.getBlueprintId());
                String name = type != null ? type.getName() : cb.getBlueprintId();
                lore.add("  <gold>• " + name + " <gray>Nv." + cb.getLevel());
            }
            lore.add("");
            lore.add("<red>Shift+Click: Remover todas");

            setItem(CLAN_SLOTS[idx++], new ItemBuilder(Material.PLAYER_HEAD)
                    .name("<yellow>" + clan.getName() + " <gray>[" + clan.getTag() + "]")
                    .lore(lore)
                    .build());
        }

        // Back button
        setItem(49, new ItemBuilder(Material.ARROW)
                .name("<gray>◀ Volver al Admin")
                .build());
        slotActions.put(49, "OPEN_GUI:admin-menu");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        return false;
    }

    @Override
    protected void onClick(int slot, InventoryClickEvent event) {
        if (!player.hasPermission("ethernova.clans.admin")) {
            player.sendMessage(plugin.getConfigManager().getMessage("error.no-permission"));
            com.ethernova.clans.util.SoundUtil.error(player);
            return;
        }

        if (slot == 0) {
            // Reload
            BlueprintManager bm = plugin.getBlueprintManager();
            if (bm != null) {
                bm.loadConfig();
                player.sendMessage(plugin.getConfigManager().getMessage("blueprint.reloaded"));
            }
            return;
        }

        BlueprintManager bm = plugin.getBlueprintManager();
        if (bm == null) return;

        int idx = -1;
        for (int i = 0; i < CLAN_SLOTS.length; i++) {
            if (CLAN_SLOTS[i] == slot) { idx = i; break; }
        }
        if (idx < 0) return;

        Map<String, List<ClanBlueprint>> allBp = bm.getAllBlueprints();
        List<String> clanIds = new ArrayList<>(allBp.keySet());

        if (idx >= clanIds.size()) return;
        String clanId = clanIds.get(idx);

        if (event.isShiftClick()) {
            bm.removeAllForClan(clanId);
            player.sendMessage(plugin.getConfigManager().getMessage("blueprint.all-removed"));
            player.closeInventory();
        }
    }
}
