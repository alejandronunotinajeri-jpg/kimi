package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanMember;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.SoundUtil;
import org.bukkit.Material;
import org.bukkit.Statistic;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.time.Instant;
import java.util.*;

/**
 * Advanced Statistics GUI.
 * Shows detailed clan and individual member stats with visual charts.
 */
public class StatsGui extends AbstractGui {

    private String currentView = "overview"; // overview, members, wars, economy

    public StatsGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "stats");
    }

    @Override
    protected void populateItems() {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return;

        // ── Tab bar (row 2, avoid border row 0) ──
        setItem(10, createTab("📊 Resumen", Material.BOOK, "overview"));
        setItem(12, createTab("👥 Miembros", Material.PLAYER_HEAD, "members"));
        setItem(14, createTab("⚔ Guerras", Material.IRON_SWORD, "wars"));
        setItem(16, createTab("💰 Economía", Material.GOLD_INGOT, "economy"));

        slotActions.put(10, "VIEW:overview");
        slotActions.put(12, "VIEW:members");
        slotActions.put(14, "VIEW:wars");
        slotActions.put(16, "VIEW:economy");

        switch (currentView) {
            case "overview" -> populateOverview(clan);
            case "members" -> populateMembersStats(clan);
            case "wars" -> populateWarStats(clan);
            case "economy" -> populateEconomyStats(clan);
        }
    }

    private void populateOverview(Clan clan) {
        int members = clan.getMembers().size();
        int maxMembers = plugin.getLevelManager().getMaxMembers(clan.getLevel());
        int level = clan.getLevel();
        long xp = plugin.getLevelManager().getXP(clan.getId());
        int territories = plugin.getTerritoryManager().getClanClaims(clan.getId()).size();
        double balance = clan.getBank().getBalance();
        int kills = clan.getTotalKills();
        int deaths = clan.getTotalDeaths();
        double kdr = deaths > 0 ? (double) kills / deaths : kills;
        int warsWon = clan.getWarsWon();
        int warsLost = clan.getWarsLost();
        int totalWars = warsWon + warsLost;
        double winRate = totalWars > 0 ? (warsWon * 100.0 / totalWars) : 0;

        // ── Main stats display ──
        setItem(13, new ItemBuilder(Material.NETHER_STAR)
                .name("<gradient:#FFD700:#00D4FF>📊 Estadísticas de " + clan.getName() + "</gradient>")
                .lore(List.of(
                        "",
                        "<gray>Fundado por: <white>" + clan.getLeaderName(),
                        "<gray>Nivel: <green>" + level + " <gray>(" + xp + " XP)",
                        "<gray>Miembros: <yellow>" + members + "/" + maxMembers,
                        ""
                ))
                .glow()
                .build());

        // ── KDR ──
        setItem(20, new ItemBuilder(Material.DIAMOND_SWORD)
                .name("<red>⚔ Combate")
                .lore(List.of(
                        "",
                        "<gray>Kills totales: <green>" + kills,
                        "<gray>Muertes totales: <red>" + deaths,
                        "<gray>K/D Ratio: <yellow>" + String.format("%.2f", kdr),
                        "",
                        buildProgressBar(kdr, 5.0, 20, "<green>", "<dark_gray>")
                ))
                .hideFlags()
                .build());

        // ── Wars ──
        setItem(22, new ItemBuilder(Material.TNT)
                .name("<red>🏰 Guerras")
                .lore(List.of(
                        "",
                        "<gray>Guerras ganadas: <green>" + warsWon,
                        "<gray>Guerras perdidas: <red>" + warsLost,
                        "<gray>Total: <white>" + totalWars,
                        "<gray>Win rate: <yellow>" + String.format("%.1f", winRate) + "%",
                        "",
                        buildProgressBar(winRate, 100.0, 20, "<gold>", "<dark_gray>")
                ))
                .build());

        // ── Territory ──
        int maxClaims = plugin.getPowerManager().getMaxClaims(clan);
        setItem(24, new ItemBuilder(Material.FILLED_MAP)
                .name("<green>🗺 Territorio")
                .lore(List.of(
                        "",
                        "<gray>Chunks reclamados: <yellow>" + territories,
                        "<gray>Chunks máximos: <white>" + maxClaims,
                        "",
                        buildProgressBar(territories, maxClaims, 20, "<aqua>", "<dark_gray>")
                ))
                .build());

        // ── Economy ──
        setItem(29, new ItemBuilder(Material.GOLD_BLOCK)
                .name("<gold>💰 Economía")
                .lore(List.of(
                        "",
                        "<gray>Balance bancario: <green>$" + String.format("%.2f", balance),
                        "<gray>Miembros: <white>" + members + "/" + maxMembers,
                        "<gray>Per capita: <yellow>$" + String.format("%.2f", members > 0 ? balance / members : 0)
                ))
                .build());

        // ── Level Progress ──
        long xpNeeded = plugin.getLevelManager().getXPForNextLevel(clan.getId());
        setItem(31, new ItemBuilder(Material.EXPERIENCE_BOTTLE)
                .name("<aqua>⭐ Progreso de Nivel")
                .lore(List.of(
                        "",
                        "<gray>Nivel actual: <green>" + level,
                        "<gray>XP: <yellow>" + xp + "/" + xpNeeded,
                        "",
                        buildProgressBar(xp, xpNeeded, 20, "<light_purple>", "<dark_gray>")
                ))
                .build());

        // ── Members breakdown ──
        long leaders = clan.getMembers().stream()
                .filter(m -> m.getRole().isAtLeast(com.ethernova.clans.clan.ClanRole.LEADER)).count();
        long officers = clan.getMembers().stream()
                .filter(m -> m.getRole() == com.ethernova.clans.clan.ClanRole.OFFICER || m.getRole() == com.ethernova.clans.clan.ClanRole.CO_LEADER).count();
        long normal = members - leaders - officers;

        setItem(33, new ItemBuilder(Material.PLAYER_HEAD)
                .name("<aqua>👥 Distribución de Miembros")
                .lore(List.of(
                        "",
                        "<gray>Líderes: <gold>" + leaders,
                        "<gray>Oficiales: <yellow>" + officers,
                        "<gray>Miembros: <white>" + normal,
                        "<gray>Total: <green>" + members
                ))
                .build());
    }

    private void populateMembersStats(Clan clan) {
        setItem(13, new ItemBuilder(Material.PLAYER_HEAD)
                .name("<aqua>👥 Estadísticas por Miembro</aqua>")
                .lore(List.of("<gray>Actividad y rendimiento individual."))
                .build());

        int[] slots = {19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};
        int idx = 0;

        List<ClanMember> sortedMembers = new ArrayList<>(clan.getMembers());
        sortedMembers.sort((a, b) -> b.getRole().getPriority() - a.getRole().getPriority());

        for (ClanMember member : sortedMembers) {
            if (idx >= slots.length) break;

            Player online = plugin.getServer().getPlayer(member.getUuid());
            String status = online != null ? "<green>● Online" : "<red>● Offline";
            String roleColor = switch (member.getRole()) {
                case LEADER -> "<gold>";
                case CO_LEADER -> "<yellow>";
                case OFFICER -> "<aqua>";
                case MEMBER -> "<white>";
                case RECRUIT -> "<gray>";
            };

            List<String> lore = new ArrayList<>();
            lore.add("");
            lore.add(status);
            lore.add("<gray>Rango: " + roleColor + member.getRole().name());
            Instant joinDate = member.getJoinDate();
            lore.add("<gray>Unido: <white>" + formatTimestamp(joinDate != null ? joinDate.toEpochMilli() : 0));

            if (online != null) {
                int playerKills = online.getStatistic(Statistic.PLAYER_KILLS);
                int playerDeaths = online.getStatistic(Statistic.DEATHS);
                lore.add("<gray>Kills (MC): <green>" + playerKills);
                lore.add("<gray>Muertes (MC): <red>" + playerDeaths);
            }

            setItem(slots[idx], new ItemBuilder(Material.PLAYER_HEAD)
                    .name(roleColor + member.getName())
                    .lore(lore)
                    .build());
            idx++;
        }
    }

    private void populateWarStats(Clan clan) {
        int warsWon = clan.getWarsWon();
        int warsLost = clan.getWarsLost();
        int totalWars = warsWon + warsLost;
        double winRate = totalWars > 0 ? (warsWon * 100.0 / totalWars) : 0;

        setItem(13, new ItemBuilder(Material.IRON_SWORD)
                .name("<red>⚔ Historial de Guerras</red>")
                .lore(List.of(
                        "",
                        "<gray>Resumen bélico del clan."
                ))
                .hideFlags()
                .build());

        // Win/Loss visualization
        setItem(20, new ItemBuilder(Material.LIME_CONCRETE)
                .name("<green>✔ Victorias: " + warsWon)
                .amount(Math.max(1, Math.min(64, warsWon)))
                .build());

        setItem(21, new ItemBuilder(Material.RED_CONCRETE)
                .name("<red>✘ Derrotas: " + warsLost)
                .amount(Math.max(1, Math.min(64, warsLost)))
                .build());

        setItem(22, new ItemBuilder(Material.YELLOW_CONCRETE)
                .name("<yellow>📊 Win Rate: " + String.format("%.1f", winRate) + "%")
                .lore(List.of(
                        "",
                        buildProgressBar(winRate, 100.0, 30, "<green>", "<red>")
                ))
                .build());

        // K/D
        int kills = clan.getTotalKills();
        int deaths = clan.getTotalDeaths();
        setItem(24, new ItemBuilder(Material.DIAMOND_SWORD)
                .name("<gold>K/D Ratio")
                .lore(List.of(
                        "",
                        "<green>Kills: " + kills,
                        "<red>Muertes: " + deaths,
                        "<yellow>Ratio: " + String.format("%.2f", deaths > 0 ? (double) kills / deaths : kills)
                ))
                .glow()
                .hideFlags()
                .build());

        // Visual bar chart
        setItem(31, new ItemBuilder(Material.PAPER)
                .name("<white>Rendimiento General")
                .lore(List.of(
                        "",
                        "<green>Victorias " + buildProgressBar(warsWon, Math.max(totalWars, 1), 20, "<green>", "<dark_gray>") + " " + warsWon,
                        "<red>Derrotas  " + buildProgressBar(warsLost, Math.max(totalWars, 1), 20, "<red>", "<dark_gray>") + " " + warsLost,
                        "<yellow>Kills     " + buildProgressBar(kills, Math.max(kills + deaths, 1), 20, "<yellow>", "<dark_gray>") + " " + kills
                ))
                .build());
    }

    private void populateEconomyStats(Clan clan) {
        double balance = clan.getBank().getBalance();
        int members = clan.getMembers().size();
        double maxBalance = plugin.getConfigManager().getConfig().getDouble("bank.max-balance", 1000000);

        setItem(13, new ItemBuilder(Material.GOLD_INGOT)
                .name("<gold>💰 Estadísticas Económicas</gold>")
                .lore(List.of("<gray>Balance y flujo de dinero."))
                .build());

        setItem(20, new ItemBuilder(Material.GOLD_BLOCK)
                .name("<green>💰 Balance Total")
                .lore(List.of(
                        "",
                        "<white>$" + String.format("%.2f", balance)
                ))
                .build());

        setItem(22, new ItemBuilder(Material.EMERALD)
                .name("<aqua>👤 Per Capita")
                .lore(List.of(
                        "",
                        "<gray>Balance por miembro:",
                        "<white>$" + String.format("%.2f", members > 0 ? balance / members : 0)
                ))
                .build());

        setItem(24, new ItemBuilder(Material.CHEST)
                .name("<yellow>📊 Capacidad Bancaria")
                .lore(List.of(
                        "",
                        "<gray>Balance: <green>$" + String.format("%.2f", balance),
                        "<gray>Límite: <white>$" + String.format("%.2f", maxBalance),
                        "",
                        buildProgressBar(balance, maxBalance, 20, "<gold>", "<dark_gray>")
                ))
                .build());

        // Transaction summary
        setItem(31, new ItemBuilder(Material.WRITABLE_BOOK)
                .name("<yellow>📜 Últimas Transacciones")
                .lore(List.of(
                        "",
                        "<gray>Consulta el banco del clan",
                        "<gray>para ver las transacciones",
                        "<gray>detalladas.",
                        "",
                        "<yellow>Click → Abrir Banco"
                ))
                .build());
        slotActions.put(31, "OPEN_BANK");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.startsWith("VIEW:")) {
            String view = action.substring("VIEW:".length());
            currentView = view;
            SoundUtil.click(player);
            refreshGui();
            return true;
        }

        if (action.equals("OPEN_BANK")) {
            player.closeInventory();
            plugin.getServer().getScheduler().runTask(plugin, () ->
                    plugin.getGuiManager().openGui(player, "bank"));
            return true;
        }

        return false;
    }

    // ── Helpers ──

    private org.bukkit.inventory.ItemStack createTab(String name, Material mat, String viewId) {
        boolean selected = currentView.equals(viewId);
        return new ItemBuilder(mat)
                .name((selected ? "<green>▶ " : "<gray>") + name)
                .glowIf(selected)
                .build();
    }

    private String buildProgressBar(double value, double max, int length, String filledColor, String emptyColor) {
        if (max <= 0) max = 1;
        int filled = (int) Math.round((value / max) * length);
        filled = Math.max(0, Math.min(length, filled));
        int empty = length - filled;
        return filledColor + "█".repeat(filled) + emptyColor + "█".repeat(empty);
    }

    private String formatTimestamp(long timestamp) {
        if (timestamp <= 0) return "Desconocido";
        long days = (System.currentTimeMillis() - timestamp) / (1000L * 60 * 60 * 24);
        if (days < 1) return "Hoy";
        if (days == 1) return "Ayer";
        return "Hace " + days + " días";
    }

    private void refreshGui() {
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            occupiedSlots.clear();
            slotActions.clear();
            rightClickActions.clear();
            slotConfigs.clear();
            fillBackground();
            placeConfigItems();
            populateItems();
        });
    }
}
