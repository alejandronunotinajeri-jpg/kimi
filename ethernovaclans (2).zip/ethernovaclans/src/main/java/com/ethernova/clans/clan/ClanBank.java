package com.ethernova.clans.clan;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
/**
 * Manages the clan's bank: balance, transactions, interest, tax, and payroll.
 * All public methods are synchronized for thread-safety.
 */
public class ClanBank {

    @FunctionalInterface
    public interface TransactionPersister {
        void persist(UUID clanId, String type, double amount, UUID actor, UUID target);
    }

    /** Callback to sync balance changes back to the authoritative ClanBankManager. */
    @FunctionalInterface
    public interface BalanceChangeListener {
        void onBalanceChanged(String clanId, double newBalance);
    }

    private final UUID clanId;
    private String clanIdString; // Original string clan ID for listener callbacks
    private double balance;
    private double taxRate;
    private Instant lastInterestTime;
    private final java.util.LinkedList<BankTransaction> transactionLog;
    private TransactionPersister persister;
    private BalanceChangeListener balanceChangeListener;

    public ClanBank(UUID clanId) {
        this.clanId = clanId;
        this.balance = 0.0;
        this.taxRate = 5.0;
        this.lastInterestTime = Instant.now();
        this.transactionLog = new java.util.LinkedList<>();
    }

    /**
     * Set a persister callback to save transactions to database.
     */
    public void setPersister(TransactionPersister persister) {
        this.persister = persister;
    }

    /** Register a listener to sync balance changes to ClanBankManager. */
    public void setBalanceChangeListener(BalanceChangeListener listener) {
        this.balanceChangeListener = listener;
    }

    /** Set the original String clan ID for balance-change callbacks. */
    public void setClanIdString(String id) {
        this.clanIdString = id;
    }

    /** Notify the listener (ClanBankManager) that balance changed. */
    private void notifyBalanceChange() {
        if (balanceChangeListener != null && clanIdString != null) {
            balanceChangeListener.onBalanceChanged(clanIdString, balance);
        }
    }

    // ── Balance ──────────────────────────────────────────────

    public synchronized double getBalance() {
        return balance;
    }

    public synchronized void setBalance(double balance) {
        this.balance = Math.max(0, balance);
        notifyBalanceChange();
    }

    public UUID getClanId() {
        return clanId;
    }

    // ── Tax ──────────────────────────────────────────────────

    public synchronized double getTaxRate() {
        return taxRate;
    }

    public synchronized void setTaxRate(double taxRate) {
        this.taxRate = Math.max(0, Math.min(50, taxRate));
    }

    // ── Interest ─────────────────────────────────────────────

    public synchronized Instant getLastInterestTime() {
        return lastInterestTime;
    }

    public synchronized void setLastInterestTime(Instant lastInterestTime) {
        this.lastInterestTime = lastInterestTime;
    }

    // ── Operations ───────────────────────────────────────────

    /**
     * Deposit money into the bank.
     * @param amount amount to deposit
     * @param maxBalance maximum allowed balance
     * @param depositor UUID of the depositor
     * @return actual amount deposited (may be capped)
     */
    public synchronized double deposit(double amount, double maxBalance, UUID depositor) {
        double actual = Math.min(amount, maxBalance - balance);
        if (actual <= 0) return 0;
        balance += actual;
        logTransaction(TransactionType.DEPOSIT, actual, depositor, null);
        notifyBalanceChange();
        return actual;
    }

    /**
     * Withdraw money from the bank.
     * @param amount amount to withdraw
     * @param withdrawer UUID of the withdrawer
     * @return actual amount withdrawn
     */
    public synchronized double withdraw(double amount, UUID withdrawer) {
        double actual = Math.min(amount, balance);
        if (actual <= 0) return 0;
        balance -= actual;
        logTransaction(TransactionType.WITHDRAW, actual, withdrawer, null);
        notifyBalanceChange();
        return actual;
    }

    /**
     * Pay a clan member from the bank.
     * @param amount amount to pay
     * @param payer UUID of the payer (who initiated)
     * @param recipient UUID of the recipient
     * @return true if payment was successful
     */
    public synchronized boolean pay(double amount, UUID payer, UUID recipient) {
        if (amount > balance || amount <= 0) return false;
        balance -= amount;
        logTransaction(TransactionType.PAY_MEMBER, amount, payer, recipient);
        notifyBalanceChange();
        return true;
    }

    /**
     * Apply interest to the bank balance.
     * @param rate interest rate (percentage)
     * @param cap maximum interest per interval
     * @param maxBalance maximum allowed balance
     * @return amount of interest earned
     */
    public synchronized double applyInterest(double rate, double cap, double maxBalance) {
        double interest = balance * (rate / 100.0);
        interest = Math.min(interest, cap);
        interest = Math.min(interest, maxBalance - balance);
        if (interest <= 0) return 0;
        balance += interest;
        lastInterestTime = Instant.now();
        logTransaction(TransactionType.INTEREST, interest, null, null);
        return interest;
    }

    /**
     * Apply tax from a player's earnings.
     * @param earnings the total earnings
     * @param maxBalance maximum allowed balance
     * @param source UUID of the earner
     * @return amount taxed
     */
    public synchronized double applyTax(double earnings, double maxBalance, UUID source) {
        double tax = earnings * (taxRate / 100.0);
        tax = Math.min(tax, maxBalance - balance);
        if (tax <= 0) return 0;
        balance += tax;
        logTransaction(TransactionType.TAX, tax, source, null);
        return tax;
    }

    // ── Transaction Log ──────────────────────────────────────

    public synchronized List<BankTransaction> getTransactionLog() {
        return Collections.unmodifiableList(new ArrayList<>(transactionLog));
    }

    public synchronized List<BankTransaction> getRecentTransactions(int count) {
        int start = Math.max(0, transactionLog.size() - count);
        return Collections.unmodifiableList(new ArrayList<>(transactionLog.subList(start, transactionLog.size())));
    }

    private synchronized void logTransaction(TransactionType type, double amount, UUID actor, UUID target) {
        transactionLog.add(new BankTransaction(type, amount, actor, target, Instant.now()));
        // Keep log size in check
        while (transactionLog.size() > 1000) {
            transactionLog.removeFirst();
        }
        // Persist to database if persister is set
        if (persister != null) {
            try {
                persister.persist(clanId, type.name(), amount, actor, target);
            } catch (Exception e) {
                // Don't let persistence failures break bank operations, but log for audit trail
                org.bukkit.Bukkit.getLogger().log(java.util.logging.Level.WARNING,
                        "Failed to persist bank transaction for clan " + clanId + " (" + type + " " + amount + ")", e);
            }
        }
    }

    public synchronized void clearLog() {
        transactionLog.clear();
    }

    /**
     * Add a transaction loaded from database (does not cap size).
     */
    public synchronized void addLoadedTransaction(BankTransaction tx) {
        transactionLog.add(tx);
    }

    // ── Inner Types ──────────────────────────────────────────

    public enum TransactionType {
        DEPOSIT("DEPOSIT", "<green>"),
        WITHDRAW("WITHDRAW", "<yellow>"),
        PAY_MEMBER("PAY_MEMBER", "<aqua>"),
        PAY_ALL("PAY_ALL", "<aqua>"),
        TAX("TAX", "<gray>"),
        INTEREST("INTEREST", "<gold>"),
        WAR_COST("WAR_COST", "<red>"),
        WAR_REWARD("WAR_REWARD", "<green>"),
        ALLIANCE_COST("ALLIANCE_COST", "<red>"),
        ADMIN("ADMIN", "<dark_red>");

        private final String displayName;
        private final String color;

        TransactionType(String displayName, String color) {
            this.displayName = displayName;
            this.color = color;
        }

        public String getDisplayName() {
            return displayName;
        }

        public String getColor() {
            return color;
        }
    }

    public record BankTransaction(
            TransactionType type,
            double amount,
            UUID actor,
            UUID target,
            Instant timestamp
    ) {}
}
