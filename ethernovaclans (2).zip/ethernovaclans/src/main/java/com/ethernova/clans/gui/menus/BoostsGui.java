package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.level.ClanLevelManager;
import com.ethernova.clans.util.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * GUI showing detailed boost/level information for the clan's current level.
 */
public class BoostsGui extends AbstractGui {

    private static final int[] BOOST_SLOTS = {
            20, 22, 24,
            29, 31, 33
    };

    public BoostsGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "boosts");
    }

    @Override
    protected void populateItems() {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return;

        ClanLevelManager levelMgr = plugin.getLevelManager();
        int level = clan.getLevel();
        ClanLevelManager.LevelData currentData = levelMgr.getLevelData(level);

        // Header item
        setItem(4, new ItemBuilder(Material.BEACON)
                .name("<gradient:#00FFFF:#00BFFF>\u2728 Boosts del Clan</gradient>")
                .lore(List.of(
                        "",
                        "<gray>Nivel actual: <yellow>" + level,
                        "<gray>Nombre: <white>" + (currentData != null ? currentData.name() : "N/A"),
                        "",
                        "<gray>Los boosts se aplican autom\u00e1ticamente",
                        "<gray>a todos los miembros del clan."
                ))
                .glow()
                .build());

        if (currentData == null) {
            setItem(22, new ItemBuilder(Material.BARRIER)
                    .name("<gray>Sin boosts activos")
                    .lore(List.of(
                            "",
                            "<gray>Sube de nivel para desbloquear",
                            "<gray>boosts para tu clan."
                    ))
                    .build());
            return;
        }

        // Show current level benefits
        List<String[]> benefits = new ArrayList<>();
        benefits.add(new String[]{"Miembros M\u00e1x", String.valueOf(currentData.maxMembers()), "PLAYER_HEAD"});
        benefits.add(new String[]{"Territorios M\u00e1x", String.valueOf(currentData.maxClaims()), "FILLED_MAP"});
        benefits.add(new String[]{"Alianzas M\u00e1x", String.valueOf(currentData.maxAllies()), "EMERALD"});

        for (int i = 0; i < BOOST_SLOTS.length && i < benefits.size(); i++) {
            String[] benefit = benefits.get(i);
            Material mat = switch (i) {
                case 0 -> Material.PLAYER_HEAD;
                case 1 -> Material.FILLED_MAP;
                case 2 -> Material.EMERALD;
                default -> Material.PAPER;
            };

            setItem(BOOST_SLOTS[i], new ItemBuilder(mat)
                    .name("<aqua>\u2726 " + benefit[0])
                    .lore(List.of(
                            "",
                            "<gray>Valor: <yellow>" + benefit[1],
                            "",
                            "<dark_gray>Se aplica automáticamente."
                    ))
                    .hideFlags()
                    .glow()
                    .build());
        }

        // Upgrade bonuses (if upgrade manager is available)
        var um = plugin.getUpgradeManager();
        if (um != null) {
            var upgrades = um.getAllDefinitions().toArray(new com.ethernova.clans.upgrade.UpgradeManager.UpgradeDefinition[0]);
            int upgradeIdx = 0;
            int[] upgradeSlots = {29, 31, 33};
            for (int i = 0; i < upgradeSlots.length && upgradeIdx < upgrades.length; i++, upgradeIdx++) {
                var def = upgrades[upgradeIdx];
                int lvl = um.getUpgradeLevel(clan, def.id());
                if (lvl <= 0) continue;
                String suffix = def.valueType().equals("percentage") ? "%" : "";
                double val = um.getUpgradeValue(def.id(), lvl);
                setItem(upgradeSlots[i], new ItemBuilder(Material.BLAZE_POWDER)
                        .name("<gold>⬆ " + def.displayName())
                        .lore(List.of(
                                "",
                                "<gray>" + def.description(),
                                "<gray>Nivel: <yellow>" + lvl + "/" + def.maxLevel(),
                                "<gray>Bonus: <green>+" + String.format("%.0f", val) + suffix
                        ))
                        .build());
            }
        }

        // Show next level preview
        int nextLevel = Math.min(level + 1, levelMgr.getMaxLevel());
        if (nextLevel > level) {
            ClanLevelManager.LevelData nextData = levelMgr.getLevelData(nextLevel);
            if (nextData != null) {
                List<String> nextLore = new ArrayList<>();
                nextLore.add("");
                nextLore.add("<gray>Nivel <yellow>" + nextLevel + " <gray>desbloquea:");
                nextLore.add("");
                nextLore.add("<yellow>  + Miembros: " + nextData.maxMembers());
                nextLore.add("<yellow>  + Territorios: " + nextData.maxClaims());
                nextLore.add("<yellow>  + Alianzas: " + nextData.maxAllies());

                setItem(40, new ItemBuilder(Material.NETHER_STAR)
                        .name("<gold>\u2b06 Pr\u00f3ximos Boosts</gold>")
                        .lore(nextLore)
                        .glow()
                        .build());
            }
        }
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        return false;
    }
}
