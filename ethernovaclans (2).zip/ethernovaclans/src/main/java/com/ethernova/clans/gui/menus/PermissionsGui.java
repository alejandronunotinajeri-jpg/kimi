package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanMember;
import com.ethernova.clans.clan.ClanRole;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.SoundUtil;
import com.ethernova.clans.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/**
 * GUI for configuring custom per-clan role permissions.
 * Only accessible by clan leaders.
 *
 * Permissions are stored per-clan and override default role-based checks.
 */
public class PermissionsGui extends AbstractGui {

    /**
     * Default permission definitions.
     */
    private static final List<PermDef> PERM_DEFS = List.of(
            new PermDef("invite",       "Invitar Miembros",     Material.PAPER,            "Permite invitar jugadores al clan"),
            new PermDef("kick",         "Expulsar Miembros",    Material.IRON_BOOTS,       "Permite expulsar miembros del clan"),
            new PermDef("claim",        "Reclamar Territorio",  Material.FILLED_MAP,       "Permite reclamar y liberar chunks"),
            new PermDef("bank.withdraw","Retirar del Banco",    Material.GOLD_INGOT,       "Permite retirar dinero del banco"),
            new PermDef("bank.deposit", "Depositar al Banco",   Material.GOLD_NUGGET,      "Permite depositar dinero al banco"),
            new PermDef("war.declare",  "Declarar Guerras",     Material.NETHERITE_SWORD,  "Permite declarar guerras a otros clanes"),
            new PermDef("ally.request", "Solicitar Alianzas",   Material.EMERALD,          "Permite enviar y aceptar solicitudes de alianza"),
            new PermDef("sethq",        "Definir HQ",           Material.BEACON,           "Permite establecer la base del clan"),
            new PermDef("settings",     "Editar Configuración", Material.COMPARATOR,       "Permite modificar la configuración del clan"),
            new PermDef("promote",      "Promover Miembros",    Material.EXPERIENCE_BOTTLE,"Permite promover a otros miembros"),
            new PermDef("upgrade",      "Comprar Mejoras",      Material.ANVIL,            "Permite comprar mejoras del clan"),
            new PermDef("chat.toggle",  "Toggle Chat Clan",     Material.WRITABLE_BOOK,    "Permite activar/desactivar el chat del clan")
    );

    private record PermDef(String key, String displayName, Material icon, String description) {}

    /**
     * Available minimum role settings (order matters for cycling).
     */
    private static final ClanRole[] ROLE_CYCLE = { ClanRole.RECRUIT, ClanRole.MEMBER, ClanRole.OFFICER, ClanRole.CO_LEADER, ClanRole.LEADER };

    // Slots for each permission (2 rows of 7 max or 3 rows)
    private static final int[] PERM_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25
    };

    public PermissionsGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "permissions");
    }

    @Override
    protected void populateItems() {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return;

        ClanMember member = clan.getMember(player.getUniqueId());
        if (member == null || member.getRole() != ClanRole.LEADER) {
            player.sendMessage(plugin.getConfigManager().getMessage("settings.leader-only-permissions"));
            player.closeInventory();
            return;
        }

        // Header
        ItemStack header = new ItemBuilder(Material.COMMAND_BLOCK)
                .name(plugin.getConfigManager().getMessage("gui.permissions-title"))
                .lore(
                        "",
                        "<gray>Click en cada permiso para cambiar</gray>",
                        "<gray>el rol m\u00ednimo requerido.</gray>",
                        "",
                        "<green>MIEMBRO</green> <dark_gray>\u2192</dark_gray> <aqua>MOD</aqua> <dark_gray>\u2192</dark_gray> <gold>L\u00cdDER</gold>"
                )
                .build();
        setItem(4, header);

        // Permission items
        Map<String, ClanRole> permissions = getPermissions(clan);

        for (int i = 0; i < PERM_DEFS.size() && i < PERM_SLOTS.length; i++) {
            PermDef def = PERM_DEFS.get(i);
            int slot = PERM_SLOTS[i];

            ClanRole minRole = permissions.getOrDefault(def.key(), getDefaultRole(def.key()));
            String roleDisplay = formatRole(minRole);

            boolean glow = minRole == ClanRole.LEADER;

            ItemBuilder builder = new ItemBuilder(def.icon())
                    .name(TextUtil.parse("<yellow>" + def.displayName()))
                    .lore(
                            "",
                            "<gray>" + def.description() + "</gray>",
                            "",
                            "<gray>Rol m\u00ednimo:</gray> " + roleDisplay,
                            "",
                            "<yellow>Click para cambiar</yellow>"
                    );

            if (glow) builder.glow();

            setItem(slot, builder.build());
            slotActions.put(slot, "TOGGLE_PERM:" + def.key());
        }
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (!action.startsWith("TOGGLE_PERM:")) return false;

        String permKey = action.substring("TOGGLE_PERM:".length());
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return true;

        ClanMember member = clan.getMember(player.getUniqueId());
        if (member == null || member.getRole() != ClanRole.LEADER) {
            player.sendMessage(plugin.getConfigManager().getMessage("settings.leader-only-permissions"));
            return true;
        }

        Map<String, ClanRole> permissions = getPermissions(clan);
        ClanRole current = permissions.getOrDefault(permKey, getDefaultRole(permKey));

        // Cycle to next role
        ClanRole next = cycleRole(current);
        permissions.put(permKey, next);
        savePermissions(clan, permissions);

        SoundUtil.click(player);
        refreshGui();

        return true;
    }

    private ClanRole cycleRole(ClanRole current) {
        for (int i = 0; i < ROLE_CYCLE.length; i++) {
            if (ROLE_CYCLE[i] == current) {
                return ROLE_CYCLE[(i + 1) % ROLE_CYCLE.length];
            }
        }
        return ClanRole.MEMBER;
    }

    private String formatRole(ClanRole role) {
        return switch (role) {
            case LEADER -> "<gold>👑 LÍDER</gold>";
            case CO_LEADER -> "<yellow>👑 CO-LÍDER</yellow>";
            case OFFICER -> "<aqua>🛡 OFICIAL</aqua>";
            case MEMBER -> "<green>👤 MIEMBRO</green>";
            case RECRUIT -> "<dark_gray>👤 RECLUTA</dark_gray>";
        };
    }

    private ClanRole getDefaultRole(String key) {
        return switch (key) {
            case "kick", "promote", "war.declare", "settings", "upgrade" -> ClanRole.OFFICER;
            case "sethq" -> ClanRole.LEADER;
            default -> ClanRole.MEMBER;
        };
    }

    // ══════════════════════════════════════════════════════════
    //  PERMISSION STORAGE (persisted to database)
    // ══════════════════════════════════════════════════════════

    @SuppressWarnings("unchecked")
    private Map<String, ClanRole> getPermissions(Clan clan) {
        Map<String, ClanRole> perms = new LinkedHashMap<>();
        Map<String, ClanRole> stored = PERMISSION_CACHE.get(clan.getId());
        if (stored != null) {
            perms.putAll(stored);
        }
        return perms;
    }

    private void savePermissions(Clan clan, Map<String, ClanRole> perms) {
        PERMISSION_CACHE.put(clan.getId(), new LinkedHashMap<>(perms));
        // Persist to database asynchronously
        Map<String, String> serialized = new LinkedHashMap<>();
        for (var entry : perms.entrySet()) {
            serialized.put(entry.getKey(), entry.getValue().name());
        }
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () ->
                plugin.getStorageManager().saveClanPermissions(clan.getId(), serialized));
    }

    /** In-memory permission cache - per clan */
    private static final Map<String, Map<String, ClanRole>> PERMISSION_CACHE = new java.util.concurrent.ConcurrentHashMap<>();

    /**
     * Load all clan permissions from the database into the in-memory cache.
     * Should be called once during plugin startup after clans are loaded.
     */
    public static void loadAllFromDatabase(EthernovaClans plugin) {
        Map<String, Map<String, String>> allPerms = plugin.getStorageManager().loadAllClanPermissions();
        for (var entry : allPerms.entrySet()) {
            Map<String, ClanRole> clanPerms = new LinkedHashMap<>();
            for (var permEntry : entry.getValue().entrySet()) {
                try {
                    clanPerms.put(permEntry.getKey(), ClanRole.valueOf(permEntry.getValue()));
                } catch (IllegalArgumentException ignored) {
                    // Skip invalid role names from DB
                }
            }
            PERMISSION_CACHE.put(entry.getKey(), clanPerms);
        }
        plugin.getLogger().info("  ○ Permissions cache initialized (" + allPerms.size() + " clans)");
    }

    /**
     * Remove cached permissions for a clan (used on disband).
     */
    public static void cleanupClan(String clanId) {
        PERMISSION_CACHE.remove(clanId);
    }

    /**
     * Check if a member has a specific permission in their clan.
     * Can be called from anywhere (commands, GUIs, etc.)
     */
    public static boolean hasPermission(Clan clan, ClanMember member, String permKey) {
        if (member.getRole() == ClanRole.LEADER) return true; // Leader always has all perms

        Map<String, ClanRole> stored = PERMISSION_CACHE.get(clan.getId());
        ClanRole minRole;
        if (stored != null && stored.containsKey(permKey)) {
            minRole = stored.get(permKey);
        } else {
            // Default roles
            minRole = switch (permKey) {
                case "kick", "promote", "war.declare", "settings", "upgrade" -> ClanRole.OFFICER;
                case "sethq" -> ClanRole.LEADER;
                default -> ClanRole.MEMBER;
            };
        }

        return member.getRole().isAtLeast(minRole);
    }

    private void refreshGui() {
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            occupiedSlots.clear();
            slotActions.clear();
            rightClickActions.clear();
            slotConfigs.clear();
            fillBackground();
            placeConfigItems();
            populateItems();
        });
    }
}
