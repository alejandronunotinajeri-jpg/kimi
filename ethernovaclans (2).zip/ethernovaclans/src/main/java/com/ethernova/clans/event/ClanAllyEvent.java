package com.ethernova.clans.event;

import com.ethernova.clans.clan.Clan;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Fired when two clans form an alliance.
 * Cancellable to prevent the alliance.
 */
public class ClanAllyEvent extends Event implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();
    private boolean cancelled = false;

    private final Clan clan;
    private final Clan allyClan;
    private final @Nullable Player initiator;

    public ClanAllyEvent(@NotNull Clan clan, @NotNull Clan allyClan, @Nullable Player initiator) {
        this.clan = clan;
        this.allyClan = allyClan;
        this.initiator = initiator;
    }

    public @NotNull Clan getClan() { return clan; }
    public @NotNull Clan getAllyClan() { return allyClan; }
    public @Nullable Player getInitiator() { return initiator; }

    @Override public boolean isCancelled() { return cancelled; }
    @Override public void setCancelled(boolean cancel) { this.cancelled = cancel; }
    @Override public @NotNull HandlerList getHandlers() { return HANDLERS; }
    public static HandlerList getHandlerList() { return HANDLERS; }
}
