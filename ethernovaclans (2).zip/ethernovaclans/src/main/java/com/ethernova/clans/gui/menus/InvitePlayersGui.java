package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.SoundUtil;
import com.ethernova.clans.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

/**
 * GUI showing online players that can be invited to the clan.
 * Clicking a player head sends an invitation.
 */
public class InvitePlayersGui extends AbstractGui {

    private static final int ITEMS_PER_PAGE = 21; // 3 rows of 7
    private static final int[] ITEM_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34
    };

    private int page = 0;
    private final List<Player> invitablePlayers = new ArrayList<>();

    public InvitePlayersGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "invite-players");
    }

    @Override
    protected void populateItems() {
        loadInvitablePlayers();
        displayPage();
    }

    private void loadInvitablePlayers() {
        invitablePlayers.clear();
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return;

        for (Player online : Bukkit.getOnlinePlayers()) {
            // Skip the viewer
            if (online.getUniqueId().equals(player.getUniqueId())) continue;
            // Skip players already in a clan
            if (plugin.getClanManager().isInClan(online.getUniqueId())) continue;
            // Skip players already invited
            if (clan.hasInvite(online.getUniqueId())) continue;
            invitablePlayers.add(online);
        }

        // Sort by name
        invitablePlayers.sort((a, b) -> a.getName().compareToIgnoreCase(b.getName()));
    }

    private void displayPage() {
        // Clear content slots
        for (int slot : ITEM_SLOTS) {
            inventory.setItem(slot, null);
        }

        int maxPages = getMaxPage();

        // Header
        setItem(4, new ItemBuilder(Material.WRITABLE_BOOK)
                .name("<gradient:#00FF7F:#32CD32>✉ Invitar Jugadores</gradient>")
                .lore(List.of(
                        "",
                        "<gray>Jugadores disponibles: <yellow>" + invitablePlayers.size(),
                        "<gray>Página: <aqua>" + (page + 1) + "/" + maxPages,
                        "",
                        "<gray>Haz click en un jugador para invitarlo."
                ))
                .glow()
                .build());

        if (invitablePlayers.isEmpty()) {
            setItem(22, new ItemBuilder(Material.BARRIER)
                    .name("<gray>No hay jugadores disponibles")
                    .lore(List.of(
                            "",
                            "<dark_gray>No hay jugadores online sin clan",
                            "<dark_gray>que puedan ser invitados."
                    ))
                    .build());
            return;
        }

        int start = page * ITEMS_PER_PAGE;
        int end = Math.min(start + ITEMS_PER_PAGE, invitablePlayers.size());

        for (int i = start; i < end; i++) {
            int slotIdx = i - start;
            if (slotIdx >= ITEM_SLOTS.length) break;
            int slot = ITEM_SLOTS[slotIdx];

            Player target = invitablePlayers.get(i);
            setItem(slot, new ItemBuilder(Material.PLAYER_HEAD)
                    .name("<green>" + target.getName())
                    .lore(List.of(
                            "",
                            "<gray>Nivel: <white>" + target.getLevel(),
                            "",
                            "<yellow>▶ Click para invitar"
                    ))
                    .skull(target.getPlayerProfile())
                    .build());
            slotActions.put(slot, "INVITE:" + target.getName());
        }

        // Page info
        setItem(49, new ItemBuilder(Material.PAPER)
                .name("<yellow>Página " + (page + 1) + "/" + maxPages)
                .lore(List.of("", "<gray>Total disponibles: <white>" + invitablePlayers.size()))
                .build());

        // Prev page
        if (page > 0) {
            setItem(45, new ItemBuilder(Material.ARROW)
                    .name("<yellow>← Página anterior")
                    .build());
            slotActions.put(45, "PREV_PAGE");
        }

        // Next page
        if (page < maxPages - 1) {
            setItem(53, new ItemBuilder(Material.ARROW)
                    .name("<yellow>Página siguiente →")
                    .build());
            slotActions.put(53, "NEXT_PAGE");
        }
    }

    private int getMaxPage() {
        return Math.max(1, (int) Math.ceil((double) invitablePlayers.size() / ITEMS_PER_PAGE));
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.startsWith("INVITE:")) {
            String targetName = action.substring("INVITE:".length());
            Player target = Bukkit.getPlayerExact(targetName);
            Clan clan = plugin.getClanManager().getClanByPlayer(player);

            if (target == null || !target.isOnline()) {
                player.sendMessage(plugin.getConfigManager().getMessage("error.player-not-online"));
                SoundUtil.error(player);
                refreshGui();
                return true;
            }

            if (clan == null) {
                SoundUtil.error(player);
                return true;
            }

            // Permission check
            if (!plugin.getClanManager().hasPermission(clan, player.getUniqueId(), "invite")) {
                player.sendMessage(plugin.getConfigManager().getMessage("general.no-permission"));
                SoundUtil.error(player);
                return true;
            }

            boolean success = true;
            try {
                plugin.getClanManager().invitePlayer(player, clan, target);
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Error inviting player " + targetName, e);
                success = false;
            }
            if (success) {
                SoundUtil.success(player);
            } else {
                SoundUtil.error(player);
            }
            refreshGui();
            return true;
        }

        // Handle OPEN_GUI: actions explicitly so back-to-menu always works
        if (action.toUpperCase().startsWith("OPEN_GUI:")) {
            String guiName = action.substring("OPEN_GUI:".length());
            plugin.getServer().getScheduler().runTask(plugin, () ->
                    plugin.getGuiManager().openGui(player, guiName));
            return true;
        }

        return switch (action.toUpperCase()) {
            case "PREV_PAGE" -> {
                if (page > 0) { page--; refreshGui(); }
                yield true;
            }
            case "NEXT_PAGE" -> {
                if (page < getMaxPage() - 1) { page++; refreshGui(); }
                yield true;
            }
            case "BACK" -> {
                plugin.getServer().getScheduler().runTask(plugin, () ->
                        plugin.getGuiManager().openMembers(player));
                yield true;
            }
            default -> false;
        };
    }

    private void refreshGui() {
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            occupiedSlots.clear();
            slotActions.clear();
            rightClickActions.clear();
            slotConfigs.clear();
            fillBackground();
            placeConfigItems();
            populateItems();
        });
    }
}
