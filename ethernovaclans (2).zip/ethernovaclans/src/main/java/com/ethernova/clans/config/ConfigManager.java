package com.ethernova.clans.config;

import com.ethernova.clans.EthernovaClans;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ConfigManager {

    private final JavaPlugin plugin;
    private FileConfiguration config;
    private final MiniMessage mini = MiniMessage.miniMessage();

    public ConfigManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void loadAllConfigs() {
        File configFile = new File(plugin.getDataFolder(), "config.yml");
        boolean existed = configFile.exists();

        // Solo crea si no existe — nunca sobreescribe
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        config = plugin.getConfig();

        if (existed) {
            plugin.getLogger().info("config.yml existente cargado (no se sobreescribió)");
            // Merge: agrega claves nuevas del default sin tocar las del usuario
            mergeDefaults(configFile);
        } else {
            plugin.getLogger().info("config.yml creado por primera vez con valores por defecto");
        }
    }

    /**
     * Merge missing default keys into an existing user config.
     * Preserves ALL user values. Only adds keys present in the JAR
     * default but missing from the user's file.
     */
    private void mergeDefaults(File configFile) {
        try (InputStream defStream = plugin.getResource("config.yml")) {
            if (defStream == null) return;
            YamlConfiguration defaults = YamlConfiguration.loadConfiguration(
                    new InputStreamReader(defStream, StandardCharsets.UTF_8));

            Set<String> allDefaultKeys = defaults.getKeys(true);
            int added = 0;
            for (String key : allDefaultKeys) {
                if (!config.contains(key)) {
                    config.set(key, defaults.get(key));
                    added++;
                }
            }
            if (added > 0) {
                plugin.saveConfig();
                plugin.reloadConfig();
                config = plugin.getConfig();
                plugin.getLogger().info("config.yml actualizado: " + added + " clave(s) nueva(s) añadida(s)");
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error al hacer merge de config defaults", e);
        }
    }

    public FileConfiguration getConfig() { return config; }

    // ── Config convenience delegates ─────────────────────────

    public void set(String path, Object value) {
        config.set(path, value);
        plugin.saveConfig(); // Persistir cambio a disco inmediatamente
    }

    /** Reload config from disk (e.g. after external edit). */
    public void reload() {
        loadAllConfigs();
    }

    public double getDouble(String path, double def) {
        return config.getDouble(path, def);
    }

    public int getInt(String path, int def) {
        return config.getInt(path, def);
    }

    public String getString(String path, String def) {
        return config.getString(path, def);
    }

    public boolean getBoolean(String path, boolean def) {
        return config.getBoolean(path, def);
    }

    // ── Message helpers (delegate to MessageManager) ─────────

    /**
     * Get a formatted Component from the message files.
     * Replacement pairs: "key", "value" → replaces {key} with value.
     */
    public Component getMessage(String path, String... replacements) {
        if (plugin instanceof EthernovaClans clans && clans.getMessageManager() != null) {
            // Wrap bare keys in {} so MessageManager replace works
            String[] fixed = new String[replacements.length];
            for (int i = 0; i < replacements.length; i++) {
                if (i % 2 == 0 && !replacements[i].startsWith("{")) {
                    fixed[i] = "{" + replacements[i] + "}";
                } else {
                    fixed[i] = replacements[i];
                }
            }
            return clans.getMessageManager().parse(
                    clans.getMessageManager().get(path, fixed));
        }
        return mini.deserialize("<red>[" + path + "]</red>");
    }

    /**
     * Get a raw (unparsed) MiniMessage string from the message files.
     * Useful when you need the string template before Component parsing.
     */
    public String getRawMessage(String path, String... replacements) {
        if (plugin instanceof EthernovaClans clans && clans.getMessageManager() != null) {
            String msg = clans.getMessageManager().get(path);
            for (int i = 0; i + 1 < replacements.length; i += 2) {
                msg = msg.replace("{" + replacements[i] + "}", replacements[i + 1]);
            }
            return msg;
        }
        return path;
    }

    // ── GUI Config ───────────────────────────────────────

    /**
     * Get a GUI configuration section by key.
     * Loads from individual YAML files via ConfigurableGUI.
     */
    public org.bukkit.configuration.ConfigurationSection getGuiConfig(String guiKey) {
        if (plugin instanceof EthernovaClans clans && clans.getConfigurableGUI() != null) {
            return clans.getConfigurableGUI().getConfig(guiKey);
        }
        return null;
    }

    // ── Time parsing ─────────────────────────────────────────

    private static final Pattern TIME_PATTERN = Pattern.compile("(\\d+)([smhdw])");

    /**
     * Parse a time string like "5m", "1h30m", "2d" into milliseconds.
     */
    public long parseTimeToMillis(String time) {
        if (time == null || time.isEmpty()) return 300_000L; // 5min default
        Matcher m = TIME_PATTERN.matcher(time.toLowerCase());
        long total = 0;
        while (m.find()) {
            long val = Long.parseLong(m.group(1));
            total += switch (m.group(2)) {
                case "s" -> val * 1000L;
                case "m" -> val * 60_000L;
                case "h" -> val * 3_600_000L;
                case "d" -> val * 86_400_000L;
                case "w" -> val * 604_800_000L;
                default -> 0L;
            };
        }
        return total > 0 ? total : 300_000L;
    }
}
