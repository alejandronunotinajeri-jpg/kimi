package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanMember;
import com.ethernova.clans.clan.ClanRole;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.shop.ClanShopManager;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.SoundUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.List;

/**
 * Clan internal shop GUI.
 * Members can buy items, officers can add/remove items.
 */
public class ClanShopGui extends AbstractGui {

    private int page = 0;
    private static final int[] ITEM_SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};

    public ClanShopGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "clan-shop");
    }

    @Override
    protected void populateItems() {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return;

        ClanShopManager shopMgr = plugin.getShopManager();
        if (shopMgr == null) return;

        List<ClanShopManager.ShopItem> items = shopMgr.getShopItems(clan.getId());

        // Header
        setItem(4, new ItemBuilder(Material.CHEST)
                .name("<gradient:#FFD700:#FF6B35>🏪 Tienda del Clan</gradient>")
                .lore(List.of(
                        "",
                        "<gray>Items disponibles: <white>" + items.size(),
                        "<gray>Banco del clan: <green>$" + String.format("%.2f", clan.getBank().getBalance()),
                        "",
                        "<gray>Las ganancias van al banco del clan."
                ))
                .build());

        // Display items (paginated)
        int start = page * ITEM_SLOTS.length;
        for (int i = 0; i < ITEM_SLOTS.length; i++) {
            int idx = start + i;
            if (idx >= items.size()) break;

            ClanShopManager.ShopItem item = items.get(idx);
            int slot = ITEM_SLOTS[i];

            setItem(slot, new ItemBuilder(item.material())
                    .name("<yellow>" + item.displayName())
                    .lore(List.of(
                            "",
                            "<gray>Precio: <green>$" + String.format("%.2f", item.price()),
                            "<gray>Stock: <white>" + item.stock() + "/" + item.maxStock(),
                            "<gray>Añadido por: <white>" + item.addedBy(),
                            "",
                            item.stock() > 0 ? "<green>Click izquierdo → Comprar" : "<red>Sin stock",
                            "<red>Click derecho → Eliminar (oficiales)"
                    ))
                    .amount(Math.max(1, Math.min(64, item.stock())))
                    .build());
            slotActions.put(slot, "BUY:" + item.id());
            rightClickActions.put(slot, "REMOVE:" + item.id());
        }

        // Pagination
        if (page > 0) {
            setItem(45, new ItemBuilder(Material.ARROW).name("<yellow>← Anterior").build());
            slotActions.put(45, "PREV_PAGE");
        }
        if (start + ITEM_SLOTS.length < items.size()) {
            setItem(53, new ItemBuilder(Material.ARROW).name("<yellow>Siguiente →").build());
            slotActions.put(53, "NEXT_PAGE");
        }

        // Add item button (officers+)
        ClanMember member = clan.getMember(player.getUniqueId());
        if (member != null && member.getRole().isAtLeast(ClanRole.OFFICER)) {
            setItem(49, new ItemBuilder(Material.EMERALD)
                    .name("<green>+ Agregar Item")
                    .lore(List.of(
                            "<gray>Pon un item a la venta.",
                            "<gray>Se te pedirá material, precio y cantidad."
                    ))
                    .build());
            slotActions.put(49, "ADD_ITEM");
        }
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return false;

        ClanShopManager shopMgr = plugin.getShopManager();
        if (shopMgr == null) return false;

        if (action.startsWith("BUY:")) {
            String itemId = action.substring("BUY:".length());
            if (shopMgr.buyItem(clan, player, itemId)) {
                SoundUtil.success(player);
                player.sendMessage(plugin.getConfigManager().getMessage("gui.shop-purchase-success"));
            } else {
                SoundUtil.error(player);
                player.sendMessage(plugin.getConfigManager().getMessage("gui.shop-purchase-failed"));
            }
            refreshGui();
            return true;
        }

        if (action.startsWith("REMOVE:")) {
            String itemId = action.substring("REMOVE:".length());
            ClanMember member = clan.getMember(player.getUniqueId());
            if (member == null || !member.getRole().isAtLeast(ClanRole.OFFICER)) {
                player.sendMessage(plugin.getConfigManager().getMessage("gui.shop-no-permission-remove"));
                return true;
            }
            if (shopMgr.removeItem(clan, itemId)) {
                SoundUtil.click(player);
                player.sendMessage(plugin.getConfigManager().getMessage("gui.shop-item-removed"));
            }
            refreshGui();
            return true;
        }

        if (action.equals("ADD_ITEM")) {
            player.closeInventory();
            player.sendMessage(plugin.getConfigManager().getMessage("gui.shop-enter-material"));
            plugin.getGuiManager().registerAnvilInput(player, materialInput -> {
                Material mat;
                try { mat = Material.valueOf(materialInput.toUpperCase()); }
                catch (Exception e) {
                    player.sendMessage(plugin.getConfigManager().getMessage("gui.shop-invalid-material",
                            "input", materialInput));
                    plugin.getServer().getScheduler().runTask(plugin, () -> plugin.getGuiManager().openGui(player, "clan-shop"));
                    return;
                }
                player.sendMessage(plugin.getConfigManager().getMessage("gui.shop-enter-price"));
                plugin.getGuiManager().registerAnvilInput(player, priceInput -> {
                    double price;
                    try { price = Double.parseDouble(priceInput); }
                    catch (Exception e) {
                        player.sendMessage(plugin.getConfigManager().getMessage("gui.shop-invalid-price"));
                        return;
                    }
                    if (price <= 0) {
                        player.sendMessage(plugin.getConfigManager().getMessage("gui.shop-price-positive"));
                        return;
                    }
                    player.sendMessage(plugin.getConfigManager().getMessage("gui.shop-enter-stock"));
                    plugin.getGuiManager().registerAnvilInput(player, stockInput -> {
                        int stock;
                        try { stock = Integer.parseInt(stockInput); }
                        catch (Exception e) {
                            player.sendMessage(plugin.getConfigManager().getMessage("gui.shop-invalid-stock"));
                            return;
                        }
                        if (stock <= 0) {
                            player.sendMessage(plugin.getConfigManager().getMessage("gui.shop-stock-positive"));
                            return;
                        }
                        Clan c = plugin.getClanManager().getClanByPlayer(player);
                        if (c != null && shopMgr.addItem(c, player, mat, mat.name(), price, stock)) {
                            player.sendMessage(plugin.getConfigManager().getMessage("gui.shop-item-added",
                                    "material", mat.name(), "stock", String.valueOf(stock), "price", String.valueOf(price)));
                        }
                        plugin.getServer().getScheduler().runTask(plugin, () -> plugin.getGuiManager().openGui(player, "clan-shop"));
                    });
                });
            });
            return true;
        }

        return switch (action.toUpperCase()) {
            case "PREV_PAGE" -> { page = Math.max(0, page - 1); refreshGui(); yield true; }
            case "NEXT_PAGE" -> { page++; refreshGui(); yield true; }
            default -> false;
        };
    }

    private void refreshGui() {
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            occupiedSlots.clear();
            slotActions.clear();
            rightClickActions.clear();
            slotConfigs.clear();
            fillBackground();
            placeConfigItems();
            populateItems();
        });
    }
}
