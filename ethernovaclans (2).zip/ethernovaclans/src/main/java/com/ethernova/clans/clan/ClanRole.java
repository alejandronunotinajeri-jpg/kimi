package com.ethernova.clans.clan;

/**
 * Represents a role within a clan.
 * Each role has a priority level for permission hierarchy.
 */
public enum ClanRole {

    RECRUIT("recluta", 0, "👤"),
    MEMBER("miembro", 1, "👤"),
    OFFICER("oficial", 2, "🛡️"),
    CO_LEADER("co-líder", 3, "👑"),
    LEADER("líder", 4, "👑");

    private final String id;
    private final int priority;
    private final String icon;

    ClanRole(String id, int priority, String icon) {
        this.id = id;
        this.priority = priority;
        this.icon = icon;
    }

    public String getId() {
        return id;
    }

    public int getPriority() {
        return priority;
    }

    public String getIcon() {
        return icon;
    }

    /**
     * Check if this role is higher or equal to another role.
     */
    public boolean isAtLeast(ClanRole other) {
        return this.priority >= other.priority;
    }

    /**
     * Check if this role is strictly higher than another.
     */
    public boolean isHigherThan(ClanRole other) {
        return this.priority > other.priority;
    }

    /**
     * Get role from config id string.
     */
    public static ClanRole fromId(String id) {
        for (ClanRole role : values()) {
            if (role.id.equalsIgnoreCase(id)) {
                return role;
            }
        }
        return MEMBER;
    }

    /**
     * Get the next role up in hierarchy.
     */
    public ClanRole promote() {
        ClanRole next = next();
        return next != null ? next : this;
    }

    /**
     * Get the next role down in hierarchy.
     */
    public ClanRole demote() {
        ClanRole prev = previous();
        return prev != null ? prev : this;
    }

    public ClanRole next() {
        int next = ordinal() + 1;
        if (next >= values().length) return null;
        return values()[next];
    }

    public ClanRole previous() {
        int prev = ordinal() - 1;
        if (prev < 0) return null;
        return values()[prev];
    }

    public String getDisplayName() {
        return switch (this) {
            case RECRUIT -> "Recluta";
            case MEMBER -> "Miembro";
            case OFFICER -> "Oficial";
            case CO_LEADER -> "Co-Líder";
            case LEADER -> "Líder";
        };
    }
}
