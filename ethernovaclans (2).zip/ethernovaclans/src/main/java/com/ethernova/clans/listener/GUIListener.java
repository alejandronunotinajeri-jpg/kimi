package com.ethernova.clans.listener;

import com.ethernova.clans.EthernovaClans;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

public class GUIListener implements Listener {

    private final EthernovaClans plugin;

    public GUIListener(EthernovaClans plugin) { this.plugin = plugin; }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (plugin.getGuiManager().isInMenu(player.getUniqueId())) {
            plugin.getGuiManager().handleClick(event);
        }
    }

    /**
     * Prevent item dragging into GUI menus — blocks item duplication/loss exploit.
     */
    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (plugin.getGuiManager().isInMenu(player.getUniqueId())) {
            // Cancel if any dragged slot is in the top (GUI) inventory
            int topSize = event.getView().getTopInventory().getSize();
            for (int slot : event.getRawSlots()) {
                if (slot < topSize) {
                    event.setCancelled(true);
                    return;
                }
            }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (event.getPlayer() instanceof Player player) {
            plugin.getGuiManager().handleClose(player, event.getInventory());
        }
    }
}
