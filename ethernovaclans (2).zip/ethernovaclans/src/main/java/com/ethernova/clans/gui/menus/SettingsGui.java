package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanRole;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.SoundUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

/**
 * Settings GUI for clan configuration (name, tag, colors, pvp, invites, etc.).
 */
public class SettingsGui extends AbstractGui {

    public SettingsGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "settings");
    }

    @Override
    protected void populateItems() {
        // Config items handle display; dynamic state already replaced via placeholders
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return false;

        // Handle YAML-based prefix actions
        if (action.startsWith("ANVIL_INPUT:")) {
            String suffix = action.substring("ANVIL_INPUT:".length());
            switch (suffix) {
                case "change-name" -> {
                    if (!checkRole(clan, ClanRole.CO_LEADER)) return true;
                    promptInput("name");
                }
                case "change-tag" -> {
                    if (!checkRole(clan, ClanRole.CO_LEADER)) return true;
                    promptInput("tag");
                }
                case "change-description" -> {
                    if (!checkRole(clan, ClanRole.CO_LEADER)) return true;
                    promptInput("description");
                }
                case "change-icon" -> promptInput("icon");
                default -> { return false; }
            }
            return true;
        }

        if (action.startsWith("TOGGLE_SETTING:")) {
            String suffix = action.substring("TOGGLE_SETTING:".length());
            switch (suffix) {
                case "friendly-fire" -> {
                    if (!checkRole(clan, ClanRole.LEADER)) return true;
                    clan.setFriendlyFire(!clan.isFriendlyFire());
                    player.sendMessage(plugin.getConfigManager().getMessage(
                            clan.isFriendlyFire() ? "settings.pvp-enabled" : "settings.pvp-disabled"));
                    refreshGui();
                }
                case "clan-chat" -> {
                    if (!checkRole(clan, ClanRole.OFFICER)) return true;
                    clan.setClanChatEnabled(!clan.isClanChatEnabled());
                    refreshGui();
                }
                case "war-participation" -> {
                    if (!checkRole(clan, ClanRole.LEADER)) return true;
                    clan.setWarParticipation(!clan.isWarParticipation());
                    player.sendMessage(plugin.getConfigManager().getMessage(
                            clan.isWarParticipation() ? "settings.war-enabled" : "settings.war-disabled"));
                    refreshGui();
                }
                default -> { return false; }
            }
            return true;
        }

        if (action.startsWith("CYCLE_SETTING:")) {
            String suffix = action.substring("CYCLE_SETTING:".length());
            if (suffix.equals("invite-mode")) {
                if (!checkRole(clan, ClanRole.OFFICER)) return true;
                // 3-way cycle: open -> invite -> closed -> open
                String current = clan.getInviteMode() != null ? clan.getInviteMode() : "invite";
                String next = switch (current) {
                    case "open" -> "invite";
                    case "invite" -> "closed";
                    default -> "open";
                };
                clan.setInviteMode(next);
                player.sendMessage(plugin.getConfigManager().getMessage(
                        "settings.invite-mode-" + next, "mode", next));
                refreshGui();
                return true;
            }
            return false;
        }

        if (action.startsWith("CONFIRM:")) {
            String suffix = action.substring("CONFIRM:".length());
            if (suffix.equals("disband")) {
                if (!checkRole(clan, ClanRole.LEADER)) return true;
                promptInput("disband");
                return true;
            }
            return false;
        }

        if (action.equals("OPEN_GUI:transfer-selector")) {
            if (!checkRole(clan, ClanRole.LEADER)) return true;
            promptInput("transfer");
            return true;
        }

        // Handle legacy action strings
        return switch (action.toUpperCase()) {
            case "CHANGE_NAME" -> {
                if (!checkRole(clan, ClanRole.CO_LEADER)) yield true;
                promptInput("name");
                yield true;
            }
            case "CHANGE_TAG" -> {
                if (!checkRole(clan, ClanRole.CO_LEADER)) yield true;
                promptInput("tag");
                yield true;
            }
            case "CHANGE_DESCRIPTION" -> {
                if (!checkRole(clan, ClanRole.CO_LEADER)) yield true;
                promptInput("description");
                yield true;
            }
            case "CHANGE_ICON" -> {
                if (!checkRole(clan, ClanRole.LEADER)) yield true;
                promptInput("icon");
                yield true;
            }
            case "OPEN_COLOR_PICKER" -> {
                plugin.getGuiManager().openColorPicker(player);
                yield true;
            }
            case "TOGGLE_PVP" -> {
                if (!checkRole(clan, ClanRole.LEADER)) yield true;
                clan.setFriendlyFire(!clan.isFriendlyFire());
                player.sendMessage(plugin.getConfigManager().getMessage(
                        clan.isFriendlyFire() ? "settings.pvp-enabled" : "settings.pvp-disabled"));
                refreshGui();
                yield true;
            }
            case "TOGGLE_INVITES" -> {
                if (!checkRole(clan, ClanRole.OFFICER)) yield true;
                clan.setInviteMode(clan.isInviteOpen() ? "invite" : "open");
                player.sendMessage(plugin.getConfigManager().getMessage(
                        clan.isInviteOpen() ? "settings.invites-open" : "settings.invites-closed"));
                refreshGui();
                yield true;
            }
            case "TOGGLE_CHAT" -> {
                if (!checkRole(clan, ClanRole.OFFICER)) yield true;
                clan.setClanChatEnabled(!clan.isClanChatEnabled());
                refreshGui();
                yield true;
            }
            case "TOGGLE_WAR" -> {
                if (!checkRole(clan, ClanRole.LEADER)) yield true;
                clan.setWarParticipation(!clan.isWarParticipation());
                player.sendMessage(plugin.getConfigManager().getMessage(
                        clan.isWarParticipation() ? "settings.war-enabled" : "settings.war-disabled"));
                refreshGui();
                yield true;
            }
            case "TRANSFER_LEADERSHIP" -> {
                if (!checkRole(clan, ClanRole.LEADER)) yield true;
                promptInput("transfer");
                yield true;
            }
            case "DISBAND_CLAN" -> {
                if (!checkRole(clan, ClanRole.LEADER)) yield true;
                promptInput("disband");
                yield true;
            }
            default -> false;
        };
    }

    private boolean checkRole(Clan clan, ClanRole required) {
        var member = clan.getMember(player.getUniqueId());
        if (member == null || !member.getRole().isAtLeast(required)) {
            player.sendMessage(plugin.getConfigManager().getMessage("general.no-permission"));
            SoundUtil.error(player);
            return false;
        }
        return true;
    }

    private void promptInput(String type) {
        player.closeInventory();

        String messageKey = switch (type) {
            case "name" -> "settings.enter-name";
            case "tag" -> "settings.enter-tag";
            case "description" -> "settings.enter-description";
            case "transfer" -> "settings.enter-transfer-player";
            case "disband" -> "settings.confirm-disband";
            case "icon" -> "settings.enter-icon";
            default -> "settings.enter-value";
        };

        player.sendMessage(plugin.getConfigManager().getMessage(messageKey));

        plugin.getGuiManager().registerAnvilInput(player, input -> {
            Clan clan = plugin.getClanManager().getClanByPlayer(player);
            if (clan == null) return;

            switch (type) {
                case "name" -> plugin.getClanManager().changeName(clan, input, player);
                case "tag" -> plugin.getClanManager().changeTag(clan, input, player);
                case "description" -> {
                    clan.setDescription(input);
                    player.sendMessage(plugin.getConfigManager().getMessage("settings.description-changed",
                            "description", input));
                }
                case "icon" -> {
                    try {
                        org.bukkit.Material mat = org.bukkit.Material.valueOf(input.toUpperCase().replace(" ", "_"));
                        clan.setIcon(mat.name());
                        player.sendMessage(plugin.getConfigManager().getMessage("settings.icon-changed",
                                "icon", mat.name()));
                    } catch (IllegalArgumentException e) {
                        player.sendMessage(plugin.getConfigManager().getMessage("settings.invalid-icon"));
                    }
                }
                case "transfer" -> {
                    var target = plugin.getServer().getPlayer(input);
                    if (target == null || !clan.isMember(target.getUniqueId())) {
                        player.sendMessage(plugin.getConfigManager().getMessage("settings.player-not-found"));
                        return;
                    }
                    plugin.getClanManager().transferLeadership(clan, player.getUniqueId(), target.getUniqueId());
                }
                case "disband" -> {
                    if (input.equalsIgnoreCase("confirm") || input.equalsIgnoreCase(clan.getName())) {
                        plugin.getClanManager().disbandClan(clan, player);
                        return; // Don't reopen GUI
                    } else {
                        player.sendMessage(plugin.getConfigManager().getMessage("settings.disband-cancelled"));
                    }
                }
            }

            // Reopen settings
            if (!type.equals("disband")) {
                plugin.getServer().getScheduler().runTask(plugin, () ->
                        plugin.getGuiManager().openSettings(player));
            }
        });
    }

    private void refreshGui() {
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            occupiedSlots.clear();
            slotActions.clear();
            rightClickActions.clear();
            slotConfigs.clear();
            fillBackground();
            placeConfigItems();
            populateItems();
        });
    }
}
