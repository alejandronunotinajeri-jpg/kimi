package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.SoundUtil;
import com.ethernova.clans.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.time.Duration;
import java.time.Instant;
import java.util.*;

/**
 * GUI showing pending clan invitations with accept/deny and expiry timers.
 * This shows invitations FROM other clans TO the viewing player.
 */
public class InvitationsGui extends AbstractGui {

    private static final int ITEMS_PER_PAGE = 21; // 3 rows of 7
    private static final int[] ITEM_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34
    };

    private int page = 0;
    private final List<InviteEntry> invites = new ArrayList<>();

    private record InviteEntry(Clan clan, Instant expiry) {}

    public InvitationsGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "invitations");
    }

    @Override
    protected void populateItems() {
        loadInvites();
        displayPage();
    }

    private void loadInvites() {
        invites.clear();
        UUID playerUuid = player.getUniqueId();

        for (Clan clan : plugin.getClanManager().getAllClans()) {
            if (clan.hasInvite(playerUuid)) {
                Instant expiry = clan.getPendingInvites().get(playerUuid);
                if (expiry != null && expiry.isAfter(Instant.now())) {
                    invites.add(new InviteEntry(clan, expiry));
                }
            }
        }

        // Sort by expiry (soonest first)
        invites.sort(Comparator.comparing(InviteEntry::expiry));
    }

    private void displayPage() {
        // Clear previous items
        for (int slot : ITEM_SLOTS) {
            inventory.setItem(slot, null);
        }

        int start = page * ITEMS_PER_PAGE;
        int end = Math.min(start + ITEMS_PER_PAGE, invites.size());

        for (int i = start; i < end; i++) {
            int slotIdx = i - start;
            if (slotIdx >= ITEM_SLOTS.length) break;
            int slot = ITEM_SLOTS[slotIdx];

            InviteEntry entry = invites.get(i);
            Clan clan = entry.clan();
            Instant expiry = entry.expiry();

            Duration remaining = Duration.between(Instant.now(), expiry);
            String timeStr = formatDuration(remaining);

            String statusColor = remaining.toMinutes() < 5 ? "<red>" : "<green>";

            ItemStack item = new ItemBuilder(Material.PAPER)
                    .name(plugin.getConfigManager().getMessage("gui.invitation-item-name",
                            "clan", clan.getName()))
                    .lore(List.of(
                            "",
                            "<gray>Tag:</gray> " + clan.getFormattedTag(),
                            "<gray>Nivel:</gray> <yellow>" + clan.getLevel() + "</yellow>",
                            "<gray>Miembros:</gray> <aqua>" + clan.getMemberCount() + "</aqua>",
                            "<gray>Power:</gray> <gold>" + clan.getPower() + "</gold>",
                            "",
                            "<gray>Expira en:</gray> " + statusColor + timeStr,
                            "",
                            "<green>\u25b6 Click izquierdo = ACEPTAR</green>",
                            "<red>\u25b6 Click derecho = RECHAZAR</red>"
                    ))
                    .build();

            setItem(slot, item);
            slotActions.put(slot, "ACCEPT_INVITE:" + clan.getId());
            rightClickActions.put(slot, "DENY_INVITE:" + clan.getId());
        }

        // Empty state
        if (invites.isEmpty()) {
            ItemStack empty = new ItemBuilder(Material.STRUCTURE_VOID)
                    .name(plugin.getConfigManager().getMessage("gui.no-invitations"))
                    .lore(
                            "",
                            "<dark_gray>No tienes invitaciones activas.</dark_gray>",
                            "<dark_gray>Pide a un l\u00edder de clan que te invite.</dark_gray>"
                    )
                    .build();
            setItem(22, empty);
        }

        // Header
        ItemStack header = new ItemBuilder(Material.BELL)
                .name(plugin.getConfigManager().getMessage("gui.invitations-title"))
                .lore(
                        "",
                        "<gray>Total:</gray> <yellow>" + invites.size() + "</yellow>",
                        "<gray>P\u00e1gina:</gray> <aqua>" + (page + 1) + "/" + getMaxPage() + "</aqua>"
                )
                .build();
        setItem(4, header);

        // Pagination buttons
        int maxPage = getMaxPage();

        if (page > 0) {
            ItemStack prev = new ItemBuilder(Material.ARROW)
                    .name(plugin.getConfigManager().getMessage("gui.previous-page"))
                    .build();
            setItem(45, prev);
            slotActions.put(45, "PREV_PAGE");
        }

        if (page < maxPage - 1) {
            ItemStack next = new ItemBuilder(Material.ARROW)
                    .name(plugin.getConfigManager().getMessage("gui.next-page"))
                    .build();
            setItem(53, next);
            slotActions.put(53, "NEXT_PAGE");
        }
    }

    private int getMaxPage() {
        return Math.max(1, (int) Math.ceil((double) invites.size() / ITEMS_PER_PAGE));
    }

    private String formatDuration(Duration duration) {
        if (duration.isNegative()) return "Expirado";
        long hours = duration.toHours();
        long minutes = duration.toMinutesPart();
        if (hours > 0) return hours + "h " + minutes + "m";
        long seconds = duration.toSecondsPart();
        return minutes + "m " + seconds + "s";
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.equals("PREV_PAGE")) {
            if (page > 0) {
                page--;
                refreshGui();
            }
            return true;
        }

        if (action.equals("NEXT_PAGE")) {
            if (page < getMaxPage() - 1) {
                page++;
                refreshGui();
            }
            return true;
        }

        if (action.startsWith("ACCEPT_INVITE:")) {
            String clanIdStr = action.substring("ACCEPT_INVITE:".length());
            try {
                Clan clan = plugin.getClanManager().getClanById(clanIdStr);
                if (clan != null && clan.hasInvite(player.getUniqueId())) {
                    // Check if player is already in a clan
                    if (plugin.getClanManager().isInClan(player.getUniqueId())) {
                        player.sendMessage(plugin.getConfigManager().getMessage("error.already-in-clan"));
                        SoundUtil.error(player);
                        return true;
                    }
                    clan.removeInvite(player.getUniqueId());
                    plugin.getClanManager().addMember(clan, player);
                    player.sendMessage(plugin.getConfigManager().getMessage("clan.joined",
                            "clan", clan.getName()));
                    SoundUtil.success(player);
                    player.closeInventory();
                } else {
                    player.sendMessage(plugin.getConfigManager().getMessage("clan.invite-expired"));
                    SoundUtil.error(player);
                    refreshGui();
                }
            } catch (Exception e) {
                SoundUtil.error(player);
            }
            return true;
        }

        if (action.startsWith("DENY_INVITE:")) {
            String clanIdStr = action.substring("DENY_INVITE:".length());
            try {
                Clan clan = plugin.getClanManager().getClanById(clanIdStr);
                if (clan != null) {
                    clan.removeInvite(player.getUniqueId());
                    player.sendMessage(plugin.getConfigManager().getMessage("invite.rejected",
                            "clan", clan.getName()));
                    SoundUtil.click(player);
                    refreshGui();
                }
            } catch (Exception ignored) {}
            return true;
        }

        return false;
    }

    private void refreshGui() {
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            occupiedSlots.clear();
            slotActions.clear();
            rightClickActions.clear();
            slotConfigs.clear();
            fillBackground();
            placeConfigItems();
            loadInvites();
            displayPage();
        });
    }
}
