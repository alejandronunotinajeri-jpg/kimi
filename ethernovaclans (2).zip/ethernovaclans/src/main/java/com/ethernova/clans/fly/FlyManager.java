package com.ethernova.clans.fly;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanManager;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages clan fly permissions in claimed territory.
 * Players can toggle flight in their own territory.
 */
public class FlyManager {

    private final EthernovaClans plugin;

    /** Players who have clan fly enabled */
    private final Set<UUID> flyingPlayers = ConcurrentHashMap.newKeySet();

    public FlyManager(EthernovaClans plugin) {
        this.plugin = plugin;
    }

    /**
     * Toggle fly for a player.
     */
    public void toggleFly(Player player) {
        if (!plugin.getConfigManager().getBoolean("claims.fly.enabled", true)
                || !plugin.getCoreHook().hasTerritory()) {
            player.sendMessage(plugin.getConfigManager().getMessage("fly.feature-disabled"));
            return;
        }

        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) {
            player.sendMessage(plugin.getConfigManager().getMessage("clan.not-in-clan"));
            return;
        }

        // Check level requirement
        int requiredLevel = plugin.getConfigManager().getInt("claims.fly.min-level", 3);
        if (clan.getLevel() < requiredLevel) {
            player.sendMessage(plugin.getConfigManager().getMessage("fly.level-required",
                    "level", String.valueOf(requiredLevel)));
            return;
        }

        if (flyingPlayers.contains(player.getUniqueId())) {
            // Disable fly
            disableFly(player);
            player.sendMessage(plugin.getConfigManager().getMessage("fly.disabled"));
        } else {
            // Check if in own territory
            String chunkKey = ClanManager.buildChunkKey(
                    player.getWorld().getName(),
                    player.getLocation().getChunk().getX(),
                    player.getLocation().getChunk().getZ());

            Clan owner = plugin.getClanManager().getClaimOwner(chunkKey);
            if (owner == null || !owner.getId().equals(clan.getId())) {
                // Also allow in ally territory
                boolean isAlly = owner != null && clan.isAlly(owner.getId());
                boolean allowAllyFly = plugin.getConfigManager().getBoolean("claims.fly.allow-ally-territory", true);
                if (!isAlly || !allowAllyFly) {
                    player.sendMessage(plugin.getConfigManager().getMessage("fly.not-in-territory"));
                    return;
                }
            }

            enableFly(player);
            player.sendMessage(plugin.getConfigManager().getMessage("fly.enabled"));
        }
    }

    /**
     * Enable fly for a player.
     */
    public void enableFly(Player player) {
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        flyingPlayers.add(player.getUniqueId());
        player.setAllowFlight(true);
        player.setFlying(true);
    }

    /**
     * Disable fly for a player (safe landing).
     */
    public void disableFly(Player player) {
        flyingPlayers.remove(player.getUniqueId());
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        player.setFlying(false);
        player.setAllowFlight(false);
        // Prevent fall damage after fly is disabled
        player.setFallDistance(0f);
    }

    /**
     * Check and update fly status when a player moves to a new chunk.
     * Called from TerritoryListener on chunk change.
     */
    public void checkFlyOnChunkChange(Player player, String newChunkKey) {
        if (!plugin.getCoreHook().hasTerritory()) return;
        if (!flyingPlayers.contains(player.getUniqueId())) return;

        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) {
            disableFly(player);
            player.sendMessage(plugin.getConfigManager().getMessage("fly.lost"));
            return;
        }

        Clan owner = plugin.getClanManager().getClaimOwner(newChunkKey);
        boolean isOwn = owner != null && owner.getId().equals(clan.getId());
        boolean isAlly = owner != null && clan.isAlly(owner.getId());
        boolean allowAllyFly = plugin.getConfigManager().getBoolean("claims.fly.allow-ally-territory", true);

        if (!isOwn && !(isAlly && allowAllyFly)) {
            // Left territory - disable fly with grace period
            int graceTicks = plugin.getConfigManager().getInt("claims.fly.leave-grace-ticks", 60);
            player.sendMessage(plugin.getConfigManager().getMessage("fly.leaving-territory"));

            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!player.isOnline()) return;
                if (!flyingPlayers.contains(player.getUniqueId())) return;

                // Re-fetch clan to avoid stale reference
                Clan currentClan = plugin.getClanManager().getClanByPlayer(player);
                if (currentClan == null) {
                    disableFly(player);
                    player.sendMessage(plugin.getConfigManager().getMessage("fly.lost"));
                    return;
                }

                // Re-check location
                String currentChunk = ClanManager.buildChunkKey(
                        player.getWorld().getName(),
                        player.getLocation().getChunk().getX(),
                        player.getLocation().getChunk().getZ());
                Clan currentOwner = plugin.getClanManager().getClaimOwner(currentChunk);
                boolean stillSafe = currentOwner != null &&
                        (currentOwner.getId().equals(currentClan.getId()) ||
                                (currentClan.isAlly(currentOwner.getId()) && allowAllyFly));

                if (!stillSafe) {
                    disableFly(player);
                    player.sendMessage(plugin.getConfigManager().getMessage("fly.lost"));
                }
            }, graceTicks);
        }
    }

    /**
     * Remove a player from fly tracking (on quit or clan leave).
     */
    public void removePlayer(UUID playerId) {
        flyingPlayers.remove(playerId);
    }

    /**
     * Check if a player has clan fly active.
     */
    public boolean isFlying(UUID playerId) {
        return flyingPlayers.contains(playerId);
    }
}
