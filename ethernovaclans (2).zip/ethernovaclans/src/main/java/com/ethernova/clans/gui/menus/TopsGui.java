package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Tops/Rankings GUI showing clan leaderboards with pagination.
 */
public class TopsGui extends AbstractGui {

    private String category = "power"; // power, kd, kills, level, balance
    private int page = 0;

    private static final int[] TOP_SLOTS = {
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34,
            37, 38, 39, 40, 41, 42, 43
    };

    private static final int ITEMS_PER_PAGE = TOP_SLOTS.length; // 21

    public TopsGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "tops");
    }

    @Override
    protected void populateItems() {
        // Category tabs (row 1, slots 10-14)
        setItem(10, new ItemBuilder(Material.BLAZE_POWDER)
                .name("<gold>Power")
                .glowIf(category.equals("power"))
                .build());
        slotActions.put(10, "CAT_POWER");

        setItem(11, new ItemBuilder(Material.IRON_SWORD)
                .name("<red>K/D Ratio")
                .glowIf(category.equals("kd"))
                .hideFlags()
                .build());
        slotActions.put(11, "CAT_KD");

        setItem(12, new ItemBuilder(Material.DIAMOND_SWORD)
                .name("<dark_red>Total Kills")
                .glowIf(category.equals("kills"))
                .hideFlags()
                .build());
        slotActions.put(12, "CAT_KILLS");

        setItem(13, new ItemBuilder(Material.EXPERIENCE_BOTTLE)
                .name("<green>Level")
                .glowIf(category.equals("level"))
                .build());
        slotActions.put(13, "CAT_LEVEL");

        setItem(14, new ItemBuilder(Material.GOLD_INGOT)
                .name("<yellow>Balance")
                .glowIf(category.equals("balance"))
                .build());
        slotActions.put(14, "CAT_BALANCE");

        // Get all clans for this category
        int totalClans = plugin.getClanManager().getAllClans().size();
        int maxPages = Math.max(1, (int) Math.ceil((double) totalClans / ITEMS_PER_PAGE));
        if (page >= maxPages) page = maxPages - 1;
        if (page < 0) page = 0;

        int offset = page * ITEMS_PER_PAGE;
        List<Clan> topClans = plugin.getClanManager().getTopClans(category, offset + ITEMS_PER_PAGE);

        // Clear content slots first
        for (int slot : TOP_SLOTS) {
            inventory.setItem(slot, null);
        }

        for (int i = 0; i < TOP_SLOTS.length; i++) {
            int globalIndex = offset + i;
            if (globalIndex >= topClans.size()) break;

            Clan clan = topClans.get(globalIndex);
            int rank = globalIndex + 1;

            String rankColor = switch (rank) {
                case 1 -> "<gold>";
                case 2 -> "<gray>";
                case 3 -> "<#CD7F32>"; // bronze
                default -> "<white>";
            };

            String rankIcon = switch (rank) {
                case 1 -> "🥇";
                case 2 -> "🥈";
                case 3 -> "🥉";
                default -> "#" + rank;
            };

            String value = getCategoryValue(clan);

            List<String> lore = new ArrayList<>(List.of(
                    "",
                    "<gray>Level: <white>" + clan.getLevel(),
                    "<gray>Power: <white>" + clan.getPower(),
                    "<gray>Members: <white>" + clan.getMembers().size(),
                    "<gray>K/D: <white>" + String.format("%.2f", clan.getKD()),
                    "<gray>Balance: <gold>" + TextUtil.formatCurrency(clan.getBank().getBalance()),
                    "",
                    rankColor + TextUtil.capitalize(category) + ": " + value
            ));

            Material headMat;
            if (clan.getIcon() != null) {
                try {
                    headMat = Material.valueOf(clan.getIcon().toUpperCase());
                } catch (IllegalArgumentException e) {
                    headMat = Material.DIAMOND;
                }
            } else {
                headMat = switch (rank) {
                    case 1 -> Material.DIAMOND;
                    case 2 -> Material.GOLD_INGOT;
                    case 3 -> Material.IRON_INGOT;
                    default -> Material.STONE;
                };
            }

            setItem(TOP_SLOTS[i], new ItemBuilder(headMat)
                    .name(rankColor + rankIcon + " " + clan.getFormattedTag() + " " + clan.getName())
                    .lore(lore)
                    .amount(Math.min(rank, 64))
                    .build());
        }

        // Page info
        setItem(49, new ItemBuilder(Material.PAPER)
                .name("<yellow>Página " + (page + 1) + "/" + maxPages)
                .lore(List.of("", "<gray>Total de clanes: <white>" + totalClans))
                .build());

        // Previous page button
        if (page > 0) {
            setItem(45, new ItemBuilder(Material.ARROW)
                    .name("<yellow>← Página anterior")
                    .build());
            slotActions.put(45, "PREV_PAGE");
        }

        // Next page button
        if (page < maxPages - 1) {
            setItem(53, new ItemBuilder(Material.ARROW)
                    .name("<yellow>Página siguiente →")
                    .build());
            slotActions.put(53, "NEXT_PAGE");
        }
    }

    private String getCategoryValue(Clan clan) {
        return switch (category) {
            case "power" -> String.valueOf(clan.getPower());
            case "kd" -> String.format("%.2f", clan.getKD());
            case "kills" -> String.valueOf(clan.getKills());
            case "level" -> String.valueOf(clan.getLevel());
            case "balance" -> TextUtil.formatCurrency(clan.getBank().getBalance());
            default -> "???";
        };
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.toUpperCase().startsWith("TOP:")) {
            String suffix = action.substring(4).toLowerCase();
            category = suffix;
            page = 0;
            refreshGui();
            return true;
        }

        // Handle OPEN_GUI: actions explicitly so back-to-menu always works
        if (action.toUpperCase().startsWith("OPEN_GUI:")) {
            String guiName = action.substring("OPEN_GUI:".length());
            plugin.getServer().getScheduler().runTask(plugin, () ->
                    plugin.getGuiManager().openGui(player, guiName));
            return true;
        }

        return switch (action.toUpperCase()) {
            case "CAT_POWER" -> { category = "power"; page = 0; refreshGui(); yield true; }
            case "CAT_KD" -> { category = "kd"; page = 0; refreshGui(); yield true; }
            case "CAT_KILLS" -> { category = "kills"; page = 0; refreshGui(); yield true; }
            case "CAT_LEVEL" -> { category = "level"; page = 0; refreshGui(); yield true; }
            case "CAT_BALANCE" -> { category = "balance"; page = 0; refreshGui(); yield true; }
            case "PREV_PAGE" -> { page = Math.max(0, page - 1); refreshGui(); yield true; }
            case "NEXT_PAGE" -> { page++; refreshGui(); yield true; }
            case "BACK" -> {
                plugin.getServer().getScheduler().runTask(plugin, () ->
                        plugin.getGuiManager().openMainMenu(player));
                yield true;
            }
            default -> false;
        };
    }

    private void refreshGui() {
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            slotActions.clear();
            rightClickActions.clear();
            slotConfigs.clear();
            occupiedSlots.clear();
            fillBackground();
            placeConfigItems();
            populateItems();
        });
    }
}
