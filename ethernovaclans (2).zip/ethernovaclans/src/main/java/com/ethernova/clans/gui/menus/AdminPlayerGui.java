package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanMember;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.SoundUtil;
import com.ethernova.clans.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.Optional;

/**
 * Admin GUI for managing a specific player — view clan info,
 * promote/demote, kick, force join, teleport, etc.
 */
public class AdminPlayerGui extends AbstractGui {

    private final Player targetPlayer;

    public AdminPlayerGui(EthernovaClans plugin, Player adminPlayer, Player targetPlayer) {
        super(plugin, adminPlayer, "admin-player");
        this.targetPlayer = targetPlayer;
    }

    @Override
    protected void populateItems() {
        // Driven by YAML + placeholders
    }

    @Override
    protected String replacePlaceholders(String text) {
        if (text == null) return "";
        text = super.replacePlaceholders(text);

        // Target player placeholders
        text = text.replace("{target_name}", targetPlayer.getName())
                .replace("{target_uuid}", targetPlayer.getUniqueId().toString())
                .replace("{target_online_status}", targetPlayer.isOnline() ? "<green>🟢 Online" : "<red>🔴 Offline");

        Clan targetClan = plugin.getClanManager().getClanByPlayer(targetPlayer);
        if (targetClan != null) {
            text = text.replace("{target_clan_info}", targetClan.getFormattedTag() + " " + targetClan.getName());
            ClanMember member = targetClan.getMember(targetPlayer.getUniqueId());
            if (member != null) {
                text = text.replace("{target_role}", member.getRole().getIcon() + " " + member.getRole().name())
                        .replace("{target_kills}", String.valueOf(member.getKills()))
                        .replace("{target_deaths}", String.valueOf(member.getDeaths()))
                        .replace("{target_kd}", String.format("%.2f", member.getKD()))
                        .replace("{target_power}", String.valueOf(member.getPowerContributed()));
            } else {
                text = text.replace("{target_role}", "<gray>N/A")
                        .replace("{target_kills}", "0")
                        .replace("{target_deaths}", "0")
                        .replace("{target_kd}", "0.00")
                        .replace("{target_power}", "0");
            }
        } else {
            text = text.replace("{target_clan_info}", "<gray>No clan")
                    .replace("{target_role}", "<gray>N/A")
                    .replace("{target_kills}", "0")
                    .replace("{target_deaths}", "0")
                    .replace("{target_kd}", "0.00")
                    .replace("{target_power}", "0");
        }

        return text;
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        Clan targetClan = plugin.getClanManager().getClanByPlayer(targetPlayer);

        return switch (action.toUpperCase()) {
            case "ADMIN_GOTO_PLAYER_CLAN" -> {
                if (targetClan == null) {
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.player-no-clan"));
                    yield true;
                }
                AdminClanGui gui = new AdminClanGui(plugin, player, targetClan);
                gui.open();
                yield true;
            }
            case "ADMIN_PROMOTE_PLAYER" -> {
                if (targetClan == null) {
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.player-no-clan"));
                    yield true;
                }
                ClanMember member = targetClan.getMember(targetPlayer.getUniqueId());
                if (member == null) {
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.member-not-found",
                            "name", targetPlayer.getName()));
                    yield true;
                }
                var newRole = member.getRole().promote();
                if (newRole == member.getRole()) {
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.max-role"));
                    yield true;
                }
                member.setRole(newRole);
                player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.promoted",
                        "player", targetPlayer.getName(), "role", newRole.name()));
                SoundUtil.success(player);
                refreshGui();
                yield true;
            }
            case "ADMIN_DEMOTE_PLAYER" -> {
                if (targetClan == null) {
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.player-no-clan"));
                    yield true;
                }
                ClanMember member = targetClan.getMember(targetPlayer.getUniqueId());
                if (member == null) {
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.member-not-found",
                            "name", targetPlayer.getName()));
                    yield true;
                }
                var newRole = member.getRole().demote();
                if (newRole == member.getRole()) {
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.min-role"));
                    yield true;
                }
                member.setRole(newRole);
                player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.demoted",
                        "player", targetPlayer.getName(), "role", newRole.name()));
                SoundUtil.success(player);
                refreshGui();
                yield true;
            }
            case "ADMIN_KICK_FROM_CLAN" -> {
                if (targetClan == null) {
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.player-no-clan"));
                    yield true;
                }
                plugin.getClanManager().removeMember(targetClan, targetPlayer.getUniqueId(), true);
                player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.kicked-from-clan",
                        "player", targetPlayer.getName(), "clan", targetClan.getName()));
                SoundUtil.success(player);
                refreshGui();
                yield true;
            }
            case "ADMIN_FORCE_JOIN" -> {
                player.closeInventory();
                player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.enter-clan-name"));
                plugin.getGuiManager().registerAnvilInput(player, input -> {
                    Clan clan = plugin.getClanManager().getClanByName(input);
                    if (clan == null) clan = plugin.getClanManager().getClanByTag(input);
                    if (clan == null) {
                        player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.clan-not-found",
                                "input", input));
                    } else if (plugin.getClanManager().isInClan(targetPlayer.getUniqueId())) {
                        player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.already-in-clan-kick"));
                    } else {
                        plugin.getClanManager().addMember(clan, targetPlayer);
                        player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.forced-join",
                                "player", targetPlayer.getName(), "clan", clan.getName()));
                    }
                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        AdminPlayerGui newGui = new AdminPlayerGui(plugin, player, targetPlayer);
                        newGui.open();
                    });
                });
                yield true;
            }
            case "ADMIN_MOVE_CLAN" -> {
                if (targetClan == null) {
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.player-no-clan"));
                    yield true;
                }
                player.closeInventory();
                player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.enter-dest-clan"));
                plugin.getGuiManager().registerAnvilInput(player, input -> {
                    Clan destination = plugin.getClanManager().getClanByName(input);
                    if (destination == null) destination = plugin.getClanManager().getClanByTag(input);
                    if (destination == null) {
                        player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.dest-clan-not-found",
                                "input", input));
                    } else {
                        // Remove from current, add to new
                        Clan currentClan = plugin.getClanManager().getClanByPlayer(targetPlayer);
                        if (currentClan != null) {
                            plugin.getClanManager().removeMember(currentClan, targetPlayer.getUniqueId(), false);
                        }
                        plugin.getClanManager().addMember(destination, targetPlayer);
                        player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.transferred",
                                "player", targetPlayer.getName(), "clan", destination.getName()));
                    }
                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        AdminPlayerGui newGui = new AdminPlayerGui(plugin, player, targetPlayer);
                        newGui.open();
                    });
                });
                yield true;
            }
            case "ADMIN_TELEPORT" -> {
                if (!targetPlayer.isOnline()) {
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.player-not-online"));
                    yield true;
                }
                player.closeInventory();
                player.teleport(targetPlayer.getLocation());
                player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.teleported",
                        "player", targetPlayer.getName()));
                yield true;
            }
            default -> false;
        };
    }

    private void refreshGui() {
        occupiedSlots.clear();
        slotActions.clear();
        rightClickActions.clear();
        slotConfigs.clear();
        fillBackground();
        placeConfigItems();
        populateItems();
    }
}
