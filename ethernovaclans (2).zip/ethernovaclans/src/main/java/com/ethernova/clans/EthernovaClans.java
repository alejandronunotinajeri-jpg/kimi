package com.ethernova.clans;

import com.ethernova.clans.achievement.AchievementManager;
import com.ethernova.clans.alliance.AllianceManager;
import com.ethernova.clans.audit.AuditLogger;
import com.ethernova.clans.bank.ClanBankManager;
import com.ethernova.clans.chat.ClanChatManager;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanManager;
import com.ethernova.clans.command.*;
import com.ethernova.clans.config.ConfigManager;
import com.ethernova.clans.diplomacy.DiplomacyManager;
import com.ethernova.clans.discord.DiscordWebhook;
import com.ethernova.clans.economy.EconomyManager;
import com.ethernova.clans.fly.FlyManager;
import com.ethernova.clans.gui.ConfigurableGUI;
import com.ethernova.clans.gui.GUIManager;
import com.ethernova.clans.hologram.HologramManager;
import com.ethernova.clans.hook.CombatHook;
import com.ethernova.clans.hook.CoreHook;
import com.ethernova.clans.hook.DynmapHook;
import com.ethernova.clans.hook.WorldGuardHook;
import com.ethernova.clans.nation.NationManager;
import com.ethernova.clans.outpost.OutpostManager;
import com.ethernova.clans.spy.SpyManager;
import com.ethernova.clans.webmap.WebMapServer;
import com.ethernova.clans.territory.TerritoryHUD;
import com.ethernova.clans.territory.ChunkVisualizer;
import com.ethernova.clans.api.ClanAPI;
import com.ethernova.clans.blueprint.BlueprintManager;
import com.ethernova.clans.blueprint.BlueprintEffectListener;
import com.ethernova.clans.tax.TaxManager;
import com.ethernova.clans.season.SeasonManager;
import com.ethernova.clans.banner.BannerManager;
import com.ethernova.clans.storage.SchemaManager;
import com.ethernova.core.service.ServiceRegistry;
import com.ethernova.clans.salary.SalaryManager;
import com.ethernova.clans.shop.ClanShopManager;
import com.ethernova.clans.siege.SiegeManager;
import com.ethernova.clans.skill.ClanSkillManager;
import com.ethernova.clans.invitation.InvitationManager;
import com.ethernova.clans.level.ClanLevelManager;
import com.ethernova.clans.listener.*;
import com.ethernova.clans.message.MessageManager;
import com.ethernova.clans.mission.MissionManager;
import com.ethernova.clans.placeholder.ClanPlaceholderExpansion;
import com.ethernova.clans.hook.PlaceholderHook;
import com.ethernova.clans.power.PowerManager;
import com.ethernova.clans.scheduledevent.EventScheduler;
import com.ethernova.clans.shield.ShieldManager;
import com.ethernova.clans.storage.StorageManager;
import com.ethernova.clans.teleport.TeleportManager;
import com.ethernova.clans.territory.TerritoryFlagManager;
import com.ethernova.clans.territory.TerritoryManager;
import com.ethernova.clans.upgrade.UpgradeManager;
import com.ethernova.clans.util.ConfirmationManager;
import com.ethernova.clans.war.WarManager;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;
import java.util.Map;
import java.util.logging.Level;

public class EthernovaClans extends JavaPlugin {

    private static EthernovaClans instance;

    // ── Core Ecosystem Hooks ─────────────────────────────────
    private CoreHook coreHook;
    private CombatHook combatHook;

    // ── Mode Detection ───────────────────────────────────────
    private com.ethernova.clans.mode.ClanModeManager clanModeManager;

    // ── Managers ─────────────────────────────────────────────
    private ConfigManager configManager;
    private MessageManager messageManager;
    private StorageManager storageManager;
    private ClanManager clanManager;
    private PowerManager powerManager;
    private TerritoryManager territoryManager;
    private WarManager warManager;
    private AllianceManager allianceManager;
    private EconomyManager economyManager;
    private InvitationManager invitationManager;
    private ClanChatManager chatManager;
    private GUIManager guiManager;
    private ShieldManager shieldManager;
    private HologramManager hologramManager;
    private UpgradeManager upgradeManager;
    private DiscordWebhook discordWebhook;
    private ClanBankManager bankManager;
    private ClanLevelManager levelManager;
    private AuditLogger auditLogger;
    private ConfigurableGUI configurableGUI;
    private TerritoryFlagManager territoryFlagManager;
    private TeleportManager teleportManager;
    private ConfirmationManager confirmationManager;
    private MissionManager missionManager;
    private AchievementManager achievementManager;
    private EventScheduler eventScheduler;
    private com.ethernova.clans.scheduledevent.EventBossBarManager eventBossBarManager;
    private FlyManager flyManager;
    private com.ethernova.clans.nametag.NametagManager nametagManager;
    private com.ethernova.clans.audit.AuditManager auditManager;

    // ── God-Tier Feature Managers ────────────────────────────
    private ClanSkillManager skillManager;
    private ClanShopManager shopManager;
    private SiegeManager siegeManager;
    private DiplomacyManager diplomacyManager;
    private SalaryManager salaryManager;
    private DynmapHook dynmapHook;

    // ── Top-1 Feature Managers ───────────────────────────────
    private WorldGuardHook worldGuardHook;
    private NationManager nationManager;
    private OutpostManager outpostManager;
    private SpyManager spyManager;
    private TerritoryHUD territoryHUD;
    private WebMapServer webMapServer;
    private com.ethernova.clans.webmap.WebAuthManager webAuthManager;
    private com.ethernova.clans.util.Metrics metrics;

    // ── Ultimate Feature Managers ────────────────────────────
    private BlueprintManager blueprintManager;
    private BlueprintEffectListener blueprintEffectListener;
    private com.ethernova.clans.listener.ChatFormatListener chatFormatListener;
    private TaxManager taxManager;
    private ChunkVisualizer chunkVisualizer;
    private SeasonManager seasonManager;
    private BannerManager bannerManager;
    private long enableTime;

    @Override
    public void onEnable() {
        instance = this;
        enableTime = System.currentTimeMillis();
        long start = System.currentTimeMillis();

        getLogger().info("═══════════════════════════════════════════");
        getLogger().info("  EthernovaClans v" + getDescription().getVersion());
        getLogger().info("  Loading clan system...");
        getLogger().info("    PAPI:    " + (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null ? "✔" : "○"));
        getLogger().info("    Mode:    " + (Bukkit.getPluginManager().getPlugin("EthernovaCore") != null ? "ecosystem" : "standalone"));
        getLogger().info("═══════════════════════════════════════════");

        try {
            // Phase 0: Core ecosystem hooks
            setupEcosystemHooks();
            getLogger().info("  ServerMode: " + coreHook.getServerMode()
                    + " | Territory: " + coreHook.hasTerritory());

            // Phase 0.5: Clan mode detection (survival vs practice)
            clanModeManager = new com.ethernova.clans.mode.ClanModeManager(this);
            clanModeManager.detect();

            // Phase 1: Config
            configManager = new ConfigManager(this);
            configManager.loadAllConfigs();
            getLogger().info("✔ Configuración cargada");

            // Phase 2: Messages
            messageManager = new MessageManager(this);
            getLogger().info("✔ Mensajes cargados");

            // Phase 3: Storage
            storageManager = new StorageManager(this);
            storageManager.initialize();
            // Run schema migrations
            try (var conn = storageManager.getConnection()) {
                new SchemaManager(this).migrate(conn);
            }
            getLogger().info("✔ Base de datos inicializada");

            // Phase 4: Economy
            economyManager = new EconomyManager(this);
            if (economyManager.isEnabled()) {
                getLogger().info("✔ Vault conectado");
            } else {
                getLogger().warning("○ Vault no encontrado - funciones de economía desactivadas");
            }

            // Phase 5: Managers
            powerManager = new PowerManager(this);
            clanManager = new ClanManager(this);
            territoryManager = new TerritoryManager(this);
            warManager = new WarManager(this);
            allianceManager = new AllianceManager(this);
            invitationManager = new InvitationManager(this);
            chatManager = new ClanChatManager(this);
            shieldManager = new ShieldManager(this);
            upgradeManager = new UpgradeManager(this);
            guiManager = new GUIManager(this);
            bankManager = new ClanBankManager(this);
            levelManager = new ClanLevelManager(this);
            auditLogger = new AuditLogger(this);
            configurableGUI = new ConfigurableGUI(this);
            territoryFlagManager = new TerritoryFlagManager(this);
            teleportManager = new TeleportManager(this);
            confirmationManager = new ConfirmationManager(this);
            flyManager = new FlyManager(this);
            missionManager = new MissionManager(this);
            achievementManager = new AchievementManager(this);
            nametagManager = new com.ethernova.clans.nametag.NametagManager(this);
            nametagManager.initialize();
            auditManager = new com.ethernova.clans.audit.AuditManager(this);
            eventScheduler = new EventScheduler(this);
            eventBossBarManager = new com.ethernova.clans.scheduledevent.EventBossBarManager(this);
            eventScheduler.setBossBarManager(eventBossBarManager);
            skillManager = new ClanSkillManager(this);
            shopManager = new ClanShopManager(this);
            siegeManager = new SiegeManager(this);
            diplomacyManager = new DiplomacyManager(this);
            salaryManager = new SalaryManager(this);
            dynmapHook = new DynmapHook(this);
            worldGuardHook = new WorldGuardHook(this);
            nationManager = new NationManager(this);
            outpostManager = new OutpostManager(this);
            spyManager = new SpyManager(this);
            territoryHUD = new TerritoryHUD(this);
            blueprintManager = new BlueprintManager(this);
            taxManager = new TaxManager(this);
            chunkVisualizer = new ChunkVisualizer(this);
            seasonManager = new SeasonManager(this);
            bannerManager = new BannerManager(this);
            getLogger().info("✔ Managers inicializados");

            // Phase 6: Load data
            clanManager.loadAllClans();
            getLogger().info("✔ " + clanManager.getAllClans().size() + " clanes cargados");

            // Phase 6.1: Load player power (after clans, before advanced data)
            powerManager.loadAll();
            powerManager.syncAllClanPower();

            // Phase 6.5: Load god-tier data (after clans are loaded)
            skillManager.loadAll();
            shopManager.loadAll();
            diplomacyManager.loadAll();
            salaryManager.loadAll();
            dynmapHook.tryHook();
            nationManager.loadAll();
            outpostManager.loadAll();
            // Load shields from DB
            if (shieldManager != null && storageManager != null) {
                for (var entry : storageManager.loadShields().entrySet()) {
                    shieldManager.loadShield(entry.getKey(), entry.getValue());
                }
            }
            getLogger().info("✔ Datos avanzados cargados (skills, shop, diplomacy, salaries, nations, outposts)");

            // Phase 6.75: Ultimate features (after clans loaded)
            blueprintManager.loadAll();
            bannerManager.loadAll();
            if (missionManager != null) missionManager.loadAllFromDatabase();
            getLogger().info("✔ Ultimate features cargados (blueprints, taxes, seasons, banners, missions)");

            // Phase 7: Holograms
            hologramManager = new HologramManager(this);
            getLogger().info("✔ Hologramas cargados");

            // Phase 8: Discord
            discordWebhook = new DiscordWebhook(this);

            // Phase 9: Commands
            registerCommands();
            getLogger().info("✔ Comandos registrados");

            // Phase 10: Listeners
            registerListeners();
            getLogger().info("✔ Listeners registrados");

            // Phase 11: Placeholders
            if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
                new ClanPlaceholderExpansion(this).register();  // %ethernova_clans_*%
                new PlaceholderHook(this).register();            // %ethernova_*%
                getLogger().info("✔ PlaceholderAPI conectado (2 expansions)");
            }

            // Phase 12: Tasks
            registerTasks();
            getLogger().info("✔ Tasks programados");

            // Phase 13: Register contexts with Core
            registerContexts();

            // Phase 14: Public API
            ClanAPI.init(this);
            ServiceRegistry.register(ClanAPI.class, ClanAPI.getInstance());
            getLogger().info("✔ ClanAPI pública inicializada + ServiceRegistry");

            // Phase 15: bStats Metrics
            metrics = new com.ethernova.clans.util.Metrics(this);

            // Phase 16: Update Checker
            var updateChecker = new com.ethernova.clans.util.UpdateChecker(this);
            updateChecker.check();
            Bukkit.getPluginManager().registerEvents(updateChecker, this);

            // Phase 17: Web Auth + Web Map
            webAuthManager = new com.ethernova.clans.webmap.WebAuthManager(this);
            webMapServer = new WebMapServer(this);
            webMapServer.start();

            long elapsed = System.currentTimeMillis() - start;
            getLogger().info("═══════════════════════════════════════════");
            getLogger().info("  EthernovaClans habilitado en " + elapsed + "ms");
            getLogger().info("  " + clanManager.getAllClans().size() + " clanes cargados");
            getLogger().info("═══════════════════════════════════════════");

        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Error al habilitar EthernovaClans", e);
            Bukkit.getPluginManager().disablePlugin(this);
        }
    }

    @Override
    public void onDisable() {
        getLogger().info("Deshabilitando EthernovaClans...");

        // Save missions before scheduler is cancelled (uses sync save)
        if (missionManager != null) missionManager.saveAllToDatabase();

        // Disable fly for all flying players before shutdown — must actually disable flight
        if (flyManager != null) {
            for (org.bukkit.entity.Player p : Bukkit.getOnlinePlayers()) {
                if (flyManager.isFlying(p.getUniqueId())) {
                    flyManager.disableFly(p);
                }
            }
        }

        Bukkit.getScheduler().cancelTasks(this);

        if (teleportManager != null) teleportManager.cancelAllTeleports();

        // Shutdown nametag and event scheduler
        if (nametagManager != null) nametagManager.shutdown();
        if (eventScheduler != null) eventScheduler.stop();
        if (eventBossBarManager != null) eventBossBarManager.shutdown();
        if (siegeManager != null) siegeManager.shutdown();
        if (diplomacyManager != null) diplomacyManager.shutdown();
        if (salaryManager != null) salaryManager.shutdown();
        if (dynmapHook != null) dynmapHook.shutdown();
        if (nationManager != null) nationManager.shutdown();
        if (outpostManager != null) outpostManager.shutdown();
        if (spyManager != null) spyManager.shutdown();
        if (territoryHUD != null) territoryHUD.removeAll();
        if (webAuthManager != null) webAuthManager.save();
        if (webMapServer != null) webMapServer.stop();
        if (blueprintEffectListener != null) blueprintEffectListener.shutdown();
        if (blueprintManager != null) blueprintManager.shutdown();
        if (taxManager != null) taxManager.shutdown();
        if (chunkVisualizer != null) chunkVisualizer.shutdown();
        if (seasonManager != null) seasonManager.shutdown();
        if (bannerManager != null) bannerManager.shutdown();

        // Persist data
        if (clanManager != null && storageManager != null) {
            for (var c : clanManager.getAllClans()) {
                try { clanManager.saveClan(c); } catch (Exception e) {
                    getLogger().log(java.util.logging.Level.WARNING, "Error saving clan " + c.getId(), e);
                }
            }
        }
        if (territoryManager != null && storageManager != null) storageManager.saveAllTerritories(territoryManager.getAllClaims());
        if (bankManager != null && storageManager != null) storageManager.saveBankBalances(bankManager.getAllBalances());
        if (levelManager != null && storageManager != null) storageManager.saveClanXP(levelManager.getAllXP());
        if (powerManager != null && storageManager != null) powerManager.saveAll();
        if (storageManager != null) storageManager.saveAllAlliances();
        if (shieldManager != null && storageManager != null) storageManager.saveShields(shieldManager.getAllShields());
        // Save nations synchronously before closing storage
        if (nationManager != null && storageManager != null) {
            for (var nation : nationManager.getAllNations()) {
                try { nationManager.saveSync(nation); } catch (Exception e) {
                    getLogger().log(java.util.logging.Level.WARNING, "Error saving nation " + nation.getId(), e);
                }
            }
        }
        if (storageManager != null) storageManager.close();
        if (hologramManager != null) hologramManager.removeAllHolograms();
        ServiceRegistry.unregister(ClanAPI.class);
        if (coreHook != null && coreHook.isAvailable()) coreHook.unregister();
        instance = null;
        getLogger().info("EthernovaClans deshabilitado.");
    }

    // ══════════════════════════════════════════════════════════
    //  ECOSYSTEM HOOKS
    // ══════════════════════════════════════════════════════════

    private void setupEcosystemHooks() {
        // EthernovaCore (optional — graceful degradation)
        coreHook = new CoreHook();
        if (coreHook.isAvailable()) {
            coreHook.register();
            getLogger().info("✔ EthernovaCore conectado");
        } else {
            getLogger().info("○ EthernovaCore no encontrado - modo standalone");
        }

        // EthernovaCombat (optional)
        combatHook = new CombatHook();
        if (combatHook.isAvailable()) {
            registerCombatListeners();
            getLogger().info("✔ EthernovaCombat conectado");
        } else {
            getLogger().info("○ EthernovaCombat no encontrado (opcional)");
        }
    }
    private void registerCombatListeners() {
        // Combat-specific listeners are handled by registerListeners().
        // This method exists only for combat-hook-specific event subscriptions.
        getLogger().info("  Combat listeners integrados");
    }
    private void registerTasks() {
        int saveInterval = configManager.getConfig().getInt("general.auto-save-interval", 5);
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            // Collect all data on the main thread (safe to access Location.getWorld() etc.)
            // then dispatch the actual DB writes asynchronously to avoid lag
            final List<Clan> clansSnapshot = clanManager != null
                    ? new java.util.ArrayList<>(clanManager.getAllClans()) : List.of();

            // Purge expired cooldowns while on main thread
            for (Clan c : clansSnapshot) c.purgeExpiredCooldowns();
            final Map<String, String> territoriesSnapshot = territoryManager != null
                    ? new java.util.HashMap<>(territoryManager.getAllClaims()) : Map.of();
            final Map<String, Double> bankSnapshot = bankManager != null && storageManager != null
                    ? new java.util.HashMap<>(bankManager.getAllBalances()) : Map.of();
            final Map<String, Long> xpSnapshot = levelManager != null && storageManager != null
                    ? new java.util.HashMap<>(levelManager.getAllXP()) : Map.of();

            Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
                for (Clan c : clansSnapshot) {
                    try {
                        clanManager.saveClan(c);
                    } catch (Exception e) {
                        getLogger().log(Level.WARNING, "Error saving clan " + c.getId(), e);
                    }
                }
                if (storageManager != null) {
                    storageManager.saveAllTerritories(territoriesSnapshot);
                    storageManager.saveBankBalances(bankSnapshot);
                    storageManager.saveClanXP(xpSnapshot);
                    storageManager.saveAllAlliances();
                }
                if (nationManager != null) {
                    nationManager.saveAll();
                }
                if (outpostManager != null) {
                    outpostManager.saveAll();
                }
                if (shieldManager != null && storageManager != null) {
                    storageManager.saveShields(shieldManager.getAllShields());
                }
            });
        }, 20L * 60 * saveInterval, 20L * 60 * saveInterval);

        int powerRegen = configManager.getConfig().getInt("power.regen-interval", 60);
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (powerManager != null) powerManager.regenAllOnlinePower();
        }, 20L * powerRegen, 20L * powerRegen);

        Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (warManager != null) warManager.tick();
        }, 20L, 20L);

        Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (shieldManager != null) shieldManager.tick();
        }, 20L * 60, 20L * 60);

        // Outpost resource generation
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (outpostManager != null) outpostManager.tickResources();
        }, 20L * 60, 20L * 60);
        // Territory tax
        int taxInterval = configManager.getConfig().getInt("bank.tax-interval-minutes", 60);
        if (taxInterval > 0) {
            Bukkit.getScheduler().runTaskTimer(this, () -> {
                if (bankManager != null) bankManager.applyTerritoryTax();
            }, 20L * 60 * taxInterval, 20L * 60 * taxInterval);
        }

        // Assign daily missions to all clans 30 seconds after startup (and every 6 hours)
        if (missionManager != null) {
            Bukkit.getScheduler().runTaskTimer(this, () -> {
                if (clanManager != null && missionManager != null) {
                    for (Clan c : clanManager.getAllClans()) {
                        try { missionManager.assignDailyMissions(c); }
                        catch (Exception e) { getLogger().log(Level.WARNING, "Error assigning missions to " + c.getId(), e); }
                    }
                }
            }, 20L * 30, 20L * 60 * 60 * 6); // 30s delay, then every 6 hours
        }
    }
    private void registerContexts() {
        // Register "war" context — Combat plugin checks this for extended tag duration
        // Context is added/removed by WarManager when wars start/end
        getLogger().info("✔ Contextos registrados con Core");
    }
    private void registerCommands() {
        var clanCmd = getCommand("clan");
        if (clanCmd != null) {
            ClanCommandExecutor executor = new ClanCommandExecutor(this);
            clanCmd.setExecutor(executor);
            clanCmd.setTabCompleter(executor);
        }
        var adminCmd = getCommand("clanadmin");
        if (adminCmd != null) {
            ClanAdminCommand executor = new ClanAdminCommand(this);
            adminCmd.setExecutor(executor);
            adminCmd.setTabCompleter(executor);
        }
        var webCmd = getCommand("webmap");
        if (webCmd != null) {
            WebMapCommand wexec = new WebMapCommand(this);
            webCmd.setExecutor(wexec);
            webCmd.setTabCompleter(wexec);
        }
    }
    private void registerListeners() {
        var pm = Bukkit.getPluginManager();
        pm.registerEvents(new PlayerDamageListener(this), this);   // Territory PvP flags, war tagging, teleport cancel
        pm.registerEvents(new CombatListener(this), this);         // Friendly fire, ally PvP, kill/death processing
        pm.registerEvents(new PlayerListener(this), this);         // Member tracking, boosts, nametags, invite check, cleanup
        pm.registerEvents(new ChatListener(this), this);           // Clan/ally chat, anvil input, @mentions
        pm.registerEvents(new AchievementListener(this), this);    // Achievement event checks
        // Territory-dependent listeners: only register if server mode supports territory
        if (coreHook.hasTerritory()) {
            pm.registerEvents(new TerritoryListener(this), this);
            pm.registerEvents(new com.ethernova.clans.listener.TerritoryFlyListener(this), this);
            pm.registerEvents(new SkillEffectListener(this), this);    // Skill passive effects
            pm.registerEvents(new OutpostListener(this), this);         // Outpost block protection + watchtower
            blueprintEffectListener = new BlueprintEffectListener(this);
            pm.registerEvents(blueprintEffectListener, this);            // Blueprint passive effects
            chunkVisualizer.start();
        } else {
            getLogger().info("  ○ Territory listeners omitidos (modo: " + coreHook.getServerMode() + ")");
        }
        pm.registerEvents(new GUIListener(this), this);
        chatFormatListener = new com.ethernova.clans.listener.ChatFormatListener(this);
        pm.registerEvents(chatFormatListener, this);
    }
    public static EthernovaClans getInstance() { return instance; }
    public CoreHook getCoreHook() { return coreHook; }
    public CombatHook getCombatHook() { return combatHook; }
    public ConfigManager getConfigManager() { return configManager; }
    public MessageManager getMessageManager() { return messageManager; }
    public StorageManager getStorageManager() { return storageManager; }
    public ClanManager getClanManager() { return clanManager; }
    public PowerManager getPowerManager() { return powerManager; }
    public TerritoryManager getTerritoryManager() { return territoryManager; }
    public WarManager getWarManager() { return warManager; }
    public AllianceManager getAllianceManager() { return allianceManager; }
    public EconomyManager getEconomyManager() { return economyManager; }
    public InvitationManager getInvitationManager() { return invitationManager; }
    public ClanChatManager getChatManager() { return chatManager; }
    public GUIManager getGuiManager() { return guiManager; }
    public ShieldManager getShieldManager() { return shieldManager; }
    public HologramManager getHologramManager() { return hologramManager; }
    public UpgradeManager getUpgradeManager() { return upgradeManager; }
    public DiscordWebhook getDiscordWebhook() { return discordWebhook; }
    public ClanBankManager getBankManager() { return bankManager; }
    public ClanLevelManager getLevelManager() { return levelManager; }
    public AuditLogger getAuditLogger() { return auditLogger; }
    public ConfigurableGUI getConfigurableGUI() { return configurableGUI; }
    public TerritoryFlagManager getTerritoryFlagManager() { return territoryFlagManager; }
    public TeleportManager getTeleportManager() { return teleportManager; }
    public ConfirmationManager getConfirmationManager() { return confirmationManager; }
    public EconomyManager getVaultHook() { return economyManager; }
    public MissionManager getMissionManager() { return missionManager; }
    public AchievementManager getAchievementManager() { return achievementManager; }
    public EventScheduler getEventScheduler() { return eventScheduler; }
    public com.ethernova.clans.scheduledevent.EventBossBarManager getEventBossBarManager() { return eventBossBarManager; }
    public FlyManager getFlyManager() { return flyManager; }

    // ── Additional Getters ───────────────────────────────────
    public org.bukkit.plugin.Plugin getPlaceholderHook() {
        return Bukkit.getPluginManager().getPlugin("PlaceholderAPI");
    }
    public HologramManager getHologramHook() { return hologramManager; }
    public com.ethernova.clans.nametag.NametagManager getNametagManager() { return nametagManager; }
    public com.ethernova.clans.audit.AuditManager getAuditManager() { return auditManager; }

    // ── God-Tier Feature Getters ─────────────────────────────
    public ClanSkillManager getSkillManager() { return skillManager; }
    public ClanShopManager getShopManager() { return shopManager; }
    public SiegeManager getSiegeManager() { return siegeManager; }
    public DiplomacyManager getDiplomacyManager() { return diplomacyManager; }
    public SalaryManager getSalaryManager() { return salaryManager; }
    public DynmapHook getDynmapHook() { return dynmapHook; }

    // ── Top-1 Feature Getters ────────────────────────────────
    public WorldGuardHook getWorldGuardHook() { return worldGuardHook; }
    public NationManager getNationManager() { return nationManager; }
    public OutpostManager getOutpostManager() { return outpostManager; }
    public SpyManager getSpyManager() { return spyManager; }
    public TerritoryHUD getTerritoryHUD() { return territoryHUD; }
    public WebMapServer getWebMapServer() { return webMapServer; }
    public com.ethernova.clans.webmap.WebAuthManager getWebAuthManager() { return webAuthManager; }

    // ── Ultimate Feature Getters ─────────────────────────────
    public BlueprintManager getBlueprintManager() { return blueprintManager; }
    public TaxManager getTaxManager() { return taxManager; }
    public com.ethernova.clans.listener.ChatFormatListener getChatFormatListener() { return chatFormatListener; }
    public ChunkVisualizer getChunkVisualizer() { return chunkVisualizer; }
    public SeasonManager getSeasonManager() { return seasonManager; }
    public BannerManager getBannerManager() { return bannerManager; }
    public long getEnableTime() { return enableTime; }
    public com.ethernova.clans.mode.ClanModeManager getClanModeManager() { return clanModeManager; }
}
