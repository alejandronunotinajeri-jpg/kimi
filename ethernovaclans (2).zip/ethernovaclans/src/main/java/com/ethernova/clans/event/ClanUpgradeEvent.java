package com.ethernova.clans.event;

import com.ethernova.clans.clan.Clan;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

/**
 * Fired when a clan purchases an upgrade.
 */
public class ClanUpgradeEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();

    private final Clan clan;
    private final String upgradeId;
    private final int newLevel;

    public ClanUpgradeEvent(Clan clan, String upgradeId, int newLevel) {
        this.clan = clan;
        this.upgradeId = upgradeId;
        this.newLevel = newLevel;
    }

    public Clan getClan() { return clan; }
    public String getUpgradeId() { return upgradeId; }
    public int getNewLevel() { return newLevel; }

    @Override
    public HandlerList getHandlers() { return HANDLERS; }
    public static HandlerList getHandlerList() { return HANDLERS; }
}
