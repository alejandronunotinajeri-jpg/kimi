package com.ethernova.clans.listener;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;

public class PlayerDamageListener implements Listener {

    private final EthernovaClans plugin;

    public PlayerDamageListener(EthernovaClans plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        Player attacker = resolveAttacker(event.getDamager());
        if (attacker == null || attacker.equals(victim)) return;

        // Territory PVP flag check — only applies in territory modes
        if (plugin.getCoreHook().hasTerritory()) {
            String chunkId = victim.getLocation().getChunk().getWorld().getName() + ":" +
                    victim.getLocation().getChunk().getX() + ":" + victim.getLocation().getChunk().getZ();
            String owner = plugin.getTerritoryManager().getOwner(chunkId);
            if (owner != null && !plugin.getTerritoryFlagManager().getFlag(owner, com.ethernova.clans.territory.TerritoryFlag.PVP)) {
                event.setCancelled(true);
                plugin.getMessageManager().sendMessage(attacker, "damage.pvp-disabled");
                return;
            }

            // War tagging — only in territory modes
            Clan aClan = plugin.getClanManager().getClanByPlayer(attacker.getUniqueId());
            Clan vClan = plugin.getClanManager().getClanByPlayer(victim.getUniqueId());
            if (aClan != null && vClan != null
                    && plugin.getWarManager() != null && plugin.getWarManager().isAtWar(aClan, vClan)) {
                if (plugin.getCombatHook() != null && plugin.getCombatHook().isAvailable()) {
                    plugin.getCombatHook().tagForWar(attacker, victim);
                }
            }
        }
    }

    // NOTE: onDeath removed — handled by CombatListener (avoids double power gain/loss)

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onAnyDamage(org.bukkit.event.entity.EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        plugin.getTeleportManager().cancelTeleport(player.getUniqueId());
    }

    private Player resolveAttacker(Entity d) {
        if (d instanceof Player p) return p;
        if (d instanceof Projectile proj && proj.getShooter() instanceof Player p) return p;
        if (d instanceof Tameable t && t.getOwner() instanceof Player p) return p;
        return null;
    }
}
