package com.ethernova.clans.hook;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanMember;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * PlaceholderAPI expansion providing all %ethernova_*% placeholders.
 */
public class PlaceholderHook extends PlaceholderExpansion {

    private final EthernovaClans plugin;

    public PlaceholderHook(EthernovaClans plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "ethernova";
    }

    @Override
    public @NotNull String getAuthor() {
        return "EthernovaTeam";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public @Nullable String onRequest(OfflinePlayer offlinePlayer, @NotNull String params) {
        if (offlinePlayer == null) return "";

        Clan clan = plugin.getClanManager().getClanByPlayer(offlinePlayer.getUniqueId());

        // Placeholders that don't require a clan
        switch (params.toLowerCase()) {
            case "has_clan" -> { return clan != null ? "true" : "false"; }
            case "in_clan" -> { return clan != null ? "yes" : "no"; }
        }

        // All following placeholders require a clan
        if (clan == null) return "";

        ClanMember member = clan.getMember(offlinePlayer.getUniqueId());

        return switch (params.toLowerCase()) {
            // ── Clan Info ──
            case "clan_name" -> MiniMessage.miniMessage().escapeTags(clan.getName());
            case "clan_tag" -> MiniMessage.miniMessage().escapeTags(clan.getTag());
            case "clan_tag_colored", "clan_tag_formatted" -> {
                // Convert MiniMessage to legacy §-codes for PAPI compatibility
                var component = MiniMessage.miniMessage().deserialize(clan.getFormattedTag());
                yield LegacyComponentSerializer.legacySection().serialize(component);
            }
            case "clan_id" -> clan.getId().toString();
            case "clan_description" -> clan.getDescription() != null ? MiniMessage.miniMessage().escapeTags(clan.getDescription()) : "";

            // ── Level & Power (use authoritative managers, not stale Clan fields) ──
            case "clan_level" -> String.valueOf(plugin.getLevelManager().getLevel(clan.getId()));
            case "clan_level_name" -> plugin.getLevelManager().getLevelName(plugin.getLevelManager().getLevel(clan.getId()));
            case "clan_power" -> String.valueOf(plugin.getPowerManager() != null ? plugin.getPowerManager().getClanPower(clan) : clan.getPower());
            case "clan_max_power" -> String.valueOf(plugin.getConfigManager().getInt("power.max-power", 100000));

            // ── Members ──
            case "clan_members" -> String.valueOf(clan.getMembers().size());
            case "clan_max_members" -> String.valueOf(plugin.getLevelManager().getMaxMembers(clan.getLevel()));
            case "clan_members_online" -> String.valueOf(clan.getOnlineMembers().size());

            // ── Stats ──
            case "clan_kills" -> String.valueOf(clan.getTotalKills());
            case "clan_deaths" -> String.valueOf(clan.getTotalDeaths());
            case "clan_kd" -> String.format("%.2f", clan.getKD());
            case "clan_wars_won" -> String.valueOf(clan.getWarsWon());
            case "clan_wars_lost" -> String.valueOf(clan.getWarsLost());

            // ── Bank (use authoritative BankManager) ──
            case "clan_balance", "clan_bank" -> {
                double bal = plugin.getBankManager() != null ? plugin.getBankManager().getBalance(clan.getId()) : clan.getBank().getBalance();
                yield String.format("%.2f", bal);
            }
            case "clan_balance_formatted" -> {
                double bal = plugin.getBankManager() != null ? plugin.getBankManager().getBalance(clan.getId()) : clan.getBank().getBalance();
                yield String.format("$%,.2f", bal);
            }

            // ── Diplomacy ──
            case "clan_allies" -> String.valueOf(clan.getAllies().size());
            case "clan_max_allies" -> String.valueOf(plugin.getLevelManager().getMaxAllies(clan.getLevel()));
            case "clan_rivals" -> String.valueOf(clan.getRivals().size());

            // ── Claims ──
            case "clan_claims" -> String.valueOf(plugin.getTerritoryManager().getClaimCount(clan.getId()));
            case "clan_max_claims" -> String.valueOf(plugin.getLevelManager().getMaxClaims(clan.getLevel()));

            // ── Player-specific ──
            case "player_role" -> member != null ? member.getRole().name() : "";
            case "player_role_lower" -> member != null ? member.getRole().name().toLowerCase() : "";
            case "player_kills" -> member != null ? String.valueOf(member.getKills()) : "0";
            case "player_deaths" -> member != null ? String.valueOf(member.getDeaths()) : "0";
            case "player_kd" -> member != null ? String.format("%.2f", member.getKD()) : "0.00";
            case "player_power_contributed" -> member != null ? String.valueOf(member.getPowerContributed()) : "0";

            // ── Settings ──
            case "clan_friendly_fire" -> clan.isFriendlyFire() ? "enabled" : "disabled";
            case "clan_invite_mode" -> "open".equals(clan.getInviteMode()) ? "open" : "invite";
            case "clan_war_participation" -> clan.isWarParticipation() ? "enabled" : "disabled";

            // ── Color ──
            case "clan_color" -> clan.getGradientStart() != null ? clan.getGradientStart() : "#FFFFFF";
            case "clan_gradient_start" -> clan.getGradientStart() != null ? clan.getGradientStart() : "";
            case "clan_gradient_end" -> clan.getGradientEnd() != null ? clan.getGradientEnd() : "";
            case "clan_use_gradient" -> clan.isTagUseGradient() ? "true" : "false";

            // ── Leader ──
            case "clan_leader" -> {
                for (ClanMember m : clan.getMembers()) {
                    if (m.getRole() == com.ethernova.clans.clan.ClanRole.LEADER) {
                        yield m.getName();
                    }
                }
                yield "";
            }

            default -> null; // Return null for unknown placeholders
        };
    }
}
