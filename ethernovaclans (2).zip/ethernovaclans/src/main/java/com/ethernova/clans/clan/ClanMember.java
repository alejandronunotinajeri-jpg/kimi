package com.ethernova.clans.clan;

import java.time.Instant;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Represents a member of a clan with their individual stats and metadata.
 * Thread-safe: mutable fields use volatile or AtomicInteger.
 */
public class ClanMember {

    private final UUID uuid;
    private volatile String name;
    private volatile ClanRole role;
    private volatile String rankId;  // Custom rank id (null = use legacy ClanRole)
    private final AtomicInteger kills = new AtomicInteger(0);
    private final AtomicInteger deaths = new AtomicInteger(0);
    private volatile int powerContributed;
    private volatile Instant joinDate;
    private volatile Instant lastSeen;
    private volatile boolean online;

    public ClanMember(UUID uuid, String name, ClanRole role) {
        this.uuid = uuid;
        this.name = name;
        this.role = role;
        this.rankId = ClanRank.fromLegacyRole(role);
        this.powerContributed = 0;
        this.joinDate = Instant.now();
        this.lastSeen = Instant.now();
        this.online = false;
    }

    // ── Getters ──────────────────────────────────────────────

    public UUID getUuid() {
        return uuid;
    }

    public String getName() {
        return name;
    }

    public ClanRole getRole() {
        return role;
    }

    public int getKills() {
        return kills.get();
    }

    public int getDeaths() {
        return deaths.get();
    }

    public double getKD() {
        int d = deaths.get();
        int k = kills.get();
        if (d == 0) return k;
        return Math.round((double) k / d * 100.0) / 100.0;
    }

    public int getPowerContributed() {
        return powerContributed;
    }

    public Instant getJoinDate() {
        return joinDate;
    }

    public Instant getLastSeen() {
        return lastSeen;
    }

    public boolean isOnline() {
        return online;
    }

    // ── Setters ──────────────────────────────────────────────

    public void setName(String name) {
        this.name = name;
    }

    public void setRole(ClanRole role) {
        this.role = role;
        this.rankId = ClanRank.fromLegacyRole(role);
    }

    public String getRankId() { return rankId != null ? rankId : ClanRank.fromLegacyRole(role); }

    public void setRankId(String rankId) { this.rankId = rankId; }

    public void setKills(int kills) {
        this.kills.set(kills);
    }

    public void setDeaths(int deaths) {
        this.deaths.set(deaths);
    }

    public void setPowerContributed(int powerContributed) {
        this.powerContributed = powerContributed;
    }

    public void setJoinDate(Instant joinDate) {
        this.joinDate = joinDate;
    }

    public void setLastSeen(Instant lastSeen) {
        this.lastSeen = lastSeen;
    }

    public void setOnline(boolean online) {
        this.online = online;
        this.lastSeen = Instant.now();
    }

    // ── Operations ───────────────────────────────────────────

    public void addKill() {
        this.kills.incrementAndGet();
    }

    public void addDeath() {
        this.deaths.incrementAndGet();
    }

    public void addPowerContributed(int amount) {
        synchronized (this) { this.powerContributed += amount; }
    }

    /**
     * Check if this member has a specific permission based on their role.
     * Falls back to legacy role-based check if no custom rank is set.
     */
    public boolean hasPermission(String permission) {
        // Role-based permission check (legacy) — checks if role is officer+
        // For fine-grained permissions, use hasPermission(Clan, String) with custom ranks
        if ("*".equals(permission)) return role == ClanRole.LEADER;
        return role.isAtLeast(ClanRole.OFFICER);
    }

    /**
     * Check if this member has a specific permission using the clan's custom rank system.
     */
    public boolean hasPermission(Clan clan, String permission) {
        ClanRank rank = clan.getRank(getRankId());
        if (rank == null) {
            // Fallback: legacy role-based
            return role.isAtLeast(ClanRole.OFFICER);
        }
        // Wildcard permission (leader has all)
        if (rank.hasPermission("*")) return true;
        return rank.hasPermission(permission);
    }

    /**
     * Promote this member to the next role.
     * @return true if promotion was successful
     */
    public boolean promote() {
        ClanRole next = role.promote();
        if (next == role) return false;
        this.role = next;
        return true;
    }

    /**
     * Demote this member to the previous role.
     * @return true if demotion was successful
     */
    public boolean demote() {
        ClanRole prev = role.demote();
        if (prev == role) return false;
        this.role = prev;
        return true;
    }
}
