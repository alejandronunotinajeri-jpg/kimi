package com.ethernova.clans.gui;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.gui.menus.*;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/**
 * Central GUI manager – routes all menu opens to the correct AbstractGui subclass.
 * Each Java GUI class loads its layout from the corresponding YAML in guis/ and
 * handles its own actions via processAction().
 */
public class GUIManager {

    private final EthernovaClans plugin;
    private final Map<UUID, String> openMenus = new ConcurrentHashMap<>();
    private final Map<UUID, String> configGUIMenus = new ConcurrentHashMap<>();
    private final Map<UUID, AbstractGui> activeAbstractGuis = new ConcurrentHashMap<>();
    private final Map<UUID, org.bukkit.inventory.Inventory> activeInventories = new ConcurrentHashMap<>();
    private final Map<UUID, Consumer<String>> anvilInputCallbacks = new ConcurrentHashMap<>();

    public GUIManager(EthernovaClans plugin) { this.plugin = plugin; }

    // ── Menu registration (used by AbstractGui.open() and ConfigurableGUI) ──

    public void registerConfigGUI(UUID uuid, String guiName, org.bukkit.inventory.Inventory inv) {
        openMenus.put(uuid, "config:" + guiName);
        configGUIMenus.put(uuid, guiName);
        if (inv != null) activeInventories.put(uuid, inv);
        activeAbstractGuis.remove(uuid);
    }

    public void registerGui(Player player, AbstractGui gui) {
        openMenus.put(player.getUniqueId(), "abstract:" + gui.getClass().getSimpleName());
        activeAbstractGuis.put(player.getUniqueId(), gui);
        if (gui.getInventory() != null) activeInventories.put(player.getUniqueId(), gui.getInventory());
        configGUIMenus.remove(player.getUniqueId());
    }

    // ── Click / Close handling ──────────────────────────────

    public void handleClick(InventoryClickEvent event) {
        Player player = (Player) event.getWhoClicked();
        String menu = openMenus.get(player.getUniqueId());
        if (menu == null) return;
        event.setCancelled(true);

        if (menu.startsWith("config:")) {
            String guiName = configGUIMenus.get(player.getUniqueId());
            if (guiName != null) {
                plugin.getConfigurableGUI().handleClick(player, guiName, event);
            }
            return;
        }

        if (menu.startsWith("abstract:")) {
            AbstractGui gui = activeAbstractGuis.get(player.getUniqueId());
            if (gui != null) {
                gui.handleClick(event);
            }
        }
    }

    /**
     * Inventory-aware close: only cleans up if the closing inventory matches
     * the registered GUI inventory. Prevents openInventory() close events from
     * accidentally removing a freshly-registered GUI.
     */
    public void handleClose(Player player, org.bukkit.inventory.Inventory closingInv) {
        org.bukkit.inventory.Inventory registered = activeInventories.get(player.getUniqueId());
        if (registered != null && closingInv != null && !registered.equals(closingInv)) {
            return; // A different inventory is closing, not our GUI
        }
        forceClose(player);
    }

    /** Force-close: always removes registration regardless of inventory (used on quit). */
    public void handleClose(Player player) {
        forceClose(player);
    }

    private void forceClose(Player player) {
        openMenus.remove(player.getUniqueId());
        configGUIMenus.remove(player.getUniqueId());
        activeInventories.remove(player.getUniqueId());
        AbstractGui gui = activeAbstractGuis.remove(player.getUniqueId());
        if (gui != null) {
            gui.onClose();
        }
    }

    public boolean isInMenu(UUID uuid) { return openMenus.containsKey(uuid); }

    // ══════════════════════════════════════════════════════════
    //  CENTRAL GUI ROUTER
    //  Routes a GUI name (from YAML 'action: "OPEN_GUI:xxx"') to the correct
    //  AbstractGui subclass. This is the SINGLE place that decides which Java
    //  class handles each menu.
    // ══════════════════════════════════════════════════════════

    public void openGui(Player player, String guiName) {
        if (guiName == null || guiName.isBlank()) return;

        switch (guiName.toLowerCase()) {
            // ── Main menu ──
            case "main-menu", "main_menu", "main", "menu" -> openMainMenu(player);

            // ── Core menus ──
            case "members"          -> openMembers(player);
            case "bank"             -> openBank(player);
            case "territory"        -> openTerritory(player);
            case "wars"             -> openWars(player);
            case "settings"         -> openSettings(player);
            case "tops"             -> openTops(player);
            case "upgrades"         -> openUpgrades(player);
            case "progress"         -> openProgress(player);
            case "diplomacy"        -> openDiplomacy(player);
            case "color-picker"     -> openColorPicker(player);
            case "missions"         -> openMissions(player);
            case "achievements"     -> openAchievements(player);
            case "boosts"           -> openBoosts(player);
            case "permissions"      -> openPermissions(player);
            case "audit-log"        -> openAuditLog(player);
            case "invitations"      -> openInvitations(player);
            case "invite-players"   -> openInvitePlayers(player);

            // ── Admin menus ──
            case "admin-menu"       -> openAdminMenu(player);
            case "admin-clan-list"  -> openAdminClanList(player);

            // ── God-Tier menus ──
            case "clan-skills", "skills"          -> openClanSkills(player);
            case "clan-shop", "shop"              -> openClanShop(player);
            case "event-calendar", "events"       -> openEventCalendar(player);
            case "trophies", "hall-of-fame"       -> openTrophies(player);
            case "stats", "statistics"            -> openStats(player);
            case "warps"                          -> openWarps(player);
            case "icon-selector", "icon"          -> openIconSelector(player);

            // ── Ultimate menus ──
            case "blueprints", "blueprint"        -> openBlueprints(player);
            case "blueprints-admin"               -> openBlueprintAdmin(player);
            case "seasons", "season", "rankings"  -> openSeasons(player);

            // ── Fallback: try ConfigurableGUI for unknown names ──
            default -> plugin.getConfigurableGUI().open(player, guiName);
        }
    }

    // ══════════════════════════════════════════════════════════
    //  INDIVIDUAL GUI OPENERS
    // ══════════════════════════════════════════════════════════

    public void openMainMenu(Player player) {
        new ClanMainGui(plugin, player).open();
    }

    public void openMembers(Player player) {
        new MembersGui(plugin, player).open();
    }

    public void openMemberList(Player player) {
        openMembers(player);
    }

    public void openBank(Player player) {
        new BankGui(plugin, player).open();
    }

    public void openTerritory(Player player) {
        new TerritoryMapGui(plugin, player).open();
    }

    public void openWars(Player player) {
        new WarsGui(plugin, player).open();
    }

    public void openWarMenu(Player player) {
        openWars(player);
    }

    public void openSettings(Player player) {
        new SettingsGui(plugin, player).open();
    }

    public void openTops(Player player) {
        new TopsGui(plugin, player).open();
    }

    public void openUpgrades(Player player) {
        new UpgradesGui(plugin, player).open();
    }

    public void openProgress(Player player) {
        new ProgressGui(plugin, player).open();
    }

    public void openDiplomacy(Player player) {
        new DiplomacyGui(plugin, player).open();
    }

    public void openColorPicker(Player player) {
        new ColorPickerGui(plugin, player).open();
    }

    public void openMissions(Player player) {
        new MissionsGui(plugin, player).open();
    }

    public void openAchievements(Player player) {
        new AchievementsGui(plugin, player).open();
    }

    public void openBoosts(Player player) {
        new BoostsGui(plugin, player).open();
    }

    public void openPermissions(Player player) {
        new PermissionsGui(plugin, player).open();
    }

    public void openAuditLog(Player player) {
        new AuditLogGui(plugin, player).open();
    }

    public void openInvitations(Player player) {
        new InvitationsGui(plugin, player).open();
    }

    public void openInvitePlayers(Player player) {
        new InvitePlayersGui(plugin, player).open();
    }

    public void openAdminMenu(Player player) {
        new AdminMainGui(plugin, player).open();
    }

    public void openAdminClanList(Player player) {
        new AdminClanListGui(plugin, player).open();
    }

    public void openAdminClan(Player player, Clan clan) {
        new AdminClanGui(plugin, player, clan).open();
    }

    public void openAdminPlayer(Player admin, Player target) {
        new AdminPlayerGui(plugin, admin, target).open();
    }

    // ── God-Tier Feature GUIs ────────────────────────────

    public void openClanSkills(Player player) {
        new ClanSkillsGui(plugin, player).open();
    }

    public void openClanShop(Player player) {
        new ClanShopGui(plugin, player).open();
    }

    public void openEventCalendar(Player player) {
        new EventCalendarGui(plugin, player).open();
    }

    public void openTrophies(Player player) {
        new TrophiesGui(plugin, player).open();
    }

    public void openStats(Player player) {
        new StatsGui(plugin, player).open();
    }

    public void openWarps(Player player) {
        new WarpsGui(plugin, player).open();
    }

    public void openIconSelector(Player player) {
        new IconSelectorGui(plugin, player).open();
    }

    // ── Ultimate Feature GUIs ────────────────────────────

    public void openBlueprints(Player player) {
        new BlueprintMenuGui(plugin, player).open();
    }

    public void openBlueprintAdmin(Player player) {
        new BlueprintAdminGui(plugin, player).open();
    }

    public void openSeasons(Player player) {
        new SeasonGui(plugin, player).open();
    }

    // ── Anvil Input ──────────────────────────────────────────

    public void registerAnvilInput(Player player, Consumer<String> callback) {
        anvilInputCallbacks.put(player.getUniqueId(), callback);
    }

    public Consumer<String> consumeAnvilInput(UUID uuid) {
        return anvilInputCallbacks.remove(uuid);
    }

    public boolean hasAnvilInput(UUID uuid) {
        return anvilInputCallbacks.containsKey(uuid);
    }

    /** Clean up all GUI state for a player (call on quit). */
    public void removePlayer(UUID uuid) {
        openMenus.remove(uuid);
        configGUIMenus.remove(uuid);
        activeInventories.remove(uuid);
        AbstractGui gui = activeAbstractGuis.remove(uuid);
        if (gui != null) {
            gui.onClose();
        }
        anvilInputCallbacks.remove(uuid);
    }
}
