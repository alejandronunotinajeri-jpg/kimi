package com.ethernova.clans.blueprint;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.message.MessageManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.stream.Collectors;

/**
 * Manages the Blueprint/Structure system: loading config, CRUD, effects.
 */
public class BlueprintManager {

    private final EthernovaClans plugin;

    /** Blueprint type definitions loaded from YAML */
    private final Map<String, Blueprint> blueprintTypes = new LinkedHashMap<>();

    /** clanId → list of built blueprints */
    private final Map<String, List<ClanBlueprint>> clanBlueprints = new ConcurrentHashMap<>();

    /** Max blueprints per clan level (configured) */
    private final Map<Integer, Integer> maxPerLevel = new LinkedHashMap<>();

    private boolean enabled = true;

    public BlueprintManager(EthernovaClans plugin) {
        this.plugin = plugin;
        loadConfig();
    }

    // ══════════════════════════════════════════════════════════
    //  CONFIG LOADING
    // ══════════════════════════════════════════════════════════

    public void loadConfig() {
        blueprintTypes.clear();
        maxPerLevel.clear();

        File file = new File(plugin.getDataFolder(), "blueprints.yml");
        if (!file.exists()) {
            plugin.saveResource("blueprints.yml", false);
        }
        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);

        enabled = config.getBoolean("enabled", true);
        if (!enabled) return;

        // Max per level
        ConfigurationSection maxSection = config.getConfigurationSection("max-per-clan-level");
        if (maxSection != null) {
            for (String key : maxSection.getKeys(false)) {
                try { maxPerLevel.put(Integer.parseInt(key), maxSection.getInt(key)); }
                catch (NumberFormatException ignored) {}
            }
        }

        // Load structure definitions
        ConfigurationSection structures = config.getConfigurationSection("structures");
        if (structures == null) return;

        for (String id : structures.getKeys(false)) {
            ConfigurationSection sec = structures.getConfigurationSection(id);
            if (sec == null) continue;

            String name = sec.getString("name", id);
            Material icon;
            try { icon = Material.valueOf(sec.getString("icon", "COBBLESTONE").toUpperCase()); }
            catch (Exception e) { icon = Material.COBBLESTONE; }
            int maxLev = sec.getInt("max-level", 3);

            Map<Integer, Blueprint.BlueprintLevel> levels = new LinkedHashMap<>();
            ConfigurationSection levelsSection = sec.getConfigurationSection("levels");
            if (levelsSection != null) {
                for (String levKey : levelsSection.getKeys(false)) {
                    int lev;
                    try { lev = Integer.parseInt(levKey); }
                    catch (NumberFormatException e) { continue; }

                    ConfigurationSection ls = levelsSection.getConfigurationSection(levKey);
                    if (ls == null) continue;

                    double cost = ls.getDouble("cost", 0);

                    Map<Material, Integer> materials = new LinkedHashMap<>();
                    ConfigurationSection matsSection = ls.getConfigurationSection("materials");
                    if (matsSection != null) {
                        for (String matKey : matsSection.getKeys(false)) {
                            try {
                                materials.put(Material.valueOf(matKey.toUpperCase()), matsSection.getInt(matKey));
                            } catch (Exception ignored) {}
                        }
                    }

                    Map<String, Double> effects = new LinkedHashMap<>();
                    ConfigurationSection efxSection = ls.getConfigurationSection("effects");
                    if (efxSection != null) {
                        for (String efxKey : efxSection.getKeys(false)) {
                            effects.put(efxKey, efxSection.getDouble(efxKey));
                        }
                    }

                    levels.put(lev, new Blueprint.BlueprintLevel(lev, cost, materials, effects));
                }
            }

            blueprintTypes.put(id, new Blueprint(id, name, icon, maxLev, levels));
        }

        plugin.getLogger().info("  Blueprints: " + blueprintTypes.size() + " tipos cargados");
    }

    // ══════════════════════════════════════════════════════════
    //  DATABASE PERSISTENCE
    // ══════════════════════════════════════════════════════════

    public void loadAll() {
        clanBlueprints.clear();
        try (Connection conn = plugin.getStorageManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT blueprint_id, clan_id, chunk_id, level, built_at FROM clan_blueprints")) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ClanBlueprint cb = new ClanBlueprint(
                        rs.getString("blueprint_id"),
                        rs.getString("clan_id"),
                        rs.getString("chunk_id"),
                        rs.getInt("level"),
                        rs.getLong("built_at")
                );
                clanBlueprints.computeIfAbsent(cb.getClanId(), k -> new ArrayList<>()).add(cb);
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error loading blueprints", e);
        }
    }

    public void saveAll() {
        try (Connection conn = plugin.getStorageManager().getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement del = conn.prepareStatement("DELETE FROM clan_blueprints");
                 PreparedStatement ins = conn.prepareStatement(
                         "INSERT INTO clan_blueprints (blueprint_id, clan_id, chunk_id, level, built_at) VALUES (?, ?, ?, ?, ?)")) {
                del.executeUpdate();
                for (List<ClanBlueprint> list : clanBlueprints.values()) {
                    for (ClanBlueprint cb : list) {
                        ins.setString(1, cb.getBlueprintId());
                        ins.setString(2, cb.getClanId());
                        ins.setString(3, cb.getChunkId());
                        ins.setInt(4, cb.getLevel());
                        ins.setLong(5, cb.getBuiltAt());
                        ins.addBatch();
                    }
                }
                ins.executeBatch();
                conn.commit();
            } catch (Exception e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error saving blueprints", e);
        }
    }

    // ══════════════════════════════════════════════════════════
    //  CRUD OPERATIONS
    // ══════════════════════════════════════════════════════════

    /**
     * Build a new blueprint for a clan in the given chunk.
     * @return true if built successfully
     */
    public boolean build(Clan clan, String blueprintId, String chunkId, Player player) {
        Blueprint bp = blueprintTypes.get(blueprintId);
        if (bp == null) {
            plugin.getMessageManager().sendMessage(player, "blueprint.invalid-type");
            return false;
        }

        // Check territory ownership
        String owner = plugin.getTerritoryManager().getOwner(chunkId);
        if (owner == null || !owner.equals(clan.getId())) {
            plugin.getMessageManager().sendMessage(player, "blueprint.not-in-territory");
            return false;
        }

        // Check if already has this type
        List<ClanBlueprint> existing = clanBlueprints.getOrDefault(clan.getId(), new ArrayList<>());
        if (existing.stream().anyMatch(cb -> cb.getBlueprintId().equals(blueprintId))) {
            plugin.getMessageManager().sendMessage(player, "blueprint.already-built", "{structure}", bp.getName());
            return false;
        }

        // Check max slots
        int maxSlots = getMaxSlots(clan.getLevel());
        if (existing.size() >= maxSlots) {
            plugin.getMessageManager().sendMessage(player, "blueprint.max-reached", "{max}", String.valueOf(maxSlots));
            return false;
        }

        // Check if chunk already has a blueprint
        if (existing.stream().anyMatch(cb -> cb.getChunkId().equals(chunkId))) {
            plugin.getMessageManager().sendMessage(player, "blueprint.chunk-has-blueprint");
            return false;
        }

        Blueprint.BlueprintLevel level1 = bp.getLevel(1);
        if (level1 == null) {
            plugin.getMessageManager().sendMessage(player, "blueprint.invalid-type");
            return false;
        }

        // Check cost
        if (!checkAndDeductCost(clan, player, level1)) return false;

        // Check materials
        if (!checkAndDeductMaterials(player, level1)) return false;

        // Build it
        ClanBlueprint newBp = new ClanBlueprint(blueprintId, clan.getId(), chunkId, 1, System.currentTimeMillis());
        clanBlueprints.computeIfAbsent(clan.getId(), k -> new ArrayList<>()).add(newBp);

        plugin.getMessageManager().sendMessage(player, "blueprint.built",
                "{structure}", bp.getName(), "{chunk}", chunkId);

        // Place hologram if available
        placeHologram(newBp);
        return true;
    }

    /**
     * Upgrade an existing blueprint to the next level.
     */
    public boolean upgrade(Clan clan, String blueprintId, Player player) {
        List<ClanBlueprint> list = clanBlueprints.get(clan.getId());
        if (list == null) {
            plugin.getMessageManager().sendMessage(player, "blueprint.not-built", "{structure}", blueprintId);
            return false;
        }

        ClanBlueprint cb = list.stream().filter(b -> b.getBlueprintId().equals(blueprintId)).findFirst().orElse(null);
        if (cb == null) {
            plugin.getMessageManager().sendMessage(player, "blueprint.not-built", "{structure}", blueprintId);
            return false;
        }

        Blueprint bp = blueprintTypes.get(blueprintId);
        if (bp == null) return false;

        int nextLevel = cb.getLevel() + 1;
        if (nextLevel > bp.getMaxLevel()) {
            plugin.getMessageManager().sendMessage(player, "blueprint.max-level", "{structure}", bp.getName());
            return false;
        }

        Blueprint.BlueprintLevel nextLev = bp.getLevel(nextLevel);
        if (nextLev == null) return false;

        if (!checkAndDeductCost(clan, player, nextLev)) return false;
        if (!checkAndDeductMaterials(player, nextLev)) return false;

        cb.setLevel(nextLevel);
        plugin.getMessageManager().sendMessage(player, "blueprint.upgraded",
                "{structure}", bp.getName(), "{level}", String.valueOf(nextLevel));

        updateHologram(cb);
        return true;
    }

    /**
     * Demolish a blueprint, returning 50% materials.
     */
    public boolean demolish(Clan clan, String blueprintId, Player player) {
        List<ClanBlueprint> list = clanBlueprints.get(clan.getId());
        if (list == null) {
            plugin.getMessageManager().sendMessage(player, "blueprint.not-built", "{structure}", blueprintId);
            return false;
        }

        ClanBlueprint cb = list.stream().filter(b -> b.getBlueprintId().equals(blueprintId)).findFirst().orElse(null);
        if (cb == null) {
            plugin.getMessageManager().sendMessage(player, "blueprint.not-built", "{structure}", blueprintId);
            return false;
        }

        Blueprint bp = blueprintTypes.get(blueprintId);
        if (bp == null) return false;

        // Refund 50% materials
        Blueprint.BlueprintLevel lev = bp.getLevel(cb.getLevel());
        if (lev != null) {
            for (var entry : lev.getMaterials().entrySet()) {
                int refund = entry.getValue() / 2;
                if (refund > 0) {
                    player.getInventory().addItem(new org.bukkit.inventory.ItemStack(entry.getKey(), refund));
                }
            }
            // Refund 50% money
            double moneyRefund = lev.getCost() / 2;
            if (moneyRefund > 0) {
                plugin.getBankManager().setBalance(clan.getId(),
                        plugin.getBankManager().getBalance(clan.getId()) + moneyRefund);
            }
        }

        removeHologram(cb);
        list.remove(cb);
        if (list.isEmpty()) clanBlueprints.remove(clan.getId());

        plugin.getMessageManager().sendMessage(player, "blueprint.demolished", "{structure}", bp.getName());
        return true;
    }

    /**
     * Remove all blueprints for a clan (e.g., on disband).
     */
    public void removeAllForClan(String clanId) {
        List<ClanBlueprint> list = clanBlueprints.remove(clanId);
        if (list != null) {
            for (ClanBlueprint cb : list) removeHologram(cb);
        }
    }

    /**
     * Remove blueprints in a specific chunk (e.g., chunk lost in siege).
     */
    public void removeInChunk(String clanId, String chunkId) {
        List<ClanBlueprint> list = clanBlueprints.get(clanId);
        if (list == null) return;
        list.removeIf(cb -> {
            if (cb.getChunkId().equals(chunkId)) {
                removeHologram(cb);
                return true;
            }
            return false;
        });
    }

    // ══════════════════════════════════════════════════════════
    //  EFFECT QUERIES
    // ══════════════════════════════════════════════════════════

    /**
     * Get the total effect value of a specific effect type for a clan across all blueprints.
     */
    public double getTotalEffect(String clanId, String effectKey) {
        List<ClanBlueprint> list = clanBlueprints.get(clanId);
        if (list == null) return 0;

        double total = 0;
        for (ClanBlueprint cb : list) {
            Blueprint bp = blueprintTypes.get(cb.getBlueprintId());
            if (bp == null) continue;
            Blueprint.BlueprintLevel lev = bp.getLevel(cb.getLevel());
            if (lev == null) continue;
            total += lev.getEffect(effectKey);
        }
        return total;
    }

    /**
     * Check if clan has a specific blueprint type in the given chunk.
     */
    public boolean hasInChunk(String clanId, String chunkId, String blueprintId) {
        List<ClanBlueprint> list = clanBlueprints.get(clanId);
        if (list == null) return false;
        return list.stream().anyMatch(
                cb -> cb.getChunkId().equals(chunkId) && cb.getBlueprintId().equals(blueprintId));
    }

    /**
     * Get all blueprints for a clan.
     */
    public List<ClanBlueprint> getBlueprints(String clanId) {
        return clanBlueprints.getOrDefault(clanId, Collections.emptyList());
    }

    /**
     * Get all built blueprints across all clans (for admin view/stats).
     */
    public Map<String, List<ClanBlueprint>> getAllBlueprints() {
        return Collections.unmodifiableMap(clanBlueprints);
    }

    public int getMaxSlots(int clanLevel) {
        int max = 2; // default
        for (var entry : maxPerLevel.entrySet()) {
            if (clanLevel >= entry.getKey()) max = entry.getValue();
        }
        return max;
    }

    public Map<String, Blueprint> getBlueprintTypes() {
        return Collections.unmodifiableMap(blueprintTypes);
    }

    public Blueprint getBlueprintType(String id) {
        return blueprintTypes.get(id);
    }

    public boolean isEnabled() { return enabled; }

    public Collection<String> getBlueprintTypeIds() { return blueprintTypes.keySet(); }

    public List<ClanBlueprint> getBlueprintsInChunk(String clanId, String chunkId) {
        List<ClanBlueprint> list = clanBlueprints.getOrDefault(clanId, Collections.emptyList());
        return list.stream().filter(cb -> cb.getChunkId().equals(chunkId)).collect(Collectors.toList());
    }

    public int getTotalBuilt() {
        return clanBlueprints.values().stream().mapToInt(List::size).sum();
    }

    public int getClansWithBlueprints() {
        return (int) clanBlueprints.values().stream().filter(l -> !l.isEmpty()).count();
    }

    // ══════════════════════════════════════════════════════════
    //  HELPERS
    // ══════════════════════════════════════════════════════════

    private boolean checkAndDeductCost(Clan clan, Player player, Blueprint.BlueprintLevel level) {
        double balance = plugin.getBankManager().getBalance(clan.getId());
        if (balance < level.getCost()) {
            plugin.getMessageManager().sendMessage(player, "blueprint.cannot-afford",
                    "{cost}", String.format("%.0f", level.getCost()));
            return false;
        }
        plugin.getBankManager().setBalance(clan.getId(), balance - level.getCost());
        return true;
    }

    private boolean checkAndDeductMaterials(Player player, Blueprint.BlueprintLevel level) {
        // First check all
        for (var entry : level.getMaterials().entrySet()) {
            if (!player.getInventory().containsAtLeast(
                    new org.bukkit.inventory.ItemStack(entry.getKey()), entry.getValue())) {
                plugin.getMessageManager().sendMessage(player, "blueprint.missing-materials",
                        "{material}", entry.getKey().name(), "{amount}", String.valueOf(entry.getValue()));
                return false;
            }
        }
        // Then deduct all
        for (var entry : level.getMaterials().entrySet()) {
            player.getInventory().removeItem(new org.bukkit.inventory.ItemStack(entry.getKey(), entry.getValue()));
        }
        return true;
    }

    private void placeHologram(ClanBlueprint cb) { /* future hologram integration */ }

    private void updateHologram(ClanBlueprint cb) { /* future hologram integration */ }

    private void removeHologram(ClanBlueprint cb) { /* future hologram integration */ }

    private String getClanName(String clanId) {
        Clan clan = plugin.getClanManager().getClan(clanId);
        return clan != null ? clan.getName() : clanId;
    }

    public void shutdown() {
        saveAll();
    }
}
