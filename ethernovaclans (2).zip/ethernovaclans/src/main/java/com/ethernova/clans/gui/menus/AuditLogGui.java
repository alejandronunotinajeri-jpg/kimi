package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.audit.AuditManager;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * GUI showing the clan's audit log / action history.
 */
public class AuditLogGui extends AbstractGui {

    private int page = 0;
    private static final int ITEMS_PER_PAGE = 28; // 4 rows of 7

    private static final int[] LOG_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34,
            37, 38, 39, 40, 41, 42, 43
    };

    public AuditLogGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "audit-log");
    }

    @Override
    protected void populateItems() {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return;

        AuditManager am = plugin.getAuditManager();
        if (am == null) return;

        int totalEntries = am.getTotalEntries(clan);
        int maxPages = Math.max(1, (int) Math.ceil((double) totalEntries / ITEMS_PER_PAGE));
        if (page >= maxPages) page = maxPages - 1;
        if (page < 0) page = 0;

        List<AuditManager.AuditEntry> entries = am.getLog(clan, page, ITEMS_PER_PAGE);

        // Header
        setItem(4, new ItemBuilder(Material.WRITABLE_BOOK)
                .name("<gradient:#A855F7:#6366F1>📋 Historial del Clan</gradient>")
                .lore(List.of(
                        "",
                        "<gray>Total de registros: <white>" + totalEntries,
                        "<gray>Página: <yellow>" + (page + 1) + "/" + maxPages,
                        "",
                        "<gray>Se guardan los últimos 100 eventos."
                ))
                .glow()
                .build());

        // Clear log slots
        for (int slot : LOG_SLOTS) {
            inventory.setItem(slot, null);
        }

        if (entries.isEmpty()) {
            setItem(22, new ItemBuilder(Material.BARRIER)
                    .name("<gray>No hay registros")
                    .lore(List.of("", "<gray>El historial está vacío."))
                    .build());
            return;
        }

        for (int i = 0; i < LOG_SLOTS.length && i < entries.size(); i++) {
            AuditManager.AuditEntry entry = entries.get(i);
            String icon = AuditManager.getActionIcon(entry.action());
            String time = AuditManager.formatTimestamp(entry.timestamp());

            Material mat = getActionMaterial(entry.action());

            List<String> lore = new ArrayList<>();
            lore.add("");
            lore.add("<gray>Jugador: <white>" + entry.playerName());
            lore.add("<gray>Acción: <yellow>" + entry.action());
            lore.add("<gray>Detalle: <white>" + entry.details());
            lore.add("");
            lore.add("<dark_gray>" + time);

            setItem(LOG_SLOTS[i], new ItemBuilder(mat)
                    .name(icon + " " + entry.details())
                    .lore(lore)
                    .build());
        }

        // Page controls
        setItem(48, new ItemBuilder(Material.PAPER)
                .name("<yellow>Página " + (page + 1) + "/" + maxPages)
                .build());

        if (page > 0) {
            setItem(45, new ItemBuilder(Material.ARROW)
                    .name("<yellow>← Página anterior")
                    .build());
            slotActions.put(45, "PREV_PAGE");
        }

        if (page < maxPages - 1) {
            setItem(53, new ItemBuilder(Material.ARROW)
                    .name("<yellow>Página siguiente →")
                    .build());
            slotActions.put(53, "NEXT_PAGE");
        }
    }

    private Material getActionMaterial(String action) {
        return switch (action.toUpperCase()) {
            case "DEPOSIT" -> Material.GOLD_INGOT;
            case "WITHDRAW" -> Material.GOLD_NUGGET;
            case "INVITE", "JOIN" -> Material.OAK_DOOR;
            case "KICK", "LEAVE" -> Material.IRON_DOOR;
            case "CLAIM" -> Material.FILLED_MAP;
            case "UNCLAIM" -> Material.MAP;
            case "UPGRADE" -> Material.ANVIL;
            case "WAR_START" -> Material.IRON_SWORD;
            case "WAR_END" -> Material.SHIELD;
            case "SETTINGS" -> Material.COMPARATOR;
            case "PROMOTE" -> Material.EMERALD;
            case "DEMOTE" -> Material.REDSTONE;
            case "ALLY" -> Material.BOOK;
            case "RIVAL" -> Material.BLAZE_POWDER;
            default -> Material.PAPER;
        };
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        return switch (action.toUpperCase()) {
            case "PREV_PAGE" -> { page = Math.max(0, page - 1); refreshGui(); yield true; }
            case "NEXT_PAGE" -> { page++; refreshGui(); yield true; }
            default -> false;
        };
    }

    private void refreshGui() {
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            slotActions.clear();
            rightClickActions.clear();
            slotConfigs.clear();
            occupiedSlots.clear();
            fillBackground();
            placeConfigItems();
            populateItems();
        });
    }
}
