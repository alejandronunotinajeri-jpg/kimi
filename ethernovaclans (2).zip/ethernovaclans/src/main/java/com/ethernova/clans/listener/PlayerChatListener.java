package com.ethernova.clans.listener;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

/**
 * Handles clan chat (prefix-based or toggle-based).
 */
public class PlayerChatListener implements Listener {

    private final EthernovaClans plugin;

    public PlayerChatListener(EthernovaClans plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        Player player = event.getPlayer();
        String message = PlainTextComponentSerializer.plainText().serialize(event.message());

        if (plugin.getChatManager().isInClanChat(player.getUniqueId())) {
            event.setCancelled(true);
            Clan clan = plugin.getClanManager().getClanByPlayer(player.getUniqueId());
            if (clan != null) plugin.getChatManager().sendClanMessage(player, clan, message);
            return;
        }

        if (plugin.getChatManager().isInAllyChat(player.getUniqueId())) {
            event.setCancelled(true);
            Clan clan = plugin.getClanManager().getClanByPlayer(player.getUniqueId());
            if (clan != null) plugin.getChatManager().sendAllyMessage(player, clan, message);
        }
    }
}
