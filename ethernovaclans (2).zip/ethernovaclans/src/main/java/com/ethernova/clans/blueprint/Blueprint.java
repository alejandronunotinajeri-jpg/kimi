package com.ethernova.clans.blueprint;

import org.bukkit.Material;

import java.util.List;
import java.util.Map;

/**
 * Represents a blueprint structure type definition loaded from config.
 */
public class Blueprint {

    private final String id;
    private final String name;
    private final Material icon;
    private final int maxLevel;
    private final Map<Integer, BlueprintLevel> levels;

    public Blueprint(String id, String name, Material icon, int maxLevel, Map<Integer, BlueprintLevel> levels) {
        this.id = id;
        this.name = name;
        this.icon = icon;
        this.maxLevel = maxLevel;
        this.levels = levels;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public Material getIcon() { return icon; }
    public int getMaxLevel() { return maxLevel; }
    public BlueprintLevel getLevel(int level) { return levels.get(level); }
    public Map<Integer, BlueprintLevel> getLevels() { return levels; }

    /**
     * Represents one level of a blueprint with cost, materials, and effects.
     */
    public static class BlueprintLevel {
        private final int level;
        private final double cost;
        private final Map<Material, Integer> materials;
        private final Map<String, Double> effects;

        public BlueprintLevel(int level, double cost, Map<Material, Integer> materials, Map<String, Double> effects) {
            this.level = level;
            this.cost = cost;
            this.materials = materials;
            this.effects = effects;
        }

        public int getLevel() { return level; }
        public double getCost() { return cost; }
        public Map<Material, Integer> getMaterials() { return materials; }
        public Map<String, Double> getEffects() { return effects; }

        public double getEffect(String key) {
            return effects.getOrDefault(key, 0.0);
        }
    }
}
