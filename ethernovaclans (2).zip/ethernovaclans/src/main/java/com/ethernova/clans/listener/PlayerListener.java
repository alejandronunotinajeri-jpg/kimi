package com.ethernova.clans.listener;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanMember;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * Unified handler for player join/quit events.
 * Handles: member tracking, boosts, nametags, war context, tab format,
 * invite check, clan notifications, and full cleanup on quit.
 */
public class PlayerListener implements Listener {

    private final EthernovaClans plugin;

    public PlayerListener(EthernovaClans plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan != null) {
            // Update member name, online status, last seen
            ClanMember member = clan.getMember(player.getUniqueId());
            if (member != null) {
                member.setOnline(true);
                member.setLastSeen(java.time.Instant.now());
                if (!member.getName().equals(player.getName())) {
                    member.setName(player.getName());
                }
            }

            // War context
            if (plugin.getWarManager() != null && plugin.getWarManager().isAtWar(clan)
                    && plugin.getCoreHook() != null && plugin.getCoreHook().isAvailable()) {
                plugin.getCoreHook().addContext(player.getUniqueId(), "war");
            }

            // Apply level boosts
            if (plugin.getLevelManager() != null) {
                plugin.getLevelManager().applyBoosts(player, clan);
            }

            // Nametag update
            if (plugin.getNametagManager() != null) {
                plugin.getNametagManager().updatePlayer(player);
            }

            // Notify clan members (single notification)
            for (ClanMember m : clan.getOnlineMembers()) {
                if (m.getUuid().equals(player.getUniqueId())) continue;
                Player p = plugin.getServer().getPlayer(m.getUuid());
                if (p != null) {
                    plugin.getMessageManager().sendMessage(p, "clan.member-online", "{player}", player.getName());
                }
            }
        }

        // Update nametag for players without a clan too
        if (clan == null && plugin.getNametagManager() != null) {
            plugin.getNametagManager().updatePlayer(player);
        }

        // Tab format update (delayed)
        if (plugin.getChatFormatListener() != null) {
            org.bukkit.Bukkit.getScheduler().runTaskLater(plugin, () ->
                    plugin.getChatFormatListener().updateTab(player), 5L);
        }

        // Check pending invites (delayed)
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            int inviteCount = 0;
            for (Clan c : plugin.getClanManager().getAllClans()) {
                if (c.hasInvite(player.getUniqueId())) inviteCount++;
            }
            if (inviteCount > 0) {
                player.sendMessage(plugin.getConfigManager().getMessage("invite.pending-notification",
                        "count", String.valueOf(inviteCount)));
                player.sendMessage(plugin.getConfigManager().getMessage("invite.pending-notification-hint"));
                player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
            }
        }, 40L);
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();

        // War context cleanup
        if (plugin.getCoreHook() != null && plugin.getCoreHook().isAvailable()) {
            plugin.getCoreHook().removeContext(player.getUniqueId(), "war");
        }

        // Territory autoclaim stop
        if (plugin.getTerritoryManager() != null) {
            plugin.getTerritoryManager().stopAutoClaim(player.getUniqueId());
        }

        // Chat cleanup
        if (plugin.getChatManager() != null) {
            plugin.getChatManager().exitAllChats(player.getUniqueId());
        }

        // Teleport cancel
        if (plugin.getTeleportManager() != null) {
            plugin.getTeleportManager().cancelTeleport(player.getUniqueId());
        }

        // Power cleanup
        if (plugin.getPowerManager() != null) {
            plugin.getPowerManager().removePlayer(player.getUniqueId());
        }

        // Fly cleanup
        if (plugin.getFlyManager() != null) {
            plugin.getFlyManager().disableFly(player);
        }

        // GUI cleanup
        if (plugin.getGuiManager() != null) {
            plugin.getGuiManager().handleClose(player);
            plugin.getGuiManager().consumeAnvilInput(player.getUniqueId());
        }

        // Clan-specific quit handling
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan != null) {
            ClanMember member = clan.getMember(player.getUniqueId());
            if (member != null) {
                member.setOnline(false);
                member.setLastSeen(java.time.Instant.now());
            }

            // Remove boosts
            if (plugin.getLevelManager() != null) {
                plugin.getLevelManager().removeBoosts(player, clan);
            }

            // Notify clan members (single notification)
            for (ClanMember m : clan.getOnlineMembers()) {
                if (m.getUuid().equals(player.getUniqueId())) continue;
                Player p = plugin.getServer().getPlayer(m.getUuid());
                if (p != null) {
                    plugin.getMessageManager().sendMessage(p, "clan.member-offline", "{player}", player.getName());
                }
            }

            // Save clan data async
            plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () ->
                    plugin.getStorageManager().saveClan(clan));
        }
    }
}
