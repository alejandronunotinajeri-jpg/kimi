package com.ethernova.clans.event;

import com.ethernova.clans.clan.Clan;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Fired when a clan sets another clan as a rival.
 * Cancellable to prevent the rivalry.
 */
public class ClanRivalEvent extends Event implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();
    private boolean cancelled = false;

    private final Clan clan;
    private final Clan rivalClan;
    private final @Nullable Player initiator;

    public ClanRivalEvent(@NotNull Clan clan, @NotNull Clan rivalClan, @Nullable Player initiator) {
        this.clan = clan;
        this.rivalClan = rivalClan;
        this.initiator = initiator;
    }

    public @NotNull Clan getClan() { return clan; }
    public @NotNull Clan getRivalClan() { return rivalClan; }
    public @Nullable Player getInitiator() { return initiator; }

    @Override public boolean isCancelled() { return cancelled; }
    @Override public void setCancelled(boolean cancel) { this.cancelled = cancel; }
    @Override public @NotNull HandlerList getHandlers() { return HANDLERS; }
    public static HandlerList getHandlerList() { return HANDLERS; }
}
