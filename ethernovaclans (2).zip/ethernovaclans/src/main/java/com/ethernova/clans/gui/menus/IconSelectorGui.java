package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.SoundUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.List;

/**
 * GUI for selecting a clan icon from predefined categories.
 */
public class IconSelectorGui extends AbstractGui {

    /** Materials available for clan icons, organized by theme. */
    private static final Material[] ICONS = {
            // Weapons
            Material.DIAMOND_SWORD, Material.NETHERITE_SWORD, Material.IRON_SWORD,
            Material.BOW, Material.CROSSBOW, Material.TRIDENT,
            // Armor
            Material.DIAMOND_HELMET, Material.NETHERITE_CHESTPLATE, Material.SHIELD,
            // Nature
            Material.OAK_SAPLING, Material.SUNFLOWER, Material.WITHER_ROSE,
            Material.CACTUS, Material.BAMBOO, Material.CHERRY_SAPLING,
            // Valuables
            Material.DIAMOND, Material.EMERALD, Material.GOLD_INGOT,
            Material.NETHERITE_INGOT, Material.AMETHYST_SHARD, Material.LAPIS_LAZULI,
            // Redstone
            Material.REDSTONE, Material.TNT, Material.COMPARATOR,
            // Heads & Misc
            Material.DRAGON_HEAD, Material.WITHER_SKELETON_SKULL, Material.SKELETON_SKULL,
            Material.NETHER_STAR, Material.BEACON, Material.END_CRYSTAL,
            Material.TOTEM_OF_UNDYING, Material.HEART_OF_THE_SEA, Material.CONDUIT,
            // Animals
            Material.TURTLE_EGG, Material.PHANTOM_MEMBRANE, Material.BLAZE_ROD,
            // Food
            Material.GOLDEN_APPLE, Material.ENCHANTED_GOLDEN_APPLE, Material.CAKE,
    };

    /** Slots where icon items are placed (omit border slots). */
    private static final int[] ICON_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34,
            37, 38, 39, 40, 41, 42, 43
    };

    private int page = 0;

    public IconSelectorGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "icon-selector");
    }

    @Override
    protected int getMinimumSize() {
        return 54;
    }

    @Override
    protected void populateItems() {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return;

        String currentIcon = clan.getIcon();

        // Header
        setItem(4, new ItemBuilder(Material.PAINTING)
                .name("<gradient:#FFD700:#FF4500>\u2728 Icono del Clan</gradient>")
                .lore(List.of(
                        "",
                        "<gray>Actual: <yellow>" + (currentIcon != null ? currentIcon : "Ninguno"),
                        "",
                        "<gray>Elige un icono para representar",
                        "<gray>a tu clan en men\u00fas y rankings."
                ))
                .glow()
                .build());

        // Place icon items (paginated)
        int startIdx = page * ICON_SLOTS.length;
        int totalPages = (int) Math.ceil((double) ICONS.length / ICON_SLOTS.length);

        for (int i = 0; i < ICON_SLOTS.length; i++) {
            int iconIdx = startIdx + i;
            if (iconIdx >= ICONS.length) break;
            Material mat = ICONS[iconIdx];
            boolean selected = mat.name().equalsIgnoreCase(currentIcon);

            var builder = new ItemBuilder(mat)
                    .name((selected ? "<green>\u2714 " : "<white>") + formatMaterialName(mat.name()))
                    .lore(List.of(
                            "",
                            selected ? "<green>Seleccionado actualmente" : "<yellow>\u25b6 Click para seleccionar"
                    ));

            if (selected) builder.glow();

            setItem(ICON_SLOTS[i], builder.build());
        }

        // Pagination arrows
        if (page > 0) {
            setItem(45, new ItemBuilder(Material.ARROW)
                    .name("<yellow>◀ Página Anterior")
                    .lore(List.of("<gray>Página " + page + "/" + totalPages))
                    .build());
            slotActions.put(45, "PREV_PAGE");
        }
        if (page < totalPages - 1) {
            setItem(53, new ItemBuilder(Material.ARROW)
                    .name("<yellow>Página Siguiente ▶")
                    .lore(List.of("<gray>Página " + (page + 2) + "/" + totalPages))
                    .build());
            slotActions.put(53, "NEXT_PAGE");
        }

        // Back button
        setItem(49, new ItemBuilder(Material.ARROW)
                .name("<gray>\u25c0 Volver al men\u00fa")
                .build());
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        switch (action.toUpperCase()) {
            case "PREV_PAGE" -> {
                if (page > 0) {
                    page--;
                    plugin.getServer().getScheduler().runTask(plugin, this::refreshGui);
                }
                return true;
            }
            case "NEXT_PAGE" -> {
                page++;
                plugin.getServer().getScheduler().runTask(plugin, this::refreshGui);
                return true;
            }
        }
        return false;
    }

    @Override
    protected void onClick(int slot, InventoryClickEvent event) {
        // Back button
        if (slot == 49) {
            plugin.getServer().getScheduler().runTask(plugin, () ->
                    plugin.getGuiManager().openMainMenu(player));
            return;
        }

        // Check if clicked an icon slot
        int startIdx = page * ICON_SLOTS.length;
        for (int i = 0; i < ICON_SLOTS.length; i++) {
            int iconIdx = startIdx + i;
            if (iconIdx >= ICONS.length) break;
            if (ICON_SLOTS[i] == slot) {
                Clan clan = plugin.getClanManager().getClanByPlayer(player);
                if (clan == null) return;

                var iconMember = clan.getMember(player.getUniqueId());
                if (iconMember == null || !iconMember.getRole().isAtLeast(com.ethernova.clans.clan.ClanRole.LEADER)) {
                    plugin.getMessageManager().sendMessage(player, "error.no-permission");
                    SoundUtil.error(player);
                    return;
                }

                Material mat = ICONS[iconIdx];
                clan.setIcon(mat.name());

                // Save async
                Bukkit.getScheduler().runTaskAsynchronously(plugin, () ->
                        plugin.getStorageManager().saveClan(clan));

                plugin.getMessageManager().sendMessage(player, "clan.icon-changed",
                        "{icon}", formatMaterialName(mat.name()));
                SoundUtil.success(player);

                // Refresh to show new selection
                plugin.getServer().getScheduler().runTask(plugin, this::refreshGui);
                return;
            }
        }
    }

    private void refreshGui() {
        occupiedSlots.clear();
        slotActions.clear();
        rightClickActions.clear();
        slotConfigs.clear();
        fillBackground();
        placeConfigItems();
        populateItems();
    }

    /**
     * Converts MATERIAL_NAME to Material Name format.
     */
    private String formatMaterialName(String name) {
        String[] parts = name.toLowerCase().split("_");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (!sb.isEmpty()) sb.append(" ");
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }
}
