package com.ethernova.clans.api;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanMember;
import com.ethernova.clans.clan.ClanRole;
import com.ethernova.clans.war.WarManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

/**
 * Public API for the EthernovaClans plugin.
 *
 * <p>Third-party plugins should use this class exclusively to interact with
 * the clan system. Provides access to clan queries, territory, power, relations,
 * economy, wars, combat integration, levels, shields, and utilities.</p>
 *
 * <p>Obtain the singleton instance via {@link #getInstance()}.
 * Returns {@code null} if EthernovaClans is not loaded.</p>
 *
 * <p>All methods are thread-safe and null-safe.</p>
 */
public final class ClanAPI {

    private static ClanAPI instance;
    private final EthernovaClans plugin;

    private ClanAPI(EthernovaClans plugin) {
        this.plugin = plugin;
    }

    /**
     * Initialize the API singleton.
     * <p>Called internally by EthernovaClans on enable. Do not call externally.</p>
     *
     * @param plugin the EthernovaClans plugin instance
     */
    public static void init(EthernovaClans plugin) {
        instance = new ClanAPI(plugin);
    }

    /**
     * Get the ClanAPI singleton.
     *
     * @return the ClanAPI instance, or {@code null} if EthernovaClans is not loaded
     */
    @Nullable
    public static ClanAPI getInstance() {
        return instance;
    }

    // ══════════════════════════════════════════════════════════
    //  CLAN QUERIES
    // ══════════════════════════════════════════════════════════

    /**
     * Get a clan by its unique 8-character identifier.
     *
     * @param id the clan's unique ID
     * @return the {@link Clan}, or {@code null} if no clan with that ID exists
     */
    @Nullable
    public Clan getClanById(@NotNull String id) {
        return plugin.getClanManager().getClan(id);
    }

    /**
     * Get a clan by its display name (case-insensitive).
     *
     * @param name the clan's display name
     * @return the {@link Clan}, or {@code null} if not found
     */
    @Nullable
    public Clan getClanByName(@NotNull String name) {
        return plugin.getClanManager().getClanByName(name);
    }

    /**
     * Get a clan by its tag (case-insensitive).
     *
     * @param tag the clan's tag
     * @return the {@link Clan}, or {@code null} if not found
     */
    @Nullable
    public Clan getClanByTag(@NotNull String tag) {
        return plugin.getClanManager().getClanByTag(tag);
    }

    /**
     * Get the clan a player belongs to.
     *
     * @param uuid the UUID of the player
     * @return the player's {@link Clan}, or {@code null} if not in a clan
     */
    @Nullable
    public Clan getPlayerClan(@NotNull UUID uuid) {
        return plugin.getClanManager().getClanByPlayer(uuid);
    }

    /**
     * Get the clan a player belongs to.
     *
     * @param player the online player
     * @return the player's {@link Clan}, or {@code null} if not in a clan
     */
    @Nullable
    public Clan getPlayerClan(@NotNull Player player) {
        return plugin.getClanManager().getClanByPlayer(player);
    }

    /**
     * Check if a player is in any clan.
     *
     * @param uuid the UUID of the player
     * @return {@code true} if the player belongs to a clan
     */
    public boolean isInClan(@NotNull UUID uuid) {
        return plugin.getClanManager().isInClan(uuid);
    }

    /**
     * Get all registered clans.
     *
     * @return an unmodifiable collection of all clans
     */
    @NotNull
    public Collection<Clan> getAllClans() {
        return plugin.getClanManager().getAllClans();
    }

    /**
     * Get the total number of registered clans.
     *
     * @return the clan count
     */
    public int getClanCount() {
        return plugin.getClanManager().getAllClans().size();
    }

    /**
     * Get the online members of a clan.
     *
     * @param clan the clan to query
     * @return a list of currently online {@link Player} instances
     */
    @NotNull
    public List<Player> getOnlineMembers(@NotNull Clan clan) {
        return plugin.getClanManager().getOnlineMembers(clan);
    }

    // ══════════════════════════════════════════════════════════
    //  TERRITORY
    // ══════════════════════════════════════════════════════════

    /**
     * Get the clan ID owning a specific chunk.
     *
     * @param chunkKey the chunk key in {@code "world:x:z"} format
     * @return the owning clan's ID, or {@code null} if unclaimed
     */
    @Nullable
    public String getChunkOwner(@NotNull String chunkKey) {
        return plugin.getTerritoryManager().getOwner(chunkKey);
    }

    /**
     * Get the clan owning the chunk at a given location.
     *
     * @param location the world location to check
     * @return the owning {@link Clan}, or {@code null} if unclaimed
     */
    @Nullable
    public Clan getClanAt(@NotNull Location location) {
        String key = location.getWorld().getName() + ":" +
                (location.getBlockX() >> 4) + ":" + (location.getBlockZ() >> 4);
        String ownerId = plugin.getTerritoryManager().getOwner(key);
        return ownerId != null ? plugin.getClanManager().getClan(ownerId) : null;
    }

    /**
     * Get the number of chunks claimed by a clan.
     *
     * @param clanId the clan's unique ID
     * @return the number of claimed chunks
     */
    public int getClaimCount(@NotNull String clanId) {
        return plugin.getTerritoryManager().getClaimCount(clanId);
    }

    /**
     * Check if a chunk is claimed by any clan.
     *
     * @param chunkKey the chunk key in {@code "world:x:z"} format
     * @return {@code true} if the chunk is claimed
     */
    public boolean isClaimed(@NotNull String chunkKey) {
        return plugin.getTerritoryManager().getOwner(chunkKey) != null;
    }

    /**
     * Get all chunk keys claimed by a clan.
     *
     * @param clanId the clan's unique ID
     * @return an unmodifiable set of chunk keys in {@code "world:x:z"} format
     */
    @NotNull
    public Set<String> getClanClaims(@NotNull String clanId) {
        return plugin.getTerritoryManager().getClanClaims(clanId);
    }

    // ══════════════════════════════════════════════════════════
    //  POWER
    // ══════════════════════════════════════════════════════════

    /**
     * Get a player's individual power.
     *
     * @param uuid the UUID of the player
     * @return the player's current power value
     */
    public double getPlayerPower(@NotNull UUID uuid) {
        return plugin.getPowerManager().getPower(uuid);
    }

    /**
     * Get a clan's total combined power.
     *
     * @param clan the clan to query
     * @return the sum of all members' power
     */
    public double getClanPower(@NotNull Clan clan) {
        return plugin.getPowerManager().getClanPower(clan);
    }

    /**
     * Get a clan's maximum possible power.
     *
     * @param clan the clan to query
     * @return the maximum power the clan could reach if all members were at max power
     */
    public double getMaxClanPower(@NotNull Clan clan) {
        return plugin.getPowerManager().getMaxClanPower(clan);
    }

    /**
     * Get the maximum number of chunks a clan can claim based on its power.
     *
     * @param clan the clan to query
     * @return the maximum claimable chunks
     */
    public int getMaxClaims(@NotNull Clan clan) {
        return plugin.getPowerManager().getMaxClaims(clan);
    }

    // ══════════════════════════════════════════════════════════
    //  RELATIONS
    // ══════════════════════════════════════════════════════════

    /**
     * Check if two clans are allied.
     *
     * @param a the first clan
     * @param b the second clan
     * @return {@code true} if the clans have an active alliance
     */
    public boolean areAllied(@NotNull Clan a, @NotNull Clan b) {
        return plugin.getAllianceManager().areAllied(a, b);
    }

    /**
     * Get all allies of a clan.
     *
     * @param clan the clan to query
     * @return a list of allied {@link Clan} instances
     */
    @NotNull
    public List<Clan> getAllies(@NotNull Clan clan) {
        return plugin.getAllianceManager().getAllies(clan);
    }

    /**
     * Check if two clans are currently at war.
     *
     * @param a the first clan
     * @param b the second clan
     * @return {@code true} if the clans are at war with each other
     */
    public boolean areAtWar(@NotNull Clan a, @NotNull Clan b) {
        return plugin.getWarManager().isAtWar(a, b);
    }

    /**
     * Check if a clan is in any active war.
     *
     * @param clan the clan to check
     * @return {@code true} if the clan is participating in at least one war
     */
    public boolean isAtWar(@NotNull Clan clan) {
        return plugin.getWarManager().isAtWar(clan);
    }

    // ══════════════════════════════════════════════════════════
    //  ECONOMY
    // ══════════════════════════════════════════════════════════

    /**
     * Get a clan's bank balance.
     *
     * @param clanId the clan's unique ID
     * @return the bank balance, or {@code 0.0} if the bank module is not loaded
     */
    public double getBankBalance(@NotNull String clanId) {
        return plugin.getBankManager() != null ? plugin.getBankManager().getBalance(clanId) : 0.0;
    }

    /**
     * Set a clan's bank balance (admin/API use).
     *
     * @param clanId the clan's unique ID
     * @param amount the new balance to set
     */
    public void setBankBalance(@NotNull String clanId, double amount) {
        if (plugin.getBankManager() != null) plugin.getBankManager().setBalance(clanId, amount);
    }

    // ══════════════════════════════════════════════════════════
    //  WAR
    // ══════════════════════════════════════════════════════════

    /**
     * Get the number of active wars server-wide.
     *
     * @return the count of currently active wars
     */
    public int getActiveWarCount() {
        return plugin.getWarManager().getActiveWarCount();
    }

    // ══════════════════════════════════════════════════════════
    //  COMBAT INTEGRATION
    // ══════════════════════════════════════════════════════════

    /**
     * Check if a player is in combat. Requires EthernovaCombat to be installed.
     *
     * @param player the player to check
     * @return {@code true} if the player is combat-tagged, {@code false} if not or if EthernovaCombat is unavailable
     */
    public boolean isInCombat(@NotNull Player player) {
        return plugin.getCombatHook() != null && plugin.getCombatHook().isInCombat(player);
    }

    // ══════════════════════════════════════════════════════════
    //  LEVEL & UPGRADES
    // ══════════════════════════════════════════════════════════

    /**
     * Get a clan's current level.
     *
     * @param clan the clan to query
     * @return the clan's level
     */
    public int getClanLevel(@NotNull Clan clan) {
        return clan.getLevel();
    }

    /**
     * Get a clan's current XP.
     *
     * @param clanId the clan's unique ID
     * @return the clan's accumulated XP
     */
    public long getClanXP(@NotNull String clanId) {
        return plugin.getLevelManager().getXP(clanId);
    }

    // ══════════════════════════════════════════════════════════
    //  SHIELD
    // ══════════════════════════════════════════════════════════

    /**
     * Check if a clan has an active war shield.
     *
     * @param clanId the clan's unique ID
     * @return {@code true} if the clan has an active shield, {@code false} if not or if the shield module is unavailable
     */
    public boolean hasShield(@NotNull String clanId) {
        return plugin.getShieldManager() != null && plugin.getShieldManager().hasActiveShield(clanId);
    }

    // ══════════════════════════════════════════════════════════
    //  UTILITIES
    // ══════════════════════════════════════════════════════════

    /**
     * Get the plugin version string.
     *
     * @return the current EthernovaClans version
     */
    @NotNull
    public String getVersion() {
        return plugin.getDescription().getVersion();
    }

    /**
     * Build a chunk key from world name and chunk coordinates.
     *
     * @param world  the world name
     * @param chunkX the chunk X coordinate
     * @param chunkZ the chunk Z coordinate
     * @return a chunk key in {@code "world:x:z"} format
     */
    @NotNull
    public static String buildChunkKey(@NotNull String world, int chunkX, int chunkZ) {
        return world + ":" + chunkX + ":" + chunkZ;
    }
}
