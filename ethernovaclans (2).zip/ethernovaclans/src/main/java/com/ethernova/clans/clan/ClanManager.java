package com.ethernova.clans.clan;

import com.ethernova.clans.EthernovaClans;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.stream.Collectors;

public class ClanManager {

    private final EthernovaClans plugin;
    private final Map<String, Clan> clansById = new ConcurrentHashMap<>();
    private final Map<String, Clan> clansByName = new ConcurrentHashMap<>();
    private final Map<String, Clan> clansByTag = new ConcurrentHashMap<>();
    private final Map<UUID, String> playerClanMap = new ConcurrentHashMap<>();
    /** Lock for compound operations (register/delete) that modify multiple maps atomically. */
    private final ReentrantLock registryLock = new ReentrantLock();

    public ClanManager(EthernovaClans plugin) {
        this.plugin = plugin;
    }

    // ── CREATE ───────────────────────────────────────────────

    public Clan createClan(String name, String tag, Player leader) {
        // Generate unique ID — retry if collision (extremely unlikely but safe)
        String id;
        int attempts = 0;
        do {
            id = UUID.randomUUID().toString().substring(0, 8);
            if (++attempts > 100) {
                throw new IllegalStateException("Failed to generate unique clan ID after 100 attempts");
            }
        } while (clansById.containsKey(id));

        Clan clan = new Clan(id, name, tag, leader.getUniqueId(), leader.getName());
        clan.addMember(new ClanMember(leader.getUniqueId(), leader.getName(), ClanRole.LEADER));
        registerClan(clan);
        saveClan(clan);
        return clan;
    }

    /** Overload: createClan(player, name, tag) */
    public Clan createClan(Player leader, String name, String tag) {
        return createClan(name, tag, leader);
    }

    private void registerClan(Clan clan) {
        registryLock.lock();
        try {
            clansById.put(clan.getId(), clan);
            clansByName.put(clan.getName().toLowerCase(), clan);
            clansByTag.put(clan.getTag().toLowerCase(), clan);
            for (ClanMember member : clan.getMembers()) {
                playerClanMap.put(member.getUuid(), clan.getId());
            }
        } finally {
            registryLock.unlock();
        }
        // Wire up reverse bank sync so direct ClanBank operations propagate to ClanBankManager
        if (plugin.getBankManager() != null) {
            plugin.getBankManager().registerBankSync(clan);
        }
    }

    // ── DELETE ───────────────────────────────────────────────

    public void deleteClan(Clan clan) {
        registryLock.lock();
        try {
            clansById.remove(clan.getId());
            clansByName.remove(clan.getName().toLowerCase());
            clansByTag.remove(clan.getTag().toLowerCase());
            for (ClanMember member : clan.getMembers()) {
                playerClanMap.remove(member.getUuid());
            }
        } finally {
            registryLock.unlock();
        }
        // Cleanup across managers (outside lock to avoid deadlocks)
        try {
            plugin.getTerritoryManager().unclaimAll(clan.getId());
            if (plugin.getAllianceManager() != null) plugin.getAllianceManager().removeAllAlliances(clan.getId());
            if (plugin.getBankManager() != null) plugin.getBankManager().removeBalance(clan.getId());
            if (plugin.getLevelManager() != null) plugin.getLevelManager().removeXP(clan.getId());
            if (plugin.getShieldManager() != null) plugin.getShieldManager().removeShield(clan.getId());
            plugin.getStorageManager().deleteClan(clan.getId());
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "[Clans] Error during clan deletion cleanup: " + clan.getId(), e);
        }
    }

    /** Disband a clan with notification to initiator */
    public void disbandClan(Clan clan, Player initiator) {
        // Notify online members
        for (Player p : getOnlineMembers(clan)) {
            if (!p.getUniqueId().equals(initiator.getUniqueId())) {
                plugin.getMessageManager().sendMessage(p, "clan.disbanded-notify",
                        "{player}", initiator.getName(), "{clan}", clan.getName());
            }
        }
        deleteClan(clan);
        plugin.getMessageManager().sendMessage(initiator, "clan.disbanded");
    }

    // ── SAVE / LOAD ─────────────────────────────────────────

    public void saveClan(Clan clan) {
        plugin.getStorageManager().saveClan(clan);
    }

    public void loadAllClans() {
        List<Clan> loaded = plugin.getStorageManager().loadAllClans();
        for (Clan clan : loaded) {
            registerClan(clan);
        }
    }

    // ── QUERIES ──────────────────────────────────────────────

    public Clan getClan(String id) { return clansById.get(id); }
    public Clan getClanById(String id) { return clansById.get(id); }

    public Clan getClanByName(String name) {
        return clansByName.get(name.toLowerCase());
    }

    public Clan getClanByTag(String tag) {
        return clansByTag.get(tag.toLowerCase());
    }

    public Clan getClanByPlayer(UUID uuid) {
        String id = playerClanMap.get(uuid);
        return id != null ? clansById.get(id) : null;
    }

    /** Overload: getClanByPlayer(Player) */
    public Clan getClanByPlayer(Player player) {
        return getClanByPlayer(player.getUniqueId());
    }

    public Collection<Clan> getAllClans() {
        return Collections.unmodifiableCollection(clansById.values());
    }

    public List<Player> getOnlineMembers(Clan clan) {
        List<Player> online = new ArrayList<>();
        for (ClanMember member : clan.getMembers()) {
            Player player = Bukkit.getPlayer(member.getUuid());
            if (player != null && player.isOnline()) online.add(player);
        }
        return online;
    }

    // ── TERRITORY CLAIMS (delegates to TerritoryManager) ─────

    public static String buildChunkKey(String world, int chunkX, int chunkZ) {
        return world + ":" + chunkX + ":" + chunkZ;
    }

    public Clan getClaimOwner(String chunkKey) {
        String clanId = plugin.getTerritoryManager().getOwner(chunkKey);
        return clanId != null ? clansById.get(clanId) : null;
    }

    public void claimChunk(String chunkKey, String clanId) {
        plugin.getTerritoryManager().claim(chunkKey, clanId);
    }

    /** Overload: claimChunk(clan, player, chunkKey) with validation */
    public void claimChunk(Clan clan, Player player, String chunkKey) {
        if (plugin.getTerritoryManager().getOwner(chunkKey) != null) {
            plugin.getMessageManager().sendMessage(player, "territory.already-claimed");
            return;
        }
        // Spawn protection check
        int spawnRadius = org.bukkit.Bukkit.getServer().getSpawnRadius();
        if (spawnRadius > 0) {
            org.bukkit.Chunk chunk = player.getLocation().getChunk();
            org.bukkit.Location spawnLoc = chunk.getWorld().getSpawnLocation();
            int bx = chunk.getX() << 4, bz = chunk.getZ() << 4;
            int cx = Math.max(bx, Math.min(spawnLoc.getBlockX(), bx + 15));
            int cz = Math.max(bz, Math.min(spawnLoc.getBlockZ(), bz + 15));
            if (Math.max(Math.abs(cx - spawnLoc.getBlockX()), Math.abs(cz - spawnLoc.getBlockZ())) <= spawnRadius) {
                plugin.getMessageManager().sendMessage(player, "territory.protected-area");
                return;
            }
        }
        // WorldGuard protection check
        if (plugin.getWorldGuardHook() != null && plugin.getWorldGuardHook().isAvailable()) {
            if (!plugin.getWorldGuardHook().canClaimChunk(player.getLocation().getChunk())) {
                plugin.getMessageManager().sendMessage(player, "territory.worldguard-protected");
                return;
            }
        }
        plugin.getTerritoryManager().claim(chunkKey, clan.getId());
        clan.setClaimCount(plugin.getTerritoryManager().getClaimCount(clan.getId()));
        saveClan(clan);
        plugin.getMessageManager().sendMessage(player, "territory.claimed");
    }

    public void unclaimChunk(String chunkKey) {
        plugin.getTerritoryManager().unclaim(chunkKey);
    }

    /** Overload: unclaimChunk(clan, player, chunkKey) with validation */
    public void unclaimChunk(Clan clan, Player player, String chunkKey) {
        String owner = plugin.getTerritoryManager().getOwner(chunkKey);
        if (owner == null || !owner.equals(clan.getId())) {
            plugin.getMessageManager().sendMessage(player, "territory.not-yours");
            return;
        }
        plugin.getTerritoryManager().unclaim(chunkKey);
        clan.setClaimCount(plugin.getTerritoryManager().getClaimCount(clan.getId()));
        saveClan(clan);
        plugin.getMessageManager().sendMessage(player, "territory.unclaimed");
    }

    public void unclaimAllChunks(String clanId) {
        plugin.getTerritoryManager().unclaimAll(clanId);
    }

    /** Overload: unclaimAllChunks(clan) returns count */
    public int unclaimAllChunks(Clan clan) {
        int count = plugin.getTerritoryManager().getClaimCount(clan.getId());
        plugin.getTerritoryManager().unclaimAll(clan.getId());
        clan.setClaimCount(0);
        saveClan(clan);
        return count;
    }

    public int getClaimCount(String clanId) {
        return plugin.getTerritoryManager().getClaimCount(clanId);
    }

    /**
     * Get all claimed chunk keys for a specific clan.
     */
    public java.util.Set<String> getClanClaims(String clanId) {
        return plugin.getTerritoryManager().getClanClaims(clanId);
    }

    // ── MEMBER MANAGEMENT ───────────────────────────────────

    public void updatePlayerClanMapping(UUID uuid, String clanId) {
        if (clanId == null) {
            playerClanMap.remove(uuid);
        } else {
            playerClanMap.put(uuid, clanId);
        }
    }

    public void invitePlayer(Player inviter, Clan clan, Player target) {
        if (target == null) return;
        if (getClanByPlayer(target) != null) {
            plugin.getMessageManager().sendMessage(inviter, "invite.already-in-clan",
                    "{player}", target.getName());
            return;
        }
        plugin.getInvitationManager().invite(target.getUniqueId(), clan.getId());
    }

    public void promoteMember(Clan clan, ClanMember member) {
        ClanRole next = member.getRole().next();
        if (next != null && next != ClanRole.LEADER) {
            member.setRole(next);
            saveClan(clan);
        }
    }

    /** Overload: promoteMember(clan, memberUUID, promoter) */
    public void promoteMember(Clan clan, UUID memberUuid, Player promoter) {
        ClanMember member = clan.getMember(memberUuid);
        if (member != null) promoteMember(clan, member);
    }

    public void demoteMember(Clan clan, ClanMember member) {
        ClanRole prev = member.getRole().previous();
        if (prev != null) {
            member.setRole(prev);
            saveClan(clan);
        }
    }

    /** Overload: demoteMember(clan, memberUUID, demoter) */
    public void demoteMember(Clan clan, UUID memberUuid, Player demoter) {
        ClanMember member = clan.getMember(memberUuid);
        if (member != null) demoteMember(clan, member);
    }

    public void removeMember(Clan clan, ClanMember member) {
        clan.removeMember(member.getUuid());
        playerClanMap.remove(member.getUuid());
        saveClan(clan);
        if (plugin.getDiscordWebhook() != null) plugin.getDiscordWebhook().sendMemberLeave(member.getName(), clan);
    }

    /** Overload: removeMember(clan, uuid, wasKicked) */
    public void removeMember(Clan clan, UUID uuid, boolean kicked) {
        ClanMember member = clan.getMember(uuid);
        if (member != null) removeMember(clan, member);
    }

    public void changeTag(Clan clan, String newTag) {
        registryLock.lock();
        try {
            clansByTag.remove(clan.getTag().toLowerCase());
            clan.setTag(newTag);
            clansByTag.put(newTag.toLowerCase(), clan);
        } finally {
            registryLock.unlock();
        }
        saveClan(clan);
    }

    /** Overload: changeTag(clan, tag, player) */
    public void changeTag(Clan clan, String newTag, Player player) {
        changeTag(clan, newTag);
    }

    public void changeName(Clan clan, String newName, Player player) {
        registryLock.lock();
        try {
            clansByName.remove(clan.getName().toLowerCase());
            clan.setName(newName);
            clansByName.put(newName.toLowerCase(), clan);
        } finally {
            registryLock.unlock();
        }
        saveClan(clan);
    }

    public void setHeadquarters(Clan clan, org.bukkit.Location loc) {
        clan.setHome(loc);
        saveClan(clan);
    }

    /** Overload: setHeadquarters(clan, player, chunkKey) */
    public void setHeadquarters(Clan clan, Player player, String chunkKey) {
        clan.setHome(player.getLocation());
        saveClan(clan);
        plugin.getMessageManager().sendMessage(player, "home.set",
                "{x}", String.valueOf(player.getLocation().getBlockX()),
                "{y}", String.valueOf(player.getLocation().getBlockY()),
                "{z}", String.valueOf(player.getLocation().getBlockZ()));
    }

    /** Get top clans by a metric. */
    public List<Clan> getTopClans(String metric, int limit) {
        Comparator<Clan> cmp = switch (metric.toLowerCase()) {
            case "kills" -> Comparator.comparingInt(Clan::getTotalKills).reversed();
            case "power" -> Comparator.comparingDouble(Clan::getPower).reversed();
            case "level" -> Comparator.comparingInt(Clan::getLevel).reversed();
            case "members" -> Comparator.<Clan, Integer>comparing(c -> c.getMembers().size()).reversed();
            default -> Comparator.comparingInt(Clan::getTotalKills).reversed();
        };
        return clansById.values().stream()
                .sorted(cmp)
                .limit(limit)
                .collect(Collectors.toList());
    }

    /** Check if a player has permission for a clan action. */
    public boolean hasPermission(Player player, Clan clan, String action) {
        return hasPermission(clan, player.getUniqueId(), action);
    }

    /** Overload: hasPermission(clan, uuid, action) */
    public boolean hasPermission(Clan clan, UUID uuid, String action) {
        ClanMember member = clan.getMember(uuid);
        if (member == null) return false;
        return switch (action) {
            case "invite", "kick" -> member.getRole().ordinal() >= ClanRole.OFFICER.ordinal();
            case "promote", "demote", "settings", "tag", "change-tag" -> member.getRole().ordinal() >= ClanRole.CO_LEADER.ordinal();
            case "disband" -> member.getRole() == ClanRole.LEADER;
            case "bank", "claim", "sethome", "sethq", "bank-withdraw" -> member.getRole().ordinal() >= ClanRole.MEMBER.ordinal();
            case "ally", "rival", "war" -> member.getRole().ordinal() >= ClanRole.CO_LEADER.ordinal();
            default -> true;
        };
    }

    /** Allow a player to join a clan (public/invitation-based). */
    public void joinClan(Player player, Clan clan) {
        if (getClanByPlayer(player) != null) {
            plugin.getMessageManager().sendMessage(player, "clan.already-in-clan");
            return;
        }
        ClanMember member = new ClanMember(player.getUniqueId(), player.getName(), ClanRole.RECRUIT);
        clan.addMember(member);
        playerClanMap.put(player.getUniqueId(), clan.getId());
        saveClan(clan);
        plugin.getMessageManager().sendMessage(player, "clan.joined", "{clan}", clan.getName());
        if (plugin.getDiscordWebhook() != null) plugin.getDiscordWebhook().sendMemberJoin(player.getName(), clan);
    }

    // ── Admin/Utility Methods ────────────────────────────────

    public boolean clanNameExists(String name) {
        return clansByName.containsKey(name.toLowerCase());
    }

    public void updateNameIndex(String oldName, String newName, String clanId) {
        clansByName.remove(oldName.toLowerCase());
        Clan clan = clansById.get(clanId);
        if (clan != null) clansByName.put(newName.toLowerCase(), clan);
    }

    public void updateTagIndex(String oldTag, String newTag, String clanId) {
        clansByTag.remove(oldTag.toLowerCase());
        Clan clan = clansById.get(clanId);
        if (clan != null) clansByTag.put(newTag.toLowerCase(), clan);
    }

    public void transferLeadership(Clan clan, UUID oldLeader, UUID newLeader) {
        ClanMember oldMember = clan.getMember(oldLeader);
        ClanMember newMember = clan.getMember(newLeader);
        if (oldMember != null) oldMember.setRole(ClanRole.CO_LEADER);
        if (newMember != null) newMember.setRole(ClanRole.LEADER);
        clan.setLeaderUuid(newLeader);
        if (newMember != null) clan.setLeaderName(newMember.getName());
        saveClan(clan);
    }

    public boolean isInClan(UUID uuid) {
        return playerClanMap.containsKey(uuid);
    }

    public void addMember(Clan clan, Player player) {
        ClanMember member = new ClanMember(player.getUniqueId(), player.getName(), ClanRole.RECRUIT);
        clan.addMember(member);
        playerClanMap.put(player.getUniqueId(), clan.getId());
        saveClan(clan);
    }

    public void adminDisband(Clan clan) {
        deleteClan(clan);
    }
}
