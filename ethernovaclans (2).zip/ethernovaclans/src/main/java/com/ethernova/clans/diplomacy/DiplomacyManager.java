package com.ethernova.clans.diplomacy;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.sql.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Advanced diplomacy system with treaties, embargoes, and non-aggression pacts.
 * Treaties have a duration and provide mutual benefits.
 */
public class DiplomacyManager {

    private final EthernovaClans plugin;

    /** Active treaties: key = canonical pair "clanA:clanB" */
    private final Map<String, Treaty> treaties = new ConcurrentHashMap<>();

    public enum TreatyType {
        NON_AGGRESSION("Pacto de No Agresión",  "🕊️", 72,  "Impide declarar guerras entre clanes"),
        TRADE_AGREEMENT("Acuerdo Comercial",     "💰", 48,  "Comparte 5% de ingresos del banco"),
        MUTUAL_DEFENSE("Defensa Mutua",          "🛡️", 96,  "Los aliados reciben notificaciones de ataque"),
        EMBARGO("Embargo Comercial",             "🚫", 24,  "Bloquea comercio e interacción entre clanes");

        public final String displayName;
        public final String icon;
        public final int defaultDurationHours;
        public final String description;

        TreatyType(String displayName, String icon, int defaultDurationHours, String description) {
            this.displayName = displayName;
            this.icon = icon;
            this.defaultDurationHours = defaultDurationHours;
            this.description = description;
        }
    }

    public record Treaty(String clanIdA, String clanIdB, TreatyType type,
                         long startTime, long endTime, String proposedBy) {
        public boolean isActive() { return System.currentTimeMillis() < endTime; }
        public long getRemainingMs() { return Math.max(0, endTime - System.currentTimeMillis()); }
        public String getRemainingFormatted() {
            long ms = getRemainingMs();
            long hours = ms / 3600000;
            long mins = (ms % 3600000) / 60000;
            return hours + "h " + mins + "m";
        }
        public String getKey() { return canonicalKey(clanIdA, clanIdB); }
    }

    /** Pending treaty proposals: key = "targetClanId:proposerClanId" */
    private final Map<String, Treaty> pendingProposals = new ConcurrentHashMap<>();
    private BukkitTask expirationTask;

    public DiplomacyManager(EthernovaClans plugin) {
        this.plugin = plugin;

        // Tick every minute to expire treaties
        expirationTask = Bukkit.getScheduler().runTaskTimer(plugin, this::expireTreaties, 20L * 60, 20L * 60);
    }

    // ── Query ────────────────────────────────────────────────

    public List<Treaty> getTreaties(String clanId) {
        return treaties.values().stream()
                .filter(t -> (t.clanIdA().equals(clanId) || t.clanIdB().equals(clanId)) && t.isActive())
                .toList();
    }

    public Treaty getTreaty(String clanIdA, String clanIdB, TreatyType type) {
        String key = canonicalKey(clanIdA, clanIdB);
        Treaty t = treaties.get(key + ":" + type.name());
        return (t != null && t.isActive()) ? t : null;
    }

    public boolean hasTreaty(String clanIdA, String clanIdB, TreatyType type) {
        return getTreaty(clanIdA, clanIdB, type) != null;
    }

    public boolean hasAnyTreaty(String clanIdA, String clanIdB) {
        String key = canonicalKey(clanIdA, clanIdB);
        return treaties.values().stream()
                .anyMatch(t -> t.getKey().equals(key) && t.isActive());
    }

    public boolean isEmbargoed(String clanIdA, String clanIdB) {
        return hasTreaty(clanIdA, clanIdB, TreatyType.EMBARGO);
    }

    // ── Propose / Accept / Cancel ────────────────────────────

    /**
     * Propose a treaty to another clan.
     */
    public String proposeTreaty(Clan proposer, Clan target, TreatyType type) {
        if (proposer.getId().equals(target.getId())) return "No puedes hacer un tratado contigo mismo.";

        if (hasTreaty(proposer.getId(), target.getId(), type)) {
            return "Ya existe un tratado activo de ese tipo.";
        }

        String proposalKey = target.getId() + ":" + proposer.getId() + ":" + type.name();
        if (pendingProposals.containsKey(proposalKey)) {
            return "Ya existe una propuesta pendiente de este tipo.";
        }

        long duration = type.defaultDurationHours * 3600000L;
        Treaty treaty = new Treaty(proposer.getId(), target.getId(), type,
                System.currentTimeMillis(), System.currentTimeMillis() + duration, proposer.getLeaderName());

        pendingProposals.put(proposalKey, treaty);

        // Notify target clan
        for (var member : target.getOnlineMembers()) {
            Player p = Bukkit.getPlayer(member.getUuid());
            if (p != null) {
                p.sendMessage(plugin.getConfigManager().getMessage("diplomacy.proposal-notification",
                        "icon", type.icon, "clan", proposer.getName(), "type", type.displayName));
            }
        }

        return null; // success
    }

    /**
     * Accept a pending treaty proposal.
     */
    public String acceptTreaty(Clan acceptor, Clan proposer, TreatyType type) {
        String proposalKey = acceptor.getId() + ":" + proposer.getId() + ":" + type.name();
        Treaty treaty = pendingProposals.remove(proposalKey);
        if (treaty == null) return "No hay propuesta pendiente de ese tipo.";

        // Refresh timestamps
        long duration = type.defaultDurationHours * 3600000L;
        Treaty active = new Treaty(treaty.clanIdA(), treaty.clanIdB(), type,
                System.currentTimeMillis(), System.currentTimeMillis() + duration, treaty.proposedBy());

        String key = canonicalKey(active.clanIdA(), active.clanIdB()) + ":" + type.name();
        treaties.put(key, active);
        saveAsync();

        // Notify both clans
        notifyClan(acceptor, "<green>✔ Tratado aceptado: " + type.icon + " " + type.displayName + " con " + proposer.getName());
        notifyClan(proposer, "<green>✔ " + acceptor.getName() + " aceptó: " + type.icon + " " + type.displayName);

        if (plugin.getDiscordWebhook() != null) {
            plugin.getDiscordWebhook().sendTreatyFormed(acceptor.getName(), proposer.getName(), type.displayName);
        }

        return null;
    }

    /**
     * Reject a pending proposal.
     */
    public String rejectTreaty(Clan rejector, Clan proposer, TreatyType type) {
        String proposalKey = rejector.getId() + ":" + proposer.getId() + ":" + type.name();
        Treaty treaty = pendingProposals.remove(proposalKey);
        if (treaty == null) return "No hay propuesta pendiente.";

        notifyClan(proposer, "<red>✘ " + rejector.getName() + " rechazó: " + type.icon + " " + type.displayName);
        return null;
    }

    /**
     * Break an active treaty (with cooldown penalty).
     */
    public String breakTreaty(Clan breaker, String otherClanId, TreatyType type) {
        String key = canonicalKey(breaker.getId(), otherClanId) + ":" + type.name();
        Treaty treaty = treaties.remove(key);
        if (treaty == null) return "No hay tratado activo de ese tipo.";

        Clan other = plugin.getClanManager().getClanById(otherClanId);
        breaker.setCooldown("treaty_" + type.name(), 3600000); // 1 hour cooldown
        notifyClan(breaker, "<red>✘ Has roto el tratado: " + type.icon + " " + type.displayName);
        if (other != null) {
            notifyClan(other, "<red>⚠ " + breaker.getName() + " ha roto el tratado: " + type.icon + " " + type.displayName);
        }

        if (plugin.getDiscordWebhook() != null) {
            String otherName = other != null ? other.getName() : otherClanId;
            plugin.getDiscordWebhook().sendTreatyBroken(breaker.getName(), otherName, type.displayName);
        }

        saveAsync();
        return null;
    }

    public List<Treaty> getPendingProposals(String clanId) {
        return pendingProposals.values().stream()
                .filter(t -> t.clanIdB().equals(clanId)) // target is clanIdB
                .toList();
    }

    // ── Expiration ───────────────────────────────────────────

    private void expireTreaties() {
        treaties.entrySet().removeIf(e -> !e.getValue().isActive());
    }

    // ── Persistence ──────────────────────────────────────────

    public void loadAll() {
        try (Connection conn = plugin.getStorageManager().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM clan_treaties")) {
            while (rs.next()) {
                Treaty t = new Treaty(
                        rs.getString("clan_id_a"),
                        rs.getString("clan_id_b"),
                        TreatyType.valueOf(rs.getString("treaty_type")),
                        rs.getLong("start_time"),
                        rs.getLong("end_time"),
                        rs.getString("proposed_by")
                );
                if (t.isActive()) {
                    String key = canonicalKey(t.clanIdA(), t.clanIdB()) + ":" + t.type().name();
                    treaties.put(key, t);
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().log(java.util.logging.Level.WARNING, "Failed to load treaties", e);
        }
        plugin.getLogger().info("  ○ Treaties loaded (" + treaties.size() + " active)");
    }

    private void saveAsync() {
        List<Treaty> snapshot = new ArrayList<>(treaties.values());
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            try (Connection conn = plugin.getStorageManager().getConnection()) {
                conn.setAutoCommit(false);
                try {
                    try (Statement s = conn.createStatement()) {
                        s.executeUpdate("DELETE FROM clan_treaties");
                    }
                    if (!snapshot.isEmpty()) {
                        try (PreparedStatement ps = conn.prepareStatement(
                                "INSERT INTO clan_treaties (clan_id_a, clan_id_b, treaty_type, start_time, end_time, proposed_by) VALUES (?, ?, ?, ?, ?, ?)")) {
                            for (Treaty t : snapshot) {
                                String keyA = canonicalKey(t.clanIdA(), t.clanIdB()).equals(t.clanIdA() + ":" + t.clanIdB()) ? t.clanIdA() : t.clanIdB();
                                String keyB = keyA.equals(t.clanIdA()) ? t.clanIdB() : t.clanIdA();
                                ps.setString(1, keyA);
                                ps.setString(2, keyB);
                                ps.setString(3, t.type().name());
                                ps.setLong(4, t.startTime());
                                ps.setLong(5, t.endTime());
                                ps.setString(6, t.proposedBy());
                                ps.addBatch();
                            }
                            ps.executeBatch();
                        }
                    }
                    conn.commit();
                } catch (SQLException inner) {
                    try { conn.rollback(); } catch (SQLException ignored) {}
                    plugin.getLogger().log(java.util.logging.Level.WARNING, "Failed to save treaties", inner);
                } finally {
                    try { conn.setAutoCommit(true); } catch (SQLException ignored) {}
                }
            } catch (SQLException e) {
                plugin.getLogger().log(java.util.logging.Level.WARNING, "Failed to get DB connection for treaty save", e);
            }
        });
    }

    // ── Utility ──────────────────────────────────────────────

    static String canonicalKey(String a, String b) {
        return a.compareTo(b) <= 0 ? a + ":" + b : b + ":" + a;
    }

    private void notifyClan(Clan clan, String message) {
        for (var member : clan.getOnlineMembers()) {
            Player p = Bukkit.getPlayer(member.getUuid());
            if (p != null) p.sendMessage(com.ethernova.clans.util.TextUtil.parse(message));
        }
    }

    public void shutdown() {
        if (expirationTask != null) expirationTask.cancel();
        saveSync();
    }

    private void saveSync() {
        List<Treaty> snapshot = new ArrayList<>(treaties.values());
        try (Connection conn = plugin.getStorageManager().getConnection()) {
            conn.setAutoCommit(false);
            try {
                try (Statement s = conn.createStatement()) {
                    s.executeUpdate("DELETE FROM clan_treaties");
                }
                if (!snapshot.isEmpty()) {
                    try (PreparedStatement ps = conn.prepareStatement(
                            "INSERT INTO clan_treaties (clan_id_a, clan_id_b, treaty_type, start_time, end_time, proposed_by) VALUES (?, ?, ?, ?, ?, ?)")) {
                        for (Treaty t : snapshot) {
                            String keyA = canonicalKey(t.clanIdA(), t.clanIdB()).equals(t.clanIdA() + ":" + t.clanIdB()) ? t.clanIdA() : t.clanIdB();
                            String keyB = keyA.equals(t.clanIdA()) ? t.clanIdB() : t.clanIdA();
                            ps.setString(1, keyA);
                            ps.setString(2, keyB);
                            ps.setString(3, t.type().name());
                            ps.setLong(4, t.startTime());
                            ps.setLong(5, t.endTime());
                            ps.setString(6, t.proposedBy());
                            ps.addBatch();
                        }
                        ps.executeBatch();
                    }
                }
                conn.commit();
            } catch (SQLException inner) {
                try { conn.rollback(); } catch (SQLException ignored) {}
                plugin.getLogger().log(java.util.logging.Level.WARNING, "Failed to save treaties on shutdown", inner);
            } finally {
                try { conn.setAutoCommit(true); } catch (SQLException ignored) {}
            }
        } catch (SQLException e) {
            plugin.getLogger().log(java.util.logging.Level.WARNING, "Failed to get DB connection for treaty sync save", e);
        }
    }
}
