package com.ethernova.clans.event;

import com.ethernova.clans.clan.Clan;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Fired when a war ends between two clans.
 */
public class ClanWarEndEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();

    private final Clan winner;
    private final Clan loser;
    private final String warType;
    private final EndReason endReason;

    public ClanWarEndEvent(@Nullable Clan winner, @Nullable Clan loser, String warType, EndReason endReason) {
        this.winner = winner;
        this.loser = loser;
        this.warType = warType;
        this.endReason = endReason;
    }

    @Nullable public Clan getWinner() { return winner; }
    @Nullable public Clan getLoser() { return loser; }
    public String getWarType() { return warType; }
    public EndReason getEndReason() { return endReason; }

    @Override public @NotNull HandlerList getHandlers() { return HANDLERS; }
    public static HandlerList getHandlerList() { return HANDLERS; }

    public enum EndReason {
        VICTORY,
        SURRENDER,
        TIMEOUT,
        ADMIN,
        DISBAND
    }
}
