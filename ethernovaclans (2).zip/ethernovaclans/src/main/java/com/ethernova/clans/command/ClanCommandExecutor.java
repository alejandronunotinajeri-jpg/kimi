package com.ethernova.clans.command;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanManager;
import com.ethernova.clans.clan.ClanMember;
import com.ethernova.clans.clan.ClanRole;
import com.ethernova.clans.diplomacy.DiplomacyManager;
import com.ethernova.clans.mission.MissionManager;
import com.ethernova.clans.nation.Nation;
import com.ethernova.clans.nation.NationManager;
import com.ethernova.clans.outpost.Outpost;
import com.ethernova.clans.outpost.OutpostManager;
import com.ethernova.clans.outpost.OutpostType;
import com.ethernova.clans.salary.SalaryManager;
import com.ethernova.clans.skill.ClanSkillManager;
import com.ethernova.clans.spy.SpyManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.stream.Collectors;

public class ClanCommandExecutor implements CommandExecutor, TabCompleter {

    private final EthernovaClans plugin;
    private final Map<UUID, Long> createCooldown = new java.util.concurrent.ConcurrentHashMap<>();
    private static final long CREATE_COOLDOWN_MS = 60_000; // 1 minute

    public ClanCommandExecutor(EthernovaClans plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.getMessageManager().sendMessage(sender, "general.player-only");
            return true;
        }

        if (args.length == 0) {
            Clan clan = plugin.getClanManager().getClanByPlayer(player.getUniqueId());
            if (clan != null) {
                plugin.getGuiManager().openMainMenu(player);
            } else {
                // Show a compact guide instead of a wall of help text
                var mm = plugin.getMessageManager();
                mm.sendRaw(player, "<dark_gray><strikethrough>         </strikethrough></dark_gray> <gradient:#A855F7:#6366F1>☠ Clanes</gradient> <dark_gray><strikethrough>         </strikethrough></dark_gray>");
                mm.sendRaw(player, " ");
                mm.sendRaw(player, "<gray>No perteneces a ningún clan.</gray>");
                mm.sendRaw(player, " ");
                mm.sendRaw(player, "<click:suggest_command:/clan crear ><hover:show_text:'<gray>Click para crear tu clan'><green>▸ Crear un clan:</green> <yellow>/clan crear <nombre></yellow></hover></click>");
                mm.sendRaw(player, "<click:suggest_command:/clan unir ><hover:show_text:'<gray>Click para unirte'><aqua>▸ Unirte a uno:</aqua> <yellow>/clan unir <nombre></yellow></hover></click>");
                mm.sendRaw(player, "<click:run_command:/clan list><hover:show_text:'<gray>Click para ver clanes'><light_purple>▸ Ver clanes:</light_purple> <yellow>/clan list</yellow></hover></click>");
                mm.sendRaw(player, " ");
                mm.sendRaw(player, "<dark_gray><strikethrough>                              </strikethrough></dark_gray>");
            }
            return true;
        }

        String sub = args[0].toLowerCase();

        // Block survival-only commands on practice servers
        if (!plugin.getClanModeManager().isCommandAllowed(sub)) {
            plugin.getMessageManager().sendRaw(player,
                    "<red>\u2716</red> <gray>Este comando no est\u00e1 disponible en este servidor.</gray>");
            return true;
        }

        switch (sub) {
            case "create", "crear" -> handleCreate(player, args);
            case "disband", "disolver" -> handleDisband(player);
            case "invite", "invitar" -> handleInvite(player, args);
            case "join", "unir", "accept", "aceptar" -> handleJoin(player, args);
            case "deny", "rechazar" -> handleDenyInvite(player);
            case "leave", "salir" -> handleLeave(player);
            case "kick", "expulsar" -> handleKick(player, args);
            case "promote", "ascender" -> handlePromote(player, args);
            case "demote", "degradar" -> handleDemote(player, args);
            case "info" -> handleInfo(player, args);
            case "list", "lista" -> handleList(player, args);
            case "chat", "c" -> handleChat(player);
            case "allychat", "ac" -> handleAllyChat(player);
            case "officerchat", "oc" -> handleOfficerChat(player);
            case "ally", "aliado" -> handleAlly(player, args);
            case "enemy", "enemigo" -> handleEnemy(player, args);
            case "claim", "reclamar" -> handleClaim(player);
            case "unclaim", "abandonar" -> handleUnclaim(player);
            case "autoclaim" -> handleAutoClaim(player);
            case "map", "mapa" -> handleMap(player);
            case "home", "base" -> handleHome(player);
            case "sethome", "setbase" -> handleSetHome(player);
            case "warp" -> handleWarp(player, args);
            case "setwarp" -> handleSetWarp(player, args);
            case "delwarp" -> handleDelWarp(player, args);
            case "warps" -> handleWarps(player);
            // scoreboard removed — use external scoreboard plugin with placeholders
            case "war", "guerra" -> handleWar(player, args);
            case "upgrade", "mejorar" -> handleUpgrade(player, args);
            case "top", "ranking" -> handleTop(player, args);
            case "transfer", "transferir" -> handleTransfer(player, args);
            case "desc", "descripcion" -> handleDesc(player, args);
            case "ban", "banear" -> handleBan(player, args);
            case "unban", "desbanear" -> handleUnban(player, args);
            case "menu", "gui" -> plugin.getGuiManager().openMainMenu(player);
            case "help", "ayuda" -> showHelp(player);
            case "bank", "banco" -> handleBank(player, args);
            case "level", "nivel" -> handleLevel(player);
            case "confirm", "confirmar" -> plugin.getConfirmationManager().confirm(player);
            case "log", "registro" -> handleLog(player);
            case "flags", "permisos" -> handleFlags(player, args);
            case "nation", "nacion" -> handleNation(player, args);
            case "outpost", "puesto" -> handleOutpost(player, args);
            case "spy", "espiar" -> handleSpy(player, args);
            case "diplomacy", "diplomacia" -> handleDiplomacy(player, args);
            case "salary", "salario" -> handleSalary(player, args);
            case "skills", "habilidades" -> handleSkills(player);
            case "shop", "tienda" -> handleShop(player);
            case "stats", "estadisticas" -> handleStats(player, args);
            case "banner", "estandarte" -> handleBanner(player, args);
            case "season", "temporada" -> handleSeason(player);
            case "siege", "asedio" -> handleSiege(player, args);
            case "settings", "ajustes" -> handleSettings(player);
            case "borders", "bordes" -> handleBorders(player);
            case "missions", "misiones" -> handleMissions(player);
            case "achievements", "logros" -> handleAchievements(player);
            default -> showHelp(player);
        }
        return true;
    }

    // ══════════════════════════════════════════════════════════
    //  SUBCOMMANDS
    // ══════════════════════════════════════════════════════════

    private void handleCreate(Player player, String[] args) {
        if (!player.hasPermission("ethernova.clans.create")) {
            plugin.getMessageManager().sendMessage(player, "general.no-permission"); return;
        }
        if (plugin.getClanManager().getClanByPlayer(player.getUniqueId()) != null) {
            plugin.getMessageManager().sendMessage(player, "clan.already-in-clan"); return;
        }
        if (args.length < 2) {
            plugin.getMessageManager().sendMessage(player, "clan.create-usage"); return;
        }

        // Cooldown
        long now = System.currentTimeMillis();
        Long lastCreate = createCooldown.get(player.getUniqueId());
        if (lastCreate != null && now - lastCreate < CREATE_COOLDOWN_MS) {
            long remaining = (CREATE_COOLDOWN_MS - (now - lastCreate)) / 1000;
            plugin.getMessageManager().sendMessage(player, "clan.create-cooldown", "{time}", String.valueOf(remaining));
            return;
        }

        String name = args[1];
        String tag = args.length >= 3 ? args[2] : name.substring(0, Math.min(4, name.length())).toUpperCase();

        // Validate name
        int minLen = plugin.getConfigManager().getConfig().getInt("clans.name-min-length", 3);
        int maxLen = plugin.getConfigManager().getConfig().getInt("clans.name-max-length", 16);
        if (name.length() < minLen || name.length() > maxLen) {
            plugin.getMessageManager().sendMessage(player, "clan.invalid-name"); return;
        }
        // Validate name — alphanumeric, spaces, underscores only (no MiniMessage injection)
        if (!name.matches("[a-zA-Z0-9_ ]{" + minLen + "," + maxLen + "}")) {
            plugin.getMessageManager().sendMessage(player, "clan.invalid-name"); return;
        }
        // Validate tag — alphanumeric only, 2-5 characters, no MiniMessage injection
        if (!tag.matches("[a-zA-Z0-9]{2,5}")) {
            plugin.getMessageManager().sendMessage(player, "clan.tag-invalid");
            return;
        }
        if (plugin.getClanManager().getClanByName(name) != null) {
            plugin.getMessageManager().sendMessage(player, "clan.name-taken"); return;
        }
        if (plugin.getClanManager().getClanByTag(tag) != null) {
            plugin.getMessageManager().sendMessage(player, "clan.tag-taken"); return;
        }

        // Economy check
        double cost = plugin.getConfigManager().getConfig().getDouble("clans.create-cost", 5000.0);
        if (cost > 0 && plugin.getEconomyManager().isEnabled()) {
            if (!plugin.getEconomyManager().has(player, cost)) {
                plugin.getMessageManager().sendMessage(player, "clan.not-enough-money",
                        "{cost}", plugin.getEconomyManager().format(cost)); return;
            }
            plugin.getEconomyManager().withdraw(player, cost);
        }

        // Create
        Clan clan = plugin.getClanManager().createClan(name, tag, player);
        createCooldown.put(player.getUniqueId(), System.currentTimeMillis());
        plugin.getMessageManager().sendMessage(player, "clan.created", "{clan}", name);
        plugin.getAuditLogger().log(clan.getId(), player.getUniqueId(), player.getName(),
                com.ethernova.clans.audit.AuditAction.CLAN_CREATED, "tag=" + tag);

        // Broadcast
        String broadcastMsg = plugin.getMessageManager().get("clan.created-broadcast",
                "{player}", player.getName(), "{clan}", name);
        Bukkit.broadcast(plugin.getMessageManager().parse(broadcastMsg));

        // Discord
        if (plugin.getDiscordWebhook() != null) {
            plugin.getDiscordWebhook().sendClanCreated(clan);
        }
    }

    private void handleDisband(Player player) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.LEADER)) return;

        if (plugin.getWarManager().isAtWar(clan)) {
            plugin.getMessageManager().sendMessage(player, "clan.cannot-disband-at-war"); return;
        }
        if (plugin.getCombatHook().isInCombat(player)) {
            plugin.getMessageManager().sendMessage(player, "clan.cannot-disband-in-combat"); return;
        }

        // Require confirmation
        String clanName = clan.getName();
        plugin.getConfirmationManager().requestConfirmation(player, "disband",
                "<red><bold>⚠ ¿Estás seguro de disolver " + clanName + "?</bold></red>\n" +
                "<gray>Se perderán todos los territorios, alianzas, banco y mejoras.</gray>",
                () -> {
                    // Hologram and flag cleanup (not handled by deleteClan)
                    plugin.getHologramManager().removeHologram(clan.getId());
                    plugin.getTerritoryFlagManager().removeFlags(clan.getId());
                    plugin.getAuditLogger().log(clan.getId(), player.getUniqueId(), player.getName(),
                            com.ethernova.clans.audit.AuditAction.CLAN_DISBANDED, null);
                    // deleteClan handles: alliances, territories, bank, XP, shields, DB
                    plugin.getClanManager().deleteClan(clan);
                    plugin.getMessageManager().sendMessage(player, "clan.disbanded", "{clan}", clanName);
                    if (plugin.getDiscordWebhook() != null) plugin.getDiscordWebhook().sendClanDisbanded(clan);
                });
    }

    private void handleInvite(Player player, String[] args) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.OFFICER)) return;

        // No args → open invite GUI showing online clanless players
        if (args.length < 2) {
            plugin.getGuiManager().openInvitePlayers(player);
            return;
        }

        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            plugin.getMessageManager().sendMessage(player, "general.player-not-found"); return;
        }
        if (plugin.getClanManager().getClanByPlayer(target.getUniqueId()) != null) {
            plugin.getMessageManager().sendMessage(player, "clan.target-in-clan"); return;
        }

        // Check member limit
        int maxMembers = plugin.getConfigManager().getConfig().getInt("clans.max-members", 20)
                + plugin.getUpgradeManager().getMemberSlotBonus(clan)
                + plugin.getLevelManager().getMaxMembersBonus(clan.getId());
        if (clan.getMembers().size() >= maxMembers) {
            plugin.getMessageManager().sendMessage(player, "clan.max-members"); return;
        }

        plugin.getInvitationManager().invite(target.getUniqueId(), clan.getId());
        plugin.getMessageManager().sendMessage(player, "clan.invite-sent", "{player}", target.getName());

        // Send clickable accept/deny to target
        MiniMessage mm = MiniMessage.miniMessage();
        Component header = mm.deserialize(
                "<gold>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━</gold>");
        Component inviteMsg = mm.deserialize(
                "<yellow>📩 <white>" + player.getName() + "</white> te ha invitado al clan <gold>" +
                        clan.getDisplayName() + "</gold>!</yellow>");

        Component acceptBtn = mm.deserialize("<green><bold>[✔ ACEPTAR]</bold></green>")
                .clickEvent(ClickEvent.runCommand("/clan join " + clan.getName()))
                .hoverEvent(HoverEvent.showText(mm.deserialize("<green>Click para aceptar la invitación</green>")));

        Component denyBtn = mm.deserialize("<red><bold>[✘ RECHAZAR]</bold></red>")
                .clickEvent(ClickEvent.runCommand("/clan deny " + clan.getName()))
                .hoverEvent(HoverEvent.showText(mm.deserialize("<red>Click para rechazar la invitación</red>")));

        Component buttons = Component.text("        ").append(acceptBtn)
                .append(Component.text("  ")).append(denyBtn);

        target.sendMessage(header);
        target.sendMessage(inviteMsg);
        target.sendMessage(Component.empty());
        target.sendMessage(buttons);
        target.sendMessage(header);
    }

    private void handleJoin(Player player, String[] args) {
        if (plugin.getClanManager().getClanByPlayer(player.getUniqueId()) != null) {
            plugin.getMessageManager().sendMessage(player, "clan.already-in-clan"); return;
        }

        String clanId = plugin.getInvitationManager().getInvitedClanId(player.getUniqueId());
        if (clanId == null) {
            plugin.getMessageManager().sendMessage(player, "clan.no-invitation"); return;
        }

        Clan clan = plugin.getClanManager().getClan(clanId);
        if (clan == null) {
            plugin.getMessageManager().sendMessage(player, "clan.clan-not-found"); return;
        }

        // Check ban
        if (clan.isBanned(player.getUniqueId())) {
            plugin.getMessageManager().sendMessage(player, "clan.banned-from-clan"); return;
        }

        // Check member limit (TOCTOU guard - re-check at join time)
        int maxMembers = plugin.getConfigManager().getConfig().getInt("clans.max-members", 20)
                + plugin.getUpgradeManager().getMemberSlotBonus(clan)
                + plugin.getLevelManager().getMaxMembersBonus(clan.getId());
        if (clan.getMembers().size() >= maxMembers) {
            plugin.getMessageManager().sendMessage(player, "clan.max-members"); return;
        }

        clan.addMember(new ClanMember(player.getUniqueId(), player.getName(), ClanRole.RECRUIT));
        plugin.getClanManager().updatePlayerClanMapping(player.getUniqueId(), clan.getId());
        plugin.getInvitationManager().removeInvitation(player.getUniqueId());
        plugin.getClanManager().saveClan(clan);
        plugin.getMessageManager().sendMessage(player, "clan.joined", "{clan}", clan.getDisplayName());
        plugin.getAuditLogger().log(clan.getId(), player.getUniqueId(), player.getName(),
                com.ethernova.clans.audit.AuditAction.MEMBER_JOINED, null);
        plugin.getLevelManager().onMemberJoin(clan.getId());

        // Notify clan
        for (Player member : plugin.getClanManager().getOnlineMembers(clan)) {
            if (!member.equals(player)) {
                plugin.getMessageManager().sendMessage(member, "clan.member-joined", "{player}", player.getName());
            }
        }
    }

    private void handleDenyInvite(Player player) {
        String clanId = plugin.getInvitationManager().getInvitedClanId(player.getUniqueId());
        if (clanId == null) {
            plugin.getMessageManager().sendMessage(player, "clan.no-invitation");
            return;
        }
        Clan clan = plugin.getClanManager().getClan(clanId);
        String clanName = clan != null ? clan.getDisplayName() : "desconocido";
        plugin.getInvitationManager().removeInvitation(player.getUniqueId());
        plugin.getMessageManager().sendMessage(player, "clan.invite-denied", "{clan}", clanName);
    }

    private void handleLeave(Player player) {
        Clan clan = requireClan(player); if (clan == null) return;
        ClanMember member = clan.getMember(player.getUniqueId());
        if (member != null && member.getRole() == ClanRole.LEADER) {
            plugin.getMessageManager().sendMessage(player, "clan.leader-cannot-leave"); return;
        }

        String displayName = clan.getDisplayName();
        plugin.getConfirmationManager().requestConfirmation(player, "leave",
                "<yellow>⚠ ¿Seguro que quieres salir de <white>" + displayName + "</white>?</yellow>\n" +
                "<gray>Usa <green>/clan confirm</green> para confirmar.</gray>",
                () -> {
                    clan.removeMember(player.getUniqueId());
                    plugin.getClanManager().updatePlayerClanMapping(player.getUniqueId(), null);
                    plugin.getMessageManager().sendMessage(player, "clan.left", "{clan}", displayName);
                    plugin.getAuditLogger().log(clan.getId(), player.getUniqueId(), player.getName(),
                            com.ethernova.clans.audit.AuditAction.MEMBER_LEFT, null);

                    for (Player m : plugin.getClanManager().getOnlineMembers(clan)) {
                        plugin.getMessageManager().sendMessage(m, "clan.member-left", "{player}", player.getName());
                    }
                });
    }

    private void handleKick(Player player, String[] args) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.OFFICER)) return;
        if (args.length < 2) {
            plugin.getMessageManager().sendMessage(player, "clan.usage-kick");
            return;
        }

        ClanMember target = clan.getMemberByName(args[1]);
        if (target == null) {
            plugin.getMessageManager().sendMessage(player, "clan.member-not-found"); return;
        }
        if (target.getRole().ordinal() >= clan.getMember(player.getUniqueId()).getRole().ordinal()) {
            plugin.getMessageManager().sendMessage(player, "clan.cannot-kick-higher"); return;
        }

        clan.removeMember(target.getUuid());
        plugin.getClanManager().updatePlayerClanMapping(target.getUuid(), null);
        plugin.getMessageManager().sendMessage(player, "clan.kicked", "{player}", target.getName());
        plugin.getAuditLogger().log(clan.getId(), player.getUniqueId(), player.getName(),
                com.ethernova.clans.audit.AuditAction.MEMBER_KICKED, target.getName());

        Player targetPlayer = Bukkit.getPlayer(target.getUuid());
        if (targetPlayer != null) {
            plugin.getMessageManager().sendMessage(targetPlayer, "clan.been-kicked", "{clan}", clan.getDisplayName());
        }
    }

    private void handlePromote(Player player, String[] args) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.LEADER)) return;
        if (args.length < 2) {
            plugin.getMessageManager().sendMessage(player, "clan.usage-promote");
            return;
        }

        ClanMember target = clan.getMemberByName(args[1]);
        if (target == null) {
            plugin.getMessageManager().sendMessage(player, "clan.member-not-found"); return;
        }

        ClanRole next = target.getRole().next();
        if (next == null || next == ClanRole.LEADER) {
            plugin.getMessageManager().sendMessage(player, "clan.max-role"); return;
        }

        target.setRole(next);
        plugin.getClanManager().saveClan(clan);
        plugin.getMessageManager().sendMessage(player, "clan.promoted",
                "{player}", target.getName(), "{role}", next.name());
        plugin.getAuditLogger().log(clan.getId(), player.getUniqueId(), player.getName(),
                com.ethernova.clans.audit.AuditAction.MEMBER_PROMOTED, target.getName() + " -> " + next.name());
    }

    private void handleDemote(Player player, String[] args) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.LEADER)) return;
        if (args.length < 2) {
            plugin.getMessageManager().sendMessage(player, "clan.usage-demote");
            return;
        }

        ClanMember target = clan.getMemberByName(args[1]);
        if (target == null) {
            plugin.getMessageManager().sendMessage(player, "clan.member-not-found");
            return;
        }

        ClanRole prev = target.getRole().previous();
        if (prev == null) {
            plugin.getMessageManager().sendMessage(player, "rank.already-minimum");
            return;
        }

        target.setRole(prev);
        plugin.getClanManager().saveClan(clan);
        plugin.getMessageManager().sendMessage(player, "clan.demoted",
                "{player}", target.getName(), "{role}", prev.name());
        plugin.getAuditLogger().log(clan.getId(), player.getUniqueId(), player.getName(),
                com.ethernova.clans.audit.AuditAction.MEMBER_DEMOTED, target.getName() + " -> " + prev.name());
    }

    private void handleInfo(Player player, String[] args) {
        Clan clan;
        if (args.length >= 2) {
            clan = plugin.getClanManager().getClanByName(args[1]);
        } else {
            clan = plugin.getClanManager().getClanByPlayer(player.getUniqueId());
        }
        if (clan == null) {
            plugin.getMessageManager().sendMessage(player, "clan.clan-not-found"); return;
        }

        var mm = plugin.getMessageManager();
        mm.sendMessage(player, "clan.info-header",
                "{clan_tag}", clan.getTag() != null ? "[" + clan.getTag() + "]" : "",
                "{clan_name}", clan.getDisplayName());
        if (clan.getDescription() != null && !clan.getDescription().isBlank()) {
            mm.sendMessage(player, "clan.info-description", "{description}", clan.getDescription());
        }
        mm.sendMessage(player, "clan.info-leader", "{leader}", clan.getLeaderName());
        mm.sendMessage(player, "clan.info-level",
                "{level}", String.valueOf(plugin.getLevelManager().getLevel(clan.getId())),
                "{level_name}", plugin.getLevelManager().getLevelName(plugin.getLevelManager().getLevel(clan.getId())));
        mm.sendMessage(player, "clan.info-members",
                "{online}", String.valueOf(plugin.getClanManager().getOnlineMembers(clan).size()),
                "{total}", String.valueOf(clan.getMembers().size()),
                "{max}", String.valueOf(plugin.getConfigManager().getConfig().getInt("clans.max-members", 20)));
        mm.sendMessage(player, "clan.info-power",
                "{power}", String.format("%.0f", plugin.getPowerManager().getClanPower(clan)),
                "{max_power}", String.format("%.0f", plugin.getPowerManager().getMaxClanPower(clan)));
        mm.sendMessage(player, "clan.info-territories",
                "{count}", String.valueOf(plugin.getTerritoryManager().getClaimCount(clan.getId())),
                "{max}", String.valueOf(plugin.getPowerManager().getMaxClaims(clan)));
        mm.sendMessage(player, "clan.info-bank",
                "{balance}", plugin.getEconomyManager().format(plugin.getBankManager().getBalance(clan.getId())));
        mm.sendMessage(player, "clan.info-allies",
                "{allies}", String.valueOf(plugin.getAllianceManager().getAllyCount(clan)));

        if (plugin.getWarManager().isAtWar(clan)) {
            var war = plugin.getWarManager().getWar(clan);
            mm.sendMessage(player, "clan.info-at-war",
                    "{enemies}", war != null ? String.valueOf(war.getRemainingSeconds() / 60) + "m" : "");
        }
        if (plugin.getShieldManager().hasActiveShield(clan.getId())) {
            mm.sendMessage(player, "clan.info-shield", "{time}", "");
        }
        mm.sendMessage(player, "clan.info-footer");
    }

    private void handleList(Player player, String[] args) {
        var allClans = new java.util.ArrayList<>(plugin.getClanManager().getAllClans());
        var mm = plugin.getMessageManager();

        int page = 1;
        if (args.length >= 2) {
            try { page = Integer.parseInt(args[1]); } catch (NumberFormatException ignored) {}
        }

        int perPage = 10;
        int totalPages = Math.max(1, (int) Math.ceil((double) allClans.size() / perPage));
        page = Math.max(1, Math.min(page, totalPages));

        int start = (page - 1) * perPage;
        int end = Math.min(start + perPage, allClans.size());

        mm.sendMessage(player, "clan.list-header",
                "{page}", String.valueOf(page),
                "{pages}", String.valueOf(totalPages));

        for (int i = start; i < end; i++) {
            Clan clan = allClans.get(i);
            mm.sendMessage(player, "clan.list-entry",
                    "{rank}", String.valueOf(i + 1),
                    "{clan}", clan.getDisplayName(),
                    "{members}", String.valueOf(clan.getMembers().size()),
                    "{power}", String.format("%.0f", plugin.getPowerManager().getClanPower(clan)),
                    "{level}", String.valueOf(plugin.getLevelManager().getLevel(clan.getId())));
        }

        if (allClans.isEmpty()) {
            mm.sendMessage(player, "clan.list-empty");
        }

        // Navigation
        if (page < totalPages) {
            mm.sendMessage(player, "clan.list-navigation",
                    "{page}", String.valueOf(page),
                    "{pages}", String.valueOf(totalPages),
                    "{next}", String.valueOf(page + 1));
        }
    }

    private void handleChat(Player player) {
        Clan clan = requireClan(player); if (clan == null) return;
        plugin.getChatManager().toggleClanChat(player.getUniqueId());
        boolean inChat = plugin.getChatManager().isInClanChat(player.getUniqueId());
        plugin.getMessageManager().sendMessage(player, inChat ? "chat.clan-on" : "chat.clan-off");
    }

    private void handleAllyChat(Player player) {
        Clan clan = requireClan(player); if (clan == null) return;
        plugin.getChatManager().toggleAllyChat(player.getUniqueId());
        boolean inChat = plugin.getChatManager().isInAllyChat(player.getUniqueId());
        plugin.getMessageManager().sendMessage(player, inChat ? "chat.ally-on" : "chat.ally-off");
    }

    private void handleOfficerChat(Player player) {
        Clan clan = requireClan(player); if (clan == null) return;
        ClanMember member = clan.getMember(player.getUniqueId());
        if (member == null || !member.getRole().isAtLeast(com.ethernova.clans.clan.ClanRole.OFFICER)) {
            plugin.getMessageManager().sendMessage(player, "chat.officer-no-permission");
            return;
        }
        plugin.getChatManager().toggleOfficerChat(player.getUniqueId());
        boolean inChat = plugin.getChatManager().isInOfficerChat(player.getUniqueId());
        plugin.getMessageManager().sendMessage(player, inChat ? "chat.officer-on" : "chat.officer-off");
    }

    private void handleTop(Player player, String[] args) {
        String type = args.length >= 2 ? args[1].toLowerCase() : "power";
        // Check if type arg is actually a page number (e.g., /clan top 2)
        int page = 1;
        if (args.length >= 3) {
            try { page = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
        }
        // If second arg is a number, treat as page for default (power) sort
        if (args.length == 2) {
            try {
                page = Integer.parseInt(args[1]);
                type = "power";
            } catch (NumberFormatException ignored) { /* it's a type, not a page */ }
        }

        var clans = new java.util.ArrayList<>(plugin.getClanManager().getAllClans());

        String finalType = type;
        switch (type) {
            case "members", "miembros" -> clans.sort((a, b) -> b.getMembers().size() - a.getMembers().size());
            case "kills" -> clans.sort((a, b) -> getClanKills(b) - getClanKills(a));
            case "territory", "territorio" -> clans.sort((a, b) ->
                    plugin.getTerritoryManager().getClaimCount(b.getId()) - plugin.getTerritoryManager().getClaimCount(a.getId()));
            case "level", "nivel" -> clans.sort((a, b) ->
                    Long.compare(plugin.getLevelManager().getXP(b.getId()), plugin.getLevelManager().getXP(a.getId())));
            case "bank", "banco" -> clans.sort((a, b) ->
                    Double.compare(plugin.getBankManager().getBalance(b.getId()), plugin.getBankManager().getBalance(a.getId())));
            default -> clans.sort((a, b) ->
                    Double.compare(plugin.getPowerManager().getClanPower(b), plugin.getPowerManager().getClanPower(a)));
        }

        int perPage = 10;
        int totalPages = Math.max(1, (int) Math.ceil((double) clans.size() / perPage));
        page = Math.max(1, Math.min(page, totalPages));
        int start = (page - 1) * perPage;
        int end = Math.min(start + perPage, clans.size());

        var mm = plugin.getMessageManager();
        mm.sendMessage(player, "clan.top-header",
                "{category}", finalType,
                "{page}", String.valueOf(page),
                "{pages}", String.valueOf(totalPages));

        for (int i = start; i < end; i++) {
            Clan clan = clans.get(i);
            String value = switch (finalType) {
                case "members", "miembros" -> clan.getMembers().size() + " members";
                case "kills" -> getClanKills(clan) + " kills";
                case "territory", "territorio" -> plugin.getTerritoryManager().getClaimCount(clan.getId()) + " chunks";
                case "level", "nivel" -> "Lv." + plugin.getLevelManager().getLevel(clan.getId());
                case "bank", "banco" -> plugin.getEconomyManager().format(plugin.getBankManager().getBalance(clan.getId()));
                default -> String.format("%.0f", plugin.getPowerManager().getClanPower(clan)) + " power";
            };
            mm.sendMessage(player, "clan.top-entry",
                    "{rank}", String.valueOf(i + 1),
                    "{clan}", clan.getDisplayName(),
                    "{value}", value);
        }

        if (clans.isEmpty()) {
            mm.sendMessage(player, "clan.top-empty");
        }

        // Navigation
        if (page > 1 || page < totalPages) {
            mm.sendMessage(player, "clan.top-navigation",
                    "{page}", String.valueOf(page),
                    "{pages}", String.valueOf(totalPages));
        }
    }

    private void handleTransfer(Player player, String[] args) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.LEADER)) return;
        if (args.length < 2) {
            plugin.getMessageManager().sendMessage(player, "clan.transfer-usage"); return;
        }

        ClanMember target = clan.getMemberByName(args[1]);
        if (target == null) {
            plugin.getMessageManager().sendMessage(player, "clan.member-not-found"); return;
        }
        if (target.getUuid().equals(player.getUniqueId())) {
            plugin.getMessageManager().sendMessage(player, "clan.transfer-self"); return;
        }

        // Transfer
        ClanMember self = clan.getMember(player.getUniqueId());
        target.setRole(ClanRole.LEADER);
        self.setRole(ClanRole.CO_LEADER);
        clan.setLeaderUuid(target.getUuid());
        clan.setLeaderName(target.getName());

        plugin.getMessageManager().sendMessage(player, "clan.transfer-done", "{player}", target.getName());
        Player targetPlayer = org.bukkit.Bukkit.getPlayer(target.getUuid());
        if (targetPlayer != null) {
            plugin.getMessageManager().sendMessage(targetPlayer, "clan.transfer-received", "{player}", player.getName());
        }

        for (Player m : plugin.getClanManager().getOnlineMembers(clan)) {
            if (!m.equals(player) && !m.getUniqueId().equals(target.getUuid())) {
                plugin.getMessageManager().sendMessage(m, "clan.transfer-broadcast",
                        "{old}", player.getName(), "{new}", target.getName());
            }
        }
        plugin.getAuditLogger().log(clan.getId(), player.getUniqueId(), player.getName(),
                com.ethernova.clans.audit.AuditAction.LEADERSHIP_TRANSFERRED, target.getName());
        plugin.getClanManager().saveClan(clan);
    }

    private void handleDesc(Player player, String[] args) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.OFFICER)) return;
        if (args.length < 2) {
            plugin.getMessageManager().sendMessage(player, "clan.desc-usage"); return;
        }

        String desc = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
        // Strip MiniMessage tags to prevent injection
        desc = desc.replaceAll("<[^>]+>", "").trim();
        int maxLen = plugin.getConfigManager().getConfig().getInt("clans.desc-max-length", 100);
        if (desc.length() > maxLen) {
            plugin.getMessageManager().sendMessage(player, "clan.desc-too-long", "{max}", String.valueOf(maxLen)); return;
        }

        clan.setDescription(desc);
        plugin.getMessageManager().sendMessage(player, "clan.desc-set");
        plugin.getAuditLogger().log(clan.getId(), player.getUniqueId(), player.getName(),
                com.ethernova.clans.audit.AuditAction.DESCRIPTION_CHANGED, desc);
    }

    private void handleBan(Player player, String[] args) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.LEADER)) return;
        if (args.length < 2) return;

        // Use cached lookup to avoid blocking the main thread (Mojang API)
        org.bukkit.OfflinePlayer target = org.bukkit.Bukkit.getOfflinePlayerIfCached(args[1]);
        if (target == null) {
            plugin.getMessageManager().sendMessage(player, "general.player-not-found");
            return;
        }
        clan.addBanned(target.getUniqueId());

        // Kick if member
        if (clan.isMember(target.getUniqueId())) {
            clan.removeMember(target.getUniqueId());
            plugin.getClanManager().updatePlayerClanMapping(target.getUniqueId(), null);
        }

        plugin.getMessageManager().sendMessage(player, "clan.banned", "{player}", args[1]);
        plugin.getAuditLogger().log(clan.getId(), player.getUniqueId(), player.getName(),
                com.ethernova.clans.audit.AuditAction.MEMBER_BANNED, args[1]);
    }

    private void handleUnban(Player player, String[] args) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.LEADER)) return;
        if (args.length < 2) return;

        // Use cached lookup to avoid blocking the main thread (Mojang API)
        org.bukkit.OfflinePlayer target = org.bukkit.Bukkit.getOfflinePlayerIfCached(args[1]);
        if (target == null) {
            plugin.getMessageManager().sendMessage(player, "general.player-not-found");
            return;
        }
        clan.removeBanned(target.getUniqueId());
        plugin.getMessageManager().sendMessage(player, "clan.unbanned", "{player}", args[1]);
        plugin.getAuditLogger().log(clan.getId(), player.getUniqueId(), player.getName(),
                com.ethernova.clans.audit.AuditAction.MEMBER_UNBANNED, args[1]);
    }

    private void handleAutoClaim(Player player) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.OFFICER)) return;

        boolean toggled = plugin.getTerritoryManager().toggleAutoClaim(player.getUniqueId());
        plugin.getMessageManager().sendMessage(player, toggled ? "territory.autoclaim-on" : "territory.autoclaim-off");
    }

    private void handleMap(Player player) {
        var mm = plugin.getMessageManager();
        mm.sendMessage(player, "map.header");

        org.bukkit.Chunk center = player.getLocation().getChunk();
        Clan playerClan = plugin.getClanManager().getClanByPlayer(player.getUniqueId());
        int radius = 4;

        // Header with compass
        mm.sendMessage(player, "map.north");

        for (int dz = -radius; dz <= radius; dz++) {
            StringBuilder line = new StringBuilder();
            if (dz == 0) line.append("<gray>W </gray>");
            else line.append("<gray>  </gray>");

            for (int dx = -radius; dx <= radius; dx++) {
                String chunkId = center.getWorld().getName() + ":" + (center.getX() + dx) + ":" + (center.getZ() + dz);
                String owner = plugin.getTerritoryManager().getOwner(chunkId);

                if (dx == 0 && dz == 0) {
                    line.append("<white><bold>+</bold></white>");
                } else if (owner == null) {
                    line.append("<dark_gray>-</dark_gray>");
                } else if (playerClan != null && owner.equals(playerClan.getId())) {
                    line.append("<green>■</green>");
                } else {
                    Clan ownerClan = plugin.getClanManager().getClan(owner);
                    if (ownerClan != null && playerClan != null && plugin.getAllianceManager().areAllied(playerClan, ownerClan)) {
                        line.append("<aqua>■</aqua>");
                    } else if (ownerClan != null && playerClan != null && plugin.getWarManager().isAtWar(playerClan, ownerClan)) {
                        line.append("<red>■</red>");
                    } else {
                        line.append("<yellow>■</yellow>");
                    }
                }
            }

            if (dz == 0) line.append("<gray> E</gray>");
            mm.sendRaw(player, line.toString());
        }

        mm.sendMessage(player, "map.south");
    }

    private void handleHome(Player player) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (clan.getHome() == null) {
            plugin.getMessageManager().sendMessage(player, "clan.no-home"); return;
        }
        if (plugin.getCombatHook().isInCombat(player)) {
            plugin.getMessageManager().sendMessage(player, "clan.cannot-tp-combat"); return;
        }

        // Cooldown
        if (plugin.getCoreHook().isAvailable()) {
            if (plugin.getCoreHook().hasCooldown(player.getUniqueId(), "clan_home")) {
                String remaining = plugin.getCoreHook().getRemainingFormatted(player.getUniqueId(), "clan_home");
                plugin.getMessageManager().sendMessage(player, "clan.home-cooldown", "{time}", remaining);
                return;
            }
        }

        // Warmup teleport — cooldown set ONLY on successful completion
        Runnable onTeleportComplete = () -> {
            if (plugin.getCoreHook().isAvailable()) {
                long cooldownMs = plugin.getConfigManager().getConfig().getLong("clans.home-cooldown-seconds", 60) * 1000L;
                plugin.getCoreHook().setCooldown(player.getUniqueId(), "clan_home", cooldownMs);
            }
        };
        plugin.getTeleportManager().teleportWithWarmup(player, clan.getHome(), "clan.teleported-home", onTeleportComplete);
    }

    private void handleLog(Player player) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.OFFICER)) return;

        var mm = plugin.getMessageManager();
        mm.sendMessage(player, "audit.header");

        // Async DB query to avoid blocking the main thread
        plugin.getAuditLogger().getRecentLogsAsync(clan.getId(), 15, logs -> {
            if (logs.isEmpty()) {
                mm.sendMessage(player, "audit.no-records");
            } else {
                for (String log : logs) {
                    mm.sendRaw(player, log);
                }
            }
        });
    }

    private void handleFlags(Player player, String[] args) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.LEADER)) return;

        if (args.length < 2) {
            // Show all flags
            var mm = plugin.getMessageManager();
            mm.sendMessage(player, "territory.flags-header", "{chunk}", "");
            for (com.ethernova.clans.territory.TerritoryFlag flag : com.ethernova.clans.territory.TerritoryFlag.values()) {
                boolean val = plugin.getTerritoryFlagManager().getFlag(clan.getId(), flag);
                String value = val ? "<green>✔ ON</green>" : "<red>✖ OFF</red>";
                mm.sendMessage(player, "territory.flags-entry",
                        "{flag}", flag.getDisplayName(),
                        "{value}", value);
            }
            mm.sendMessage(player, "territory.flags-usage");
            return;
        }

        String flagName = args[1].toUpperCase().replace("-", "_");
        try {
            com.ethernova.clans.territory.TerritoryFlag flag = com.ethernova.clans.territory.TerritoryFlag.valueOf(flagName);
            plugin.getTerritoryFlagManager().toggleFlag(clan.getId(), flag);
            boolean newVal = plugin.getTerritoryFlagManager().getFlag(clan.getId(), flag);
            plugin.getMessageManager().sendMessage(player, "territory.flag-toggled",
                    "{flag}", flag.getDisplayName(),
                    "{value}", newVal ? "ON" : "OFF");
            plugin.getAuditLogger().log(clan.getId(), player.getUniqueId(), player.getName(),
                    com.ethernova.clans.audit.AuditAction.FLAG_CHANGED, flag.name() + "=" + newVal);
        } catch (IllegalArgumentException e) {
            plugin.getMessageManager().sendMessage(player, "territory.flag-invalid", "{flag}", args[1]);
        }
    }

    // ══════════════════════════════════════════════════════════
    //  MISSING HANDLER STUBS
    // ══════════════════════════════════════════════════════════

    private void handleAlly(Player player, String[] args) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.CO_LEADER)) return;
        if (args.length < 2) {
            plugin.getMessageManager().sendMessage(player, "alliance.usage"); return;
        }
        String action = args[1].toLowerCase();
        Clan target = args.length >= 3 ? plugin.getClanManager().getClanByName(args[2]) : null;
        if (target == null && !action.equals("list")) {
            plugin.getMessageManager().sendMessage(player, "alliance.clan-not-found"); return;
        }
        switch (action) {
            case "request", "add" -> {
                plugin.getAllianceManager().sendAllyRequest(clan, target);
                plugin.getMessageManager().sendMessage(player, "alliance.request-sent", "{clan}", target.getDisplayName());
            }
            case "accept" -> {
                plugin.getAllianceManager().acceptAllyRequest(clan, target);
                plugin.getMessageManager().sendMessage(player, "alliance.accepted", "{clan}", target.getDisplayName());
            }
            case "deny" -> {
                plugin.getAllianceManager().denyAllyRequest(clan, target);
                plugin.getMessageManager().sendMessage(player, "alliance.denied", "{clan}", target.getDisplayName());
            }
            case "break", "remove" -> {
                plugin.getAllianceManager().breakAlliance(clan, target);
                plugin.getMessageManager().sendMessage(player, "alliance.broken", "{clan}", target.getDisplayName());
            }
            default -> plugin.getMessageManager().sendMessage(player, "alliance.usage");
        }
    }

    private void handleEnemy(Player player, String[] args) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.CO_LEADER)) return;
        if (args.length < 2) return;
        Clan target = plugin.getClanManager().getClanByName(args[1]);
        if (target == null) { plugin.getMessageManager().sendMessage(player, "alliance.clan-not-found"); return; }
        plugin.getAllianceManager().setRival(clan, target);
        plugin.getMessageManager().sendMessage(player, "alliance.rival-set", "{clan}", target.getDisplayName());
    }

    private void handleClaim(Player player) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.OFFICER)) return;
        org.bukkit.Chunk chunk = player.getLocation().getChunk();
        String chunkKey = ClanManager.buildChunkKey(chunk.getWorld().getName(), chunk.getX(), chunk.getZ());
        plugin.getClanManager().claimChunk(clan, player, chunkKey);
    }

    private void handleUnclaim(Player player) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.OFFICER)) return;
        org.bukkit.Chunk chunk = player.getLocation().getChunk();
        String chunkKey = ClanManager.buildChunkKey(chunk.getWorld().getName(), chunk.getX(), chunk.getZ());
        plugin.getClanManager().unclaimChunk(clan, player, chunkKey);
    }

    private void handleSetHome(Player player) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.OFFICER)) return;
        clan.setHome(player.getLocation());
        plugin.getClanManager().saveClan(clan);
        plugin.getMessageManager().sendMessage(player, "clan.home-set");
    }

    private void handleWarp(Player player, String[] args) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (args.length < 2) {
            plugin.getMessageManager().sendMessage(player, "clan.warp-usage"); return;
        }
        org.bukkit.Location loc = clan.getWarp(args[1]);
        if (loc == null) {
            plugin.getMessageManager().sendMessage(player, "clan.warp-not-found"); return;
        }
        plugin.getTeleportManager().teleportWithWarmup(player, loc, "clan.warped");
    }

    private void handleSetWarp(Player player, String[] args) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.OFFICER)) return;
        if (args.length < 2) {
            plugin.getMessageManager().sendMessage(player, "clan.warp-usage"); return;
        }
        clan.setWarp(args[1], player.getLocation());
        plugin.getClanManager().saveClan(clan);
        plugin.getMessageManager().sendMessage(player, "clan.warp-set", "{name}", args[1]);
    }

    private void handleDelWarp(Player player, String[] args) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.OFFICER)) return;
        if (args.length < 2) return;
        if (clan.removeWarp(args[1])) {
            plugin.getClanManager().saveClan(clan);
            plugin.getMessageManager().sendMessage(player, "clan.warp-deleted", "{name}", args[1]);
        } else {
            plugin.getMessageManager().sendMessage(player, "clan.warp-not-found");
        }
    }

    private void handleWarps(Player player) {
        Clan clan = requireClan(player); if (clan == null) return;
        var warps = clan.getWarps();
        if (warps.isEmpty()) {
            plugin.getMessageManager().sendMessage(player, "clan.no-warps"); return;
        }
        var mm = plugin.getMessageManager();
        mm.sendMessage(player, "warp.list-header",
                "{count}", String.valueOf(warps.size()),
                "{max}", "");
        for (var entry : warps.entrySet()) {
            var loc = entry.getValue();
            String worldName = loc.getWorld() != null ? loc.getWorld().getName() : "unknown";
            mm.sendMessage(player, "warp.list-entry",
                    "{name}", entry.getKey(),
                    "{world}", worldName,
                    "{x}", String.valueOf(loc.getBlockX()),
                    "{y}", String.valueOf(loc.getBlockY()),
                    "{z}", String.valueOf(loc.getBlockZ()));
        }
    }

    private void handleWar(Player player, String[] args) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.CO_LEADER)) return;
        if (args.length < 2) {
            plugin.getGuiManager().openWars(player); return;
        }
        String action = args[1].toLowerCase();
        switch (action) {
            case "declare" -> {
                if (args.length < 3) { plugin.getMessageManager().sendMessage(player, "war.usage"); return; }
                Clan target = plugin.getClanManager().getClanByName(args[2]);
                if (target == null) { plugin.getMessageManager().sendMessage(player, "war.clan-not-found"); return; }
                boolean success = plugin.getWarManager().declareWar(clan, target);
                if (!success) {
                    plugin.getMessageManager().sendMessage(player, "war.declare-failed", "{clan}", target.getDisplayName());
                }
            }
            case "accept" -> {
                boolean accepted = plugin.getWarManager().acceptWar(clan);
                if (!accepted) {
                    plugin.getMessageManager().sendMessage(player, "war.no-pending");
                }
            }
            case "deny" -> {
                boolean denied = plugin.getWarManager().denyWar(clan);
                if (!denied) {
                    plugin.getMessageManager().sendMessage(player, "war.no-pending");
                }
            }
            case "surrender" -> plugin.getWarManager().surrender(clan);
            default -> plugin.getGuiManager().openWars(player);
        }
    }

    private void handleUpgrade(Player player, String[] args) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.CO_LEADER)) return;
        plugin.getGuiManager().openUpgrades(player);
    }

    private void handleBank(Player player, String[] args) {
        Clan clan = requireClan(player); if (clan == null) return;
        if (args.length < 2) {
            plugin.getGuiManager().openBank(player); return;
        }
        String action = args[1].toLowerCase();
        switch (action) {
            case "balance" -> {
                double bal = plugin.getBankManager().getBalance(clan.getId());
                plugin.getMessageManager().sendMessage(player, "bank.balance",
                        "{balance}", plugin.getEconomyManager().format(bal));
            }
            case "deposit" -> {
                if (args.length < 3) { plugin.getMessageManager().sendMessage(player, "bank.deposit-usage"); return; }
                try {
                    double amount = Double.parseDouble(args[2]);
                    if (amount <= 0) { plugin.getMessageManager().sendMessage(player, "bank.invalid-amount"); return; }
                    // Use BankManager as the single source of truth (syncs with ClanBank + persists)
                    if (plugin.getBankManager().deposit(clan, player, amount)) {
                        plugin.getMessageManager().sendMessage(player, "bank.deposited",
                                "{amount}", plugin.getEconomyManager().format(amount));
                    } else {
                        plugin.getMessageManager().sendMessage(player, "bank.insufficient-funds");
                    }
                } catch (NumberFormatException e) { plugin.getMessageManager().sendMessage(player, "bank.invalid-amount"); }
            }
            case "withdraw" -> {
                if (!requireRole(player, clan, ClanRole.OFFICER)) return;
                if (args.length < 3) { plugin.getMessageManager().sendMessage(player, "bank.withdraw-usage"); return; }
                try {
                    double amount = Double.parseDouble(args[2]);
                    if (amount <= 0) { plugin.getMessageManager().sendMessage(player, "bank.invalid-amount"); return; }
                    // Use BankManager as the single source of truth (syncs with ClanBank + persists)
                    if (plugin.getBankManager().withdraw(clan, player, amount)) {
                        plugin.getMessageManager().sendMessage(player, "bank.withdrawn",
                                "{amount}", plugin.getEconomyManager().format(amount));
                    } else {
                        plugin.getMessageManager().sendMessage(player, "bank.insufficient-bank-funds");
                    }
                } catch (NumberFormatException e) { plugin.getMessageManager().sendMessage(player, "bank.invalid-amount"); }
            }
            default -> plugin.getGuiManager().openBank(player);
        }
    }

    private void handleLevel(Player player) {
        Clan clan = requireClan(player); if (clan == null) return;
        int level = plugin.getLevelManager().getLevel(clan.getId());
        long xp = plugin.getLevelManager().getXP(clan.getId());
        long needed = plugin.getLevelManager().getXPForNextLevel(clan.getId());
        var mm = plugin.getMessageManager();
        mm.sendMessage(player, "level.info-header");
        mm.sendMessage(player, "level.info-level",
                "{level}", String.valueOf(level),
                "{level_name}", plugin.getLevelManager().getLevelName(level));
        mm.sendMessage(player, "level.info-xp",
                "{xp}", String.valueOf(xp),
                "{max_xp}", String.valueOf(needed));
        mm.sendMessage(player, "level.info-progress",
                "{bar}", com.ethernova.clans.util.TextUtil.progressBar(
                        (int) plugin.getLevelManager().getCurrentLevelXP(clan.getId()), (int) needed),
                "{percent}", String.valueOf(needed > 0 ? (plugin.getLevelManager().getCurrentLevelXP(clan.getId()) * 100 / needed) : 0));
    }

    // ══════════════════════════════════════════════════════════
    //  NATION COMMANDS
    // ══════════════════════════════════════════════════════════

    private void handleNation(Player player, String[] args) {
        var mm = plugin.getMessageManager();
        NationManager nm = plugin.getNationManager();

        if (args.length < 2) {
            // Show nation info if in one, otherwise help
            Clan clan = requireClan(player);
            if (clan == null) return;
            Nation nation = nm.getNationByClan(clan.getId());
            if (nation != null) {
                showNationInfo(player, nation);
            } else {
                showNationHelp(player);
            }
            return;
        }

        String sub = args[1].toLowerCase();
        switch (sub) {
            case "create", "crear" -> handleNationCreate(player, args);
            case "disband", "disolver" -> handleNationDisband(player);
            case "invite", "invitar" -> handleNationInvite(player, args);
            case "accept", "aceptar", "join", "unir" -> handleNationAccept(player);
            case "deny", "rechazar" -> handleNationDeny(player);
            case "kick", "expulsar" -> handleNationKick(player, args);
            case "leave", "salir" -> handleNationLeave(player);
            case "promote", "ascender" -> handleNationPromote(player, args);
            case "demote", "degradar" -> handleNationDemote(player, args);
            case "info" -> handleNationInfoCmd(player, args);
            case "list", "lista" -> handleNationList(player);
            case "chat", "c" -> handleNationChat(player);
            case "desc", "descripcion" -> handleNationDesc(player, args);
            default -> showNationHelp(player);
        }
    }

    private void handleNationCreate(Player player, String[] args) {
        var mm = plugin.getMessageManager();
        Clan clan = requireClan(player);
        if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.LEADER)) return;

        if (args.length < 3) {
            mm.sendMessage(player, "nation.create-usage");
            return;
        }

        NationManager nm = plugin.getNationManager();
        if (nm.isInNation(clan.getId())) {
            mm.sendMessage(player, "nation.already-in-nation");
            return;
        }

        String name = args[2];
        String tag = args.length >= 4 ? args[3] : name.substring(0, Math.min(3, name.length())).toUpperCase();

        // Check cost
        double cost = nm.getCreateCost();
        if (cost > 0 && plugin.getEconomyManager().isEnabled()) {
            double bal = plugin.getEconomyManager().getBalance(player);
            if (bal < cost) {
                mm.sendMessage(player, "nation.create-insufficient-funds", "{cost}", String.format("%.0f", cost));
                return;
            }
            plugin.getEconomyManager().withdraw(player, cost);
        }

        Nation nation = nm.createNation(name, tag, clan);
        mm.sendMessage(player, "nation.created", "{nation}", nation.getName());
        mm.sendMessage(player, "nation.created-hint");
    }

    private void handleNationDisband(Player player) {
        var mm = plugin.getMessageManager();
        Clan clan = requireClan(player);
        if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.LEADER)) return;

        NationManager nm = plugin.getNationManager();
        Nation nation = nm.getNationByClan(clan.getId());
        if (nation == null) {
            mm.sendMessage(player, "nation.not-in-nation");
            return;
        }
        if (!nation.getLeaderClanId().equals(clan.getId())) {
            mm.sendMessage(player, "nation.disband-no-permission");
            return;
        }

        nm.disbandNation(nation);
        mm.sendMessage(player, "nation.disbanded", "{nation}", nation.getName());
    }

    private void handleNationInvite(Player player, String[] args) {
        var mm = plugin.getMessageManager();
        Clan clan = requireClan(player);
        if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.LEADER)) return;

        NationManager nm = plugin.getNationManager();
        Nation nation = nm.getNationByClan(clan.getId());
        if (nation == null) {
            mm.sendMessage(player, "nation.not-in-nation");
            return;
        }
        if (!nation.getRole(clan.getId()).isAtLeast(Nation.NationRole.OFFICER)) {
            mm.sendMessage(player, "nation.invite-no-permission");
            return;
        }

        if (args.length < 3) {
            mm.sendMessage(player, "nation.invite-usage");
            return;
        }

        Clan targetClan = plugin.getClanManager().getClanByName(args[2]);
        if (targetClan == null) {
            mm.sendMessage(player, "nation.clan-not-found", "{clan}", args[2]);
            return;
        }

        String error = nm.inviteClan(nation, targetClan);
        if (error != null) {
            switch (error) {
                case "nation-full" -> mm.sendMessage(player, "nation.max-clans");
                case "clan-already-in-nation" -> mm.sendMessage(player, "nation.target-already-in-nation");
                case "invite-already-pending" -> mm.sendMessage(player, "nation.invite-already-pending");
            }
            return;
        }
        mm.sendMessage(player, "nation.invited", "{clan}", targetClan.getDisplayName());
    }

    private void handleNationAccept(Player player) {
        var mm = plugin.getMessageManager();
        Clan clan = requireClan(player);
        if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.LEADER)) return;

        String error = plugin.getNationManager().acceptInvite(clan);
        if (error != null) {
            switch (error) {
                case "no-pending-invite" -> mm.sendMessage(player, "nation.no-pending-invite");
                case "nation-not-found" -> mm.sendMessage(player, "nation.nation-not-found");
            }
            return;
        }
        Nation nation = plugin.getNationManager().getNationByClan(clan.getId());
        mm.sendMessage(player, "nation.joined", "{nation}", nation != null ? nation.getName() : "?");
    }

    private void handleNationDeny(Player player) {
        var mm = plugin.getMessageManager();
        Clan clan = requireClan(player);
        if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.LEADER)) return;

        plugin.getNationManager().denyInvite(clan.getId());
        mm.sendMessage(player, "nation.invite-denied");
    }

    private void handleNationKick(Player player, String[] args) {
        var mm = plugin.getMessageManager();
        Clan clan = requireClan(player);
        if (clan == null) return;

        NationManager nm = plugin.getNationManager();
        Nation nation = nm.getNationByClan(clan.getId());
        if (nation == null) {
            mm.sendMessage(player, "nation.not-in-nation");
            return;
        }
        if (args.length < 3) {
            mm.sendMessage(player, "nation.kick-usage");
            return;
        }

        Clan targetClan = plugin.getClanManager().getClanByName(args[2]);
        if (targetClan == null) {
            mm.sendMessage(player, "nation.clan-not-found", "{clan}", args[2]);
            return;
        }

        String error = nm.kickClan(nation, targetClan.getId(), clan.getId());
        if (error != null) {
            switch (error) {
                case "cannot-kick-leader" -> mm.sendMessage(player, "nation.cannot-kick-leader");
                case "not-in-nation" -> mm.sendMessage(player, "nation.not-in-this-nation");
                case "no-permission" -> mm.sendMessage(player, "nation.kick-no-permission");
                case "cannot-kick-higher-rank" -> mm.sendMessage(player, "nation.cannot-kick-higher-rank");
            }
            return;
        }
        mm.sendMessage(player, "nation.kicked", "{clan}", targetClan.getDisplayName());
    }

    private void handleNationLeave(Player player) {
        var mm = plugin.getMessageManager();
        Clan clan = requireClan(player);
        if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.LEADER)) return;

        NationManager nm = plugin.getNationManager();
        Nation nation = nm.getNationByClan(clan.getId());
        if (nation == null) {
            mm.sendMessage(player, "nation.not-in-nation");
            return;
        }

        String error = nm.leaveClan(nation, clan);
        if (error != null) {
            if (error.equals("leader-cannot-leave")) {
                mm.sendMessage(player, "nation.leader-cannot-leave");
            }
            return;
        }
        mm.sendMessage(player, "nation.left", "{nation}", nation.getName());
    }

    private void handleNationPromote(Player player, String[] args) {
        var mm = plugin.getMessageManager();
        Clan clan = requireClan(player);
        if (clan == null) return;

        NationManager nm = plugin.getNationManager();
        Nation nation = nm.getNationByClan(clan.getId());
        if (nation == null) { mm.sendMessage(player, "nation.not-in-nation"); return; }
        if (args.length < 3) { mm.sendMessage(player, "nation.promote-usage"); return; }

        Clan target = plugin.getClanManager().getClanByName(args[2]);
        if (target == null) { mm.sendMessage(player, "nation.clan-not-found", "{clan}", args[2]); return; }

        String error = nm.promoteClan(nation, target.getId(), clan.getId());
        if (error != null) {
            switch (error) {
                case "only-leader" -> mm.sendMessage(player, "nation.promote-no-permission");
                case "not-in-nation" -> mm.sendMessage(player, "nation.not-in-this-nation");
                case "already-leader" -> mm.sendMessage(player, "nation.already-leader");
            }
            return;
        }
        mm.sendMessage(player, "nation.promoted", "{clan}", target.getDisplayName());
    }

    private void handleNationDemote(Player player, String[] args) {
        var mm = plugin.getMessageManager();
        Clan clan = requireClan(player);
        if (clan == null) return;

        NationManager nm = plugin.getNationManager();
        Nation nation = nm.getNationByClan(clan.getId());
        if (nation == null) { mm.sendMessage(player, "nation.not-in-nation"); return; }
        if (args.length < 3) { mm.sendMessage(player, "nation.demote-usage"); return; }

        Clan target = plugin.getClanManager().getClanByName(args[2]);
        if (target == null) { mm.sendMessage(player, "nation.clan-not-found", "{clan}", args[2]); return; }

        String error = nm.demoteClan(nation, target.getId(), clan.getId());
        if (error != null) {
            switch (error) {
                case "only-leader" -> mm.sendMessage(player, "nation.demote-no-permission");
                case "not-in-nation" -> mm.sendMessage(player, "nation.not-in-this-nation");
                case "already-member" -> mm.sendMessage(player, "nation.already-member");
            }
            return;
        }
        mm.sendMessage(player, "nation.demoted", "{clan}", target.getDisplayName());
    }

    private void handleNationInfoCmd(Player player, String[] args) {
        var mm = plugin.getMessageManager();
        NationManager nm = plugin.getNationManager();
        Nation nation;
        if (args.length >= 3) {
            // Look up by nation name
            nation = nm.getAllNations().stream()
                    .filter(n -> n.getName().equalsIgnoreCase(args[2]))
                    .findFirst().orElse(null);
        } else {
            Clan clan = requireClan(player);
            if (clan == null) return;
            nation = nm.getNationByClan(clan.getId());
        }
        if (nation == null) {
            mm.sendMessage(player, "nation.nation-not-found");
            return;
        }
        showNationInfo(player, nation);
    }

    private void showNationInfo(Player player, Nation nation) {
        var mm = plugin.getMessageManager();
        Clan leaderClan = plugin.getClanManager().getClan(nation.getLeaderClanId());
        String leaderName = leaderClan != null ? leaderClan.getDisplayName() : "???";

        mm.sendMessage(player, "nation.info-header", "{nation}", nation.getName() + " [" + nation.getTag() + "]");
        if (nation.getDescription() != null && !nation.getDescription().isEmpty()) {
            mm.sendMessage(player, "nation.info-description", "{description}", nation.getDescription());
        }
        mm.sendMessage(player, "nation.info-leader", "{leader}", leaderName);
        mm.sendMessage(player, "nation.info-clans",
                "{count}", String.valueOf(nation.getClanCount()),
                "{max}", String.valueOf(plugin.getNationManager().getMaxClansPerNation()));

        // List member clans with roles
        for (var entry : nation.getMemberClansMap().entrySet()) {
            Clan memberClan = plugin.getClanManager().getClan(entry.getKey());
            String clanName = memberClan != null ? memberClan.getDisplayName() : entry.getKey();
            mm.sendMessage(player, "nation.info-member",
                    "{clan}", clanName,
                    "{role}", entry.getValue().name());
        }
        mm.sendMessage(player, "nation.info-footer");
    }

    private void handleNationList(Player player) {
        var mm = plugin.getMessageManager();
        Collection<Nation> nations = plugin.getNationManager().getAllNations();
        if (nations.isEmpty()) {
            mm.sendMessage(player, "nation.list-empty");
            return;
        }
        mm.sendMessage(player, "nation.list-header");
        for (Nation nation : nations) {
            Clan leaderClan = plugin.getClanManager().getClan(nation.getLeaderClanId());
            String leaderName = leaderClan != null ? leaderClan.getDisplayName() : "???";
            mm.sendMessage(player, "nation.list-entry",
                    "{nation}", nation.getName(),
                    "{count}", String.valueOf(nation.getClanCount()),
                    "{leader}", leaderName);
        }
    }

    private void handleNationChat(Player player) {
        var mm = plugin.getMessageManager();
        Clan clan = requireClan(player);
        if (clan == null) return;
        Nation nation = plugin.getNationManager().getNationByClan(clan.getId());
        if (nation == null) {
            mm.sendMessage(player, "nation.not-in-nation");
            return;
        }
        plugin.getChatManager().toggleNationChat(player.getUniqueId());
        if (plugin.getChatManager().isInNationChat(player.getUniqueId())) {
            mm.sendMessage(player, "nation.chat-enabled");
        } else {
            mm.sendMessage(player, "nation.chat-disabled");
        }
    }

    private void handleNationDesc(Player player, String[] args) {
        var mm = plugin.getMessageManager();
        Clan clan = requireClan(player);
        if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.LEADER)) return;

        Nation nation = plugin.getNationManager().getNationByClan(clan.getId());
        if (nation == null) { mm.sendMessage(player, "nation.not-in-nation"); return; }
        if (!nation.getLeaderClanId().equals(clan.getId())) { mm.sendMessage(player, "nation.desc-no-permission"); return; }

        if (args.length < 3) { mm.sendMessage(player, "nation.desc-usage"); return; }

        String desc = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
        nation.setDescription(desc);
        plugin.getNationManager().saveAsync(nation);
        mm.sendMessage(player, "nation.desc-updated");
    }

    private void showNationHelp(Player player) {
        var mm = plugin.getMessageManager();
        mm.sendMessage(player, "nation.help-header");
        helpLine(mm, player, "/clan nation create <nombre> [tag]", mm.get("nation.help-create-desc"));
        helpLine(mm, player, "/clan nation info [nombre]", mm.get("nation.help-info-desc"));
        helpLine(mm, player, "/clan nation invite <clan>", mm.get("nation.help-invite-desc"));
        helpLine(mm, player, "/clan nation accept", mm.get("nation.help-accept-desc"));
        helpLine(mm, player, "/clan nation deny", mm.get("nation.help-deny-desc"));
        helpLine(mm, player, "/clan nation kick <clan>", mm.get("nation.help-kick-desc"));
        helpLine(mm, player, "/clan nation leave", mm.get("nation.help-leave-desc"));
        helpLine(mm, player, "/clan nation promote <clan>", mm.get("nation.help-promote-desc"));
        helpLine(mm, player, "/clan nation demote <clan>", mm.get("nation.help-demote-desc"));
        helpLine(mm, player, "/clan nation chat", mm.get("nation.help-chat-desc"));
        helpLine(mm, player, "/clan nation list", mm.get("nation.help-list-desc"));
        helpLine(mm, player, "/clan nation desc <texto>", mm.get("nation.help-desc-desc"));
        helpLine(mm, player, "/clan nation disband", mm.get("nation.help-disband-desc"));
    }

    // ══════════════════════════════════════════════════════════
    //  OUTPOST COMMANDS
    // ══════════════════════════════════════════════════════════

    private void handleOutpost(Player player, String[] args) {
        var mm = plugin.getMessageManager();

        if (args.length < 2) {
            showOutpostHelp(player);
            return;
        }

        String sub = args[1].toLowerCase();
        switch (sub) {
            case "place", "colocar" -> handleOutpostPlace(player, args);
            case "remove", "quitar" -> handleOutpostRemove(player);
            case "upgrade", "mejorar" -> handleOutpostUpgrade(player);
            case "list", "lista" -> handleOutpostList(player);
            case "info" -> handleOutpostInfo(player);
            default -> showOutpostHelp(player);
        }
    }

    private void handleOutpostPlace(Player player, String[] args) {
        var mm = plugin.getMessageManager();
        Clan clan = requireClan(player);
        if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.OFFICER)) return;

        if (args.length < 3) {
            mm.sendMessage(player, "outpost.place-usage");
            mm.sendMessage(player, "outpost.place-types");
            return;
        }

        OutpostType type;
        try {
            String typeStr = args[2].toUpperCase().replace("-", "_");
            type = OutpostType.valueOf(typeStr);
        } catch (IllegalArgumentException e) {
            mm.sendMessage(player, "outpost.invalid-type");
            return;
        }

        String error = plugin.getOutpostManager().placeOutpost(player, type);
        if (error != null) {
            if (error.startsWith("insufficient-funds:")) {
                mm.sendMessage(player, "outpost.cannot-afford");
            } else {
                switch (error) {
                    case "not-in-clan" -> mm.sendMessage(player, "clan.not-in-clan");
                    case "not-your-territory" -> mm.sendMessage(player, "outpost.not-in-territory");
                    case "max-outposts-reached" -> mm.sendMessage(player, "outpost.max-outposts");
                    case "max-outposts-in-chunk" -> mm.sendMessage(player, "outpost.max-outposts");
                    case "outpost-already-here" -> mm.sendMessage(player, "outpost.not-found");
                    default -> mm.sendMessage(player, "error.generic", "{error}", error);
                }
            }
        }
        // Success message is sent by OutpostManager itself
    }

    private void handleOutpostRemove(Player player) {
        var mm = plugin.getMessageManager();
        Clan clan = requireClan(player);
        if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.OFFICER)) return;

        String error = plugin.getOutpostManager().removeOutpost(player, player.getLocation().getBlock().getLocation());
        if (error != null) {
            switch (error) {
                case "no-outpost-here" -> mm.sendMessage(player, "outpost.not-found");
                case "not-your-outpost" -> mm.sendMessage(player, "outpost.not-your-outpost");
                default -> mm.sendMessage(player, "error.generic", "{error}", error);
            }
        }
    }

    private void handleOutpostUpgrade(Player player) {
        var mm = plugin.getMessageManager();
        Clan clan = requireClan(player);
        if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.OFFICER)) return;

        String error = plugin.getOutpostManager().upgradeOutpost(player, player.getLocation().getBlock().getLocation());
        if (error != null) {
            if (error.startsWith("insufficient-funds:")) {
                mm.sendMessage(player, "outpost.cannot-afford");
            } else {
                switch (error) {
                    case "no-outpost-here" -> mm.sendMessage(player, "outpost.not-found");
                    case "not-your-outpost" -> mm.sendMessage(player, "outpost.not-your-outpost");
                    case "max-level" -> mm.sendMessage(player, "outpost.max-level");
                    default -> mm.sendMessage(player, "error.generic", "{error}", error);
                }
            }
        }
    }

    private void handleOutpostList(Player player) {
        var mm = plugin.getMessageManager();
        Clan clan = requireClan(player);
        if (clan == null) return;

        List<Outpost> outposts = plugin.getOutpostManager().getClanOutposts(clan.getId());
        if (outposts.isEmpty()) {
            mm.sendMessage(player, "outpost.list-empty");
            return;
        }

        mm.sendMessage(player, "outpost.list-header",
                "{count}", String.valueOf(outposts.size()),
                "{max}", "");
        for (Outpost o : outposts) {
            double hpPct = o.getHealthPercent() * 100;
            String hpColor = hpPct > 50 ? "<green>" : hpPct > 25 ? "<yellow>" : "<red>";
            String loc = o.getLocation() != null
                    ? "(" + o.getLocation().getBlockX() + ", " + o.getLocation().getBlockY() + ", " + o.getLocation().getBlockZ() + ")"
                    : "(?)";
            mm.sendMessage(player, "outpost.list-entry",
                    "{type}", o.getType().getPrefix(),
                    "{level}", String.valueOf(o.getLevel()),
                    "{health}", hpColor + String.format("%.0f%%", hpPct),
                    "{location}", loc);
        }
    }

    private void handleOutpostInfo(Player player) {
        var mm = plugin.getMessageManager();
        Outpost outpost = plugin.getOutpostManager().getOutpostAt(player.getLocation().getBlock().getLocation());
        if (outpost == null) {
            mm.sendMessage(player, "outpost.no-outpost-here");
            return;
        }

        mm.sendMessage(player, "outpost.info-header");
        mm.sendMessage(player, "outpost.info-type", "{type}", outpost.getType().getDisplayName());
        mm.sendMessage(player, "outpost.info-level", "{level}", outpost.getLevel() + "/" + outpost.getType().getMaxLevel());
        mm.sendMessage(player, "outpost.info-health",
                "{hp}", String.valueOf(outpost.getHealth()),
                "{max_hp}", String.valueOf(outpost.getMaxHealth()));
        if (outpost.canUpgrade()) {
            double upgradeCost = outpost.getType().getUpgradeCost(outpost.getLevel());
            mm.sendMessage(player, "outpost.info-upgrade-cost", "{cost}", String.format("%.0f", upgradeCost));
        } else {
            mm.sendMessage(player, "outpost.info-max-level");
        }
        mm.sendMessage(player, "outpost.info-description", "{description}", outpost.getType().getDescription());
    }

    private void showOutpostHelp(Player player) {
        var mm = plugin.getMessageManager();
        mm.sendMessage(player, "outpost.help-header");
        helpLine(mm, player, "/clan outpost place <tipo>", mm.get("outpost.help-place-desc"));
        helpLine(mm, player, "/clan outpost remove", mm.get("outpost.help-remove-desc"));
        helpLine(mm, player, "/clan outpost upgrade", mm.get("outpost.help-upgrade-desc"));
        helpLine(mm, player, "/clan outpost list", mm.get("outpost.help-list-desc"));
        helpLine(mm, player, "/clan outpost info", mm.get("outpost.help-info-desc"));
        mm.sendMessage(player, "outpost.help-types");
    }

    // ══════════════════════════════════════════════════════════
    //  SPY COMMANDS
    // ══════════════════════════════════════════════════════════

    private void handleSpy(Player player, String[] args) {
        var mm = plugin.getMessageManager();

        if (args.length < 2) {
            showSpyHelp(player);
            return;
        }

        String sub = args[1].toLowerCase();
        switch (sub) {
            case "socialspy" -> handleSpySocialSpy(player);
            case "infiltrate", "infiltrar" -> handleSpyInfiltrate(player, args);
            case "stop", "parar" -> handleSpyStop(player);
            case "intel", "informe" -> handleSpyIntel(player, args);
            default -> showSpyHelp(player);
        }
    }

    private void handleSpySocialSpy(Player player) {
        var mm = plugin.getMessageManager();
        if (!player.hasPermission("ethernova.spy.socialspy")) {
            mm.sendMessage(player, "spy.no-permission");
            return;
        }

        boolean enabled = plugin.getSpyManager().toggleSocialSpy(player.getUniqueId());
        if (enabled) {
            mm.sendMessage(player, "spy.socialspy-on");
        } else {
            mm.sendMessage(player, "spy.socialspy-off");
        }
    }

    private void handleSpyInfiltrate(Player player, String[] args) {
        var mm = plugin.getMessageManager();
        if (!player.hasPermission("ethernova.spy.infiltrate")) {
            mm.sendMessage(player, "spy.no-permission");
            return;
        }

        if (args.length < 3) {
            mm.sendMessage(player, "spy.infiltrate-usage");
            return;
        }

        Clan targetClan = plugin.getClanManager().getClanByName(args[2]);
        if (targetClan == null) {
            mm.sendMessage(player, "spy.clan-not-found", "{clan}", args[2]);
            return;
        }

        String error = plugin.getSpyManager().startInfiltration(player, targetClan);
        if (error != null) {
            if (error.startsWith("infiltration-cooldown:")) {
                mm.sendMessage(player, "spy.infiltrate-cooldown", "{time}", error.split(":")[1]);
            } else if (error.startsWith("insufficient-funds:")) {
                mm.sendMessage(player, "spy.infiltrate-insufficient-funds", "{cost}", error.split(":")[1]);
            } else {
                switch (error) {
                    case "already-infiltrating" -> mm.sendMessage(player, "spy.already-infiltrating");
                    case "cannot-spy-own-clan" -> mm.sendMessage(player, "spy.cannot-spy-own");
                    default -> mm.sendMessage(player, "error.generic", "{error}", error);
                }
            }
        }
    }

    private void handleSpyStop(Player player) {
        var mm = plugin.getMessageManager();
        if (!plugin.getSpyManager().isInfiltrating(player.getUniqueId())) {
            mm.sendMessage(player, "spy.not-infiltrating");
            return;
        }
        plugin.getSpyManager().stopInfiltration(player.getUniqueId());
    }

    private void handleSpyIntel(Player player, String[] args) {
        var mm = plugin.getMessageManager();
        if (!player.hasPermission("ethernova.spy.intel")) {
            mm.sendMessage(player, "spy.intel-no-permission");
            return;
        }

        if (args.length < 3) {
            mm.sendMessage(player, "spy.intel-usage");
            return;
        }

        Clan targetClan = plugin.getClanManager().getClanByName(args[2]);
        if (targetClan == null) {
            mm.sendMessage(player, "spy.clan-not-found", "{clan}", args[2]);
            return;
        }

        String error = plugin.getSpyManager().generateIntelReport(player, targetClan);
        if (error != null) {
            if (error.startsWith("intel-cooldown:")) {
                mm.sendMessage(player, "spy.infiltrate-cooldown", "{time}", error.split(":")[1]);
            }
        }
    }

    private void showSpyHelp(Player player) {
        var mm = plugin.getMessageManager();
        mm.sendMessage(player, "spy.help-header");
        helpLine(mm, player, "/clan spy socialspy", mm.get("spy.help-socialspy-desc"));
        helpLine(mm, player, "/clan spy infiltrate <clan>", mm.get("spy.help-infiltrate-desc"));
        helpLine(mm, player, "/clan spy stop", mm.get("spy.help-stop-desc"));
        helpLine(mm, player, "/clan spy intel <clan>", mm.get("spy.help-intel-desc"));
    }

    // ══════════════════════════════════════════════════════════
    //  UTILITY METHODS
    // ══════════════════════════════════════════════════════════

    private Clan requireClan(Player player) {
        Clan clan = plugin.getClanManager().getClanByPlayer(player.getUniqueId());
        if (clan == null) {
            plugin.getMessageManager().sendMessage(player, "clan.not-in-clan");
        }
        return clan;
    }

    private boolean requireRole(Player player, Clan clan, ClanRole minRole) {
        ClanMember member = clan.getMember(player.getUniqueId());
        if (member == null || !member.getRole().isAtLeast(minRole)) {
            plugin.getMessageManager().sendMessage(player, "general.no-permission");
            return false;
        }
        return true;
    }

    private int getClanKills(Clan clan) {
        return clan.getTotalKills();
    }

    // ══════════════════════════════════════════════════════════
    //  DIPLOMACY COMMANDS
    // ══════════════════════════════════════════════════════════

    private void handleDiplomacy(Player player, String[] args) {
        var mm = plugin.getMessageManager();
        var dm = plugin.getDiplomacyManager();

        if (args.length < 2) {
            Clan clan = requireClan(player);
            if (clan == null) return;
            plugin.getGuiManager().openDiplomacy(player);
            return;
        }

        String sub = args[1].toLowerCase();
        switch (sub) {
            case "propose", "proponer" -> {
                Clan clan = requireClan(player);
                if (clan == null) return;
                if (!requireRole(player, clan, ClanRole.OFFICER)) return;
                if (args.length < 4) { mm.sendMessage(player, "diplomacy.usage"); return; }
                Clan target = plugin.getClanManager().getClanByName(args[2]);
                if (target == null) { mm.sendMessage(player, "general.clan-not-found"); return; }
                try {
                    var type = DiplomacyManager.TreatyType.valueOf(args[3].toUpperCase());
                    String error = dm.proposeTreaty(clan, target, type);
                    if (error == null) mm.sendMessage(player, "diplomacy.operation-success");
                    else mm.sendRaw(player, mm.get("general.unknown-command"));
                } catch (IllegalArgumentException e) { mm.sendMessage(player, "diplomacy.invalid-type"); }
            }
            case "accept", "aceptar" -> {
                Clan clan = requireClan(player);
                if (clan == null) return;
                if (!requireRole(player, clan, ClanRole.OFFICER)) return;
                if (args.length < 3) { mm.sendMessage(player, "diplomacy.usage"); return; }
                Clan proposer = plugin.getClanManager().getClanByName(args[2]);
                if (proposer == null) { mm.sendMessage(player, "general.clan-not-found"); return; }
                var pending = dm.getPendingProposals(clan.getId());
                var match = pending.stream()
                        .filter(t -> t.clanIdA().equals(proposer.getId()) || t.clanIdB().equals(proposer.getId()))
                        .findFirst();
                if (match.isPresent()) {
                    dm.acceptTreaty(clan, proposer, match.get().type());
                    mm.sendMessage(player, "diplomacy.operation-success");
                } else { mm.sendMessage(player, "diplomacy.no-treaties"); }
            }
            case "reject", "rechazar" -> {
                Clan clan = requireClan(player);
                if (clan == null) return;
                if (args.length < 3) { mm.sendMessage(player, "diplomacy.usage"); return; }
                Clan proposer = plugin.getClanManager().getClanByName(args[2]);
                if (proposer == null) { mm.sendMessage(player, "general.clan-not-found"); return; }
                var pending = dm.getPendingProposals(clan.getId());
                var match = pending.stream()
                        .filter(t -> t.clanIdA().equals(proposer.getId()) || t.clanIdB().equals(proposer.getId()))
                        .findFirst();
                if (match.isPresent()) {
                    dm.rejectTreaty(clan, proposer, match.get().type());
                    mm.sendMessage(player, "diplomacy.operation-success");
                } else { mm.sendMessage(player, "diplomacy.no-treaties"); }
            }
            case "break", "romper" -> {
                Clan clan = requireClan(player);
                if (clan == null) return;
                if (!requireRole(player, clan, ClanRole.LEADER)) return;
                if (args.length < 3) { mm.sendMessage(player, "diplomacy.usage"); return; }
                Clan other = plugin.getClanManager().getClanByName(args[2]);
                if (other == null) { mm.sendMessage(player, "general.clan-not-found"); return; }
                var treaties = dm.getTreaties(clan.getId());
                var active = treaties.stream()
                        .filter(t -> (t.clanIdA().equals(other.getId()) || t.clanIdB().equals(other.getId())) && t.isActive())
                        .findFirst();
                if (active.isPresent()) {
                    dm.breakTreaty(clan, other.getId(), active.get().type());
                    mm.sendMessage(player, "diplomacy.operation-success");
                } else { mm.sendMessage(player, "diplomacy.no-treaties"); }
            }
            case "list", "lista" -> {
                Clan clan = requireClan(player);
                if (clan == null) return;
                var treaties = dm.getTreaties(clan.getId());
                var active = treaties.stream().filter(DiplomacyManager.Treaty::isActive).toList();
                if (active.isEmpty()) { mm.sendMessage(player, "diplomacy.no-treaties"); return; }
                mm.sendMessage(player, "diplomacy.treaty-list-header");
                for (var treaty : active) {
                    String otherClanId = treaty.clanIdA().equals(clan.getId()) ? treaty.clanIdB() : treaty.clanIdA();
                    Clan other = plugin.getClanManager().getClan(otherClanId);
                    String clanName = other != null ? other.getName() : otherClanId;
                    mm.sendMessage(player, "diplomacy.treaty-entry",
                            "{icon}", treaty.type().icon, "{clan}", clanName,
                            "{type}", treaty.type().displayName, "{duration}", treaty.getRemainingFormatted());
                }
            }
            default -> showDiplomacyHelp(player);
        }
    }

    private void showDiplomacyHelp(Player player) {
        var mm = plugin.getMessageManager();
        mm.sendMessage(player, "diplomacy.help-header");
        mm.sendMessage(player, "diplomacy.help-propose");
        mm.sendMessage(player, "diplomacy.help-accept");
        mm.sendMessage(player, "diplomacy.help-reject");
        mm.sendMessage(player, "diplomacy.help-break");
        mm.sendMessage(player, "diplomacy.help-list");
        mm.sendMessage(player, "diplomacy.help-types");
    }

    // ══════════════════════════════════════════════════════════
    //  SALARY COMMANDS
    // ══════════════════════════════════════════════════════════

    private void handleSalary(Player player, String[] args) {
        var mm = plugin.getMessageManager();
        var sm = plugin.getSalaryManager();
        Clan clan = requireClan(player);
        if (clan == null) return;

        if (args.length < 2 || args[1].equalsIgnoreCase("info") || args[1].equalsIgnoreCase("ver")) {
            var salaries = sm.getSalaryConfig(clan.getId());
            mm.sendMessage(player, "salary.help-header");
            if (salaries.isEmpty() || salaries.values().stream().allMatch(v -> v == 0)) {
                mm.sendMessage(player, "salary.no-config");
            } else {
                for (var entry : salaries.entrySet()) {
                    mm.sendMessage(player, "salary.entry", "{role}", entry.getKey(), "{amount}", String.format("%.0f", entry.getValue()));
                }
                mm.sendMessage(player, "salary.total-cost", "{total}", String.format("%.0f", sm.getTotalSalaryCost(clan)));
            }
            return;
        }

        String sub = args[1].toLowerCase();
        if (sub.equals("set") || sub.equals("configurar")) {
            if (!requireRole(player, clan, ClanRole.LEADER)) return;
            if (args.length < 4) { mm.sendMessage(player, "salary.usage-set"); return; }
            try {
                ClanRole role = ClanRole.valueOf(args[2].toUpperCase());
                double amount = Double.parseDouble(args[3]);
                if (amount < 0) { mm.sendMessage(player, "salary.invalid-amount"); return; }
                sm.setSalary(clan.getId(), role, amount);
                mm.sendMessage(player, "salary.set-success", "{role}", role.name().toLowerCase(), "{amount}", String.format("%.0f", amount));
            } catch (IllegalArgumentException e) { mm.sendMessage(player, "salary.invalid-rank"); }
        } else {
            mm.sendMessage(player, "salary.help-header");
            mm.sendMessage(player, "salary.help-set");
            mm.sendMessage(player, "salary.help-ranks");
        }
    }

    // ══════════════════════════════════════════════════════════
    //  SKILLS / SHOP / STATS / BANNER / SEASON / SIEGE
    // ══════════════════════════════════════════════════════════

    private void handleSkills(Player player) {
        Clan clan = requireClan(player);
        if (clan == null) return;
        plugin.getGuiManager().openClanSkills(player);
    }

    private void handleShop(Player player) {
        Clan clan = requireClan(player);
        if (clan == null) return;
        plugin.getGuiManager().openClanShop(player);
    }

    private void handleStats(Player player, String[] args) {
        var mm = plugin.getMessageManager();
        if (args.length >= 2) {
            Clan clan = plugin.getClanManager().getClanByName(args[1]);
            if (clan == null) { mm.sendMessage(player, "general.clan-not-found"); return; }
        } else {
            Clan clan = requireClan(player);
            if (clan == null) return;
        }
        plugin.getGuiManager().openStats(player);
    }

    private void handleBanner(Player player, String[] args) {
        var mm = plugin.getMessageManager();
        Clan clan = requireClan(player);
        if (clan == null) return;
        if (args.length < 2) { plugin.getBannerManager().giveBanner(player, clan); return; }
        String sub = args[1].toLowerCase();
        switch (sub) {
            case "set", "establecer" -> {
                if (!requireRole(player, clan, ClanRole.OFFICER)) return;
                boolean success = plugin.getBannerManager().setBannerFromHand(player, clan);
                if (success) mm.sendMessage(player, "banner.set-success");
                else mm.sendMessage(player, "banner.must-hold-banner");
            }
            case "get", "obtener" -> {
                plugin.getBannerManager().giveBanner(player, clan);
                mm.sendMessage(player, "banner.received");
            }
            default -> {
                mm.sendMessage(player, "banner.help-header");
                mm.sendMessage(player, "banner.help-set");
                mm.sendMessage(player, "banner.help-get");
                mm.sendMessage(player, "banner.usage");
            }
        }
    }

    private void handleSeason(Player player) {
        var mm = plugin.getMessageManager();
        if (!plugin.getSeasonManager().isEnabled()) { mm.sendMessage(player, "season.disabled"); return; }
        plugin.getGuiManager().openSeasons(player);
    }

    private void handleSiege(Player player, String[] args) {
        var mm = plugin.getMessageManager();
        Clan clan = requireClan(player);
        if (clan == null) return;
        var sieges = plugin.getSiegeManager().getSiegesByClan(clan.getId());
        if (sieges.isEmpty()) {
            mm.sendMessage(player, "siege.no-active");
            return;
        }
        for (var siege : sieges) {
            String otherClanId = siege.attackerClanId().equals(clan.getId()) ? siege.defenderClanId() : siege.attackerClanId();
            Clan other = plugin.getClanManager().getClan(otherClanId);
            String otherName = other != null ? other.getName() : "?";
            String role = siege.attackerClanId().equals(clan.getId()) ? "⚔ Atacante" : "🛡 Defensor";
            mm.sendMessage(player, "siege.active-entry",
                    "{clan}", otherName, "{role}", role,
                    "{progress}", String.format("%.0f%%", siege.getProgress()),
                    "{time}", String.valueOf(siege.getRemainingSeconds()));
        }
    }

    private void handleSettings(Player player) {
        Clan clan = requireClan(player);
        if (clan == null) return;
        if (!requireRole(player, clan, ClanRole.OFFICER)) return;
        plugin.getGuiManager().openSettings(player);
    }

    private void handleBorders(Player player) {
        var mm = plugin.getMessageManager();
        Clan clan = requireClan(player);
        if (clan == null) return;
        plugin.getChunkVisualizer().toggle(player);
        if (plugin.getChunkVisualizer().isViewing(player))
            mm.sendMessage(player, "territory.borders-on");
        else
            mm.sendMessage(player, "territory.borders-off");
    }

    private void handleMissions(Player player) {
        Clan clan = requireClan(player);
        if (clan == null) return;
        // Ensure missions are assigned (idempotent — won't duplicate if already active)
        if (plugin.getMissionManager() != null) {
            plugin.getMissionManager().assignDailyMissions(clan);
        }
        plugin.getGuiManager().openMissions(player);
    }

    private void handleAchievements(Player player) {
        Clan clan = requireClan(player);
        if (clan == null) return;
        plugin.getGuiManager().openAchievements(player);
    }

    // ══════════════════════════════════════════════════════════
    //  HELP
    // ══════════════════════════════════════════════════════════

    private void showHelp(Player player) {
        var mm = plugin.getMessageManager();
        boolean practice = plugin.getClanModeManager().isPracticeMode();
        mm.sendMessage(player, "clan.help-header");
        mm.sendMessage(player, "clan.help-create");
        mm.sendMessage(player, "clan.help-info");
        mm.sendMessage(player, "clan.help-invite");
        mm.sendMessage(player, "clan.help-join");
        mm.sendMessage(player, "clan.help-leave");
        mm.sendMessage(player, "clan.help-chat");
        mm.sendMessage(player, "clan.help-allychat");
        if (!practice) {
            mm.sendMessage(player, "clan.help-claim");
            mm.sendMessage(player, "clan.help-autoclaim");
            mm.sendMessage(player, "clan.help-map");
            mm.sendMessage(player, "clan.help-home");
            mm.sendMessage(player, "clan.help-war");
        }
        mm.sendMessage(player, "clan.help-ally");
        mm.sendMessage(player, "clan.help-top");
        mm.sendMessage(player, "clan.help-transfer");
        mm.sendMessage(player, "clan.help-desc");
        if (!practice) {
            mm.sendMessage(player, "clan.help-bank");
        }
        mm.sendMessage(player, "clan.help-level");
        if (!practice) {
            mm.sendMessage(player, "clan.help-flags");
        }
        mm.sendMessage(player, "clan.help-log");
        mm.sendMessage(player, "clan.help-ban");
        mm.sendMessage(player, "clan.help-unban");
        mm.sendMessage(player, "clan.help-menu");
        if (!practice) {
            mm.sendMessage(player, "clan.help-setwarp");
            mm.sendMessage(player, "clan.help-warp");
            mm.sendMessage(player, "clan.help-warps");
            mm.sendMessage(player, "clan.help-delwarp");
            mm.sendMessage(player, "clan.help-advanced-header");
            mm.sendMessage(player, "clan.help-fly");
            mm.sendMessage(player, "clan.help-nation");
            mm.sendMessage(player, "clan.help-outpost");
            mm.sendMessage(player, "clan.help-spy");
            mm.sendMessage(player, "clan.help-diplomacy");
            mm.sendMessage(player, "clan.help-salary");
            mm.sendMessage(player, "clan.help-skills");
        } else {
            mm.sendMessage(player, "clan.help-advanced-header");
        }
        mm.sendMessage(player, "clan.help-shop");
        mm.sendMessage(player, "clan.help-stats");
        mm.sendMessage(player, "clan.help-banner");
        mm.sendMessage(player, "clan.help-season");
        mm.sendMessage(player, "clan.help-settings");
        if (!practice) {
            mm.sendMessage(player, "clan.help-borders");
        }
        mm.sendMessage(player, "clan.help-missions");
        mm.sendMessage(player, "clan.help-achievements");
        mm.sendMessage(player, "clan.help-footer");
    }

    private void helpLine(com.ethernova.clans.message.MessageManager mm, Player player, String cmd, String desc) {
        String baseCmd = cmd.split(" ")[0] + " " + cmd.split(" ")[1];
        mm.sendRaw(player, "<click:suggest_command:" + baseCmd + " ><hover:show_text:'<gray>Click para usar</gray>'><yellow>" + cmd + "</yellow></hover></click> <dark_gray>—</dark_gray> <gray>" + desc + "</gray>");
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command cmd,
                                                @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) {
            var modeManager = plugin.getClanModeManager();
            List<String> subs = Arrays.asList(
                    "create", "crear", "disband", "disolver", "invite", "invitar",
                    "join", "unir", "leave", "salir", "kick", "expulsar",
                    "promote", "ascender", "demote", "degradar",
                    "info", "list", "lista", "chat", "allychat", "officerchat",
                    "ally", "aliado", "enemy", "enemigo",
                    "claim", "reclamar", "unclaim", "abandonar", "autoclaim",
                    "map", "mapa", "home", "base", "sethome", "setbase",
                    "war", "guerra", "upgrade", "mejorar", "top", "ranking",
                    "transfer", "transferir", "desc", "descripcion",
                    "ban", "banear", "unban", "desbanear",
                    "bank", "banco", "level", "nivel",
                    "flags", "permisos", "log", "registro",
                    "confirm", "confirmar",
                    "setwarp", "warp", "warps", "delwarp", "menu", "gui",
                    "help", "ayuda",
                    "nation", "nacion", "outpost", "puesto", "spy", "espiar",
                    "diplomacy", "diplomacia", "salary", "salario",
                    "skills", "habilidades", "shop", "tienda",
                    "stats", "estadisticas", "banner", "estandarte",
                    "season", "temporada", "siege", "asedio",
                    "settings", "ajustes", "borders", "bordes",
                    "missions", "misiones", "achievements", "logros"
            );
            return subs.stream()
                    .filter(s -> modeManager.isCommandAllowed(s))
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .collect(Collectors.toList());
        }
        if (args.length == 2) {
            String sub = args[0].toLowerCase();
            switch (sub) {
                case "invite", "invitar" -> {
                    return null; // player names
                }
                case "kick", "expulsar" -> {
                    return null; // player names
                }
                case "promote", "ascender" -> {
                    return null; // player names
                }
                case "demote", "degradar" -> {
                    return null; // player names
                }
                case "transfer", "transferir" -> {
                    return null; // player names
                }
                case "ban", "banear" -> {
                    return null; // player names
                }
                case "unban", "desbanear" -> {
                    return null; // player names
                }
                case "flags", "permisos" -> {
                    return Arrays.stream(com.ethernova.clans.territory.TerritoryFlag.values())
                            .map(f -> f.name().toLowerCase())
                            .filter(s -> s.startsWith(args[1].toLowerCase()))
                            .collect(Collectors.toList());
                }
                case "bank", "banco" -> {
                    return Arrays.asList("deposit", "withdraw", "balance").stream()
                            .filter(s -> s.startsWith(args[1].toLowerCase())).collect(Collectors.toList());
                }
                case "top", "ranking" -> {
                    return Arrays.asList("power", "members", "kills", "territory", "level", "bank").stream()
                            .filter(s -> s.startsWith(args[1].toLowerCase())).collect(Collectors.toList());
                }
                case "setwarp", "warp", "delwarp", "warps" -> {
                    Clan clan = plugin.getClanManager().getClanByPlayer(((Player) sender).getUniqueId());
                    if (clan != null) {
                        return clan.getWarps().keySet().stream()
                                .filter(s -> s.startsWith(args[1].toLowerCase()))
                                .collect(Collectors.toList());
                    }
                    return null;
                }
                case "nation", "nacion" -> {
                    return Arrays.asList("create", "disband", "invite", "accept", "deny", "kick", "leave",
                                    "promote", "demote", "info", "list", "chat", "desc").stream()
                            .filter(s -> s.startsWith(args[1].toLowerCase())).collect(Collectors.toList());
                }
                case "outpost", "puesto" -> {
                    return Arrays.asList("place", "remove", "upgrade", "list", "info").stream()
                            .filter(s -> s.startsWith(args[1].toLowerCase())).collect(Collectors.toList());
                }
                case "spy", "espiar" -> {
                    return Arrays.asList("socialspy", "infiltrate", "stop", "intel").stream()
                            .filter(s -> s.startsWith(args[1].toLowerCase())).collect(Collectors.toList());
                }
                case "ally", "aliado" -> {
                    return Arrays.asList("request", "accept", "deny", "break").stream()
                            .filter(s -> s.startsWith(args[1].toLowerCase())).collect(Collectors.toList());
                }
                case "war", "guerra" -> {
                    return Arrays.asList("declare", "accept", "surrender", "status", "history").stream()
                            .filter(s -> s.startsWith(args[1].toLowerCase())).collect(Collectors.toList());
                }
                case "upgrade", "mejorar" -> {
                    return Arrays.asList("member-slots", "power-bonus", "bank-limit", "territory-limit", "warp-slots").stream()
                            .filter(s -> s.startsWith(args[1].toLowerCase())).collect(Collectors.toList());
                }
                case "diplomacy", "diplomacia" -> {
                    return Arrays.asList("propose", "accept", "reject", "break", "list").stream()
                            .filter(s -> s.startsWith(args[1].toLowerCase())).collect(Collectors.toList());
                }
                case "salary", "salario" -> {
                    return Arrays.asList("set", "info").stream()
                            .filter(s -> s.startsWith(args[1].toLowerCase())).collect(Collectors.toList());
                }
                case "banner", "estandarte" -> {
                    return Arrays.asList("set", "get").stream()
                            .filter(s -> s.startsWith(args[1].toLowerCase())).collect(Collectors.toList());
                }
                case "info", "stats", "estadisticas" -> {
                    return plugin.getClanManager().getAllClans().stream()
                            .map(Clan::getName)
                            .filter(s -> s.toLowerCase().startsWith(args[1].toLowerCase()))
                            .collect(Collectors.toList());
                }
            }
        }
        if (args.length == 3) {
            String sub = args[0].toLowerCase();
            String sub2 = args[1].toLowerCase();
            // Nation sub-sub-completions
            if (sub.equals("nation") || sub.equals("nacion")) {
                switch (sub2) {
                    case "invite", "invitar", "kick", "expulsar", "promote", "ascender", "demote", "degradar", "info" -> {
                        // clan names
                        return plugin.getClanManager().getAllClans().stream()
                                .map(Clan::getName)
                                .filter(s -> s.toLowerCase().startsWith(args[2].toLowerCase()))
                                .collect(Collectors.toList());
                    }
                }
            }
            // Outpost sub-sub-completions
            if (sub.equals("outpost") || sub.equals("puesto")) {
                if (sub2.equals("place") || sub2.equals("colocar")) {
                    return Arrays.stream(OutpostType.values())
                            .map(t -> t.name().toLowerCase())
                            .filter(s -> s.startsWith(args[2].toLowerCase()))
                            .collect(Collectors.toList());
                }
            }
            // Spy sub-sub-completions
            if (sub.equals("spy") || sub.equals("espiar")) {
                if (sub2.equals("infiltrate") || sub2.equals("infiltrar") || sub2.equals("intel") || sub2.equals("informe")) {
                    // clan names
                    return plugin.getClanManager().getAllClans().stream()
                            .map(Clan::getName)
                            .filter(s -> s.toLowerCase().startsWith(args[2].toLowerCase()))
                            .collect(Collectors.toList());
                }
            }
            // Diplomacy sub-sub-completions
            if (sub.equals("diplomacy") || sub.equals("diplomacia")) {
                if (sub2.equals("propose") || sub2.equals("proponer") || sub2.equals("accept") || sub2.equals("aceptar")
                        || sub2.equals("reject") || sub2.equals("rechazar") || sub2.equals("break") || sub2.equals("romper")) {
                    return plugin.getClanManager().getAllClans().stream()
                            .map(Clan::getName)
                            .filter(s -> s.toLowerCase().startsWith(args[2].toLowerCase()))
                            .collect(Collectors.toList());
                }
            }
            // Ally sub-sub-completions
            if (sub.equals("ally") || sub.equals("aliado")) {
                return plugin.getClanManager().getAllClans().stream()
                        .map(Clan::getName)
                        .filter(s -> s.toLowerCase().startsWith(args[2].toLowerCase()))
                        .collect(Collectors.toList());
            }
            // War sub-sub-completions
            if (sub.equals("war") || sub.equals("guerra")) {
                if (sub2.equals("declare")) {
                    return plugin.getClanManager().getAllClans().stream()
                            .map(Clan::getName)
                            .filter(s -> s.toLowerCase().startsWith(args[2].toLowerCase()))
                            .collect(Collectors.toList());
                }
            }
            // Salary sub-sub-completions
            if (sub.equals("salary") || sub.equals("salario")) {
                if (sub2.equals("set") || sub2.equals("configurar")) {
                    return Arrays.asList("member", "officer", "co_leader").stream()
                            .filter(s -> s.startsWith(args[2].toLowerCase()))
                            .collect(Collectors.toList());
                }
            }
        }
        // Depth 4: diplomacy propose <clan> <type>
        if (args.length == 4) {
            String sub = args[0].toLowerCase();
            if (sub.equals("diplomacy") || sub.equals("diplomacia")) {
                String sub2 = args[1].toLowerCase();
                if (sub2.equals("propose") || sub2.equals("proponer")) {
                    return Arrays.asList("non_aggression", "trade_agreement", "mutual_defense", "embargo").stream()
                            .filter(s -> s.startsWith(args[3].toLowerCase()))
                            .collect(Collectors.toList());
                }
            }
        }
        return List.of();
    }
}
