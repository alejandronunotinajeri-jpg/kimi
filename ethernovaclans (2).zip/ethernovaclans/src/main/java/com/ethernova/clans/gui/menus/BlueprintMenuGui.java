package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.blueprint.Blueprint;
import com.ethernova.clans.blueprint.BlueprintManager;
import com.ethernova.clans.blueprint.ClanBlueprint;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.*;

/**
 * GUI for viewing and managing clan blueprints.
 */
public class BlueprintMenuGui extends AbstractGui {

    private static final int[] STRUCTURE_SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};

    public BlueprintMenuGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "blueprints");
    }

    @Override
    protected void populateItems() {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return;

        BlueprintManager bm = plugin.getBlueprintManager();
        if (bm == null || !bm.isEnabled()) return;

        List<ClanBlueprint> builtList = bm.getBlueprints(clan.getId());
        int maxSlots = bm.getMaxSlots(clan.getLevel());

        // Info header
        setItem(4, new ItemBuilder(Material.ANVIL)
                .name("<gradient:#FFD700:#FF6B35>🏗 Estructuras del Clan</gradient>")
                .lore(List.of(
                        "",
                        "<gray>Construidas: <white>" + builtList.size() + "/" + maxSlots,
                        "<gray>Nivel del clan: <white>" + clan.getLevel(),
                        "",
                        "<gray>Las estructuras dan buffs",
                        "<gray>pasivos a tu clan y se destruyen",
                        "<gray>si pierdes el chunk en un asedio."
                ))
                .build());

        // Place each blueprint type
        int idx = 0;
        for (Blueprint bp : bm.getBlueprintTypes().values()) {
            if (idx >= STRUCTURE_SLOTS.length) break;
            int slot = STRUCTURE_SLOTS[idx++];

            ClanBlueprint built = builtList.stream()
                    .filter(b -> b.getBlueprintId().equals(bp.getId()))
                    .findFirst().orElse(null);

            List<String> lore = new ArrayList<>();
            if (built != null) {
                Blueprint.BlueprintLevel currentLev = bp.getLevel(built.getLevel());
                lore.add("<green>✔ Construida - Nivel " + built.getLevel() + "/" + bp.getMaxLevel());
                lore.add("");
                if (currentLev != null) {
                    lore.add("<gold>Efectos actuales:");
                    for (var entry : currentLev.getEffects().entrySet()) {
                        lore.add("  <gray>• " + formatEffect(entry.getKey()) + ": <white>" + formatValue(entry.getValue()));
                    }
                }
                if (built.getLevel() < bp.getMaxLevel()) {
                    Blueprint.BlueprintLevel nextLev = bp.getLevel(built.getLevel() + 1);
                    if (nextLev != null) {
                        lore.add("");
                        lore.add("<yellow>⬆ Siguiente Nivel:");
                        lore.add("  <gray>Costo: <white>$" + String.format("%.0f", nextLev.getCost()));
                        for (var mat : nextLev.getMaterials().entrySet()) {
                            lore.add("  <gray>" + mat.getValue() + "x " + mat.getKey().name());
                        }
                        lore.add("");
                        lore.add("<green>Click izquierdo: Mejorar");
                    }
                } else {
                    lore.add("");
                    lore.add("<gold>¡Nivel máximo alcanzado!");
                }
                lore.add("<red>Click derecho: Demoler (devuelve 50%)");

                setItem(slot, new ItemBuilder(bp.getIcon())
                        .name("<gold>" + bp.getName() + " <gray>[Nv." + built.getLevel() + "]")
                        .lore(lore)
                        .glow()
                        .build());
            } else {
                Blueprint.BlueprintLevel lev1 = bp.getLevel(1);
                lore.add("<gray>No construida");
                lore.add("");
                if (lev1 != null) {
                    lore.add("<yellow>Efectos Nivel 1:");
                    for (var entry : lev1.getEffects().entrySet()) {
                        lore.add("  <gray>• " + formatEffect(entry.getKey()) + ": <white>" + formatValue(entry.getValue()));
                    }
                    lore.add("");
                    lore.add("<gray>Costo: <white>$" + String.format("%.0f", lev1.getCost()));
                    for (var mat : lev1.getMaterials().entrySet()) {
                        lore.add("  <gray>" + mat.getValue() + "x " + mat.getKey().name());
                    }
                }
                lore.add("");
                lore.add("<green>Click para construir");

                setItem(slot, new ItemBuilder(bp.getIcon())
                        .name("<gray>" + bp.getName())
                        .lore(lore)
                        .build());
            }
        }

        // Back button
        setItem(49, new ItemBuilder(Material.ARROW)
                .name("<gray>◀ Volver al menú")
                .build());
        slotActions.put(49, "OPEN_GUI:main-menu");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        return false;
    }

    @Override
    protected void onClick(int slot, InventoryClickEvent event) {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return;

        BlueprintManager bm = plugin.getBlueprintManager();
        if (bm == null) return;

        int idx = -1;
        for (int i = 0; i < STRUCTURE_SLOTS.length; i++) {
            if (STRUCTURE_SLOTS[i] == slot) { idx = i; break; }
        }
        if (idx < 0) return;

        List<Blueprint> types = new ArrayList<>(bm.getBlueprintTypes().values());
        if (idx >= types.size()) return;

        Blueprint bp = types.get(idx);
        List<ClanBlueprint> builtList = bm.getBlueprints(clan.getId());
        ClanBlueprint built = builtList.stream()
                .filter(b -> b.getBlueprintId().equals(bp.getId()))
                .findFirst().orElse(null);

        String chunkId = player.getLocation().getChunk().getWorld().getName()
                + ":" + player.getLocation().getChunk().getX()
                + ":" + player.getLocation().getChunk().getZ();

        player.closeInventory();

        if (built != null) {
            if (event.isLeftClick() && built.getLevel() < bp.getMaxLevel()) {
                bm.upgrade(clan, bp.getId(), player);
            } else if (event.isRightClick()) {
                bm.demolish(clan, bp.getId(), player);
            }
        } else {
            bm.build(clan, bp.getId(), chunkId, player);
        }
    }

    private String formatEffect(String key) {
        return switch (key) {
            case "max-members-bonus" -> "Miembros extra";
            case "passive-income" -> "Ingreso pasivo/h";
            case "watchtower-radius" -> "Radio alerta (chunks)";
            case "slowness-level" -> "Slowness enemigos";
            case "mining-fatigue-level" -> "Mining Fatigue enemigos";
            case "tax-reduction" -> "Reducción impuestos";
            case "regen-level" -> "Regeneración";
            case "strength-level" -> "Fuerza en territorio";
            case "resistance-level" -> "Resistencia en territorio";
            case "max-power-bonus" -> "Power máximo extra";
            case "death-power-reduction" -> "Reducción pérdida poder";
            default -> key;
        };
    }

    private String formatValue(double value) {
        if (value == (int) value) return String.valueOf((int) value);
        return String.format("%.1f", value);
    }
}
