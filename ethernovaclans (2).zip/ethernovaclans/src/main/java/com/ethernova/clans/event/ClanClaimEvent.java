package com.ethernova.clans.event;

import com.ethernova.clans.clan.Clan;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

/**
 * Fired when a clan claims or unclaims a chunk.
 * Cancellable to prevent the claim/unclaim.
 */
public class ClanClaimEvent extends Event implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();
    private boolean cancelled = false;

    private final Clan clan;
    private final Player player;
    private final String chunkKey; // "world:x:z"
    private final ClaimAction action;

    public enum ClaimAction {
        CLAIM, UNCLAIM, SET_HQ
    }

    public ClanClaimEvent(@NotNull Clan clan, @NotNull Player player, @NotNull String chunkKey, @NotNull ClaimAction action) {
        this.clan = clan;
        this.player = player;
        this.chunkKey = chunkKey;
        this.action = action;
    }

    public @NotNull Clan getClan() { return clan; }
    public @NotNull Player getPlayer() { return player; }
    public @NotNull String getChunkKey() { return chunkKey; }
    public @NotNull ClaimAction getAction() { return action; }

    @Override public boolean isCancelled() { return cancelled; }
    @Override public void setCancelled(boolean cancel) { this.cancelled = cancel; }
    @Override public @NotNull HandlerList getHandlers() { return HANDLERS; }
    public static HandlerList getHandlerList() { return HANDLERS; }
}
