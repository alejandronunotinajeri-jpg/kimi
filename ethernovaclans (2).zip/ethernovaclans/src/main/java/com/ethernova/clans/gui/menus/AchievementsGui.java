package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.achievement.AchievementManager;
import com.ethernova.clans.achievement.AchievementManager.AchievementDefinition;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * GUI showing clan achievements and their unlock progress.
 * Supports pagination for many achievements.
 */
public class AchievementsGui extends AbstractGui {

    private static final int[] ACHIEVEMENT_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34
    };

    private static final int PREV_PAGE_SLOT = 45;
    private static final int NEXT_PAGE_SLOT = 53;
    private static final int INFO_SLOT = 4;

    private int page = 0;

    public AchievementsGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "achievements");
    }

    public AchievementsGui(EthernovaClans plugin, Player player, int page) {
        super(plugin, player, "achievements");
        this.page = page;
    }

    @Override
    protected void populateItems() {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return;

        AchievementManager am = plugin.getAchievementManager();
        if (am == null) return;

        List<AchievementDefinition> all = new ArrayList<>(am.getAllDefinitions());
        int totalPages = (int) Math.ceil((double) all.size() / ACHIEVEMENT_SLOTS.length);
        if (totalPages == 0) totalPages = 1;

        int unlocked = am.getUnlockedCount(clan);
        int total = am.getTotalCount();
        double percent = total > 0 ? (double) unlocked / total * 100.0 : 0;

        // Info header
        setItem(INFO_SLOT, new ItemBuilder(Material.GOLDEN_APPLE)
                .name("<gradient:#FFD700:#FFA500>🏆 Logros del Clan</gradient>")
                .lore(List.of(
                        "",
                        "<gray>Logros desbloqueados: <green>" + unlocked + "<gray>/<white>" + total,
                        "<gray>Progreso: <yellow>" + String.format("%.1f", percent) + "%",
                        TextUtil.progressBar(unlocked, total),
                        "",
                        "<gray>Desbloquea logros para ganar",
                        "<gray>Power, dinero y XP para tu clan."
                ))
                .glow()
                .build());

        // Place achievements for current page
        int startIdx = page * ACHIEVEMENT_SLOTS.length;
        for (int i = 0; i < ACHIEVEMENT_SLOTS.length; i++) {
            int idx = startIdx + i;
            if (idx >= all.size()) break;

            AchievementDefinition def = all.get(idx);
            boolean isUnlocked = am.isUnlocked(clan, def.id());
            int currentProgress = am.getCurrentProgress(clan, def);
            double progressPct = am.getProgress(clan, def);

            Material mat = isUnlocked ? Material.LIME_DYE : Material.GRAY_DYE;
            try {
                mat = Material.valueOf(def.icon().toUpperCase());
            } catch (IllegalArgumentException ignored) {}

            String statusStr;
            if (isUnlocked) {
                statusStr = "<green>✔ Desbloqueado";
            } else {
                statusStr = "<yellow>⏳ " + String.format("%.0f", progressPct) + "%";
            }

            String progressBar = TextUtil.progressBar(currentProgress, def.target());

            List<String> lore = new ArrayList<>(List.of(
                    "",
                    "<gray>" + def.description(),
                    "",
                    "<gray>Progreso: <white>" + Math.min(currentProgress, def.target()) + "/" + def.target(),
                    progressBar,
                    "",
                    "<gray>Estado: " + statusStr
            ));

            // Show rewards
            if (!isUnlocked) {
                lore.add("");
                lore.add("<gray>Recompensas al desbloquear:");
                if (def.powerReward() > 0) {
                    lore.add("<gold>  ⚡ +" + def.powerReward() + " Power");
                }
                if (def.moneyReward() > 0) {
                    lore.add("<gold>  💰 $" + TextUtil.formatCurrency(def.moneyReward()));
                }
                if (def.xpReward() > 0) {
                    lore.add("<aqua>  ✦ +" + def.xpReward() + " XP");
                }
            } else {
                lore.add("");
                lore.add("<green>¡Recompensas entregadas!");
            }

            setItem(ACHIEVEMENT_SLOTS[i], new ItemBuilder(mat)
                    .name((isUnlocked ? "<green>✔ " : "<gray>") + def.name())
                    .lore(lore)
                    .glowIf(isUnlocked)
                    .build());
        }

        // Pagination
        if (page > 0) {
            setItem(PREV_PAGE_SLOT, new ItemBuilder(Material.ARROW)
                    .name("<yellow>◀ Página Anterior")
                    .lore(List.of("<gray>Página " + page + "/" + totalPages))
                    .build());
            slotActions.put(PREV_PAGE_SLOT, "PREV_PAGE");
        }

        if (page < totalPages - 1) {
            setItem(NEXT_PAGE_SLOT, new ItemBuilder(Material.ARROW)
                    .name("<yellow>Página Siguiente ▶")
                    .lore(List.of("<gray>Página " + (page + 2) + "/" + totalPages))
                    .build());
            slotActions.put(NEXT_PAGE_SLOT, "NEXT_PAGE");
        }
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        switch (action.toUpperCase()) {
            case "PREV_PAGE" -> {
                if (page > 0) {
                    page--;
                    plugin.getServer().getScheduler().runTask(plugin, this::refreshGui);
                }
                return true;
            }
            case "NEXT_PAGE" -> {
                page++;
                plugin.getServer().getScheduler().runTask(plugin, this::refreshGui);
                return true;
            }
        }

        if (action.toUpperCase().startsWith("OPEN_GUI:")) {
            String guiName = action.substring("OPEN_GUI:".length());
            plugin.getServer().getScheduler().runTask(plugin, () ->
                    plugin.getGuiManager().openGui(player, guiName));
            return true;
        }
        if (action.equalsIgnoreCase("BACK")) {
            plugin.getServer().getScheduler().runTask(plugin, () ->
                    plugin.getGuiManager().openMainMenu(player));
            return true;
        }
        return false;
    }

    private void refreshGui() {
        occupiedSlots.clear();
        slotActions.clear();
        rightClickActions.clear();
        slotConfigs.clear();
        fillBackground();
        placeConfigItems();
        populateItems();
    }
}
