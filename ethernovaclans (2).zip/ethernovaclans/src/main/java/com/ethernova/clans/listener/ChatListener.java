package com.ethernova.clans.listener;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanMember;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Handles chat events for clan chat, alliance chat, @mentions, and global chat formatting.
 */
public class ChatListener implements Listener {

    private final EthernovaClans plugin;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();
    private static final Pattern MENTION_PATTERN = Pattern.compile("@(\\w{3,16})");

    public ChatListener(EthernovaClans plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onChat(AsyncChatEvent event) {
        Player player = event.getPlayer();

        // Check for pending anvil input (chat-based input)
        if (plugin.getGuiManager().hasAnvilInput(player.getUniqueId())) {
            event.setCancelled(true);
            String message = PlainTextComponentSerializer.plainText().serialize(event.message());

            // Handle on main thread
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                var callback = plugin.getGuiManager().consumeAnvilInput(player.getUniqueId());
                if (callback != null) callback.accept(message);
            });
            return;
        }

        // Check if player is in clan chat mode
        if (plugin.getChatManager() != null && plugin.getChatManager().isInClanChat(player.getUniqueId())) {
            event.setCancelled(true);
            String message = PlainTextComponentSerializer.plainText().serialize(event.message());

            var clan = plugin.getClanManager().getClanByPlayer(player);
            if (clan != null) {
                // Send on main thread
                plugin.getServer().getScheduler().runTask(plugin, () ->
                        plugin.getChatManager().sendClanMessage(player, clan, message));
            }
            return;
        }

        // Check if player is in alliance chat mode
        if (plugin.getChatManager() != null && plugin.getChatManager().isInAllyChat(player.getUniqueId())) {
            event.setCancelled(true);
            String message = PlainTextComponentSerializer.plainText().serialize(event.message());

            var clan = plugin.getClanManager().getClanByPlayer(player);
            if (clan != null) {
                plugin.getServer().getScheduler().runTask(plugin, () ->
                        plugin.getChatManager().sendAllyMessage(player, clan, message));
            }
            return;
        }

        // Check if player is in officer chat mode
        if (plugin.getChatManager() != null && plugin.getChatManager().isInOfficerChat(player.getUniqueId())) {
            event.setCancelled(true);
            String message = PlainTextComponentSerializer.plainText().serialize(event.message());

            var clan = plugin.getClanManager().getClanByPlayer(player);
            if (clan != null) {
                plugin.getServer().getScheduler().runTask(plugin, () ->
                        plugin.getChatManager().sendOfficerMessage(player, clan, message));
            }
            return;
        }

        // Check if player is in nation chat mode
        if (plugin.getChatManager() != null && plugin.getChatManager().isInNationChat(player.getUniqueId())) {
            event.setCancelled(true);
            String message = PlainTextComponentSerializer.plainText().serialize(event.message());

            var clan = plugin.getClanManager().getClanByPlayer(player);
            if (clan != null && plugin.getNationManager() != null) {
                var nation = plugin.getNationManager().getNationByClan(clan.getId());
                if (nation != null) {
                    plugin.getServer().getScheduler().runTask(plugin, () ->
                            plugin.getNationManager().sendNationMessage(nation, player, message));
                }
            }
            return;
        }

        // ── @Mentions in global chat ──
        String rawMessage = PlainTextComponentSerializer.plainText().serialize(event.message());
        processMentions(player, rawMessage);

        // ── Global chat formatting with clan tag ──
        // Disabled by default — use PlaceholderAPI (%ethernova_clan_tag_colored%) in your chat plugin.
        // Only modifies chat renderer if explicitly enabled in config.
        if (plugin.getConfigManager().getBoolean("chat.global.enabled", false)) {
            event.renderer((source, sourceDisplayName, message, viewer) -> {
                Clan clan = plugin.getClanManager().getClanByPlayer(source);
                String plainMsg = PlainTextComponentSerializer.plainText().serialize(message);

                // Highlight @mentions in message
                String highlighted = highlightMentions(plainMsg);
                Component msgComponent = miniMessage.deserialize(highlighted);

                if (clan != null) {
                    String format = plugin.getConfigManager().getString(
                            "chat.global.format", "{clan_tag} ");

                    String prefix = format
                            .replace("{clan_tag}", clan.getFormattedTag())
                            .replace("{clan_name}", clan.getName())
                            .replace("{player}", source.getName())
                            .replace("{player_name}", source.getName());

                    Component tagComponent = miniMessage.deserialize(prefix);
                    return tagComponent
                            .append(sourceDisplayName)
                            .append(Component.text(" "))
                            .append(msgComponent);
                } else {
                    return sourceDisplayName
                            .append(Component.text(" "))
                            .append(msgComponent);
                }
            });
        }
    }

    /**
     * Process @mentions and notify mentioned players.
     */
    private void processMentions(Player sender, String message) {
        if (!plugin.getConfigManager().getBoolean("chat.mentions.enabled", true)) return;

        Matcher matcher = MENTION_PATTERN.matcher(message);
        while (matcher.find()) {
            String mentionedName = matcher.group(1);
            Player mentioned = Bukkit.getPlayerExact(mentionedName);
            if (mentioned != null && mentioned.isOnline() && !mentioned.equals(sender)) {
                // Play mention sound on main thread
                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    mentioned.playSound(mentioned.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);
                    mentioned.sendMessage(miniMessage.deserialize(
                            "<gold>✦</gold> <yellow>" + sender.getName() + "</yellow> <gray>te mencionó en el chat!</gray>"));
                });
            }
        }
    }

    /**
     * Highlight @mentions with a color in the message.
     */
    private String highlightMentions(String message) {
        Matcher matcher = MENTION_PATTERN.matcher(message);
        StringBuilder sb = new StringBuilder();
        int lastEnd = 0;
        while (matcher.find()) {
            String name = matcher.group(1);
            Player p = Bukkit.getPlayerExact(name);
            // Escape the text BEFORE this match
            String before = message.substring(lastEnd, matcher.start());
            sb.append(MiniMessage.miniMessage().escapeTags(before));
            if (p != null && p.isOnline()) {
                sb.append("<yellow>@").append(name).append("</yellow>");
            } else {
                sb.append(MiniMessage.miniMessage().escapeTags("@" + name));
            }
            lastEnd = matcher.end();
        }
        // Escape the remaining tail
        sb.append(MiniMessage.miniMessage().escapeTags(message.substring(lastEnd)));
        return sb.toString();
    }
}
