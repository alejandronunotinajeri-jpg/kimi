package com.ethernova.clans.chat;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanMember;
import com.ethernova.clans.clan.ClanRole;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages clan chat, ally chat, and officer chat channels.
 */
public class ClanChatManager {

    private final EthernovaClans plugin;
    private final MiniMessage mini = MiniMessage.miniMessage();
    private final Set<UUID> clanChat = ConcurrentHashMap.newKeySet();
    private final Set<UUID> allyChat = ConcurrentHashMap.newKeySet();
    private final Set<UUID> officerChat = ConcurrentHashMap.newKeySet();
    private final Set<UUID> nationChat = ConcurrentHashMap.newKeySet();

    public ClanChatManager(EthernovaClans plugin) { this.plugin = plugin; }

    // ══════════════════════════════════════════════════════════
    //  CHAT MODE TOGGLES
    // ══════════════════════════════════════════════════════════

    public void toggleClanChat(UUID uuid) {
        if (!clanChat.remove(uuid)) {
            clanChat.add(uuid); allyChat.remove(uuid); officerChat.remove(uuid); nationChat.remove(uuid);
        }
    }

    public void toggleAllyChat(UUID uuid) {
        if (!allyChat.remove(uuid)) {
            allyChat.add(uuid); clanChat.remove(uuid); officerChat.remove(uuid); nationChat.remove(uuid);
        }
    }

    public void toggleOfficerChat(UUID uuid) {
        if (!officerChat.remove(uuid)) {
            officerChat.add(uuid); clanChat.remove(uuid); allyChat.remove(uuid); nationChat.remove(uuid);
        }
    }

    public void toggleNationChat(UUID uuid) {
        if (!nationChat.remove(uuid)) {
            nationChat.add(uuid); clanChat.remove(uuid); allyChat.remove(uuid); officerChat.remove(uuid);
        }
    }

    public boolean isInClanChat(UUID uuid) { return clanChat.contains(uuid); }
    public boolean isInAllyChat(UUID uuid) { return allyChat.contains(uuid); }
    public boolean isInOfficerChat(UUID uuid) { return officerChat.contains(uuid); }
    public boolean isInNationChat(UUID uuid) { return nationChat.contains(uuid); }

    public void exitAllChats(UUID uuid) {
        clanChat.remove(uuid);
        allyChat.remove(uuid);
        officerChat.remove(uuid);
        nationChat.remove(uuid);
    }

    // ══════════════════════════════════════════════════════════
    //  MESSAGING
    // ══════════════════════════════════════════════════════════

    /**
     * Send a message to all online clan members.
     */
    public void sendClanMessage(Player sender, Clan clan, String message) {
        String safeMsg = mini.escapeTags(message);
        String format = "<dark_green>[Clan]</dark_green> <green>" + sender.getName() + "</green><gray>: " + safeMsg + "</gray>";
        var component = mini.deserialize(format);
        for (Player m : plugin.getClanManager().getOnlineMembers(clan)) m.sendMessage(component);
        // Forward to SpyManager
        if (plugin.getSpyManager() != null) {
            plugin.getSpyManager().forwardToSpies("Clan", clan.getTag(), sender.getName(), safeMsg);
            plugin.getSpyManager().forwardToInfiltrators(clan.getId(), sender.getName(), clan.getTag(), safeMsg);
        }
    }

    /**
     * Send a message to all online members of allied clans.
     */
    public void sendAllyMessage(Player sender, Clan senderClan, String message) {
        String safeMsg = mini.escapeTags(message);
        String format = "<dark_aqua>[Aliado]</dark_aqua> <aqua>" + sender.getName() + "</aqua> <dark_gray>[" + senderClan.getDisplayName() + "]</dark_gray><gray>: " + safeMsg + "</gray>";
        var component = mini.deserialize(format);
        for (Player m : plugin.getClanManager().getOnlineMembers(senderClan)) m.sendMessage(component);
        for (Clan ally : plugin.getAllianceManager().getAllies(senderClan))
            for (Player m : plugin.getClanManager().getOnlineMembers(ally)) m.sendMessage(component);
        // Forward to SpyManager
        if (plugin.getSpyManager() != null) {
            plugin.getSpyManager().forwardToSpies("Aliado", senderClan.getTag(), sender.getName(), safeMsg);
        }
    }

    /**
     * Send a message to all online officers+ of the clan.
     */
    public void sendOfficerMessage(Player sender, Clan clan, String message) {
        String safeMsg = mini.escapeTags(message);
        String format = "<gold>[Oficiales]</gold> <yellow>" + sender.getName() + "</yellow><gray>: " + safeMsg + "</gray>";
        var component = mini.deserialize(format);
        for (Player m : plugin.getClanManager().getOnlineMembers(clan)) {
            ClanMember cm = clan.getMember(m.getUniqueId());
            if (cm != null && cm.getRole().isAtLeast(ClanRole.OFFICER)) {
                m.sendMessage(component);
            }
        }
        // Forward to SpyManager
        if (plugin.getSpyManager() != null) {
            plugin.getSpyManager().forwardToSpies("Oficiales", clan.getTag(), sender.getName(), safeMsg);
        }
    }
}
