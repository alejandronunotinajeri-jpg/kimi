package com.ethernova.clans.gui;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.level.ClanLevelManager;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.SoundUtil;
import com.ethernova.clans.util.TextUtil;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;

import org.bukkit.scheduler.BukkitTask;

/**
 * Abstract base for all configurable GUIs.
 * Loads layout, items, and actions from YAML configuration.
 */
public abstract class AbstractGui {

    protected final EthernovaClans plugin;
    protected final Player player;
    protected final ConfigurationSection guiConfig;
    protected Inventory inventory;

    /** Maps slot -> action string (left click / default) */
    protected final Map<Integer, String> slotActions = new HashMap<>();
    /** Maps slot -> right-click action string */
    protected final Map<Integer, String> rightClickActions = new HashMap<>();
    /** Maps slot -> config section for the item at that slot */
    protected final Map<Integer, ConfigurationSection> slotConfigs = new HashMap<>();
    /** Slots occupied by real items (not filler) */
    protected final Set<Integer> occupiedSlots = new HashSet<>();

    /** Animation task for rainbow glass */
    private BukkitTask animationTask;
    private int animationOffset = 0;

    /** Click debounce to prevent rapid-click exploits */
    private long lastClickTime = 0;
    private static final long CLICK_COOLDOWN_MS = 200;

    private static final MiniMessage MINI = MiniMessage.miniMessage();

    public AbstractGui(EthernovaClans plugin, Player player, String guiConfigKey) {
        this.plugin = plugin;
        this.player = player;
        this.guiConfig = plugin.getConfigManager().getGuiConfig(guiConfigKey);
    }

    /**
     * Convenience: get a raw message string from MessageManager for use in GUI items.
     * Returns the raw MiniMessage string (not deserialized).
     */
    protected String msg(String key, String... replacements) {
        if (plugin.getMessageManager() == null) return key;
        return plugin.getMessageManager().get(key, replacements);
    }

    // ══════════════════════════════════════════════════════════
    //  OPEN & BUILD
    // ══════════════════════════════════════════════════════════

    /**
     * Open the GUI for the player.
     */
    public void open() {
        if (guiConfig == null) {
            player.sendMessage(plugin.getConfigManager().getMessage("gui.config-error"));
            return;
        }

        String title = guiConfig.getString("title", "<dark_gray>Menu");
        int size = guiConfig.getInt("size", 54);
        int min = getMinimumSize();
        if (size < min) size = min;

        // Replace placeholders in title
        title = replacePlaceholders(title);

        inventory = Bukkit.createInventory(null, size, MINI.deserialize(title));

        // Fill background
        fillBackground();

        // Place configured items
        placeConfigItems();

        // Let subclasses add dynamic content
        populateItems();

        // Register BEFORE opening so close event on old inventory sees correct state
        plugin.getGuiManager().registerGui(player, this);
        player.openInventory(inventory);

        // Start animation if rainbow fill is enabled
        startAnimation();

        // Item reveal animation (premium effect from core)
        try {
            var coreHook = plugin.getCoreHook();
            if (coreHook != null && coreHook.isAvailable()) {
                var coreInstance = coreHook.getCore();
                if (coreInstance != null) {
                    var animMgr = coreInstance.getGuiAnimationManager();
                    if (animMgr != null) {
                        List<Integer> borderSlots = new ArrayList<>();
                        for (int i = 0; i < inventory.getSize(); i++) {
                            if (!occupiedSlots.contains(i)) {
                                borderSlots.add(i);
                            }
                        }
                        animMgr.playItemReveal(player, inventory, occupiedSlots, borderSlots);
                    }
                }
            }
        } catch (Exception e) {
            plugin.getLogger().fine("GUI animation not available: " + e.getMessage());
        }
    }

    /**
     * Check whether the given inventory belongs to this GUI.
     */
    public boolean isOwnInventory(Inventory inv) {
        return this.inventory != null && this.inventory.equals(inv);
    }

    /**
     * Start the rainbow glass animation task.
     */
    protected void startAnimation() {
        boolean rainbowFill = plugin.getConfigManager().getBoolean("gui.rainbow-fill", true);
        boolean fillEnabled = guiConfig.getBoolean("fill.enabled", true);
        if (!rainbowFill || !fillEnabled) return;

        int animSpeed = plugin.getConfigManager().getInt("gui.animation-speed", 10);
        if (animSpeed <= 0) return; // 0 = static, no animation

        animationTask = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            animationOffset++;
            updateFillerSlots();
        }, animSpeed, animSpeed);
    }

    /**
     * Update only the filler/border slots with shifted rainbow pattern.
     */
    private void updateFillerSlots() {
        if (inventory == null) return;
        for (int i = 0; i < inventory.getSize(); i++) {
            if (!occupiedSlots.contains(i)) {
                Material pane = RAINBOW_PANES[(i + animationOffset) % RAINBOW_PANES.length];
                inventory.setItem(i, ItemBuilder.filler(pane.name()));
            }
        }
    }

    /**
     * Stop the animation task (called on GUI close).
     */
    public void stopAnimation() {
        if (animationTask != null) {
            animationTask.cancel();
            animationTask = null;
        }
        // Cancel item reveal animation from core
        try {
            var coreHook = plugin.getCoreHook();
            if (coreHook != null && coreHook.isAvailable()) {
                var coreInstance = coreHook.getCore();
                if (coreInstance != null) {
                    var animMgr = coreInstance.getGuiAnimationManager();
                    if (animMgr != null) {
                        animMgr.cancelAnimations(player.getUniqueId());
                    }
                }
            }
        } catch (Exception e) {
            plugin.getLogger().fine("Animation cancel failed: " + e.getMessage());
        }
    }

    /**
     * Called when the GUI is closed (by player or programmatically).
     */
    public void onClose() {
        stopAnimation();
    }

    /** Rainbow stained glass pane materials for decorative fill */
    private static final Material[] RAINBOW_PANES = {
            Material.RED_STAINED_GLASS_PANE,
            Material.ORANGE_STAINED_GLASS_PANE,
            Material.YELLOW_STAINED_GLASS_PANE,
            Material.LIME_STAINED_GLASS_PANE,
            Material.LIGHT_BLUE_STAINED_GLASS_PANE,
            Material.BLUE_STAINED_GLASS_PANE,
            Material.PURPLE_STAINED_GLASS_PANE,
            Material.MAGENTA_STAINED_GLASS_PANE,
            Material.PINK_STAINED_GLASS_PANE,
            Material.CYAN_STAINED_GLASS_PANE,
            Material.GREEN_STAINED_GLASS_PANE,
            Material.WHITE_STAINED_GLASS_PANE
    };

    /**
     * Fill the inventory background using config.
     * Supports rainbow glass pane mode when enabled in config.
     */
    protected void fillBackground() {
        boolean rainbowFill = plugin.getConfigManager().getBoolean("gui.rainbow-fill", true);

        // Fill all slots (respect enabled flag)
        String fillMat = guiConfig.getString("fill.material");
        boolean fillEnabled = guiConfig.getBoolean("fill.enabled", true);
        if (fillEnabled) {
            if (rainbowFill) {
                // Rainbow glass pane fill
                for (int i = 0; i < inventory.getSize(); i++) {
                    Material pane = RAINBOW_PANES[i % RAINBOW_PANES.length];
                    inventory.setItem(i, ItemBuilder.filler(pane.name()));
                }
            } else if (fillMat != null && !fillMat.equalsIgnoreCase("NONE")) {
                ItemStack filler = ItemBuilder.filler(fillMat);
                for (int i = 0; i < inventory.getSize(); i++) {
                    inventory.setItem(i, filler);
                }
            }
        }

        // Border (respect enabled flag)
        String borderMat = guiConfig.getString("border.material");
        boolean borderEnabled = guiConfig.getBoolean("border.enabled", true);
        if (borderEnabled) {
            int rows = inventory.getSize() / 9;
            for (int i = 0; i < inventory.getSize(); i++) {
                int row = i / 9;
                int col = i % 9;
                if (row == 0 || row == rows - 1 || col == 0 || col == 8) {
                    if (rainbowFill) {
                        Material pane = RAINBOW_PANES[i % RAINBOW_PANES.length];
                        inventory.setItem(i, ItemBuilder.filler(pane.name()));
                    } else if (borderMat != null && !borderMat.equalsIgnoreCase("NONE")) {
                        inventory.setItem(i, ItemBuilder.filler(borderMat));
                    }
                }
            }
        }
    }

    /**
     * Place all configured items from the "items" section.
     */
    protected void placeConfigItems() {
        var itemsSection = guiConfig.getConfigurationSection("items");
        if (itemsSection == null) return;

        for (String key : itemsSection.getKeys(false)) {
            var itemSec = itemsSection.getConfigurationSection(key);
            if (itemSec == null) continue;

            // Check requirements
            if (!checkRequirements(itemSec)) continue;

            int slot = itemSec.getInt("slot", -1);
            if (slot < 0 || slot >= inventory.getSize()) continue;

            // Build item
            ItemStack item = buildItemFromConfig(itemSec);
            if (item != null) {
                inventory.setItem(slot, item);
                occupiedSlots.add(slot);
            }

            // Store action (left-click / default)
            // Support both "action: STRING" and "actions: [LIST]" formats
            String action = itemSec.getString("action");
            if (action == null) {
                // Try "actions" list format — join into a compound action string
                List<String> actionsList = itemSec.getStringList("actions");
                if (!actionsList.isEmpty()) {
                    action = String.join(";;", actionsList);
                }
            }
            if (action != null) {
                slotActions.put(slot, action);
                slotConfigs.put(slot, itemSec);
            }

            // Store right-click action (if different from left-click)
            String rightAction = itemSec.getString("right-click-action");
            if (rightAction != null) {
                rightClickActions.put(slot, rightAction);
                if (action == null) {
                    slotConfigs.put(slot, itemSec);
                }
            }
        }
    }

    /**
     * Build an ItemStack from a config section.
     */
    protected ItemStack buildItemFromConfig(ConfigurationSection section) {
        String materialName = section.getString("material", "STONE");
        ItemBuilder builder = ItemBuilder.fromMaterialName(materialName);

        // Name
        String name = section.getString("name");
        if (name != null) {
            name = replacePlaceholders(name);
            builder.name(name);
        }

        // Lore
        List<String> lore = section.getStringList("lore");
        if (!lore.isEmpty()) {
            lore = lore.stream()
                    .map(this::replacePlaceholders)
                    .toList();
            builder.lore(lore);
        }

        // Amount
        int amount = section.getInt("amount", 1);
        builder.amount(amount);

        // Glow
        if (section.getBoolean("glow", false)) {
            builder.glow();
        }

        // Custom model data
        int cmd = section.getInt("custom-model-data", 0);
        if (cmd > 0) builder.customModelData(cmd);

        // Hide flags
        if (section.getBoolean("hide-flags", true)) {
            builder.hideFlags();
        }

        return builder.build();
    }

    /**
     * Check if item requirements are met (role, level, permission).
     */
    protected boolean checkRequirements(ConfigurationSection itemSec) {
        // Check nested requirements section
        var reqSection = itemSec.getConfigurationSection("requirements");
        if (reqSection != null) {
            String minRole = reqSection.getString("role");
            if (minRole != null && !checkRoleRequirement(minRole)) return false;

            int minLevel = reqSection.getInt("level", 0);
            if (minLevel > 0 && !checkLevelRequirement(minLevel)) return false;

            String permission = reqSection.getString("permission");
            if (permission != null && !player.hasPermission(permission)) return false;
        }

        // Also check flat require-role / require-level keys (YAML shorthand)
        String flatRole = itemSec.getString("require-role");
        if (flatRole != null && !checkRoleRequirement(flatRole)) return false;

        int flatLevel = itemSec.getInt("require-level", 0);
        if (flatLevel > 0 && !checkLevelRequirement(flatLevel)) return false;

        String flatPermission = itemSec.getString("require-permission");
        if (flatPermission != null && !player.hasPermission(flatPermission)) return false;

        return true;
    }

    private boolean checkRoleRequirement(String minRole) {
        var clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return false;
        var member = clan.getMember(player.getUniqueId());
        if (member == null) return false;
        try {
            var requiredRole = com.ethernova.clans.clan.ClanRole.valueOf(minRole.toUpperCase());
            return member.getRole().isAtLeast(requiredRole);
        } catch (IllegalArgumentException e) {
            plugin.getLogger().warning("Invalid ClanRole in config: '" + minRole + "'");
            return true;
        }
    }

    private boolean checkLevelRequirement(int minLevel) {
        var clan = plugin.getClanManager().getClanByPlayer(player);
        return clan != null && clan.getLevel() >= minLevel;
    }

    // ══════════════════════════════════════════════════════════
    //  CLICK HANDLING
    // ══════════════════════════════════════════════════════════

    /**
     * Handle a click event.
     */
    public final void handleClick(InventoryClickEvent event) {
        event.setCancelled(true);
        int slot = event.getRawSlot();
        if (slot < 0 || slot >= inventory.getSize()) return;

        // Debounce rapid clicks to prevent duplication exploits
        long now = System.currentTimeMillis();
        if (now - lastClickTime < CLICK_COOLDOWN_MS) return;
        lastClickTime = now;

        // Play sound from config
        ConfigurationSection itemSec = slotConfigs.get(slot);
        if (itemSec != null) {
            SoundUtil.playGuiSound(player, itemSec);
        }

        // Determine action based on click type
        String action = null;
        if (event.isRightClick() && rightClickActions.containsKey(slot)) {
            action = rightClickActions.get(slot);
        }
        if (action == null) {
            action = slotActions.get(slot);
        }

        if (action != null) {
            if (!processAction(action, slot, event)) {
                // If not handled by subclass, handle common actions
                handleCommonAction(action, slot, event);
            }
        }

        // Let subclass handle
        onClick(slot, event);
    }

    /**
     * Handle common actions that all GUIs share.
     * Supports compound actions separated by ";;" and bracket-style actions.
     */
    protected void handleCommonAction(String action, int slot, InventoryClickEvent event) {
        // Handle compound actions (multiple actions joined by ";;")
        if (action.contains(";;")) {
            for (String subAction : action.split(";;")) {
                String trimmed = subAction.trim();
                if (!trimmed.isEmpty()) {
                    handleSingleAction(trimmed, slot, event);
                }
            }
            return;
        }
        handleSingleAction(action, slot, event);
    }

    /**
     * Handle a single action string (either bracket-style or legacy format).
     */
    private void handleSingleAction(String action, int slot, InventoryClickEvent event) {
        String trimmed = action.trim();

        // ── Bracket-style actions: [close], [open] name, [command] cmd, [message] text, [sound] sound ──
        if (trimmed.startsWith("[")) {
            String lower = trimmed.toLowerCase();
            if (lower.equals("[close]")) {
                player.closeInventory();
            } else if (lower.startsWith("[open]")) {
                String guiName = trimmed.substring("[open]".length()).trim().replace(" ", "-");
                if (!guiName.isEmpty()) {
                    plugin.getServer().getScheduler().runTask(plugin, () ->
                            plugin.getGuiManager().openGui(player, guiName));
                }
            } else if (lower.startsWith("[command]")) {
                String cmd = trimmed.substring("[command]".length()).trim();
                if (!cmd.isEmpty()) {
                    player.closeInventory();
                    plugin.getServer().getScheduler().runTask(plugin, () ->
                            player.performCommand(cmd));
                }
            } else if (lower.startsWith("[message]")) {
                String msg = trimmed.substring("[message]".length()).trim();
                if (!msg.isEmpty()) {
                    msg = replacePlaceholders(msg);
                    player.sendMessage(MINI.deserialize(msg));
                }
            } else if (lower.startsWith("[sound]")) {
                String soundName = trimmed.substring("[sound]".length()).trim().toUpperCase();
                try {
                    player.playSound(player.getLocation(),
                            org.bukkit.Sound.valueOf(soundName), 1.0f, 1.0f);
                } catch (IllegalArgumentException e) {
                    plugin.getLogger().fine("Unknown sound in GUI config: " + soundName);
                }
            }
            return;
        }

        // ── Legacy uppercase actions ──
        switch (trimmed.toUpperCase()) {
            case "CLOSE" -> player.closeInventory();
            case "BACK" -> {
                plugin.getServer().getScheduler().runTask(plugin, () ->
                        plugin.getGuiManager().openMainMenu(player));
            }
            default -> {
                if (trimmed.startsWith("OPEN_GUI:")) {
                    String guiName = trimmed.substring("OPEN_GUI:".length());
                    plugin.getServer().getScheduler().runTask(plugin, () ->
                            plugin.getGuiManager().openGui(player, guiName));
                }
            }
        }
    }

    // ══════════════════════════════════════════════════════════
    //  ABSTRACT METHODS
    // ══════════════════════════════════════════════════════════

    /**
     * Override to add dynamic items after config items are placed.
     */
    protected abstract void populateItems();

    /**
     * Override to enforce a minimum inventory size regardless of YAML config.
     * Subclasses like TerritoryMapGui need exactly 54 slots.
     */
    protected int getMinimumSize() { return 9; }

    /**
     * Override to handle custom actions. Return true if handled.
     */
    protected abstract boolean processAction(String action, int slot, InventoryClickEvent event);

    /**
     * Override for additional click handling.
     */
    protected void onClick(int slot, InventoryClickEvent event) {}

    /**
     * Place a dynamic item and mark the slot as occupied (so animation skips it).
     */
    protected void setItem(int slot, ItemStack item) {
        if (slot >= 0 && slot < inventory.getSize()) {
            inventory.setItem(slot, item);
            if (item != null) {
                occupiedSlots.add(slot);
            } else {
                occupiedSlots.remove(slot);
            }
        }
    }

    // ══════════════════════════════════════════════════════════
    //  PLACEHOLDER REPLACEMENT
    // ══════════════════════════════════════════════════════════

    /**
     * Replace placeholders in text. Override to add more.
     */
    protected String replacePlaceholders(String text) {
        if (text == null) return "";
        text = text.replace("{player}", player.getName());

        var clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan != null) {
            ClanLevelManager levelMgr = plugin.getLevelManager();
            int level = clan.getLevel();
            int nextLevel = Math.min(level + 1, levelMgr.getMaxLevel());
            ClanLevelManager.LevelData currentData = levelMgr.getLevelData(level);
            ClanLevelManager.LevelData nextData = levelMgr.getLevelData(nextLevel);

            // ── Core clan info ──
            String clanName = clan.getName();
            String clanTag = clan.getTag();
            String formattedTag = clan.getFormattedTag();
            int power = (int) clan.getPower();
            int kills = clan.getKills();
            int deaths = clan.getDeaths();
            String kd = String.format("%.2f", clan.getKD());
            int memberCount = clan.getMembers().size();
            int onlineCount = clan.getOnlineMemberCount();
            int maxMembers = levelMgr.getMaxMembers(level);
            int maxClaims = levelMgr.getMaxClaims(level);
            int maxAllies = levelMgr.getMaxAllies(level);
            String levelName = levelMgr.getLevelName(level);
            double balance = clan.getBank().getBalance();
            String balanceStr = String.format("%.2f", balance);
            String balanceFormatted = TextUtil.formatCurrency(balance).replace("$", "");
            int warsWon = clan.getWarsWon();
            int warsLost = clan.getWarsLost();
            int alliesCount = clan.getAllies().size();
            int rivalsCount = clan.getRivals().size();
            int claimsCount = clan.getClaimCount();
            String description = clan.getDescription() != null ? clan.getDescription() : "";

            // ── Level progress ──
            int maxPower = currentData != null ? currentData.powerRequired() : power;
            int nextLevelPower = nextData != null ? nextData.powerRequired() : maxPower;
            int progressFrom = currentData != null ? currentData.powerRequired() : 0;
            int progressTotal = nextLevelPower - progressFrom;
            int progressCurrent = power - progressFrom;
            String progressPct = progressTotal > 0
                    ? String.valueOf((int) ((double) progressCurrent / progressTotal * 100))
                    : "100";
            String progressBar = progressTotal > 0
                    ? TextUtil.progressBar(progressCurrent, progressTotal)
                    : TextUtil.progressBar(1, 1);

            // ── War stats ──
            int totalWars = warsWon + warsLost;
            String winrate = totalWars > 0
                    ? String.format("%.1f", (double) warsWon / totalWars * 100)
                    : "0.0";

            // ── Bank info ──
            double taxRate = clan.getBank().getTaxRate();
            double maxBalance = plugin.getConfigManager().getDouble(
                    "bank.max-balance-per-level." + level, 50000);
            double interestRate = plugin.getConfigManager().getDouble("bank.interest.base-rate", 0.5);
            double levelBonus = plugin.getConfigManager().getDouble("bank.interest.bonus-per-level." + level, 0.0);
            double totalInterestRate = interestRate + levelBonus;
            double interestEstimate = balance * (totalInterestRate / 100.0);

            // Next interest time
            String nextInterestTime = "N/A";
            var lastInterest = clan.getBank().getLastInterestTime();
            if (lastInterest != null) {
                long intervalMs = plugin.getConfigManager().parseTimeToMillis(
                        plugin.getConfigManager().getString("bank.interest.interval", "1h"));
                java.time.Instant nextInterest = lastInterest.plusMillis(intervalMs);
                long remaining = java.time.Duration.between(java.time.Instant.now(), nextInterest).toSeconds();
                if (remaining > 0) {
                    long mins = remaining / 60;
                    long secs = remaining % 60;
                    nextInterestTime = mins > 0 ? mins + "m " + secs + "s" : secs + "s";
                } else {
                    nextInterestTime = "Soon";
                }
            }

            // ── Bank deposit/withdraw limits ──
            double depositMin = plugin.getConfigManager().getDouble("bank.deposit.min-amount", 10.0);
            double depositMax = plugin.getConfigManager().getDouble("bank.deposit.max-amount", 1000000.0);
            double withdrawMin = plugin.getConfigManager().getDouble("bank.withdraw.min-amount", 10.0);
            double withdrawMax = plugin.getConfigManager().getDouble("bank.withdraw.max-amount", 500000.0);

            // ── Config costs/cooldowns ──
            double nameCost = plugin.getConfigManager().getDouble("clan.name.change-cost", 15000.0);
            String nameCooldown = plugin.getConfigManager().getString("clan.name.change-cooldown", "168h");
            double tagCost = plugin.getConfigManager().getDouble("clan.tag.change-cost", 8000.0);
            String tagCooldown = plugin.getConfigManager().getString("clan.tag.change-cooldown", "72h");
            double refundPct = plugin.getConfigManager().getDouble("clan.disband.refund-percentage", 50.0);
            double allianceCost = plugin.getConfigManager().getDouble("alliances.cost", 5000.0);
            double rivalBonusMult = plugin.getConfigManager().getDouble("alliances.rivalries.kill-bonus-multiplier", 1.5);
            int surrenderExtra = plugin.getConfigManager().getInt("wars.surrender.extra-power-loss-percentage", 25);

            // ── War type info ──
            String dmDuration = plugin.getConfigManager().getString("wars.types.deathmatch.duration", "30m");
            double dmCost = plugin.getConfigManager().getDouble("wars.types.deathmatch.cost", 5000.0);
            int dmMinMembers = plugin.getConfigManager().getInt("wars.types.deathmatch.min-members-online", 3);
            String cqDuration = plugin.getConfigManager().getString("wars.types.conquest.duration", "45m");
            double cqCost = plugin.getConfigManager().getDouble("wars.types.conquest.cost", 10000.0);
            int cqMinMembers = plugin.getConfigManager().getInt("wars.types.conquest.min-members-online", 5);
            String rdDuration = plugin.getConfigManager().getString("wars.types.raid.duration", "20m");
            double rdCost = plugin.getConfigManager().getDouble("wars.types.raid.cost", 15000.0);
            int rdMinMembers = plugin.getConfigManager().getInt("wars.types.raid.min-members-online", 4);

            // ── Clan age ──
            long daysActive = 0;
            if (clan.getCreatedDate() != null) {
                try {
                    java.time.LocalDateTime created = java.time.LocalDateTime.parse(clan.getCreatedDate(),
                            java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
                    daysActive = java.time.temporal.ChronoUnit.DAYS.between(created.toLocalDate(), java.time.LocalDate.now());
                } catch (Exception e) {
                    plugin.getLogger().warning("Failed to parse clan created date: " + clan.getCreatedDate());
                }
            }

            // ── Player economy ──
            double playerBalance = 0;
            if (plugin.getVaultHook() != null) {
                playerBalance = plugin.getVaultHook().getBalance(player);
            }

            // ── Replace all placeholders ──
            text = text
                    // Clan core (canonical + aliases)
                    .replace("{clan_name}", clanName)
                    .replace("{clan}", clanName)
                    .replace("{clan_tag}", clanTag)
                    .replace("{clan_tag_colored}", formattedTag)
                    .replace("{clan_level}", String.valueOf(level))
                    .replace("{clan_level_name}", levelName)
                    .replace("{level_name}", levelName)
                    .replace("{clan_power}", String.valueOf(power))
                    .replace("{max_power}", String.valueOf(nextLevelPower))
                    .replace("{clan_kd}", kd)
                    .replace("{clan_description}", description)

                    // Members
                    .replace("{clan_members}", String.valueOf(memberCount))
                    .replace("{members_total}", String.valueOf(memberCount))
                    .replace("{clan_max_members}", String.valueOf(maxMembers))
                    .replace("{max_members}", String.valueOf(maxMembers))
                    .replace("{members_online}", String.valueOf(onlineCount))

                    // Kills / Deaths
                    .replace("{clan_kills}", String.valueOf(kills))
                    .replace("{total_kills}", String.valueOf(kills))
                    .replace("{clan_deaths}", String.valueOf(deaths))
                    .replace("{total_deaths}", String.valueOf(deaths))

                    // Economy / Bank
                    .replace("{clan_balance}", balanceFormatted)
                    .replace("{bank_balance}", balanceFormatted)
                    .replace("{bank_max}", TextUtil.formatCurrency(maxBalance).replace("$", ""))
                    .replace("{interest_rate}", String.format("%.1f", totalInterestRate))
                    .replace("{next_interest_time}", nextInterestTime)
                    .replace("{interest_estimate}", String.format("%.2f", interestEstimate))
                    .replace("{tax_rate}", String.format("%.0f", taxRate))
                    .replace("{player_balance}", TextUtil.formatCurrency(playerBalance).replace("$", ""))

                    // Wars
                    .replace("{clan_wars_won}", String.valueOf(warsWon))
                    .replace("{wars_won}", String.valueOf(warsWon))
                    .replace("{clan_wars_lost}", String.valueOf(warsLost))
                    .replace("{wars_lost}", String.valueOf(warsLost))
                    .replace("{war_winrate}", winrate)
                    .replace("{active_wars}", String.valueOf(
                            plugin.getWarManager() != null ? plugin.getWarManager().getActiveWars(clan).size() : 0))

                    // Diplomacy
                    .replace("{clan_allies}", String.valueOf(alliesCount))
                    .replace("{allies_count}", String.valueOf(alliesCount))
                    .replace("{max_allies}", String.valueOf(maxAllies))
                    .replace("{clan_rivals}", String.valueOf(rivalsCount))
                    .replace("{rivals_count}", String.valueOf(rivalsCount))
                    .replace("{max_rivals}", String.valueOf(plugin.getConfigManager().getInt("alliances.rivalries.max-rivals", 5)))
                    .replace("{pending_requests}", String.valueOf(clan.getPendingAllyRequests().size()))

                    // Level progress
                    .replace("{level_progress}", progressPct)
                    .replace("{progress_bar}", progressBar)
                    .replace("{next_level_power}", String.valueOf(nextLevelPower))
                    .replace("{next_level}", String.valueOf(nextLevel))
                    .replace("{next_level_name}", nextData != null ? nextData.name() : levelName)
                    .replace("{next_max_members}", nextData != null ? String.valueOf(nextData.maxMembers()) : String.valueOf(maxMembers))
                    .replace("{next_max_claims}", nextData != null ? String.valueOf(nextData.maxClaims()) : String.valueOf(maxClaims))

                    // Territory / Claims
                    .replace("{claims_count}", String.valueOf(claimsCount))
                    .replace("{max_claims}", String.valueOf(maxClaims))
                    .replace("{hq_status}", clan.getHeadquartersChunk() != null ? "<green>✔" : "<red>✘")
                    .replace("{home_status}", clan.getHomeLocation() != null ? "<green>✔ Establecido" : "<red>✘ Sin home")

                    // Settings status
                    .replace("{pvp_status}", clan.isFriendlyFire() ? "<green>ON" : "<red>OFF")
                    .replace("{invite_mode}", TextUtil.capitalize(clan.getInviteMode() != null ? clan.getInviteMode() : "invite"))
                    .replace("{clan_chat_status}", clan.isClanChatEnabled() ? "<green>ON" : "<red>OFF")
                    .replace("{chat_status}", plugin.getChatManager() != null && plugin.getChatManager().isInClanChat(player.getUniqueId()) ? "<green>ON" : "<red>OFF")
                    .replace("{player_chat_mode}", plugin.getChatManager() != null && plugin.getChatManager().isInClanChat(player.getUniqueId()) ? "<green>ON" : "<red>OFF")
                    .replace("{war_participation_status}", clan.isWarParticipation() ? "<green>ON" : "<red>OFF")

                    // Misc / Ranking placeholder (computed at runtime)
                    .replace("{clan_rank}", computeClanRank(clan))
                    .replace("{created_date}", clan.getCreatedDate() != null ? clan.getCreatedDate() : "N/A")
                    .replace("{pending_notifications}", "0")
                    .replace("{days_active}", String.valueOf(daysActive))

                    // Progress stats (computed from managers)
                    .replace("{total_power_gained}", String.valueOf(power))
                    .replace("{total_power_lost}", "0") // No tracking yet
                    .replace("{missions_completed}", String.valueOf(computeMissionsCompleted(clan)))
                    .replace("{missions_available}", String.valueOf(computeMissionsAvailable(clan)))
                    .replace("{next_boost}", nextData != null ? nextData.name() : "Max")

                    // Bank limits
                    .replace("{deposit_min}", TextUtil.formatCurrency(depositMin).replace("$", ""))
                    .replace("{deposit_max}", TextUtil.formatCurrency(depositMax).replace("$", ""))
                    .replace("{withdraw_min}", TextUtil.formatCurrency(withdrawMin).replace("$", ""))
                    .replace("{withdraw_max}", TextUtil.formatCurrency(withdrawMax).replace("$", ""))

                    // Config costs / cooldowns
                    .replace("{name_cost}", TextUtil.formatCurrency(nameCost).replace("$", ""))
                    .replace("{name_cooldown}", nameCooldown)
                    .replace("{tag_cost}", TextUtil.formatCurrency(tagCost).replace("$", ""))
                    .replace("{tag_cooldown}", tagCooldown)
                    .replace("{refund_pct}", String.format("%.0f", refundPct))
                    .replace("{alliance_cost}", TextUtil.formatCurrency(allianceCost).replace("$", ""))
                    .replace("{rival_bonus_multiplier}", String.format("%.1f", rivalBonusMult))
                    .replace("{surrender_extra}", String.valueOf(surrenderExtra))
                    .replace("{war_disable_penalty}", String.valueOf(surrenderExtra))

                    // War type info
                    .replace("{dm_duration}", dmDuration)
                    .replace("{dm_cost}", TextUtil.formatCurrency(dmCost).replace("$", ""))
                    .replace("{dm_min_members}", String.valueOf(dmMinMembers))
                    .replace("{cq_duration}", cqDuration)
                    .replace("{cq_cost}", TextUtil.formatCurrency(cqCost).replace("$", ""))
                    .replace("{cq_min_members}", String.valueOf(cqMinMembers))
                    .replace("{rd_duration}", rdDuration)
                    .replace("{rd_cost}", TextUtil.formatCurrency(rdCost).replace("$", ""))
                    .replace("{rd_min_members}", String.valueOf(rdMinMembers))

                    // War status
                    .replace("{active_war_status}",
                            plugin.getWarManager() != null && !plugin.getWarManager().getActiveWars(clan).isEmpty()
                                    ? "<red>In War" : "<green>At Peace");

            // ── Player-specific ──
            var member = clan.getMember(player.getUniqueId());
            if (member != null) {
                text = text.replace("{player_role}", member.getRole().name())
                        .replace("{player_kills}", String.valueOf(member.getKills()))
                        .replace("{player_deaths}", String.valueOf(member.getDeaths()))
                        .replace("{player_kd}", String.format("%.2f", member.getKD()))
                        .replace("{player_power_contributed}", String.valueOf(member.getPowerContributed()));
            }
        }

        return text;
    }

    // ══════════════════════════════════════════════════════════
    //  PLACEHOLDER HELPERS
    // ══════════════════════════════════════════════════════════

    /**
     * Compute the clan's rank among all clans (by power, descending).
     */
    private String computeClanRank(com.ethernova.clans.clan.Clan clan) {
        try {
            var allClans = new java.util.ArrayList<>(plugin.getClanManager().getAllClans());
            allClans.sort((a, b) -> Double.compare(b.getPower(), a.getPower()));
            for (int i = 0; i < allClans.size(); i++) {
                if (allClans.get(i).getId().equals(clan.getId())) {
                    return "#" + (i + 1);
                }
            }
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to compute clan rank: " + e.getMessage());
        }
        return "?";
    }

    /**
     * Count completed missions for this clan.
     */
    private int computeMissionsCompleted(com.ethernova.clans.clan.Clan clan) {
        try {
            var mm = plugin.getMissionManager();
            if (mm == null) return 0;
            return (int) mm.getActiveMissions(clan).stream()
                    .filter(m -> m.isCompleted())
                    .count();
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Count available (non-completed, non-expired) missions for this clan.
     */
    private int computeMissionsAvailable(com.ethernova.clans.clan.Clan clan) {
        try {
            var mm = plugin.getMissionManager();
            if (mm == null) return 0;
            return (int) mm.getActiveMissions(clan).stream()
                    .filter(m -> !m.isCompleted() && !m.isExpired())
                    .count();
        } catch (Exception e) {
            return 0;
        }
    }

    // ══════════════════════════════════════════════════════════
    //  GETTERS
    // ══════════════════════════════════════════════════════════

    public Inventory getInventory() {
        return inventory;
    }

    public Player getPlayer() {
        return player;
    }
}
