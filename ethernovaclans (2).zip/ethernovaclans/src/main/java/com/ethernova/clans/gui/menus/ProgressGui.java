package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.level.ClanLevelManager;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Progress GUI showing clan level, XP/power progress, boosts, stats, and missions.
 */
public class ProgressGui extends AbstractGui {

    public ProgressGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "progress");
    }

    @Override
    protected void populateItems() {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return;

        ClanLevelManager levelMgr = plugin.getLevelManager();
        int level = clan.getLevel();
        int nextLevel = Math.min(level + 1, levelMgr.getMaxLevel());

        ClanLevelManager.LevelData currentData = levelMgr.getLevelData(level);
        ClanLevelManager.LevelData nextData = levelMgr.getLevelData(nextLevel);

        // Level progress bar
        if (nextData != null && currentData != null && nextLevel > level) {
            int currentPower = (int) clan.getPower();
            int needed = nextData.powerRequired();
            int from = currentData.powerRequired();
            int progress = currentPower - from;
            int total = needed - from;

            String bar = TextUtil.progressBar(progress, total);
            String pct = TextUtil.percentage(progress, total);

            setItem(13, new ItemBuilder(Material.EXPERIENCE_BOTTLE)
                    .name("<gold>Nivel " + level + " → " + nextLevel)
                    .lore(List.of(
                            "",
                            "<gray>Power: <white>" + currentPower + " / " + needed,
                            bar + " <white>" + pct,
                            "",
                            "<gray>Siguiente nivel desbloquea:",
                            "<white>  Miembros Máx: " + nextData.maxMembers(),
                            "<white>  Territorios Máx: " + nextData.maxClaims(),
                            "<white>  Alianzas Máx: " + nextData.maxAllies()
                    ))
                    .glow()
                    .build());
        } else {
            setItem(13, new ItemBuilder(Material.NETHER_STAR)
                    .name("<gold>Nivel " + level + " <gray>(MÁX)")
                    .lore(List.of("<green>¡Has alcanzado el nivel máximo!"))
                    .glow()
                    .build());
        }

        // Current level benefits
        if (currentData != null) {
            setItem(29, new ItemBuilder(Material.POTION)
                    .name("<aqua>Beneficios del Nivel")
                    .lore(List.of(
                            "",
                            "<gray>Miembros Máx: <white>" + currentData.maxMembers(),
                            "<gray>Territorios Máx: <white>" + currentData.maxClaims(),
                            "<gray>Alianzas Máx: <white>" + currentData.maxAllies()
                    ))
                    .hideFlags()
                    .build());
        }

        // Stats overview
        setItem(31, new ItemBuilder(Material.BOOK)
                .name("<yellow>Estadísticas del Clan")
                .lore(List.of(
                        "",
                        "<gray>Kills: <white>" + clan.getKills(),
                        "<gray>Muertes: <white>" + clan.getDeaths(),
                        "<gray>K/D: <white>" + String.format("%.2f", clan.getKD()),
                        "",
                        "<gray>Guerras Ganadas: <green>" + clan.getWarsWon(),
                        "<gray>Guerras Perdidas: <red>" + clan.getWarsLost(),
                        "",
                        "<gray>Miembros: <white>" + clan.getMembers().size(),
                        "<gray>Aliados: <white>" + clan.getAllies().size(),
                        "<gray>Banco: <gold>" + TextUtil.formatCurrency(clan.getBank().getBalance())
                ))
                .build());

        // Level name
        if (currentData != null) {
            setItem(33, new ItemBuilder(Material.DIAMOND)
                    .name("<green>Nivel: " + currentData.name())
                    .lore(List.of(
                            "",
                            "<green>✔ " + currentData.name()
                    ))
                    .build());
        }

        // Missions preview
        var mm = plugin.getMissionManager();
        if (mm != null) {
            var missions = mm.getActiveMissions(clan);
            long completed = missions.stream().filter(m -> m.isCompleted()).count();
            long available = missions.stream().filter(m -> !m.isCompleted() && !m.isExpired()).count();
            setItem(20, new ItemBuilder(Material.WRITABLE_BOOK)
                    .name("<yellow>📋 Misiones")
                    .lore(List.of(
                            "",
                            "<gray>Completadas: <green>" + completed,
                            "<gray>Disponibles: <white>" + available,
                            "",
                            "<yellow>▶ Click para ver misiones"
                    ))
                    .build());
            slotActions.put(20, "OPEN_GUI:missions");
        }

        // Territory status
        int territories = plugin.getTerritoryManager().getClanClaims(clan.getId()).size();
        int maxClaims = currentData != null ? currentData.maxClaims() : 0;
        setItem(24, new ItemBuilder(Material.FILLED_MAP)
                .name("<green>🗺 Territorios")
                .lore(List.of(
                        "",
                        "<gray>Reclamados: <white>" + territories + "/" + maxClaims,
                        "<gray>Power: <white>" + String.format("%.0f", clan.getPower()),
                        "",
                        "<yellow>▶ Click para ver mapa"
                ))
                .build());
        slotActions.put(24, "OPEN_GUI:territory");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        return switch (action.toUpperCase()) {
            case "BACK" -> {
                plugin.getGuiManager().openMainMenu(player);
                yield true;
            }
            default -> false;
        };
    }
}
