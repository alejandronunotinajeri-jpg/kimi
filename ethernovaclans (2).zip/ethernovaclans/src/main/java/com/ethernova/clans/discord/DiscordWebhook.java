package com.ethernova.clans.discord;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import org.bukkit.Bukkit;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;

/**
 * Sends Discord webhook notifications for clan events.
 */
public class DiscordWebhook {

    private final EthernovaClans plugin;
    private final boolean enabled;
    private final String url;

    public DiscordWebhook(EthernovaClans plugin) {
        this.plugin = plugin;
        enabled = plugin.getConfigManager().getConfig().getBoolean("discord.enabled", false);
        url = plugin.getConfigManager().getConfig().getString("discord.webhook-url", "");
    }

    public void sendWarDeclaration(Clan attacker, Clan defender) {
        send("{\"embeds\":[{\"title\":\"⚔ Guerra Declarada\",\"description\":\"**" + escapeJson(attacker.getName()) + "** vs **" + escapeJson(defender.getName()) + "**\",\"color\":15158332}]}");
    }

    public void sendClanCreated(Clan clan) {
        send("{\"embeds\":[{\"title\":\"🏰 Nuevo Clan\",\"description\":\"**" + escapeJson(clan.getName()) + "** fundado\",\"color\":5763719}]}");
    }

    public void sendClanDisbanded(Clan clan) {
        send("{\"embeds\":[{\"title\":\"💔 Clan Disuelto\",\"description\":\"**" + escapeJson(clan.getName()) + "** disuelto\",\"color\":10038562}]}");
    }

    // ── Siege Events ──

    public void sendSiegeStarted(String attackerName, String defenderName, String chunkKey) {
        send("{\"embeds\":[{\"title\":\"🏰 Asedio Iniciado\","
                + "\"description\":\"**" + escapeJson(attackerName) + "** ha iniciado un asedio contra **"
                + escapeJson(defenderName) + "**\\nTerritorio: " + escapeJson(chunkKey) + "\","
                + "\"color\":15105570}]}");
    }

    public void sendSiegeComplete(String attackerName, String defenderName, boolean attackerWon) {
        String result = attackerWon
                ? "**" + escapeJson(attackerName) + "** conquistó territorio de **" + escapeJson(defenderName) + "**"
                : "**" + escapeJson(defenderName) + "** defendió con éxito contra **" + escapeJson(attackerName) + "**";
        int color = attackerWon ? 3066993 : 15158332;
        send("{\"embeds\":[{\"title\":\"🏳 Asedio Finalizado\",\"description\":\"" + result + "\",\"color\":" + color + "}]}");
    }

    // ── Member Events ──

    public void sendMemberJoin(String playerName, Clan clan) {
        send("{\"embeds\":[{\"title\":\"👋 Nuevo Miembro\","
                + "\"description\":\"**" + escapeJson(playerName) + "** se unió a **" + escapeJson(clan.getName()) + "**\","
                + "\"color\":3066993}]}");
    }

    public void sendMemberLeave(String playerName, Clan clan) {
        send("{\"embeds\":[{\"title\":\"🚶 Miembro Salió\","
                + "\"description\":\"**" + escapeJson(playerName) + "** dejó **" + escapeJson(clan.getName()) + "**\","
                + "\"color\":15105570}]}");
    }

    // ── Level Events ──

    public void sendLevelUp(Clan clan, int newLevel) {
        send("{\"embeds\":[{\"title\":\"⬆ Nivel Aumentado\","
                + "\"description\":\"**" + escapeJson(clan.getName()) + "** alcanzó el nivel **" + newLevel + "**\","
                + "\"color\":10181046}]}");
    }

    // ── Alliance Events ──

    public void sendAllianceFormed(Clan clan1, Clan clan2) {
        send("{\"embeds\":[{\"title\":\"🤝 Nueva Alianza\","
                + "\"description\":\"**" + escapeJson(clan1.getName()) + "** y **" + escapeJson(clan2.getName()) + "** formaron una alianza\","
                + "\"color\":3447003}]}");
    }

    public void sendAllianceBroken(Clan clan1, Clan clan2) {
        send("{\"embeds\":[{\"title\":\"💔 Alianza Rota\","
                + "\"description\":\"**" + escapeJson(clan1.getName()) + "** rompió su alianza con **" + escapeJson(clan2.getName()) + "**\","
                + "\"color\":10038562}]}");
    }

    // ── Diplomacy Events ──

    public void sendTreatyFormed(String clan1Name, String clan2Name, String treatyType) {
        send("{\"embeds\":[{\"title\":\"📜 Tratado Firmado\","
                + "\"description\":\"**" + escapeJson(clan1Name) + "** y **" + escapeJson(clan2Name)
                + "** firmaron un tratado de " + escapeJson(treatyType) + "\","
                + "\"color\":3447003}]}");
    }

    public void sendTreatyBroken(String clan1Name, String clan2Name, String treatyType) {
        send("{\"embeds\":[{\"title\":\"📜 Tratado Roto\","
                + "\"description\":\"**" + escapeJson(clan1Name) + "** rompió el tratado de "
                + escapeJson(treatyType) + " con **" + escapeJson(clan2Name) + "**\","
                + "\"color\":15158332}]}");
    }

    // ── War End ──

    public void sendWarEnd(Clan winner, Clan loser) {
        send("{\"embeds\":[{\"title\":\"🏆 Guerra Terminada\","
                + "\"description\":\"**" + escapeJson(winner.getName()) + "** venció a **" + escapeJson(loser.getName()) + "**\","
                + "\"color\":15844367}]}");
    }

    // ── Event ──

    public void sendEventActivated(String eventName) {
        send("{\"embeds\":[{\"title\":\"🎉 Evento Activado\","
                + "\"description\":\"El evento **" + escapeJson(eventName) + "** ha comenzado!\","
                + "\"color\":15844367}]}");
    }

    private static String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
    }

    private void send(String json) {
        if (!enabled || url.isBlank()) return;
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                HttpURLConnection conn = (HttpURLConnection) URI.create(url).toURL().openConnection();
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);
                try (OutputStream os = conn.getOutputStream()) { os.write(json.getBytes()); }
                conn.getResponseCode();
                conn.disconnect();
            } catch (Exception e) { plugin.getLogger().log(java.util.logging.Level.WARNING, "Discord error", e); }
        });
    }
}
