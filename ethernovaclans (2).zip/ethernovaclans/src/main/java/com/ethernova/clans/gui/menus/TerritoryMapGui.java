package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanManager;
import com.ethernova.clans.clan.ClanMember;
import com.ethernova.clans.clan.ClanRole;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Interactive territory map GUI (54 slots).
 * Shows a 9x5 grid of chunks (45 chunks visible) with navigation arrows.
 * Left-click a chunk to claim, right-click to unclaim.
 */
public class TerritoryMapGui extends AbstractGui {

    private int offsetX = 0;
    private int offsetZ = 0;

    // 9x5 map grid (rows 0-4, all 9 cols) — fills entire 54-slot inventory
    // Row 0 = slots 0-8, Row 1 = 9-17, Row 2 = 18-26, Row 3 = 27-35, Row 4 = 36-44
    // Row 5 (45-53) = action bar
    private static final int MAP_ROWS = 5;
    private static final int MAP_COLS = 9;

    /** Maps slot → chunk key for interactive claim/unclaim */
    private final Map<Integer, String> slotChunkKeys = new HashMap<>();
    private final Map<Integer, int[]> slotChunkCoords = new HashMap<>();

    public TerritoryMapGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "territory");
    }

    @Override
    protected int getMinimumSize() { return 54; }

    @Override
    protected void populateItems() {
        slotChunkKeys.clear();
        slotChunkCoords.clear();

        Clan playerClan = plugin.getClanManager().getClanByPlayer(player);
        int centerX = player.getLocation().getChunk().getX() + offsetX;
        int centerZ = player.getLocation().getChunk().getZ() + offsetZ;
        String worldName = player.getWorld().getName();

        int halfW = MAP_COLS / 2;  // 4
        int halfH = MAP_ROWS / 2;  // 2
        int playerChunkX = player.getLocation().getChunk().getX();
        int playerChunkZ = player.getLocation().getChunk().getZ();

        // Build the 9x5 map grid (rows 0-4)
        for (int row = 0; row < MAP_ROWS; row++) {
            for (int col = 0; col < MAP_COLS; col++) {
                int slot = row * 9 + col;
                int chunkX = centerX - halfW + col;
                int chunkZ = centerZ - halfH + row;

                String chunkKey = ClanManager.buildChunkKey(worldName, chunkX, chunkZ);
                Clan owner = plugin.getClanManager().getClaimOwner(chunkKey);

                slotChunkKeys.put(slot, chunkKey);
                slotChunkCoords.put(slot, new int[]{chunkX, chunkZ});

                boolean isPlayerPos = (chunkX == playerChunkX && chunkZ == playerChunkZ);

                Material paneMat;
                String name;
                List<String> lore = new ArrayList<>();
                lore.add("");
                lore.add("<gray>Chunk: <white>X:" + chunkX + " Z:" + chunkZ + "</white></gray>");

                if (owner == null) {
                    paneMat = isPlayerPos ? Material.WHITE_STAINED_GLASS_PANE : Material.GRAY_STAINED_GLASS_PANE;
                    name = isPlayerPos ? "<white>✦ Tu posición (Wilderness)</white>" : "<dark_gray>Wilderness</dark_gray>";
                    lore.add("<gray>Estado: <dark_gray>Sin reclamar</dark_gray></gray>");
                    lore.add("");
                    lore.add("<green>Click izquierdo → Reclamar</green>");
                } else if (playerClan != null && owner.getId().equals(playerClan.getId())) {
                    boolean isHQ = chunkKey.equals(playerClan.getHeadquartersChunk());
                    if (isPlayerPos) {
                        paneMat = isHQ ? Material.YELLOW_STAINED_GLASS_PANE : Material.LIME_STAINED_GLASS_PANE;
                        name = isHQ ? "<gold>✦ ⌂ Tu HQ (tu posición)</gold>" : "<green>✦ Tu territorio (tu posición)</green>";
                    } else {
                        paneMat = isHQ ? Material.YELLOW_STAINED_GLASS_PANE : Material.LIME_STAINED_GLASS_PANE;
                        name = isHQ ? "<gold>⌂ Tu HQ</gold>" : "<green>█ Tu territorio</green>";
                    }
                    lore.add("<gray>Clan: <green>" + owner.getName() + "</green></gray>");
                    if (isHQ) lore.add("<gold>Cuartel General</gold>");
                    lore.add("");
                    lore.add("<red>Click derecho → Liberar</red>");
                } else if (playerClan != null && playerClan.isAlly(owner.getId())) {
                    paneMat = Material.LIGHT_BLUE_STAINED_GLASS_PANE;
                    name = (isPlayerPos ? "<white>✦ </white>" : "") + "<aqua>█ " + owner.getName() + " (Aliado)</aqua>";
                    lore.add("<gray>Clan: <aqua>" + owner.getName() + "</aqua></gray>");
                    lore.add("<aqua>Aliado</aqua>");
                } else if (playerClan != null && playerClan.isRival(owner.getId())) {
                    paneMat = Material.RED_STAINED_GLASS_PANE;
                    name = (isPlayerPos ? "<white>✦ </white>" : "") + "<red>█ " + owner.getName() + " (Rival)</red>";
                    lore.add("<gray>Clan: <red>" + owner.getName() + "</red></gray>");
                    lore.add("<red>Rival</red>");
                } else {
                    paneMat = isPlayerPos ? Material.ORANGE_STAINED_GLASS_PANE : Material.YELLOW_STAINED_GLASS_PANE;
                    name = (isPlayerPos ? "<white>✦ </white>" : "") + "<yellow>█ " + owner.getName() + "</yellow>";
                    lore.add("<gray>Clan: <yellow>" + owner.getName() + "</yellow></gray>");
                }

                setItem(slot, new ItemBuilder(paneMat).name(name).lore(lore).build());
                slotActions.put(slot, "MAP_CLAIM:" + slot);
                rightClickActions.put(slot, "MAP_UNCLAIM:" + slot);
            }
        }

        // ── Row 5 (slots 45-53): Action bar with navigation arrows ──
        // Navigation arrows
        setItem(45, new ItemBuilder(Material.ARROW).name("<yellow>↑ Norte</yellow>")
                .lore(List.of("<gray>Mover mapa 4 chunks al norte</gray>")).build());
        slotActions.put(45, "NAV_NORTH");

        setItem(46, new ItemBuilder(Material.ARROW).name("<yellow>← Oeste</yellow>")
                .lore(List.of("<gray>Mover mapa 4 chunks al oeste</gray>")).build());
        slotActions.put(46, "NAV_WEST");

        setItem(47, new ItemBuilder(Material.ENDER_PEARL).name("<aqua>⊕ Centrar</aqua>")
                .lore(List.of("<gray>Resetear a tu posición</gray>")).build());
        slotActions.put(47, "NAV_CENTER");

        setItem(48, new ItemBuilder(Material.ARROW).name("<yellow>→ Este</yellow>")
                .lore(List.of("<gray>Mover mapa 4 chunks al este</gray>")).build());
        slotActions.put(48, "NAV_EAST");

        setItem(49, new ItemBuilder(Material.ARROW).name("<yellow>↓ Sur</yellow>")
                .lore(List.of("<gray>Mover mapa 4 chunks al sur</gray>")).build());
        slotActions.put(49, "NAV_SOUTH");

        // Quick actions
        setItem(51, new ItemBuilder(Material.LIME_BANNER).name("<green><bold>📌 Reclamar Actual</bold></green>")
                .lore(List.of("", "<gray>Reclama el chunk donde estás</gray>", "", "<yellow>Click para reclamar</yellow>")).build());
        slotActions.put(51, "CLAIM_CURRENT");

        setItem(52, new ItemBuilder(Material.RED_BANNER).name("<red><bold>🚫 Liberar Actual</bold></red>")
                .lore(List.of("", "<gray>Libera el chunk donde estás</gray>", "", "<yellow>Click para liberar</yellow>")).build());
        slotActions.put(52, "UNCLAIM_CURRENT");

        setItem(53, new ItemBuilder(Material.ARROW).name("<gray>← Volver</gray>")
                .lore(List.of("<dark_gray>Volver al menú principal</dark_gray>")).build());
        slotActions.put(53, "OPEN_GUI:main-menu");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        return switch (action.toUpperCase()) {
            case "NAV_NORTH"  -> { offsetZ -= 4; refreshMap(); yield true; }
            case "NAV_SOUTH"  -> { offsetZ += 4; refreshMap(); yield true; }
            case "NAV_WEST"   -> { offsetX -= 4; refreshMap(); yield true; }
            case "NAV_EAST"   -> { offsetX += 4; refreshMap(); yield true; }
            case "NAV_CENTER" -> { offsetX = 0; offsetZ = 0; refreshMap(); yield true; }

            // Claim the chunk where the player is standing
            case "CLAIM_CURRENT" -> {
                performClaim(player.getLocation().getChunk().getX(), player.getLocation().getChunk().getZ());
                yield true;
            }
            case "UNCLAIM_CURRENT" -> {
                performUnclaim(player.getLocation().getChunk().getX(), player.getLocation().getChunk().getZ());
                yield true;
            }
            case "TOGGLE_AUTOCLAIM" -> {
                player.closeInventory();
                player.performCommand("clan autoclaim");
                yield true;
            }
            case "SET_HQ" -> {
                Clan clan = plugin.getClanManager().getClanByPlayer(player);
                if (clan == null) yield true;
                var hqMember = clan.getMember(player.getUniqueId());
                if (hqMember == null || !hqMember.getRole().isAtLeast(ClanRole.CO_LEADER)) {
                    player.sendMessage(plugin.getConfigManager().getMessage("general.no-permission"));
                    com.ethernova.clans.util.SoundUtil.error(player);
                    yield true;
                }
                String chunkKey = ClanManager.buildChunkKey(
                        player.getWorld().getName(),
                        player.getLocation().getChunk().getX(),
                        player.getLocation().getChunk().getZ());
                Clan chunkOwner = plugin.getClanManager().getClaimOwner(chunkKey);
                if (chunkOwner == null || !chunkOwner.getId().equals(clan.getId())) {
                    player.sendMessage(plugin.getConfigManager().getMessage("territory.hq-must-be-own-land"));
                    yield true;
                }
                clan.setHeadquartersChunk(chunkKey);
                player.sendMessage(plugin.getConfigManager().getMessage("territory.hq-set"));
                plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () ->
                        plugin.getStorageManager().saveClan(clan));
                refreshMap();
                yield true;
            }
            case "UNCLAIM_ALL" -> {
                Clan clan2 = plugin.getClanManager().getClanByPlayer(player);
                if (clan2 == null) yield true;
                ClanMember mem = clan2.getMember(player.getUniqueId());
                if (mem == null || mem.getRole() != ClanRole.LEADER) {
                    player.sendMessage(plugin.getConfigManager().getMessage("error.leader-only"));
                    yield true;
                }
                int removed = plugin.getClanManager().unclaimAllChunks(clan2);
                player.sendMessage(plugin.getConfigManager().getMessage("territory.unclaimed-all",
                        "count", String.valueOf(removed)));
                if (plugin.getAuditManager() != null) {
                    plugin.getAuditManager().log(clan2, player,
                            "UNCLAIM_ALL", removed + " chunks");
                }
                com.ethernova.clans.util.SoundUtil.success(player);
                refreshMap();
                yield true;
            }

            default -> {
                // Map click: claim or unclaim a specific chunk from the grid
                if (action.startsWith("MAP_CLAIM:")) {
                    int targetSlot = Integer.parseInt(action.substring("MAP_CLAIM:".length()));
                    int[] coords = slotChunkCoords.get(targetSlot);
                    if (coords != null) performClaim(coords[0], coords[1]);
                    yield true;
                }
                if (action.startsWith("MAP_UNCLAIM:")) {
                    int targetSlot = Integer.parseInt(action.substring("MAP_UNCLAIM:".length()));
                    int[] coords = slotChunkCoords.get(targetSlot);
                    if (coords != null) performUnclaim(coords[0], coords[1]);
                    yield true;
                }
                yield false;
            }
        };
    }

    // ── Claim Logic ──────────────────────────────────────────

    private void performClaim(int chunkX, int chunkZ) {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) {
            player.sendMessage(plugin.getConfigManager().getMessage("error.not-in-clan"));
            return;
        }
        ClanMember member = clan.getMember(player.getUniqueId());
        if (member == null) return;

        // Permission check
        if (!PermissionsGui.hasPermission(clan, member, "claim")) {
            player.sendMessage(plugin.getConfigManager().getMessage("error.no-permission"));
            return;
        }

        String worldName = player.getWorld().getName();
        String chunkKey = ClanManager.buildChunkKey(worldName, chunkX, chunkZ);

        // Already claimed?
        Clan owner = plugin.getClanManager().getClaimOwner(chunkKey);
        if (owner != null) {
            if (owner.getId().equals(clan.getId())) {
                player.sendMessage(plugin.getConfigManager().getMessage("territory.already-claimed-own"));
            } else {
                player.sendMessage(plugin.getConfigManager().getMessage("territory.already-claimed-other"));
            }
            return;
        }

        // Max claims check
        int current = plugin.getClanManager().getClanClaims(clan.getId()).size();
        int max = plugin.getLevelManager().getLevelData(clan.getLevel()) != null
                ? plugin.getLevelManager().getLevelData(clan.getLevel()).maxClaims() : 0;
        if (current >= max) {
            player.sendMessage(plugin.getConfigManager().getMessage("territory.max-claims"));
            return;
        }

        // Spawn protection check
        org.bukkit.World world = player.getWorld();
        int spawnRadius = Bukkit.getServer().getSpawnRadius();
        if (spawnRadius > 0) {
            Location spawnLoc = world.getSpawnLocation();
            int blockMinX = chunkX << 4;
            int blockMinZ = chunkZ << 4;
            int closestX = Math.max(blockMinX, Math.min(spawnLoc.getBlockX(), blockMinX + 15));
            int closestZ = Math.max(blockMinZ, Math.min(spawnLoc.getBlockZ(), blockMinZ + 15));
            int maxDist = Math.max(Math.abs(closestX - spawnLoc.getBlockX()), Math.abs(closestZ - spawnLoc.getBlockZ()));
            if (maxDist <= spawnRadius) {
                player.sendMessage(plugin.getConfigManager().getMessage("territory.protected-area"));
                return;
            }
        }

        // WorldGuard protection check
        if (plugin.getWorldGuardHook() != null && plugin.getWorldGuardHook().isAvailable()) {
            org.bukkit.Chunk targetChunk = world.getChunkAt(chunkX, chunkZ);
            if (!plugin.getWorldGuardHook().canClaimChunk(targetChunk)) {
                player.sendMessage(plugin.getConfigManager().getMessage("territory.protected-area"));
                return;
            }
        }

        // Perform claim
        plugin.getClanManager().claimChunk(chunkKey, clan.getId());
        player.sendMessage(plugin.getConfigManager().getMessage("territory.claimed",
                "x", String.valueOf(chunkX), "z", String.valueOf(chunkZ)));

        // Audit log
        if (plugin.getAuditManager() != null) {
            plugin.getAuditManager().log(clan, player,
                    "CLAIM", "Chunk " + chunkX + "," + chunkZ);
        }

        // Save async
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () ->
                plugin.getStorageManager().saveTerritory(chunkKey, clan.getId()));

        refreshMap();
    }

    private void performUnclaim(int chunkX, int chunkZ) {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) {
            player.sendMessage(plugin.getConfigManager().getMessage("error.not-in-clan"));
            return;
        }
        ClanMember member = clan.getMember(player.getUniqueId());
        if (member == null) return;

        if (!PermissionsGui.hasPermission(clan, member, "claim")) {
            player.sendMessage(plugin.getConfigManager().getMessage("error.no-permission"));
            return;
        }

        String worldName = player.getWorld().getName();
        String chunkKey = ClanManager.buildChunkKey(worldName, chunkX, chunkZ);

        Clan owner = plugin.getClanManager().getClaimOwner(chunkKey);
        if (owner == null || !owner.getId().equals(clan.getId())) {
            player.sendMessage(plugin.getConfigManager().getMessage("territory.not-own-chunk"));
            return;
        }

        // Don't allow unclaiming HQ unless it's the last chunk
        if (chunkKey.equals(clan.getHeadquartersChunk())) {
            int claimCount = plugin.getClanManager().getClanClaims(clan.getId()).size();
            if (claimCount > 1) {
                player.sendMessage(plugin.getConfigManager().getMessage("territory.cannot-unclaim-hq"));
                return;
            }
        }

        plugin.getClanManager().unclaimChunk(chunkKey);
        player.sendMessage(plugin.getConfigManager().getMessage("territory.unclaimed",
                "x", String.valueOf(chunkX), "z", String.valueOf(chunkZ)));

        if (plugin.getAuditManager() != null) {
            plugin.getAuditManager().log(clan, player,
                    "UNCLAIM", "Chunk " + chunkX + "," + chunkZ);
        }

        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () ->
                plugin.getStorageManager().deleteTerritory(chunkKey));

        refreshMap();
    }

    private void refreshMap() {
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            slotActions.clear();
            rightClickActions.clear();
            slotConfigs.clear();
            occupiedSlots.clear();
            fillBackground();
            placeConfigItems();
            populateItems();
        });
    }
}
