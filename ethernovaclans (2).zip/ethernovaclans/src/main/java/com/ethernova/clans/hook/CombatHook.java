package com.ethernova.clans.hook;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Reflection-based hook to EthernovaCombat.
 * All methods are safe to call even if Combat is not installed.
 */
public class CombatHook {

    private static final Logger logger = Logger.getLogger(CombatHook.class.getName());

    private Object api;
    private final boolean available;

    public CombatHook() {
        boolean found = false;
        try {
            if (Bukkit.getPluginManager().getPlugin("EthernovaCombat") != null) {
                Class<?> combatClass = Class.forName("com.ethernova.combat.EthernovaCombat");
                Object combatInstance = combatClass.getMethod("getInstance").invoke(null);
                if (combatInstance != null) {
                    Class<?> apiClass = Class.forName("com.ethernova.combat.tag.CombatAPI");
                    api = apiClass.getConstructor(combatClass).newInstance(combatInstance);
                    found = true;
                }
            }
        } catch (Exception e) {
            logger.fine("EthernovaCombat not available: " + e.getMessage());
        }
        this.available = found;
    }

    public boolean isAvailable() { return available; }

    public boolean isInCombat(Player player) {
        return invokeBoolean("isInCombat", new Class[]{Player.class}, player);
    }

    public boolean isInCombat(UUID uuid) {
        return invokeBoolean("isInCombat", new Class[]{UUID.class}, uuid);
    }

    public void tagForWar(Player attacker, Player victim) {
        if (!available) return;
        try {
            api.getClass().getMethod("tag", Player.class, Player.class, String.class).invoke(api, attacker, victim, "war");
            api.getClass().getMethod("tag", Player.class, Player.class, String.class).invoke(api, victim, attacker, "war");
        } catch (Exception e) {
            logger.log(Level.WARNING, "Failed to tag players for war combat", e);
        }
    }

    public void untag(Player player) {
        if (!available) return;
        try { api.getClass().getMethod("untag", Player.class).invoke(api, player); }
        catch (Exception e) { logger.log(Level.WARNING, "Failed to untag player from combat", e); }
    }

    public int getKillStreak(UUID uuid) {
        return invokeInt("getKillStreak", new Class[]{UUID.class}, uuid);
    }

    public boolean isNewbieProtected(UUID uuid) {
        return invokeBoolean("isNewbieProtected", new Class[]{UUID.class}, uuid);
    }

    private boolean invokeBoolean(String method, Class<?>[] types, Object... args) {
        if (!available || api == null) return false;
        try { return (boolean) api.getClass().getMethod(method, types).invoke(api, args); }
        catch (Exception e) { logger.fine("CombatHook.invokeBoolean failed [" + method + "]: " + e.getMessage()); return false; }
    }

    private int invokeInt(String method, Class<?>[] types, Object... args) {
        if (!available || api == null) return 0;
        try { return (int) api.getClass().getMethod(method, types).invoke(api, args); }
        catch (Exception e) { logger.fine("CombatHook.invokeInt failed [" + method + "]: " + e.getMessage()); return 0; }
    }
}
