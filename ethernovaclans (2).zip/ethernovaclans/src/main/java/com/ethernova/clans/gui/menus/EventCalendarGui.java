package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanMember;
import com.ethernova.clans.clan.ClanRole;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.scheduledevent.EventScheduler;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.SoundUtil;
import com.ethernova.clans.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Event Calendar GUI - Shows available and active scheduled events.
 * Leaders/admins can activate events; all members can view them.
 */
public class EventCalendarGui extends AbstractGui {

    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("dd/MM HH:mm")
            .withZone(ZoneId.systemDefault());

    public EventCalendarGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "event-calendar");
    }

    @Override
    protected void populateItems() {
        EventScheduler scheduler = plugin.getEventScheduler();
        if (scheduler == null) return;

        // ── Header ──
        Collection<EventScheduler.ActiveEvent> active = scheduler.getActiveEvents();
        setItem(4, new ItemBuilder(Material.CLOCK)
                .name("<gradient:#FF6B6B:#FFE66D>📅 Calendario de Eventos</gradient>")
                .lore(List.of(
                        "",
                        "<gray>Eventos activos: <green>" + active.size(),
                        "<gray>Eventos disponibles: <white>" + scheduler.getAllDefinitions().size(),
                        "",
                        "<gray>Los eventos dan bonificaciones",
                        "<gray>a todo el servidor temporalmente."
                ))
                .build());

        // ── Active events (top row) ──
        int activeSlot = 10;
        for (EventScheduler.ActiveEvent ev : active) {
            if (activeSlot > 16) break;
            long remaining = ev.getRemainingMillis();
            String timeLeft = formatDuration(remaining);

            setItem(activeSlot, new ItemBuilder(Material.BEACON)
                    .name("<green>🟢 " + ev.getDisplayName())
                    .lore(List.of(
                            "",
                            "<gray>Tipo: <yellow>" + ev.getType().getDisplayName(),
                            "<gray>Multiplicador: <gold>" + ev.getMultiplier() + "x",
                            "<gray>Tiempo restante: <white>" + timeLeft,
                            "",
                            "<red>Click → Terminar evento (admin)"
                    ))
                    .glowIf(true)
                    .build());
            slotActions.put(activeSlot, "END_EVENT:" + ev.getId());
            activeSlot++;
        }

        // Fill remaining active slots
        for (int s = activeSlot; s <= 16; s++) {
            setItem(s, new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE)
                    .name("<dark_gray>Sin evento activo")
                    .build());
        }

        // ── Available events (rows 3-5) ──
        int[] availableSlots = {19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};
        int idx = 0;

        for (EventScheduler.EventDefinition def : scheduler.getAllDefinitions()) {
            if (idx >= availableSlots.length) break;
            boolean isActive = scheduler.hasActiveEvent(def.id());

            Material icon;
            String status;
            switch (def.type()) {
                case DOUBLE_POWER -> icon = Material.DIAMOND_SWORD;
                case DOUBLE_MONEY -> icon = Material.GOLD_INGOT;
                case KOTH -> icon = Material.GOLDEN_HELMET;
                case HAPPY_HOUR -> icon = Material.EXPERIENCE_BOTTLE;
                default -> icon = Material.NETHER_STAR;
            }

            List<String> lore = new ArrayList<>();
            lore.add("");
            lore.add("<gray>Tipo: <yellow>" + def.type().getDisplayName());
            lore.add("<gray>Duración: <white>" + formatDuration(def.duration()));
            lore.add("<gray>Cooldown: <white>" + formatDuration(def.cooldown()));
            lore.add("<gray>Multiplicador: <gold>" + def.multiplier() + "x");
            lore.add("");

            if (isActive) {
                status = "<green>● ACTIVO";
                lore.add("<green>⚡ Este evento está activo.");
            } else {
                status = "<gray>○ Disponible";
                lore.add("<yellow>Click → Activar evento (admin)");
            }

            setItem(availableSlots[idx], new ItemBuilder(icon)
                    .name("<gold>" + def.displayName() + " " + status)
                    .lore(lore)
                    .glowIf(isActive)
                    .build());
            slotActions.put(availableSlots[idx], isActive ? "END_EVENT:" + def.id() : "ACTIVATE:" + def.id());
            idx++;
        }

        // ── Info item ──
        setItem(49, new ItemBuilder(Material.BOOK)
                .name("<yellow>ℹ Información")
                .lore(List.of(
                        "<gray>Los eventos se activan",
                        "<gray>globalmente y afectan",
                        "<gray>a todo el servidor.",
                        "",
                        "<gray>Solo líderes y admins",
                        "<gray>pueden activar/terminar."
                ))
                .build());
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (!player.hasPermission("ethernova.clans.admin") && !player.hasPermission("ethernova.clans.events")) {
            Clan clan = plugin.getClanManager().getClanByPlayer(player);
            if (clan != null) {
                ClanMember m = clan.getMember(player.getUniqueId());
                if (m == null || !m.getRole().isAtLeast(ClanRole.LEADER)) {
                    player.sendMessage(plugin.getConfigManager().getMessage("scheduled-events.no-permission"));
                    SoundUtil.error(player);
                    return true;
                }
            } else {
                player.sendMessage(plugin.getConfigManager().getMessage("error.no-permission"));
                return true;
            }
        }

        EventScheduler scheduler = plugin.getEventScheduler();
        if (scheduler == null) return false;

        if (action.startsWith("ACTIVATE:")) {
            String eventId = action.substring("ACTIVATE:".length());
            if (scheduler.activateEvent(eventId)) {
                player.sendMessage(plugin.getConfigManager().getMessage("scheduled-events.activated",
                        "event", eventId));
                SoundUtil.success(player);
                plugin.getAuditManager().log(plugin.getClanManager().getClanByPlayer(player), player, "EVENT_ACTIVATE", "Activated event: " + eventId);
                if (plugin.getDiscordWebhook() != null) plugin.getDiscordWebhook().sendEventActivated(eventId);
            } else {
                player.sendMessage(plugin.getConfigManager().getMessage("scheduled-events.cannot-activate"));
                SoundUtil.error(player);
            }
            refreshGui();
            return true;
        }

        if (action.startsWith("END_EVENT:")) {
            String eventId = action.substring("END_EVENT:".length());
            scheduler.endEvent(eventId, true);
            player.sendMessage(plugin.getConfigManager().getMessage("scheduled-events.stopped",
                    "event", eventId));
            SoundUtil.click(player);
            plugin.getAuditManager().log(plugin.getClanManager().getClanByPlayer(player), player, "EVENT_END", "Ended event: " + eventId);
            refreshGui();
            return true;
        }

        return false;
    }

    private String formatDuration(long millis) {
        long seconds = millis / 1000;
        long hours = seconds / 3600;
        long mins = (seconds % 3600) / 60;
        long secs = seconds % 60;
        if (hours > 0) return hours + "h " + mins + "m";
        if (mins > 0) return mins + "m " + secs + "s";
        return secs + "s";
    }

    private void refreshGui() {
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            occupiedSlots.clear();
            slotActions.clear();
            rightClickActions.clear();
            slotConfigs.clear();
            fillBackground();
            placeConfigItems();
            populateItems();
        });
    }
}
