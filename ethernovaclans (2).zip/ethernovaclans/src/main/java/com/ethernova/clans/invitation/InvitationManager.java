package com.ethernova.clans.invitation;

import com.ethernova.clans.EthernovaClans;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages clan invitations with expiry.
 */
public class InvitationManager {

    private final EthernovaClans plugin;
    /** Map of player UUID -> Map of clan ID -> invite entry. Supports multiple concurrent invites. */
    private final Map<UUID, Map<String, InviteEntry>> pending = new ConcurrentHashMap<>();

    public InvitationManager(EthernovaClans plugin) {
        this.plugin = plugin;
        // Periodically clean up expired invitations to prevent memory leak
        org.bukkit.Bukkit.getScheduler().runTaskTimer(plugin, this::cleanExpired, 20L * 60, 20L * 60);
    }

    public void invite(UUID playerUuid, String clanId) {
        long duration = plugin.getConfigManager().getConfig().getLong("clans.invite-expiry-seconds", 120) * 1000L;
        pending.computeIfAbsent(playerUuid, k -> new ConcurrentHashMap<>())
                .put(clanId, new InviteEntry(clanId, System.currentTimeMillis() + duration));
    }

    /** Get the first (or only) invited clan ID. For backwards compatibility. */
    public String getInvitedClanId(UUID playerUuid) {
        Map<String, InviteEntry> invites = pending.get(playerUuid);
        if (invites == null) return null;
        long now = System.currentTimeMillis();
        for (var it = invites.entrySet().iterator(); it.hasNext(); ) {
            var e = it.next();
            if (now >= e.getValue().expiry) { it.remove(); continue; }
            return e.getValue().clanId;
        }
        if (invites.isEmpty()) pending.remove(playerUuid);
        return null;
    }

    /** Check if a player has a pending invite from a specific clan. */
    public String getInvitedClanId(UUID playerUuid, String clanId) {
        Map<String, InviteEntry> invites = pending.get(playerUuid);
        if (invites == null) return null;
        InviteEntry e = invites.get(clanId);
        if (e == null) return null;
        if (System.currentTimeMillis() >= e.expiry) { invites.remove(clanId); return null; }
        return e.clanId;
    }

    /** Get all pending (non-expired) clan IDs for a player. */
    public java.util.List<String> getPendingClanIds(UUID playerUuid) {
        Map<String, InviteEntry> invites = pending.get(playerUuid);
        if (invites == null) return java.util.List.of();
        long now = System.currentTimeMillis();
        java.util.List<String> result = new java.util.ArrayList<>();
        for (var it = invites.entrySet().iterator(); it.hasNext(); ) {
            var e = it.next();
            if (now >= e.getValue().expiry) { it.remove(); } else { result.add(e.getKey()); }
        }
        if (invites.isEmpty()) pending.remove(playerUuid);
        return result;
    }

    public void removeInvitation(UUID playerUuid) { pending.remove(playerUuid); }

    public void removeInvitation(UUID playerUuid, String clanId) {
        Map<String, InviteEntry> invites = pending.get(playerUuid);
        if (invites != null) {
            invites.remove(clanId);
            if (invites.isEmpty()) pending.remove(playerUuid);
        }
    }

    /** Remove all expired invitations to prevent memory accumulation. */
    private void cleanExpired() {
        long now = System.currentTimeMillis();
        pending.entrySet().removeIf(playerEntry -> {
            playerEntry.getValue().entrySet().removeIf(e -> now >= e.getValue().expiry);
            return playerEntry.getValue().isEmpty();
        });
    }

    private record InviteEntry(String clanId, long expiry) {}
}
