package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.SoundUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.List;

/**
 * Wars GUI - declare wars, view war types, active wars, war history.
 */
public class WarsGui extends AbstractGui {

    private int warPage = 0;
    private static final int[] WAR_SLOTS = {10, 11, 12, 13, 14, 15, 16};

    public WarsGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "wars");
    }

    @Override
    protected void populateItems() {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return;

        // Dynamic active war items in the GUI
        if (plugin.getWarManager() != null) {
            var wars = plugin.getWarManager().getActiveWars(clan);
            int[] warSlots = {10, 11, 12, 13, 14, 15, 16}; // Row 2 for active wars
            for (int i = 0; i < warSlots.length && i < wars.size(); i++) {
                var war = wars.get(i);
                String opponentId = war.getAttackerId().equals(clan.getId()) ? war.getDefenderId() : war.getAttackerId();
                Clan opponent = plugin.getClanManager().getClanById(opponentId);
                String oppName = opponent != null ? opponent.getName() : "Unknown";
                String oppTag = opponent != null ? opponent.getFormattedTag() : "???";
                int myScore = war.getKills(clan.getId());
                int theirScore = war.getKills(opponentId);
                int remainSecs = war.getRemainingSeconds();
                String timeLeft = remainSecs > 0 ? (remainSecs / 60) + "m " + (remainSecs % 60) + "s" : "Ending...";

                setItem(warSlots[i], new ItemBuilder(Material.IRON_SWORD)
                        .name("<red>⚔ " + oppTag + " " + oppName)
                        .lore(List.of(
                                "<gray>Puntuación: <green>" + myScore + " <gray>vs <red>" + theirScore,
                                "<gray>Tiempo: <yellow>" + timeLeft,
                                "",
                                "<red>Click to surrender"
                        ))
                        .build());
                slotActions.put(warSlots[i], "SURRENDER");
            }
        }
    }

    private void handleDeclareWar() {
        player.closeInventory();
        player.sendMessage(plugin.getConfigManager().getMessage("war.enter-target"));
        plugin.getGuiManager().registerAnvilInput(player, input -> {
            Clan myClan = plugin.getClanManager().getClanByPlayer(player);
            if (myClan == null) return;
            Clan target = plugin.getClanManager().getClanByName(input);
            if (target == null) {
                player.sendMessage(plugin.getConfigManager().getMessage("war.clan-not-found",
                        "name", input));
                return;
            }
            if (target.getId().equals(myClan.getId())) {
                player.sendMessage(plugin.getConfigManager().getMessage("war.cant-self"));
                return;
            }
            if (plugin.getWarManager() != null) {
                plugin.getWarManager().requestWar(myClan, target,
                        com.ethernova.clans.war.WarManager.WarType.DEATHMATCH);
            }
            plugin.getServer().getScheduler().runTask(plugin, () ->
                    plugin.getGuiManager().openWars(player));
        });
    }

    private void handleSurrender(Clan clan) {
        if (plugin.getWarManager() != null) {
            var member = clan.getMember(player.getUniqueId());
            if (member == null || !member.getRole().isAtLeast(com.ethernova.clans.clan.ClanRole.CO_LEADER)) {
                player.sendMessage(plugin.getConfigManager().getMessage("general.no-permission"));
                SoundUtil.error(player);
                return;
            }
            plugin.getWarManager().surrender(clan);
            SoundUtil.error(player);
            refreshGui();
        }
    }

    private void showActiveWars(Clan clan) {
        if (plugin.getWarManager() == null) {
            player.sendMessage(plugin.getConfigManager().getMessage("war.system-unavailable"));
            return;
        }
        var wars = plugin.getWarManager().getActiveWars(clan);
        if (wars.isEmpty()) {
            player.sendMessage(plugin.getConfigManager().getMessage("war.no-active-wars"));
            return;
        }
        player.sendMessage(plugin.getConfigManager().getMessage("war.active-wars-header",
                "count", String.valueOf(wars.size())));
        for (var war : wars) {
            String opponentId = war.getAttackerId().equals(clan.getId()) ? war.getDefenderId() : war.getAttackerId();
            Clan opponent = plugin.getClanManager().getClanById(opponentId);
            String oppName = opponent != null ? opponent.getName() : "Unknown";
            int myScore = war.getKills(clan.getId());
            int theirScore = war.getKills(opponentId);
            int remainSecs = war.getRemainingSeconds();
            String timeLeft = remainSecs > 0 ? (remainSecs / 60) + "m " + (remainSecs % 60) + "s" : "Ending...";
            player.sendMessage(plugin.getConfigManager().getMessage("war.active-war-entry",
                    "opponent", oppName,
                    "my_score", String.valueOf(myScore),
                    "their_score", String.valueOf(theirScore),
                    "time", timeLeft));
        }
    }

    private void showWarHistory(Clan clan) {
        player.sendMessage(plugin.getConfigManager().getMessage("war.history-header"));
        player.sendMessage(plugin.getConfigManager().getMessage("war.history-won",
                "count", String.valueOf(clan.getWarsWon())));
        player.sendMessage(plugin.getConfigManager().getMessage("war.history-lost",
                "count", String.valueOf(clan.getWarsLost())));
        int total = clan.getWarsWon() + clan.getWarsLost();
        String winrate = total > 0 ? String.format("%.1f", (clan.getWarsWon() * 100.0 / total)) : "N/A";
        player.sendMessage(plugin.getConfigManager().getMessage("war.history-winrate",
                "rate", winrate));
        player.sendMessage(plugin.getConfigManager().getMessage("war.history-kills",
                "count", String.valueOf(clan.getTotalKills())));
        player.sendMessage(plugin.getConfigManager().getMessage("war.history-deaths",
                "count", String.valueOf(clan.getTotalDeaths())));
        player.sendMessage(plugin.getConfigManager().getMessage("war.history-kd",
                "kd", String.format("%.2f", clan.getKD())));
        if (plugin.getWarManager() != null) {
            int active = plugin.getWarManager().getActiveWars(clan).size();
            player.sendMessage(plugin.getConfigManager().getMessage("war.history-active",
                    "count", String.valueOf(active)));
        }
    }

    private void refreshGui() {
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            occupiedSlots.clear();
            slotActions.clear();
            rightClickActions.clear();
            slotConfigs.clear();
            fillBackground();
            placeConfigItems();
            populateItems();
        });
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return false;

        // Handle OPEN_GUI: prefixed actions from YAML config
        if (action.equalsIgnoreCase("OPEN_GUI:war-declare")) {
            handleDeclareWar();
            return true;
        }
        if (action.equalsIgnoreCase("OPEN_GUI:active-wars")) {
            showActiveWars(clan);
            return true;
        }
        if (action.equalsIgnoreCase("OPEN_GUI:war-history")) {
            showWarHistory(clan);
            return true;
        }

        // Handle CONFIRM: prefixed actions from YAML config
        if (action.toUpperCase().startsWith("CONFIRM:")) {
            String suffix = action.substring("CONFIRM:".length()).trim().toLowerCase();
            if (suffix.equals("surrender")) {
                handleSurrender(clan);
                return true;
            }
        }

        // Page navigation
        switch (action.toUpperCase()) {
            case "WAR_PREV_PAGE" -> { warPage = Math.max(0, warPage - 1); refreshGui(); return true; }
            case "WAR_NEXT_PAGE" -> { warPage++; refreshGui(); return true; }
        }

        // Legacy / direct action labels
        return switch (action.toUpperCase()) {
            case "DECLARE_WAR" -> {
                handleDeclareWar();
                yield true;
            }
            case "SURRENDER" -> {
                handleSurrender(clan);
                yield true;
            }
            case "WAR_HISTORY" -> {
                showWarHistory(clan);
                yield true;
            }
            default -> false;
        };
    }
}
