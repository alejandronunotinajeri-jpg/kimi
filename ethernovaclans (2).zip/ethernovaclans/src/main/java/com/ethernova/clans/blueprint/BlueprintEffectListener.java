package com.ethernova.clans.blueprint;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Listener that applies blueprint effects in territory.
 * Handles: Hospital (regen), Muralla (debuffs), Forja (combat buffs), Torre (alerts).
 */
public class BlueprintEffectListener implements Listener {

    private final EthernovaClans plugin;
    private BukkitTask passiveTask;
    private BukkitTask incomeTask;
    /** Tracks watchtower alert cooldowns to prevent spam */
    private final Map<String, Long> towerAlertCooldown = new ConcurrentHashMap<>();

    public BlueprintEffectListener(EthernovaClans plugin) {
        this.plugin = plugin;
        startPassiveEffects();
        startPassiveIncome();
    }

    /**
     * Periodic passive effects: Hospital (regen) + Muralla (debuffs on enemies).
     */
    private void startPassiveEffects() {
        passiveTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            BlueprintManager bm = plugin.getBlueprintManager();
            if (bm == null || !bm.isEnabled()) return;

            for (Player player : Bukkit.getOnlinePlayers()) {
                String chunkId = getChunkId(player);
                String owner = plugin.getTerritoryManager().getOwner(chunkId);
                if (owner == null) continue;

                Clan playerClan = plugin.getClanManager().getClanByPlayer(player.getUniqueId());

                if (playerClan != null && playerClan.getId().equals(owner)) {
                    // Player is in OWN territory — apply friendly effects

                    // Hospital: Regeneration
                    double regenLevel = bm.getTotalEffect(owner, "regen-level");
                    if (regenLevel > 0) {
                        int amplifier = (int) regenLevel - 1;
                        player.addPotionEffect(new PotionEffect(
                                PotionEffectType.REGENERATION, 25 * 20, amplifier, true, false, true));
                    }

                    // Forja: Strength in own territory
                    double strengthLevel = bm.getTotalEffect(owner, "strength-level");
                    if (strengthLevel > 0) {
                        player.addPotionEffect(new PotionEffect(
                                PotionEffectType.STRENGTH, 25 * 20, (int) strengthLevel - 1, true, false, true));
                    }

                    // Forja: Resistance in own territory
                    double resistLevel = bm.getTotalEffect(owner, "resistance-level");
                    if (resistLevel > 0) {
                        player.addPotionEffect(new PotionEffect(
                                PotionEffectType.RESISTANCE, 25 * 20, (int) resistLevel - 1, true, false, true));
                    }
                } else {
                    // Player is in ENEMY territory — apply hostile effects (Muralla)
                    double slowLevel = bm.getTotalEffect(owner, "slowness-level");
                    if (slowLevel > 0) {
                        player.addPotionEffect(new PotionEffect(
                                PotionEffectType.SLOWNESS, 25 * 20, (int) slowLevel - 1, true, false, true));
                    }
                    double fatigueLevel = bm.getTotalEffect(owner, "mining-fatigue-level");
                    if (fatigueLevel > 0) {
                        player.addPotionEffect(new PotionEffect(
                                PotionEffectType.MINING_FATIGUE, 25 * 20, (int) fatigueLevel - 1, true, false, true));
                    }
                }
            }
        }, 20L * 15, 20L * 15); // Every 15 seconds
    }

    /**
     * Passive income from Farm blueprint — every hour.
     */
    private void startPassiveIncome() {
        incomeTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            BlueprintManager bm = plugin.getBlueprintManager();
            if (bm == null || !bm.isEnabled()) return;

            for (Clan clan : plugin.getClanManager().getAllClans()) {
                double income = bm.getTotalEffect(clan.getId(), "passive-income");
                if (income > 0) {
                    double currentBal = plugin.getBankManager().getBalance(clan.getId());
                    plugin.getBankManager().setBalance(clan.getId(), currentBal + income);
                    // Notify online members
                    for (var member : clan.getOnlineMembers()) {
                        Player p = Bukkit.getPlayer(member.getUuid());
                        if (p != null) {
                            plugin.getMessageManager().sendMessage(p, "blueprint.income-received",
                                    "{amount}", String.format("%.0f", income));
                        }
                    }
                }
            }
        }, 20L * 60 * 60, 20L * 60 * 60); // Every hour
    }

    /**
     * Torre de Vigilancia: Alert when enemy enters territory.
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEnemyEnter(PlayerMoveEvent event) {
        if (event.getTo() == null || event.getFrom().getChunk().equals(event.getTo().getChunk())) return;

        Player player = event.getPlayer();
        String toChunkId = getChunkId(player);
        String owner = plugin.getTerritoryManager().getOwner(toChunkId);
        if (owner == null) return;

        Clan playerClan = plugin.getClanManager().getClanByPlayer(player.getUniqueId());
        if (playerClan != null && playerClan.getId().equals(owner)) return; // Own territory
        if (playerClan != null && playerClan.isAlly(owner)) return; // Allied territory

        BlueprintManager bm = plugin.getBlueprintManager();
        if (bm == null || !bm.isEnabled()) return;

        double towerRadius = bm.getTotalEffect(owner, "watchtower-radius");
        if (towerRadius <= 0) return;

        // Cooldown check
        String cooldownKey = owner + ":" + player.getUniqueId();
        long now = System.currentTimeMillis();
        Long last = towerAlertCooldown.get(cooldownKey);
        if (last != null && now - last < 30_000) return; // 30s cooldown
        towerAlertCooldown.put(cooldownKey, now);

        // Alert clan members
        Clan ownerClan = plugin.getClanManager().getClan(owner);
        if (ownerClan == null) return;
        for (var member : ownerClan.getOnlineMembers()) {
            Player p = Bukkit.getPlayer(member.getUuid());
            if (p != null) {
                plugin.getMessageManager().sendMessage(p, "blueprint.tower-alert",
                        "{player}", player.getName(), "{chunk}", toChunkId);
                p.playSound(p.getLocation(), org.bukkit.Sound.BLOCK_BELL_USE, 1.0f, 1.0f);
            }
        }
    }

    private String getChunkId(Player player) {
        var chunk = player.getLocation().getChunk();
        return chunk.getWorld().getName() + ":" + chunk.getX() + ":" + chunk.getZ();
    }

    public void shutdown() {
        if (passiveTask != null) passiveTask.cancel();
        if (incomeTask != null) incomeTask.cancel();
    }
}
