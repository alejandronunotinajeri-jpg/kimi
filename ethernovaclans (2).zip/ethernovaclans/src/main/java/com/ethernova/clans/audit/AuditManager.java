package com.ethernova.clans.audit;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import org.bukkit.entity.Player;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages the audit log for clan actions.
 * Tracks deposits, withdrawals, invites, kicks, claims, upgrades, wars, etc.
 */
public class AuditManager {

    private final EthernovaClans plugin;

    /** Audit entries per clan: clanId -> list of entries (newest first) */
    private final Map<String, List<AuditEntry>> logs = new ConcurrentHashMap<>();

    private static final int MAX_ENTRIES_PER_CLAN = 100;
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM HH:mm");

    public AuditManager(EthernovaClans plugin) {
        this.plugin = plugin;
    }

    /**
     * Log an action to the clan's audit log.
     *
     * @param clan     The clan
     * @param player   The player who performed the action (can be null for system actions)
     * @param action   Action type (DEPOSIT, WITHDRAW, INVITE, KICK, CLAIM, UNCLAIM, UPGRADE, WAR, SETTINGS, etc.)
     * @param details  Human-readable detail string
     */
    public void log(Clan clan, Player player, String action, String details) {
        if (clan == null) return;

        String playerName = player != null ? player.getName() : "Sistema";
        UUID playerUuid = player != null ? player.getUniqueId() : null;
        long timestamp = Instant.now().toEpochMilli();

        AuditEntry entry = new AuditEntry(playerUuid, playerName, action, details, timestamp);

        logs.computeIfAbsent(clan.getId(), k -> Collections.synchronizedList(new ArrayList<>()));
        List<AuditEntry> clanLog = logs.get(clan.getId());

        clanLog.add(0, entry); // Add at beginning (newest first)

        // Trim to max size
        while (clanLog.size() > MAX_ENTRIES_PER_CLAN) {
            clanLog.remove(clanLog.size() - 1);
        }

        // Persist to DB asynchronously
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () ->
                plugin.getStorageManager().saveAuditEntry(
                        clan.getId(),
                        playerUuid != null ? playerUuid.toString() : null,
                        playerName, action, details, timestamp));
    }

    /**
     * Get the audit log for a clan with pagination.
     *
     * @param clan     The clan
     * @param page     Page number (0-indexed)
     * @param pageSize Items per page
     * @return List of audit entries for the page
     */
    public List<AuditEntry> getLog(Clan clan, int page, int pageSize) {
        List<AuditEntry> clanLog = logs.getOrDefault(clan.getId(), List.of());
        if (clanLog.isEmpty()) {
            // Try loading from database
            return loadFromDB(clan.getId(), page, pageSize);
        }
        int start = page * pageSize;
        if (start >= clanLog.size()) return List.of();
        int end = Math.min(start + pageSize, clanLog.size());
        return clanLog.subList(start, end);
    }

    /**
     * Get total number of entries for a clan.
     */
    public int getTotalEntries(Clan clan) {
        List<AuditEntry> clanLog = logs.getOrDefault(clan.getId(), List.of());
        if (clanLog.isEmpty()) {
            return plugin.getStorageManager().getAuditLogCount(clan.getId());
        }
        return clanLog.size();
    }

    /**
     * Load entries from DB as AuditEntry records.
     */
    private List<AuditEntry> loadFromDB(String clanId, int page, int pageSize) {
        var rows = plugin.getStorageManager().loadAuditLog(clanId, page, pageSize);
        List<AuditEntry> result = new ArrayList<>();
        for (var row : rows) {
            UUID uuid = row.playerUuid() != null ? UUID.fromString(row.playerUuid()) : null;
            result.add(new AuditEntry(uuid, row.playerName(), row.action(), row.details(), row.timestamp()));
        }
        return result;
    }

    /**
     * Get the icon for an action type.
     */
    public static String getActionIcon(String action) {
        return switch (action.toUpperCase()) {
            case "DEPOSIT" -> "<green>💰";
            case "WITHDRAW" -> "<red>💸";
            case "INVITE" -> "<aqua>📩";
            case "KICK" -> "<red>🚫";
            case "JOIN" -> "<green>✚";
            case "LEAVE" -> "<yellow>🚪";
            case "CLAIM" -> "<green>🗺";
            case "UNCLAIM" -> "<red>🗺";
            case "UPGRADE" -> "<gold>⬆";
            case "WAR_START" -> "<red>⚔";
            case "WAR_END" -> "<yellow>🏳";
            case "SETTINGS" -> "<white>⚙";
            case "PROMOTE" -> "<green>⬆";
            case "DEMOTE" -> "<red>⬇";
            case "ALLY" -> "<aqua>🤝";
            case "RIVAL" -> "<red>⚡";
            default -> "<gray>📋";
        };
    }

    /**
     * Format a timestamp for display.
     */
    public static String formatTimestamp(long timestampMillis) {
        LocalDateTime time = LocalDateTime.ofInstant(
                Instant.ofEpochMilli(timestampMillis), ZoneId.systemDefault());
        return FORMATTER.format(time);
    }

    /**
     * Load audit entries for a clan (from storage).
     */
    public void loadEntries(String clanId, List<AuditEntry> entries) {
        logs.put(clanId, Collections.synchronizedList(new ArrayList<>(entries)));
    }

    /**
     * Get all entries for a clan (for saving).
     */
    public List<AuditEntry> getAllEntries(String clanId) {
        return logs.getOrDefault(clanId, List.of());
    }

    /**
     * Cleanup logs for a disbanded clan.
     */
    public void removeClan(String clanId) {
        logs.remove(clanId);
    }

    // ══════════════════════════════════════════════════════════
    //  RECORD
    // ══════════════════════════════════════════════════════════

    public record AuditEntry(
            UUID playerUuid,
            String playerName,
            String action,
            String details,
            long timestamp
    ) {}
}
