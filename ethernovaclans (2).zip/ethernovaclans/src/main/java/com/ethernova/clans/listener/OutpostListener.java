package com.ethernova.clans.listener;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanMember;
import com.ethernova.clans.clan.ClanRole;
import com.ethernova.clans.outpost.Outpost;
import com.ethernova.clans.outpost.OutpostType;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * OutpostListener — protects outpost blocks and handles watchtower alerts.
 */
public class OutpostListener implements Listener {

    private final EthernovaClans plugin;
    private static final MiniMessage MINI = MiniMessage.miniMessage();

    // Cooldown for watchtower alerts (playerUUID → last alert time)
    private final ConcurrentHashMap<UUID, Long> watchtowerCooldowns = new ConcurrentHashMap<>();
    private static final long WATCHTOWER_ALERT_COOLDOWN_MS = 30_000; // 30 seconds

    public OutpostListener(EthernovaClans plugin) {
        this.plugin = plugin;
        // Periodically clean expired cooldown entries to prevent memory leak
        org.bukkit.Bukkit.getScheduler().runTaskTimer(plugin, () ->
            watchtowerCooldowns.entrySet().removeIf(e ->
                System.currentTimeMillis() - e.getValue() > WATCHTOWER_ALERT_COOLDOWN_MS * 2),
            20L * 60 * 5, 20L * 60 * 5); // every 5 minutes
    }

    /**
     * Prevent breaking outpost blocks unless the player is an officer+ of the owning clan.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        if (plugin.getOutpostManager() == null) return;

        Location loc = event.getBlock().getLocation();
        if (!plugin.getOutpostManager().isOutpostBlock(loc)) return;

        Player player = event.getPlayer();

        // Admin bypass
        if (player.hasPermission("ethernova.clans.bypass")) return;

        Outpost outpost = plugin.getOutpostManager().getOutpostAt(loc);
        if (outpost == null) return;

        Clan playerClan = plugin.getClanManager().getClanByPlayer(player.getUniqueId());

        // Not in a clan or not the owning clan → cancel always
        if (playerClan == null || !playerClan.getId().equals(outpost.getClanId())) {
            event.setCancelled(true);
            player.sendMessage(MINI.deserialize(
                    "<red>✘ Este bloque es un outpost (<white>" + outpost.getType().getDisplayName() +
                            "</white>). No puedes romperlo.</red>"));
            return;
        }

        // Own clan — require at least Officer + use the proper remove command
        ClanMember member = playerClan.getMember(player.getUniqueId());
        if (member == null || !member.getRole().isAtLeast(ClanRole.OFFICER)) {
            event.setCancelled(true);
            player.sendMessage(MINI.deserialize(
                    "<red>Solo oficiales+ pueden remover outposts. Usa <yellow>/clan outpost remove</yellow>.</red>"));
            return;
        }

        // Officer+ breaking own outpost — let it through and clean up
        event.setCancelled(true); // Still cancel the raw break, use the command
        player.sendMessage(MINI.deserialize(
                "<yellow>Usa <green>/clan outpost remove</green> parado sobre el outpost para removerlo correctamente.</yellow>"));
    }

    /**
     * Prevent explosions from destroying outpost blocks.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent event) {
        if (plugin.getOutpostManager() == null) return;
        event.blockList().removeIf(block -> plugin.getOutpostManager().isOutpostBlock(block.getLocation()));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent event) {
        if (plugin.getOutpostManager() == null) return;
        event.blockList().removeIf(block -> plugin.getOutpostManager().isOutpostBlock(block.getLocation()));
    }

    /**
     * Right-click an outpost block to see its info.
     */
    @EventHandler(priority = EventPriority.NORMAL)
    public void onInteract(PlayerInteractEvent event) {
        if (plugin.getOutpostManager() == null) return;
        if (event.getClickedBlock() == null) return;
        if (event.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;
        if (!event.getAction().name().contains("RIGHT")) return;

        Location loc = event.getClickedBlock().getLocation();
        Outpost outpost = plugin.getOutpostManager().getOutpostAt(loc);
        if (outpost == null) return;

        Player player = event.getPlayer();
        Clan ownerClan = plugin.getClanManager().getClan(outpost.getClanId());
        String ownerName = ownerClan != null ? ownerClan.getDisplayName() : "???";

        double hpPct = outpost.getHealthPercent() * 100;
        String hpColor = hpPct > 50 ? "<green>" : hpPct > 25 ? "<yellow>" : "<red>";

        player.sendMessage(MINI.deserialize(
                "<gray>═ " + outpost.getType().getPrefix() + " <gray>═</gray>"));
        player.sendMessage(MINI.deserialize(
                "<gray>Clan:</gray> <white>" + ownerName + "</white> <gray>| Nv.</gray><white>" +
                        outpost.getLevel() + "</white> <gray>| Salud:</gray> " + hpColor +
                        String.format("%.0f%%", hpPct) + "</gray>"));
    }

    /**
     * Watchtower alert: when an enemy enters a chunk covered by a watchtower,
     * notify the owning clan's online members.
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerMove(PlayerMoveEvent event) {
        if (plugin.getOutpostManager() == null) return;

        // Only trigger on chunk change
        if (event.getFrom().getChunk().equals(event.getTo().getChunk())) return;

        Player player = event.getPlayer();
        Chunk toChunk = event.getTo().getChunk();

        // Get the territory owner of the destination chunk
        String chunkKey = toChunk.getWorld().getName() + ":" + toChunk.getX() + ":" + toChunk.getZ();
        String owner = plugin.getTerritoryManager().getOwner(chunkKey);
        if (owner == null) return;

        // Player must not be from the owning clan (they're not an "enemy")
        Clan playerClan = plugin.getClanManager().getClanByPlayer(player.getUniqueId());
        if (playerClan != null && playerClan.getId().equals(owner)) return;

        // Check if this clan is allied to the territory owner
        Clan ownerClan = plugin.getClanManager().getClan(owner);
        if (ownerClan != null && playerClan != null && plugin.getAllianceManager().areAllied(ownerClan, playerClan)) return;

        // Check if the territory owner has watchtower coverage for this chunk
        if (!plugin.getOutpostManager().hasWatchtowerCoverage(owner, toChunk)) return;

        // Cooldown per player
        long now = System.currentTimeMillis();
        Long lastAlert = watchtowerCooldowns.get(player.getUniqueId());
        if (lastAlert != null && now - lastAlert < WATCHTOWER_ALERT_COOLDOWN_MS) return;
        watchtowerCooldowns.put(player.getUniqueId(), now);

        // Alert the owning clan
        if (ownerClan != null) {
            var alertMsg = MINI.deserialize(
                    "<yellow>⚐ <red>¡ALERTA!</red> <gray>Intruso detectado: <white>" + player.getName() +
                            "</white> en chunk (" + toChunk.getX() + ", " + toChunk.getZ() + ")</gray></yellow>");
            for (var member : ownerClan.getOnlineMembers()) {
                Player p = org.bukkit.Bukkit.getPlayer(member.getUuid());
                if (p != null) {
                    p.sendMessage(alertMsg);
                    p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 0.8f, 1.5f);
                }
            }
        }
    }
}
