package com.ethernova.clans.blueprint;

/**
 * Represents a built blueprint instance belonging to a clan.
 */
public class ClanBlueprint {

    private final String blueprintId;
    private final String clanId;
    private final String chunkId;   // "world:x:z"
    private int level;
    private final long builtAt;

    public ClanBlueprint(String blueprintId, String clanId, String chunkId, int level, long builtAt) {
        this.blueprintId = blueprintId;
        this.clanId = clanId;
        this.chunkId = chunkId;
        this.level = level;
        this.builtAt = builtAt;
    }

    public String getBlueprintId() { return blueprintId; }
    public String getClanId() { return clanId; }
    public String getChunkId() { return chunkId; }
    public int getLevel() { return level; }
    public void setLevel(int level) { this.level = level; }
    public long getBuiltAt() { return builtAt; }
}
