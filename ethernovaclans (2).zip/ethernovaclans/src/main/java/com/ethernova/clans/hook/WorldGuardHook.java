package com.ethernova.clans.hook;

import com.ethernova.clans.EthernovaClans;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.lang.reflect.Method;

/**
 * WorldGuard integration — prevents claiming in WG-protected regions.
 * Uses reflection to avoid compile-time dependency.
 */
public class WorldGuardHook {

    private final EthernovaClans plugin;
    private boolean available = false;
    private Object regionContainer;
    private Method getApplicableRegionsMethod;
    private Method sizeMethod;

    public WorldGuardHook(EthernovaClans plugin) {
        this.plugin = plugin;
        try {
            if (Bukkit.getPluginManager().getPlugin("WorldGuard") == null) return;

            // WorldGuard 7.x API
            Class<?> wgClass = Class.forName("com.sk89q.worldguard.WorldGuard");
            Object wgInstance = wgClass.getMethod("getInstance").invoke(null);
            Object platform = wgClass.getMethod("getPlatform").invoke(wgInstance);
            regionContainer = platform.getClass().getMethod("getRegionContainer").invoke(platform);

            Class<?> containerClass = regionContainer.getClass();
            Class<?> bukAdaptClass = Class.forName("com.sk89q.worldedit.bukkit.BukkitAdapter");

            // Cache reflection methods
            getApplicableRegionsMethod = null; // Will use dynamic lookup per call
            available = true;
            plugin.getLogger().info("[Hook] WorldGuard 7 detected — claim protection active");

        } catch (Exception e) {
            plugin.getLogger().info("[Hook] WorldGuard not found — skipping integration");
        }
    }

    public boolean isAvailable() {
        return available;
    }

    /**
     * Check if a location is inside a WorldGuard protected region.
     * Returns true if the location has ANY regions (claiming should be blocked there).
     */
    public boolean isInProtectedRegion(Location location) {
        if (!available || location == null || location.getWorld() == null) return false;

        try {
            Class<?> bukAdaptClass = Class.forName("com.sk89q.worldedit.bukkit.BukkitAdapter");
            Object weWorld = bukAdaptClass.getMethod("adapt", org.bukkit.World.class)
                    .invoke(null, location.getWorld());

            // Get the region manager for this world
            Object regionManager = regionContainer.getClass()
                    .getMethod("get", Class.forName("com.sk89q.worldedit.world.World"))
                    .invoke(regionContainer, weWorld);

            if (regionManager == null) return false;

            // Convert Location to BlockVector3
            Class<?> bv3Class = Class.forName("com.sk89q.worldedit.math.BlockVector3");
            Object position = bv3Class.getMethod("at", int.class, int.class, int.class)
                    .invoke(null, location.getBlockX(), location.getBlockY(), location.getBlockZ());

            // Get applicable regions at position
            Object regionSet = regionManager.getClass()
                    .getMethod("getApplicableRegions", bv3Class)
                    .invoke(regionManager, position);

            // Check if any regions exist (size > 0)
            int size = (int) regionSet.getClass().getMethod("size").invoke(regionSet);
            return size > 0;

        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Check if claiming should be allowed — checks center + all 4 corners
     * of the chunk to catch regions that only cover part of it.
     */
    public boolean canClaimChunk(org.bukkit.Chunk chunk) {
        if (!available) return true;
        int bx = chunk.getX() << 4;
        int bz = chunk.getZ() << 4;
        org.bukkit.World world = chunk.getWorld();
        // Check center and all 4 corners
        Location[] points = {
                new Location(world, bx + 8, 64, bz + 8),   // center
                new Location(world, bx, 64, bz),             // NW
                new Location(world, bx + 15, 64, bz),        // NE
                new Location(world, bx, 64, bz + 15),        // SW
                new Location(world, bx + 15, 64, bz + 15)    // SE
        };
        for (Location loc : points) {
            if (isInProtectedRegion(loc)) return false;
        }
        return true;
    }

    /**
     * Check if a player can build at a location considering WorldGuard flags.
     */
    public boolean canBuild(Player player, Location location) {
        if (!available) return true;
        try {
            Class<?> bukAdaptClass = Class.forName("com.sk89q.worldedit.bukkit.BukkitAdapter");
            Object weWorld = bukAdaptClass.getMethod("adapt", org.bukkit.World.class)
                    .invoke(null, location.getWorld());

            Object regionManager = regionContainer.getClass()
                    .getMethod("get", Class.forName("com.sk89q.worldedit.world.World"))
                    .invoke(regionContainer, weWorld);

            if (regionManager == null) return true;

            // Use WorldGuard's query API for BUILD flag
            Class<?> bv3Class = Class.forName("com.sk89q.worldedit.math.BlockVector3");
            Object position = bv3Class.getMethod("at", int.class, int.class, int.class)
                    .invoke(null, location.getBlockX(), location.getBlockY(), location.getBlockZ());

            Object regionSet = regionManager.getClass()
                    .getMethod("getApplicableRegions", bv3Class)
                    .invoke(regionManager, position);

            // If there are no regions, allow
            int size = (int) regionSet.getClass().getMethod("size").invoke(regionSet);
            return size == 0;

        } catch (Exception e) {
            return true;
        }
    }
}
