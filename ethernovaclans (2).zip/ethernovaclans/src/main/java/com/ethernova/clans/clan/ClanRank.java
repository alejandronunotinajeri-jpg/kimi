package com.ethernova.clans.clan;

import java.util.HashSet;
import java.util.Set;

/**
 * Custom clan rank with configurable permissions.
 * Higher priority = more authority (Leader = 1000, default Recruit = 0).
 */
public class ClanRank {

    private final String id;
    private String displayName;
    private String prefix;            // Shown in chat, e.g. "⚔"
    private int priority;             // Higher = more power; Leader is always highest
    private final Set<String> permissions;  // e.g. "claim", "invite", "kick", "bank.withdraw", "war.declare"
    private boolean isDefault;        // Whether this is the rank assigned to new members

    public ClanRank(String id, String displayName, int priority) {
        this.id = id;
        this.displayName = displayName;
        this.prefix = "";
        this.priority = priority;
        this.permissions = new HashSet<>();
        this.isDefault = false;
    }

    // ── Getters ────────────────────────────

    public String getId() { return id; }
    public String getDisplayName() { return displayName; }
    public String getPrefix() { return prefix; }
    public int getPriority() { return priority; }
    public Set<String> getPermissions() { return permissions; }
    public boolean isDefault() { return isDefault; }

    // ── Setters ────────────────────────────

    public void setDisplayName(String displayName) { this.displayName = displayName; }
    public void setPrefix(String prefix) { this.prefix = prefix; }
    public void setPriority(int priority) { this.priority = priority; }
    public void setDefault(boolean isDefault) { this.isDefault = isDefault; }

    // ── Permission helpers ─────────────────

    public boolean hasPermission(String permission) { return permissions.contains(permission); }
    public void addPermission(String permission) { permissions.add(permission); }
    public void removePermission(String permission) { permissions.remove(permission); }

    /**
     * Check if this rank has at least the same authority as another.
     */
    public boolean isAtLeast(ClanRank other) { return this.priority >= other.priority; }
    public boolean isHigherThan(ClanRank other) { return this.priority > other.priority; }

    /**
     * Convert legacy ClanRole to a default ClanRank id.
     */
    public static String fromLegacyRole(ClanRole role) {
        return switch (role) {
            case RECRUIT    -> "recruit";
            case MEMBER     -> "member";
            case OFFICER    -> "officer";
            case CO_LEADER  -> "co-leader";
            case LEADER     -> "leader";
        };
    }

    /**
     * Create the 5 default ranks that every new clan starts with.
     */
    public static java.util.List<ClanRank> createDefaults() {
        var ranks = new java.util.ArrayList<ClanRank>();

        ClanRank recruit = new ClanRank("recruit", "Recluta", 0);
        recruit.setPrefix("<gray>");
        recruit.setDefault(true);
        ranks.add(recruit);

        ClanRank member = new ClanRank("member", "Miembro", 100);
        member.setPrefix("<white>");
        member.addPermission("home");
        member.addPermission("warp");
        ranks.add(member);

        ClanRank officer = new ClanRank("officer", "Oficial", 200);
        officer.setPrefix("<yellow>");
        officer.addPermission("home");
        officer.addPermission("warp");
        officer.addPermission("setwarp");
        officer.addPermission("claim");
        officer.addPermission("invite");
        officer.addPermission("kick");
        officer.addPermission("bank.deposit");
        officer.addPermission("bank.withdraw");
        officer.addPermission("chat.officer");
        ranks.add(officer);

        ClanRank coLeader = new ClanRank("co-leader", "Co-Líder", 500);
        coLeader.setPrefix("<gold>");
        coLeader.addPermission("home");
        coLeader.addPermission("warp");
        coLeader.addPermission("setwarp");
        coLeader.addPermission("delwarp");
        coLeader.addPermission("claim");
        coLeader.addPermission("unclaim");
        coLeader.addPermission("invite");
        coLeader.addPermission("kick");
        coLeader.addPermission("promote");
        coLeader.addPermission("demote");
        coLeader.addPermission("bank.deposit");
        coLeader.addPermission("bank.withdraw");
        coLeader.addPermission("bank.pay");
        coLeader.addPermission("sethome");
        coLeader.addPermission("ally.request");
        coLeader.addPermission("chat.officer");
        coLeader.addPermission("upgrade");
        ranks.add(coLeader);

        ClanRank leader = new ClanRank("leader", "Líder", 1000);
        leader.setPrefix("<red>");
        leader.addPermission("*"); // All permissions
        ranks.add(leader);

        return ranks;
    }

    @Override
    public String toString() {
        return "ClanRank{id='" + id + "', priority=" + priority + ", perms=" + permissions.size() + "}";
    }
}
