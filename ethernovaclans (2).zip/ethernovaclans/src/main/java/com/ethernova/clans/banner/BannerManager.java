package com.ethernova.clans.banner;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.message.MessageManager;
import org.bukkit.*;
import org.bukkit.block.banner.Pattern;
import org.bukkit.block.banner.PatternType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BannerMeta;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.stream.Collectors;

/**
 * Clan Banner/Emblem system.
 * Each clan can design a custom banner that represents them.
 * Banners are saved to DB and can be placed in territory or given to members.
 */
public class BannerManager {

    private final EthernovaClans plugin;

    /** clanId → banner ItemStack (serialized) */
    private final Map<String, ItemStack> clanBanners = new ConcurrentHashMap<>();

    public BannerManager(EthernovaClans plugin) {
        this.plugin = plugin;
    }

    // ══════════════════════════════════════════════════════════
    //  CRUD
    // ══════════════════════════════════════════════════════════

    /**
     * Set the clan banner from the item the player is holding.
     */
    public boolean setBannerFromHand(Player player, Clan clan) {
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item == null || !item.getType().name().contains("BANNER")) {
            plugin.getMessageManager().sendMessage(player, "banner.must-hold-banner");
            return false;
        }

        ItemStack banner = item.clone();
        banner.setAmount(1);
        clanBanners.put(clan.getId(), banner);
        plugin.getMessageManager().sendMessage(player, "banner.set-success");
        return true;
    }

    /**
     * Give the clan banner to a player.
     */
    public void giveBanner(Player player, Clan clan) {
        ItemStack banner = clanBanners.get(clan.getId());
        if (banner == null) {
            plugin.getMessageManager().sendMessage(player, "banner.no-banner");
            return;
        }

        ItemStack copy = banner.clone();
        BannerMeta meta = (BannerMeta) copy.getItemMeta();
        if (meta != null) {
            meta.displayName(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                    .deserialize("<gold>⚔ Banner de " + clan.getName()));
            copy.setItemMeta(meta);
        }
        player.getInventory().addItem(copy);
        plugin.getMessageManager().sendMessage(player, "banner.received");
    }

    /**
     * Get the clan banner or null if not set.
     */
    public ItemStack getBanner(String clanId) {
        return clanBanners.get(clanId);
    }

    /**
     * Remove the clan banner (e.g., on disband).
     */
    public void removeBanner(String clanId) {
        clanBanners.remove(clanId);
    }

    /**
     * Set a banner directly for a clan.
     */
    public void setBanner(String clanId, org.bukkit.inventory.ItemStack banner) {
        org.bukkit.inventory.ItemStack copy = banner.clone();
        copy.setAmount(1);
        clanBanners.put(clanId, copy);
    }

    /**
     * Get a default banner for the clan (alias for createDefaultBanner).
     */
    public ItemStack getDefaultBanner(Clan clan) {
        return createDefaultBanner(clan);
    }

    /**
     * Create a default banner from clan tag color.
     */
    public ItemStack createDefaultBanner(Clan clan) {
        ItemStack banner = new ItemStack(Material.WHITE_BANNER);
        BannerMeta meta = (BannerMeta) banner.getItemMeta();
        if (meta != null) {
            // Use tag hash to pick a color
            int hash = Math.abs(clan.getTag().hashCode());
            DyeColor[] colors = DyeColor.values();
            DyeColor primary = colors[hash % colors.length];
            DyeColor secondary = colors[(hash / 16) % colors.length];

            meta.addPattern(new Pattern(primary, PatternType.STRIPE_CENTER));
            meta.addPattern(new Pattern(secondary, PatternType.TRIANGLE_BOTTOM));
            meta.addPattern(new Pattern(DyeColor.BLACK, PatternType.BORDER));
            meta.displayName(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                    .deserialize("<gold>⚔ Banner de " + clan.getName()));
            banner.setItemMeta(meta);
        }
        return banner;
    }

    // ══════════════════════════════════════════════════════════
    //  PERSISTENCE
    // ══════════════════════════════════════════════════════════

    public void loadAll() {
        clanBanners.clear();
        try (Connection conn = plugin.getStorageManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT clan_id, banner_data FROM clan_banners")) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String clanId = rs.getString("clan_id");
                byte[] data = rs.getBytes("banner_data");
                if (data != null) {
                    try {
                        ItemStack banner = ItemStack.deserializeBytes(data);
                        clanBanners.put(clanId, banner);
                    } catch (Exception e) {
                        plugin.getLogger().warning("Failed to deserialize banner for clan " + clanId);
                    }
                }
            }
        } catch (Exception e) {
            // Table may not exist yet
            plugin.getLogger().log(Level.FINE, "Error loading banners", e);
        }
    }

    public void saveAll() {
        try (Connection conn = plugin.getStorageManager().getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement del = conn.prepareStatement("DELETE FROM clan_banners");
                 PreparedStatement ins = conn.prepareStatement(
                         "INSERT INTO clan_banners (clan_id, banner_data) VALUES (?, ?)")) {
                del.executeUpdate();
                for (var entry : clanBanners.entrySet()) {
                    ins.setString(1, entry.getKey());
                    ins.setBytes(2, entry.getValue().serializeAsBytes());
                    ins.addBatch();
                }
                ins.executeBatch();
                conn.commit();
            } catch (Exception e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error saving banners", e);
        }
    }

    public void shutdown() {
        saveAll();
    }
}
