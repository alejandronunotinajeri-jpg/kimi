package com.ethernova.clans.event;

import com.ethernova.clans.clan.Clan;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

/**
 * Fired when a player joins a clan.
 */
public class ClanMemberJoinEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();

    private final Clan clan;
    private final Player player;

    public ClanMemberJoinEvent(Clan clan, Player player) {
        this.clan = clan;
        this.player = player;
    }

    public Clan getClan() { return clan; }
    public Player getPlayer() { return player; }

    @Override public @NotNull HandlerList getHandlers() { return HANDLERS; }
    public static HandlerList getHandlerList() { return HANDLERS; }
}
