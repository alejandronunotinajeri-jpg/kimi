package com.ethernova.clans.hook;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.UUID;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Reflection-based hook to EthernovaCore.
 * All methods are safe to call even if Core is not installed.
 */
public class CoreHook {

    private static final Logger logger = Logger.getLogger(CoreHook.class.getName());

    private Object core;
    private final boolean available;

    public CoreHook() {
        boolean found = false;
        try {
            if (Bukkit.getPluginManager().getPlugin("EthernovaCore") != null) {
                Class<?> cls = Class.forName("com.ethernova.core.EthernovaCore");
                core = cls.getMethod("getInstance").invoke(null);
                found = core != null;
            }
        } catch (Exception e) {
            logger.fine("EthernovaCore not available: " + e.getMessage());
        }
        this.available = found;
    }

    public boolean isAvailable() { return available; }

    /**
     * Get the EthernovaCore instance.
     * Returns null if Core is not available.
     */
    public com.ethernova.core.EthernovaCore getCore() {
        return available && core instanceof com.ethernova.core.EthernovaCore ec ? ec : null;
    }

    // ── Context ──────────────────────────────────────────────
    public void addContext(UUID uuid, String context) {
        invoke("getContextManager", "addContext", new Class[]{UUID.class, String.class}, uuid, context);
    }

    public void removeContext(UUID uuid, String context) {
        invoke("getContextManager", "removeContext", new Class[]{UUID.class, String.class}, uuid, context);
    }

    public boolean hasContext(UUID uuid, String context) {
        Object result = invoke("getContextManager", "hasContext", new Class[]{UUID.class, String.class}, uuid, context);
        return result instanceof Boolean b && b;
    }

    // ── EventBus ─────────────────────────────────────────────
    public void publishEvent(Object event) {
        if (!available) return;
        try {
            Object bus = core.getClass().getMethod("getEventBus").invoke(core);
            bus.getClass().getMethod("publish", Object.class).invoke(bus, event);
        } catch (Exception e) {
            logger.log(Level.WARNING, "Failed to publish event via CoreHook", e);
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public void subscribeEvent(Class<?> type, Consumer listener) {
        if (!available) return;
        try {
            Object bus = core.getClass().getMethod("getEventBus").invoke(core);
            bus.getClass().getMethod("subscribe", Class.class, Consumer.class).invoke(bus, type, listener);
        } catch (Exception e) {
            logger.log(Level.WARNING, "Failed to subscribe event via CoreHook", e);
        }
    }

    // ── Visual ───────────────────────────────────────────────
    public void sendTitle(Player player, String title, String subtitle) {
        invoke("getVisualManager", "sendTitle", new Class[]{Player.class, String.class, String.class}, player, title, subtitle);
    }

    public void sendActionBar(Player player, String message) {
        invoke("getVisualManager", "sendActionBar", new Class[]{Player.class, String.class}, player, message);
    }

    // ── Hologram ─────────────────────────────────────────────
    public Object getHologramHook() {
        if (!available) return null;
        try { return core.getClass().getMethod("getHologramHook").invoke(core); }
        catch (Exception e) { logger.fine("Hologram hook not available: " + e.getMessage()); return null; }
    }

    // ── ServerMode ───────────────────────────────────────
    /**
     * Get the current server mode. Falls back to SURVIVAL if Core is unavailable.
     */
    public com.ethernova.core.server.ServerMode getServerMode() {
        if (!available) return com.ethernova.core.server.ServerMode.SURVIVAL;
        try {
            Object mgr = core.getClass().getMethod("getServerModeManager").invoke(core);
            Object mode = mgr.getClass().getMethod("getMode").invoke(mgr);
            return mode instanceof com.ethernova.core.server.ServerMode sm ? sm : com.ethernova.core.server.ServerMode.SURVIVAL;
        } catch (Exception e) { logger.fine("ServerMode lookup failed: " + e.getMessage()); return com.ethernova.core.server.ServerMode.SURVIVAL; }
    }

    /**
     * Convenience: true if the current server mode supports territory features.
     */
    public boolean hasTerritory() {
        return getServerMode().hasTerritory();
    }

    /**
     * Check if a feature is enabled for the current mode (with config override).
     */
    public boolean isFeatureEnabled(String feature, boolean defaultForMode) {
        if (!available) return defaultForMode;
        try {
            Object mgr = core.getClass().getMethod("getServerModeManager").invoke(core);
            Object result = mgr.getClass().getMethod("isFeatureEnabled", String.class, boolean.class)
                    .invoke(mgr, feature, defaultForMode);
            return result instanceof Boolean b ? b : defaultForMode;
        } catch (Exception e) { logger.fine("Feature check failed for '" + feature + "': " + e.getMessage()); return defaultForMode; }
    }

    // ── Registration ─────────────────────────────────────────
    public void register() {
        if (!available) return;
        try { core.getClass().getMethod("registerPlugin", String.class).invoke(core, "EthernovaClans"); }
        catch (Exception e) { logger.log(Level.WARNING, "Failed to register with Core", e); }
    }

    public void unregister() {
        if (!available) return;
        try { core.getClass().getMethod("unregisterPlugin", String.class).invoke(core, "EthernovaClans"); }
        catch (Exception e) { logger.log(Level.WARNING, "Failed to unregister from Core", e); }
    }

    // ── Helper ───────────────────────────────────────────────
    private Object invoke(String managerGetter, String method, Class<?>[] paramTypes, Object... args) {
        if (!available) return null;
        try {
            Object manager = core.getClass().getMethod(managerGetter).invoke(core);
            return manager.getClass().getMethod(method, paramTypes).invoke(manager, args);
        } catch (Exception e) { logger.fine("Invoke failed [" + managerGetter + "." + method + "]: " + e.getMessage()); return null; }
    }

    // ── Cooldowns ────────────────────────────────────────────
    public void setCooldown(UUID uuid, String key, long ms) {
        invoke("getCooldownManager", "setCooldown", new Class[]{UUID.class, String.class, long.class}, uuid, key, ms);
    }

    public boolean hasCooldown(UUID uuid, String key) {
        Object result = invoke("getCooldownManager", "hasCooldown", new Class[]{UUID.class, String.class}, uuid, key);
        return result instanceof Boolean b && b;
    }

    public String getRemainingFormatted(UUID uuid, String key) {
        Object result = invoke("getCooldownManager", "getRemainingFormatted", new Class[]{UUID.class, String.class}, uuid, key);
        return result instanceof String s ? s : "0s";
    }

    // ── Profiles ─────────────────────────────────────────────
    public Object getProfile(UUID uuid) {
        if (!available) return null;
        try {
            Object mgr = core.getClass().getMethod("getProfileManager").invoke(core);
            return mgr.getClass().getMethod("getProfile", UUID.class).invoke(mgr, uuid);
        } catch (Exception e) { logger.fine("Profile lookup failed for " + uuid + ": " + e.getMessage()); return null; }
    }
}
