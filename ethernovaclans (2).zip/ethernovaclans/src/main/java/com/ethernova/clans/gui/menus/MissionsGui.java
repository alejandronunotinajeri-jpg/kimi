package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.mission.MissionManager;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * GUI showing active missions and their progress.
 */
public class MissionsGui extends AbstractGui {

    private static final int[] MISSION_SLOTS = {
            20, 22, 24,
            29, 31, 33
    };

    public MissionsGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "missions");
    }

    @Override
    protected void populateItems() {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return;

        MissionManager mm = plugin.getMissionManager();
        if (mm == null) return;

        List<MissionManager.ActiveMission> missions = mm.getActiveMissions(clan);
        if (missions == null) missions = List.of();

        // Title header
        setItem(4, new ItemBuilder(Material.MAP)
                .name("<gradient:#FFD700:#FFA500>📜 Misiones del Clan</gradient>")
                .lore(List.of(
                        "",
                        "<gray>Misiones activas: <yellow>" + missions.size(),
                        "<gray>Completa misiones para ganar",
                        "<gray>Power y dinero para tu clan.",
                        "",
                        "<gray>Las misiones se renuevan diariamente."
                ))
                .glow()
                .build());

        if (missions.isEmpty()) {
            setItem(22, new ItemBuilder(Material.BARRIER)
                    .name("<gray>No hay misiones activas")
                    .lore(List.of(
                            "",
                            "<gray>Las misiones se asignan automáticamente.",
                            "<gray>Vuelve más tarde."
                    ))
                    .build());
            return;
        }

        for (int i = 0; i < MISSION_SLOTS.length && i < missions.size(); i++) {
            try {
                MissionManager.ActiveMission mission = missions.get(i);
                MissionManager.MissionDefinition def = mm.getDefinition(mission.getDefinitionId());
                if (def == null) continue;

                boolean completed = mission.isCompleted();
                boolean expired = mission.isExpired();

                Material mat = Material.PAPER;
                if (def.icon() != null) {
                    try {
                        mat = Material.valueOf(def.icon().toUpperCase());
                    } catch (IllegalArgumentException ignored) {}
                }

                String status;
                if (completed) {
                    status = "<green>✔ Completada";
                } else if (expired) {
                    status = "<red>✘ Expirada";
                } else {
                    status = "<yellow>⏳ En progreso";
                }

                String progressBar = TextUtil.progressBar(mission.getProgress(), mission.getTarget());
                String progressPct = String.format("%.0f%%", mission.getProgressPercent());

                // Time remaining
                String timeLeft = "Expirada";
                if (!expired && !completed && mission.getExpiresAt() != null) {
                    Duration remaining = Duration.between(Instant.now(), mission.getExpiresAt());
                    if (!remaining.isNegative()) {
                        long hours = remaining.toHours();
                        long mins = remaining.toMinutes() % 60;
                        timeLeft = hours > 0 ? hours + "h " + mins + "m" : mins + "m";
                    }
                }

                String displayName = def.displayName() != null ? def.displayName() : mission.getDefinitionId();
                String description = def.description() != null ? def.description() : "";

                List<String> lore = new ArrayList<>(List.of(
                        "",
                        "<gray>" + description,
                        "",
                        "<gray>Progreso: <white>" + mission.getProgress() + "/" + mission.getTarget(),
                        progressBar + " <white>" + progressPct,
                        "",
                        "<gray>Tiempo restante: <yellow>" + timeLeft,
                        "<gray>Estado: " + status,
                        "",
                        "<gray>Recompensas:",
                        "<gold>  ⚡ +" + def.powerReward() + " Power"
                ));

                if (def.moneyReward() > 0) {
                    lore.add("<gold>  💰 $" + TextUtil.formatCurrency(def.moneyReward()));
                }

                setItem(MISSION_SLOTS[i], new ItemBuilder(mat)
                        .name((completed ? "<green>✔ " : "<yellow>") + displayName)
                        .lore(lore)
                        .glowIf(completed)
                        .build());
            } catch (Exception e) {
                plugin.getLogger().log(java.util.logging.Level.WARNING, "Error rendering mission item", e);
            }
        }
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        // Handle OPEN_GUI: actions explicitly so back-to-menu always works
        if (action.toUpperCase().startsWith("OPEN_GUI:")) {
            String guiName = action.substring("OPEN_GUI:".length());
            plugin.getServer().getScheduler().runTask(plugin, () ->
                    plugin.getGuiManager().openGui(player, guiName));
            return true;
        }
        if (action.equalsIgnoreCase("BACK")) {
            plugin.getServer().getScheduler().runTask(plugin, () ->
                    plugin.getGuiManager().openMainMenu(player));
            return true;
        }
        return false;
    }
}
