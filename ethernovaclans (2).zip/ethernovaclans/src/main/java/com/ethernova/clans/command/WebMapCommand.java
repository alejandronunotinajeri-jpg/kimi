package com.ethernova.clans.command;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.webmap.WebAuthManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.stream.Collectors;

/**
 * /webmap command — register and manage web password.
 * <p>
 * Usage:
 *   /webmap register &lt;password&gt;  — Register a web account
 *   /webmap changepass &lt;password&gt; — Change your web password
 */
public class WebMapCommand implements CommandExecutor, TabCompleter {

    private final EthernovaClans plugin;

    public WebMapCommand(EthernovaClans plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.getMessageManager().sendMessage(sender, "general.player-only");
            return true;
        }

        if (args.length == 0) {
            showUsage(player);
            return true;
        }

        WebAuthManager auth = plugin.getWebAuthManager();
        if (auth == null) {
            plugin.getMessageManager().sendMessage(player, "webmap.disabled");
            return true;
        }

        String sub = args[0].toLowerCase();
        switch (sub) {
            case "register", "registrar" -> handleRegister(player, args, auth);
            case "changepass", "cambiarpass" -> handleChangePass(player, args, auth);
            default -> showUsage(player);
        }
        return true;
    }

    private void handleRegister(Player player, String[] args, WebAuthManager auth) {
        if (auth.hasAccount(player.getUniqueId())) {
            plugin.getMessageManager().sendMessage(player, "webmap.already-registered");
            return;
        }
        if (args.length < 2) {
            plugin.getMessageManager().sendMessage(player, "webmap.register-usage");
            return;
        }
        String password = args[1];
        if (password.length() < 4) {
            plugin.getMessageManager().sendMessage(player, "webmap.password-too-short");
            return;
        }
        if (password.length() > 64) {
            plugin.getMessageManager().sendMessage(player, "webmap.password-too-long");
            return;
        }
        auth.setPassword(player.getUniqueId(), password);
        plugin.getMessageManager().sendMessage(player, "webmap.registered");
    }

    private void handleChangePass(Player player, String[] args, WebAuthManager auth) {
        if (!auth.hasAccount(player.getUniqueId())) {
            plugin.getMessageManager().sendMessage(player, "webmap.not-registered");
            return;
        }
        if (args.length < 2) {
            plugin.getMessageManager().sendMessage(player, "webmap.changepass-usage");
            return;
        }
        String password = args[1];
        if (password.length() < 4) {
            plugin.getMessageManager().sendMessage(player, "webmap.password-too-short");
            return;
        }
        if (password.length() > 64) {
            plugin.getMessageManager().sendMessage(player, "webmap.password-too-long");
            return;
        }
        auth.setPassword(player.getUniqueId(), password);
        plugin.getMessageManager().sendMessage(player, "webmap.password-changed");
    }

    private void showUsage(Player player) {
        plugin.getMessageManager().sendMessage(player, "webmap.help");
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command cmd,
                                                @NotNull String label, @NotNull String[] args) {
        if (args.length == 1) {
            String partial = args[0].toLowerCase();
            return List.of("register", "registrar", "changepass", "cambiarpass").stream()
                    .filter(s -> s.startsWith(partial))
                    .collect(Collectors.toList());
        }
        return List.of();
    }
}
