package com.ethernova.clans.cooldown;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Displays active cooldowns on the actionbar for players.
 * Cooldowns are shown as visual progress bars in real-time.
 */
public class CooldownDisplay {

    private final EthernovaClans plugin;
    private BukkitTask displayTask;

    /**
     * Active cooldowns: playerUUID -> (cooldownName -> CooldownEntry)
     */
    private final Map<UUID, Map<String, CooldownEntry>> activeCooldowns = new ConcurrentHashMap<>();

    public record CooldownEntry(String displayName, Instant startTime, Instant endTime, String color) {}

    public CooldownDisplay(EthernovaClans plugin) {
        this.plugin = plugin;
    }

    /**
     * Start the actionbar display task (runs every 5 ticks = 0.25s on main thread).
     * Runs synchronously since actionbar rendering is lightweight and requires Bukkit API access.
     */
    public void start() {
        if (displayTask != null) displayTask.cancel();
        displayTask = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tickDisplay, 10L, 5L);
    }

    /**
     * Stop the actionbar display task.
     */
    public void stop() {
        if (displayTask != null) {
            displayTask.cancel();
            displayTask = null;
        }
    }

    /**
     * Add a cooldown for a player.
     *
     * @param player    the player
     * @param key       unique cooldown key (e.g., "teleport", "name_change")
     * @param display   display name shown on actionbar
     * @param duration  total duration
     * @param color     MiniMessage color tag (e.g., "<aqua>")
     */
    public void addCooldown(Player player, String key, String display, Duration duration, String color) {
        Instant now = Instant.now();
        CooldownEntry entry = new CooldownEntry(display, now, now.plus(duration), color);
        activeCooldowns.computeIfAbsent(player.getUniqueId(), k -> new ConcurrentHashMap<>())
                .put(key, entry);
    }

    /**
     * Remove a specific cooldown.
     */
    public void removeCooldown(Player player, String key) {
        Map<String, CooldownEntry> map = activeCooldowns.get(player.getUniqueId());
        if (map != null) {
            map.remove(key);
            if (map.isEmpty()) activeCooldowns.remove(player.getUniqueId());
        }
    }

    /**
     * Check if a player has an active cooldown.
     */
    public boolean hasCooldown(Player player, String key) {
        Map<String, CooldownEntry> map = activeCooldowns.get(player.getUniqueId());
        if (map == null) return false;
        CooldownEntry entry = map.get(key);
        if (entry == null) return false;
        if (Instant.now().isAfter(entry.endTime())) {
            map.remove(key);
            return false;
        }
        return true;
    }

    /**
     * Get remaining time for a cooldown.
     */
    public Duration getRemainingTime(Player player, String key) {
        Map<String, CooldownEntry> map = activeCooldowns.get(player.getUniqueId());
        if (map == null) return Duration.ZERO;
        CooldownEntry entry = map.get(key);
        if (entry == null) return Duration.ZERO;
        Duration remaining = Duration.between(Instant.now(), entry.endTime());
        return remaining.isNegative() ? Duration.ZERO : remaining;
    }

    /**
     * Clean up a player's cooldowns (on quit).
     */
    public void cleanup(UUID playerUuid) {
        activeCooldowns.remove(playerUuid);
    }

    /**
     * Tick: update actionbar for all players with active cooldowns.
     */
    private void tickDisplay() {
        Instant now = Instant.now();

        activeCooldowns.forEach((uuid, cooldowns) -> {
            Player player = Bukkit.getPlayer(uuid);
            if (player == null || !player.isOnline()) {
                activeCooldowns.remove(uuid);
                return;
            }

            // Remove expired cooldowns
            cooldowns.entrySet().removeIf(e -> now.isAfter(e.getValue().endTime()));

            if (cooldowns.isEmpty()) {
                activeCooldowns.remove(uuid);
                return;
            }

            // Build actionbar from all active cooldowns
            StringBuilder sb = new StringBuilder();
            boolean first = true;

            for (CooldownEntry entry : cooldowns.values()) {
                if (!first) sb.append("  <dark_gray>│</dark_gray>  ");
                first = false;

                Duration total = Duration.between(entry.startTime(), entry.endTime());
                Duration remaining = Duration.between(now, entry.endTime());
                if (remaining.isNegative()) remaining = Duration.ZERO;

                double progress = 1.0 - ((double) remaining.toMillis() / total.toMillis());
                String bar = buildProgressBar(progress, 12, entry.color());
                String timeStr = formatDuration(remaining);

                sb.append(entry.color()).append(entry.displayName()).append("</").append(entry.color().substring(1))
                        .append(" ").append(bar)
                        .append(" <white>").append(timeStr).append("</white>");
            }

            final String actionbarText = sb.toString();
            // Already on main thread — send directly
            if (player.isOnline()) {
                player.sendActionBar(TextUtil.parse(actionbarText));
            }
        });
    }

    /**
     * Build a visual progress bar with MiniMessage formatting.
     */
    private String buildProgressBar(double progress, int totalBars, String color) {
        int filled = (int) (progress * totalBars);
        int remaining = totalBars - filled;

        StringBuilder sb = new StringBuilder();
        sb.append("<dark_gray>[</dark_gray>");
        sb.append(color);
        sb.append("▮".repeat(Math.max(0, filled)));
        sb.append(color.replace("<", "</").length() > 0 ? "<dark_gray>" : "<dark_gray>");
        sb.append("▯".repeat(Math.max(0, remaining)));
        sb.append("<dark_gray>]</dark_gray>");
        return sb.toString();
    }

    /**
     * Format a duration to a compact string.
     */
    private String formatDuration(Duration duration) {
        long totalSeconds = duration.getSeconds();
        if (totalSeconds >= 3600) {
            long hours = totalSeconds / 3600;
            long minutes = (totalSeconds % 3600) / 60;
            return hours + "h" + (minutes > 0 ? minutes + "m" : "");
        } else if (totalSeconds >= 60) {
            long minutes = totalSeconds / 60;
            long seconds = totalSeconds % 60;
            return minutes + "m" + (seconds > 0 ? seconds + "s" : "");
        } else {
            return totalSeconds + "s";
        }
    }
}
