package com.ethernova.clans.event;

import com.ethernova.clans.clan.Clan;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

/**
 * Fired when a war starts between two clans.
 */
public class ClanWarStartEvent extends Event implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();
    private boolean cancelled = false;

    private final Clan attacker;
    private final Clan defender;
    private final String warType;

    public ClanWarStartEvent(Clan attacker, Clan defender, String warType) {
        this.attacker = attacker;
        this.defender = defender;
        this.warType = warType;
    }

    public Clan getAttacker() { return attacker; }
    public Clan getDefender() { return defender; }
    public String getWarType() { return warType; }

    @Override public boolean isCancelled() { return cancelled; }
    @Override public void setCancelled(boolean cancel) { this.cancelled = cancel; }
    @Override public @NotNull HandlerList getHandlers() { return HANDLERS; }
    public static HandlerList getHandlerList() { return HANDLERS; }
}
