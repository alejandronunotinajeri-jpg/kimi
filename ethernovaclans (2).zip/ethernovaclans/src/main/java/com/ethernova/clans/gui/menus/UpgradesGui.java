package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanRole;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.upgrade.UpgradeManager;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.ParticleUtil;
import com.ethernova.clans.util.SoundUtil;
import com.ethernova.clans.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * GUI for purchasing clan upgrades.
 */
public class UpgradesGui extends AbstractGui {

    private static final int[] UPGRADE_SLOTS = {
            10, 12, 14, 16,
            28, 30, 32, 34
    };

    public UpgradesGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "upgrades");
    }

    @Override
    protected void populateItems() {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return;

        UpgradeManager um = plugin.getUpgradeManager();
        if (um == null) return;

        // Header
        setItem(4, new ItemBuilder(Material.ANVIL)
                .name("<gradient:#FFD700:#FF6B35>⬆ Mejoras del Clan</gradient>")
                .lore(List.of(
                        "",
                        "<gray>Compra mejoras permanentes",
                        "<gray>para tu clan con dinero del banco.",
                        "",
                        "<gray>Banco: <gold>" + TextUtil.formatCurrency(clan.getBank().getBalance())
                ))
                .glow()
                .build());

        var definitions = um.getAllDefinitions().toArray(new UpgradeManager.UpgradeDefinition[0]);

        for (int i = 0; i < UPGRADE_SLOTS.length && i < definitions.length; i++) {
            UpgradeManager.UpgradeDefinition def = definitions[i];
            int currentLevel = um.getUpgradeLevel(clan, def.id());
            boolean maxed = currentLevel >= def.maxLevel();
            double cost = um.getUpgradeCost(def.id(), currentLevel);
            double currentValue = um.getUpgradeValue(def.id(), currentLevel);
            double nextValue = um.getUpgradeValue(def.id(), currentLevel + 1);
            boolean canAfford = clan.getBank().getBalance() >= cost;

            Material mat;
            try {
                mat = Material.valueOf(def.icon().toUpperCase());
            } catch (IllegalArgumentException e) {
                mat = Material.EMERALD;
            }

            String suffix = def.valueType().equals("percentage") ? "%" : "";

            List<String> lore = new ArrayList<>();
            lore.add("");
            lore.add("<gray>" + def.description());
            lore.add("");
            lore.add("<gray>Nivel actual: <yellow>" + currentLevel + "/" + def.maxLevel());
            lore.add("<gray>Valor actual: <green>" + String.format("%.0f", currentValue) + suffix);

            if (!maxed) {
                lore.add("");
                lore.add("<gray>Próximo nivel: <yellow>" + (currentLevel + 1));
                lore.add("<gray>Nuevo valor: <green>" + String.format("%.0f", nextValue) + suffix);
                lore.add("");
                lore.add("<gray>Costo: " + (canAfford ? "<green>" : "<red>") +
                        "$" + TextUtil.formatCurrency(cost));
                lore.add("");
                if (canAfford) {
                    lore.add("<yellow>Click para comprar");
                } else {
                    lore.add("<red>No tienes suficiente dinero");
                }
            } else {
                lore.add("");
                lore.add("<green>✔ Nivel máximo alcanzado");
            }

            // Progress bar
            String progressBar = TextUtil.progressBar(currentLevel, def.maxLevel());
            lore.add(2, progressBar);

            setItem(UPGRADE_SLOTS[i], new ItemBuilder(mat)
                    .name((maxed ? "<green>✔ " : "<yellow>⬆ ") + def.displayName())
                    .lore(lore)
                    .amount(Math.max(1, currentLevel))
                    .glowIf(maxed)
                    .build());
            slotActions.put(UPGRADE_SLOTS[i], "BUY:" + def.id());
        }
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (!action.startsWith("BUY:")) return false;

        String upgradeId = action.substring(4);
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return true;

        // Only leader/mod can buy upgrades
        var member = clan.getMember(player.getUniqueId());
        if (member == null || !member.getRole().isAtLeast(ClanRole.OFFICER)) {
            player.sendMessage(plugin.getConfigManager().getMessage("general.no-permission"));
            SoundUtil.error(player);
            return true;
        }

        UpgradeManager um = plugin.getUpgradeManager();
        if (um == null) return true;

        if (um.purchaseUpgrade(clan, upgradeId)) {
            player.sendMessage(plugin.getConfigManager().getMessage("upgrade.purchased",
                    "upgrade", upgradeId, "level", String.valueOf(um.getUpgradeLevel(clan, upgradeId))));
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);
            // Log to audit
            if (plugin.getAuditManager() != null) {
                var def = um.getDefinition(upgradeId);
                String name = def != null ? def.displayName() : upgradeId;
                plugin.getAuditManager().log(clan, player, "UPGRADE",
                        "Compró mejora: " + name + " (Nivel " + um.getUpgradeLevel(clan, upgradeId) + ")");
            }

            refreshGui();
        } else {
            UpgradeManager.UpgradeDefinition def = um.getDefinition(upgradeId);
            int currentLevel = um.getUpgradeLevel(clan, upgradeId);
            if (def != null && currentLevel >= def.maxLevel()) {
                player.sendMessage(plugin.getConfigManager().getMessage("upgrade.max-level"));
            } else {
                player.sendMessage(plugin.getConfigManager().getMessage("upgrade.insufficient-funds"));
            }
            SoundUtil.error(player);
        }

        return true;
    }

    private void refreshGui() {
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            slotActions.clear();
            rightClickActions.clear();
            slotConfigs.clear();
            occupiedSlots.clear();
            fillBackground();
            placeConfigItems();
            populateItems();
        });
    }
}
