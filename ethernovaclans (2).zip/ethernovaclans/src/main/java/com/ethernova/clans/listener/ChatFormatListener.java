package com.ethernova.clans.listener;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

/**
 * Optional built-in chat/tab formatter.
 * <p>
 * <b>Disabled by default.</b> Use PlaceholderAPI placeholders in your chat plugin instead:
 * <ul>
 *   <li>{@code %ethernova_clan_tag_colored%} – tag with §-color codes</li>
 *   <li>{@code %ethernova_clans_clan_formatted%} – [TAG] with brackets</li>
 * </ul>
 * Enable {@code chat.modify-global-format} only if you have NO external chat plugin.
 */
public class ChatFormatListener implements Listener {

    private final EthernovaClans plugin;
    private final MiniMessage mini = MiniMessage.miniMessage();

    public ChatFormatListener(EthernovaClans plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onChat(AsyncChatEvent event) {
        // Disabled by default — let external chat plugins use PlaceholderAPI placeholders
        if (!plugin.getConfigManager().getConfig().getBoolean("chat.modify-global-format", false)) return;

        Player player = event.getPlayer();
        Clan clan = plugin.getClanManager().getClanByPlayer(player.getUniqueId());

        // Player has no clan → don't touch the renderer at all (let external plugin handle it)
        if (clan == null || clan.getTag() == null) return;

        String tagFormat = plugin.getConfigManager().getConfig().getString("chat.global-tag-format",
                "<gray>[<white>{tag}</white>]</gray> ");
        String tag = tagFormat.replace("{tag}", clan.getTag()).replace("{clan}", clan.getDisplayName());

        Component prefix = mini.deserialize(tag);
        event.renderer((source, sourceDisplayName, message, viewer) ->
                prefix.append(sourceDisplayName).append(Component.text(" ")).append(message));
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onJoin(PlayerJoinEvent event) {
        if (!plugin.getConfigManager().getConfig().getBoolean("chat.modify-tab", false)) return;
        updateTab(event.getPlayer());
    }

    public void updateTab(Player player) {
        Clan clan = plugin.getClanManager().getClanByPlayer(player.getUniqueId());
        if (clan == null || clan.getTag() == null) return;

        String format = plugin.getConfigManager().getConfig().getString("chat.tab-format",
                "<gray>[{tag}]</gray> <white>{player}</white>");
        format = format.replace("{tag}", clan.getTag())
                .replace("{clan}", clan.getDisplayName())
                .replace("{player}", player.getName());

        player.playerListName(mini.deserialize(format));
    }
}
