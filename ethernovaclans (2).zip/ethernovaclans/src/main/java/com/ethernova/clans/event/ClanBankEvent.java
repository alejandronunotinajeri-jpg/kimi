package com.ethernova.clans.event;

import com.ethernova.clans.clan.Clan;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Fired when a bank transaction occurs (deposit or withdraw).
 */
public class ClanBankEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();

    private final Clan clan;
    private final @Nullable Player player;
    private final double amount;
    private final BankAction action;

    public enum BankAction {
        DEPOSIT, WITHDRAW, INTEREST
    }

    public ClanBankEvent(@NotNull Clan clan, @Nullable Player player, double amount, @NotNull BankAction action) {
        this.clan = clan;
        this.player = player;
        this.amount = amount;
        this.action = action;
    }

    public @NotNull Clan getClan() { return clan; }
    public @Nullable Player getPlayer() { return player; }
    public double getAmount() { return amount; }
    public @NotNull BankAction getAction() { return action; }

    @Override public @NotNull HandlerList getHandlers() { return HANDLERS; }
    public static HandlerList getHandlerList() { return HANDLERS; }
}
