package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.season.SeasonEntry;
import com.ethernova.clans.season.SeasonManager;
import com.ethernova.clans.util.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * GUI to display season rankings and history.
 */
public class SeasonGui extends AbstractGui {

    public SeasonGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "seasons");
    }

    private static final int[] RANKING_SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};

    @Override
    protected void populateItems() {
        SeasonManager sm = plugin.getSeasonManager();
        if (sm == null || !sm.isEnabled()) return;

        // Time remaining
        long remainMs = sm.getTimeRemainingMs();
        long days = TimeUnit.MILLISECONDS.toDays(remainMs);
        long hours = TimeUnit.MILLISECONDS.toHours(remainMs) % 24;

        setItem(4, new ItemBuilder(Material.CLOCK)
                .name("<gradient:#FFD700:#FF0000>🏆 Temporada " + sm.getCurrentSeason() + "</gradient>")
                .lore(List.of(
                        "",
                        "<gray>Termina en: <white>" + days + "d " + hours + "h",
                        "",
                        "<gray>Al finalizar la temporada",
                        "<gray>se premian los top 3 clanes."
                ))
                .build());

        // Rankings
        List<SeasonEntry> rankings = sm.getCurrentRankings();
        String[] medals = {"<gold>🥇", "<white>🥈", "<#CD7F32>🥉"};
        Material[] headColors = {Material.GOLD_BLOCK, Material.IRON_BLOCK, Material.COPPER_BLOCK};

        for (int i = 0; i < Math.min(rankings.size(), RANKING_SLOTS.length); i++) {
            SeasonEntry entry = rankings.get(i);
            Material mat = i < 3 ? headColors[i] : Material.STONE;
            String prefix = i < 3 ? medals[i] + " " : "<gray>#" + (i + 1) + " ";

            List<String> lore = new ArrayList<>();
            lore.add("<gray>Score: <white>" + String.format("%.0f", entry.getScore()));
            lore.add("");
            lore.add("<gray>Kills: <white>" + entry.getKills());
            lore.add("<gray>Guerras ganadas: <white>" + entry.getWarsWon());
            lore.add("<gray>Power: <white>" + entry.getPower());
            lore.add("<gray>Nivel: <white>" + entry.getLevel());
            lore.add("<gray>Territorios: <white>" + entry.getTerritories());
            lore.add("<gray>Miembros: <white>" + entry.getMembers());

            setItem(RANKING_SLOTS[i], new ItemBuilder(mat)
                    .name(prefix + "<yellow>" + entry.getClanName())
                    .lore(lore)
                    .build());
        }

        // Back button
        setItem(49, new ItemBuilder(Material.ARROW)
                .name("<gray>◀ Volver al menú")
                .build());
        slotActions.put(49, "BACK");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.equalsIgnoreCase("BACK")) {
            plugin.getServer().getScheduler().runTask(plugin, () ->
                    plugin.getGuiManager().openMainMenu(player));
            return true;
        }
        return false;
    }
}
