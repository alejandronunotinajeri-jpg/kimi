package com.ethernova.clans.command;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ClanAdminCommand implements CommandExecutor, TabCompleter {

    private final EthernovaClans plugin;

    public ClanAdminCommand(EthernovaClans plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd,
                             @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("ethernova.clans.admin")) {
            plugin.getMessageManager().sendMessage(sender, "general.no-permission");
            return true;
        }

        if (args.length == 0) { showHelp(sender); return true; }

        switch (args[0].toLowerCase()) {
            case "gui", "menu" -> {
                if (!(sender instanceof Player p)) {
                    plugin.getMessageManager().sendMessage(sender, "admin.only-players-gui");
                    return true;
                }
                plugin.getGuiManager().openAdminMenu(p);
            }
            case "reload" -> {
                plugin.getConfigManager().loadAllConfigs();
                plugin.getMessageManager().sendMessage(sender, "admin.reloaded");
            }
            case "disband" -> {
                if (args.length < 2) { showHelp(sender); return true; }
                Clan clan = plugin.getClanManager().getClanByName(args[1]);
                if (clan == null) {
                    plugin.getMessageManager().sendMessage(sender, "clan.clan-not-found"); return true;
                }
                plugin.getAllianceManager().removeAllAlliances(clan.getId());
                plugin.getTerritoryManager().unclaimAll(clan.getId());
                plugin.getClanManager().deleteClan(clan);
                plugin.getMessageManager().sendMessage(sender, "admin.clan-deleted", "clan", clan.getName());
            }
            case "setpower" -> {
                if (args.length < 3) { showHelp(sender); return true; }
                Player target = Bukkit.getPlayer(args[1]);
                if (target == null) { plugin.getMessageManager().sendMessage(sender, "error.player-not-found"); return true; }
                try {
                    double power = Double.parseDouble(args[2]);
                    plugin.getPowerManager().setPower(target.getUniqueId(), power);
                    plugin.getMessageManager().sendMessage(sender, "admin.power-set", "clan", target.getName(), "power", String.valueOf(power));
                } catch (NumberFormatException e) {
                    plugin.getMessageManager().sendMessage(sender, "error.invalid-number");
                }
            }
            case "forcejoin" -> {
                if (args.length < 3) { plugin.getMessageManager().sendMessage(sender, "admin.usage-forcejoin"); return true; }
                Player target = Bukkit.getPlayer(args[1]);
                Clan clan = plugin.getClanManager().getClanByName(args[2]);
                if (target == null) { plugin.getMessageManager().sendMessage(sender, "error.player-not-found"); return true; }
                if (clan == null) { plugin.getMessageManager().sendMessage(sender, "error.clan-not-found"); return true; }
                if (plugin.getClanManager().getClanByPlayer(target.getUniqueId()) != null) {
                    plugin.getMessageManager().sendMessage(sender, "error.already-in-clan"); return true;
                }
                clan.addMember(new com.ethernova.clans.clan.ClanMember(target.getUniqueId(), target.getName(), com.ethernova.clans.clan.ClanRole.MEMBER));
                plugin.getClanManager().updatePlayerClanMapping(target.getUniqueId(), clan.getId());
                plugin.getClanManager().saveClan(clan);
                plugin.getMessageManager().sendMessage(sender, "admin.forcejoin-success", "player", target.getName(), "clan", clan.getName());
            }
            case "forceleader" -> {
                if (args.length < 3) { plugin.getMessageManager().sendMessage(sender, "admin.usage-forceleader"); return true; }
                Clan clan = plugin.getClanManager().getClanByName(args[1]);
                if (clan == null) { plugin.getMessageManager().sendMessage(sender, "error.clan-not-found"); return true; }
                com.ethernova.clans.clan.ClanMember member = clan.getMemberByName(args[2]);
                if (member == null) { plugin.getMessageManager().sendMessage(sender, "error.not-a-member"); return true; }
                com.ethernova.clans.clan.ClanMember oldLeader = clan.getMember(clan.getLeaderUuid());
                if (oldLeader != null) oldLeader.setRole(com.ethernova.clans.clan.ClanRole.CO_LEADER);
                member.setRole(com.ethernova.clans.clan.ClanRole.LEADER);
                clan.setLeaderUuid(member.getUuid());
                clan.setLeaderName(member.getName());
                plugin.getClanManager().saveClan(clan);
                plugin.getMessageManager().sendMessage(sender, "admin.leader-changed", "player", member.getName(), "clan", clan.getName());
            }
            case "spy" -> {
                if (!(sender instanceof Player p)) return true;
                boolean has = p.hasPermission("ethernova.clans.spy");
                plugin.getMessageManager().sendMessage(sender, has ? "admin.spy-toggle-on" : "admin.spy-no-permission");
            }
            case "blueprint", "blueprints" -> {
                if (!(sender instanceof Player p)) {
                    plugin.getMessageManager().sendMessage(sender, "admin.only-players-gui");
                    return true;
                }
                plugin.getGuiManager().openGui(p, "blueprints-admin");
            }
            case "season" -> {
                if (args.length < 2) {
                    plugin.getMessageManager().sendMessage(sender, "admin.usage-season");
                    return true;
                }
                if ("reset".equalsIgnoreCase(args[1])) {
                    if (plugin.getSeasonManager() != null) {
                        plugin.getSeasonManager().forceEndSeason();
                        plugin.getMessageManager().sendMessage(sender, "admin.season-reset");
                    } else {
                        plugin.getMessageManager().sendMessage(sender, "admin.season-not-enabled");
                    }
                }
            }
            case "tax" -> {
                if (args.length < 2) {
                    plugin.getMessageManager().sendMessage(sender, "admin.usage-tax");
                    return true;
                }
                if ("collect".equalsIgnoreCase(args[1])) {
                    if (plugin.getTaxManager() != null) {
                        plugin.getTaxManager().collectNow();
                        plugin.getMessageManager().sendMessage(sender, "admin.tax-collected");
                    } else {
                        plugin.getMessageManager().sendMessage(sender, "admin.tax-not-enabled");
                    }
                }
            }
            case "setbank" -> {
                if (args.length < 3) { plugin.getMessageManager().sendMessage(sender, "admin.usage-setbank"); return true; }
                Clan clan = plugin.getClanManager().getClanByName(args[1]);
                if (clan == null) { plugin.getMessageManager().sendMessage(sender, "error.clan-not-found"); return true; }
                try {
                    double amount = Double.parseDouble(args[2]);
                    plugin.getBankManager().setBalance(clan.getId(), amount);
                    plugin.getMessageManager().sendMessage(sender, "admin.bank-set", "clan", clan.getName(), "amount", String.valueOf(amount));
                } catch (NumberFormatException e) { plugin.getMessageManager().sendMessage(sender, "error.invalid-number"); }
            }
            case "setlevel" -> {
                if (args.length < 3) { plugin.getMessageManager().sendMessage(sender, "admin.usage-setlevel"); return true; }
                Clan clan = plugin.getClanManager().getClanByName(args[1]);
                if (clan == null) { plugin.getMessageManager().sendMessage(sender, "error.clan-not-found"); return true; }
                try {
                    long xp = Long.parseLong(args[2]);
                    plugin.getLevelManager().loadXP(clan.getId(), xp);
                    plugin.getMessageManager().sendMessage(sender, "admin.xp-set", "clan", clan.getName(), "xp", String.valueOf(xp), "level", String.valueOf(plugin.getLevelManager().getLevel(clan.getId())));
                } catch (NumberFormatException e) { plugin.getMessageManager().sendMessage(sender, "error.invalid-number"); }
            }
            case "info" -> {
                plugin.getMessageManager().sendMessage(sender, "admin.info-header");
                plugin.getMessageManager().sendMessage(sender, "admin.info-clans", "count", String.valueOf(plugin.getClanManager().getAllClans().size()));
                plugin.getMessageManager().sendMessage(sender, "admin.info-wars", "count", String.valueOf(plugin.getWarManager().getActiveWarCount()));
                plugin.getMessageManager().sendMessage(sender, "admin.info-core", "status", (plugin.getCoreHook().isAvailable() ? "<green>Conectado</green>" : "<red>No</red>"));
                plugin.getMessageManager().sendMessage(sender, "admin.info-combat", "status", (plugin.getCombatHook().isAvailable() ? "<green>Conectado</green>" : "<red>No</red>"));
            }
            case "audit" -> {
                if (args.length < 2) { plugin.getMessageManager().sendMessage(sender, "admin.usage-audit"); return true; }
                Clan clan = plugin.getClanManager().getClanByName(args[1]);
                if (clan == null) { plugin.getMessageManager().sendMessage(sender, "error.clan-not-found"); return true; }
                int limit = 20;
                if (args.length >= 3) {
                    try { limit = Integer.parseInt(args[2]); }
                    catch (NumberFormatException e) { plugin.getMessageManager().sendMessage(sender, "error.invalid-number"); return true; }
                }
                plugin.getMessageManager().sendMessage(sender, "admin.audit-header", "clan", clan.getName());
                for (String log : plugin.getAuditLogger().getRecentLogs(clan.getId(), limit)) {
                    plugin.getMessageManager().sendRaw(sender, log);
                }
            }
            case "unclaimall" -> {
                if (args.length < 2) { plugin.getMessageManager().sendMessage(sender, "admin.usage-unclaimall"); return true; }
                Clan clan = plugin.getClanManager().getClanByName(args[1]);
                if (clan == null) { plugin.getMessageManager().sendMessage(sender, "error.clan-not-found"); return true; }
                int count = plugin.getTerritoryManager().getClaimCount(clan.getId());
                plugin.getTerritoryManager().unclaimAll(clan.getId());
                plugin.getMessageManager().sendMessage(sender, "admin.unclaim-all-success", "count", String.valueOf(count), "clan", clan.getName());
            }
            case "resetlevel" -> {
                if (args.length < 2) { plugin.getMessageManager().sendMessage(sender, "admin.usage-resetlevel"); return true; }
                Clan clan = plugin.getClanManager().getClanByName(args[1]);
                if (clan == null) { plugin.getMessageManager().sendMessage(sender, "error.clan-not-found"); return true; }
                plugin.getLevelManager().loadXP(clan.getId(), 0);
                plugin.getMessageManager().sendMessage(sender, "admin.xp-reset", "clan", clan.getName());
            }
            case "resetbank" -> {
                if (args.length < 2) { plugin.getMessageManager().sendMessage(sender, "admin.usage-resetbank"); return true; }
                Clan clan = plugin.getClanManager().getClanByName(args[1]);
                if (clan == null) { plugin.getMessageManager().sendMessage(sender, "error.clan-not-found"); return true; }
                plugin.getBankManager().setBalance(clan.getId(), 0);
                plugin.getMessageManager().sendMessage(sender, "admin.bank-reset", "clan", clan.getName());
            }
            case "tpchunk" -> {
                if (!(sender instanceof Player p)) return true;
                if (args.length < 3) { plugin.getMessageManager().sendMessage(sender, "admin.usage-tpchunk"); return true; }
                String[] parts = args[1].split(":");
                if (parts.length != 3) { plugin.getMessageManager().sendMessage(sender, "admin.tpchunk-format"); return true; }
                var world = Bukkit.getWorld(parts[0]);
                if (world == null) { plugin.getMessageManager().sendMessage(sender, "admin.world-not-found"); return true; }
                int cx, cz;
                try {
                    cx = Integer.parseInt(parts[1]);
                    cz = Integer.parseInt(parts[2]);
                } catch (NumberFormatException e) {
                    plugin.getMessageManager().sendMessage(sender, "admin.invalid-coordinates");
                    return true;
                }
                p.teleport(new org.bukkit.Location(world, cx * 16 + 8, world.getHighestBlockYAt(cx * 16 + 8, cz * 16 + 8) + 1, cz * 16 + 8));
                plugin.getMessageManager().sendMessage(sender, "admin.tpchunk-success", "chunk", args[1]);
            }

            default -> showHelp(sender);
        }
        return true;
    }

    private void showHelp(CommandSender sender) {
        var mm = plugin.getMessageManager();
        mm.sendMessage(sender, "admin.help-header");
        mm.sendMessage(sender, "admin.help-gui");
        mm.sendMessage(sender, "admin.help-reload");
        mm.sendMessage(sender, "admin.help-delete");
        mm.sendMessage(sender, "admin.help-setpower");
        mm.sendMessage(sender, "admin.help-forcejoin");
        mm.sendMessage(sender, "admin.help-forceleader");
        mm.sendMessage(sender, "admin.help-setbank");
        mm.sendMessage(sender, "admin.help-resetbank");
        mm.sendMessage(sender, "admin.help-setlevel");
        mm.sendMessage(sender, "admin.help-resetlevel");
        mm.sendMessage(sender, "admin.help-unclaimall");
        mm.sendMessage(sender, "admin.help-audit");
        mm.sendMessage(sender, "admin.help-tpchunk");
        mm.sendMessage(sender, "admin.help-spy");
        mm.sendMessage(sender, "admin.help-info");
        mm.sendMessage(sender, "admin.help-season");
        mm.sendMessage(sender, "admin.help-tax");
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command cmd,
                                                @NotNull String alias, @NotNull String[] args) {
        if (!sender.hasPermission("ethernova.clans.admin")) return List.of();
        if (args.length == 1) {
            return Arrays.asList("gui", "reload", "disband", "setpower", "forcejoin", "forceleader",
                    "setbank", "resetbank", "setlevel", "resetlevel", "unclaimall", "audit", "tpchunk", "spy", "info",
                    "blueprint", "season", "tax").stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        }
        if (args.length == 2) {
            String sub = args[0].toLowerCase();
            if (java.util.List.of("disband", "forceleader", "setbank", "resetbank", "setlevel",
                    "resetlevel", "unclaimall", "audit").contains(sub)) {
                return plugin.getClanManager().getAllClans().stream()
                        .map(Clan::getName).filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase()))
                        .collect(Collectors.toList());
            }
            if ("setpower".equals(sub) || "forcejoin".equals(sub)) return null;
            if ("season".equals(sub)) return List.of("reset").stream()
                    .filter(s -> s.startsWith(args[1].toLowerCase())).collect(Collectors.toList());
            if ("tax".equals(sub)) return List.of("collect").stream()
                    .filter(s -> s.startsWith(args[1].toLowerCase())).collect(Collectors.toList());
        }
        if (args.length == 3 && "forcejoin".equalsIgnoreCase(args[0])) {
            return plugin.getClanManager().getAllClans().stream()
                    .map(Clan::getName).filter(n -> n.toLowerCase().startsWith(args[2].toLowerCase()))
                    .collect(Collectors.toList());
        }
        return List.of();
    }
}
