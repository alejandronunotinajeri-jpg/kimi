package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Admin GUI showing all clans with pagination and sorting.
 */
public class AdminClanListGui extends AbstractGui {

    private int page = 0;
    private String sortMode = "power"; // power, members, level, balance, name
    private static final int[] CLAN_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34,
            37, 38, 39, 40, 41, 42, 43
    };

    public AdminClanListGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "admin-clan-list");
    }

    @Override
    protected void populateItems() {
        List<Clan> clans = getSortedClans();
        int start = page * CLAN_SLOTS.length;
        int end = Math.min(start + CLAN_SLOTS.length, clans.size());

        for (int i = 0; i < CLAN_SLOTS.length; i++) {
            int index = start + i;
            if (index >= end) {
                inventory.setItem(CLAN_SLOTS[i], null);
                continue;
            }

            Clan clan = clans.get(index);
            int rank = index + 1;

            Material icon = switch (rank) {
                case 1 -> Material.GOLD_BLOCK;
                case 2 -> Material.IRON_BLOCK;
                case 3 -> Material.COPPER_BLOCK;
                default -> Material.STONE;
            };

            List<String> lore = new ArrayList<>(List.of(
                    "",
                    "<dark_gray>▎ <gray>Level:</gray> <yellow>" + clan.getLevel() + "</yellow> <dark_gray>(" + plugin.getLevelManager().getLevelName(clan.getLevel()) + ")</dark_gray>",
                    "<dark_gray>▎ <gray>Power:</gray> <gold>" + clan.getPower() + "</gold>",
                    "<dark_gray>▎ <gray>Members:</gray> <aqua>" + clan.getOnlineMemberCount() + "/" + clan.getMembers().size() + "</aqua>",
                    "<dark_gray>▎ <gray>Bank:</gray> <gold>" + TextUtil.formatCurrency(clan.getBank().getBalance()) + "</gold>",
                    "<dark_gray>▎ <gray>KD:</gray> <red>" + String.format("%.2f", clan.getKD()) + "</red>",
                    "<dark_gray>▎ <gray>Wars:</gray> <green>" + clan.getWarsWon() + "W</green> <red>" + clan.getWarsLost() + "L</red>",
                    "",
                    "<yellow>Left click:</yellow> <white>Manage</white>",
                    "<red>Shift + Right click:</red> <white>Disband</white>"
            ));

            setItem(CLAN_SLOTS[i], new ItemBuilder(icon)
                    .name(clan.getFormattedTag() + " <white>" + clan.getName())
                    .lore(lore)
                    .build());
            slotActions.put(CLAN_SLOTS[i], "ADMIN_CLAN:" + clan.getId());
        }

        // Page info
        int totalPages = Math.max(1, (int) Math.ceil((double) clans.size() / CLAN_SLOTS.length));
        setItem(49, new ItemBuilder(Material.PAPER)
                .name("<gray>Page " + (page + 1) + "/" + totalPages)
                .lore(List.of("<gray>Total clans: " + clans.size()))
                .build());

        // Highlight active sort button
        highlightSort();
    }

    private void highlightSort() {
        // The sort buttons are placed by placeConfigItems from YAML
        // We add glow to the active sort via dynamic items
        Material[] sortMats = {Material.BLAZE_POWDER, Material.PLAYER_HEAD, Material.EXPERIENCE_BOTTLE, Material.GOLD_INGOT, Material.NAME_TAG};
        String[] sortNames = {"<gold>Sort: Power", "<aqua>Sort: Members", "<green>Sort: Level", "<gold>Sort: Balance", "<white>Sort: Name"};
        String[] sortKeys = {"power", "members", "level", "balance", "name"};
        int[] sortSlots = {2, 3, 4, 5, 6};

        for (int i = 0; i < sortSlots.length; i++) {
            var builder = new ItemBuilder(sortMats[i])
                    .name(sortNames[i])
                    .lore(List.of(
                            sortMode.equals(sortKeys[i]) ? "<green>✔ Selected" : "<gray>Click to sort"
                    ))
                    .glowIf(sortMode.equals(sortKeys[i]));
            if (sortMats[i] == Material.PLAYER_HEAD) {
                builder.hideFlags();
            }
            setItem(sortSlots[i], builder.build());
            slotActions.put(sortSlots[i], "ADMIN_SORT:" + sortKeys[i]);
        }
    }

    private List<Clan> getSortedClans() {
        List<Clan> clans = new ArrayList<>(plugin.getClanManager().getAllClans());
        switch (sortMode) {
            case "power" -> clans.sort(Comparator.comparingDouble(Clan::getPower).reversed());
            case "members" -> clans.sort(Comparator.comparingInt((Clan c) -> c.getMembers().size()).reversed());
            case "level" -> clans.sort(Comparator.comparingInt(Clan::getLevel).reversed());
            case "balance" -> clans.sort(Comparator.comparingDouble((Clan c) -> c.getBank().getBalance()).reversed());
            case "name" -> clans.sort(Comparator.comparing(Clan::getName, String.CASE_INSENSITIVE_ORDER));
        }
        return clans;
    }

    @Override
    protected String replacePlaceholders(String text) {
        text = super.replacePlaceholders(text);
        int totalClans = plugin.getClanManager().getAllClans().size();
        int totalPages = Math.max(1, (int) Math.ceil((double) totalClans / CLAN_SLOTS.length));
        text = text.replace("{total_clans}", String.valueOf(totalClans))
                .replace("{page}", String.valueOf(page + 1))
                .replace("{max_page}", String.valueOf(totalPages));
        return text;
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        // Sort prefix
        if (action.startsWith("ADMIN_SORT:")) {
            String sort = action.substring("ADMIN_SORT:".length());
            sortMode = sort;
            page = 0;
            refreshGui();
            return true;
        }

        // Clan click
        if (action.startsWith("ADMIN_CLAN:")) {
            String clanId = action.substring("ADMIN_CLAN:".length());
            Clan clan = plugin.getClanManager().getClanById(clanId);
            if (clan == null) {
                player.sendMessage(plugin.getConfigManager().getMessage("error.clan-not-found"));
                return true;
            }

            if (event.isShiftClick() && event.isRightClick()) {
                // Disband
                plugin.getClanManager().adminDisband(clan);
                player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.disband-success",
                        "clan", clan.getName()));
                refreshGui();
            } else {
                // Open admin clan GUI
                AdminClanGui gui = new AdminClanGui(plugin, player, clan);
                gui.open();
            }
            return true;
        }

        return switch (action.toUpperCase()) {
            case "ADMIN_PREV_PAGE" -> {
                if (page > 0) {
                    page--;
                    refreshGui();
                }
                yield true;
            }
            case "ADMIN_NEXT_PAGE" -> {
                List<Clan> clans = getSortedClans();
                int totalPages = (int) Math.ceil((double) clans.size() / CLAN_SLOTS.length);
                if (page < totalPages - 1) {
                    page++;
                    refreshGui();
                }
                yield true;
            }
            default -> false;
        };
    }

    private void refreshGui() {
        occupiedSlots.clear();
        slotActions.clear();
        rightClickActions.clear();
        slotConfigs.clear();
        fillBackground();
        placeConfigItems();
        populateItems();
    }
}
