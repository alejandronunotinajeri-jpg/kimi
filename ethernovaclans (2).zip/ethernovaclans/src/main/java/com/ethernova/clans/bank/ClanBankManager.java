package com.ethernova.clans.bank;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ClanBankManager {

    private final EthernovaClans plugin;
    private final Map<String, Double> balances = new ConcurrentHashMap<>();

    public ClanBankManager(EthernovaClans plugin) {
        this.plugin = plugin;
    }

    /**
     * Wire up reverse-sync: when ClanBank changes via direct calls (e.g., clan.getBank().deposit()),
     * the change propagates back to this manager. Should be called after a Clan is loaded/created.
     */
    public void registerBankSync(Clan clan) {
        clan.getBank().setClanIdString(clan.getId());
        clan.getBank().setBalanceChangeListener((clanId, newBalance) -> {
            balances.put(clanId, newBalance);
        });
    }

    public double getBalance(String clanId) {
        return balances.getOrDefault(clanId, 0.0);
    }

    public void setBalance(String clanId, double amount) {
        double clamped = Math.max(0, amount);
        balances.put(clanId, clamped);
        // Sync with the in-memory Clan bank object to prevent divergence
        Clan clan = plugin.getClanManager().getClan(clanId);
        if (clan != null) clan.getBank().setBalance(clamped);
    }

    /**
     * Atomic balance modification. Positive amount = deposit, negative = withdraw.
     * Uses ConcurrentHashMap.compute for thread safety (avoids read-modify-write race).
     */
    public void addBalance(String clanId, double amount) {
        balances.compute(clanId, (k, old) -> Math.max(0, (old != null ? old : 0) + amount));
        Clan clan = plugin.getClanManager().getClan(clanId);
        if (clan != null) clan.getBank().setBalance(balances.getOrDefault(clanId, 0.0));
    }

    public boolean deposit(Clan clan, org.bukkit.entity.Player player, double amount) {
        if (amount <= 0) return false;
        if (plugin.getEconomyManager() == null || !plugin.getEconomyManager().isEnabled()) return false;
        if (!plugin.getEconomyManager().has(player, amount)) return false;

        plugin.getEconomyManager().withdraw(player, amount);

        // Atomic balance update
        balances.compute(clan.getId(), (k, old) -> Math.max(0, (old != null ? old : 0) + amount));
        // Sync with in-memory ClanBank object
        clan.getBank().setBalance(balances.getOrDefault(clan.getId(), 0.0));

        plugin.getLogger().info(player.getName() + " deposited " + amount + " to clan " + clan.getName());
        return true;
    }

    public boolean withdraw(Clan clan, org.bukkit.entity.Player player, double amount) {
        if (amount <= 0) return false;
        if (plugin.getEconomyManager() == null || !plugin.getEconomyManager().isEnabled()) return false;

        // Enforce max withdraw per transaction
        double maxWithdraw = plugin.getConfigManager().getConfig()
                .getDouble("bank.max-withdraw-per-day", 0);
        if (maxWithdraw > 0 && amount > maxWithdraw) return false;

        // Atomic check-and-deduct
        boolean[] success = {false};
        balances.compute(clan.getId(), (k, old) -> {
            double current = old != null ? old : 0;
            if (current < amount) return current; // insufficient
            success[0] = true;
            return Math.max(0, current - amount);
        });
        if (!success[0]) return false;

        // Sync with in-memory ClanBank object
        clan.getBank().setBalance(balances.getOrDefault(clan.getId(), 0.0));
        if (plugin.getEconomyManager() != null) {
            plugin.getEconomyManager().deposit(player, amount);
        }

        plugin.getLogger().info(player.getName() + " withdrew " + amount + " from clan " + clan.getName());
        return true;
    }

    public double getTaxRate() {
        return plugin.getConfigManager().getConfig().getDouble("bank.territory-tax-rate", 0);
    }

    /**
     * Apply territory tax — called periodically.
     */
    public void applyTerritoryTax() {
        double rate = getTaxRate();
        if (rate <= 0) return;

        for (Clan clan : plugin.getClanManager().getAllClans()) {
            int claims = plugin.getTerritoryManager().getClaimCount(clan.getId());
            if (claims <= 0) continue;

            double tax = claims * rate;
            double balance = getBalance(clan.getId());

            if (balance >= tax) {
                // Atomic: use addBalance instead of read-modify-write
                addBalance(clan.getId(), -tax);
            } else {
                // Can't pay tax — unclaim random territories
                setBalance(clan.getId(), 0);
                int toUnclaim = (int) Math.ceil((tax - balance) / rate);
                plugin.getTerritoryManager().unclaimRandom(clan.getId(), toUnclaim);

                for (org.bukkit.entity.Player m : plugin.getClanManager().getOnlineMembers(clan)) {
                    plugin.getMessageManager().sendMessage(m, "bank.tax-unclaimed",
                            "{chunks}", String.valueOf(toUnclaim));
                }
            }
        }
    }

    // Persistence
    public void loadBalance(String clanId, double amount) {
        balances.put(clanId, amount);
    }

    public Map<String, Double> getAllBalances() {
        return Map.copyOf(balances);
    }

    public void removeBalance(String clanId) {
        balances.remove(clanId);
    }
}
