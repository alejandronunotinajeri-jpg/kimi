package com.ethernova.clans.command.sub;

import com.ethernova.clans.EthernovaClans;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Registry that manages all subcommand handlers.
 * Provides command lookup and tab completion aggregation.
 */
public class SubCommandRegistry {

    private final Map<String, SubCommand> commands = new LinkedHashMap<>();
    private final Map<String, SubCommand> aliases = new HashMap<>();

    /**
     * Register a subcommand handler.
     */
    public void register(SubCommand command) {
        commands.put(command.getName().toLowerCase(), command);
        for (String alias : command.getAliases()) {
            aliases.put(alias.toLowerCase(), command);
        }
    }

    /**
     * Find a subcommand by name or alias.
     * @return the subcommand, or null if not found
     */
    public SubCommand find(String name) {
        String lower = name.toLowerCase();
        SubCommand cmd = commands.get(lower);
        if (cmd != null) return cmd;
        return aliases.get(lower);
    }

    /**
     * Get all registered subcommand names (for tab completion).
     */
    public List<String> getAllNames() {
        List<String> names = new ArrayList<>(commands.keySet());
        names.addAll(aliases.keySet());
        return names;
    }

    /**
     * Get tab completions filtered by partial input.
     */
    public List<String> getCompletions(String partial) {
        String lower = partial.toLowerCase();
        return getAllNames().stream()
                .filter(name -> name.startsWith(lower))
                .sorted()
                .collect(Collectors.toList());
    }

    /**
     * Get all registered subcommands (for help).
     */
    public Collection<SubCommand> getAllCommands() {
        return Collections.unmodifiableCollection(commands.values());
    }

    /**
     * Execute a subcommand by name.
     * @return true if the command was found and executed
     */
    public boolean execute(EthernovaClans plugin, Player player, String name, String[] args) {
        SubCommand cmd = find(name);
        if (cmd == null) return false;

        // Check permission
        if (cmd.getPermission() != null && !player.hasPermission(cmd.getPermission())) {
            player.sendMessage(plugin.getConfigManager().getMessage("general.no-permission"));
            return true;
        }

        cmd.execute(plugin, player, args);
        return true;
    }

    /**
     * Get tab completions for a specific subcommand.
     */
    public List<String> tabComplete(EthernovaClans plugin, Player player, String name, String[] args) {
        SubCommand cmd = find(name);
        if (cmd == null) return List.of();
        return cmd.tabComplete(plugin, player, args);
    }
}
