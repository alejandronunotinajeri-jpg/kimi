package com.ethernova.clans.achievement;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.event.ClanAchievementEvent;
import com.ethernova.clans.util.SoundUtil;
import com.ethernova.clans.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages clan achievements — persistent milestones that reward clans.
 * Achievements are defined in achievements.yml and tracked per clan in the database.
 */
public class AchievementManager {

    private final EthernovaClans plugin;
    private FileConfiguration achievementsConfig;

    /** Achievement definitions loaded from achievements.yml */
    private final Map<String, AchievementDefinition> achievementDefs = new LinkedHashMap<>();

    /** Unlocked achievements per clan: clanId -> set of achievement ids */
    private final Map<String, Set<String>> unlockedAchievements = new ConcurrentHashMap<>();

    /** Completed mission count per clan (tracked in memory for MISSIONS type) */
    private final Map<String, Integer> missionCompletions = new ConcurrentHashMap<>();

    /** Total upgrade purchases per clan */
    private final Map<String, Integer> upgradePurchases = new ConcurrentHashMap<>();

    public AchievementManager(EthernovaClans plugin) {
        this.plugin = plugin;
        loadDefinitions();
    }

    // ══════════════════════════════════════════════════════════
    //  LOADING
    // ══════════════════════════════════════════════════════════

    public void loadDefinitions() {
        achievementDefs.clear();
        File file = new File(plugin.getDataFolder(), "achievements.yml");
        if (!file.exists()) {
            plugin.saveResource("achievements.yml", false);
        }
        achievementsConfig = YamlConfiguration.loadConfiguration(file);

        ConfigurationSection section = achievementsConfig.getConfigurationSection("achievements");
        if (section == null) return;

        for (String key : section.getKeys(false)) {
            ConfigurationSection aSec = section.getConfigurationSection(key);
            if (aSec == null) continue;

            String name = aSec.getString("name", key);
            String description = aSec.getString("description", "");
            AchievementType type = AchievementType.fromString(aSec.getString("type", "KILLS"));
            int target = aSec.getInt("target", 1);
            String icon = aSec.getString("icon", "DIAMOND");
            int powerReward = aSec.getInt("rewards.power", 0);
            double moneyReward = aSec.getDouble("rewards.money", 0);
            int xpReward = aSec.getInt("rewards.xp", 0);

            achievementDefs.put(key, new AchievementDefinition(
                    key, name, description, type, target,
                    icon, powerReward, moneyReward, xpReward
            ));
        }

        plugin.getLogger().info("✔ Loaded " + achievementDefs.size() + " achievement definitions");
    }

    // ══════════════════════════════════════════════════════════
    //  CHECKING & UNLOCKING
    // ══════════════════════════════════════════════════════════

    /**
     * Check all achievements for a clan and unlock any that are newly met.
     * Called after relevant events (kills, claims, level ups, etc.)
     */
    public void checkAchievements(Clan clan) {
        if (clan == null) return;

        Set<String> unlocked = unlockedAchievements.computeIfAbsent(clan.getId(), k -> ConcurrentHashMap.newKeySet());
        boolean changed = false;

        for (AchievementDefinition def : achievementDefs.values()) {
            if (unlocked.contains(def.id())) continue; // Already unlocked

            int current = getCurrentValue(clan, def.type());
            if (current >= def.target()) {
                unlocked.add(def.id());
                changed = true;
                grantReward(clan, def);

                // Fire event
                var event = new ClanAchievementEvent(clan, def.id(), def.name());
                Bukkit.getPluginManager().callEvent(event);

                // Notify online members
                notifyAchievement(clan, def);
            }
        }

        if (changed) {
            saveAchievementsAsync(clan.getId());
        }
    }

    /**
     * Check achievements only for a specific type (more efficient).
     */
    public void checkAchievements(Clan clan, AchievementType type) {
        if (clan == null) return;

        Set<String> unlocked = unlockedAchievements.computeIfAbsent(clan.getId(), k -> ConcurrentHashMap.newKeySet());
        boolean changed = false;

        for (AchievementDefinition def : achievementDefs.values()) {
            if (def.type() != type) continue;
            if (unlocked.contains(def.id())) continue;

            int current = getCurrentValue(clan, def.type());
            if (current >= def.target()) {
                unlocked.add(def.id());
                changed = true;
                grantReward(clan, def);

                var event = new ClanAchievementEvent(clan, def.id(), def.name());
                Bukkit.getPluginManager().callEvent(event);

                notifyAchievement(clan, def);
            }
        }

        if (changed) {
            saveAchievementsAsync(clan.getId());
        }
    }

    /**
     * Get the current value for an achievement type from a clan.
     */
    private int getCurrentValue(Clan clan, AchievementType type) {
        return switch (type) {
            case KILLS -> clan.getTotalKills();
            case DEATHS -> clan.getTotalDeaths();
            case MEMBERS -> clan.getMembers().size();
            case CLAIMS -> plugin.getTerritoryManager().getClaimCount(clan.getId());
            case POWER -> (int) clan.getPower();
            case LEVEL -> plugin.getLevelManager().getLevel(clan.getId());
            case BANK_BALANCE -> (int) clan.getBank().getBalance();
            case WARS_WON -> clan.getWarsWon();
            case WARS_FOUGHT -> clan.getWarsWon() + clan.getWarsLost();
            case ALLIES -> clan.getAllies().size();
            case UPGRADES -> upgradePurchases.getOrDefault(clan.getId(), countTotalUpgrades(clan));
            case MISSIONS -> missionCompletions.getOrDefault(clan.getId(), 0);
            case DEPOSITS -> (int) clan.getBank().getBalance(); // Approximation using current balance
        };
    }

    /**
     * Count total upgrade levels purchased by a clan.
     */
    private int countTotalUpgrades(Clan clan) {
        int total = 0;
        for (int level : clan.getUpgrades().values()) {
            total += level;
        }
        upgradePurchases.put(clan.getId(), total);
        return total;
    }

    /**
     * Grant achievement rewards to a clan.
     */
    private void grantReward(Clan clan, AchievementDefinition def) {
        if (def.powerReward() > 0) {
            // Distribute power reward to clan leader
            plugin.getPowerManager().addPower(clan.getLeaderUuid(), def.powerReward());
        }
        if (def.moneyReward() > 0) {
            double maxBalance = plugin.getConfigManager().getDouble(
                    "bank.max-balance-per-level." + clan.getLevel(), 50000);
            clan.getBank().deposit(def.moneyReward(), maxBalance, null);
            // Balance sync already handled by BalanceChangeListener
        }
        // XP reward adds extra power which drives level-ups
        if (def.xpReward() > 0) {
            plugin.getPowerManager().addPower(clan.getLeaderUuid(), def.xpReward());
        }
    }

    /**
     * Notify all online clan members about an achievement unlock.
     */
    private void notifyAchievement(Clan clan, AchievementDefinition def) {
        net.kyori.adventure.text.Component msg = plugin.getConfigManager().getMessage("achievements.unlocked",
                "achievement", def.name(),
                "description", def.description(),
                "power", String.valueOf(def.powerReward()),
                "money", TextUtil.formatCurrency(def.moneyReward()),
                "xp", String.valueOf(def.xpReward()));

        for (var member : clan.getOnlineMembers()) {
            Player player = Bukkit.getPlayer(member.getUuid());
            if (player != null) {
                player.sendMessage(msg);
                // Play achievement sound
                SoundUtil.play(player, "ENTITY_PLAYER_LEVELUP");
            }
        }
    }

    // ══════════════════════════════════════════════════════════
    //  TRACKING HELPERS (called from listeners/managers)
    // ══════════════════════════════════════════════════════════

    /**
     * Increment mission completion counter and check achievements.
     */
    public void trackMissionCompletion(Clan clan) {
        missionCompletions.merge(clan.getId(), 1, Integer::sum);
        checkAchievements(clan, AchievementType.MISSIONS);
    }

    /**
     * Increment upgrade purchase counter and check achievements.
     */
    public void trackUpgradePurchase(Clan clan) {
        upgradePurchases.merge(clan.getId(), 1, Integer::sum);
        checkAchievements(clan, AchievementType.UPGRADES);
    }

    // ══════════════════════════════════════════════════════════
    //  GETTERS
    // ══════════════════════════════════════════════════════════

    public boolean isUnlocked(Clan clan, String achievementId) {
        Set<String> unlocked = unlockedAchievements.get(clan.getId());
        return unlocked != null && unlocked.contains(achievementId);
    }

    public Set<String> getUnlockedAchievements(Clan clan) {
        return Collections.unmodifiableSet(
                unlockedAchievements.getOrDefault(clan.getId(), Set.of()));
    }

    public int getUnlockedCount(Clan clan) {
        Set<String> unlocked = unlockedAchievements.get(clan.getId());
        return unlocked == null ? 0 : unlocked.size();
    }

    public int getTotalCount() {
        return achievementDefs.size();
    }

    public Collection<AchievementDefinition> getAllDefinitions() {
        return Collections.unmodifiableCollection(achievementDefs.values());
    }

    public AchievementDefinition getDefinition(String id) {
        return achievementDefs.get(id);
    }

    /**
     * Get progress percentage for an achievement (0.0 to 100.0).
     */
    public double getProgress(Clan clan, AchievementDefinition def) {
        int current = getCurrentValue(clan, def.type());
        return Math.min(100.0, (double) current / def.target() * 100.0);
    }

    /**
     * Get current numeric progress for an achievement.
     */
    public int getCurrentProgress(Clan clan, AchievementDefinition def) {
        return getCurrentValue(clan, def.type());
    }

    // ══════════════════════════════════════════════════════════
    //  DATABASE PERSISTENCE
    // ══════════════════════════════════════════════════════════

    /**
     * Load all unlocked achievements from the database.
     */
    public void loadAllFromDatabase() {
        try {
            Map<String, Set<String>> all = plugin.getStorageManager().loadAllClanAchievements();
            for (var entry : all.entrySet()) {
                unlockedAchievements.put(entry.getKey(), ConcurrentHashMap.newKeySet());
                unlockedAchievements.get(entry.getKey()).addAll(entry.getValue());
            }
            plugin.getLogger().info("  ○ Loaded achievements for " + all.size() + " clans");
        } catch (Exception e) {
            plugin.getLogger().log(java.util.logging.Level.WARNING, "Failed to load clan achievements from DB", e);
        }
    }

    /**
     * Save achievements to DB asynchronously.
     */
    private void saveAchievementsAsync(String clanId) {
        Set<String> achievements = unlockedAchievements.get(clanId);
        if (achievements == null) return;
        Set<String> snapshot = new HashSet<>(achievements);
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () ->
                plugin.getStorageManager().saveClanAchievements(clanId, snapshot));
    }

    /**
     * Save all achievements to DB (called on shutdown).
     */
    public void saveAllToDatabase() {
        for (var entry : unlockedAchievements.entrySet()) {
            plugin.getStorageManager().saveClanAchievements(entry.getKey(), new HashSet<>(entry.getValue()));
        }
    }

    /**
     * Clean up data for a disbanded clan.
     */
    public void cleanupClan(String clanId) {
        unlockedAchievements.remove(clanId);
        missionCompletions.remove(clanId);
        upgradePurchases.remove(clanId);
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () ->
                plugin.getStorageManager().deleteClanAchievements(clanId));
    }

    // ══════════════════════════════════════════════════════════
    //  RECORDS & ENUMS
    // ══════════════════════════════════════════════════════════

    public record AchievementDefinition(
            String id,
            String name,
            String description,
            AchievementType type,
            int target,
            String icon,
            int powerReward,
            double moneyReward,
            int xpReward
    ) {}

    public enum AchievementType {
        KILLS, DEATHS, MEMBERS, CLAIMS, POWER, LEVEL,
        BANK_BALANCE, WARS_WON, WARS_FOUGHT, ALLIES,
        UPGRADES, MISSIONS, DEPOSITS;

        public static AchievementType fromString(String s) {
            try { return valueOf(s.toUpperCase()); }
            catch (Exception e) { return KILLS; }
        }
    }
}
