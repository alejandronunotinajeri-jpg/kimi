package com.ethernova.clans.hook;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/**
 * TAB/FastTab plugin integration for displaying clan tags in tab/scoreboard.
 * Compatible with TAB plugin (NEZNAMY/TAB).
 */
public class TabHook {

    private final EthernovaClans plugin;
    private boolean enabled;

    public TabHook(EthernovaClans plugin) {
        this.plugin = plugin;
        this.enabled = Bukkit.getPluginManager().getPlugin("TAB") != null;
    }

    public boolean isEnabled() {
        return enabled;
    }

    /**
     * Update a player's tab display with their clan tag.
     * This works through PlaceholderAPI placeholders that TAB reads.
     * TAB plugin should be configured to use %ethernova_clan_tag_colored% placeholder.
     */
    public void updatePlayer(Player player, Clan clan) {
        if (!enabled) return;

        // TAB plugin reads PlaceholderAPI placeholders automatically.
        // The configuration in TAB's config.yml should reference:
        //   tabprefix: "%ethernova_clan_tag_colored% "
        // or
        //   tagprefix: "%ethernova_clan_tag_colored% "
        //
        // No direct API call needed - TAB refreshes PAPI placeholders on its own schedule.
        // However, we can force a refresh if the TAB API is available.

        try {
            // Try to force TAB to refresh this player's placeholders
            // This uses reflection to avoid hard dependency
            Class<?> tabApiClass = Class.forName("me.neznamy.tab.api.TabAPI");
            var getInstance = tabApiClass.getMethod("getInstance");
            var tabApi = getInstance.invoke(null);

            var getPlayer = tabApi.getClass().getMethod("getPlayer", java.util.UUID.class);
            var tabPlayer = getPlayer.invoke(tabApi, player.getUniqueId());

            if (tabPlayer != null) {
                // TAB will auto-refresh, but we log for debug
                if (plugin.getConfigManager().getBoolean("general.debug", false)) {
                    plugin.getLogger().info("TAB update triggered for " + player.getName());
                }
            }
        } catch (Exception ignored) {
            // TAB API not available or changed - fallback to PAPI-based integration
        }
    }

    /**
     * Update all online players' tab displays.
     */
    public void updateAllPlayers() {
        if (!enabled) return;
        for (Player player : Bukkit.getOnlinePlayers()) {
            Clan clan = plugin.getClanManager().getClanByPlayer(player);
            updatePlayer(player, clan);
        }
    }

    /**
     * Remove clan tag from a player's tab display.
     */
    public void removePlayer(Player player) {
        if (!enabled) return;
        // When a player leaves their clan, PAPI will return empty for clan placeholders
        // TAB will pick this up on next refresh
        updatePlayer(player, null);
    }
}
