package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.ColorUtil;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.SoundUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.List;

/**
 * Color picker GUI for clan tag colors and gradients.
 * Supports solid colors, preset gradients, and custom HEX input.
 */
public class ColorPickerGui extends AbstractGui {

    private String mode = "solid"; // solid, gradient, preset
    private String selectedGradientStart = null;

    // Slots for color palette
    private static final int[] COLOR_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34
    };

    // Slots for gradient presets
    private static final int[] GRADIENT_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25
    };

    public ColorPickerGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "color-picker");
    }

    @Override
    protected void populateItems() {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return;

        switch (mode) {
            case "solid" -> populateSolidColors(clan);
            case "gradient" -> populateGradientSelect(clan);
            case "preset" -> populateGradientPresets(clan);
        }

        // Preview of current tag
        setItem(4, new ItemBuilder(Material.NAME_TAG)
                .name("<white>Preview: " + clan.getFormattedTag())
                .lore(List.of(
                        "",
                        "<gray>Current color: <white>" + (clan.getTagColor() != null ? clan.getTagColor() : "none"),
                        "<gray>Gradient: <white>" + (clan.isUseGradient() ? "Yes" : "No")
                ))
                .build());

        // Mode tabs (row 6 to avoid collision with palette)
        setItem(45, new ItemBuilder(Material.RED_DYE)
                .name("<red>Solid Color")
                .lore(List.of("<gray>Pick a single color for your tag"))
                .glowIf(mode.equals("solid"))
                .build());
        slotActions.put(45, "MODE_SOLID");

        setItem(46, new ItemBuilder(Material.ORANGE_DYE)
                .name("<gold>Custom Gradient")
                .lore(List.of("<gray>Choose start and end colors"))
                .glowIf(mode.equals("gradient"))
                .build());
        slotActions.put(46, "MODE_GRADIENT");

        setItem(47, new ItemBuilder(Material.PURPLE_DYE)
                .name("<light_purple>Preset Gradients")
                .lore(List.of("<gray>Choose from beautiful presets"))
                .glowIf(mode.equals("preset"))
                .build());
        slotActions.put(47, "MODE_PRESET");

        // Custom HEX button
        setItem(52, new ItemBuilder(Material.WRITABLE_BOOK)
                .name("<yellow>Custom HEX")
                .lore(List.of("<gray>Type a custom #RRGGBB code"))
                .build());
        slotActions.put(52, "CUSTOM_HEX");
    }

    private void populateSolidColors(Clan clan) {
        for (int i = 0; i < COLOR_SLOTS.length && i < ColorUtil.PRESET_COLORS.length; i++) {
            String[] preset = ColorUtil.PRESET_COLORS[i];
            String name = preset[0];
            String hex = preset[1];

            boolean selected = hex.equalsIgnoreCase(clan.getTagColor());
            setItem(COLOR_SLOTS[i], new ItemBuilder(Material.LEATHER_CHESTPLATE)
                    .name("<color:" + hex + ">" + name)
                    .lore(List.of(
                            "<gray>HEX: <white>" + hex,
                            "<gray>Preview: " + ColorUtil.solidColor(clan.getTag(), hex),
                            "",
                            selected ? "<green>✔ Selected" : "<yellow>Click to select"
                    ))
                    .leatherColor(hex)
                    .glowIf(selected)
                    .hideFlags()
                    .build());
            slotActions.put(COLOR_SLOTS[i], "COLOR:" + hex);
        }
    }

    private void populateGradientSelect(Clan clan) {
        // Show colors to pick gradient start/end
        for (int i = 0; i < COLOR_SLOTS.length && i < ColorUtil.PRESET_COLORS.length; i++) {
            String[] preset = ColorUtil.PRESET_COLORS[i];
            String name = preset[0];
            String hex = preset[1];

            boolean isStart = hex.equalsIgnoreCase(selectedGradientStart);
            String instruction;
            if (selectedGradientStart == null) {
                instruction = "<yellow>Click to set as START color";
            } else if (isStart) {
                instruction = "<green>✔ START color selected";
            } else {
                instruction = "<yellow>Click to set as END color";
            }

            setItem(COLOR_SLOTS[i], new ItemBuilder(Material.LEATHER_CHESTPLATE)
                    .name("<color:" + hex + ">" + name)
                    .lore(List.of(
                            "<gray>HEX: <white>" + hex,
                            "",
                            instruction,
                            selectedGradientStart != null && !isStart ?
                                    "<gray>Preview: " + ColorUtil.gradient(clan.getTag(), selectedGradientStart, hex) : ""
                    ))
                    .leatherColor(hex)
                    .glowIf(isStart)
                    .hideFlags()
                    .build());
            slotActions.put(COLOR_SLOTS[i], "GRADIENT_COLOR:" + hex);
        }

        if (selectedGradientStart != null) {
            setItem(49, new ItemBuilder(Material.BARRIER)
                    .name("<red>Reset Selection")
                    .lore(List.of("<gray>Start over"))
                    .build());
            slotActions.put(49, "GRADIENT_RESET");
        }
    }

    private void populateGradientPresets(Clan clan) {
        for (int i = 0; i < GRADIENT_SLOTS.length && i < ColorUtil.PRESET_GRADIENTS.length; i++) {
            String[] preset = ColorUtil.PRESET_GRADIENTS[i];
            String name = preset[0];
            String start = preset[1];
            String end = preset[2];

            boolean selected = start.equalsIgnoreCase(clan.getGradientStart()) &&
                    end.equalsIgnoreCase(clan.getGradientEnd());

            setItem(GRADIENT_SLOTS[i], new ItemBuilder(Material.FIREWORK_STAR)
                    .name(ColorUtil.gradient(name, start, end))
                    .lore(List.of(
                            "<gray>Colors: <white>" + start + " → " + end,
                            "<gray>Preview: " + ColorUtil.gradient(clan.getTag(), start, end),
                            "",
                            selected ? "<green>✔ Selected" : "<yellow>Click to apply"
                    ))
                    .glowIf(selected)
                    .build());
            slotActions.put(GRADIENT_SLOTS[i], "PRESET:" + start + ":" + end);
        }
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return false;

        // Permission check — only CO_LEADER+ can change clan colors
        var colorMember = clan.getMember(player.getUniqueId());
        if (colorMember == null || !colorMember.getRole().isAtLeast(com.ethernova.clans.clan.ClanRole.CO_LEADER)) {
            player.sendMessage(plugin.getConfigManager().getMessage("general.no-permission"));
            SoundUtil.error(player);
            return true;
        }

        // YAML action: COLOR_MODE:solid / COLOR_MODE:gradient
        if (action.startsWith("COLOR_MODE:")) {
            String modeValue = action.substring("COLOR_MODE:".length());
            switch (modeValue.toLowerCase()) {
                case "solid" -> mode = "solid";
                case "gradient" -> mode = "gradient";
            }
            selectedGradientStart = null;
            refreshGui();
            return true;
        }

        // YAML action: SELECT_COLOR:#RRGGBB – apply solid color immediately
        if (action.startsWith("SELECT_COLOR:")) {
            String hex = action.substring("SELECT_COLOR:".length());
            clan.setTagColorStart(hex);
            clan.setTagUseGradient(false);
            player.sendMessage(plugin.getConfigManager().getMessage("settings.color-changed",
                    "color", hex, "preview", clan.getFormattedTag()));
            SoundUtil.success(player);
            saveAsync(clan);
            refreshGui();
            return true;
        }

        // YAML action: ANVIL_INPUT:custom-hex – prompt for custom hex
        if (action.startsWith("ANVIL_INPUT:custom-hex")) {
            player.closeInventory();
            player.sendMessage(plugin.getConfigManager().getMessage("settings.enter-hex"));
            plugin.getGuiManager().registerAnvilInput(player, input -> {
                String hex = ColorUtil.normalizeHex(input);
                Clan c = plugin.getClanManager().getClanByPlayer(player);
                if (c != null) {
                    c.setTagColorStart(hex);
                    c.setTagUseGradient(false);
                    player.sendMessage(plugin.getConfigManager().getMessage("settings.color-changed",
                            "color", hex, "preview", c.getFormattedTag()));
                    plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () ->
                            plugin.getStorageManager().saveClan(c));
                }
                plugin.getServer().getScheduler().runTask(plugin, () ->
                        plugin.getGuiManager().openColorPicker(player));
            });
            return true;
        }

        // YAML action: GRADIENT_SET:1 / GRADIENT_SET:2 / GRADIENT_SET:3 – switch to gradient mode
        if (action.startsWith("GRADIENT_SET:")) {
            // Switch to gradient selection mode so user can pick colors
            mode = "gradient";
            selectedGradientStart = null;
            SoundUtil.click(player);
            refreshGui();
            return true;
        }

        // Legacy prefix: COLOR:#RRGGBB
        if (action.startsWith("COLOR:")) {
            String hex = action.substring("COLOR:".length());
            clan.setTagColorStart(hex);
            clan.setTagUseGradient(false);
            player.sendMessage(plugin.getConfigManager().getMessage("settings.color-changed",
                    "color", hex, "preview", clan.getFormattedTag()));
            SoundUtil.success(player);
            saveAsync(clan);
            refreshGui();
            return true;
        }

        if (action.startsWith("GRADIENT_COLOR:")) {
            String hex = action.substring("GRADIENT_COLOR:".length());
            if (selectedGradientStart == null) {
                selectedGradientStart = hex;
                SoundUtil.click(player);
            } else {
                // Apply gradient
                String startHex = selectedGradientStart;
                clan.setTagColorStart(startHex);
                clan.setTagColorEnd(hex);
                clan.setTagUseGradient(true);
                selectedGradientStart = null;
                player.sendMessage(plugin.getConfigManager().getMessage("settings.gradient-changed",
                        "from", startHex, "to", hex, "preview", clan.getFormattedTag()));
                SoundUtil.success(player);
                saveAsync(clan);
            }
            refreshGui();
            return true;
        }

        if (action.startsWith("PRESET:")) {
            String[] parts = action.split(":");
            if (parts.length == 3) {
                clan.setTagColorStart(parts[1]);
                clan.setTagColorEnd(parts[2]);
                clan.setTagUseGradient(true);
                player.sendMessage(plugin.getConfigManager().getMessage("settings.gradient-changed",
                        "from", parts[1], "to", parts[2], "preview", clan.getFormattedTag()));
                SoundUtil.success(player);
                saveAsync(clan);
                refreshGui();
            }
            return true;
        }

        return switch (action.toUpperCase()) {
            case "MODE_SOLID" -> {
                mode = "solid";
                selectedGradientStart = null;
                refreshGui();
                yield true;
            }
            case "MODE_GRADIENT" -> {
                mode = "gradient";
                selectedGradientStart = null;
                refreshGui();
                yield true;
            }
            case "MODE_PRESET" -> {
                mode = "preset";
                selectedGradientStart = null;
                refreshGui();
                yield true;
            }
            case "GRADIENT_RESET" -> {
                selectedGradientStart = null;
                refreshGui();
                yield true;
            }
            case "CUSTOM_HEX" -> {
                player.closeInventory();
                player.sendMessage(plugin.getConfigManager().getMessage("settings.enter-hex"));
                plugin.getGuiManager().registerAnvilInput(player, input -> {
                    String hex = ColorUtil.normalizeHex(input);
                    Clan c = plugin.getClanManager().getClanByPlayer(player);
                    if (c != null) {
                        c.setTagColorStart(hex);
                        c.setTagUseGradient(false);
                        player.sendMessage(plugin.getConfigManager().getMessage("settings.color-changed",
                                "color", hex, "preview", c.getFormattedTag()));
                    }
                    plugin.getServer().getScheduler().runTask(plugin, () ->
                            plugin.getGuiManager().openColorPicker(player));
                });
                yield true;
            }
            case "APPLY_COLORS" -> {
                player.sendMessage(plugin.getConfigManager().getMessage("settings.color-applied",
                        "color", clan.getFormattedTag()));
                SoundUtil.success(player);
                yield true;
            }
            default -> false;
        };
    }

    private void saveAsync(Clan clan) {
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () ->
                plugin.getStorageManager().saveClan(clan));
    }

    private void refreshGui() {
        occupiedSlots.clear();
        slotActions.clear();
        slotConfigs.clear();
        rightClickActions.clear();
        fillBackground();
        placeConfigItems();
        populateItems();

        // Update nametags for all clan members when colors change
        Clan refreshClan = plugin.getClanManager().getClanByPlayer(player);
        if (refreshClan != null && plugin.getNametagManager() != null) {
            plugin.getNametagManager().updateClanMembers(refreshClan);
        }
    }
}
