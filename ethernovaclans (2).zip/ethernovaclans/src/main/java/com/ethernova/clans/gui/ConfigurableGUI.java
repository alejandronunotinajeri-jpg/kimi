package com.ethernova.clans.gui;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.io.File;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Fully configurable GUI system — all items, slots, lore, actions loaded from YAML.
 */
public class ConfigurableGUI {

    private final EthernovaClans plugin;
    private final MiniMessage mini = MiniMessage.miniMessage();
    private final Map<String, YamlConfiguration> guiConfigs = new HashMap<>();

    public ConfigurableGUI(EthernovaClans plugin) {
        this.plugin = plugin;
        loadAll();
    }

    public void loadAll() {
        guiConfigs.clear();
        File guiFolder = new File(plugin.getDataFolder(), "guis");
        if (!guiFolder.exists()) guiFolder.mkdirs();
        // Always extract missing default GUIs (safe: saveResource won't overwrite existing)
        saveDefaults();
        File[] files = guiFolder.listFiles((d, n) -> n.endsWith(".yml"));
        if (files == null) return;
        for (File file : files) {
            String name = file.getName().replace(".yml", "");
            guiConfigs.put(name, YamlConfiguration.loadConfiguration(file));
        }
    }

    /**
     * Get the loaded YAML configuration for a GUI by name.
     * Used by AbstractGui to load layout, items, and actions.
     */
    public YamlConfiguration getConfig(String guiName) {
        return guiConfigs.get(guiName);
    }

    public void open(Player player, String guiName) {
        YamlConfiguration config = guiConfigs.get(guiName);
        if (config == null) {
            plugin.getLogger().warning("GUI not found: " + guiName);
            return;
        }

        Clan clan = plugin.getClanManager().getClanByPlayer(player.getUniqueId());
        String title = replacePlaceholders(config.getString("title", guiName), player, clan);
        int size = config.getInt("size", 54);

        Inventory inv = Bukkit.createInventory(null, size, mini.deserialize(title));

        // Fill
        String fillMat = config.getString("fill.material", "");
        if (!fillMat.isBlank()) {
            try {
                ItemStack fill = createItem(Material.valueOf(fillMat.toUpperCase()), " ", null);
                for (int i = 0; i < size; i++) inv.setItem(i, fill);
            } catch (Exception e) {
                plugin.getLogger().warning("Invalid fill material in GUI config: '" + fillMat + "'");
            }
        }

        // Border
        String borderMat = config.getString("border.material", "");
        if (!borderMat.isBlank()) {
            try {
                ItemStack border = createItem(Material.valueOf(borderMat.toUpperCase()), " ", null);
                for (int i = 0; i < size; i++) {
                    if (i < 9 || i >= size - 9 || i % 9 == 0 || i % 9 == 8) inv.setItem(i, border);
                }
            } catch (Exception e) {
                plugin.getLogger().warning("Invalid border material in GUI config: '" + borderMat + "'");
            }
        }

        // Items
        ConfigurationSection items = config.getConfigurationSection("items");
        if (items != null) {
            for (String key : items.getKeys(false)) {
                ConfigurationSection item = items.getConfigurationSection(key);
                if (item == null) continue;

                // Condition check
                String condition = item.getString("condition", "");
                if (!checkCondition(condition, player, clan)) continue;

                int slot = item.getInt("slot", 0);
                String matName = item.getString("material", "STONE");
                String displayName = replacePlaceholders(item.getString("name", key), player, clan);
                List<String> lore = item.getStringList("lore").stream()
                        .map(l -> replacePlaceholders(l, player, clan))
                        .collect(Collectors.toList());
                int amount = item.getInt("amount", 1);
                boolean glow = item.getBoolean("glow", false);
                int customModelData = item.getInt("custom-model-data", 0);

                Material mat;
                try { mat = Material.valueOf(matName.toUpperCase()); }
                catch (Exception e) { plugin.getLogger().warning("Invalid material in GUI config: '" + matName + "'"); mat = Material.STONE; }

                ItemStack is;
                if (mat == Material.PLAYER_HEAD && item.contains("skull-owner")) {
                    is = createSkull(item.getString("skull-owner", ""), player, displayName, lore);
                } else {
                    is = createItem(mat, displayName, lore);
                }

                is.setAmount(amount);
                ItemMeta meta = is.getItemMeta();
                if (meta != null) {
                    if (glow) {
                        meta.addEnchant(org.bukkit.enchantments.Enchantment.UNBREAKING, 1, true);
                        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
                    }
                    if (customModelData > 0) meta.setCustomModelData(customModelData);
                    meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
                    is.setItemMeta(meta);
                }

                inv.setItem(slot, is);
            }
        }

        // Dynamic member list
        if (config.getBoolean("dynamic-members.enabled", false) && clan != null) {
            int startSlot = config.getInt("dynamic-members.start-slot", 10);
            int maxSlots = config.getInt("dynamic-members.max-slots", 28);
            List<Integer> skipSlots = config.getIntegerList("dynamic-members.skip-slots");
            int placed = 0;
            int slot = startSlot;

            for (com.ethernova.clans.clan.ClanMember member : clan.getMembers()) {
                if (placed >= maxSlots) break;
                while (skipSlots.contains(slot) || slot % 9 == 0 || slot % 9 == 8) slot++;
                if (slot >= size - 9) break;

                boolean online = Bukkit.getPlayer(member.getUuid()) != null;
                String statusColor = online ? "<green>" : "<gray>";
                String statusIcon = online ? "●" : "○";

                ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
                SkullMeta meta = (SkullMeta) skull.getItemMeta();
                if (meta != null) {
                    meta.setOwningPlayer(Bukkit.getOfflinePlayer(member.getUuid()));
                    meta.displayName(mini.deserialize(statusColor + member.getName() + " " + statusIcon + "</" + statusColor.substring(1)));
                    String rankLabel = plugin.getConfigManager().getRawMessage("gui.member-rank-label");
                    String statusText = online
                            ? plugin.getConfigManager().getRawMessage("gui.member-online")
                            : plugin.getConfigManager().getRawMessage("gui.member-offline");
                    meta.lore(List.of(
                            mini.deserialize("<gray>" + rankLabel + "</gray> <yellow>" + member.getRole().getDisplayName() + "</yellow>"),
                            mini.deserialize(statusColor + statusText + "</" + statusColor.substring(1))
                    ));
                    skull.setItemMeta(meta);
                }
                inv.setItem(slot, skull);
                slot++;
                placed++;
            }
        }

        plugin.getGuiManager().registerConfigGUI(player.getUniqueId(), guiName, inv);
        player.openInventory(inv);

        // Open sound
        String openSound = config.getString("open-sound", "");
        playSound(player, openSound);
    }

    public boolean handleClick(Player player, String guiName, InventoryClickEvent event) {
        YamlConfiguration config = guiConfigs.get(guiName);
        if (config == null) return false;

        int slot = event.getRawSlot();
        ConfigurationSection items = config.getConfigurationSection("items");
        if (items == null) return false;

        Clan clan = plugin.getClanManager().getClanByPlayer(player.getUniqueId());

        for (String key : items.getKeys(false)) {
            ConfigurationSection item = items.getConfigurationSection(key);
            if (item == null || item.getInt("slot", -1) != slot) continue;

            // Click sound
            String clickSound = item.getString("click-sound", config.getString("click-sound", "UI_BUTTON_CLICK"));
            playSound(player, clickSound);

            // Actions — support both "actions:" (list) and "action:" (singular string)
            List<String> actions = item.getStringList("actions");
            if (actions.isEmpty()) {
                String singleAction = item.getString("action");
                if (singleAction != null && !singleAction.isBlank()) {
                    actions = List.of(singleAction);
                }
            }
            for (String action : actions) {
                executeAction(player, clan, action);
            }
            return true;
        }
        return false;
    }

    private void executeAction(Player player, Clan clan, String action) {
        if (action.startsWith("[close]")) {
            player.closeInventory();
        } else if (action.startsWith("[open]")) {
            String gui = action.substring(6).trim();
            Bukkit.getScheduler().runTaskLater(plugin, () -> open(player, gui), 1L);
        } else if (action.startsWith("[command]")) {
            String cmd = replacePlaceholders(action.substring(9).trim(), player, clan);
            player.performCommand(cmd);
        } else if (action.startsWith("[console]")) {
            String cmd = replacePlaceholders(action.substring(9).trim(), player, clan);
            plugin.getLogger().info("[GUI Console] " + player.getName() + " triggered: " + cmd);
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
        } else if (action.startsWith("[message]")) {
            String msg = replacePlaceholders(action.substring(9).trim(), player, clan);
            player.sendMessage(mini.deserialize(msg));
        } else if (action.startsWith("[sound]")) {
            playSound(player, action.substring(7).trim());
        } else if (action.startsWith("[title]")) {
            String[] parts = action.substring(7).trim().split("\\|", 2);
            String title = replacePlaceholders(parts[0], player, clan);
            String subtitle = parts.length > 1 ? replacePlaceholders(parts[1], player, clan) : "";
            if (plugin.getCoreHook() != null && plugin.getCoreHook().isAvailable()) {
                plugin.getCoreHook().sendTitle(player, title, subtitle);
            }
        }
    }

    private boolean checkCondition(String condition, Player player, Clan clan) {
        if (condition == null || condition.isBlank()) return true;
        return switch (condition) {
            case "has_clan" -> clan != null;
            case "no_clan" -> clan == null;
            case "is_leader" -> clan != null && clan.getLeaderUuid().equals(player.getUniqueId());
            case "is_member" -> clan != null && clan.getMember(player.getUniqueId()) != null &&
                    clan.getMember(player.getUniqueId()).getRole().ordinal() >= com.ethernova.clans.clan.ClanRole.MEMBER.ordinal();
            case "is_officer" -> clan != null && clan.getMember(player.getUniqueId()) != null &&
                    clan.getMember(player.getUniqueId()).getRole().ordinal() >= com.ethernova.clans.clan.ClanRole.OFFICER.ordinal();
            case "is_co_leader" -> clan != null && clan.getMember(player.getUniqueId()) != null &&
                    clan.getMember(player.getUniqueId()).getRole().ordinal() >= com.ethernova.clans.clan.ClanRole.CO_LEADER.ordinal();
            case "at_war" -> clan != null && plugin.getWarManager() != null && plugin.getWarManager().isAtWar(clan);
            case "has_shield" -> clan != null && plugin.getShieldManager() != null && plugin.getShieldManager().hasActiveShield(clan.getId());
            case "in_combat" -> plugin.getCombatHook() != null && plugin.getCombatHook().isInCombat(player);
            default -> true;
        };
    }

    private String replacePlaceholders(String text, Player player, Clan clan) {
        if (text == null) return "";
        text = text.replace("{player}", player.getName());
        if (clan != null) {
            text = text.replace("{clan}", clan.getDisplayName())
                    .replace("{clan_name}", clan.getName())
                    .replace("{tag}", clan.getTag() != null ? clan.getTag() : "")
                    .replace("{members}", String.valueOf(clan.getMembers().size()))
                    .replace("{online}", String.valueOf(plugin.getClanManager().getOnlineMembers(clan).size()))
                    .replace("{power}", String.format("%.0f", plugin.getPowerManager().getClanPower(clan)))
                    .replace("{max_power}", String.format("%.0f", plugin.getPowerManager().getMaxClanPower(clan)))
                    .replace("{claims}", String.valueOf(plugin.getTerritoryManager().getClaimCount(clan.getId())))
                    .replace("{max_claims}", String.valueOf(plugin.getPowerManager().getMaxClaims(clan)))
                    .replace("{bank}", plugin.getEconomyManager().format(plugin.getBankManager().getBalance(clan.getId())))
                    .replace("{level}", String.valueOf(plugin.getLevelManager().getLevel(clan.getId())))
                    .replace("{allies}", String.valueOf(plugin.getAllianceManager().getAllyCount(clan)))
                    .replace("{leader}", clan.getLeaderName());
        } else {
            text = text.replace("{clan}", "").replace("{clan_name}", "").replace("{tag}", "")
                    .replace("{members}", "0").replace("{online}", "0").replace("{power}", "0")
                    .replace("{max_power}", "0").replace("{claims}", "0").replace("{max_claims}", "0")
                    .replace("{bank}", "$0").replace("{level}", "0").replace("{allies}", "0")
                    .replace("{leader}", "");
        }
        return text;
    }

    private ItemStack createItem(Material mat, String name, List<String> lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(mini.deserialize(name));
            if (lore != null && !lore.isEmpty()) {
                meta.lore(lore.stream().map(mini::deserialize).collect(Collectors.toList()));
            }
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack createSkull(String owner, Player player, String name, List<String> lore) {
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) skull.getItemMeta();
        if (meta != null) {
            String resolved = owner.replace("{player}", player.getName());
            meta.setOwningPlayer(Bukkit.getOfflinePlayer(resolved));
            meta.displayName(mini.deserialize(name));
            if (lore != null && !lore.isEmpty()) {
                meta.lore(lore.stream().map(mini::deserialize).collect(Collectors.toList()));
            }
            skull.setItemMeta(meta);
        }
        return skull;
    }

    private void playSound(Player player, String soundName) {
        if (soundName == null || soundName.isBlank()) return;
        try {
            Sound sound = Sound.valueOf(soundName.toUpperCase());
            player.playSound(player.getLocation(), sound, 0.5f, 1f);
        } catch (Exception e) {
            plugin.getLogger().fine("Unknown sound in GUI config: " + soundName);
        }
    }

    private void saveDefaults() {
        String[] defaults = {
                "main_menu.yml", "main-menu.yml", "members.yml", "territory.yml",
                "upgrades.yml", "war.yml", "wars.yml", "bank.yml", "settings.yml",
                "tops.yml", "missions.yml", "permissions.yml", "progress.yml",
                "diplomacy.yml", "invitations.yml", "invite-players.yml",
                "boosts.yml", "color-picker.yml", "audit-log.yml", "achievements.yml",
                "admin-menu.yml", "admin-clan.yml", "admin-clan-list.yml", "admin-player.yml",
                "clan-skills.yml", "clan-shop.yml", "event-calendar.yml", "trophies.yml",
                "stats.yml", "warps.yml", "icon-selector.yml",
                "blueprints.yml", "blueprints-admin.yml", "seasons.yml"
        };
        for (String name : defaults) {
            File guiFile = new File(plugin.getDataFolder(), "guis/" + name);
            if (!guiFile.exists()) {
                try { plugin.saveResource("guis/" + name, false); }
                catch (Exception e) { plugin.getLogger().fine("GUI resource not found: guis/" + name); }
            }
        }
    }
}
