package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.SoundUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Diplomacy GUI - manage allies and rivals.
 */
public class DiplomacyGui extends AbstractGui {

    private int allyPage = 0;
    private int rivalPage = 0;
    private static final int[] ALLY_SLOTS = {10, 11, 12, 13, 14, 15, 16};
    private static final int[] RIVAL_SLOTS = {28, 29, 30, 31, 32, 33, 34};

    public DiplomacyGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "diplomacy");
    }

    @Override
    protected void populateItems() {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return;

        populateAllies(clan);
        populateRivals(clan);
    }

    private void populateAllies(Clan clan) {
        List<String> allies = new ArrayList<>(clan.getAllies());
        int maxAllies = plugin.getLevelManager().getMaxAllies(clan.getLevel());
        int totalPages = Math.max(1, (int) Math.ceil((double) allies.size() / ALLY_SLOTS.length));
        if (allyPage >= totalPages) allyPage = totalPages - 1;
        if (allyPage < 0) allyPage = 0;

        int start = allyPage * ALLY_SLOTS.length;
        int end = Math.min(start + ALLY_SLOTS.length, allies.size());

        for (int slot : ALLY_SLOTS) inventory.setItem(slot, null);

        for (int i = 0; i < ALLY_SLOTS.length; i++) {
            int index = start + i;
            if (index >= end) continue;
            String allyId = allies.get(index);
            Clan ally = plugin.getClanManager().getClanById(allyId);
            if (ally == null) continue;

            setItem(ALLY_SLOTS[i], new ItemBuilder(Material.EMERALD)
                    .name("<green>" + ally.getName() + " " + ally.getFormattedTag())
                    .lore(List.of(
                            "",
                            "<gray>Nivel: <white>" + ally.getLevel(),
                            "<gray>Power: <white>" + ally.getPower(),
                            "<gray>Miembros: <white>" + ally.getMembers().size(),
                            "",
                            "<red>\u25b6 Click derecho para romper alianza"
                    ))
                    .build());
            slotActions.put(ALLY_SLOTS[i], "BREAK_ALLY:" + allyId);
        }

        // Ally header with count
        List<String> allyLore = new ArrayList<>();
        allyLore.add("<gray>Clanes aliados actualmente");
        if (totalPages > 1) allyLore.add("<gray>Página: <yellow>" + (allyPage + 1) + "/" + totalPages);
        setItem(18, new ItemBuilder(Material.EMERALD)
                .name("<green>\u2726 Alianzas (" + allies.size() + "/" + maxAllies + ")")
                .lore(allyLore)
                .build());

        // Ally page navigation
        if (totalPages > 1) {
            if (allyPage > 0) {
                setItem(9, new ItemBuilder(Material.ARROW)
                        .name("<yellow>\u2190 Alianzas anteriores")
                        .lore(List.of("<gray>Página " + allyPage + "/" + totalPages))
                        .build());
                slotActions.put(9, "ALLY_PREV");
            }
            if (allyPage < totalPages - 1) {
                setItem(17, new ItemBuilder(Material.ARROW)
                        .name("<yellow>Más alianzas \u2192")
                        .lore(List.of("<gray>Página " + (allyPage + 2) + "/" + totalPages))
                        .build());
                slotActions.put(17, "ALLY_NEXT");
            }
        }
    }

    private void populateRivals(Clan clan) {
        List<String> rivals = new ArrayList<>(clan.getRivals());
        int maxRivals = plugin.getConfigManager().getInt("alliances.rivalries.max-rivals", 5);
        int totalPages = Math.max(1, (int) Math.ceil((double) rivals.size() / RIVAL_SLOTS.length));
        if (rivalPage >= totalPages) rivalPage = totalPages - 1;
        if (rivalPage < 0) rivalPage = 0;

        int start = rivalPage * RIVAL_SLOTS.length;
        int end = Math.min(start + RIVAL_SLOTS.length, rivals.size());

        for (int slot : RIVAL_SLOTS) inventory.setItem(slot, null);

        for (int i = 0; i < RIVAL_SLOTS.length; i++) {
            int index = start + i;
            if (index >= end) continue;
            String rivalId = rivals.get(index);
            Clan rival = plugin.getClanManager().getClanById(rivalId);
            if (rival == null) continue;

            setItem(RIVAL_SLOTS[i], new ItemBuilder(Material.REDSTONE)
                    .name("<red>" + rival.getName() + " " + rival.getFormattedTag())
                    .lore(List.of(
                            "",
                            "<gray>Nivel: <white>" + rival.getLevel(),
                            "<gray>Power: <white>" + rival.getPower(),
                            "<gray>Miembros: <white>" + rival.getMembers().size(),
                            "",
                            "<green>\u25b6 Click derecho para quitar rivalidad"
                    ))
                    .build());
            slotActions.put(RIVAL_SLOTS[i], "REMOVE_RIVAL:" + rivalId);
        }

        // Rival header with count
        List<String> rivalLore = new ArrayList<>();
        rivalLore.add("<gray>Clanes declarados como rivales");
        if (totalPages > 1) rivalLore.add("<gray>Página: <yellow>" + (rivalPage + 1) + "/" + totalPages);
        setItem(27, new ItemBuilder(Material.REDSTONE)
                .name("<red>\u2694 Rivales (" + rivals.size() + "/" + maxRivals + ")")
                .lore(rivalLore)
                .build());

        // Rival page navigation
        if (totalPages > 1) {
            if (rivalPage > 0) {
                setItem(36, new ItemBuilder(Material.ARROW)
                        .name("<yellow>\u2190 Rivales anteriores")
                        .lore(List.of("<gray>Página " + rivalPage + "/" + totalPages))
                        .build());
                slotActions.put(36, "RIVAL_PREV");
            }
            if (rivalPage < totalPages - 1) {
                setItem(35, new ItemBuilder(Material.ARROW)
                        .name("<yellow>Más rivales \u2192")
                        .lore(List.of("<gray>Página " + (rivalPage + 2) + "/" + totalPages))
                        .build());
                slotActions.put(35, "RIVAL_NEXT");
            }
        }
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return false;

        // Page navigation
        switch (action.toUpperCase()) {
            case "ALLY_PREV" -> { allyPage = Math.max(0, allyPage - 1); refreshGui(); return true; }
            case "ALLY_NEXT" -> { allyPage++; refreshGui(); return true; }
            case "RIVAL_PREV" -> { rivalPage = Math.max(0, rivalPage - 1); refreshGui(); return true; }
            case "RIVAL_NEXT" -> { rivalPage++; refreshGui(); return true; }
        }

        // Handle OPEN_GUI actions from YAML config before prefix/switch checks
        if (action.equalsIgnoreCase("OPEN_GUI:alliance-selector")) {
            player.closeInventory();
            player.sendMessage(plugin.getConfigManager().getMessage("alliance.enter-ally-name"));
            plugin.getGuiManager().registerAnvilInput(player, input -> {
                Clan myClan = plugin.getClanManager().getClanByPlayer(player);
                if (myClan == null) return;
                Clan target = plugin.getClanManager().getClanByName(input);
                if (target == null) {
                    player.sendMessage(plugin.getConfigManager().getMessage("alliance.clan-not-found",
                            "name", input));
                    return;
                }
                if (plugin.getAllianceManager() != null) {
                    plugin.getAllianceManager().sendAllyRequest(myClan, target);
                }
                plugin.getServer().getScheduler().runTask(plugin, () ->
                        plugin.getGuiManager().openDiplomacy(player));
            });
            return true;
        }

        if (action.equalsIgnoreCase("OPEN_GUI:alliance-requests")) {
            showPendingRequests(clan);
            return true;
        }

        if (action.equalsIgnoreCase("OPEN_GUI:rival-selector")) {
            player.closeInventory();
            player.sendMessage(plugin.getConfigManager().getMessage("alliance.enter-rival-name"));
            plugin.getGuiManager().registerAnvilInput(player, input -> {
                Clan myClan = plugin.getClanManager().getClanByPlayer(player);
                if (myClan == null) return;
                Clan target = plugin.getClanManager().getClanByName(input);
                if (target == null) {
                    player.sendMessage(plugin.getConfigManager().getMessage("alliance.clan-not-found",
                            "name", input));
                    return;
                }
                if (plugin.getAllianceManager() != null) {
                    plugin.getAllianceManager().setRival(myClan, target);
                }
                plugin.getServer().getScheduler().runTask(plugin, () ->
                        plugin.getGuiManager().openDiplomacy(player));
            });
            return true;
        }

        if (action.startsWith("BREAK_ALLY:")) {
            if (!event.isRightClick()) return true;
            var member = clan.getMember(player.getUniqueId());
            if (member == null || !member.getRole().isAtLeast(com.ethernova.clans.clan.ClanRole.CO_LEADER)) {
                player.sendMessage(plugin.getConfigManager().getMessage("general.no-permission"));
                com.ethernova.clans.util.SoundUtil.error(player);
                return true;
            }
            String allyId = action.substring("BREAK_ALLY:".length());
            Clan allyClan = plugin.getClanManager().getClanById(allyId);
            if (allyClan != null && plugin.getAllianceManager() != null) {
                plugin.getAllianceManager().breakAlliance(clan, allyClan);
            }
            refreshGui();
            return true;
        }

        if (action.startsWith("REMOVE_RIVAL:")) {
            if (!event.isRightClick()) return true;
            var member2 = clan.getMember(player.getUniqueId());
            if (member2 == null || !member2.getRole().isAtLeast(com.ethernova.clans.clan.ClanRole.CO_LEADER)) {
                player.sendMessage(plugin.getConfigManager().getMessage("general.no-permission"));
                com.ethernova.clans.util.SoundUtil.error(player);
                return true;
            }
            String rivalId = action.substring("REMOVE_RIVAL:".length());
            clan.removeRival(rivalId);
            Clan rivalClan = plugin.getClanManager().getClanById(rivalId);
            if (rivalClan != null) {
                rivalClan.removeRival(clan.getId());
            }
            player.sendMessage(plugin.getConfigManager().getMessage("alliance.rival-removed"));
            refreshGui();
            return true;
        }

        return switch (action.toUpperCase()) {
            case "SEND_ALLY_REQUEST" -> {
                var allyMember = clan.getMember(player.getUniqueId());
                if (allyMember == null || !allyMember.getRole().isAtLeast(com.ethernova.clans.clan.ClanRole.CO_LEADER)) {
                    player.sendMessage(plugin.getConfigManager().getMessage("general.no-permission"));
                    com.ethernova.clans.util.SoundUtil.error(player);
                    yield true;
                }
                player.closeInventory();
                player.sendMessage(plugin.getConfigManager().getMessage("alliance.enter-ally-name"));
                plugin.getGuiManager().registerAnvilInput(player, input -> {
                    Clan myClan = plugin.getClanManager().getClanByPlayer(player);
                    if (myClan == null) return;
                    Clan target = plugin.getClanManager().getClanByName(input);
                    if (target == null) {
                        player.sendMessage(plugin.getConfigManager().getMessage("alliance.clan-not-found",
                                "name", input));
                        return;
                    }
                    if (plugin.getAllianceManager() != null) {
                        plugin.getAllianceManager().sendAllyRequest(myClan, target);
                    }
                    plugin.getServer().getScheduler().runTask(plugin, () ->
                            plugin.getGuiManager().openDiplomacy(player));
                });
                yield true;
            }
            case "SET_RIVAL" -> {
                var rivalMember = clan.getMember(player.getUniqueId());
                if (rivalMember == null || !rivalMember.getRole().isAtLeast(com.ethernova.clans.clan.ClanRole.CO_LEADER)) {
                    player.sendMessage(plugin.getConfigManager().getMessage("general.no-permission"));
                    com.ethernova.clans.util.SoundUtil.error(player);
                    yield true;
                }
                player.closeInventory();
                player.sendMessage(plugin.getConfigManager().getMessage("alliance.enter-rival-name"));
                plugin.getGuiManager().registerAnvilInput(player, input -> {
                    Clan myClan = plugin.getClanManager().getClanByPlayer(player);
                    if (myClan == null) return;
                    Clan target = plugin.getClanManager().getClanByName(input);
                    if (target == null) {
                        player.sendMessage(plugin.getConfigManager().getMessage("alliance.clan-not-found",
                                "name", input));
                        return;
                    }
                    if (plugin.getAllianceManager() != null) {
                        plugin.getAllianceManager().setRival(myClan, target);
                    }
                    plugin.getServer().getScheduler().runTask(plugin, () ->
                            plugin.getGuiManager().openDiplomacy(player));
                });
                yield true;
            }
            default -> false;
        };
    }

    private void showPendingRequests(Clan clan) {
        Set<String> pending = clan.getPendingAllyRequests();
        if (pending.isEmpty()) {
            player.sendMessage(plugin.getConfigManager().getMessage("alliance.no-pending-requests"));
            return;
        }
        player.sendMessage(plugin.getConfigManager().getMessage("alliance.pending-header",
                "count", String.valueOf(pending.size())));
        for (String requesterId : pending) {
            Clan requester = plugin.getClanManager().getClanById(requesterId);
            if (requester == null) continue;
            player.sendMessage(plugin.getConfigManager().getMessage("alliance.pending-entry",
                    "tag", requester.getFormattedTag(),
                    "clan", requester.getName(),
                    "level", String.valueOf(requester.getLevel()),
                    "members", String.valueOf(requester.getMembers().size())));
            player.sendMessage(plugin.getConfigManager().getMessage("alliance.pending-actions",
                    "clan", requester.getName()));
        }
    }

    private void refreshGui() {
        occupiedSlots.clear();
        slotActions.clear();
        rightClickActions.clear();
        slotConfigs.clear();
        fillBackground();
        placeConfigItems();
        populateItems();
    }
}
