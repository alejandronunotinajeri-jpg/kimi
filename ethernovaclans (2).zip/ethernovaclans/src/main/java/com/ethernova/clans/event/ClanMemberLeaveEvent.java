package com.ethernova.clans.event;

import com.ethernova.clans.clan.Clan;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

/**
 * Fired when a player leaves a clan (kicked or voluntary).
 */
public class ClanMemberLeaveEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();

    private final Clan clan;
    private final UUID playerUuid;
    private final String playerName;
    private final LeaveReason reason;

    public ClanMemberLeaveEvent(Clan clan, UUID playerUuid, String playerName, LeaveReason reason) {
        this.clan = clan;
        this.playerUuid = playerUuid;
        this.playerName = playerName;
        this.reason = reason;
    }

    public Clan getClan() { return clan; }
    public UUID getPlayerUuid() { return playerUuid; }
    public String getPlayerName() { return playerName; }
    public LeaveReason getReason() { return reason; }

    @Override public @NotNull HandlerList getHandlers() { return HANDLERS; }
    public static HandlerList getHandlerList() { return HANDLERS; }

    public enum LeaveReason {
        LEAVE,
        KICKED,
        DISBANDED,
        INACTIVITY
    }
}
