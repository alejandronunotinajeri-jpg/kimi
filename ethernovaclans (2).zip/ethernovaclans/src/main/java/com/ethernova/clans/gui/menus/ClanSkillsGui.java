package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanMember;
import com.ethernova.clans.clan.ClanRole;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.skill.ClanSkillManager;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.SoundUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Clan Skills/Passive tree GUI.
 * Players invest skill points (earned from leveling) into passive buffs.
 */
public class ClanSkillsGui extends AbstractGui {

    private static final int[] SKILL_SLOTS = {10, 11, 12, 13, 14, 15, 16, 19};

    public ClanSkillsGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "clan-skills");
    }

    @Override
    protected void populateItems() {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return;

        ClanSkillManager skillMgr = plugin.getSkillManager();
        if (skillMgr == null) return;

        int availablePoints = skillMgr.getAvailablePoints(clan);

        var mm = plugin.getMessageManager();

        // Header - skill points info
        setItem(4, new ItemBuilder(Material.NETHER_STAR)
                .name("<gradient:#FFD700:#FF6B35>⚡ " + mm.get("skills.gui-title") + "</gradient>")
                .lore(List.of(
                        "",
                        "<gray>" + mm.get("skills.gui-clan-level") + ": <white>" + clan.getLevel(),
                        "<gray>" + mm.get("skills.gui-available-points") + ": <yellow>" + availablePoints,
                        "<gray>" + mm.get("skills.gui-used-points") + ": <white>" + skillMgr.getTotalSkillPoints(clan.getId()),
                        "",
                        "<gray>" + mm.get("skills.gui-points-hint")
                ))
                .build());

        // Skill items
        List<ClanSkillManager.SkillDef> skills = ClanSkillManager.SKILLS;
        for (int i = 0; i < skills.size() && i < SKILL_SLOTS.length; i++) {
            ClanSkillManager.SkillDef def = skills.get(i);
            int level = skillMgr.getSkillLevel(clan.getId(), def.id());
            int slot = SKILL_SLOTS[i];

            Material mat;
            try { mat = Material.valueOf(def.icon()); } catch (Exception e) { mat = Material.BOOK; }

            List<String> lore = new ArrayList<>();
            lore.add("");
            lore.add("<gray>" + mm.get("skills.desc." + def.id()));
            lore.add("");
            lore.add("<gray>" + mm.get("skills.gui-level") + ": " + formatLevel(level, def.maxLevel()));
            lore.add(buildProgressBar(level, def.maxLevel()));

            // Show current value
            if (level > 0) {
                lore.add("<gray>" + mm.get("skills.gui-current-effect") + ": <green>+" + String.format("%.0f", def.getValue(level)) + "%");
            }
            // Show next value
            if (level < def.maxLevel()) {
                lore.add("<gray>" + mm.get("skills.gui-next-level") + ": <yellow>+" + String.format("%.0f", def.getValue(level + 1)) + "%");
                lore.add("");
                if (availablePoints > 0) {
                    lore.add("<green>" + mm.get("skills.gui-click-upgrade"));
                } else {
                    lore.add("<red>" + mm.get("skills.gui-no-points"));
                }
            } else {
                lore.add("");
                lore.add("<gold>✔ " + mm.get("skills.gui-max-level"));
            }

            ItemBuilder builder = new ItemBuilder(mat)
                    .name("<yellow>" + mm.get("skills.name." + def.id()))
                    .lore(lore)
                    .amount(Math.max(1, level));
            if (level >= def.maxLevel()) builder.glow();

            setItem(slot, builder.build());
            slotActions.put(slot, "UPGRADE_SKILL:" + def.id());
        }

        // Reset button
        ClanMember member = clan.getMember(player.getUniqueId());
        if (member != null && member.getRole() == ClanRole.LEADER && skillMgr.getTotalSkillPoints(clan.getId()) > 0) {
            setItem(49, new ItemBuilder(Material.BARRIER)
                    .name("<red>⟳ " + mm.get("skills.gui-reset-title"))
                    .lore(List.of(
                            "<gray>" + mm.get("skills.gui-reset-desc"),
                            "",
                            "<red>" + mm.get("skills.gui-reset-confirm")
                    ))
                    .build());
            slotActions.put(49, "RESET_SKILLS");
        }
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return false;

        ClanSkillManager skillMgr = plugin.getSkillManager();
        if (skillMgr == null) return false;

        if (action.startsWith("UPGRADE_SKILL:")) {
            String skillId = action.substring("UPGRADE_SKILL:".length());
            ClanMember member = clan.getMember(player.getUniqueId());
            if (member == null || !member.getRole().isAtLeast(ClanRole.OFFICER)) {
                player.sendMessage(plugin.getConfigManager().getMessage("error.no-permission"));
                return true;
            }
            if (skillMgr.upgradeSkill(clan, skillId)) {
                SoundUtil.success(player);
                player.sendMessage(plugin.getConfigManager().getMessage("skills.upgraded",
                        "skill", skillId, "level", String.valueOf(skillMgr.getSkillLevel(clan.getId(), skillId))));
            } else {
                SoundUtil.error(player);
                player.sendMessage(plugin.getConfigManager().getMessage("skills.cannot-upgrade"));
            }
            refreshGui();
            return true;
        }

        if (action.equals("RESET_SKILLS")) {
            if (!event.isShiftClick()) {
                player.sendMessage(plugin.getConfigManager().getMessage("skills.confirm-reset"));
                return true;
            }
            ClanMember member = clan.getMember(player.getUniqueId());
            if (member == null || member.getRole() != ClanRole.LEADER) {
                player.sendMessage(plugin.getConfigManager().getMessage("error.leader-only"));
                return true;
            }
            skillMgr.resetSkills(clan);
            SoundUtil.success(player);
            player.sendMessage(plugin.getConfigManager().getMessage("skills.reset-success"));
            refreshGui();
            return true;
        }

        return false;
    }

    private String formatLevel(int current, int max) {
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= max; i++) {
            if (i <= current) sb.append("<green>●");
            else sb.append("<dark_gray>●");
        }
        return sb + " <white>" + current + "/" + max;
    }

    private String buildProgressBar(int current, int max) {
        StringBuilder sb = new StringBuilder("<dark_gray>[");
        int filled = (int) ((current / (double) max) * 20);
        for (int i = 0; i < 20; i++) {
            sb.append(i < filled ? "<green>|" : "<dark_gray>|");
        }
        sb.append("<dark_gray>]");
        return sb.toString();
    }

    private void refreshGui() {
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            occupiedSlots.clear();
            slotActions.clear();
            rightClickActions.clear();
            slotConfigs.clear();
            fillBackground();
            placeConfigItems();
            populateItems();
        });
    }
}
