package com.ethernova.clans.alliance;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages alliances between clans.
 */
public class AllianceManager {

    private final EthernovaClans plugin;
    private final Map<String, Set<String>> alliances = new ConcurrentHashMap<>();
    private final Map<String, String> pendingRequests = new ConcurrentHashMap<>();

    public AllianceManager(EthernovaClans plugin) { this.plugin = plugin; }

    // ══════════════════════════════════════════════════════════
    //  ALLIANCE OPERATIONS
    // ══════════════════════════════════════════════════════════

    public boolean areAllied(Clan a, Clan b) {
        if (a == null || b == null) return false;
        Set<String> allies = alliances.get(a.getId());
        return allies != null && allies.contains(b.getId());
    }

    public void createAlliance(Clan a, Clan b) {
        alliances.computeIfAbsent(a.getId(), k -> ConcurrentHashMap.newKeySet()).add(b.getId());
        alliances.computeIfAbsent(b.getId(), k -> ConcurrentHashMap.newKeySet()).add(a.getId());
        // Sync Clan objects so clan.isAlly() is consistent with AllianceManager.areAllied()
        a.addAlly(b.getId());
        b.addAlly(a.getId());
    }

    public void removeAlliance(Clan a, Clan b) {
        Set<String> aSet = alliances.get(a.getId()); if (aSet != null) aSet.remove(b.getId());
        Set<String> bSet = alliances.get(b.getId()); if (bSet != null) bSet.remove(a.getId());
        // Sync Clan objects
        a.removeAlly(b.getId());
        b.removeAlly(a.getId());
    }

    public List<Clan> getAllies(Clan clan) {
        Set<String> ids = alliances.get(clan.getId());
        if (ids == null) return List.of();
        List<Clan> list = new ArrayList<>();
        for (String id : ids) { Clan c = plugin.getClanManager().getClan(id); if (c != null) list.add(c); }
        return list;
    }

    public int getAllyCount(Clan clan) {
        Set<String> ids = alliances.get(clan.getId());
        return ids != null ? ids.size() : 0;
    }

    // ══════════════════════════════════════════════════════════
    //  REQUESTS
    // ══════════════════════════════════════════════════════════

    public void sendAllianceRequest(String from, String to) { pendingRequests.put(from, to); }
    public boolean hasPendingRequest(String from, String to) { return to.equals(pendingRequests.get(from)); }
    public void removePendingRequest(String from) { pendingRequests.remove(from); }

    /** Clan-based overloads for command handlers */
    public void sendAllyRequest(Clan from, Clan to) {
        if (from.getId().equals(to.getId())) return; // Self-ally check
        if (areAllied(from, to)) return; // Already allied
        // If the target already sent us a request, auto-accept instead of blocking
        if (hasPendingRequest(to.getId(), from.getId())) {
            removePendingRequest(to.getId());
            createAlliance(from, to);
            if (plugin.getDiscordWebhook() != null) plugin.getDiscordWebhook().sendAllianceFormed(from, to);
            return;
        }
        int maxAllies = plugin.getConfigManager().getConfig().getInt("alliance.max-allies", 5);
        if (maxAllies > 0 && getAllyCount(from) >= maxAllies) return; // Max allies reached
        sendAllianceRequest(from.getId(), to.getId());
    }
    public void acceptAllyRequest(Clan from, Clan to) {
        if (hasPendingRequest(to.getId(), from.getId())) {
            removePendingRequest(to.getId());
            createAlliance(from, to);
            if (plugin.getDiscordWebhook() != null) plugin.getDiscordWebhook().sendAllianceFormed(from, to);
        }
    }
    public void denyAllyRequest(Clan from, Clan to) { removePendingRequest(to.getId()); }
    public void breakAlliance(Clan a, Clan b) {
        removeAlliance(a, b);
        if (plugin.getDiscordWebhook() != null) plugin.getDiscordWebhook().sendAllianceBroken(a, b);
    }
    public void setRival(Clan clan, Clan target) {
        // Rivals are one-directional
        clan.addRival(target.getId());
    }

    // ══════════════════════════════════════════════════════════
    //  PERSISTENCE
    // ══════════════════════════════════════════════════════════

    public void loadAlliance(String clanIdA, String clanIdB) {
        alliances.computeIfAbsent(clanIdA, k -> ConcurrentHashMap.newKeySet()).add(clanIdB);
        alliances.computeIfAbsent(clanIdB, k -> ConcurrentHashMap.newKeySet()).add(clanIdA);
    }

    public Set<String> getAlliedIds(String clanId) {
        Set<String> ids = alliances.get(clanId);
        return ids != null ? Set.copyOf(ids) : Set.of();
    }

    public void removeAllAlliances(String clanId) {
        Set<String> allies = alliances.remove(clanId);
        if (allies != null) {
            for (String a : allies) {
                Set<String> s = alliances.get(a); if (s != null) s.remove(clanId);
                // Sync Clan objects so clan.isAlly() stays consistent
                Clan alyClan = plugin.getClanManager().getClan(a);
                if (alyClan != null) alyClan.removeAlly(clanId);
            }
        }
        // Also sync the disbanded clan's Clan object
        Clan disbanded = plugin.getClanManager().getClan(clanId);
        if (disbanded != null) disbanded.clearAllies();
    }
}
