package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.clan.ClanMember;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.ItemBuilder;
import com.ethernova.clans.util.SoundUtil;
import com.ethernova.clans.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.List;
import java.util.Optional;

/**
 * Admin GUI for managing a specific clan — modify power, level, bank,
 * members, settings, etc.
 */
public class AdminClanGui extends AbstractGui {

    private final Clan targetClan;

    public AdminClanGui(EthernovaClans plugin, Player player, Clan targetClan) {
        super(plugin, player, "admin-clan");
        this.targetClan = targetClan;
    }

    @Override
    protected void populateItems() {
        // Items are driven by YAML + placeholders replacement
    }

    @Override
    protected String replacePlaceholders(String text) {
        if (text == null) return "";
        text = text.replace("{player}", player.getName());

        // Use the target clan instead of the admin's clan
        text = text.replace("{clan_name}", targetClan.getName())
                .replace("{clan}", targetClan.getName())
                .replace("{clan_id}", targetClan.getIdString())
                .replace("{clan_tag}", targetClan.getTag())
                .replace("{clan_tag_colored}", targetClan.getFormattedTag())
                .replace("{clan_level}", String.valueOf(targetClan.getLevel()))
                .replace("{level_name}", plugin.getLevelManager().getLevelName(targetClan.getLevel()))
                .replace("{clan_level_name}", plugin.getLevelManager().getLevelName(targetClan.getLevel()))
                .replace("{clan_power}", String.valueOf(targetClan.getPower()))
                .replace("{clan_kd}", String.format("%.2f", targetClan.getKD()))
                .replace("{members_total}", String.valueOf(targetClan.getMembers().size()))
                .replace("{members_online}", String.valueOf(targetClan.getOnlineMemberCount()))
                .replace("{clan_members}", String.valueOf(targetClan.getMembers().size()))
                .replace("{bank_balance}", TextUtil.formatCurrency(targetClan.getBank().getBalance()).replace("$", ""))
                .replace("{clan_balance}", TextUtil.formatCurrency(targetClan.getBank().getBalance()).replace("$", ""))
                .replace("{wars_won}", String.valueOf(targetClan.getWarsWon()))
                .replace("{wars_lost}", String.valueOf(targetClan.getWarsLost()))
                .replace("{allies_count}", String.valueOf(targetClan.getAllies().size()))
                .replace("{rivals_count}", String.valueOf(targetClan.getRivals().size()))
                .replace("{created_date}", targetClan.getCreatedDate() != null ? targetClan.getCreatedDate() : "N/A")
                .replace("{pvp_status}", targetClan.isFriendlyFire() ? "<green>Enabled" : "<red>Disabled")
                .replace("{war_participation_status}", targetClan.isWarParticipation() ? "<green>Enabled" : "<red>Disabled");

        // Leader name
        Optional<ClanMember> leader = targetClan.getLeader();
        text = text.replace("{leader_name}", leader.map(ClanMember::getName).orElse("None"));

        return text;
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        return switch (action.toUpperCase()) {
            // ── Power ──
            case "ADMIN_ADD_POWER" -> {
                if (event.getClick() == ClickType.SHIFT_RIGHT) {
                    promptValue("power");
                } else {
                    int amount = event.isShiftClick() ? 1000 : 100;
                    plugin.getPowerManager().adminAddPower(targetClan, amount);
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.power-set",
                            "value", String.valueOf(targetClan.getPower())));
                    refreshGui();
                }
                yield true;
            }
            case "ADMIN_REMOVE_POWER" -> {
                if (event.getClick() == ClickType.SHIFT_RIGHT) {
                    promptValue("power");
                } else {
                    int amount = event.isShiftClick() ? 1000 : 100;
                    plugin.getPowerManager().adminRemovePower(targetClan, amount);
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.power-set",
                            "value", String.valueOf(targetClan.getPower())));
                    refreshGui();
                }
                yield true;
            }

            // ── Level ──
            case "ADMIN_LEVEL_UP" -> {
                if (event.getClick() == ClickType.SHIFT_RIGHT) {
                    promptValue("level");
                } else {
                    int newLevel = Math.min(targetClan.getLevel() + 1, plugin.getLevelManager().getMaxLevel());
                    plugin.getLevelManager().setLevel(targetClan, newLevel);
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.level-set",
                            "level", String.valueOf(newLevel)));
                    refreshGui();
                }
                yield true;
            }
            case "ADMIN_LEVEL_DOWN" -> {
                if (event.getClick() == ClickType.SHIFT_RIGHT) {
                    promptValue("level");
                } else {
                    int newLevel = Math.max(targetClan.getLevel() - 1, 1);
                    plugin.getLevelManager().setLevel(targetClan, newLevel);
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.level-set",
                            "level", String.valueOf(newLevel)));
                    refreshGui();
                }
                yield true;
            }

            // ── Bank ──
            case "ADMIN_ADD_BANK" -> {
                if (event.getClick() == ClickType.SHIFT_RIGHT) {
                    promptValue("bank");
                } else {
                    double amount = event.isShiftClick() ? 100000 : 10000;
                    targetClan.getBank().setBalance(targetClan.getBank().getBalance() + amount);
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.balance-set",
                            "amount", TextUtil.formatCurrency(targetClan.getBank().getBalance())));
                    refreshGui();
                }
                yield true;
            }
            case "ADMIN_REMOVE_BANK" -> {
                if (event.getClick() == ClickType.SHIFT_RIGHT) {
                    promptValue("bank");
                } else {
                    double amount = event.isShiftClick() ? 100000 : 10000;
                    double newBalance = Math.max(0, targetClan.getBank().getBalance() - amount);
                    targetClan.getBank().setBalance(newBalance);
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.balance-set",
                            "amount", TextUtil.formatCurrency(newBalance)));
                    refreshGui();
                }
                yield true;
            }

            // ── Name / Tag ──
            case "ADMIN_CHANGE_NAME" -> {
                player.closeInventory();
                player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.enter-name"));
                plugin.getGuiManager().registerAnvilInput(player, input -> {
                    // Validate name
                    int minName = plugin.getConfigManager().getInt("clan.name.min-length", 3);
                    int maxName = plugin.getConfigManager().getInt("clan.name.max-length", 16);
                    if (input.length() < minName || input.length() > maxName) {
                        player.sendMessage(plugin.getConfigManager().getMessage("clan.create-name-length",
                                "min", String.valueOf(minName), "max", String.valueOf(maxName)));
                        return;
                    }
                    String nameRegex = plugin.getConfigManager().getString("clan.name.regex", "^[a-zA-Z0-9_ ]+$");
                    if (!input.matches(nameRegex)) {
                        player.sendMessage(plugin.getConfigManager().getMessage("clan.create-name-invalid"));
                        return;
                    }
                    if (plugin.getClanManager().clanNameExists(input) && !input.equalsIgnoreCase(targetClan.getName())) {
                        player.sendMessage(plugin.getConfigManager().getMessage("clan.create-name-taken", "name", input));
                        return;
                    }
                    // Update index maps to keep lookups consistent
                    plugin.getClanManager().updateNameIndex(targetClan.getName(), input, targetClan.getId());
                    targetClan.setName(input);
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.name-changed",
                            "name", input));
                    if (plugin.getNametagManager() != null) {
                        plugin.getNametagManager().updateClanMembers(targetClan);
                    }
                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        AdminClanGui gui = new AdminClanGui(plugin, player, targetClan);
                        gui.open();
                    });
                });
                yield true;
            }
            case "ADMIN_CHANGE_TAG" -> {
                player.closeInventory();
                player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.enter-tag"));
                plugin.getGuiManager().registerAnvilInput(player, input -> {
                    if (input.length() > 5) {
                        player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.tag-too-long"));
                    } else {
                        // Update index maps to keep lookups consistent
                        plugin.getClanManager().updateTagIndex(targetClan.getTag(), input, targetClan.getId());
                        targetClan.setTag(input);
                        player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.tag-changed",
                                "tag", input));
                        if (plugin.getNametagManager() != null) {
                            plugin.getNametagManager().updateClanMembers(targetClan);
                        }
                    }
                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        AdminClanGui gui = new AdminClanGui(plugin, player, targetClan);
                        gui.open();
                    });
                });
                yield true;
            }

            // ── Transfer Leadership ──
            case "ADMIN_TRANSFER_LEADER" -> {
                player.closeInventory();
                player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.enter-leader"));
                plugin.getGuiManager().registerAnvilInput(player, input -> {
                    ClanMember member = targetClan.getMemberByName(input);
                    if (member == null) {
                        player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.member-not-found",
                                "name", input));
                    } else {
                        Optional<ClanMember> currentLeader = targetClan.getLeader();
                        if (currentLeader.isPresent()) {
                            plugin.getClanManager().transferLeadership(
                                    targetClan, currentLeader.get().getUuid(), member.getUuid());
                            player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.leader-changed",
                                    "name", member.getName()));
                        }
                    }
                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        AdminClanGui gui = new AdminClanGui(plugin, player, targetClan);
                        gui.open();
                    });
                });
                yield true;
            }

            // ── View Members ──
            case "ADMIN_VIEW_MEMBERS" -> {
                StringBuilder sb = new StringBuilder();
                sb.append("<gold><bold>═══ Members of ").append(targetClan.getName()).append(" ═══</bold></gold>\n");
                for (ClanMember m : targetClan.getMembers()) {
                    String status = m.isOnline() ? "<green>●</green>" : "<red>●</red>";
                    sb.append(status).append(" <white>").append(m.getName())
                            .append(" <gray>[").append(m.getRole().name()).append("]")
                            .append(" K:").append(m.getKills())
                            .append(" D:").append(m.getDeaths())
                            .append(" P:").append(m.getPowerContributed())
                            .append("</gray>\n");
                }
                player.sendMessage(TextUtil.parse(sb.toString().trim()));
                yield true;
            }

            // ── Add Member ──
            case "ADMIN_ADD_MEMBER" -> {
                player.closeInventory();
                player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.enter-player-add"));
                plugin.getGuiManager().registerAnvilInput(player, input -> {
                    Player target = Bukkit.getPlayer(input);
                    if (target == null) {
                        player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.player-not-found",
                                "input", input));
                    } else if (plugin.getClanManager().isInClan(target.getUniqueId())) {
                        player.sendMessage(plugin.getConfigManager().getMessage("error.already-in-clan"));
                    } else {
                        plugin.getClanManager().addMember(targetClan, target);
                        player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.player-added",
                                "player", target.getName(), "clan", targetClan.getName()));
                    }
                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        AdminClanGui gui = new AdminClanGui(plugin, player, targetClan);
                        gui.open();
                    });
                });
                yield true;
            }

            // ── Kick Member ──
            case "ADMIN_KICK_MEMBER" -> {
                player.closeInventory();
                player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.enter-player-kick"));
                plugin.getGuiManager().registerAnvilInput(player, input -> {
                    ClanMember member = targetClan.getMemberByName(input);
                    if (member == null) {
                        player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.member-not-found",
                                "name", input));
                    } else {
                        plugin.getClanManager().removeMember(targetClan, member.getUuid(), true);
                        player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.player-kicked",
                                "player", member.getName(), "clan", targetClan.getName()));
                    }
                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        AdminClanGui gui = new AdminClanGui(plugin, player, targetClan);
                        gui.open();
                    });
                });
                yield true;
            }

            // ── Toggles ──
            case "ADMIN_TOGGLE_PVP" -> {
                targetClan.setFriendlyFire(!targetClan.isFriendlyFire());
                player.sendMessage(plugin.getConfigManager().getMessage(
                        targetClan.isFriendlyFire() ? "settings.pvp-enabled" : "settings.pvp-disabled"));
                refreshGui();
                yield true;
            }
            case "ADMIN_TOGGLE_WAR" -> {
                targetClan.setWarParticipation(!targetClan.isWarParticipation());
                player.sendMessage(plugin.getConfigManager().getMessage(
                        targetClan.isWarParticipation() ? "settings.war-enabled" : "settings.war-disabled"));
                refreshGui();
                yield true;
            }

            // ── End Wars ──
            case "ADMIN_END_CLAN_WARS" -> {
                if (plugin.getWarManager() != null) {
                    plugin.getWarManager().forceEndAllWars(targetClan);
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.war-resolved"));
                }
                yield true;
            }

            // ── Reset Stats ──
            case "ADMIN_RESET_STATS" -> {
                if (!event.isShiftClick()) {
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.disband-confirm"));
                    yield true;
                }
                targetClan.setTotalKills(0);
                targetClan.setTotalDeaths(0);
                targetClan.setWarsWon(0);
                targetClan.setWarsLost(0);
                player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.status"));
                refreshGui();
                yield true;
            }

            // ── Disband ──
            case "ADMIN_DISBAND" -> {
                if (!event.isShiftClick()) {
                    player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.disband-confirm"));
                    yield true;
                }
                String name = targetClan.getName();
                plugin.getClanManager().adminDisband(targetClan);
                player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.disband-success",
                        "clan", name));
                plugin.getGuiManager().openGui(player, "admin-clan-list");
                yield true;
            }

            // ── Save Clan ──
            case "ADMIN_SAVE_CLAN" -> {
                Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
                    plugin.getStorageManager().saveClan(targetClan);
                    Bukkit.getScheduler().runTask(plugin, () -> {
                        player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.save-complete"));
                        SoundUtil.success(player);
                    });
                });
                yield true;
            }

            default -> false;
        };
    }

    private void promptValue(String type) {
        player.closeInventory();
        player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.enter-number"));

        plugin.getGuiManager().registerAnvilInput(player, input -> {
            try {
                double value = Double.parseDouble(input.replace(",", "").replace("$", ""));
                switch (type) {
                    case "power" -> {
                        plugin.getPowerManager().setPower(targetClan, (int) value);
                        player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.power-set",
                                "value", String.valueOf((int) value)));
                    }
                    case "level" -> {
                        int lvl = Math.max(1, Math.min((int) value, plugin.getLevelManager().getMaxLevel()));
                        plugin.getLevelManager().setLevel(targetClan, lvl);
                        player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.level-set",
                                "level", String.valueOf(lvl)));
                    }
                    case "bank" -> {
                        targetClan.getBank().setBalance(Math.max(0, value));
                        player.sendMessage(plugin.getConfigManager().getMessage("admin-gui.balance-set",
                                "amount", TextUtil.formatCurrency(value)));
                    }
                }
            } catch (NumberFormatException e) {
                player.sendMessage(plugin.getConfigManager().getMessage("error.invalid-number"));
            }
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                AdminClanGui gui = new AdminClanGui(plugin, player, targetClan);
                gui.open();
            });
        });
    }

    private void refreshGui() {
        occupiedSlots.clear();
        slotActions.clear();
        rightClickActions.clear();
        slotConfigs.clear();
        fillBackground();
        placeConfigItems();
        populateItems();
    }
}
