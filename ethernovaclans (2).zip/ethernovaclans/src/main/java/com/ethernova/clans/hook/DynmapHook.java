package com.ethernova.clans.hook;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.lang.reflect.Method;
import java.util.*;
import java.util.logging.Level;

/**
 * Dynmap / BlueMap integration hook.
 * Renders clan territories on the web map with colors.
 * Auto-detects Dynmap or BlueMap via reflection to avoid compile-time deps.
 */
public class DynmapHook {

    private final EthernovaClans plugin;
    private Object dynmapApi;   // org.dynmap.DynmapAPI
    private Object markerApi;   // org.dynmap.markers.MarkerAPI
    private Object markerSet;   // org.dynmap.markers.MarkerSet
    private Object blueMapApi;  // de.blueez.blueMap.api.BlueMapAPI
    private boolean useDynmap = false;
    private boolean useBlueMap = false;
    private BukkitTask updateTask;
    private static final String MARKER_SET_ID = "ethernova_clans";
    private static final String MARKER_SET_LABEL = "EthernovaClans Territories";

    public DynmapHook(EthernovaClans plugin) {
        this.plugin = plugin;
    }

    /**
     * Attempt to hook into Dynmap or BlueMap.
     * @return true if successfully hooked
     */
    public boolean tryHook() {
        // Try Dynmap first
        if (Bukkit.getPluginManager().getPlugin("dynmap") != null) {
            try {
                Object dynPlugin = Bukkit.getPluginManager().getPlugin("dynmap");
                // Get API via reflection: ((DynmapPlugin) plugin).getAPI()
                // or via DynmapAPI interface
                Class<?> apiClass = Class.forName("org.dynmap.DynmapAPI");
                if (apiClass.isInstance(dynPlugin)) {
                    dynmapApi = dynPlugin;
                    Method getMarkerAPI = apiClass.getMethod("getMarkerAPI");
                    markerApi = getMarkerAPI.invoke(dynmapApi);
                    if (markerApi != null) {
                        // Get or create marker set
                        Method getMarkerSet = markerApi.getClass().getMethod("getMarkerSet", String.class);
                        markerSet = getMarkerSet.invoke(markerApi, MARKER_SET_ID);
                        if (markerSet == null) {
                            Method createMarkerSet = markerApi.getClass().getMethod("createMarkerSet",
                                    String.class, String.class, java.util.Set.class, boolean.class);
                            markerSet = createMarkerSet.invoke(markerApi, MARKER_SET_ID, MARKER_SET_LABEL, null, false);
                        }
                        useDynmap = true;
                        plugin.getLogger().info("✔ Dynmap hook activated - territories will appear on web map");
                    }
                }
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Could not hook into Dynmap", e);
            }
        }

        // Try BlueMap
        if (!useDynmap && Bukkit.getPluginManager().getPlugin("BlueMap") != null) {
            try {
                Class<?> blueMapClass = Class.forName("de.blueez.bluemap.api.BlueMapAPI");
                Method getInstance = blueMapClass.getMethod("getInstance");
                Object optionalApi = getInstance.invoke(null);
                // Optional<BlueMapAPI>.isPresent()
                Method isPresent = optionalApi.getClass().getMethod("isPresent");
                if ((boolean) isPresent.invoke(optionalApi)) {
                    Method get = optionalApi.getClass().getMethod("get");
                    blueMapApi = get.invoke(optionalApi);
                    useBlueMap = true;
                    plugin.getLogger().info("✔ BlueMap hook activated - territories will appear on web map");
                }
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Could not hook into BlueMap", e);
            }
        }

        if (!useDynmap && !useBlueMap) {
            plugin.getLogger().info("○ No web map plugin found (Dynmap/BlueMap) - map integration disabled");
            return false;
        }

        // Start periodic update task (every 5 minutes)
        startUpdateTask();
        return true;
    }

    /**
     * Start periodic territory update on web map.
     */
    private void startUpdateTask() {
        updateTask = plugin.getServer().getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            try {
                updateAllTerritories();
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Error updating map territories", e);
            }
        }, 100L, 6000L); // 5 seconds delay, then every 5 minutes
    }

    /**
     * Update all clan territories on the web map.
     */
    public void updateAllTerritories() {
        if (useDynmap) {
            updateDynmapTerritories();
        }
        // BlueMap integration would go here
    }

    private void updateDynmapTerritories() {
        if (markerSet == null) return;

        try {
            // Clear existing markers
            Method getAreaMarkers = markerSet.getClass().getMethod("getAreaMarkers");
            @SuppressWarnings("unchecked")
            Set<Object> existing = (Set<Object>) getAreaMarkers.invoke(markerSet);
            if (existing != null) {
                for (Object marker : new ArrayList<>(existing)) {
                    Method deleteMarker = marker.getClass().getMethod("deleteMarker");
                    deleteMarker.invoke(marker);
                }
            }

            // Create new markers for each clan
            for (Clan clan : plugin.getClanManager().getAllClans()) {
                Set<String> chunks = plugin.getTerritoryManager().getClanClaims(clan.getId());
                if (chunks.isEmpty()) continue;

                int colorInt = getClanColor(clan);

                // Group chunks by world
                Map<String, List<int[]>> worldChunks = new HashMap<>();
                for (String chunkKey : chunks) {
                    String[] parts = chunkKey.split(",");
                    if (parts.length < 3) continue;
                    String worldName = parts[0];
                    int cx = Integer.parseInt(parts[1]);
                    int cz = Integer.parseInt(parts[2]);
                    worldChunks.computeIfAbsent(worldName, k -> new ArrayList<>()).add(new int[]{cx, cz});
                }

                // Create area marker for each chunk
                int markerIdx = 0;
                for (Map.Entry<String, List<int[]>> entry : worldChunks.entrySet()) {
                    String worldName = entry.getKey();
                    for (int[] chunkPos : entry.getValue()) {
                        String markerId = "clan_" + clan.getId() + "_" + (markerIdx++);

                        // Each chunk is 16x16 blocks
                        double[] xCoords = {chunkPos[0] * 16.0, chunkPos[0] * 16.0 + 16.0,
                                            chunkPos[0] * 16.0 + 16.0, chunkPos[0] * 16.0};
                        double[] zCoords = {chunkPos[1] * 16.0, chunkPos[1] * 16.0,
                                            chunkPos[1] * 16.0 + 16.0, chunkPos[1] * 16.0 + 16.0};

                        try {
                            // Create area marker via reflection
                            Method createAreaMarker = markerSet.getClass().getMethod("createAreaMarker",
                                    String.class, String.class, boolean.class, String.class,
                                    double[].class, double[].class, boolean.class);
                            Object areaMarker = createAreaMarker.invoke(markerSet,
                                    markerId, clan.getName() + " [" + clan.getTag() + "]",
                                    false, worldName, xCoords, zCoords, false);

                            if (areaMarker != null) {
                                // Set colors
                                Method setFillStyle = areaMarker.getClass().getMethod("setFillStyle", double.class, int.class);
                                Method setLineStyle = areaMarker.getClass().getMethod("setLineStyle", int.class, double.class, int.class);
                                setFillStyle.invoke(areaMarker, 0.35, colorInt);
                                setLineStyle.invoke(areaMarker, 2, 0.8, colorInt);

                                // Set description (popup HTML)
                                Method setDescription = areaMarker.getClass().getMethod("setDescription", String.class);
                                String desc = "<div><b>" + clan.getName() + "</b><br>"
                                        + "Tag: [" + clan.getTag() + "]<br>"
                                        + "Nivel: " + clan.getLevel() + "<br>"
                                        + "Miembros: " + clan.getMembers().size() + "<br>"
                                        + "</div>";
                                setDescription.invoke(areaMarker, desc);
                            }
                        } catch (Exception e) {
                            // Silently skip individual marker failures
                        }
                    }
                }
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Failed to update Dynmap markers", e);
        }
    }

    /**
     * Get a color integer for a clan (based on tag hash for consistency).
     */
    private int getClanColor(Clan clan) {
        // Use clan tag hash to generate a consistent color
        int hash = clan.getTag().hashCode();
        int r = (hash & 0xFF0000) >> 16;
        int g = (hash & 0x00FF00) >> 8;
        int b = hash & 0x0000FF;
        // Ensure minimum brightness
        r = Math.max(60, r);
        g = Math.max(60, g);
        b = Math.max(60, b);
        return (r << 16) | (g << 8) | b;
    }

    /**
     * Called when a territory is claimed/unclaimed to trigger immediate update.
     */
    public void onTerritoryChange(Clan clan) {
        if (!useDynmap && !useBlueMap) return;
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, this::updateAllTerritories);
    }

    /**
     * Shutdown the hook and clean up tasks.
     */
    public void shutdown() {
        if (updateTask != null) {
            updateTask.cancel();
            updateTask = null;
        }
    }

    public boolean isHooked() {
        return useDynmap || useBlueMap;
    }

    public String getHookedPlugin() {
        if (useDynmap) return "Dynmap";
        if (useBlueMap) return "BlueMap";
        return "None";
    }
}
