package com.ethernova.clans.gui.menus;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import com.ethernova.clans.gui.AbstractGui;
import com.ethernova.clans.util.SoundUtil;
import com.ethernova.clans.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

/**
 * Main clan menu GUI showing clan overview and navigation to sub-menus.
 * Items are loaded from main-menu.yml config; this class handles special actions.
 */
public class ClanMainGui extends AbstractGui {

    public ClanMainGui(EthernovaClans plugin, Player player) {
        super(plugin, player, "main-menu");
    }

    @Override
    protected void populateItems() {
        // All items are placed by placeConfigItems() from YAML.
        // Dynamic content uses placeholders replaced in AbstractGui.
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        Clan clan = plugin.getClanManager().getClanByPlayer(player);

        return switch (action.toUpperCase()) {
            case "TOGGLE_CHAT" -> {
                plugin.getChatManager().toggleClanChat(player.getUniqueId());
                SoundUtil.success(player);
                plugin.getServer().getScheduler().runTask(plugin, this::refreshGui);
                yield true;
            }
            case "TOGGLE_FLY" -> {
                if (plugin.getFlyManager() != null) {
                    plugin.getFlyManager().toggleFly(player);
                    SoundUtil.success(player);
                }
                yield true;
            }
            case "INVITE_PLAYERS" -> {
                if (clan == null) {
                    yield true;
                }
                if (!plugin.getClanManager().hasPermission(clan, player.getUniqueId(), "invite")) {
                    player.sendMessage(plugin.getConfigManager().getMessage("general.no-permission"));
                    SoundUtil.error(player);
                    yield true;
                }
                plugin.getServer().getScheduler().runTask(plugin, () ->
                        new InvitePlayersGui(plugin, player).open());
                yield true;
            }
            case "HOME_TP" -> {
                if (clan == null) yield true;
                player.closeInventory();
                if (plugin.getTeleportManager() != null) {
                    plugin.getTeleportManager().teleportHome(player, clan);
                }
                yield true;
            }
            case "SET_HOME" -> {
                if (clan == null) yield true;
                if (!plugin.getClanManager().hasPermission(clan, player.getUniqueId(), "sethq")) {
                    player.sendMessage(plugin.getConfigManager().getMessage("general.no-permission"));
                    SoundUtil.error(player);
                    yield true;
                }
                player.closeInventory();
                if (plugin.getTeleportManager() != null) {
                    plugin.getTeleportManager().setHome(player, clan);
                }
                yield true;
            }
            case "DELETE_HOME" -> {
                if (clan == null) yield true;
                if (!plugin.getClanManager().hasPermission(clan, player.getUniqueId(), "sethq")) {
                    player.sendMessage(plugin.getConfigManager().getMessage("general.no-permission"));
                    SoundUtil.error(player);
                    yield true;
                }
                if (clan.getHomeLocation() == null) {
                    plugin.getMessageManager().sendMessage(player, "gui.home-not-set");
                    SoundUtil.error(player);
                } else {
                    clan.setHomeLocation(null);
                    plugin.getMessageManager().sendMessage(player, "gui.home-deleted");
                    SoundUtil.success(player);
                    // Save async
                    Bukkit.getScheduler().runTaskAsynchronously(plugin, () ->
                            plugin.getStorageManager().saveClan(clan));
                }
                plugin.getServer().getScheduler().runTask(plugin, this::refreshGui);
                yield true;
            }
            case "UNCLAIM_ALL" -> {
                if (clan == null) yield true;
                if (!plugin.getClanManager().hasPermission(clan, player.getUniqueId(), "claim")) {
                    player.sendMessage(plugin.getConfigManager().getMessage("general.no-permission"));
                    SoundUtil.error(player);
                    yield true;
                }
                if (plugin.getTerritoryManager().getClaimCount(clan.getId()) == 0) {
                    plugin.getMessageManager().sendMessage(player, "gui.no-territories");
                    SoundUtil.error(player);
                } else {
                    int count = plugin.getClanManager().unclaimAllChunks(clan);
                    plugin.getMessageManager().sendMessage(player, "gui.territories-unclaimed", "{count}", String.valueOf(count));
                    SoundUtil.success(player);
                }
                plugin.getServer().getScheduler().runTask(plugin, this::refreshGui);
                yield true;
            }
            case "SHOW_INFO" -> {
                player.closeInventory();
                if (clan != null) {
                    player.performCommand("clan info");
                }
                yield true;
            }
            case "TOGGLE_OFFICER_CHAT" -> {
                if (clan == null) yield true;
                var member = clan.getMember(player.getUniqueId());
                if (member == null || !member.getRole().isAtLeast(com.ethernova.clans.clan.ClanRole.OFFICER)) {
                    plugin.getMessageManager().sendMessage(player, "chat.officer-no-permission");
                    SoundUtil.error(player);
                    yield true;
                }
                plugin.getChatManager().toggleOfficerChat(player.getUniqueId());
                boolean on = plugin.getChatManager().isInOfficerChat(player.getUniqueId());
                plugin.getMessageManager().sendMessage(player, on ? "chat.officer-on" : "chat.officer-off");
                SoundUtil.success(player);
                plugin.getServer().getScheduler().runTask(plugin, this::refreshGui);
                yield true;
            }
            default -> false;
        };
    }

    private void refreshGui() {
        occupiedSlots.clear();
        slotActions.clear();
        rightClickActions.clear();
        slotConfigs.clear();
        fillBackground();
        placeConfigItems();
        populateItems();
    }
}
