package com.ethernova.clans.listener;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.achievement.AchievementManager;
import com.ethernova.clans.achievement.AchievementManager.AchievementType;
import com.ethernova.clans.event.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

/**
 * Listens to clan events and triggers achievement checks.
 * Reacts to kills, claims, level changes, wars, alliances, upgrades, and missions.
 */
public class AchievementListener implements Listener {

    private final EthernovaClans plugin;

    public AchievementListener(EthernovaClans plugin) {
        this.plugin = plugin;
    }

    private AchievementManager am() {
        return plugin.getAchievementManager();
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onClanCreate(ClanCreateEvent event) {
        // Check all achievements when a clan is first created
        am().checkAchievements(event.getClan());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMemberJoin(ClanMemberJoinEvent event) {
        am().checkAchievements(event.getClan(), AchievementType.MEMBERS);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPowerChange(ClanPowerChangeEvent event) {
        am().checkAchievements(event.getClan(), AchievementType.POWER);
        am().checkAchievements(event.getClan(), AchievementType.KILLS);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onLevelUp(ClanLevelUpEvent event) {
        am().checkAchievements(event.getClan(), AchievementType.LEVEL);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onClaim(ClanClaimEvent event) {
        am().checkAchievements(event.getClan(), AchievementType.CLAIMS);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onWarEnd(ClanWarEndEvent event) {
        if (event.getWinner() != null) {
            am().checkAchievements(event.getWinner(), AchievementType.WARS_WON);
            am().checkAchievements(event.getWinner(), AchievementType.WARS_FOUGHT);
        }
        if (event.getLoser() != null) {
            am().checkAchievements(event.getLoser(), AchievementType.WARS_FOUGHT);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onAlly(ClanAllyEvent event) {
        am().checkAchievements(event.getClan(), AchievementType.ALLIES);
        am().checkAchievements(event.getAllyClan(), AchievementType.ALLIES);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBank(ClanBankEvent event) {
        am().checkAchievements(event.getClan(), AchievementType.BANK_BALANCE);
        am().checkAchievements(event.getClan(), AchievementType.DEPOSITS);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onUpgrade(ClanUpgradeEvent event) {
        am().trackUpgradePurchase(event.getClan());
    }
}
