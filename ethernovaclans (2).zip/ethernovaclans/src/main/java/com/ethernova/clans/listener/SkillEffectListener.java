package com.ethernova.clans.listener;

import com.ethernova.clans.EthernovaClans;
import com.ethernova.clans.clan.Clan;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 * Applies passive skill effects for clans.
 * <ul>
 *   <li><b>fortification</b> – reduce incoming damage in own territory</li>
 *   <li><b>sharpness</b> – increase outgoing damage during wars</li>
 *   <li><b>vitality</b> – passive REGENERATION in own territory</li>
 *   <li><b>haste</b> – FAST_DIGGING in own territory</li>
 *   <li><b>swiftness</b> – SPEED in own territory</li>
 * </ul>
 *
 * <b>expansion</b> and <b>recruitment</b> are checked inline when calculating
 * max claims / max members.
 * <b>treasury</b> is applied in SalaryManager deposit interest.
 */
public class SkillEffectListener implements Listener {

    private final EthernovaClans plugin;

    /** Duration ticks for territory potion effects (refreshed every chunk cross) */
    private static final int POTION_TICKS = 200; // 10 seconds

    public SkillEffectListener(EthernovaClans plugin) {
        this.plugin = plugin;
    }

    // ── Combat skills ────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (plugin.getSkillManager() == null) return;

        // --- Fortification: reduce damage when victim is in own territory ---
        if (event.getEntity() instanceof Player victim) {
            Clan victimClan = plugin.getClanManager().getClanByPlayer(victim);
            if (victimClan != null) {
                String chunkKey = chunkKey(victim.getLocation());
                Clan owner = plugin.getClanManager().getClaimOwner(chunkKey);
                if (owner != null && owner.getId().equals(victimClan.getId())) {
                    double reduction = plugin.getSkillManager().getSkillValue(victimClan.getId(), "fortification");
                    if (reduction > 0) {
                        double newDamage = event.getDamage() * (1.0 - reduction / 100.0);
                        event.setDamage(Math.max(0, newDamage));
                    }
                }
            }
        }

        // --- Sharpness: increase damage when attacker is at war with target ---
        Player attacker = resolveAttacker(event);
        if (attacker != null && event.getEntity() instanceof Player target) {
            Clan attackerClan = plugin.getClanManager().getClanByPlayer(attacker);
            Clan targetClan = plugin.getClanManager().getClanByPlayer(target);
            if (attackerClan != null && targetClan != null) {
                if (plugin.getWarManager() != null && plugin.getWarManager().isAtWar(attackerClan, targetClan)) {
                    double bonus = plugin.getSkillManager().getSkillValue(attackerClan.getId(), "sharpness");
                    if (bonus > 0) {
                        double newDamage = event.getDamage() * (1.0 + bonus / 100.0);
                        event.setDamage(newDamage);
                    }
                }
            }
        }
    }

    // ── Territory potion effects ─────────────────────────────

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (plugin.getSkillManager() == null) return;

        Location from = event.getFrom();
        Location to = event.getTo();
        if (to == null) return;

        // Only trigger on chunk change
        if (from.getBlockX() >> 4 == to.getBlockX() >> 4
                && from.getBlockZ() >> 4 == to.getBlockZ() >> 4) {
            return;
        }

        Player player = event.getPlayer();
        Clan clan = plugin.getClanManager().getClanByPlayer(player);
        if (clan == null) return;

        String newChunkKey = chunkKey(to);
        Clan owner = plugin.getClanManager().getClaimOwner(newChunkKey);

        boolean inOwnTerritory = owner != null && owner.getId().equals(clan.getId());

        if (inOwnTerritory) {
            applyTerritoryEffects(player, clan.getId());
        }
        // Effects expire naturally after POTION_TICKS when leaving territory
    }

    private void applyTerritoryEffects(Player player, String clanId) {
        // Vitality → Regeneration
        double vitality = plugin.getSkillManager().getSkillValue(clanId, "vitality");
        if (vitality > 0) {
            int amplifier = Math.max(0, (int) vitality - 1); // level 1=0amp, 2=1amp, 3=2amp
            player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, POTION_TICKS, amplifier, true, false, true));
        }

        // Haste → Fast Digging
        double haste = plugin.getSkillManager().getSkillValue(clanId, "haste");
        if (haste > 0) {
            int amplifier = haste >= 30 ? 2 : (haste >= 20 ? 1 : 0);
            player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, POTION_TICKS, amplifier, true, false, true));
        }

        // Swiftness → Speed
        double swiftness = plugin.getSkillManager().getSkillValue(clanId, "swiftness");
        if (swiftness > 0) {
            int amplifier = swiftness >= 15 ? 2 : (swiftness >= 10 ? 1 : 0);
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, POTION_TICKS, amplifier, true, false, true));
        }
    }

    // ── Helpers ──────────────────────────────────────────────

    private Player resolveAttacker(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player p) return p;
        if (event.getDamager() instanceof org.bukkit.entity.Projectile proj
                && proj.getShooter() instanceof Player p) return p;
        return null;
    }

    private String chunkKey(Location loc) {
        Chunk chunk = loc.getChunk();
        return loc.getWorld().getName() + ":" + chunk.getX() + ":" + chunk.getZ();
    }
}
