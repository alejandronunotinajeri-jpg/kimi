# EthernovaClans — Gap Analysis Report

> **Date:** 2025  
> **Scope:** `src/` module (main plugin), cross-referencing `progression/`, `ranked/`, `cosmetics/`  
> **Goal:** Identify every specific gap preventing a 10/10 rating  

---

## 1. MISSING_MESSAGES — Keys in EN absent from ES

**15 message keys exist in `messages_en.yml` but are completely absent from `messages_es.yml`.**

### 1.1 — `clan` section help keys (10 keys)

| # | Key | EN Location |
|---|-----|-------------|
| 1 | `clan.help-settings` | `messages_en.yml` L225 |
| 2 | `clan.help-siege` | `messages_en.yml` L229 |
| 3 | `clan.help-diplomacy` | `messages_en.yml` L230 |
| 4 | `clan.help-salary` | `messages_en.yml` L231 |
| 5 | `clan.help-skills` | `messages_en.yml` L232 |
| 6 | `clan.help-shop` | `messages_en.yml` L233 |
| 7 | `clan.help-stats` | `messages_en.yml` L234 |
| 8 | `clan.help-banner` | `messages_en.yml` L235 |
| 9 | `clan.help-season` | `messages_en.yml` L236 |
| 10 | `clan.help-borders` | `messages_en.yml` L237 |

### 1.2 — `banner` section keys (5 keys)

| # | Key | EN Location |
|---|-----|-------------|
| 11 | `banner.help-header` | `messages_en.yml` L1147 |
| 12 | `banner.help-info` | `messages_en.yml` L1148 |
| 13 | `banner.help-set` | `messages_en.yml` L1149 |
| 14 | `banner.help-get` | `messages_en.yml` L1150 |
| 15 | `banner.usage` | `messages_en.yml` L1151 |

> **Impact:** Spanish players will see raw keys or English fallback for these 15 entries. The file size difference (EN=1183 lines, ES=1164 lines) is almost entirely explained by these missing keys plus minor formatting.

---

## 2. HARDCODED_STRINGS — Text not routed through MessageManager

### 2.1 — `ClanCommandExecutor.java` (6 locations)

| # | ~Line | Method | Content |
|---|-------|--------|---------|
| 1 | ~193 | `handleDisband()` | Hardcoded **Spanish** confirmation dialog: `"<red><bold>⚠ ¿Estás seguro de disolver " + clanName + "?</bold></red>\n<gray>Se perderán todos los territorios, alianzas, banco y mejoras.</gray>"` |
| 2 | ~241–260 | `handleInvite()` | Hardcoded MiniMessage invite notification sent to target player (multi-line hover/click component built in code, not from messages file) |
| 3 | ~335 | `handleLeave()` | Hardcoded **Spanish** confirmation: `"<yellow>⚠ ¿Seguro que quieres salir de..."` |
| 4 | ~1475–1480 | `showNationHelp()` | All help descriptions hardcoded in **Spanish**: `"Crear nación"`, `"Info de nación"`, `"Invitar clan"`, `"Aceptar invitación"`, etc. (~13 lines) |
| 5 | ~1594–1600 | `showOutpostHelp()` | All help descriptions hardcoded in **Spanish**: `"Colocar avanzada"`, `"Remover"`, `"Mejorar"`, `"Listar"`, `"Info"` |
| 6 | ~1687–1692 | `showSpyHelp()` | All help descriptions hardcoded in **Spanish**: `"Activar social spy"`, `"Infiltrar clan"`, `"Detener infiltración"`, `"Informe de intel"` |

### 2.2 — `SeasonManager.java` (1 location)

| # | ~Line | Method | Content |
|---|-------|--------|---------|
| 7 | ~155–190 | `broadcastSeasonEnd()` | Entire season-end broadcast built with hardcoded **Spanish** MiniMessage strings: `"<gold><bold>═══════ Temporada "`, `"<yellow>🏆 Primer lugar"`, rankings loop, separator, etc. Should use `season.ended` / `season.reward` / `season.new-season` keys from messages file |

### 2.3 — `ClanSkillManager.java` (8 descriptions)

| # | ~Line | Content |
|---|-------|---------|
| 8 | ~40–80 | All 8 skill descriptions hardcoded in **Spanish**: `"Fortificación"` → "Aumenta la resistencia de los territorios", `"Filo"` → "Aumenta el daño de los miembros", `"Tesoro"` → "Aumenta la capacidad del banco", `"Expansión"` → etc., `"Reclutamiento"`, `"Vitalidad"`, `"Celeridad"`, `"Agilidad"`. These should be configurable message keys or config entries. |

> **Impact:** Any server running in English will see Spanish text in disband/leave confirmations, nation/outpost/spy help menus, season broadcasts, and all skill names/descriptions.

---

## 3. MISSING_PLACEHOLDERS — PlaceholderAPI expansion gaps

**File:** `ClanPlaceholderExpansion.java` (~100 lines)

Current coverage: ~30 placeholders. Missing despite backing data existing in managers:

### 3.1 — Season placeholders (SeasonManager has the data)

| # | Placeholder | Data Source |
|---|------------|-------------|
| 1 | `ethernova_clans_season_number` | `SeasonManager.getCurrentSeason()` |
| 2 | `ethernova_clans_season_rank` | `SeasonManager.getRankings()` |
| 3 | `ethernova_clans_season_time_remaining` | `SeasonManager.getTimeRemainingMs()` |

### 3.2 — Skill placeholders (ClanSkillManager has the data)

| # | Placeholder | Data Source |
|---|------------|-------------|
| 4 | `ethernova_clans_skill_level_<id>` | `ClanSkillManager.getSkillLevel(clan, id)` |
| 5 | `ethernova_clans_skill_points` | `ClanSkillManager.getAvailablePoints(clan)` |

### 3.3 — Mission placeholders (MissionManager has the data)

| # | Placeholder | Data Source |
|---|------------|-------------|
| 6 | `ethernova_clans_mission_active_count` | `MissionManager.getActiveMissions(clan).size()` |
| 7 | `ethernova_clans_mission_completed_count` | `MissionManager.getCompletedCount(clan)` |

### 3.4 — Combat/War stat placeholders (Clan object has the data)

| # | Placeholder | Data Source |
|---|------------|-------------|
| 8 | `ethernova_clans_war_wins` | `Clan.getWarsWon()` |
| 9 | `ethernova_clans_war_losses` | `Clan.getWarsLost()` |
| 10 | `ethernova_clans_wars_fought` | `getWarsWon() + getWarsLost()` |
| 11 | `ethernova_clans_war_winrate` | Computed ratio |
| 12 | `ethernova_clans_clan_kills` | `Clan.getTotalKills()` |
| 13 | `ethernova_clans_clan_deaths` | `Clan.getTotalDeaths()` |
| 14 | `ethernova_clans_clan_kdr` | Computed ratio |

### 3.5 — Miscellaneous

| # | Placeholder | Data Source |
|---|------------|-------------|
| 15 | `ethernova_clans_clan_age` | `Clan.getCreationDate()` (formatted days since) |
| 16 | `ethernova_clans_clan_created` | `Clan.getCreationDate()` (formatted date) |

> **Impact:** Server owners cannot display season rankings, skill trees, mission progress, combat stats, or clan age on scoreboards/holograms/tab via PlaceholderAPI.

---

## 4. MISSING_CONFIG — Missing `config.yml` sections/keys

**File:** `config.yml` (237 lines)

The following features have code/message support but **no configuration section** in `config.yml`:

| # | Missing Section/Key | Evidence |
|---|---------------------|----------|
| 1 | `missions.enabled` | `missions.disabled` message exists; MissionManager exists; no toggle in config |
| 2 | `missions.max-active` | MissionManager references max active missions |
| 3 | `missions.daily-count` / `missions.weekly-count` | MissionManager assigns daily/weekly but count not configurable |
| 4 | `achievements.enabled` | AchievementManager and `achievements.*` messages exist; no toggle |
| 5 | `skills.enabled` | ClanSkillManager and `skills.*` messages exist; no toggle |
| 6 | `skills.max-level` | Hardcoded to 5 in ClanSkillManager; should be configurable |
| 7 | `shop.enabled` | ClanShopManager exists; no toggle |
| 8 | `shop.max-items-per-clan` | No limit on shop items |
| 9 | `fly.enabled` / `fly.required-level` | `fly.level-required` message key references fly feature; no config |
| 10 | `salary.enabled` | `salary.*` messages exist; SalaryManager referenced; no config section |
| 11 | `salary.cycle-hours` | Salary payment frequency not configurable |
| 12 | `diplomacy.enabled` | `diplomacy.*` messages exist with full treaty system; no config |
| 13 | `diplomacy.max-treaties` | No limit configurable |
| 14 | `siege.enabled` | `siege.*` messages exist; no config section |
| 15 | `blueprint.enabled` | `blueprint.*` messages fully defined; no config section |
| 16 | `blueprint.max-per-clan` | Referenced in code but not in config |
| 17 | `banner.enabled` | `banner.*` messages exist; no config section |
| 18 | `scheduled-events.enabled` | Full event system in messages; no config |

### 4.1 — Config/Code Mismatch

| # | Issue | Detail |
|---|-------|--------|
| 19 | Season rewards key mismatch | `config.yml` L228–234 uses keys `seasons.rewards.first.money`, `seasons.rewards.second.money`, `seasons.rewards.third.money`. But `SeasonManager.java` ~L130 iterates with `config.getDouble("seasons.rewards." + place + ".money")` where `place` is an **int** (1, 2, 3) — will always return 0.0 because "1" ≠ "first". |

> **Impact:** Season rewards silently fail (always $0). 18 features cannot be toggled on/off without code changes. Server admins cannot tune mission counts, skill caps, shop limits, etc.

---

## 5. MISSING_TAB_COMPLETE — Tab completion gaps

**File:** `ClanCommandExecutor.java`, `onTabComplete()` at ~L1779

### 5.1 — Subcommands in switch but missing from tab-complete list

| # | Subcommand | In Switch? | In Tab Complete? |
|---|-----------|------------|-----------------|
| 1 | `officerchat` | ✅ Yes | ❌ No |
| 2 | `enemy` / `enemigo` | ✅ Yes | ❌ No |
| 3 | `confirm` / `confirmar` | ✅ Yes | ❌ No |

### 5.2 — Missing sub-argument completions

| # | Command | Missing Completions |
|---|---------|-------------------|
| 4 | `/clan ally <tab>` | Should suggest: `request`, `accept`, `deny`, `break` for args[1] |
| 5 | `/clan ally request <tab>` | Should suggest clan names for args[2] |
| 6 | `/clan war <tab>` | Should suggest: `declare`, `accept`, `surrender` for args[1] |
| 7 | `/clan war declare <tab>` | Should suggest clan names for args[2] |
| 8 | `/clan upgrade <tab>` | Should suggest upgrade types |

### 5.3 — Spanish aliases missing from tab-complete

| # | Missing Alias | Equivalent |
|---|--------------|-----------|
| 9 | `crear` | `create` |
| 10 | `disolver` | `disband` |
| 11 | `invitar` | `invite` |
| 12 | `unirse` | `join` |
| 13 | `salir` | `leave` |
| 14 | `expulsar` | `kick` |
| 15 | `ascender` | `promote` |
| 16 | `degradar` | `demote` |
| 17 | `aliado` | `ally` |
| 18 | `enemigo` | `enemy` |
| 19 | `reclamar` | `claim` |
| 20 | `desreclamar` | `unclaim` |
| 21 | `autoreclamar` | `autoclaim` |
| 22 | `mapa` | `map` |
| 23 | `base` | `home` |
| 24 | `setbase` | `sethome` |
| 25 | `guerra` | `war` |
| 26 | `mejorar` | `upgrade` |
| 27 | `transferir` | `transfer` |
| 28 | `banco` | `bank` |
| 29 | `nivel` | `level` |
| 30 | `confirmar` | `confirm` |
| 31 | `nacion` | `nation` |
| 32 | `puesto` | `outpost` |
| 33 | `espia` | `spy` |
| 34 | `ayuda` | `help` |
| 35 | `lista` | `list` |

### 5.4 — Planned subcommands absent from both switch AND tab-complete

These appear in `showHelp()` as `help-*` message keys but have **no handler and no tab completion**:

| # | Subcommand | Help Key Source |
|---|-----------|----------------|
| 36 | `diplomacy` | `clan.help-diplomacy` (EN L230) |
| 37 | `salary` | `clan.help-salary` (EN L231) |
| 38 | `skills` | `clan.help-skills` (EN L232) |
| 39 | `shop` | `clan.help-shop` (EN L233) |
| 40 | `stats` | `clan.help-stats` (EN L234) |
| 41 | `banner` | `clan.help-banner` (EN L235) |
| 42 | `season` | `clan.help-season` (EN L236) |
| 43 | `siege` | `clan.help-siege` (EN L229) |
| 44 | `settings` | `clan.help-settings` (EN L225) |
| 45 | `borders` | `clan.help-borders` (EN L237) |
| 46 | `missions` | Available in `progression` module but not from `/clan` |
| 47 | `achievements` | Available in `progression` module but not from `/clan` |

> **Impact:** 3 existing commands not discoverable via tab. Spanish-speaking players get no tab suggestions for aliases. 12 planned features shown in `/clan help` will error when typed.

---

## 6. CODE_QUALITY — Bugs and inconsistencies

| # | File (~Line) | Issue | Severity |
|---|-------------|-------|----------|
| 1 | `SeasonManager.java` ~L130 | **Season rewards always $0.** Code uses `config.getDouble("seasons.rewards." + place + ".money")` with `place` as int (1/2/3), but config keys are `first/second/third`. Will never match. | **CRITICAL** |
| 2 | `ClanAdminCommand.java` ~L200 | `tpchunk` case checks `args.length < 3` but the command is `/cadmin tpchunk <x> <z>` requiring exactly 3 args. The condition should be `args.length < 3` which is correct for minimum check, but error message should clarify usage. Currently no usage message is sent. | LOW |
| 3 | `ClanAdminCommand.java` ~L110–113 | `spy` admin subcommand only checks permission (`ethernova.clans.admin.spy`) and sends no response. Doesn't actually toggle spy mode or call any spy manager method. Dead code path. | HIGH |
| 4 | `ClanCommandExecutor.java` ~L408 | References message key `rank.already-minimum` for demote — this key does not exist in either messages file. Should be `clan.demote-fail` or similar. | MEDIUM |
| 5 | `ClanCommandExecutor.java` showHelp() | Sends help lines for `diplomacy`, `salary`, `skills`, `shop`, `stats`, `banner`, `season`, `siege`, `settings`, `borders` — but none of these have handlers. Players see commands that don't work. | HIGH |
| 6 | `MissionManager.java` ~L175 | Uses `plugin.getConfigManager().getMessage(...)` — consistent with the rest of the codebase, but the `MissionManager` constructs the reward notification inline rather than delegating to the `missions.completed` message key with proper placeholders. Reward values may not match message template. | LOW |
| 7 | `SeasonManager.java` ~L155–190 | `broadcastSeasonEnd()` builds the entire end-of-season broadcast as hardcoded MiniMessage instead of using the `season.ended`, `season.reward`, and `season.new-season` keys that are defined in both message files. Duplicated, unmaintainable logic. | HIGH |
| 8 | `ClanSkillManager.java` ~L40–80 | Skill names and descriptions stored as hardcoded Spanish strings in a HashMap. No config or messages file integration. Impossible to customize or translate without recompiling. | HIGH |

---

## 7. MISSING_FEATURES — Features with infrastructure but no command entry point

### 7.1 — Subcommands advertised in help but unimplemented

The `/clan help` output (via `showHelp()`) displays these subcommands using message keys, but `ClanCommandExecutor.onCommand()` has **no `case` for them**:

| # | Subcommand | Infrastructure Present | What's Missing |
|---|-----------|----------------------|----------------|
| 1 | `/clan diplomacy` | Full message set (15 keys EN/ES), GuiManager has `openDiplomacy()` | No switch case, no CLI handler, no tab complete |
| 2 | `/clan salary` | Full message set (14 keys EN/ES) | No switch case, no CLI handler, no tab complete |
| 3 | `/clan skills` | ClanSkillManager (8 skills, 5 levels), `skills.*` messages | No switch case, no CLI handler, no tab complete |
| 4 | `/clan shop` | ClanShopManager (full CRUD), cosmetics module has separate `/cosmetics shop` | No switch case in `/clan`, no tab complete |
| 5 | `/clan stats` | Clan object has kills/deaths/wars data | No switch case, no handler, no messages specific to stats view |
| 6 | `/clan banner` | Full message set (9 keys EN, 4 keys ES) | No switch case, no CLI handler, no tab complete |
| 7 | `/clan season` | SeasonManager, full message set (4 keys), ranked module has `/ranked season` | No switch case in `/clan`, no tab complete |
| 8 | `/clan siege` | `siege.*` messages (4 keys EN/ES) | No switch case, no handler, no config, no SiegeManager |
| 9 | `/clan settings` | Help key exists | No switch case, no handler, no settings manager |
| 10 | `/clan borders` | Help key exists | No switch case, no handler, no border visualization |
| 11 | `/clan missions` | MissionManager, full message set (10 keys), progression module has `/progression missions` | No switch case in `/clan`, no tab complete |
| 12 | `/clan achievements` | AchievementManager, full message set (4 keys), progression module has `/progression achievements` | No switch case in `/clan`, no tab complete |

### 7.2 — Scheduler gaps

| # | Feature | Issue |
|---|---------|-------|
| 13 | Daily mission rotation | `MissionManager.assignDailyMissions()` exists but is never scheduled. No `BukkitRunnable` or scheduled task triggers it automatically. Missions must be assigned manually or via external trigger. |
| 14 | Salary payment cycle | `salary.paid-notification` message exists but there's no scheduled task in the main module to collect/pay salaries periodically. |

### 7.3 — Admin command gaps

**File:** `ClanAdminCommand.java` (278 lines)

| # | Missing Admin Command | Rationale |
|---|----------------------|-----------|
| 15 | `/cadmin forcekick <player>` | Can forcejoin but not forcekick |
| 16 | `/cadmin resetskills <clan>` | No way to reset clan skills via admin |
| 17 | `/cadmin resetmissions <clan>` | No way to reset missions via admin |
| 18 | `/cadmin setname <clan> <name>` | No way to rename a clan without disbanding |
| 19 | `/cadmin settag <clan> <tag>` | No way to change clan tag without disbanding |
| 20 | `/cadmin endwar <clan1> <clan2>` | No way to force-end a war between clans |

---

## Summary

| Category | Count | Severity |
|----------|-------|----------|
| MISSING_MESSAGES (EN→ES) | 15 keys | Medium |
| HARDCODED_STRINGS | 8 locations | High |
| MISSING_PLACEHOLDERS | 16 placeholders | Medium |
| MISSING_CONFIG | 19 entries | High |
| MISSING_TAB_COMPLETE | 47 items | Medium |
| CODE_QUALITY | 8 issues (1 critical) | Critical–Low |
| MISSING_FEATURES | 20 items | High |

**Total gaps identified: 133**

### Critical Priority (fix first)
1. Season rewards always $0 due to config key mismatch (§6 #1)
2. 12 help-advertised subcommands that error on use (§7.1)
3. Hardcoded Spanish strings in confirmations and help menus (§2)

### High Priority
4. 15 missing ES translations (§1)
5. 18 missing config toggles for major features (§4)
6. Dead code in admin spy command (§6 #3)
7. Skill system completely untranslatable (§2.3)

### Medium Priority
8. 16 missing PAPI placeholders (§3)
9. 47 tab-complete gaps (§5)
10. Missing schedulers for missions/salary (§7.2)
