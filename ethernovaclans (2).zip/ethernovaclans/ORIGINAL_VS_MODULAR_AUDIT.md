# 🔍 Auditoría Completa: UltimateFFA Original vs EthernovaClans Modularizado

## Resumen Ejecutivo

El plugin original **UltimateFFA v1.1.0** era un plugin monolítico con **30+ sistemas** integrados.
La versión modularizada **EthernovaClans** tiene **11 módulos Maven** pero hay diferencias significativas.

---

## 📦 ITEMS DEL LOBBY — LO QUE SE INVENTÓ vs LO ORIGINAL

### ❌ Lo que se inventó (INCORRECTO - en config.yml actual):
| Slot | Material | Nombre | Acción |
|------|----------|--------|--------|
| 0 | IRON_SWORD | ⚔ Duelos | `duel queue` |
| 1 | GOLDEN_SWORD | ⚔ FFA | `ffa join` |
| 4 | COMPASS | ✦ Estadísticas | `duel stats` |
| 7 | BOOK | ☆ Perfil | `ethernova profile` |
| 8 | RED_BED | ✖ Salir | `hub` |

### ✅ Lo que tenía el original (GameManager.java línea 383):
| Slot | Material | Nombre | Mecánica |
|------|----------|--------|----------|
| **0** | `DIAMOND_SWORD` | `§aPvP Mode §7(Mantén)` | Timer tick-based: mantener 3 ticks consecutivos → activa PvP Mode (armadura diamond + espada + 8 golden apples, SURVIVAL) |
| **2** | `COMPASS` | `§aArenas FFA` | Abre GUI de Arenas FFA (`openArenasGUI`) |
| **4** | `NETHER_STAR` | `§b§l✦ Menú Principal §b✦` | Abre Menú Principal (45 slots) con acceso a: Party, Misiones, Battle Pass, Ranking, Calendario, Logros, Clanes, Duelos, Ajustes |
| **6** | `ENDER_EYE` | `§eEspectar` | Abre GUI de Espectador |
| **8** | `EMERALD` | `§aTienda de Cosméticos` | Abre GUI de Tienda |

### Items dinámicos del original:
- **Slot 3**: Vacío si no tiene party / `NETHER_STAR` (Menú Principal) si tiene party
- **Slot 4**: `NETHER_STAR` (Menú Principal) si no tiene party / `CAKE` (Party info) si tiene party

### Mecánicas especiales del lobby original:
- **PvP Sword Timer**: La espada NO hace click, se MANTIENE en la mano 3 ticks con una barra de carga en ActionBar
- **GameMode**: ADVENTURE en lobby
- **Items taggeados**: con `lobby_item` key en PersistentDataContainer (previene drops)
- **Click detection**: por nombre del item (strip color codes + contains match)

---

## 🔧 SISTEMAS — Original vs Modularizado

### ✅ PRESENTE en ambos (funcional):
| Sistema | Original | Modularizado | Módulo |
|---------|----------|-------------|--------|
| FFA (Free-For-All) | ✅ GameManager | ✅ FFAManager | `ffa` |
| Duelos 1v1 | ✅ DuelManager | ✅ DuelManager | `duels` |
| Clanes | ✅ ClansManager | ✅ ClanManager (extendido) | `src` (clans) |
| Partys | ✅ PartyManager | ✅ PartyManager | `party` |
| Ranked/ELO | ✅ RankedManager | ✅ EloManager | `ranked` |
| Combate (CombatTag) | ✅ CombatManager | ✅ CombatTagManager | `combat` |
| Bounties | ✅ BountyManager | ✅ BountyManager | `combat` |
| Killstreaks | ✅ KillstreakManager | ✅ KillstreakManager | `combat` |
| Streaks mejorados | ✅ ImprovedStreaksManager | ✅ StreakAbilityManager | `combat` |
| Niveles | ✅ LevelManager | ✅ LevelManager | `progression` |
| Prestigio | ✅ PrestigeManager | ✅ PrestigeManager | `progression` |
| Misiones | ✅ MissionsManager | ✅ MissionManager | `progression` |
| Logros | ✅ AchievementsManager | ✅ AchievementManager | `progression` |
| BattlePass | ✅ BattlePassManager | ✅ BattlePassManager | `progression` |
| Cosméticos | ✅ CosmeticsManager | ✅ CosmeticsManager | `cosmetics` |
| Auras avanzadas | ✅ AdvancedAurasManager | ✅ AuraManager | `cosmetics` |
| Hit Effects | ✅ HitEffectsManager | ✅ HitEffectManager | `cosmetics` |
| Death Recap | ✅ DeathRecapManager | ✅ DeathRecapManager | `combat` |
| Economía | ✅ EconomyManager | ✅ EconomyService | `core` |
| Scoreboard | ✅ FastBoardManager | ✅ ScoreboardManager | `core` |
| Almacenamiento | ✅ StorageProvider (YAML/SQLite) | ✅ DatabaseManager (SQLite/MySQL) | `core` |
| Restauración bloques | ✅ BlockRestoreManager | ✅ ArenaRollbackEngine | `core` |
| Rotación arenas | ✅ ArenaRotationManager | (parcial) | `ffa` |
| Espectador | ✅ SpectatorManager | ✅ SpectatorManager | `duels` |
| Settings jugador | ✅ PlayerSettingsManager | (parcial via profile) | `core` |
| Discord | N/A | ✅ EthernovaDiscord | `discord` |

### ⚠️ PARCIAL — Existe pero con menos funcionalidad:
| Sistema | Original | Modularizado | Qué falta |
|---------|----------|-------------|-----------|
| **Tienda/Shop** | GUI completa con 14+ categorías (skins, auras, kill-effects, death-sounds, pets, join-messages, trails, elytra-trails, hit-effects, achievement-cosmetics, prestige shop, mystery crate, settings) | Solo compra básica de cosméticos | GUI de tienda con todas las categorías, mystery box, daily rewards |
| **GUIs** | 10+ GUIs configurables (arena-selector, shop, duel-selector, stats, rankings, missions, kit-editor, settings, main-menu) | GUIs básicos | Faltan: Main Menu, Rankings, Settings GUI, Kit Editor |
| **Estadísticas avanzadas** | advanced-stats.yml (100+ métricas: combate, streaks, duelos, elo, arenas, economía, cosméticos, social, sesiones, diarias/semanales/mensuales, récords personales, análisis rendimiento) | Stats básicas | Falta mayoría de métricas avanzadas |
| **Lobby con items** | 5 items hardcodeados + items dinámicos de party + PvP sword timer | 5 items INVENTADOS en config | Items completamente diferentes |
| **Eventos** | 6 tipos (Happy Hour, Blood Moon, King of Hill, Supply Drop, Boss Fight, Sudden Death) con programación automática | EventsManager existe | Verificar completitud |

### ❌ AUSENTE en la versión modularizada:
| Sistema | Archivo/Manager Original | Descripción |
|---------|-------------------------|-------------|
| **Party Games** | PartyGamesManager.java, PartyGamesArenaManager.java, party-games en Config.yml | 7 modos: Duels, Party FFA, KotH, Sumo, Parkour, Challenge, Party Wars |
| **Títulos** | TitlesManager.java | Títulos con prefijo que se desbloquean con logros/rango |
| **Finishers** | FinishersManager.java | 8 tipos de animaciones al matar |
| **Skins de armas/armadura** | skins.yml (485 líneas) | Skins con model data, partículas, sonidos (6+ weapon skins, 4+ armor sets, bow skins, projectile effects) |
| **Elytra Trails** | elytra-trails.yml | 20+ trails animados para elytra |
| **Mascotas (Pets)** | PetManager.java | Mascotas que siguen al jugador |
| **Kit Layout Editor** | KitLayoutEditor.java, guis.yml kit-editor | Editor de posición de items en inventario |
| **Custom Kits** | CustomKitsManager | Kits personalizados guardados |
| **Seasons** | SeasonsManager | Temporadas con reset de stats y rewards |
| **Referrals** | ReferralManager | Sistema de referidos |
| **Tournaments** | TournamentManager | Torneos programados |
| **Logs** | LogsManager | Logging avanzado |
| **Optimization** | OptimizationManager | Optimizaciones de rendimiento |
| **Admin GUI** | AdminGUIManager.java, AdminPlayerGUI.java | Panel admin completo con GUI |
| **GUI animadas** | disco-glass en Config.yml | Cristales animados en bordes de GUIs |
| **Menú Principal** | Slot 4 lobby: Menú con acceso a todos los sistemas | GUI central de 45 slots |
| **Rankings GUI** | guis.yml (Top Kills, KDR, Dinero, ELO, Victorias) | GUI de leaderboards |
| **Settings GUI** | guis.yml (Espectadores, Invitaciones, Scoreboard) | GUI de ajustes del jugador |
| **Comparar jugadores** | `/compare` command, comparison en advanced-stats.yml | Comparación de stats jugador vs jugador |
| **Daily Rewards** | shop.yml (7 días, cooldown, racha) | Recompensas diarias por login |
| **Mystery Box** | shop.yml (costo + refund duplicado) | Caja de cosméticos aleatorios |

---

## 📋 COMANDOS — Original vs Modularizado

### Comandos del original (plugin.yml):
| Comando | Original | ¿Existe en modularizado? |
|---------|----------|-------------------------|
| `/ffa` | ✅ | ✅ |
| `/shop` (`/tienda`, `/store`) | ✅ | ❌ (shop module no existe como tal) |
| `/lobby` (`/hub`, `/l`) | ✅ | ⚠️ Parcial (solo via `sendToLobby`) |
| `/ffasetkit` | ✅ | ✅ |
| `/spectate` | ✅ | ✅ |
| `/1v1` (`/duel`) | ✅ | ✅ |
| `/prestige` | ✅ | ✅ |
| `/missions` | ✅ | ✅ |
| `/achievements` | ✅ | ✅ |
| `/clan` | ✅ | ✅ |
| `/party` | ✅ | ✅ |
| `/ranked` | ✅ | ✅ |
| `/titles` | ✅ | ❌ |
| `/events` | ✅ | ⚠️ verificar |
| `/skins` | ✅ | ❌ |
| `/compare` | ✅ | ❌ |
| `/stats` | ✅ | ⚠️ parcial |
| `/leaderboard` | ✅ | ⚠️ parcial |
| `/auras` | ✅ | ⚠️ parcial |
| `/hiteffects` | ✅ | ⚠️ parcial |
| `/kiteditor` | ✅ | ❌ |
| `/deathrecap` | ✅ | ✅ |
| `/pgsetup` (Party Games) | ✅ | ❌ |

---

## 📄 ARCHIVOS DE CONFIGURACIÓN — Original vs Modularizado

| Config Original | Líneas | ¿Migrado? | Notas |
|----------------|--------|-----------|-------|
| Config.yml | 887 | ⚠️ Parcial | Muchas secciones no migradas (shop GUI, kill-effects, economy, bounty, killstreak, levels, battlepass, auras, party-games, armor-trims) |
| guis.yml | 402 | ❌ | 10 GUIs completas no migradas |
| messages.yml | 200 | ⚠️ Parcial | Mensajes split entre módulos |
| arenas.yml | 259 | ⚠️ Parcial | Template de arena + arenas predefinidas |
| Kits.yml | ~50 | ⚠️ Parcial | Kits con allowBuild |
| achievements.yml | 394 | ⚠️ | Verificar completitud |
| shop.yml | 235 | ❌ | Mystery box, daily rewards, precios |
| scoreboards.yml | 161 | ⚠️ Parcial | 3 scoreboards (lobby, ffa, duel) + animaciones |
| ranks.yml | 284 | ⚠️ | Verificar 8 rangos con rewards |
| elo.yml | 228 | ⚠️ | 7 divisiones, matchmaking, protecciones, seasons |
| rewards.yml | 317 | ⚠️ | Kill rewards, killstreaks, duel rewards, bounties, first-time |
| events.yml | 381 | ⚠️ | 6 tipos de eventos |
| clans.yml | 362 | ✅ | Migrado al módulo clans (expandido significativamente) |
| party.yml | ~100 | ✅ | Migrado |
| skins.yml | 485 | ❌ | No existe módulo de skins |
| elytra-trails.yml | 61 | ❌ | No existe |
| advanced-stats.yml | 396 | ❌ | No existe como config |

---

## ✅ LO QUE EL MODULARIZADO AGREGÓ (no estaba en el original):

1. **Módulo Clans enormemente expandido**: Naciones, territorios, asedios, outposts, diplomacia, impuestos, salarios, blueprints, webmap, upgrades, shields, skills, spy, hologramas, seasons/economy propias
2. **Discord module**: Bot integrado con sincronización
3. **MySQL support**: Además de SQLite
4. **MiniMessage/Adventure**: En vez de legacy ChatColor
5. **Paper 1.21.4**: Actualizado desde 1.20
6. **Multi-server architecture**: Diseñado para separar Survival/Practice
7. **Maven multi-module**: Build modular
8. **Arena Rollback Engine**: Sistema más robusto que el BlockRestoreManager original
9. **Queue system**: Matchmaking separado del original

---

## 🎯 PRIORIDAD DE RESTAURACIÓN

### P0 — CRÍTICO (lobby roto):
1. **Corregir items del lobby** para que coincidan con el original
2. **Implementar PvP Sword Timer** (mecánica de mantener la espada)
3. **Restaurar Menú Principal GUI** (45 slots, acceso a todo)

### P1 — ALTO (sistemas visibles por jugadores):
4. **Shop/Tienda GUI** con todas las categorías
5. **Rankings/Leaderboard GUI**
6. **Settings GUI** del jugador
7. **Party Games** (7 modos)
8. **Titles system**
9. **Daily Rewards**
10. **Mystery Box**

### P2 — MEDIO (mejoran la experiencia):
11. **Skins system** (armas, armadura, proyectiles)
12. **Finishers** (animaciones de kill)
13. **Kit Editor** (layout personalizable)
14. **Elytra Trails**
15. **Pets**
16. **GUI disco-glass** (animaciones)
17. **Main Menu** GUI central

### P3 — BAJO (infraestructura):
18. **Seasons/Temporadas** (reset de stats)
19. **Tournaments** (torneos)
20. **Referrals** (sistema de referidos)
21. **Admin GUI**
22. **Optimization Manager**
23. **Advanced Logs**
