# 🔍 Deep Code Audit Report — EthernovaCombat, EthernovaCosmetics, EthernovaParty

**Audited:** All 74 Java files + all resource files across 3 plugins  
**API Target:** Paper 1.21  
**Date:** 2025  

---

## Summary

| Severity | Count |
|----------|-------|
| 🔴 CRITICAL | 4 |
| 🟠 HIGH | 6 |
| 🟡 MEDIUM | 10 |
| 🔵 LOW | 5 |
| **Total** | **25** |

---

## 🔴 CRITICAL Bugs

### BUG-01: DeathRecapManager is completely dead code — never integrated
- **Plugin:** EthernovaCombat
- **Files:** `CombatDamageListener.java`, `CombatDeathListener.java`, `DeathRecapManager.java`
- **Methods:** `CombatDamageListener.onEntityDamage()`, `CombatDeathListener.onPlayerDeath()`
- **Severity:** 🔴 CRITICAL
- **Category:** Logic Error / Inter-system connectivity

**Description:**  
`DeathRecapManager` is instantiated in `EthernovaCombat.onEnable()` and exposes two key methods: `recordDamage()` (to log incoming damage) and `sendRecap()` (to display the recap on death). **Neither method is ever called from anywhere in the codebase.**

- `CombatDamageListener.onEntityDamage()` tags players and shows hit effects, but **never calls `deathRecapManager.recordDamage()`** to record the damage entry.
- `CombatDeathListener.onPlayerDeath()` processes kill rewards, killstreaks, and death effects, but **never calls `deathRecapManager.sendRecap()`** to show the victim their death recap.

The entire death recap system (damage recording, 8-entry Deque, formatted death summary) is dead code.

**Suggested Fix:**  
In `CombatDamageListener.onEntityDamage()`, after tagging, add:
```java
plugin.getDeathRecapManager().recordDamage(victim.getUniqueId(), cause, damage, attackerName);
```
In `CombatDeathListener.onPlayerDeath()`, before/after processing kill rewards, add:
```java
plugin.getDeathRecapManager().sendRecap(victim);
```

---

### BUG-02: BountyManager.claimBounties() is never called — bounties never pay out
- **Plugin:** EthernovaCombat
- **Files:** `CombatDeathListener.java`, `BountyManager.java`
- **Method:** `CombatDeathListener.onPlayerDeath()`
- **Severity:** 🔴 CRITICAL
- **Category:** Logic Error / Inter-system connectivity

**Description:**  
`BountyManager` allows players to place bounties via `/bounty <player> <amount>` and stores them in a `ConcurrentHashMap<UUID, List<Bounty>>`. The `claimBounties(UUID killer, UUID victim)` method is designed to pay out bounties when the target is killed.

However, **`claimBounties()` is never called from `CombatDeathListener` or anywhere else**. When a player with a bounty on their head is killed, nothing happens — the bounty stays active indefinitely and the killer is never rewarded.

**Suggested Fix:**  
In `CombatDeathListener.onPlayerDeath()`, after confirming a valid kill:
```java
plugin.getBountyManager().claimBounties(killer.getUniqueId(), victim.getUniqueId());
```

---

### BUG-03: ComboManager is completely dead code — never integrated
- **Plugin:** EthernovaCombat
- **Files:** `CombatDamageListener.java`, `ComboManager.java`
- **Method:** `CombatDamageListener.onEntityDamage()`
- **Severity:** 🔴 CRITICAL
- **Category:** Logic Error / Inter-system connectivity

**Description:**  
`ComboManager` tracks consecutive hits on the same target within a time window and returns a `[comboCount, damageMultiplier]` pair. It exposes `registerHit()` to record hits and query the combo state.

**`registerHit()` is never called from any listener or handler.** The combo system (consecutive hit tracking, damage multiplier, combo counter display) is entirely dead code.

**Suggested Fix:**  
In `CombatDamageListener.onEntityDamage()`, after resolving the attacker:
```java
int[] comboResult = plugin.getComboManager().registerHit(attacker.getUniqueId(), victim.getUniqueId());
// Apply comboResult[1] as damage multiplier if desired
```

---

### BUG-04: StreakAbilityManager is completely dead code — never integrated
- **Plugin:** EthernovaCombat
- **Files:** `CombatDeathListener.java`, `StreakAbilityManager.java`
- **Method:** `CombatDeathListener.onPlayerDeath()`
- **Severity:** 🔴 CRITICAL
- **Category:** Logic Error / Inter-system connectivity

**Description:**  
`StreakAbilityManager` applies potion effects at killstreak milestones using `PotionEffectType.getByKey()`. It exposes `checkStreak(Player player, int streak)` to apply streak-based abilities.

**`checkStreak()` is never called from `CombatDeathListener` or anywhere else**, despite `KillStreakManager.addKill()` being called correctly on each kill. The killstreak counter goes up, but the ability rewards from `StreakAbilityManager` are never applied.

**Suggested Fix:**  
In `CombatDeathListener.onPlayerDeath()`, after `killStreakManager.addKill()`:
```java
int streak = plugin.getKillStreakManager().getStreak(killer.getUniqueId());
plugin.getStreakAbilityManager().checkStreak(killer, streak);
```

---

## 🟠 HIGH Bugs

### BUG-05: Bounties are never persisted — all lost on server restart
- **Plugin:** EthernovaCombat
- **File:** `BountyManager.java`
- **Severity:** 🟠 HIGH
- **Category:** Data Loss

**Description:**  
`BountyManager` stores bounties in a `ConcurrentHashMap<UUID, List<Bounty>>` that exists only in memory. There is no `save()` or `load()` method, no file I/O, and no SQL integration. When the server restarts or the plugin is reloaded, **all active bounties are permanently lost** — including the money that was deducted from the bounty placers.

Players lose their money when placing a bounty, and if no one claims it before a restart, that money simply vanishes.

**Suggested Fix:**  
Implement persistence via a YAML file or the Core SQL `StorageManager`:
```java
public void saveBounties() { /* serialize to bounties.yml or SQL */ }
public void loadBounties() { /* deserialize on enable */ }
```
Call `saveBounties()` in `EthernovaCombat.onDisable()` and after each `placeBounty()`/`claimBounties()`.

---

### BUG-06: DeathRecapManager uses non-thread-safe ArrayDeque inside ConcurrentHashMap
- **Plugin:** EthernovaCombat
- **File:** `DeathRecapManager.java`
- **Method:** `recordDamage()`, timer-based iteration
- **Severity:** 🟠 HIGH
- **Category:** Thread Safety

**Description:**  
`DeathRecapManager` uses `ConcurrentHashMap<UUID, Deque<DamageEntry>>` where the `Deque` is an `ArrayDeque`. While `ConcurrentHashMap` provides thread-safe key/value access, the `ArrayDeque` value itself is **not thread-safe**. If `recordDamage()` is called from an async event or timer while another thread iterates the deque for `sendRecap()`, it can cause `ConcurrentModificationException` or corrupt the deque's internal array.

**Suggested Fix:**  
Replace `ArrayDeque` with `ConcurrentLinkedDeque` or `LinkedBlockingDeque`, or synchronize access:
```java
playerDamage.computeIfAbsent(uuid, k -> new ConcurrentLinkedDeque<>());
```

---

### BUG-07: CombatDisconnectListener missing cleanup for 5 managers on player quit
- **Plugin:** EthernovaCombat
- **File:** `CombatDisconnectListener.java`
- **Method:** `onPlayerQuit()`
- **Severity:** 🟠 HIGH
- **Category:** Memory Leak / State Corruption

**Description:**  
`onPlayerQuit()` cleans up `profileManager`, `killStreakManager`, `rewardManager`, `kdrAbuseManager`, `newbieManager`, and `detectionManager`. However, it **fails to clean up** data for the disconnecting player in:

1. **`ComboManager`** — combo tracking for the player persists
2. **`BountyManager`** — placed bounties remain (if persistence is added later)
3. **`DeathRecapManager`** — accumulated damage entries remain in memory
4. **`StreakAbilityManager`** — activated streak abilities tracking persists
5. **`RevengeManager`** — last-killer tracking persists

Over time with many joins/quits, these maps accumulate stale entries causing a slow memory leak.

**Suggested Fix:**  
Add cleanup calls in `onPlayerQuit()`:
```java
plugin.getComboManager().clear(uuid);
plugin.getDeathRecapManager().clear(uuid);
plugin.getStreakAbilityManager().clear(uuid);
plugin.getRevengeManager().clear(uuid);
```

---

### BUG-08: MiniMessage injection in party chat messages
- **Plugin:** EthernovaParty
- **File:** `PartyChat.java`
- **Method:** `formatMessage()`
- **Severity:** 🟠 HIGH
- **Category:** Security / Input Validation

**Description:**  
`formatMessage()` replaces `{message}` in the format string with the raw, unescaped chat message, then passes the entire string to `MiniMessage.deserialize()`:

```java
String formatted = format
        .replace("{player}", sender.getName())
        .replace("{message}", message);  // RAW user input
return MINI.deserialize(formatted);
```

This allows **any player** to inject MiniMessage formatting tags in party chat:
- `<red><bold>` for arbitrary formatting
- `<click:run_command:/op SomePlayer>Click here!</click>` to create deceptive clickable components
- `<hover:show_text:'malicious'>` for misleading hover text
- `<reset>` to break the format

While clickable components require another player to click, this is a **social engineering vector** that could trick party members into running commands.

**Suggested Fix:**  
Escape user input before inserting into the format:
```java
String escapedMessage = MiniMessage.miniMessage().escapeTags(message);
String escapedPlayer = MiniMessage.miniMessage().escapeTags(sender.getName());
String formatted = format
        .replace("{player}", escapedPlayer)
        .replace("{message}", escapedMessage);
```

---

### BUG-09: Combat tag not cleaned up when NPC dies or despawns
- **Plugin:** EthernovaCombat
- **Files:** `CombatNPCManager.java`, `CombatNPCListener.java`, `CombatDisconnectListener.java`
- **Methods:** `onNPCKilled()`, NPC auto-despawn scheduler
- **Severity:** 🟠 HIGH
- **Category:** Logic Error / Resource Leak

**Description:**  
When a player disconnects during combat:
1. `CombatDisconnectListener` spawns an NPC but does **not** untag the player
2. The combat tag timer continues running for the offline player
3. When the NPC dies (`CombatNPCListener.onNPCKilled()`) or auto-despawns, the tag is **never removed**
4. The tag timer continues trying to send BossBar/ActionBar updates to a null/offline player

This means:
- The timer loop in `CombatTagManager` iterates stale entries for offline players
- BossBar updates to offline players waste resources
- The tag only expires naturally after the configured duration, regardless of NPC state

**Suggested Fix:**  
In `CombatNPCManager.onNPCKilled()` and the auto-despawn runnable, call:
```java
plugin.getTagManager().untag(ownerUuid);
```

---

### BUG-10: Cosmetic unlock not atomic with coin deduction — data loss on crash
- **Plugin:** EthernovaCosmetics
- **Files:** `CosmeticTypeGui.java`, `CosmeticShopGui.java`, `PlayerCosmeticManager.java`
- **Severity:** 🟠 HIGH
- **Category:** Data Integrity

**Description:**  
When purchasing a cosmetic, the flow is:
1. `profile.removeCoins(price)` — immediate, synchronous
2. `playerCosmeticManager.unlock(uuid, cosmetic)` — updates in-memory map synchronously, but SQL save runs **asynchronously** via `Bukkit.getScheduler().runTaskAsynchronously()`

If the server crashes after step 1 but before the async SQL save in step 2 completes, the player's coins are deducted (Core profile is saved), but the cosmetic ownership is lost (never written to SQL). The player loses money with nothing to show for it.

**Suggested Fix:**  
Either make the SQL save synchronous for purchases, or wrap both operations in a single transaction:
```java
// Option A: Make critical saves synchronous
playerCosmeticManager.unlockSync(uuid, cosmetic);

// Option B: Save coins and cosmetic in same async transaction
Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
    try (Connection conn = ...) {
        conn.setAutoCommit(false);
        // deduct coins
        // insert cosmetic
        conn.commit();
    }
});
```

---

## 🟡 MEDIUM Bugs

### BUG-11: ComboManager.ComboData has non-volatile mutable fields
- **Plugin:** EthernovaCombat
- **File:** `ComboManager.java`
- **Inner class:** `ComboData`
- **Severity:** 🟡 MEDIUM
- **Category:** Thread Safety

**Description:**  
`ComboData` is stored as a value in a `ConcurrentHashMap<UUID, ComboData>` but its fields (`comboCount`, `lastTarget`, `lastHitTime`, `damageMultiplier`) are **plain (non-volatile) instance fields**. While the `ConcurrentHashMap` guarantees safe publication of the reference, subsequent mutations to the object's fields are **not guaranteed to be visible across threads** without volatile or synchronization.

**Suggested Fix:**  
Either make `ComboData` immutable (replace-on-write pattern with `ConcurrentHashMap.put()`) or mark fields as `volatile`.

---

### BUG-12: RevengeManager.clear() only removes victim key, leaks killer references
- **Plugin:** EthernovaCombat
- **File:** `RevengeManager.java`
- **Method:** `clear(UUID uuid)`
- **Severity:** 🟡 MEDIUM
- **Category:** Memory Leak / Incomplete Cleanup

**Description:**  
`clear(UUID uuid)` only removes the entry where `uuid` is the victim key in the `lastKiller` map. It does **not** remove entries where `uuid` is the killer value. If player A killed player B, then player A disconnects, the entry `B → A` persists. When B kills someone else, the revenge check compares against stale data.

**Suggested Fix:**
```java
public void clear(UUID uuid) {
    lastKiller.remove(uuid);
    lastKiller.values().removeIf(killerUuid -> killerUuid.equals(uuid));
}
```

---

### BUG-13: ClanIntegrationListener uses hardcoded oldPower=0
- **Plugin:** EthernovaCombat
- **File:** `ClanIntegrationListener.java`
- **Method:** `onCombatLogPenalty()`
- **Severity:** 🟡 MEDIUM
- **Category:** Logic Error

**Description:**  
When publishing `PowerChangeEvent` for combat log penalties, the `oldPower` parameter is hardcoded to `0` instead of fetching the player's actual current power:

```java
new PowerChangeEvent(uuid, 0, -powerLoss, "combat_log")
```

Any system listening for `PowerChangeEvent` that uses `oldPower` for calculations or logging will see incorrect data.

**Suggested Fix:**  
Retrieve the actual current power from the clan system before publishing the event.

---

### BUG-14: LootProtectionManager.shouldShowDenialMessage() is never used
- **Plugin:** EthernovaCombat
- **Files:** `CombatItemListener.java`, `LootProtectionManager.java`
- **Severity:** 🟡 MEDIUM
- **Category:** Dead Code / Duplicate Logic

**Description:**  
`LootProtectionManager` implements `shouldShowDenialMessage()` with a configurable cooldown for loot denial messages. However, `CombatItemListener` implements its **own separate cooldown logic** using a local `denialCooldowns` map and never calls `LootProtectionManager.shouldShowDenialMessage()`.

This results in duplicate, divergent cooldown implementations — the one in `LootProtectionManager` is dead code.

**Suggested Fix:**  
Remove the duplicate cooldown in `CombatItemListener` and call:
```java
if (plugin.getLootProtectionManager().shouldShowDenialMessage(uuid)) {
    // send denial message
}
```

---

### BUG-15: PartyListener uses deprecated AsyncPlayerChatEvent
- **Plugin:** EthernovaParty
- **File:** `PartyListener.java`
- **Method:** `onPlayerChat()`
- **Severity:** 🟡 MEDIUM
- **Category:** Deprecation / Compatibility

**Description:**  
`PartyListener` uses `AsyncPlayerChatEvent` which is deprecated in Paper 1.19+ and may be removed in future versions. For Paper 1.21, the correct event is `io.papermc.paper.event.player.AsyncChatEvent` with the new Adventure-based chat system.

Additionally, `event.setCancelled(true)` on `AsyncPlayerChatEvent` suppresses the message for ALL listeners, not just chat output. Other plugins listening to this event (e.g., logging plugins) will also miss the message.

**Suggested Fix:**  
Migrate to `AsyncChatEvent`:
```java
@EventHandler(priority = EventPriority.LOW)
public void onPlayerChat(AsyncChatEvent event) {
    // Use event.message() (Component) instead of event.getMessage() (String)
}
```

---

### BUG-16: PartyChat quick-prefix chat processed on async thread
- **Plugin:** EthernovaParty
- **File:** `PartyListener.java`
- **Method:** `onPlayerChat()`
- **Severity:** 🟡 MEDIUM
- **Category:** Thread Safety

**Description:**  
The `AsyncPlayerChatEvent` fires on an **async thread**. The handler correctly schedules the broadcast to the main thread:
```java
Bukkit.getScheduler().runTask(plugin, () -> partyChat.broadcast(...));
```

However, **before** reaching this line, the handler calls:
- `partyChat.isChatEnabled()` — reads from `ConcurrentHashMap.newKeySet()` (safe individually)
- `plugin.getPartyManager().getParty()` — reads from `ConcurrentHashMap` (safe individually)
- `partyChat.disable()` — writes to `ConcurrentHashMap.newKeySet()` (safe individually)

The combined logic (check chat enabled → get party → if null, disable chat) has a TOCTOU window: the party could be disbanded between the `getParty()` check and the broadcast. The main-thread broadcast would then send to a disbanded party's stale member list.

**Suggested Fix:**  
Move the entire logic to the main thread, or add a null check inside the broadcast lambda:
```java
Bukkit.getScheduler().runTask(plugin, () -> {
    Party party = plugin.getPartyManager().getParty(player.getUniqueId());
    if (party != null) partyChat.broadcast(party, player, finalMessage);
});
```

---

### BUG-17: Party.accept() has TOCTOU race on isFull() + add()
- **Plugin:** EthernovaParty
- **File:** `Party.java`
- **Method:** `accept(UUID uuid)`
- **Severity:** 🟡 MEDIUM
- **Category:** Thread Safety

**Description:**  
```java
public boolean accept(UUID uuid) {
    if (isFull()) return false;        // Check
    if (!isPublic && !isInvited(uuid)) return false;
    invited.remove(uuid);
    members.add(uuid);                 // Act
    return true;
}
```

`isFull()` checks `members.size() >= maxSize` and `members.add()` are **not atomic**. If two players accept simultaneously (e.g., two public party joins processed in quick succession), both could pass the `isFull()` check before either's `add()` executes, allowing the party to exceed `maxSize`.

In practice, Bukkit commands run on the main thread so this is unlikely, but `joinPublicParty()` could theoretically be called from non-main-thread contexts.

**Suggested Fix:**  
Add synchronization around the check-then-act:
```java
public synchronized boolean accept(UUID uuid) { ... }
```

---

### BUG-18: PartyGui hardcodes 7 member slots — truncates larger parties
- **Plugin:** EthernovaParty
- **File:** `PartyGui.java`
- **Method:** `populateItems()`
- **Severity:** 🟡 MEDIUM
- **Category:** GUI Bug

**Description:**  
```java
int[] memberSlots = {19, 20, 21, 22, 23, 24, 25};
```

The GUI only allocates 7 slots for member heads. The config allows `party.max-size` to be set to any value (default 5, but configurable). If an admin sets `max-size` to 8+, the 8th and subsequent members will **not be displayed** in the GUI, and leaders cannot kick/promote them via the GUI.

**Suggested Fix:**  
Either cap `max-size` validation at 7 in the config loader, add a second row of member slots, or paginate the member display.

---

### BUG-19: Pending invites allow only one per player globally
- **Plugin:** EthernovaParty
- **File:** `PartyManager.java`
- **Method:** `invitePlayer()`
- **Severity:** 🟡 MEDIUM
- **Category:** Logic Error

**Description:**  
`pendingInvites` is a `Map<UUID, PartyInvite>` keyed by invited player UUID. This means a player can only have **one** pending invite at a time across ALL parties. If party A invites player X, and then party B also invites player X, the second invite is rejected with "already-invited" — even though it's from a completely different party.

The check:
```java
if (pendingInvites.containsKey(targetUuid)) {
    sendPrefixed(inviter, getMessage("already-invited"));
    return false;
}
```

This is confusing because the "already-invited" message suggests the inviter's party already invited them, when in reality a different party did.

**Suggested Fix:**  
Either change the map to `Map<UUID, List<PartyInvite>>` to support multiple concurrent invites, or show a distinct message: "That player already has a pending invite from another party."

---

### BUG-20: Cosmetic player data loading race on join
- **Plugin:** EthernovaCosmetics
- **Files:** `PlayerCosmeticManager.java`, `CosmeticListener.java`
- **Methods:** `loadPlayer()` (async), `onPlayerJoin()`
- **Severity:** 🟡 MEDIUM
- **Category:** Race Condition

**Description:**  
`loadPlayer()` runs SQL on an async thread via `runTaskAsynchronously()`. There is no loading state flag or CompletableFuture. If a player opens `/cosmetics` before the async load completes, they see an empty inventory (no owned cosmetics). Purchases could also conflict — the player might buy a cosmetic they already own because the ownership data hasn't loaded yet.

**Suggested Fix:**  
Add a `Set<UUID> loadingPlayers` flag and check it when opening GUIs:
```java
if (playerCosmeticManager.isLoading(uuid)) {
    player.sendMessage("Loading your cosmetics...");
    return;
}
```

---

## 🔵 LOW Bugs

### BUG-21: AdminGUIManager uses plain HashMap — inconsistent with rest of codebase
- **Plugin:** EthernovaCombat
- **File:** `AdminGUIManager.java`
- **Fields:** `openGUIs`, `worldContext`, `pageContext`
- **Severity:** 🔵 LOW
- **Category:** Thread Safety (Defensive)

**Description:**  
These three fields use plain `HashMap` while the rest of the codebase consistently uses `ConcurrentHashMap`. Since all GUI operations run on the main Bukkit thread, this is currently safe. However, the `openActiveCombats()` method schedules a `runTaskLater` that accesses `openGUIs` — still main thread, but inconsistent.

**Suggested Fix:**  
Replace with `ConcurrentHashMap` for defensive consistency.

---

### BUG-22: KillStreakManager uses deprecated PotionEffectType.getByName()
- **Plugin:** EthernovaCombat
- **File:** `KillStreakManager.java`
- **Method:** `checkMilestone()`
- **Severity:** 🔵 LOW
- **Category:** Deprecation

**Description:**  
`PotionEffectType.getByName(String)` is deprecated in the Bukkit API. The code should use `Registry.EFFECT.get(NamespacedKey.minecraft(name))` or `PotionEffectType.getByKey()` (as `StreakAbilityManager` already does correctly).

**Suggested Fix:**  
```java
PotionEffectType type = Registry.EFFECT.get(NamespacedKey.minecraft(effectName.toLowerCase()));
```

---

### BUG-23: AdminGUIManager active combats auto-refresh causes inventory flicker
- **Plugin:** EthernovaCombat
- **File:** `AdminGUIManager.java`
- **Method:** `openActiveCombats()`
- **Severity:** 🔵 LOW
- **Category:** UX / GUI Bug

**Description:**  
`openActiveCombats()` schedules a `runTaskLater` that calls `openActiveCombats()` again after 60 ticks (3 seconds), creating an infinite self-scheduling refresh loop. Each call creates a new `Inventory` and opens it, causing visible inventory **flicker/flash** every 3 seconds. The loop correctly stops when the player navigates away.

**Suggested Fix:**  
Instead of re-opening the inventory, update the existing inventory's contents in-place:
```java
Inventory existing = player.getOpenInventory().getTopInventory();
// Update items directly instead of player.openInventory(newInventory)
```

---

### BUG-24: CombatVisualManager.sendKillFeed iterates all world players
- **Plugin:** EthernovaCombat
- **File:** `CombatVisualManager.java`
- **Method:** `sendKillFeed()`
- **Severity:** 🔵 LOW
- **Category:** Performance

**Description:**  
`sendKillFeed()` calls `killer.getWorld().getPlayers()` to broadcast the kill feed message, then applies a radius check. For each kill it iterates **all players in the world** rather than using a spatial query. On busy servers with many players in one world, this is inefficient.

**Suggested Fix:**  
Use Paper's optimized spatial lookup:
```java
killer.getLocation().getNearbyPlayers(radius)
```

---

### BUG-25: WinEffectHandler delayed effects may target disconnected players
- **Plugin:** EthernovaCosmetics
- **File:** `WinEffectHandler.java`
- **Method:** `triggerWinEffect()`
- **Severity:** 🔵 LOW
- **Category:** Null Pointer Risk

**Description:**  
`triggerWinEffect()` schedules multiple delayed tasks (fireworks, lightning, particle effects) over several seconds. If the player disconnects between the trigger and a delayed task execution, `Bukkit.getPlayer(uuid)` returns `null`. Delayed lambdas that don't check for null may throw `NullPointerException`.

**Suggested Fix:**  
Add null/online check at the beginning of each delayed lambda:
```java
Bukkit.getScheduler().runTaskLater(plugin, () -> {
    Player p = Bukkit.getPlayer(uuid);
    if (p == null || !p.isOnline()) return;
    // ... proceed with effects
}, delay);
```

---

## Bug Distribution by Plugin

| Plugin | CRITICAL | HIGH | MEDIUM | LOW | Total |
|--------|----------|------|--------|-----|-------|
| EthernovaCombat | 4 | 4 | 4 | 4 | **16** |
| EthernovaCosmetics | 0 | 1 | 1 | 1 | **3** |
| EthernovaParty | 0 | 1 | 5 | 0 | **6** |

## Bug Distribution by Category

| Category | Count |
|----------|-------|
| Logic Error / Inter-system connectivity | 6 |
| Thread Safety | 5 |
| Memory Leak / Incomplete Cleanup | 3 |
| Data Integrity / Persistence | 2 |
| Security / Input Validation | 1 |
| GUI Bug | 2 |
| Deprecation / Compatibility | 2 |
| Dead Code / Duplicate Logic | 1 |
| Performance | 1 |
| Race Condition | 1 |
| Null Pointer Risk | 1 |

---

## Priority Fix Order

1. **BUG-01 through BUG-04** (CRITICAL) — Integrate the 4 dead systems: DeathRecap, Bounty claim, Combo, StreakAbility. These represent significant features that were built but never wired in.
2. **BUG-05** — Persist bounties so player money isn't lost on restart.
3. **BUG-08** — Fix MiniMessage injection in party chat (security).
4. **BUG-07** — Add missing cleanup on disconnect to prevent memory leaks.
5. **BUG-09** — Clean up combat tags when NPC dies/despawns.
6. **BUG-10** — Make cosmetic purchase atomic.
7. **BUG-06** — Replace ArrayDeque with thread-safe Deque.
8. Remaining MEDIUM/LOW bugs in order of impact.
