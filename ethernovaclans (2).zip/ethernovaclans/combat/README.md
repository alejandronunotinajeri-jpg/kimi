# EthernovaCombat

> Sistema de combate avanzado para el ecosistema Ethernova.

## Características

- **Combat Tag** — Marca de combate con duración configurable y perfiles por mundo
- **Kill Streaks** — Rachas de kills con recompensas y habilidades
- **Combat NPCs** — NPC que aparece al desconectarse en combate
- **Bounties** — Sistema de recompensas por cabezas
- **Death Recap** — Resumen detallado de muerte
- **Anti-Abuse** — Detección de KDR farming y combate repetitivo
- **Newbie Protection** — Protección temporal para jugadores nuevos
- **Loot Protection** — Protección de drops al morir
- **Safe Logout** — Desconexión segura con temporizador
- **Combo System** — Conteo de combos con efectos
- **Streak Abilities** — Habilidades desbloqueables por racha
- **Visual Effects** — Indicadores visuales de combate
- **Module System** — Módulos extensibles vía API

## API

```java
CombatAPI api = ServiceRegistry.get(CombatAPI.class);
api.isInCombat(uuid);
api.tag(player1, player2, "default");
api.getKillStreak(uuid);
api.isNewbieProtected(uuid);
```

## Comandos

| Comando | Permiso | Descripción |
|---------|---------|-------------|
| `/combat` | `combat.use` | Estado de combate |
| `/combatadmin` | `combat.admin` | Panel de administración |
| `/logout` | `combat.logout` | Desconexión segura |
| `/bounty` | `combat.bounty` | Sistema de bounties |

## Placeholders

| Placeholder | Descripción |
|-------------|-------------|
| `%combat_tagged%` | En combate (sí/no) |
| `%combat_time%` | Tiempo restante de tag |
| `%combat_killstreak%` | Racha actual |
| `%combat_kills%` | Kills totales |
