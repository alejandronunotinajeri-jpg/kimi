# EthernovaCombat — Complete Technical Documentation

> **Plugin:** EthernovaCombat v1.0.0  
> **API Version:** Paper 1.21  
> **Main Class:** `com.ethernova.combat.EthernovaCombat`  
> **Dependencies:** EthernovaCore (hard), Vault (soft), PlaceholderAPI (soft)  
> **Package Root:** `com.ethernova.combat`  
> **Total Source Files:** 40 Java files across 24 packages  

---

## Table of Contents

1. [Architecture Overview](#1-architecture-overview)
2. [Plugin Lifecycle — EthernovaCombat](#2-plugin-lifecycle--ethernovacombat)
3. [Combat Tag System (End-to-End)](#3-combat-tag-system-end-to-end)
4. [Tag Package](#4-tag-package)
5. [Config Package](#5-config-package)
6. [Message Package](#6-message-package)
7. [Command Package](#7-command-package)
8. [Listener Package](#8-listener-package)
9. [Cheat Prevention Package](#9-cheat-prevention-package)
10. [NPC Package](#10-npc-package)
11. [Penalty Package](#11-penalty-package)
12. [Kill Streak Package](#12-kill-streak-package)
13. [Reward Package](#13-reward-package)
14. [Revenge Package](#14-revenge-package)
15. [Newbie Protection Package](#15-newbie-protection-package)
16. [Abuse Package (Legacy)](#16-abuse-package-legacy)
17. [Detection Package (Enhanced)](#17-detection-package-enhanced)
18. [Loot Protection Package](#18-loot-protection-package)
19. [Death Effects Package](#19-death-effects-package)
20. [Visual Package](#20-visual-package)
21. [Profile Package](#21-profile-package)
22. [Module Package](#22-module-package)
23. [World Configuration Package](#23-world-configuration-package)
24. [GUI Package (Admin GUI System)](#24-gui-package-admin-gui-system)
25. [Safe Logout Package](#25-safe-logout-package)
26. [Clan Integration](#26-clan-integration)
27. [Commands & Permissions Reference](#27-commands--permissions-reference)
28. [Configuration Reference](#28-configuration-reference)
29. [Resource Files Reference](#29-resource-files-reference)
30. [Maven Dependencies](#30-maven-dependencies)
31. [Flow Diagrams](#31-flow-diagrams)

---

## 1. Architecture Overview

EthernovaCombat is a modular combat tagging plugin for the Ethernova ecosystem. It runs on Paper 1.21+ and depends on EthernovaCore for shared services (EventBus, economy hooks, visual manager, MiniMessage, profiles, context manager).

### High-Level Architecture

```
EthernovaCombat (JavaPlugin)
├── Config Layer         → CombatConfigManager (config.yml, killstreaks.yml, rewards.yml, profiles.yml)
├── Message Layer        → CombatMessageManager (messages_XX.yml, MiniMessage formatting)
├── Core Tag System      → CombatTagManager ←→ CombatTag, CombatTagEvent, CombatAPI
├── Listeners (8)        → Damage, Death, Disconnect, Cheat, Move, Item, NPC, ClanIntegration
├── Sub-Systems (15)
│   ├── CheatPreventionManager   (flight, commands, pearl, chorus, elytra, gamemode, riptide)
│   ├── CombatNPCManager         (villager NPCs for combat loggers)
│   ├── PenaltyManager           (money/power loss on combat log)
│   ├── KillStreakManager         (streak tracking, milestone rewards)
│   ├── RewardManager            (kill rewards: money, XP)
│   ├── RevengeManager           (revenge kill bonus)
│   ├── NewbieProtectionManager  (PvP immunity for new players)
│   ├── KDRAbuseManager          (legacy: same-IP, repeat-kill detection)
│   ├── DetectionManager         (enhanced: multi-account, kill farm, location farm, low gear)
│   ├── SanctionManager          (3-tier automated punishment)
│   ├── LootProtectionManager    (death loot protection for killer)
│   ├── DeathEffectManager       (particles, sounds, lightning on death)
│   ├── CombatVisualManager      (hit FX, combat flash, compass, heartbeat, kill feed)
│   ├── CombatProfileManager     (context-based profiles: survival/war/arena/ffa)
│   └── SafeLogoutManager        (/logout countdown)
├── World System         → WorldConfigManager + WorldCombatConfig (per-world overrides)
├── Module System        → CombatModuleRegistry + CombatModule interface + ModuleSetting
└── Admin GUI System     → AdminGUIManager (13 screens) + AdminGUIListener + GUIHelper
```

### EthernovaCore Integration Points

| Core Service | Usage |
|---|---|
| `core.getEventBus()` | Publish `EthernovaPlayerKillEvent`, `PowerChangeEvent`; subscribe to `ClanWarStartEvent`, `ClanWarEndEvent` |
| `core.getEconomyHook()` | Vault economy: deposit, withdraw, getBalance |
| `core.getVisualManager()` | BossBar create/show/hide/remove, ActionBar, Title, Lightning |
| `core.getMessageManager().getMiniMessage()` | MiniMessage deserialization for Adventure components |
| `core.getProfileManager()` | Player profile: getKills/setKills, getDeaths/setDeaths, addKill, addDeath |
| `core.getContextManager()` | Detect player context (war, arena, ffa) for profile auto-detection |
| `core.registerPlugin()` / `core.unregisterPlugin()` | Ecosystem plugin registration |

---

## 2. Plugin Lifecycle — EthernovaCombat

**Class:** `EthernovaCombat extends JavaPlugin`  
**Lines:** ~160  

### Fields

| Field | Type | Description |
|---|---|---|
| `instance` | `static EthernovaCombat` | Singleton instance |
| `core` | `EthernovaCore` | Reference to core plugin |
| `configManager` | `CombatConfigManager` | Multi-file config loader |
| `messageManager` | `CombatMessageManager` | i18n message system |
| `tagManager` | `CombatTagManager` | Core combat tag engine |
| `killStreakManager` | `KillStreakManager` | Kill streak tracking |
| `npcManager` | `CombatNPCManager` | Combat log NPC spawning |
| `rewardManager` | `RewardManager` | Kill reward distribution |
| `penaltyManager` | `PenaltyManager` | Combat log penalties |
| `newbieManager` | `NewbieProtectionManager` | New player PvP immunity |
| `abuseManager` | `KDRAbuseManager` | Legacy anti-abuse |
| `logoutManager` | `SafeLogoutManager` | /logout countdown |
| `lootManager` | `LootProtectionManager` | Death loot protection |
| `cheatManager` | `CheatPreventionManager` | In-combat restrictions |
| `deathEffectManager` | `DeathEffectManager` | Death visual/audio FX |
| `profileManager` | `CombatProfileManager` | Profile context detection |
| `visualManager` | `CombatVisualManager` | Combat visual effects |
| `api` | `CombatAPI` | Public API facade |
| `worldConfigManager` | `WorldConfigManager` | Per-world combat config |
| `moduleRegistry` | `CombatModuleRegistry` | Ecosystem module registry |
| `detectionManager` | `DetectionManager` | Enhanced abuse detection |
| `guiManager` | `AdminGUIManager` | Admin GUI system |
| `revengeManager` | `RevengeManager` | Revenge kill tracking |

### onEnable() Initialization Order

1. Resolve `EthernovaCore` dependency → `core.registerPlugin("EthernovaCombat")`
2. Load configs → `CombatConfigManager.loadAll()`
3. Initialize message manager → `CombatMessageManager`
4. Create all 21 managers in dependency order
5. Create `CombatAPI`
6. Register 8 Bukkit listeners
7. Register 3 commands (`/combat`, `/combatadmin`, `/logout`)
8. Subscribe to EventBus events via `ClanIntegrationListener`

### onDisable() Shutdown Order

1. Cancel all Bukkit tasks
2. Save world configs
3. Shutdown tag manager (cancel tick task, untag all)
4. Shutdown visual manager (cancel compass/particle tasks)
5. Cancel all pending logouts
6. Remove all combat NPCs
7. Unregister from core

### Getters

All 21 managers have public getter methods (e.g., `getTagManager()`, `getCore()`, `getInstance()`).

---

## 3. Combat Tag System (End-to-End)

### Flow: Player A hits Player B

```
1. EntityDamageByEntityEvent fired
   └─→ CombatDamageListener.onDamage()
       ├── Resolve attacker (direct, projectile, tameable)
       ├── Check per-world combat tag enabled (WorldConfigManager)
       ├── Check newbie protection for BOTH players
       │   ├── Victim protected → cancel event, notify attacker
       │   └── Attacker protected + lose-on-attack → remove protection
       ├── Determine profile (CombatProfileManager)
       ├── Tag BOTH players (bidirectional):
       │   └─→ CombatTagManager.tag(player, enemy, profile)
       │       ├── Check bypass permission: ethernova.combat.bypass.tag
       │       ├── Fire CombatTagEvent (cancellable Bukkit event)
       │       ├── If existing tag: extend duration (if config enabled)
       │       ├── If new tag: create CombatTag, create BossBar, send message
       │       └── Show combat entry flash (CombatVisualManager)
       ├── Show hit effect particle
       └── Cancel pending safe logouts for both players

2. Every 1 second (tick task in CombatTagManager):
   ├── Decrement all tag timers
   ├── Remove expired tags → send "untagged" message
   ├── Update BossBar (progress, color transitions: green→yellow→red)
   ├── Update ActionBar with time remaining
   └── Cleanup offline players

3. CombatVisualManager (every 0.5 seconds):
   ├── Spawn red dust particles above tagged players
   ├── Heartbeat bass sound at ≤6 HP (faster at ≤3 HP)
   └── Update compass to point at enemy (every 1 second)

4. On death (CombatDeathListener):
   ├── Untag victim, reset killstreak
   ├── Run abuse/detection checks
   ├── If clean kill: increment stats, add streak, check milestone
   │   ├── Process kill reward (money + XP)
   │   ├── Apply death effects (particle, sound, lightning)
   │   ├── Send kill feed
   │   ├── Process revenge check
   │   └── Record kill for revenge tracking
   ├── Untag killer
   ├── Protect loot for killer
   └── Publish EthernovaPlayerKillEvent to EventBus

5. On disconnect while tagged (CombatDisconnectListener):
   ├── Untag player
   ├── Spawn combat NPC (if enabled)
   ├── Clear player inventory (moved to NPC)
   ├── Apply combat log penalty (money + power loss)
   └── Broadcast combat log death message
```

---

## 4. Tag Package

### `CombatTag`

**Package:** `com.ethernova.combat.tag`  
**Lines:** ~40  
**Description:** Data class representing an active combat tag on a single player. Thread-safe via `volatile` fields and `AtomicInteger`.

#### Fields

| Field | Type | Description |
|---|---|---|
| `player` | `UUID` (final) | The tagged player's UUID |
| `enemy` | `volatile UUID` | Current enemy UUID (updated on re-tag) |
| `remainingSeconds` | `AtomicInteger` | Countdown timer (decremented each tick) |
| `maxDuration` | `volatile int` | Maximum duration (for BossBar progress calc) |
| `profile` | `volatile String` | Active combat profile (survival/war/arena/ffa) |

#### Methods

| Method | Description |
|---|---|
| `tick()` | Decrements `remainingSeconds` by 1 |
| `isExpired()` | Returns `true` if remaining ≤ 0 |
| `extend(int seconds, int max)` | Extends timer up to `max`, updates `maxDuration` |
| `getPlayer()` / `getEnemy()` / `setEnemy()` | Player/enemy UUID accessors |
| `getRemainingSeconds()` | Returns remaining (floored at 0) |
| `getMaxDuration()` | Returns max duration for progress bar calculation |
| `getProfile()` / `setProfile()` | Combat profile accessors |

---

### `CombatTagManager`

**Package:** `com.ethernova.combat.tag`  
**Lines:** ~145  
**Description:** Central manager for all active combat tags. Maintains a `ConcurrentHashMap<UUID, CombatTag>`, runs a 1-second tick task, manages BossBar/ActionBar updates.

#### Fields

| Field | Type | Description |
|---|---|---|
| `plugin` | `EthernovaCombat` | Plugin reference |
| `core` | `EthernovaCore` | Core reference |
| `tags` | `ConcurrentHashMap<UUID, CombatTag>` | All active combat tags |
| `tickTask` | `BukkitTask` | 1-second repeating timer |

#### Methods

| Method | Signature | Description |
|---|---|---|
| `tag` | `boolean tag(Player, Player, String)` | Tag a player. Fires `CombatTagEvent`. Returns false if cancelled or bypassed. Creates BossBar, sends message, shows entry flash. If already tagged and `extend-on-hit` is true, extends duration. |
| `untag` | `void untag(Player)` / `void untag(UUID)` | Remove tag, hide BossBar, send "untagged" message |
| `untagAll` | `void untagAll()` | Untag all players (used on shutdown/reload) |
| `isInCombat` | `boolean isInCombat(Player)` / `boolean isInCombat(UUID)` | Check if player is tagged (auto-cleans expired) |
| `getRemainingSeconds` | `int getRemainingSeconds(UUID)` | Get remaining tag seconds |
| `getEnemy` | `UUID getEnemy(UUID)` | Get the enemy UUID for a tagged player |
| `getProfile` | `String getProfile(UUID)` | Get combat profile (default: "survival") |
| `getTaggedCount` | `int getTaggedCount()` | Number of actively tagged players |
| `getActiveTags` | `Map<UUID, CombatTag> getActiveTags()` | Unmodifiable copy of all tags |
| `shutdown` | `void shutdown()` | Cancel tick task, untag all |

#### Tick Task Logic (every 20 ticks / 1 second)

1. Iterate all tags
2. Call `tag.tick()` to decrement
3. If expired → `untag(uuid)`
4. If player offline → cleanup
5. Update BossBar:
   - Set progress = remaining / maxDuration
   - Color: ≤25% → RED, ≤50% → YELLOW, else unchanged
   - Update name with time and enemy name
6. Send ActionBar (if enabled)

---

### `CombatTagEvent`

**Package:** `com.ethernova.combat.tag`  
**Lines:** ~42  
**Extends:** `Event`  
**Implements:** `Cancellable`  
**Description:** Cancellable Bukkit event fired before a combat tag is applied. Other plugins can listen to this to prevent tagging or modify the duration.

#### Fields/Accessors

| Field | Type | Mutable | Description |
|---|---|---|---|
| `player` | `Player` | No | The player about to be tagged |
| `enemy` | `Player` | No | The attacker |
| `duration` | `int` | Yes | Tag duration in seconds |
| `profile` | `String` | No | Combat profile |
| `cancelled` | `boolean` | Yes | Cancel the tag |

---

### `CombatAPI`

**Package:** `com.ethernova.combat.tag`  
**Lines:** ~36  
**Description:** Public API facade for external plugins to interact with the combat system.

#### Methods

| Method | Description |
|---|---|
| `isInCombat(Player)` / `isInCombat(UUID)` | Check combat status |
| `tag(Player, Player, String)` | Tag BOTH players with given profile |
| `untag(Player)` | Remove a player's combat tag |
| `getRemainingSeconds(UUID)` | Get remaining tag seconds |
| `getKillStreak(UUID)` | Get current kill streak |
| `isNewbieProtected(UUID)` | Check newbie protection status |
| `registerModule(CombatModule)` | Register an ecosystem module |
| `unregisterModule(String)` | Unregister a module by ID |
| `getModuleRegistry()` | Get the module registry |

---

## 5. Config Package

### `CombatConfigManager`

**Package:** `com.ethernova.combat.config`  
**Lines:** ~57  
**Description:** Loads and manages multiple YAML configuration files.

#### Fields

| Field | Type | Description |
|---|---|---|
| `plugin` | `JavaPlugin` | Plugin reference |
| `config` | `FileConfiguration` | Main config.yml |
| `killStreaksConfig` | `YamlConfiguration` | killstreaks.yml |
| `rewardsConfig` | `YamlConfiguration` | rewards.yml |
| `profilesConfig` | `YamlConfiguration` | profiles.yml |

#### Methods

| Method | Description |
|---|---|
| `loadAll()` | Save defaults + load all 4 config files |
| `reload()` | Re-load all configs |
| `getConfig()` | Returns main config |
| `getKillStreaksConfig()` | Returns killstreaks config |
| `getRewardsConfig()` | Returns rewards config |
| `getProfilesConfig()` | Returns profiles config |
| `getString(path, def)` | Convenience accessor for main config |
| `getInt(path, def)` | Convenience accessor for main config |
| `getDouble(path, def)` | Convenience accessor for main config |
| `getBoolean(path, def)` | Convenience accessor for main config |
| `getLong(path, def)` | Convenience accessor for main config |

---

## 6. Message Package

### `CombatMessageManager`

**Package:** `com.ethernova.combat.message`  
**Lines:** ~65  
**Description:** Internationalized message system. Loads `messages_XX.yml` based on `general.language` config. Uses MiniMessage format.

#### Fields

| Field | Type | Description |
|---|---|---|
| `plugin` | `EthernovaCombat` | Plugin reference |
| `mini` | `MiniMessage` | MiniMessage instance for deserialization |
| `messages` | `YamlConfiguration` | Loaded message file |
| `prefix` | `String` | Cached prefix string |

#### Methods

| Method | Description |
|---|---|
| `load()` | Load `messages_{lang}.yml`, fallback to `messages_es.yml` |
| `get(path, replacements...)` | Get raw MiniMessage string with placeholder replacements |
| `send(CommandSender, path, replacements...)` | Deserialize and send a message |
| `sendRaw(CommandSender, miniMsg)` | Send a raw MiniMessage string |
| `getRaw(path, replacements...)` | Alias for `get()` |

#### Supported Languages

- Spanish (`messages_es.yml`) — default/fallback
- English (`messages_en.yml`)

---

## 7. Command Package

### `CombatCommand`

**Package:** `com.ethernova.combat.command`  
**Lines:** ~40  
**Implements:** `CommandExecutor`, `TabCompleter`  
**Command:** `/combat`

#### Subcommands

| Subcommand | Description |
|---|---|
| `/combat` or `/combat status` | Shows combat status: in combat (yes/no + remaining time), current kill streak |
| `/combat newbie` | Toggle newbie protection off (cannot re-enable) |

#### Tab Completions

`status`, `newbie`

---

### `CombatAdminCommand`

**Package:** `com.ethernova.combat.command`  
**Lines:** ~70  
**Implements:** `CommandExecutor`, `TabCompleter`  
**Command:** `/combatadmin`  
**Permission:** `ethernova.combat.admin`

#### Subcommands

| Subcommand | Arguments | Description |
|---|---|---|
| `/combatadmin` (no args) | — | Opens Admin GUI (if player) or shows usage (if console) |
| `/combatadmin gui` | — | Opens Admin GUI (player only) |
| `/combatadmin reload` | — | Reloads config + messages |
| `/combatadmin tag` | `<player1> <player2>` | Force-tag two players (bidirectional, "default" profile) |
| `/combatadmin untag` | `<player>` | Remove a player's combat tag |

#### Tab Completions

Arg 1: `reload`, `tag`, `untag`, `gui`  
Arg 2+: Online player names (Bukkit default)

---

### `LogoutCommand`

**Package:** `com.ethernova.combat.command`  
**Lines:** ~17  
**Implements:** `CommandExecutor`  
**Command:** `/logout`

| Behavior | Description |
|---|---|
| Player executes `/logout` | Starts safe logout countdown via `SafeLogoutManager.startLogout()` |

---

## 8. Listener Package

### `CombatDamageListener`

**Lines:** ~55  
**Events:** `EntityDamageByEntityEvent` (HIGH), `EntityDamageEvent` (HIGH)

| Handler | Description |
|---|---|
| `onDamage(EntityDamageByEntityEvent)` | Resolves attacker from Player/Projectile/Tameable. Checks per-world combat tag enabled. Handles newbie protection (cancel if victim protected; remove if attacker attacks). Tags both players bidirectionally. Shows hit effect. Cancels pending logouts for both. |
| `onAnyDamage(EntityDamageEvent)` | For non-entity damage (fire, fall, etc.), cancels pending safe logouts. |

**Attacker Resolution:**
- Direct `Player` → return player
- `Projectile` with `Player` shooter → return shooter
- `Tameable` with `Player` owner → return owner

---

### `CombatDeathListener`

**Lines:** ~75  
**Events:** `PlayerDeathEvent` (HIGH), `EntityResurrectEvent` (HIGH)

| Handler | Description |
|---|---|
| `onDeath(PlayerDeathEvent)` | Full death processing pipeline: untag victim, reset streak, run abuse detection (enhanced then legacy fallback), process rewards/penalties/effects/kill-feed/revenge, untag killer, protect loot, publish EventBus event |
| `onTotem(EntityResurrectEvent)` | When a combat-tagged player uses a totem, re-tags them to maintain combat state |

---

### `CombatDisconnectListener`

**Lines:** ~65  
**Events:** `PlayerQuitEvent` (HIGH), `PlayerJoinEvent` (HIGH)

| Handler | Description |
|---|---|
| `onQuit(PlayerQuitEvent)` | Cancel pending logout. If in combat: untag → spawn NPC → clear inventory → apply penalty → broadcast. Cleanup: profile, streak, rewards, abuse, newbie, detection. |
| `onJoin(PlayerJoinEvent)` | Detection login tracking. Newbie check. Profile detection. NPC reconnect (if NPC was killed → kill player; if NPC survived → restore inventory). |

---

### `CombatCheatListener`

**Lines:** ~85  
**Events:** `PlayerCommandPreprocessEvent` (HIGHEST), `PlayerToggleFlightEvent` (HIGHEST), `PlayerTeleportEvent` (HIGHEST), `PlayerGameModeChangeEvent` (HIGHEST), `PlayerRiptideEvent` (HIGHEST)

| Handler | Blocks | Condition |
|---|---|---|
| `onCommand` | Commands in blocked list | In combat + commands blocked + no bypass. Per-world list falls back to global list. Strips namespace prefixes. |
| `onFlight` | Flight toggle | In combat + per-world or global flight block + no bypass |
| `onTeleport` | Ender pearl, Chorus fruit, Command teleport | In combat + respective block enabled + no bypass |
| `onGameMode` | Gamemode changes | In combat + gamemode block + no bypass |
| `onRiptide` | Riptide trident | In combat + riptide block + no bypass. Teleports player back after 5 ticks. |

---

### `CombatMoveListener`

**Lines:** ~22  
**Events:** `EntityToggleGlideEvent` (HIGHEST)

| Handler | Description |
|---|---|
| `onGlide` | Cancels elytra gliding for combat-tagged players (if `block-elytra` is enabled and no bypass) |

---

### `CombatItemListener`

**Lines:** ~40  
**Events:** `EntityPickupItemEvent` (HIGH)

| Handler | Description |
|---|---|
| `onPickupItem` | Prevents non-killer players from picking up protected loot. Has a 3-second cooldown on the "protected" message per player. |

---

### `CombatNPCListener`

**Lines:** ~27  
**Events:** `EntityDeathEvent` (HIGH)

| Handler | Description |
|---|---|
| `onNPCDeath` | When a combat NPC entity dies: clears drops/XP from vanilla event, resolves owner UUID, calls `CombatNPCManager.onNPCKilled()` |

---

### `ClanIntegrationListener`

**Lines:** ~50  
**Description:** Subscribes to EthernovaCore EventBus events for clan system integration. Not a Bukkit listener — uses EventBus subscriptions.

| Event Subscription | Action |
|---|---|
| `ClanWarStartEvent` | Logs war start (debug mode) |
| `ClanWarEndEvent` | Logs war end (debug mode) |
| `PenaltyManager.CombatLogPenaltyEvent` | Publishes `PowerChangeEvent` to EventBus so Clans module can deduct power |

---

## 9. Cheat Prevention Package

### `CheatPreventionManager`

**Package:** `com.ethernova.combat.cheat`  
**Lines:** ~45  
**Description:** Config-driven query interface for combat restrictions. Each method reads from `config.yml` and returns the current boolean state. Used by `CombatCheatListener`.

#### Methods

| Method | Config Key | Default |
|---|---|---|
| `blockFlight()` | `combat-tag.block-flight` | `true` |
| `blockCommands()` | `combat-tag.block-commands` | `true` |
| `blockEnderPearl()` | `combat-tag.block-enderpearl` | `true` |
| `blockChorusFruit()` | `combat-tag.block-chorus` | `true` |
| `blockTeleport()` | `combat-tag.block-teleport` | `true` |
| `blockElytra()` | `combat-tag.block-elytra` | `true` |
| `blockGamemodeChange()` | `combat-tag.block-gamemode` | `true` |
| `blockRiptide()` | `combat-tag.block-riptide` | `true` |
| `getBlockedCommands()` | `combat-tag.blocked-commands` | List: home, spawn, tpa, tp, warp, back |

---

## 10. NPC Package

### `CombatNPC`

**Package:** `com.ethernova.combat.npc`  
**Lines:** ~32  
**Description:** Data class for a combat NPC entity.

#### Fields

| Field | Type | Description |
|---|---|---|
| `playerUuid` | `UUID` (final) | Owner player's UUID |
| `entityUuid` | `UUID` (final) | The Villager entity UUID |
| `duration` | `int` (final) | NPC lifetime in seconds |
| `killed` | `volatile boolean` | Whether the NPC was killed |
| `inventory` | `ItemStack[]` (final) | Snapshot of player inventory |
| `armor` | `ItemStack[]` (final) | Snapshot of player armor |

---

### `CombatNPCManager`

**Package:** `com.ethernova.combat.npc`  
**Lines:** ~110  
**Description:** Manages combat log NPCs. When a player disconnects during combat, a Villager NPC is spawned at their location with their equipment. If killed, items drop. If the player reconnects, they either die (NPC was killed) or get inventory back (NPC survived).

#### Fields

| Field | Type | Description |
|---|---|---|
| `plugin` | `EthernovaCombat` | Plugin reference |
| `core` | `EthernovaCore` | Core reference |
| `npcs` | `ConcurrentHashMap<UUID, CombatNPC>` | Player UUID → NPC data |
| `entityToOwner` | `ConcurrentHashMap<UUID, UUID>` | Entity UUID → Owner UUID (reverse map for O(1) lookup) |

#### Methods

| Method | Description |
|---|---|
| `spawnNPC(Player)` | Spawns a Villager at player location. Sets AI=false, custom name `"<red>{player} [NPC]</red>"`, copies health. Schedules auto-despawn after `combat-npc.duration` seconds. |
| `onNPCKilled(UUID ownerUuid, Player killer)` | Marks NPC as killed. If `drop-items` enabled: drops all inventory/armor at NPC location. Protects dropped loot for the killer. Removes entity. |
| `isCombatNPC(Entity)` | Returns true if entity is a tracked combat NPC |
| `getOwnerFromNPC(Entity)` | Returns the owner UUID for a combat NPC entity |
| `handleReconnect(UUID)` | Called on player join. Returns the NPC data (killed/survived). Removes entity and clears tracking. |
| `removeAll()` | Removes all NPC entities and clears maps (onDisable) |

#### NPC Entity Properties

- **Type:** Villager (Profession.NONE)
- **AI:** Disabled
- **Custom Name:** Visible, formatted as `<red>{player} [NPC]</red>`
- **Invulnerable:** false (can be killed)
- **Silent:** true

---

## 11. Penalty Package

### `PenaltyManager`

**Package:** `com.ethernova.combat.penalty`  
**Lines:** ~42  
**Description:** Applies penalties when a player combat logs (disconnects during combat).

#### Methods

| Method | Description |
|---|---|
| `applyCombatLogPenalty(UUID, String)` | Withdraws money (offline), publishes power loss event, broadcasts message, executes configured commands |

#### Penalty Actions

| Action | Config Key | Default |
|---|---|---|
| Money withdrawal | `combat-log.penalty.money-loss` | 500 |
| Power loss event | `combat-log.penalty.power-loss` | 20 |
| Broadcast | `combat-log.penalty.broadcast` | true |
| Console commands | `combat-log.penalty.commands` | [] |

#### Inner Record: `CombatLogPenaltyEvent`

```java
public record CombatLogPenaltyEvent(UUID playerUuid, String playerName, int powerLoss) {}
```

Used by `ClanIntegrationListener` to publish `PowerChangeEvent` to the EventBus.

---

## 12. Kill Streak Package

### `KillStreakManager`

**Package:** `com.ethernova.combat.killstreak`  
**Lines:** ~110  
**Description:** Tracks consecutive kills per player. Checks for milestone thresholds defined in `killstreaks.yml` and applies rewards.

#### Fields

| Field | Type | Description |
|---|---|---|
| `plugin` | `EthernovaCombat` | Plugin reference |
| `core` | `EthernovaCore` | Core reference |
| `streaks` | `ConcurrentHashMap<UUID, Integer>` | Player UUID → current streak count |

#### Methods

| Method | Description |
|---|---|
| `addKill(Player)` | Increments streak counter, sends streak message |
| `checkMilestone(Player)` | Checks `killstreaks.yml` for a milestone matching current streak. If found: broadcast, play sound, show title, spawn lightning, grant rewards (money, commands, potion effects). |
| `onDeath(Player)` | Resets streak if `reset-on-death` is true. Sends "streak lost" message. |
| `getStreak(UUID)` / `getStreak(Player)` | Get current streak count |
| `resetStreak(UUID)` | Force-reset a player's streak |
| `cleanupPlayer(UUID)` | Remove tracking data |

#### Milestone Configuration (killstreaks.yml)

| Key | Type | Description |
|---|---|---|
| `streaks.<N>.broadcast` | boolean | Broadcast milestone to server |
| `streaks.<N>.broadcast-message` | String | MiniMessage format with `{player}`, `{streak}` |
| `streaks.<N>.sound` | String | Sound name (e.g., `ENTITY_PLAYER_LEVELUP`) |
| `streaks.<N>.title.title` | String | Title text |
| `streaks.<N>.title.subtitle` | String | Subtitle text |
| `streaks.<N>.lightning-on-kill` | boolean | Strike lightning at killer location |
| `streaks.<N>.rewards.money` | double | Money reward |
| `streaks.<N>.rewards.commands` | List<String> | Console commands (`{player}`, `{streak}`) |
| `streaks.<N>.rewards.effects` | List<Map> | Potion effects: `{type, duration, amplifier}` |

#### Default Milestones

| Streak | Broadcast | Sound | Rewards |
|---|---|---|---|
| **5** | `🔥 {player} lleva 5 kills seguidos!` | `ENTITY_PLAYER_LEVELUP` | $500, Speed I (10s) |
| **10** | `🔥🔥 {player} lleva 10 kills!` | `ENTITY_ENDER_DRAGON_GROWL` | $2000, Speed II (20s), Strength I (10s), Title |
| **25** | `☠ {player} lleva 25 kills! ¡LEYENDA!` | `ENTITY_WITHER_SPAWN` | $10000, Speed III (30s), Strength II (20s), Title, Lightning |

---

## 13. Reward Package

### `RewardManager`

**Package:** `com.ethernova.combat.reward`  
**Lines:** ~85  
**Description:** Processes kill rewards and death penalties based on `rewards.yml` configuration.

#### Fields

| Field | Type | Description |
|---|---|---|
| `plugin` | `EthernovaCombat` | Plugin reference |
| `lastKilled` | `ConcurrentHashMap<UUID, UUID>` | Victim → Killer (for revenge bonus in rewards) |

#### Methods

| Method | Description |
|---|---|
| `processKillReward(Player killer, Player victim)` | Calculates and grants money reward based on mode (FIXED/RANDOM/PERCENTAGE). Applies revenge bonus multiplier if killer was previously killed by victim. Grants XP. |
| `processDeathPenalty(Player victim)` | Applies death penalties: money (FIXED/PERCENTAGE mode) and XP level loss |
| `cleanupPlayer(UUID)` | Removes tracking data |

#### Kill Reward Modes

| Mode | Description |
|---|---|
| `FIXED` | Uses `min` value |
| `RANDOM` | Random between `min` and `max` |
| `PERCENTAGE` | X% of victim's balance, capped at `percentage-cap` |

#### Configuration (rewards.yml)

| Key | Default | Description |
|---|---|---|
| `kill-reward.money.enabled` | `true` | Enable money rewards |
| `kill-reward.money.mode` | `RANDOM` | FIXED / RANDOM / PERCENTAGE |
| `kill-reward.money.min` | `50.0` | Minimum (or fixed) amount |
| `kill-reward.money.max` | `200.0` | Maximum (random mode) |
| `kill-reward.money.percentage` | `5.0` | % of victim balance |
| `kill-reward.money.percentage-cap` | `10000.0` | Max for percentage mode |
| `kill-reward.xp.enabled` | `true` | Enable XP rewards |
| `kill-reward.xp.amount` | `50` | XP amount |
| `death-penalty.money.enabled` | `false` | Enable death money penalty |
| `death-penalty.money.mode` | `FIXED` | FIXED / PERCENTAGE |
| `death-penalty.money.amount` | `100.0` | Fixed penalty amount |
| `death-penalty.money.percentage` | `2.0` | % of victim balance |
| `death-penalty.xp.enabled` | `false` | Enable XP level loss |
| `death-penalty.xp.levels` | `3` | Levels to deduct |
| `revenge-bonus.enabled` | `true` | Enable revenge multiplier |
| `revenge-bonus.money-multiplier` | `2.0` | Multiplier on revenge kills |
| `revenge-bonus.message` | MiniMessage | Revenge notification |

---

## 14. Revenge Package

### `RevengeManager`

**Package:** `com.ethernova.combat.revenge`  
**Lines:** ~65  
**Description:** Tracks who killed each player and grants a money bonus + sound when a player kills their last killer.

#### Fields

| Field | Type | Description |
|---|---|---|
| `plugin` | `EthernovaCombat` | Plugin reference |
| `lastKiller` | `ConcurrentHashMap<UUID, UUID>` | Victim UUID → Killer UUID |

#### Methods

| Method | Description |
|---|---|
| `recordKill(UUID killer, UUID victim)` | Records that killer killed victim (for future revenge detection) |
| `processRevenge(Player killer, Player victim)` | Checks if this kill avenges a previous death. If so: grants money bonus (`revenge.money-bonus`), sends message, plays `UI_TOAST_CHALLENGE_COMPLETE` sound. Returns true if revenge. |
| `clear(UUID)` | Clears tracking for a player |

#### Configuration

| Key | Default | Description |
|---|---|---|
| `revenge.enabled` | `true` | Enable revenge system |
| `revenge.money-bonus` | `100` | Money bonus for revenge kills |
| `revenge.message` | `true` | Send revenge notification |

---

## 15. Newbie Protection Package

### `NewbieProtectionManager`

**Package:** `com.ethernova.combat.newbie`  
**Lines:** ~55  
**Description:** Grants temporary PvP immunity to new players. Protection expires after a configurable duration or when the player attacks another player.

#### Fields

| Field | Type | Description |
|---|---|---|
| `plugin` | `EthernovaCombat` | Plugin reference |
| `protectedPlayers` | `ConcurrentHashMap<UUID, Long>` | Player UUID → expiry timestamp |

#### Methods

| Method | Description |
|---|---|
| `addProtection(UUID)` | Grants protection for `duration-minutes` from now |
| `isProtected(Player)` / `isProtected(UUID)` | Returns true if protection is active (auto-cleans expired entries) |
| `removeProtection(Player, boolean notify)` | Removes protection, optionally sends "lost" message |
| `removeProtection(UUID)` | Removes protection silently |
| `checkNewPlayer(Player)` | Called on join. If `!hasPlayedBefore()` and enabled, grants protection + sends message |
| `toggle(Player)` | If protected: remove protection. If not: send "cannot-enable" message |

#### Configuration

| Key | Default | Description |
|---|---|---|
| `newbie-protection.enabled` | `true` | Enable newbie protection |
| `newbie-protection.duration-minutes` | `120` | Protection duration in minutes |
| `newbie-protection.lose-on-attack` | `true` | Lose protection when attacking |

---

## 16. Abuse Package (Legacy)

### `KDRAbuseManager`

**Package:** `com.ethernova.combat.abuse`  
**Lines:** ~55  
**Description:** Legacy anti-abuse system. Checks for same-IP kills and repeat kills within a time window. Superseded by `DetectionManager` but kept as a fallback.

#### Fields

| Field | Type | Description |
|---|---|---|
| `plugin` | `EthernovaCombat` | Plugin reference |
| `recentKills` | `ConcurrentHashMap<UUID, List<KillRecord>>` | Killer UUID → recent kill records |

#### Inner Record

```java
private record KillRecord(UUID victim, long time) {}
```

#### Methods

| Method | Description |
|---|---|
| `isAbusiveKill(Player killer, Player victim)` | Returns `true` if: (1) same IP address, or (2) same victim killed more than `max-repeat-kills` times within `repeat-window-minutes`. Sends appropriate abuse message. |
| `cleanupPlayer(UUID)` | Removes tracking data for a player |

#### Configuration

| Key | Default | Description |
|---|---|---|
| `anti-abuse.enabled` | `true` | Enable legacy abuse detection |
| `anti-abuse.block-same-ip` | `true` | Block kills from same IP |
| `anti-abuse.max-repeat-kills` | `3` | Max kills on same victim |
| `anti-abuse.repeat-window-minutes` | `30` | Time window for repeat detection |

---

## 17. Detection Package (Enhanced)

### `AbuseRecord`

**Package:** `com.ethernova.combat.detection`  
**Lines:** ~18  
**Description:** Immutable record of a detected abuse violation.

```java
public record AbuseRecord(UUID player, String playerName, AbuseType type, String details, long timestamp) {
    public enum AbuseType {
        MULTI_ACCOUNT,    // Same IP killing own alt
        KILL_FARMING,     // Farming kills on same victim repeatedly
        LOCATION_FARM,    // Kills consistently at same location
        LOW_GEAR_FARM     // Killing unarmed/unarmored players repeatedly
    }
}
```

---

### `DetectionManager`

**Package:** `com.ethernova.combat.detection`  
**Lines:** ~155  
**Description:** Central coordinator for all abuse detection systems. Integrates `MultiAccountDetector`, `KillFarmDetector`, and `SanctionManager`. Called on every kill to determine if it's abusive.

#### Fields

| Field | Type | Description |
|---|---|---|
| `plugin` | `EthernovaCombat` | Plugin reference |
| `multiAccountDetector` | `MultiAccountDetector` | IP-based multi-account detection |
| `killFarmDetector` | `KillFarmDetector` | Kill farming pattern detection |
| `sanctionManager` | `SanctionManager` | Automated punishment system |
| `violationLog` | `List<AbuseRecord>` (synchronized) | History of all violations |
| `violationCounts` | `ConcurrentHashMap<UUID, Integer>` | Per-player offense count |
| `multiAccountEnabled` | `boolean` | Toggle for multi-account detection |
| `killFarmEnabled` | `boolean` | Toggle for kill farm detection |
| `alertChannel` | `String` | Alert channel: CHAT / DISCORD / BOTH |

#### Methods

| Method | Description |
|---|---|
| `onPlayerLogin(Player)` | Tracks IP for multi-account. Checks for simultaneous accounts above threshold → alerts admins. |
| `onPlayerQuit(UUID)` | Forwards to `MultiAccountDetector` |
| `checkKill(Player killer, Player victim)` | **Main detection entry point.** Returns `true` if kill is abusive. Checks multi-account (same IP), then kill farming (same victim, low gear, location). On detection: logs record, increments violation count, alerts admins, applies sanction. |
| `alertAdmins(String, AbuseType)` | Sends formatted alert to all online players with `ethernova.combat.admin` permission |
| `getViolationLog()` | Full unmodifiable violation history |
| `getViolationLog(page, pageSize)` | Paginated violation history (newest first) |
| `getViolationCount(UUID)` | Offense count for a player |
| `clearViolations(UUID)` | Clear all violations + sanctions for a player |
| `getAllViolationCounts()` | All player violation counts |
| Toggle getters/setters | `isMultiAccountEnabled()`, `setMultiAccountEnabled()`, `isKillFarmEnabled()`, `setKillFarmEnabled()`, `getAlertChannel()`, `setAlertChannel()`, `cycleAlertChannel()` |

---

### `MultiAccountDetector`

**Package:** `com.ethernova.combat.detection`  
**Lines:** ~100  
**Description:** Detects multi-account abuse by tracking IP addresses.

#### Fields

| Field | Type | Description |
|---|---|---|
| `ipToPlayers` | `ConcurrentHashMap<String, Set<UUID>>` | IP → all UUIDs from that IP |
| `playerIps` | `ConcurrentHashMap<UUID, String>` | UUID → IP reverse lookup |
| `detectedAlts` | `ConcurrentHashMap<UUID, Set<UUID>>` | UUID → confirmed alt UUIDs (via kill) |

#### Methods

| Method | Description |
|---|---|
| `onLogin(Player)` | Records player IP and UUID mapping |
| `isSameIpKill(Player killer, Player victim)` | Returns true if same IP. Records bidirectional alt relationship. |
| `getSimultaneousAccounts(Player)` | Counts online players from the same IP |
| `getAlts(UUID)` | Gets all UUIDs ever seen from the same IP |
| `getDetectedAlts(UUID)` | Gets confirmed alts (detected via actual kills) |
| `onQuit(UUID)` | No-op (keeps history for detection) |
| `getFlagLevel(UUID)` | Number of detected alt relationships |
| `clearFlags(UUID)` | Clears alt flags |
| `getAllFlagged()` | All players with detected alts |

---

### `KillFarmDetector`

**Package:** `com.ethernova.combat.detection`  
**Lines:** ~130  
**Description:** Detects three types of kill farming patterns.

#### Detection Types

| Type | Trigger | Config Threshold |
|---|---|---|
| **KILL_FARMING** | Same killer/victim pair exceeds threshold within window | `detection.kill-farm.same-victim-threshold` (default 3) in `same-victim-window-minutes` (30) |
| **LOW_GEAR_FARM** | Killing players with ≤1 armor piece and no sword/axe | `detection.kill-farm.low-gear-threshold` (default 5) |
| **LOCATION_FARM** | Multiple kills within `location-radius` (10 blocks) | `detection.kill-farm.location-threshold` (default 5) |

#### Fields

| Field | Type | Description |
|---|---|---|
| `killHistory` | `ConcurrentHashMap<String, List<Long>>` | "killer:victim" → timestamps |
| `locationHistory` | `ConcurrentHashMap<UUID, List<KillLocation>>` | Killer → kill locations |

#### Methods

| Method | Description |
|---|---|
| `checkKill(Player killer, Player victim, Location)` | Returns `AbuseType` or null. Checks: same victim threshold → low gear detection → location pattern. |
| `getSuspicionScore(UUID killer)` | Sum of all recent kills across all pairs |
| `cleanup()` | Periodic cleanup (every 10 minutes) — removes entries older than 1 hour |

#### Inner Record

```java
private record KillLocation(int x, int y, int z, String world, long time) {}
```

#### Low Gear Detection Logic

A player is considered "low gear" when:
- ≤1 armor piece equipped AND
- No sword or axe in main hand

---

### `SanctionManager`

**Package:** `com.ethernova.combat.detection`  
**Lines:** ~160  
**Description:** 3-tier automated punishment system for detected abuse.

#### Sanction Tiers

| Tier | Offense | Punishment |
|---|---|---|
| **1** | First offense | Warning messages + Kick (after 2 seconds) + Nullify fraudulent kills |
| **2** | Second offense | 1-day temp ban + Nullify kills + Admin alert |
| **3+** | Third+ offense | Full stats reset + 3-day temp ban + Admin alert |

#### Fields

| Field | Type | Description |
|---|---|---|
| `offenseLevels` | `ConcurrentHashMap<UUID, Integer>` | Player → current offense level |
| `nullifiedKills` | `ConcurrentHashMap<UUID, Integer>` | Player → number of nullified kill batches |

#### Methods

| Method | Description |
|---|---|
| `applySanction(Player, int offense, AbuseType, String)` | Routes to appropriate tier handler. Always nullifies kills first. |
| `nullifyFraudulentKills(Player)` | Resets kill streak. Deducts `detection.sanction.kills-to-nullify` (default 5) kills from Core profile. |
| `resetStats(Player)` | Sets kills=0, deaths=0 in Core profile. Resets streak. |
| `getOffenseLevel(UUID)` | Get current offense level |
| `clearRecord(UUID)` | Clear offense + nullification records |
| `getNullifiedKills(UUID)` | Get nullified kill batch count |
| `getAllOffenses()` | All players with offenses |

---

## 18. Loot Protection Package

### `LootProtectionManager`

**Package:** `com.ethernova.combat.loot`  
**Lines:** ~30  
**Description:** Protects dropped items from a PvP death so only the killer can pick them up for a configurable duration.

#### Fields

| Field | Type | Description |
|---|---|---|
| `plugin` | `EthernovaCombat` | Plugin reference |
| `protectedItems` | `ConcurrentHashMap<UUID, UUID>` | Item entity UUID → Killer UUID |

#### Methods

| Method | Description |
|---|---|
| `protectLoot(UUID killerUuid, List<Item> items)` | Marks items as protected for `loot-protection.duration` seconds. After expiry, items become available to everyone. |
| `canPickup(UUID playerUuid, UUID itemEntityUuid)` | Returns true if the item is unprotected or the player is the killer |

#### Configuration

| Key | Default | Description |
|---|---|---|
| `loot-protection.enabled` | `true` | Enable loot protection |
| `loot-protection.duration` | `30` | Protection duration (seconds) |

---

## 19. Death Effects Package

### `DeathEffectManager`

**Package:** `com.ethernova.combat.death`  
**Lines:** ~42  
**Description:** Applies visual and audio effects on PvP death.

#### Methods

| Method | Description |
|---|---|
| `applyDeathEffects(Player victim, Player killer)` | Spawns red dust particles at death location (30 particles), plays configurable death sound, optionally strikes lightning. |
| `broadcastCombatLogDeath(String playerName)` | Broadcasts a server-wide message when a combat logger's NPC dies (or they are penalized). |

#### Configuration

| Key | Default | Description |
|---|---|---|
| `death-effects.enabled` | `true` | Enable death effects |
| `death-effects.particle` | `true` | Enable red dust particles |
| `death-effects.sound` | `ENTITY_PLAYER_DEATH` | Sound name |
| `death-effects.lightning` | `false` | Strike lightning on death |

---

## 20. Visual Package

### `CombatVisualManager`

**Package:** `com.ethernova.combat.visual`  
**Lines:** ~175  
**Description:** Manages all combat visual effects: hit particles, entry flash title, compass tracking, heartbeat sounds, combat state particles, and enhanced kill feed.

#### Fields

| Field | Type | Description |
|---|---|---|
| `plugin` | `EthernovaCombat` | Plugin reference |
| `compassTask` | `BukkitTask` | 1-second compass update task |
| `particleTask` | `BukkitTask` | 0.5-second particle/heartbeat task |
| `lastHeartbeat` | `ConcurrentHashMap<UUID, Long>` | Heartbeat cooldown tracking |

#### Methods

| Method | Description |
|---|---|
| `showHitEffect(Location)` | Spawns `DAMAGE_INDICATOR` particles (5) at hit location |
| `showCritEffect(Location)` | Spawns `CRIT` particles (10) at hit location |
| `showCombatEntryFlash(Player, String enemyName)` | Shows red title "⚔" with subtitle "Combat with {enemy}" (100ms fade in, 600ms stay, 300ms fade out). Plays `ENTITY_ENDER_DRAGON_GROWL` at 0.3 volume. |
| `sendKillFeed(Player killer, Player victim)` | Enhanced kill feed via ActionBar to nearby players (50 block radius). Shows killer → victim with weapon name, distance (if >10 blocks), and streak (if ≥3). |
| `shutdown()` | Cancels compass/particle tasks, clears heartbeat tracking |

#### Background Tasks

| Task | Interval | Description |
|---|---|---|
| Compass Tracking | 20 ticks (1s) | Points each tagged player's compass to their enemy (same-world only) |
| Combat Particles + Heartbeat | 10 ticks (0.5s) | Red dust particles above tagged players. Bass note heartbeat at ≤6 HP (interval: 1s at ≤6, 0.5s at ≤3). Double-beat pattern. |

#### Configuration

| Key | Default | Description |
|---|---|---|
| `visuals.hit-effect` | `true` | Hit damage indicator particles |
| `visuals.combat-flash` | `true` | Red title on combat entry |
| `visuals.compass-tracking` | `true` | Compass points to enemy |
| `visuals.combat-particles` | `true` | Red dust over tagged players |
| `visuals.heartbeat` | `true` | Bass heartbeat at low HP |
| `visuals.kill-feed` | `true` | Enhanced kill feed |

#### Kill Feed Format

```
☠ Killer → Victim [Weapon Name] (distance if >10m) 🔥streak if ≥3
```

Weapon resolution:
1. If item has custom display name → use it
2. If no custom name → format material name (e.g., `DIAMOND_SWORD` → `Diamond Sword`)
3. If hand is empty → `Puños`

---

## 21. Profile Package

### `CombatProfileManager`

**Package:** `com.ethernova.combat.profile`  
**Lines:** ~38  
**Description:** Manages context-based combat profiles. Each player has an active profile (survival, war, arena, ffa) that determines combat tag behavior.

#### Fields

| Field | Type | Description |
|---|---|---|
| `plugin` | `EthernovaCombat` | Plugin reference |
| `activeProfiles` | `ConcurrentHashMap<UUID, String>` | Player → profile name |

#### Methods

| Method | Description |
|---|---|
| `getActiveProfile(Player)` / `getActiveProfile(UUID)` | Returns active profile (default: "survival") |
| `setProfile(UUID, String)` | Set active profile |
| `removeProfile(UUID)` | Remove tracking (on quit) |
| `detectProfile(Player)` | Auto-detect profile from Core context: war → "war", arena → "arena", ffa → "ffa", else → "survival" |

#### Profile Definitions (profiles.yml)

| Profile | Tag Duration | Block Flight | Block Commands | Killstreaks | Rewards | Newbie |
|---|---|---|---|---|---|---|
| `survival` | 15s | ✓ | ✓ | ✓ | ✓ | ✓ |
| `war` | 30s | ✓ | ✓ | ✓ | ✓ | ✗ |
| `arena` | 20s | ✓ | ✓ | ✗ | ✗ | ✗ |
| `ffa` | 10s | ✓ | ✗ | ✓ | ✓ | ✗ |

---

## 22. Module Package

### `CombatModule` (Interface)

**Package:** `com.ethernova.combat.module`  
**Lines:** ~50  
**Description:** Interface for ecosystem plugins (Clans, FFA, Duels, Party) to integrate with the combat system. Modules can expose configurable settings in the admin GUI and hook into combat tag behavior.

#### Required Methods

| Method | Return | Description |
|---|---|---|
| `getId()` | `String` | Unique module ID (e.g., "clans", "ffa") |
| `getDisplayName()` | `String` | Display name for GUIs |
| `getIcon()` | `Material` | Icon material for module list |
| `isEnabled()` | `boolean` | Whether module is active |
| `getSettings()` | `List<ModuleSetting>` | Configurable settings |
| `buildConfigGUI(Inventory, String worldName)` | `void` | Build sub-menu in inventory |
| `handleClick(Player, int slot, ClickType, String worldName)` | `void` | Handle clicks in sub-menu |

#### Default Methods (Hooks)

| Method | Default | Description |
|---|---|---|
| `modifyTagDuration(Player, Player, int)` | Returns base duration | Modify tag duration. Return -1 to cancel. |
| `shouldPreventDamage(Player, Player)` | Returns false | Prevent damage between players |
| `onCombatTag(Player, Player)` | No-op | Called when tagged |
| `onCombatExpire(Player)` | No-op | Called when tag expires |

---

### `ModuleSetting` (Record)

**Package:** `com.ethernova.combat.module`  
**Lines:** ~20  

```java
public record ModuleSetting(
    String key, String displayName, Material icon,
    SettingType type, Object defaultValue, String description
) {
    public enum SettingType { TOGGLE, INTEGER, DOUBLE, CYCLE, STRING_LIST }
}
```

---

### `CombatModuleRegistry`

**Package:** `com.ethernova.combat.module`  
**Lines:** ~35  
**Description:** Thread-safe registry for combat modules.

#### Methods

| Method | Description |
|---|---|
| `register(CombatModule)` | Register a module |
| `unregister(String id)` | Unregister by ID |
| `getModule(String id)` | Get by ID |
| `getAll()` | All registered modules |
| `getEnabled()` | Only enabled modules |
| `hasModule(String id)` | Check if registered |

---

## 23. World Configuration Package

### `WorldCombatConfig`

**Package:** `com.ethernova.combat.world`  
**Lines:** ~90  
**Description:** Per-world combat configuration data class. Each world can override global combat settings.

#### Fields & Defaults

| Field | Type | Default | Description |
|---|---|---|---|
| `worldName` | `String` | — | World name |
| `combatTagEnabled` | `boolean` | `true` | Enable combat tag in this world |
| `tagDuration` | `int` | `15` | Tag duration (seconds, clamped 1-120) |
| `keepInventory` | `boolean` | `false` | Keep items on PvP death |
| `logoutPenalty` | `String` | `"KILL"` | KILL / DROP_INVENTORY / NONE |
| `flyDisabled` | `boolean` | `true` | Disable flight in combat |
| `npcSpawnOnLogout` | `boolean` | `true` | Spawn NPC on combat logout |
| `potionRestrict` | `boolean` | `false` | Restrict potions in combat |
| `bossBarEnabled` | `boolean` | `true` | Show BossBar in this world |
| `actionBarEnabled` | `boolean` | `true` | Show ActionBar in this world |
| `newbieProtectionMinutes` | `int` | `30` | Newbie protection duration (minutes) |
| `enderPearlDeny` | `boolean` | `false` | Deny ender pearls in combat |
| `enderPearlCooldown` | `int` | `16` | Pearl cooldown (seconds) |
| `lootProtection` | `boolean` | `true` | Enable loot protection |
| `lootProtectionSeconds` | `int` | `30` | Loot protection duration |
| `craftBlockInCombat` | `boolean` | `false` | Block crafting in combat |
| `blockedCommands` | `List<String>` | home, spawn, tpa, tpaccept, warp, sethome, back | Commands blocked in combat |

#### Methods

All fields have getters and setters. Setters clamp values where appropriate. `cycleLogoutPenalty()` cycles: KILL → DROP_INVENTORY → NONE → KILL.

---

### `WorldConfigManager`

**Package:** `com.ethernova.combat.world`  
**Lines:** ~110  
**Description:** Loads/saves per-world combat configurations from `worlds.yml`.

#### Fields

| Field | Type | Description |
|---|---|---|
| `plugin` | `EthernovaCombat` | Plugin reference |
| `configs` | `ConcurrentHashMap<String, WorldCombatConfig>` | World name → config |
| `configFile` | `File` | `worlds.yml` file reference |

#### Methods

| Method | Description |
|---|---|
| `load()` | Load from `worlds.yml`. Creates default configs for all Bukkit worlds. Ensures every loaded world has a config entry. |
| `save()` | Serializes all configs to `worlds.yml` |
| `getConfig(String worldName)` | Get config for world (creates default if missing) |
| `getConfig(World)` | Get config for Bukkit World |
| `getAll()` | All world configs |
| `getWorldNames()` | All configured world names |

---

## 24. GUI Package (Admin GUI System)

### GUIHelper

**Package:** `com.ethernova.combat.gui`  
**Lines:** ~140  
**Description:** Utility class for building inventory GUI items with Adventure/MiniMessage components. Provides reusable item builders.

#### Static Constants

- `RAINBOW_PANES` — 12 stained glass pane materials for decorative borders

#### Static Methods

| Method | Description |
|---|---|
| `item(Material, String name, String... lore)` | Build an ItemStack with MiniMessage name and lore (all `<!italic>`) |
| `item(Material, String name, List<String> lore)` | Overload accepting List |
| `toggle(String name, boolean enabled, String... extraLore)` | Toggle item: lime dye (on) / gray dye (off) with ACTIVADO/DESACTIVADO status |
| `numberItem(Material, String name, int value, String unit, String... extraLore)` | Number adjuster: shows value + instructions (Click +1/-1, Shift ±5) |
| `cycleItem(Material, String name, String currentValue, String... extraLore)` | Cycle-through item |
| `backButton()` | Arrow item "◀ Volver" |
| `prevPageButton()` / `nextPageButton()` | Pagination arrows |
| `rainbowPane(int index)` | Rainbow glass pane based on slot index |
| `sectionPane(Material, String name)` | Colored section separator pane |
| `tabActive(String name, String desc)` | Active tab indicator (lime dye, bold green arrow) |
| `tabInactive(Material dye, String name, String desc)` | Inactive tab indicator |
| `filler()` | Black glass pane (empty name) |
| `fillBorder(Inventory)` | Fill ALL slots with rainbow glass panes |

---

### AdminGUIManager

**Package:** `com.ethernova.combat.gui`  
**Lines:** ~937  
**Description:** Central manager for all 13 combat admin GUI screens. Each method constructs a 54-slot inventory with the appropriate layout.

#### GUI Types (Enum)

| GUIType | Title | Description |
|---|---|---|
| `MAIN_MENU` | Panel Principal | Hub with 7 navigation buttons |
| `WORLD_LIST` | Mundos | Paginated list of all worlds |
| `WORLD_SETTINGS` | {world} \| General | Per-world: tag toggle, duration, keep inv, penalty, NPC, loot |
| `WORLD_SETTINGS_RESTRICTIONS` | {world} \| Restricciones | Per-world: fly, potions, pearl, craft, commands |
| `WORLD_SETTINGS_VISUAL` | {world} \| Visual | Per-world: BossBar, ActionBar, newbie protection, global FX info |
| `MODULE_LIST` | Módulos | Paginated list of registered ecosystem modules |
| `DETECTION_SETTINGS` | Detección | Multi-account & kill farm toggles, thresholds, sanction tiers |
| `SUSPECT_LIST` | Sospechosos | Flagged players ranked by violation count |
| `LOG_VIEWER` | Logs | Paginated abuse detection history |
| `GLOBAL_CONFIG` | Config Global \| Combat Tag | Global tag settings + cheat prevention toggles |
| `GLOBAL_CONFIG_VISUAL` | Config Global \| Visual | BossBar, ActionBar, effects toggles |
| `GLOBAL_CONFIG_NPC` | Config Global \| NPC & Penalty | NPC settings, penalties, revenge |
| `ACTIVE_COMBATS` | Combates Activos | Live dashboard of tagged players (auto-refreshes every 3s) |

#### Tracking Fields

| Field | Type | Description |
|---|---|---|
| `openGUIs` | `Map<UUID, GUIType>` | Which GUI each player has open |
| `worldContext` | `Map<UUID, String>` | Current world being configured |
| `pageContext` | `Map<UUID, Integer>` | Current page for paginated views |

#### Screen Details

##### Main Menu (slot layout)
| Slot | Icon | Label | Action |
|---|---|---|---|
| 4 | NETHER_STAR | EthernovaCombat | Info header (worlds count, modules count) |
| 10 | GRASS_BLOCK | Mundos | Opens World List |
| 12 | COMPARATOR | Config Global | Opens Global Config |
| 14 | COMMAND_BLOCK | Módulos | Opens Module List |
| 16 | OBSERVER | Detección | Opens Detection Settings |
| 28 | DIAMOND_SWORD | Combates Activos | Opens Active Combats dashboard |
| 30 | PLAYER_HEAD | Sospechosos | Opens Suspect List |
| 32 | BOOK | Logs | Opens Log Viewer |
| 34 | WRITABLE_BOOK | Guardar Todo | Save worlds + reload config + messages |
| 49 | BARRIER | Cerrar | Close inventory |

##### World Settings (Tabbed — 3 tabs)
- **Tab 1 (General):** Combat tag toggle, duration, keep inventory, logout penalty cycle, NPC spawn, loot protection toggle + duration
- **Tab 2 (Restricciones):** Fly disable, potion restrict, ender pearl deny, pearl cooldown, craft block, blocked commands list
- **Tab 3 (Visual):** BossBar toggle, ActionBar toggle, newbie protection minutes, global effects info (read-only)

##### Global Config (Tabbed — 3 tabs)
- **Tab 1 (Combat Tag):** Default/max duration, extend on hit, block flight/commands/pearl/chorus/teleport/elytra/gamemode/riptide
- **Tab 2 (Visual):** BossBar/ActionBar global, combat flash, compass tracking, particles, heartbeat, kill feed, hit effect
- **Tab 3 (NPC & Penalty):** NPC enabled/duration, penalty enabled/money/power, revenge enabled/bonus/message

##### Active Combats Dashboard
- Lists all tagged players with: enemy name, remaining time (color-coded), health %, profile, world
- Click to teleport to player
- Shift+click to force untag
- Auto-refreshes every 3 seconds
- Manual refresh button

---

### AdminGUIListener

**Package:** `com.ethernova.combat.gui`  
**Lines:** ~545  
**Implements:** `Listener`  
**Description:** Routes all inventory click events to the correct handler based on which GUI screen the player has open.

#### Event Handlers

| Event | Description |
|---|---|
| `onClose(InventoryCloseEvent)` | Clears GUI tracking for the closing player |
| `onDrag(InventoryDragEvent)` | Cancels all drags in tracked GUIs |
| `onClick(InventoryClickEvent)` | Cancels event, validates slot, routes to type-specific handler |

#### Click Handlers (one per GUIType)

Each handler switches on the clicked slot to determine the action:

- **Toggle items:** Invert the boolean value, reopen the GUI to reflect change
- **Number items:** Left click +1 (or +5 with shift), right click -1 (or -5 with shift)
- **Cycle items:** Call the cycle method, reopen GUI
- **Navigation:** Back buttons → return to parent GUI; pagination buttons → adjust page + reopen
- **Save:** Save config file, reload, send confirmation message
- **World list clicks:** Calculate index from slot + page, open world settings
- **Suspect list clicks:** Calculate index, clear violations for clicked player, reopen
- **Active combats clicks:** Regular click → teleport to player; shift click → force untag

#### Helper Method

```java
private int getInnerIndex(int slot, int invSize)
```
Converts an inventory slot to a sequential index, excluding border slots (columns 0 & 8, first & last rows). Used for paginated item lists.

---

## 25. Safe Logout Package

### `SafeLogoutManager`

**Package:** `com.ethernova.combat.logout`  
**Lines:** ~45  
**Description:** Provides a `/logout` command for safe disconnection. Players must stand still for a countdown period. Cancelled by damage or being in combat.

#### Fields

| Field | Type | Description |
|---|---|---|
| `plugin` | `EthernovaCombat` | Plugin reference |
| `pending` | `ConcurrentHashMap<UUID, BukkitTask>` | Players with pending logouts |

#### Methods

| Method | Description |
|---|---|
| `startLogout(Player)` | Starts countdown. Blocked if in combat or already pending. After `safe-logout.duration` seconds, kicks with "Safe logout". |
| `cancelLogout(UUID)` | Cancels a pending logout + notifies player |
| `onDamage(Player)` | Cancels logout if the player takes damage |
| `cancelAll()` | Cancels all pending logouts (onDisable) |

#### Configuration

| Key | Default | Description |
|---|---|---|
| `safe-logout.duration` | `10` | Countdown in seconds |
| `safe-logout.countdown` | `10` | (Defined but not yet used for periodic messages) |
| `safe-logout.cancel-on-move` | `true` | (Defined but movement cancellation not yet implemented) |
| `safe-logout.cancel-on-damage` | `true` | Cancel on damage (implemented via listener) |

---

## 26. Clan Integration

The `ClanIntegrationListener` bridges EthernovaCombat with EthernovaClans through the shared EventBus in EthernovaCore:

| Direction | Event | Purpose |
|---|---|---|
| Clans → Combat | `ClanWarStartEvent` | Logged in debug mode (combat context set by Clans) |
| Clans → Combat | `ClanWarEndEvent` | Logged in debug mode |
| Combat → Clans | `EthernovaPlayerKillEvent` | Published on every valid PvP kill (killer UUID, victim UUID, context) |
| Combat → Clans | `PowerChangeEvent` | Published when combat log penalty includes power loss |

---

## 27. Commands & Permissions Reference

### Commands

| Command | Permission | Description |
|---|---|---|
| `/combat` | — | Main player command (status, newbie) |
| `/combat status` | — | View combat status and kill streak |
| `/combat newbie` | — | Toggle off newbie protection |
| `/combatadmin` | `ethernova.combat.admin` | Open Admin GUI |
| `/combatadmin gui` | `ethernova.combat.admin` | Open Admin GUI |
| `/combatadmin reload` | `ethernova.combat.admin` | Reload all configs and messages |
| `/combatadmin tag <p1> <p2>` | `ethernova.combat.admin` | Force combat tag two players |
| `/combatadmin untag <player>` | `ethernova.combat.admin` | Remove combat tag from a player |
| `/logout` | — | Start safe logout countdown |

### Permissions

| Permission | Default | Description |
|---|---|---|
| `ethernova.combat.bypass.tag` | `op` | Bypass combat tagging entirely (won't be tagged and attacking won't tag others) |
| `ethernova.combat.admin` | `op` | Access admin commands and GUI, receive abuse alerts |

---

## 28. Configuration Reference

### config.yml (Main Configuration)

#### Combat Tag Settings

| Key | Type | Default | Description |
|---|---|---|---|
| `combat-tag.default-duration` | int | `15` | Default tag duration (seconds) |
| `combat-tag.max-duration` | int | `30` | Maximum tag duration after extensions |
| `combat-tag.extend-on-hit` | boolean | `true` | Reset timer on each hit |
| `combat-tag.block-flight` | boolean | `true` | Disable flight in combat |
| `combat-tag.block-commands` | boolean | `true` | Block commands in combat |
| `combat-tag.block-enderpearl` | boolean | `true` | Block ender pearls |
| `combat-tag.block-chorus` | boolean | `true` | Block chorus fruit |
| `combat-tag.block-teleport` | boolean | `true` | Block command teleportation |
| `combat-tag.block-elytra` | boolean | `true` | Block elytra gliding |
| `combat-tag.block-gamemode` | boolean | `true` | Block gamemode changes |
| `combat-tag.block-riptide` | boolean | `true` | Block riptide trident |
| `combat-tag.blocked-commands` | list | home, spawn, tpa, tp, warp, back | Commands blocked during combat |
| `combat-tag.bossbar.enabled` | boolean | `true` | Show BossBar timer |
| `combat-tag.bossbar.format` | string | MiniMessage | BossBar format (`{time}`, `{enemy}`) |
| `combat-tag.actionbar.enabled` | boolean | `true` | Show ActionBar timer |
| `combat-tag.actionbar.format` | string | MiniMessage | ActionBar format (`{time}`, `{enemy}`) |

#### Combat NPC Settings

| Key | Type | Default | Description |
|---|---|---|---|
| `combat-npc.enabled` | boolean | `true` | Spawn NPC on combat logout |
| `combat-npc.duration` | int | `30` | NPC lifetime (seconds) |
| `combat-npc.drop-items` | boolean | `true` | Drop inventory when NPC killed |
| `combat-npc.kill-means-death` | boolean | `true` | Player dies on reconnect if NPC was killed |

#### Combat Log Penalty

| Key | Type | Default | Description |
|---|---|---|---|
| `combat-log.penalty.enabled` | boolean | `true` | Enable disconnect penalties |
| `combat-log.penalty.money-loss` | double | `500` | Money deducted |
| `combat-log.penalty.power-loss` | int | `20` | Power deducted (sent to Clans) |
| `combat-log.penalty.broadcast` | boolean | `true` | Broadcast disconnect message |
| `combat-log.penalty.commands` | list | `[]` | Console commands to run (`{player}`) |
| `combat-log.broadcast-death` | boolean | `true` | Broadcast combat log death |

#### Newbie Protection

| Key | Type | Default | Description |
|---|---|---|---|
| `newbie-protection.enabled` | boolean | `true` | Enable newbie protection |
| `newbie-protection.duration-minutes` | int | `120` | Duration (minutes) |
| `newbie-protection.lose-on-attack` | boolean | `true` | Lose protection on attacking |

#### Anti-Abuse (Legacy)

| Key | Type | Default | Description |
|---|---|---|---|
| `anti-abuse.enabled` | boolean | `true` | Enable legacy detection |
| `anti-abuse.block-same-ip` | boolean | `true` | Block same-IP kills |
| `anti-abuse.max-repeat-kills` | int | `3` | Max repeat kills |
| `anti-abuse.repeat-window-minutes` | int | `30` | Time window |

#### Safe Logout

| Key | Type | Default | Description |
|---|---|---|---|
| `safe-logout.duration` | int | `10` | Countdown seconds |
| `safe-logout.countdown` | int | `10` | Countdown (unused) |
| `safe-logout.cancel-on-move` | boolean | `true` | Cancel on movement |
| `safe-logout.cancel-on-damage` | boolean | `true` | Cancel on damage |

#### Loot Protection

| Key | Type | Default | Description |
|---|---|---|---|
| `loot-protection.enabled` | boolean | `true` | Enable loot protection |
| `loot-protection.duration` | int | `30` | Protection seconds |

#### Death Effects

| Key | Type | Default | Description |
|---|---|---|---|
| `death-effects.enabled` | boolean | `true` | Enable effects |
| `death-effects.particle` | boolean | `true` | Red dust particles |
| `death-effects.sound` | string | `ENTITY_PLAYER_DEATH` | Death sound |
| `death-effects.lightning` | boolean | `false` | Lightning effect |

#### Visual Effects

| Key | Type | Default | Description |
|---|---|---|---|
| `visuals.hit-effect` | boolean | `true` | Hit particles |
| `visuals.combat-flash` | boolean | `true` | Red title on combat entry |
| `visuals.compass-tracking` | boolean | `true` | Compass → enemy |
| `visuals.combat-particles` | boolean | `true` | Particles above tagged players |
| `visuals.heartbeat` | boolean | `true` | Heartbeat at low HP |
| `visuals.kill-feed` | boolean | `true` | Enhanced kill feed |

#### Revenge

| Key | Type | Default | Description |
|---|---|---|---|
| `revenge.enabled` | boolean | `true` | Enable revenge system |
| `revenge.money-bonus` | int | `100` | Bonus money |
| `revenge.message` | boolean | `true` | Notify on revenge |

#### Kill Streaks

| Key | Type | Default | Description |
|---|---|---|---|
| `killstreaks.enabled` | boolean | `true` | Enable kill streaks |
| `killstreaks.reset-on-death` | boolean | `true` | Reset on death |

#### Detection (Enhanced)

| Key | Type | Default | Description |
|---|---|---|---|
| `detection.multi-account.enabled` | boolean | `true` | Multi-account detection |
| `detection.multi-account.suspicion-threshold` | int | `2` | Accounts for alert |
| `detection.kill-farm.enabled` | boolean | `true` | Kill farm detection |
| `detection.kill-farm.same-victim-threshold` | int | `3` | Same victim limit |
| `detection.kill-farm.same-victim-window-minutes` | long | `30` | Time window |
| `detection.kill-farm.low-gear-detection` | boolean | `true` | Low gear detection |
| `detection.kill-farm.low-gear-threshold` | int | `5` | Low gear kill limit |
| `detection.kill-farm.location-pattern` | boolean | `true` | Location farming |
| `detection.kill-farm.location-threshold` | int | `5` | Location kill limit |
| `detection.kill-farm.location-radius` | double | `10.0` | Radius (blocks) |
| `detection.alert-channel` | string | `BOTH` | CHAT / DISCORD / BOTH |
| `detection.sanction.kills-to-nullify` | int | `5` | Kills deducted per sanction |

---

## 29. Resource Files Reference

### Plugin Resources

| File | Description |
|---|---|
| `plugin.yml` | Bukkit plugin descriptor |
| `config.yml` | Main configuration |
| `killstreaks.yml` | Kill streak milestone definitions |
| `rewards.yml` | Kill reward & death penalty settings |
| `profiles.yml` | Combat profiles (survival/war/arena/ffa) |
| `messages_en.yml` | English messages (MiniMessage format) |
| `messages_es.yml` | Spanish messages (MiniMessage format, default) |
| `messages/messages_en.yml` | Alternate message directory (English) |
| `messages/messages_es.yml` | Alternate message directory (Spanish) |

### Generated Files (at runtime)

| File | Description |
|---|---|
| `worlds.yml` | Per-world combat configurations (created by WorldConfigManager) |

### Message Keys Summary

All messages use MiniMessage format with `{prefix}` auto-replaced. Key categories:

| Category | Example Keys |
|---|---|
| `general.*` | prefix, player-only, no-permission, player-not-found |
| `combat.*` | tagged, untagged, cannot-command, cannot-fly, cannot-enderpearl, cannot-chorus, cannot-elytra, cannot-teleport, cannot-gamemode, cannot-riptide, log-broadcast, log-death, revenge, status-header, status-in-combat, status-not-in-combat, status-streak |
| `npc.*` | killed, despawned, name-format |
| `newbie.*` | protected, lost, target-protected |
| `abuse.*` | same-ip, repeat-kill |
| `reward.*` | money |
| `killstreak.*` | gained, lost |
| `logout.*` | in-combat, already-pending, started, success, cancelled |
| `visual.*` | combat-entry-title, combat-entry-subtitle, kill-feed, kill-feed-distance, kill-feed-streak, bossbar-format, actionbar-format |
| `sanction.*` | warn-title, warn-detail, warn-nullified, warn-next, kick-header-1/2/3, kick-reason-1/2/3, kick-sanction-1/2/3, kick-detail-1/2/3, kick-next-1/2 |
| `detection.*` | admin-alert, same-ip, kill-farming, low-gear, location-farming, farming-detected, multi-account |
| `admin.*` | usage, player-only, tag-usage, tag-not-found, tag-success, untag-success |
| `admin-gui.*` | config-saved, world-saved, flags-cleared, global-saved, global-error, combat-removed, teleported |

---

## 30. Maven Dependencies

```xml
<parent>
    <groupId>com.ethernova</groupId>
    <artifactId>ethernova-parent</artifactId>
    <version>1.0.0</version>
</parent>

<artifactId>ethernova-combat</artifactId>
```

| Dependency | Scope | Description |
|---|---|---|
| `io.papermc.paper:paper-api` | (from parent) | Paper 1.21 API (Adventure, MiniMessage, etc.) |
| `com.github.MilkBowl:VaultAPI` | (from parent) | Economy integration (soft depend) |
| `com.ethernova:ethernova-core:1.0.0` | `provided` | Core framework (EventBus, profiles, visuals, economy hook) |
| `me.clip:placeholderapi` | (from parent) | PlaceholderAPI (soft depend; placeholder dir exists but is empty) |

---

## 31. Flow Diagrams

### Combat Tag Lifecycle

```
Player A attacks Player B
     │
     ▼
CombatDamageListener.onDamage()
     │
     ├─ Check world config: combat tag enabled?
     │  └─ No → return (no tag)
     │
     ├─ Check newbie protection
     │  ├─ Victim protected → cancel damage, return
     │  └─ Attacker protected → remove protection (if lose-on-attack)
     │
     ├─ Detect profile (survival/war/arena/ffa)
     │
     ├─ CombatTagManager.tag(A, B, profile)
     │  ├─ Check bypass permission
     │  ├─ Fire CombatTagEvent (cancellable)
     │  ├─ Create/extend CombatTag
     │  ├─ Create BossBar
     │  ├─ Send tagged message
     │  └─ Show combat entry flash
     │
     ├─ CombatTagManager.tag(B, A, profile)  (bidirectional)
     │
     ├─ Show hit effect particles
     └─ Cancel pending safe logouts

        ┌──────────────────────────────────────────┐
        │    Tick Task (every 1 second)             │
        │  ┌─────────────────────────────────────┐  │
        │  │ For each active tag:                │  │
        │  │  • tick() — decrement               │  │
        │  │  • If expired → untag()             │  │
        │  │  • Update BossBar (progress, color) │  │
        │  │  • Send ActionBar                   │  │
        │  └─────────────────────────────────────┘  │
        └──────────────────────────────────────────┘

Tag expires → untag()
     │
     ├─ Remove from tags map
     ├─ Hide + remove BossBar
     └─ Send "untagged" message
```

### Death Processing Flow

```
PlayerDeathEvent
     │
     ▼
CombatDeathListener.onDeath()
     │
     ├─ Untag victim
     ├─ Reset victim's kill streak (if reset-on-death)
     │
     ├─ No killer? → return
     │
     ├─ DetectionManager.checkKill(killer, victim)
     │  ├─ Multi-account check (same IP)
     │  ├─ Kill farming check (repeat victim)
     │  ├─ Low gear check
     │  └─ Location pattern check
     │
     ├─ If abusive → nullify (no rewards, no stats)
     │  └─ SanctionManager applies tier punishment
     │
     ├─ If clean kill:
     │  ├─ Increment kills/deaths in Core profile
     │  ├─ Add kill to streak + check milestone
     │  ├─ Process kill reward (money + XP)
     │  ├─ Process death penalty (optional)
     │  ├─ Apply death effects (particle, sound, lightning)
     │  ├─ Send enhanced kill feed
     │  ├─ Process revenge (bonus if avenging previous death)
     │  └─ Record kill for future revenge tracking
     │
     ├─ Untag killer
     ├─ Protect dropped loot for killer
     └─ Publish EthernovaPlayerKillEvent
```

### Combat Log (Disconnect) Flow

```
PlayerQuitEvent (while in combat)
     │
     ▼
CombatDisconnectListener.onQuit()
     │
     ├─ Cancel pending safe logout
     ├─ Untag player
     │
     ├─ Spawn Combat NPC (Villager)
     │  ├─ Copy inventory + armor to NPC data
     │  ├─ Set health, custom name, AI=false
     │  └─ Schedule auto-despawn after 30s
     │
     ├─ Clear player inventory (items now on NPC)
     │
     ├─ PenaltyManager.applyCombatLogPenalty()
     │  ├─ Withdraw money (offline)
     │  ├─ Publish power loss event → Clans
     │  ├─ Broadcast disconnect message
     │  └─ Execute console commands
     │
     └─ Broadcast combat log death message

        ┌────────────────────────────────────────┐
        │  While NPC is alive (up to 30s):       │
        │  • Other players can attack/kill it    │
        │  • On NPC death → drop all items       │
        │  •   Items protected for the killer    │
        └────────────────────────────────────────┘

Player reconnects (PlayerJoinEvent)
     │
     ▼
CombatDisconnectListener.onJoin()
     │
     ├─ NPC killed? → Kill the player (set health 0)
     │
     └─ NPC survived? → Restore inventory from NPC data
```

---

## Appendix: Complete Class Index

| # | Package | Class | Type | Lines | Description |
|---|---|---|---|---|---|
| 1 | `combat` | `EthernovaCombat` | Class (extends JavaPlugin) | ~160 | Main plugin class, lifecycle, DI container |
| 2 | `combat.abuse` | `KDRAbuseManager` | Class | ~55 | Legacy anti-abuse (same IP, repeat kills) |
| 3 | `combat.cheat` | `CheatPreventionManager` | Class | ~45 | Config query for combat restrictions |
| 4 | `combat.command` | `CombatCommand` | Class (implements CommandExecutor, TabCompleter) | ~40 | /combat command |
| 5 | `combat.command` | `CombatAdminCommand` | Class (implements CommandExecutor, TabCompleter) | ~70 | /combatadmin command |
| 6 | `combat.command` | `LogoutCommand` | Class (implements CommandExecutor) | ~17 | /logout command |
| 7 | `combat.config` | `CombatConfigManager` | Class | ~57 | Multi-file YAML config loader |
| 8 | `combat.death` | `DeathEffectManager` | Class | ~42 | Death particles, sound, lightning |
| 9 | `combat.detection` | `AbuseRecord` | Record | ~18 | Violation data record |
| 10 | `combat.detection` | `DetectionManager` | Class | ~155 | Central abuse detection coordinator |
| 11 | `combat.detection` | `KillFarmDetector` | Class | ~130 | Kill farming pattern detection |
| 12 | `combat.detection` | `MultiAccountDetector` | Class | ~100 | IP-based multi-account detection |
| 13 | `combat.detection` | `SanctionManager` | Class | ~160 | 3-tier automated punishment |
| 14 | `combat.gui` | `AdminGUIManager` | Class | ~937 | 13-screen admin GUI system |
| 15 | `combat.gui` | `AdminGUIListener` | Class (implements Listener) | ~545 | GUI click event routing |
| 16 | `combat.gui` | `GUIHelper` | Final Class | ~140 | Static GUI item builders |
| 17 | `combat.killstreak` | `KillStreakManager` | Class | ~110 | Kill streak tracking & milestones |
| 18 | `combat.listener` | `ClanIntegrationListener` | Class | ~50 | EventBus subscriptions for clan integration |
| 19 | `combat.listener` | `CombatCheatListener` | Class (implements Listener) | ~85 | Command/flight/teleport/gamemode/riptide blocking |
| 20 | `combat.listener` | `CombatDamageListener` | Class (implements Listener) | ~55 | Damage → tag pipeline |
| 21 | `combat.listener` | `CombatDeathListener` | Class (implements Listener) | ~75 | Death → rewards/penalties pipeline |
| 22 | `combat.listener` | `CombatDisconnectListener` | Class (implements Listener) | ~65 | Quit → NPC/penalty; Join → NPC reconnect |
| 23 | `combat.listener` | `CombatItemListener` | Class (implements Listener) | ~40 | Loot pickup protection |
| 24 | `combat.listener` | `CombatMoveListener` | Class (implements Listener) | ~22 | Elytra glide blocking |
| 25 | `combat.listener` | `CombatNPCListener` | Class (implements Listener) | ~27 | NPC death handling |
| 26 | `combat.logout` | `SafeLogoutManager` | Class | ~45 | /logout countdown system |
| 27 | `combat.loot` | `LootProtectionManager` | Class | ~30 | Death loot protection |
| 28 | `combat.message` | `CombatMessageManager` | Class | ~65 | i18n MiniMessage system |
| 29 | `combat.module` | `CombatModule` | Interface | ~50 | Ecosystem module contract |
| 30 | `combat.module` | `CombatModuleRegistry` | Class | ~35 | Module registration |
| 31 | `combat.module` | `ModuleSetting` | Record | ~20 | Module setting descriptor |
| 32 | `combat.newbie` | `NewbieProtectionManager` | Class | ~55 | New player PvP immunity |
| 33 | `combat.npc` | `CombatNPC` | Class | ~32 | NPC data container |
| 34 | `combat.npc` | `CombatNPCManager` | Class | ~110 | NPC spawn/kill/reconnect |
| 35 | `combat.penalty` | `PenaltyManager` | Class | ~42 | Combat log monetary/power penalties |
| 36 | `combat.placeholder` | *(empty package)* | — | — | Placeholder expansion (not yet implemented) |
| 37 | `combat.profile` | `CombatProfileManager` | Class | ~38 | Context-based profile management |
| 38 | `combat.revenge` | `RevengeManager` | Class | ~65 | Revenge kill tracking & bonus |
| 39 | `combat.reward` | `RewardManager` | Class | ~85 | Kill rewards & death penalties |
| 40 | `combat.tag` | `CombatAPI` | Class | ~36 | Public API facade |
| 41 | `combat.tag` | `CombatTag` | Class | ~40 | Tag data (thread-safe) |
| 42 | `combat.tag` | `CombatTagEvent` | Class (extends Event, Cancellable) | ~42 | Cancellable tag event |
| 43 | `combat.tag` | `CombatTagManager` | Class | ~145 | Central tag engine |
| 44 | `combat.visual` | `CombatVisualManager` | Class | ~175 | Combat visual effects |
| 45 | `combat.world` | `WorldCombatConfig` | Class | ~90 | Per-world config data |
| 46 | `combat.world` | `WorldConfigManager` | Class | ~110 | Per-world config I/O |

---

*Documentation generated from source analysis of all 40+ Java files, 4 YAML config files, 2 message files, plugin.yml, and pom.xml in the EthernovaCombat module.*
