package com.ethernova.combat.gui;

import com.ethernova.combat.EthernovaCombat;
import com.ethernova.combat.detection.AbuseRecord;
import com.ethernova.combat.detection.DetectionManager;
import com.ethernova.combat.module.CombatModule;
import com.ethernova.combat.module.CombatModuleRegistry;
import com.ethernova.combat.world.WorldCombatConfig;
import com.ethernova.combat.world.WorldConfigManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.text.SimpleDateFormat;
import java.util.*;

import static com.ethernova.combat.gui.GUIHelper.*;

/**
 * Central manager for all Combat Admin GUI screens.
 * Each method opens a specific inventory-based menu.
 */
public class AdminGUIManager {

    private static final MiniMessage MINI = MiniMessage.miniMessage();
    private static final String TITLE_PREFIX = "<dark_gray>CombatAdmin</dark_gray> <dark_gray>»</dark_gray> ";

    private final EthernovaCombat plugin;

    // Track which GUI each player has open for routing clicks
    private final Map<UUID, GUIType> openGUIs = new HashMap<>();
    // Track per-world context for world settings GUI
    private final Map<UUID, String> worldContext = new HashMap<>();
    // Track pagination
    private final Map<UUID, Integer> pageContext = new HashMap<>();

    public AdminGUIManager(EthernovaCombat plugin) {
        this.plugin = plugin;
    }

    public enum GUIType {
        MAIN_MENU,
        WORLD_LIST,
        WORLD_SETTINGS,
        WORLD_SETTINGS_RESTRICTIONS,
        WORLD_SETTINGS_VISUAL,
        MODULE_LIST,
        MODULE_CONFIG,
        DETECTION_SETTINGS,
        SUSPECT_LIST,
        LOG_VIEWER,
        GLOBAL_CONFIG,
        GLOBAL_CONFIG_VISUAL,
        GLOBAL_CONFIG_NPC,
        ACTIVE_COMBATS
    }

    // ─── Track / Query ──────────────────────────────────────────

    public void trackGUI(UUID uuid, GUIType type) { openGUIs.put(uuid, type); }
    public GUIType getOpenGUI(UUID uuid) { return openGUIs.get(uuid); }
    public void clearGUI(UUID uuid) { openGUIs.remove(uuid); worldContext.remove(uuid); pageContext.remove(uuid); }

    public void setWorldContext(UUID uuid, String world) { worldContext.put(uuid, world); }
    public String getWorldContext(UUID uuid) { return worldContext.get(uuid); }

    public void setPage(UUID uuid, int page) { pageContext.put(uuid, page); }
    public int getPage(UUID uuid) { return pageContext.getOrDefault(uuid, 0); }

    // ─── Main Menu ──────────────────────────────────────────────

    public void openMainMenu(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54,
                MINI.deserialize(TITLE_PREFIX + "<gold>Panel Principal</gold>"));

        fillBorder(inv);

        // Row 2 (slots 10-16) — Main sections
        inv.setItem(10, item(Material.GRASS_BLOCK,
                "<green>Mundos</green>",
                "<gray>Configuración per-world</gray>",
                "<gray>de combat tag</gray>",
                "",
                "<dark_gray>Click para abrir</dark_gray>"));

        inv.setItem(12, item(Material.COMPARATOR,
                "<light_purple>Config Global</light_purple>",
                "<gray>Editar configuración general</gray>",
                "<gray>del combat tag</gray>",
                "",
                "<dark_gray>Click para abrir</dark_gray>"));

        inv.setItem(14, item(Material.COMMAND_BLOCK,
                "<aqua>Módulos</aqua>",
                "<gray>Gestión de módulos del</gray>",
                "<gray>ecosistema (FFA, Duels...)</gray>",
                "",
                "<dark_gray>Click para abrir</dark_gray>"));

        inv.setItem(16, item(Material.OBSERVER,
                "<red>Detección</red>",
                "<gray>Anti multi-cuenta y</gray>",
                "<gray>kill farming</gray>",
                "",
                "<dark_gray>Click para abrir</dark_gray>"));

        // Header (slot 4)
        int totalWorlds = plugin.getWorldConfigManager().getWorldNames().size();
        int totalModules = plugin.getModuleRegistry().getAll().size();
        inv.setItem(4, item(Material.NETHER_STAR,
                "<gradient:#EF4444:#F97316><bold>EthernovaCombat</bold></gradient>",
                "",
                "<gray>Panel de administración</gray>",
                "<gray>del sistema de combate</gray>",
                "",
                "<dark_gray>Mundos: <white>" + totalWorlds + "</white></dark_gray>",
                "<dark_gray>Módulos: <white>" + totalModules + "</white></dark_gray>"));

        // Row 4 (slots 28-34) — Secondary sections
        int taggedCount = plugin.getTagManager().getTaggedCount();
        String activeLabel = taggedCount > 0
                ? "<red>" + taggedCount + " jugadores en combate</red>"
                : "<green>" + taggedCount + " jugadores en combate</green>";
        inv.setItem(28, item(Material.DIAMOND_SWORD,
                "<gold>Combates Activos</gold>",
                activeLabel,
                "",
                "<dark_gray>Click para ver en vivo</dark_gray>"));

        inv.setItem(30, item(Material.PLAYER_HEAD,
                "<yellow>Sospechosos</yellow>",
                "<gray>Lista de jugadores</gray>",
                "<gray>flaggeados por el sistema</gray>",
                "",
                "<dark_gray>Click para abrir</dark_gray>"));

        inv.setItem(32, item(Material.BOOK,
                "<white>Logs</white>",
                "<gray>Historial de violaciones</gray>",
                "<gray>detectadas</gray>",
                "",
                "<dark_gray>Click para abrir</dark_gray>"));

        inv.setItem(34, item(Material.WRITABLE_BOOK,
                "<white>Guardar Todo</white>",
                "<gray>Guardar configuración</gray>",
                "<gray>de mundos + recargar</gray>",
                "",
                "<dark_gray>Click para guardar</dark_gray>"));

        // Bottom row
        inv.setItem(49, item(Material.BARRIER,
                "<red>Cerrar</red>",
                "<dark_gray>Click para cerrar</dark_gray>"));

        player.openInventory(inv);
        trackGUI(player.getUniqueId(), GUIType.MAIN_MENU);
    }

    // ─── World List ─────────────────────────────────────────────

    public void openWorldList(Player player) {
        WorldConfigManager wcm = plugin.getWorldConfigManager();
        List<String> worlds = wcm.getWorldNames();

        int page = getPage(player.getUniqueId());
        int pageSize = 28; // 4 rows × 7 cols
        int totalPages = Math.max(1, (int) Math.ceil((double) worlds.size() / pageSize));
        if (page >= totalPages) page = totalPages - 1;
        if (page < 0) page = 0;
        setPage(player.getUniqueId(), page);

        Inventory inv = Bukkit.createInventory(null, 54,
                MINI.deserialize(TITLE_PREFIX + "<green>Mundos</green> <dark_gray>(" + (page + 1) + "/" + totalPages + ")</dark_gray>"));

        fillBorder(inv);

        int start = page * pageSize;
        int end = Math.min(start + pageSize, worlds.size());
        int slot = 10;
        for (int i = start; i < end; ) {
            if (slot >= 45) break;
            if (slot % 9 == 0) { slot++; continue; }
            if (slot % 9 == 8) { slot += 2; continue; }

            String worldName = worlds.get(i);
            WorldCombatConfig wc = wcm.getConfig(worldName);
            Material icon = wc.isCombatTagEnabled() ? Material.LIME_CONCRETE : Material.RED_CONCRETE;
            String status = wc.isCombatTagEnabled() ? "<green>ACTIVADO</green>" : "<red>DESACTIVADO</red>";

            inv.setItem(slot, item(icon,
                    "<white>" + worldName + "</white>",
                    "Combat Tag: " + status,
                    "<gray>Duración: " + wc.getTagDuration() + "s</gray>",
                    "<gray>Penalización logout: " + wc.getLogoutPenalty() + "</gray>",
                    "",
                    "<dark_gray>Click para configurar</dark_gray>"));
            slot++;
            i++;
        }

        // Navigation
        inv.setItem(45, backButton());
        if (page > 0) {
            inv.setItem(48, prevPageButton());
        }
        inv.setItem(49, item(Material.PAPER, "<white>Página " + (page + 1) + "/" + totalPages + "</white>",
                "<gray>" + worlds.size() + " mundos</gray>"));
        if (page < totalPages - 1) {
            inv.setItem(50, nextPageButton());
        }

        player.openInventory(inv);
        trackGUI(player.getUniqueId(), GUIType.WORLD_LIST);
    }

    // ─── World Settings (Tabbed) ───────────────────────────────

    public void openWorldSettings(Player player, String worldName) {
        openWorldSettingsGeneral(player, worldName);
    }

    /**
     * Tab 1: General settings (combat tag, duration, keep inv, penalties, NPC)
     */
    public void openWorldSettingsGeneral(Player player, String worldName) {
        WorldConfigManager wcm = plugin.getWorldConfigManager();
        WorldCombatConfig wc = wcm.getConfig(worldName);

        Inventory inv = Bukkit.createInventory(null, 54,
                MINI.deserialize(TITLE_PREFIX + "<green>" + worldName + "</green> <dark_gray>|</dark_gray> <white>General</white>"));

        fillBorder(inv);

        // Tab bar (row 1: slots 2-6)
        inv.setItem(2, tabActive("General", "Configuración principal"));
        inv.setItem(4, tabInactive(Material.ORANGE_DYE, "<yellow>Restricciones</yellow>", "Bloqueos en combate"));
        inv.setItem(6, tabInactive(Material.MAGENTA_DYE, "<light_purple>Visual</light_purple>", "BossBar, ActionBar, Newbie"));
        inv.setItem(11, sectionPane(Material.LIME_STAINED_GLASS_PANE, "<green>▼</green>"));

        // Content (rows 2-4)
        inv.setItem(19, toggle("<white>Combat Tag</white>", wc.isCombatTagEnabled(),
                "<gray>Habilita el tag de combate</gray>", "<gray>en este mundo</gray>"));
        inv.setItem(20, numberItem(Material.CLOCK, "<white>Duración Tag</white>",
                wc.getTagDuration(), "seg", "<gray>Duración del combat tag</gray>"));
        inv.setItem(21, toggle("<white>Keep Inventory</white>", wc.isKeepInventory(),
                "<gray>Mantener items al morir</gray>"));
        inv.setItem(22, cycleItem(Material.SKELETON_SKULL, "<white>Logout Penalty</white>",
                wc.getLogoutPenalty(), "<gray>KILL / DROP_INVENTORY / NONE</gray>"));
        inv.setItem(23, toggle("<white>NPC al Logout</white>", wc.isNpcSpawnOnLogout(),
                "<gray>Spawn NPC al desconectar</gray>", "<gray>durante combate</gray>"));
        inv.setItem(24, toggle("<white>Loot Protection</white>", wc.isLootProtection(),
                "<gray>Proteger loot del muerto</gray>"));
        inv.setItem(25, numberItem(Material.CHEST, "<white>Loot Tiempo</white>",
                wc.getLootProtectionSeconds(), "seg", "<gray>Duración protección de loot</gray>"));

        // Save button
        inv.setItem(40, item(Material.EMERALD, "<green>Guardar Mundo</green>",
                "<gray>Guardar esta configuración</gray>"));

        inv.setItem(45, backButton());

        player.openInventory(inv);
        // Set context AFTER openInventory since openInventory triggers onClose->clearGUI
        setWorldContext(player.getUniqueId(), worldName);
        trackGUI(player.getUniqueId(), GUIType.WORLD_SETTINGS);
    }

    /**
     * Tab 2: Restrictions (flight, commands, ender pearl, elytra, etc.)
     */
    public void openWorldSettingsRestrictions(Player player, String worldName) {
        WorldConfigManager wcm = plugin.getWorldConfigManager();
        WorldCombatConfig wc = wcm.getConfig(worldName);

        Inventory inv = Bukkit.createInventory(null, 54,
                MINI.deserialize(TITLE_PREFIX + "<green>" + worldName + "</green> <dark_gray>|</dark_gray> <yellow>Restricciones</yellow>"));

        fillBorder(inv);

        // Tab bar
        inv.setItem(2, tabInactive(Material.GRAY_DYE, "<gray>General</gray>", "Configuración principal"));
        inv.setItem(4, tabActive("Restricciones", "Bloqueos en combate"));
        inv.setItem(6, tabInactive(Material.MAGENTA_DYE, "<light_purple>Visual</light_purple>", "BossBar, ActionBar, Newbie"));
        inv.setItem(13, sectionPane(Material.LIME_STAINED_GLASS_PANE, "<green>▼</green>"));

        // Content
        inv.setItem(19, toggle("<white>Deshab. Vuelo</white>", wc.isFlyDisabled(),
                "<gray>Desactivar fly en combate</gray>"));
        inv.setItem(20, toggle("<white>Restringir Pociones</white>", wc.isPotionRestrict(),
                "<gray>Pociones restringidas</gray>", "<gray>durante combate</gray>"));
        inv.setItem(21, toggle("<white>Denegar Ender Pearl</white>", wc.isEnderPearlDeny(),
                "<gray>Bloquear ender pearls</gray>", "<gray>en combate</gray>"));
        inv.setItem(22, numberItem(Material.ENDER_PEARL, "<white>Pearl Cooldown</white>",
                wc.getEnderPearlCooldown(), "seg", "<gray>Cooldown de ender pearls</gray>"));
        inv.setItem(23, toggle("<white>Bloquear Craft</white>", wc.isCraftBlockInCombat(),
                "<gray>No permitir crafteo en combate</gray>"));

        inv.setItem(24, item(Material.PAPER, "<white>Comandos Bloqueados</white>",
                "<yellow>" + wc.getBlockedCommands().size() + " comandos</yellow>",
                "<gray>" + String.join(", ", wc.getBlockedCommands()) + "</gray>",
                "",
                "<dark_gray>Editar en worlds.yml</dark_gray>"));

        // Save
        inv.setItem(40, item(Material.EMERALD, "<green>Guardar Mundo</green>",
                "<gray>Guardar esta configuración</gray>"));

        inv.setItem(45, backButton());

        player.openInventory(inv);
        // Set context AFTER openInventory since openInventory triggers onClose->clearGUI
        setWorldContext(player.getUniqueId(), worldName);
        trackGUI(player.getUniqueId(), GUIType.WORLD_SETTINGS_RESTRICTIONS);
    }

    /**
     * Tab 3: Visual settings (BossBar, ActionBar, Newbie protection)
     */
    public void openWorldSettingsVisual(Player player, String worldName) {
        WorldConfigManager wcm = plugin.getWorldConfigManager();
        WorldCombatConfig wc = wcm.getConfig(worldName);

        Inventory inv = Bukkit.createInventory(null, 54,
                MINI.deserialize(TITLE_PREFIX + "<green>" + worldName + "</green> <dark_gray>|</dark_gray> <light_purple>Visual</light_purple>"));

        fillBorder(inv);

        // Tab bar
        inv.setItem(2, tabInactive(Material.GRAY_DYE, "<gray>General</gray>", "Configuración principal"));
        inv.setItem(4, tabInactive(Material.ORANGE_DYE, "<yellow>Restricciones</yellow>", "Bloqueos en combate"));
        inv.setItem(6, tabActive("Visual", "BossBar, ActionBar, Newbie"));
        inv.setItem(15, sectionPane(Material.LIME_STAINED_GLASS_PANE, "<green>▼</green>"));

        // Content
        inv.setItem(19, toggle("<white>BossBar</white>", wc.isBossBarEnabled(),
                "<gray>Mostrar bossbar de combate</gray>",
                "<gray>en este mundo</gray>"));
        inv.setItem(20, toggle("<white>ActionBar</white>", wc.isActionBarEnabled(),
                "<gray>Mostrar actionbar de combate</gray>",
                "<gray>en este mundo</gray>"));
        inv.setItem(21, sectionPane(Material.PURPLE_STAINED_GLASS_PANE, "<light_purple>🛡 Protección</light_purple>"));
        inv.setItem(22, numberItem(Material.SHIELD, "<white>Newbie Protect</white>",
                wc.getNewbieProtectionMinutes(), "min", "<gray>Minutos de protección</gray>", "<gray>para nuevos jugadores</gray>"));

        // Global visual settings info (read-only, configured in Global Config)
        var cfg = plugin.getConfigManager();
        inv.setItem(24, sectionPane(Material.MAGENTA_STAINED_GLASS_PANE, "<light_purple>🎨 Globales</light_purple>"));
        String flashStatus = cfg.getBoolean("visuals.combat-flash", true) ? "<green>ON</green>" : "<red>OFF</red>";
        String compassStatus = cfg.getBoolean("visuals.compass-tracking", true) ? "<green>ON</green>" : "<red>OFF</red>";
        String particlesStatus = cfg.getBoolean("visuals.combat-particles", true) ? "<green>ON</green>" : "<red>OFF</red>";
        String heartbeatStatus = cfg.getBoolean("visuals.heartbeat", true) ? "<green>ON</green>" : "<red>OFF</red>";
        String killFeedStatus = cfg.getBoolean("visuals.kill-feed", true) ? "<green>ON</green>" : "<red>OFF</red>";
        inv.setItem(25, item(Material.SPYGLASS, "<light_purple>Efectos Globales</light_purple>",
                "<gray>Flash Combate: " + flashStatus + "</gray>",
                "<gray>Brújula Track: " + compassStatus + "</gray>",
                "<gray>Partículas: " + particlesStatus + "</gray>",
                "<gray>Heartbeat: " + heartbeatStatus + "</gray>",
                "<gray>Kill Feed: " + killFeedStatus + "</gray>",
                "",
                "<dark_gray>Editar en Config Global</dark_gray>",
                "<dark_gray>del menú principal</dark_gray>"));

        // Save
        inv.setItem(40, item(Material.EMERALD, "<green>Guardar Mundo</green>",
                "<gray>Guardar esta configuración</gray>"));

        inv.setItem(45, backButton());

        player.openInventory(inv);
        // Set context AFTER openInventory since openInventory triggers onClose->clearGUI
        setWorldContext(player.getUniqueId(), worldName);
        trackGUI(player.getUniqueId(), GUIType.WORLD_SETTINGS_VISUAL);
    }

    // ─── Module List ────────────────────────────────────────────

    public void openModuleList(Player player) {
        CombatModuleRegistry registry = plugin.getModuleRegistry();
        List<CombatModule> modules = new ArrayList<>(registry.getAll());

        int page = getPage(player.getUniqueId());
        int pageSize = 28;
        int totalPages = Math.max(1, (int) Math.ceil((double) modules.size() / pageSize));
        if (page >= totalPages) page = totalPages - 1;
        if (page < 0) page = 0;
        setPage(player.getUniqueId(), page);

        Inventory inv = Bukkit.createInventory(null, 54,
                MINI.deserialize(TITLE_PREFIX + "<aqua>Módulos</aqua>"));

        fillBorder(inv);

        if (modules.isEmpty()) {
            inv.setItem(22, item(Material.STRUCTURE_VOID,
                    "<gray>Sin módulos registrados</gray>",
                    "<dark_gray>Los plugins del ecosistema</dark_gray>",
                    "<dark_gray>se registran automáticamente</dark_gray>",
                    "<dark_gray>(FFA, Duels, Party...)</dark_gray>"));
        } else {
            int start = page * pageSize;
            int end = Math.min(start + pageSize, modules.size());
            int slot = 10;
            for (int i = start; i < end; ) {
                if (slot >= 45) break;
                if (slot % 9 == 0) { slot++; continue; }
                if (slot % 9 == 8) { slot += 2; continue; }

                CombatModule module = modules.get(i);
                String status = module.isEnabled() ? "<green>ACTIVO</green>" : "<red>INACTIVO</red>";
                String typeLabel = module.hasCombatConfig() ? "<yellow>⚔ PVP</yellow>" : "<aqua>ℹ Info</aqua>";
                String clickAction = module.hasCombatConfig()
                        ? "<dark_gray>Click para configurar</dark_gray>"
                        : "<dark_gray>Solo lectura</dark_gray>";
                inv.setItem(slot, item(module.getIcon(),
                        "<white>" + module.getDisplayName() + "</white>",
                        status,
                        typeLabel,
                        "<gray>ID: " + module.getId() + "</gray>",
                        "",
                        clickAction));
                slot++;
                i++;
            }
        }

        // Navigation
        inv.setItem(45, backButton());
        if (page > 0) {
            inv.setItem(48, prevPageButton());
        }
        if (page < totalPages - 1) {
            inv.setItem(50, nextPageButton());
        }

        player.openInventory(inv);
        trackGUI(player.getUniqueId(), GUIType.MODULE_LIST);
    }

    // ─── Module Config ──────────────────────────────────────────

    /**
     * Opens the per-module combat configuration GUI for a PVP module.
     */
    public void openModuleConfig(Player player, String moduleId) {
        CombatModule module = plugin.getModuleRegistry().getModule(moduleId);
        if (module == null || !module.hasCombatConfig()) {
            openModuleList(player);
            return;
        }

        var mc = plugin.getModuleConfigManager().getConfig(moduleId);

        Inventory inv = Bukkit.createInventory(null, 54,
                MINI.deserialize(TITLE_PREFIX + "<white>" + module.getDisplayName() + "</white>"));

        fillBorder(inv);

        // Header
        inv.setItem(4, item(module.getIcon(),
                "<gradient:#EF4444:#F97316><bold>" + module.getDisplayName() + "</bold></gradient>",
                "<gray>Configuración de combate</gray>",
                "<gray>para este módulo</gray>",
                "",
                "<dark_gray>Los ajustes de este módulo</dark_gray>",
                "<dark_gray>anulan los del mundo/globales</dark_gray>"));

        // Row 3: Combat settings
        inv.setItem(19, toggle("<white>Combat Tag</white>", mc.isCombatTagEnabled(),
                "<gray>Habilitar combat tag</gray>",
                "<gray>en " + module.getDisplayName() + "</gray>"));

        String durationLabel = mc.getTagDuration() == -1 ? "GLOBAL" : mc.getTagDuration() + "s";
        Material durationMat = mc.getTagDuration() == -1 ? Material.HOPPER : Material.CLOCK;
        inv.setItem(20, item(durationMat,
                "<white>Duración Tag</white>",
                "<yellow>" + durationLabel + "</yellow>",
                "",
                "<gray>-1 = usar config global/mundo</gray>",
                "<dark_gray>Click izq: +1 | Click der: -1</dark_gray>",
                "<dark_gray>Shift+Click: ±5</dark_gray>"));

        inv.setItem(21, toggle("<white>Keep Inventory</white>", mc.isKeepInventory(),
                "<gray>Mantener items al morir</gray>",
                "<gray>en " + module.getDisplayName() + "</gray>"));

        inv.setItem(22, toggle("<white>Loot Protection</white>", mc.isLootProtection(),
                "<gray>Proteger drops del muerto</gray>",
                "<gray>para el asesino</gray>"));

        inv.setItem(23, cycleItem(Material.SKELETON_SKULL, "<white>Logout Penalty</white>",
                mc.getLogoutPenalty(),
                "<gray>GLOBAL / KILL / DROP_INVENTORY / NONE</gray>"));

        // Row 4: More settings
        inv.setItem(28, toggle("<white>Desactivar Vuelo</white>", mc.isFlyDisabled(),
                "<gray>Quitar fly al entrar en combate</gray>"));

        inv.setItem(29, toggle("<white>Bloquear Comandos</white>", mc.isBlockCommands(),
                "<gray>Bloquear comandos en combate</gray>"));

        // Save + Back
        inv.setItem(40, item(Material.EMERALD, "<green>Guardar Módulo</green>",
                "<gray>Guardar configuración de</gray>",
                "<gray>" + module.getDisplayName() + "</gray>"));

        inv.setItem(45, backButton());

        player.openInventory(inv);
        setWorldContext(player.getUniqueId(), moduleId); // Reuse worldContext to store moduleId
        trackGUI(player.getUniqueId(), GUIType.MODULE_CONFIG);
    }

    // ─── Detection Settings ─────────────────────────────────────

    public void openDetectionSettings(Player player) {
        DetectionManager dm = plugin.getDetectionManager();
        Inventory inv = Bukkit.createInventory(null, 54,
                MINI.deserialize(TITLE_PREFIX + "<red>Detección</red>"));

        fillBorder(inv);

        // Section header
        inv.setItem(4, item(Material.OBSERVER,
                "<gradient:#EF4444:#F97316><bold>Anti-Abuse</bold></gradient>",
                "<gray>Sistema de detección de</gray>",
                "<gray>abuso y multi-cuenta</gray>"));

        // Multi-account section
        inv.setItem(10, toggle("<white>Multi-Cuenta</white>", dm.isMultiAccountEnabled(),
                "<gray>Detecta cuando varias</gray>",
                "<gray>cuentas usan la misma IP</gray>"));

        int suspicionThreshold = plugin.getConfigManager().getInt(
                "detection.multi-account.suspicion-threshold", 2);
        inv.setItem(11, numberItem(Material.SPYGLASS, "<white>Umbral Sospecha</white>",
                suspicionThreshold, "cuentas",
                "<gray>Cuentas simultáneas para</gray>",
                "<gray>generar alerta</gray>"));

        // Separator
        inv.setItem(12, sectionPane(Material.ORANGE_STAINED_GLASS_PANE, "<gold>⚔ Kill Farm</gold>"));

        // Kill farm section
        inv.setItem(13, toggle("<white>Kill Farming</white>", dm.isKillFarmEnabled(),
                "<gray>Detecta kill farming,</gray>",
                "<gray>low gear y location farm</gray>"));

        int sameVictimThreshold = plugin.getConfigManager().getInt(
                "detection.kill-farm.max-kills-same-player", 3);
        inv.setItem(14, numberItem(Material.DIAMOND_SWORD, "<white>Umbral Same Victim</white>",
                sameVictimThreshold, "kills",
                "<gray>Kills al mismo jugador</gray>",
                "<gray>para flag</gray>"));

        int lowGearThreshold = plugin.getConfigManager().getInt(
                "detection.kill-farm.low-gear-threshold", 5);
        inv.setItem(15, numberItem(Material.LEATHER_CHESTPLATE, "<white>Umbral Low Gear</white>",
                lowGearThreshold, "kills",
                "<gray>Kills a víctimas sin</gray>",
                "<gray>equipo para flag</gray>"));

        // Alert channel
        inv.setItem(16, cycleItem(Material.BELL, "<white>Canal Alertas</white>",
                dm.getAlertChannel(),
                "<gray>CHAT / DISCORD / BOTH</gray>"));

        // Sanction tiers section
        inv.setItem(22, sectionPane(Material.RED_STAINED_GLASS_PANE, "<red>⚖ Sanciones</red>"));

        inv.setItem(28, item(Material.IRON_BARS, "<yellow>Tier 1</yellow>",
                "<white>Kick + Anular kills</white>",
                "<gray>Primera ofensa</gray>"));

        inv.setItem(30, item(Material.IRON_BARS, "<gold>Tier 2</gold>",
                "<white>Tempban 1 día + Anular</white>",
                "<gray>Segunda ofensa</gray>"));

        inv.setItem(32, item(Material.IRON_BARS, "<red>Tier 3</red>",
                "<white>Reset stats + Tempban 3d</white>",
                "<gray>Tercera ofensa +</gray>"));

        // Stats
        int totalViolations = dm.getViolationLog().size();
        int flaggedPlayers = dm.getAllViolationCounts().size();
        inv.setItem(34, item(Material.PAPER, "<white>Estadísticas</white>",
                "<yellow>Violaciones: " + totalViolations + "</yellow>",
                "<yellow>Flaggeados: " + flaggedPlayers + "</yellow>"));

        inv.setItem(45, backButton());
        player.openInventory(inv);
        trackGUI(player.getUniqueId(), GUIType.DETECTION_SETTINGS);
    }

    // ─── Suspect List ───────────────────────────────────────────

    public void openSuspectList(Player player) {
        DetectionManager dm = plugin.getDetectionManager();
        Map<UUID, Integer> violations = dm.getAllViolationCounts();

        // Sort by violation count descending
        List<Map.Entry<UUID, Integer>> sorted = new ArrayList<>(violations.entrySet());
        sorted.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));

        int page = getPage(player.getUniqueId());
        int pageSize = 28;
        int totalPages = Math.max(1, (int) Math.ceil((double) sorted.size() / pageSize));
        if (page >= totalPages) page = totalPages - 1;
        if (page < 0) page = 0;
        setPage(player.getUniqueId(), page);

        Inventory inv = Bukkit.createInventory(null, 54,
                MINI.deserialize(TITLE_PREFIX + "<yellow>Sospechosos</yellow> <dark_gray>(" + (page + 1) + "/" + totalPages + ")</dark_gray>"));

        fillBorder(inv);

        if (sorted.isEmpty()) {
            inv.setItem(22, item(Material.STRUCTURE_VOID,
                    "<green>Sin sospechosos</green>",
                    "<gray>No se han detectado</gray>",
                    "<gray>violaciones activas</gray>"));
        } else {
            int start = page * pageSize;
            int end = Math.min(start + pageSize, sorted.size());
            int slot = 10;
            for (int i = start; i < end; ) {
                if (slot >= 45) break;
                if (slot % 9 == 0) { slot++; continue; }
                if (slot % 9 == 8) { slot += 2; continue; }

                var entry = sorted.get(i);
                UUID uuid = entry.getKey();
                int count = entry.getValue();
                String name = Bukkit.getOfflinePlayer(uuid).getName();
                if (name == null) name = uuid.toString().substring(0, 8);

                Material head = count >= 3 ? Material.REDSTONE : (count >= 2 ? Material.ORANGE_DYE : Material.YELLOW_DYE);
                String tier = count >= 3 ? "<red>TIER 3+</red>" : (count >= 2 ? "<gold>TIER 2</gold>" : "<yellow>TIER 1</yellow>");

                // Check alts
                Set<UUID> alts = dm.getMultiAccountDetector().getDetectedAlts(uuid);
                List<String> lore = new ArrayList<>();
                lore.add(tier);
                lore.add("<gray>Ofensas: " + count + "</gray>");
                if (!alts.isEmpty()) {
                    lore.add("");
                    lore.add("<gray>Alts detectados:</gray>");
                    for (UUID alt : alts) {
                        String altName = Bukkit.getOfflinePlayer(alt).getName();
                        lore.add("<dark_gray> - " + (altName != null ? altName : alt.toString().substring(0, 8)) + "</dark_gray>");
                    }
                }
                lore.add("");
                lore.add("<dark_gray>Click: Limpiar flags</dark_gray>");

                inv.setItem(slot, item(head, "<white>" + name + "</white>", lore));
                slot++;
                i++;
            }
        }

        // Navigation
        inv.setItem(45, backButton());
        if (page > 0) {
            inv.setItem(48, prevPageButton());
        }
        if (page < totalPages - 1) {
            inv.setItem(50, nextPageButton());
        }

        player.openInventory(inv);
        trackGUI(player.getUniqueId(), GUIType.SUSPECT_LIST);
    }

    // ─── Log Viewer ─────────────────────────────────────────────

    public void openLogViewer(Player player) {
        DetectionManager dm = plugin.getDetectionManager();
        int page = getPage(player.getUniqueId());
        int pageSize = 28; // 4 rows of 7

        List<AbuseRecord> records = dm.getViolationLog(page, pageSize);
        int totalRecords = dm.getViolationLog().size();
        int totalPages = Math.max(1, (int) Math.ceil((double) totalRecords / pageSize));

        Inventory inv = Bukkit.createInventory(null, 54,
                MINI.deserialize(TITLE_PREFIX + "<white>Logs (" + (page + 1) + "/" + totalPages + ")</white>"));

        fillBorder(inv);

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM HH:mm");

        int slot = 10;
        for (AbuseRecord record : records) {
            if (slot >= 45) break;
            if (slot % 9 == 0) { slot++; continue; }
            if (slot % 9 == 8) { slot += 2; continue; }

            Material icon = switch (record.type()) {
                case MULTI_ACCOUNT -> Material.COMMAND_BLOCK_MINECART;
                case KILL_FARMING -> Material.DIAMOND_SWORD;
                case LOW_GEAR_FARM -> Material.LEATHER_CHESTPLATE;
                case LOCATION_FARM -> Material.COMPASS;
            };

            inv.setItem(slot, item(icon,
                    "<white>" + record.playerName() + "</white>",
                    "<yellow>" + record.type().name() + "</yellow>",
                    "<gray>" + record.details() + "</gray>",
                    "<dark_gray>" + sdf.format(new Date(record.timestamp())) + "</dark_gray>"));
            slot++;
        }

        if (records.isEmpty()) {
            inv.setItem(22, item(Material.STRUCTURE_VOID,
                    "<gray>Sin registros</gray>",
                    "<dark_gray>No hay violaciones</dark_gray>",
                    "<dark_gray>registradas aún</dark_gray>"));
        }

        // Navigation
        inv.setItem(45, backButton());
        if (page > 0) {
            inv.setItem(48, item(Material.ARROW, "<gray>◀ Página Anterior</gray>"));
        }
        if (page < totalPages - 1) {
            inv.setItem(50, item(Material.ARROW, "<gray>Página Siguiente ▶</gray>"));
        }

        player.openInventory(inv);
        trackGUI(player.getUniqueId(), GUIType.LOG_VIEWER);
    }

    // ─── Global Config (Tabbed) ───────────────────────────────

    public void openGlobalConfig(Player player) {
        openGlobalConfigCombat(player);
    }

    /**
     * Tab 1: Combat Tag core + Cheat Prevention
     */
    public void openGlobalConfigCombat(Player player) {
        var cfg = plugin.getConfigManager();
        Inventory inv = Bukkit.createInventory(null, 54,
                MINI.deserialize(TITLE_PREFIX + "<light_purple>Config Global</light_purple> <dark_gray>|</dark_gray> <white>Combat Tag</white>"));

        fillBorder(inv);

        // Tab bar (row 1)
        inv.setItem(2, tabActive("Combat Tag", "Tag y cheat prevention"));
        inv.setItem(4, tabInactive(Material.MAGENTA_DYE, "<light_purple>Visual</light_purple>", "Efectos visuales y sonidos"));
        inv.setItem(6, tabInactive(Material.ORANGE_DYE, "<yellow>NPC & Penalty</yellow>", "NPC, castigos y revenge"));
        // Tab underline
        inv.setItem(11, sectionPane(Material.LIME_STAINED_GLASS_PANE, "<green>▼</green>"));

        // Row 3: Core tag settings
        inv.setItem(19, numberItem(Material.CLOCK, "<white>Duración Default</white>",
                cfg.getInt("combat-tag.default-duration", 15), "seg",
                "<gray>Duración base del tag</gray>"));
        inv.setItem(20, numberItem(Material.BLAZE_ROD, "<white>Duración Máxima</white>",
                cfg.getInt("combat-tag.max-duration", 30), "seg",
                "<gray>Máximo al extender</gray>"));
        inv.setItem(21, toggle("<white>Extender al Golpear</white>",
                cfg.getBoolean("combat-tag.extend-on-hit", true),
                "<gray>Reinicia el timer al golpear</gray>"));

        // Separator
        inv.setItem(22, sectionPane(Material.RED_STAINED_GLASS_PANE, "<red>🛡 Prevención</red>"));

        inv.setItem(23, toggle("<white>Bloquear Vuelo</white>",
                cfg.getBoolean("combat-tag.block-flight", true),
                "<gray>Cancelar fly en combate</gray>"));
        inv.setItem(24, toggle("<white>Bloquear Comandos</white>",
                cfg.getBoolean("combat-tag.block-commands", true),
                "<gray>Bloquear home, spawn, etc</gray>"));
        inv.setItem(25, toggle("<white>Bloquear Enderpearl</white>",
                cfg.getBoolean("combat-tag.block-enderpearl", true),
                "<gray>Sin ender pearl en combate</gray>"));

        // Row 4: More blocks
        inv.setItem(28, toggle("<white>Bloquear Chorus</white>",
                cfg.getBoolean("combat-tag.block-chorus", true),
                "<gray>Chorus fruit bloqueado</gray>"));
        inv.setItem(29, toggle("<white>Bloquear Teleport</white>",
                cfg.getBoolean("combat-tag.block-teleport", true),
                "<gray>Sin tp en combate</gray>"));
        inv.setItem(30, toggle("<white>Bloquear Elytra</white>",
                cfg.getBoolean("combat-tag.block-elytra", true),
                "<gray>Elytra cancelada</gray>"));
        inv.setItem(31, toggle("<white>Bloquear Gamemode</white>",
                cfg.getBoolean("combat-tag.block-gamemode", true),
                "<gray>Sin cambio de modo</gray>"));
        inv.setItem(32, toggle("<white>Bloquear Riptide</white>",
                cfg.getBoolean("combat-tag.block-riptide", true),
                "<gray>Tridente riptide bloqueado</gray>"));

        // Bottom
        inv.setItem(45, backButton());
        inv.setItem(49, item(Material.EMERALD, "<green>Guardar y Recargar</green>",
                "<gray>Guardar config.yml y</gray>", "<gray>recargar todo</gray>"));

        player.openInventory(inv);
        trackGUI(player.getUniqueId(), GUIType.GLOBAL_CONFIG);
    }

    /**
     * Tab 2: Visual & Effects
     */
    public void openGlobalConfigVisual(Player player) {
        var cfg = plugin.getConfigManager();
        Inventory inv = Bukkit.createInventory(null, 54,
                MINI.deserialize(TITLE_PREFIX + "<light_purple>Config Global</light_purple> <dark_gray>|</dark_gray> <light_purple>Visual</light_purple>"));

        fillBorder(inv);

        // Tab bar
        inv.setItem(2, tabInactive(Material.GRAY_DYE, "<gray>Combat Tag</gray>", "Tag y cheat prevention"));
        inv.setItem(4, tabActive("Visual", "Efectos visuales y sonidos"));
        inv.setItem(6, tabInactive(Material.ORANGE_DYE, "<yellow>NPC & Penalty</yellow>", "NPC, castigos y revenge"));
        inv.setItem(13, sectionPane(Material.LIME_STAINED_GLASS_PANE, "<green>▼</green>"));

        // Row 3: HUD
        inv.setItem(19, toggle("<white>BossBar Global</white>",
                cfg.getBoolean("combat-tag.bossbar.enabled", true),
                "<gray>Mostrar bossbar durante</gray>", "<gray>el combate</gray>"));
        inv.setItem(20, toggle("<white>ActionBar Global</white>",
                cfg.getBoolean("combat-tag.actionbar.enabled", true),
                "<gray>Mostrar actionbar durante</gray>", "<gray>el combate</gray>"));

        // Separator
        inv.setItem(21, sectionPane(Material.MAGENTA_STAINED_GLASS_PANE, "<light_purple>🎨 Efectos</light_purple>"));

        inv.setItem(22, toggle("<white>Flash de Combate</white>",
                cfg.getBoolean("visuals.combat-flash", true),
                "<gray>Título rojo ⚔ al entrar</gray>", "<gray>en combate</gray>"));
        inv.setItem(23, toggle("<white>Brújula Tracking</white>",
                cfg.getBoolean("visuals.compass-tracking", true),
                "<gray>Brújula apunta al</gray>", "<gray>enemigo automáticamente</gray>"));
        inv.setItem(24, toggle("<white>Partículas Combate</white>",
                cfg.getBoolean("visuals.combat-particles", true),
                "<gray>Partículas rojas sobre</gray>", "<gray>jugadores en combate</gray>"));
        inv.setItem(25, toggle("<white>Heartbeat</white>",
                cfg.getBoolean("visuals.heartbeat", true),
                "<gray>Sonido de latido a</gray>", "<gray>baja vida en combate</gray>"));

        // Row 4
        inv.setItem(28, toggle("<white>Kill Feed</white>",
                cfg.getBoolean("visuals.kill-feed", true),
                "<gray>Kill feed mejorado con</gray>", "<gray>arma y distancia</gray>"));
        inv.setItem(29, toggle("<white>Hit Effect</white>",
                cfg.getBoolean("visuals.hit-effect", true),
                "<gray>Efecto visual al golpear</gray>"));

        // Bottom
        inv.setItem(45, backButton());
        inv.setItem(49, item(Material.EMERALD, "<green>Guardar y Recargar</green>",
                "<gray>Guardar config.yml y</gray>", "<gray>recargar todo</gray>"));

        player.openInventory(inv);
        trackGUI(player.getUniqueId(), GUIType.GLOBAL_CONFIG_VISUAL);
    }

    /**
     * Tab 3: NPC, Penalty & Revenge
     */
    public void openGlobalConfigNPC(Player player) {
        var cfg = plugin.getConfigManager();
        Inventory inv = Bukkit.createInventory(null, 54,
                MINI.deserialize(TITLE_PREFIX + "<light_purple>Config Global</light_purple> <dark_gray>|</dark_gray> <yellow>NPC & Penalty</yellow>"));

        fillBorder(inv);

        // Tab bar
        inv.setItem(2, tabInactive(Material.GRAY_DYE, "<gray>Combat Tag</gray>", "Tag y cheat prevention"));
        inv.setItem(4, tabInactive(Material.MAGENTA_DYE, "<light_purple>Visual</light_purple>", "Efectos visuales y sonidos"));
        inv.setItem(6, tabActive("NPC & Penalty", "NPC, castigos y revenge"));
        inv.setItem(15, sectionPane(Material.LIME_STAINED_GLASS_PANE, "<green>▼</green>"));

        // Row 3: NPC settings
        inv.setItem(19, toggle("<white>NPC Enabled</white>",
                cfg.getBoolean("combat-npc.enabled", true),
                "<gray>Spawn NPC al logout</gray>", "<gray>en combate</gray>"));
        inv.setItem(20, numberItem(Material.ARMOR_STAND, "<white>NPC Duración</white>",
                cfg.getInt("combat-npc.duration", 30), "seg",
                "<gray>Tiempo de vida del NPC</gray>"));

        // Separator
        inv.setItem(21, sectionPane(Material.ORANGE_STAINED_GLASS_PANE, "<gold>⚠ Penalización</gold>"));

        inv.setItem(22, toggle("<white>Penalización Log</white>",
                cfg.getBoolean("combat-log.penalty.enabled", true),
                "<gray>Castigar al desconectarse</gray>", "<gray>en combate</gray>"));
        inv.setItem(23, numberItem(Material.GOLD_INGOT, "<white>Pérdida Money</white>",
                cfg.getInt("combat-log.penalty.money-loss", 500), "$",
                "<gray>Dinero perdido al loguearse</gray>"));
        inv.setItem(24, numberItem(Material.REDSTONE, "<white>Pérdida Power</white>",
                cfg.getInt("combat-log.penalty.power-loss", 20), "pts",
                "<gray>Power perdido al loguearse</gray>"));

        // Separator
        inv.setItem(25, sectionPane(Material.PURPLE_STAINED_GLASS_PANE, "<light_purple>⚡ Revenge</light_purple>"));

        // Row 4: Revenge
        inv.setItem(28, toggle("<white>Revenge Enabled</white>",
                cfg.getBoolean("revenge.enabled", true),
                "<gray>Sistema de venganza</gray>", "<gray>bonus al vengar una muerte</gray>"));
        inv.setItem(29, numberItem(Material.DIAMOND, "<white>Bonus Money</white>",
                cfg.getInt("revenge.money-bonus", 100), "$",
                "<gray>Dinero extra por venganza</gray>"));
        inv.setItem(30, toggle("<white>Mensaje Revenge</white>",
                cfg.getBoolean("revenge.message", true),
                "<gray>Notificar al jugador</gray>", "<gray>del bonus de venganza</gray>"));

        // Bottom
        inv.setItem(45, backButton());
        inv.setItem(49, item(Material.EMERALD, "<green>Guardar y Recargar</green>",
                "<gray>Guardar config.yml y</gray>", "<gray>recargar todo</gray>"));

        player.openInventory(inv);
        trackGUI(player.getUniqueId(), GUIType.GLOBAL_CONFIG_NPC);
    }

    // ─── Active Combats Dashboard ───────────────────────────────

    public void openActiveCombats(Player player) {
        var tagMgr = plugin.getTagManager();
        Map<UUID, com.ethernova.combat.tag.CombatTag> activeTags = tagMgr.getActiveTags();
        List<Map.Entry<UUID, com.ethernova.combat.tag.CombatTag>> entries = new ArrayList<>(activeTags.entrySet());

        int page = getPage(player.getUniqueId());
        int pageSize = 28;
        int totalPages = Math.max(1, (int) Math.ceil((double) entries.size() / pageSize));
        if (page >= totalPages) page = totalPages - 1;
        if (page < 0) page = 0;
        setPage(player.getUniqueId(), page);

        Inventory inv = Bukkit.createInventory(null, 54,
                MINI.deserialize(TITLE_PREFIX + "<gold>Combates Activos</gold> <dark_gray>(" + entries.size() + ")</dark_gray>"));

        fillBorder(inv);

        if (entries.isEmpty()) {
            inv.setItem(22, item(Material.STRUCTURE_VOID,
                    "<green>Sin combates activos</green>",
                    "<gray>No hay jugadores en</gray>",
                    "<gray>combate actualmente</gray>",
                    "",
                    "<dark_gray>Auto-actualiza cada 3s</dark_gray>"));
        } else {
            int start = page * pageSize;
            int end = Math.min(start + pageSize, entries.size());
            int slot = 10;
            for (int i = start; i < end; ) {
                if (slot >= 45) break;
                if (slot % 9 == 0) { slot++; continue; }
                if (slot % 9 == 8) { slot += 2; continue; }

                var entry = entries.get(i);
                UUID playerUuid = entry.getKey();
                com.ethernova.combat.tag.CombatTag tag = entry.getValue();

                Player taggedPlayer = Bukkit.getPlayer(playerUuid);
                Player enemyPlayer = Bukkit.getPlayer(tag.getEnemy());

                String playerName = taggedPlayer != null ? taggedPlayer.getName() : "Offline";
                String enemyName = enemyPlayer != null ? enemyPlayer.getName() : "?";
                int remaining = tag.getRemainingSeconds();
                float healthPct = taggedPlayer != null ? (float) taggedPlayer.getHealth() / 20f * 100f : 0;

                String timeStr = remaining <= 5 ? "<red>" + remaining + "s</red>"
                        : (remaining <= 10 ? "<yellow>" + remaining + "s</yellow>" : "<green>" + remaining + "s</green>");
                String healthStr = healthPct <= 25 ? "<red>" + String.format("%.0f", healthPct) + "%</red>"
                        : (healthPct <= 50 ? "<yellow>" + String.format("%.0f", healthPct) + "%</yellow>" : "<green>" + String.format("%.0f", healthPct) + "%</green>");

                Material icon = remaining <= 5 ? Material.RED_STAINED_GLASS_PANE :
                        (remaining <= 10 ? Material.YELLOW_STAINED_GLASS_PANE : Material.LIME_STAINED_GLASS_PANE);

                List<String> lore = new ArrayList<>();
                lore.add("<gray>vs</gray> <white>" + enemyName + "</white>");
                lore.add("");
                lore.add("<gray>Tiempo: " + timeStr + "</gray>");
                lore.add("<gray>Vida: " + healthStr + "</gray>");
                lore.add("<gray>Perfil: <yellow>" + tag.getProfile() + "</yellow></gray>");
                if (taggedPlayer != null) {
                    lore.add("<gray>Mundo: <white>" + taggedPlayer.getWorld().getName() + "</white></gray>");
                }
                lore.add("");
                lore.add("<dark_gray>Click: Teleportar</dark_gray>");
                lore.add("<dark_gray>Shift+Click: Forzar untag</dark_gray>");

                inv.setItem(slot, item(icon, "<white>" + playerName + "</white>", lore));
                slot++;
                i++;
            }
        }

        // Navigation
        inv.setItem(45, backButton());
        if (page > 0) {
            inv.setItem(48, prevPageButton());
        }
        inv.setItem(49, item(Material.COMPASS, "<yellow>Actualizar</yellow>",
                "<dark_gray>Click para refrescar</dark_gray>"));
        if (page < totalPages - 1) {
            inv.setItem(50, nextPageButton());
        }

        player.openInventory(inv);
        trackGUI(player.getUniqueId(), GUIType.ACTIVE_COMBATS);

        // Auto-refresh every 3 seconds
        UUID uuid = player.getUniqueId();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline() && getOpenGUI(uuid) == GUIType.ACTIVE_COMBATS) {
                openActiveCombats(p);
            }
        }, 60L);
    }
}
