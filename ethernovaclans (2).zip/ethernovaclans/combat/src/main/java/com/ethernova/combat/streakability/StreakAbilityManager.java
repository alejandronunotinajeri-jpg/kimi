package com.ethernova.combat.streakability;

import com.ethernova.combat.EthernovaCombat;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Streak Abilities. At certain killstreaks, players unlock temporary abilities.
 * These are configurable buff/debuff loadouts per streak milestone.
 */
public class StreakAbilityManager {

    private final EthernovaCombat combat;
    private final MiniMessage mini = MiniMessage.miniMessage();
    private final List<StreakAbility> abilities = new ArrayList<>();
    private final Map<UUID, Set<Integer>> activatedStreaks = new ConcurrentHashMap<>();

    public StreakAbilityManager(EthernovaCombat combat) {
        this.combat = combat;
        loadAbilities();
    }

    private void loadAbilities() {
        abilities.clear();
        var config = combat.getConfigManager().getConfig();
        var section = config.getConfigurationSection("streak-abilities");
        if (section == null) {
            // Defaults
            abilities.add(new StreakAbility(3, "Velocidad I", PotionEffectType.SPEED, 0, 600, "<aqua>⚡ ¡Velocidad desbloqueada!"));
            abilities.add(new StreakAbility(5, "Regeneración I", PotionEffectType.REGENERATION, 0, 400, "<green>❤ ¡Regeneración desbloqueada!"));
            abilities.add(new StreakAbility(7, "Fuerza I", PotionEffectType.STRENGTH, 0, 400, "<red>💪 ¡Fuerza desbloqueada!"));
            abilities.add(new StreakAbility(10, "Resistencia I", PotionEffectType.RESISTANCE, 0, 600, "<blue>🛡 ¡Resistencia desbloqueada!"));
            abilities.add(new StreakAbility(15, "Velocidad II", PotionEffectType.SPEED, 1, 600, "<aqua>⚡⚡ ¡Velocidad II!"));
            abilities.add(new StreakAbility(20, "Absorción", PotionEffectType.ABSORPTION, 1, 600, "<gold>✨ ¡Absorción desbloqueada!"));
            return;
        }

        for (String key : section.getKeys(false)) {
            var entry = section.getConfigurationSection(key);
            if (entry == null) continue;
            int streak = entry.getInt("streak", 3);
            String name = entry.getString("name", key);
            String effectName = entry.getString("effect", "SPEED");
            int amplifier = entry.getInt("amplifier", 0);
            int durationTicks = entry.getInt("duration-ticks", 600);
            String message = entry.getString("message", "<yellow>¡Habilidad desbloqueada!");
            try {
                PotionEffectType type = PotionEffectType.getByKey(org.bukkit.NamespacedKey.minecraft(effectName.toLowerCase()));
                if (type != null) {
                    abilities.add(new StreakAbility(streak, name, type, amplifier, durationTicks, message));
                }
            } catch (Exception e) {
                combat.getLogger().log(Level.WARNING, "Invalid streak ability effect '" + effectName + "' in config", e);
            }
        }

        abilities.sort(Comparator.comparingInt(a -> a.streak));
    }

    /**
     * Check and apply streak abilities for the player at the given streak count.
     */
    public void checkAndApply(Player player, int currentStreak) {
        UUID uuid = player.getUniqueId();
        Set<Integer> activated = activatedStreaks.computeIfAbsent(uuid, k -> ConcurrentHashMap.newKeySet());

        for (StreakAbility ability : abilities) {
            if (currentStreak >= ability.streak && !activated.contains(ability.streak)) {
                activated.add(ability.streak);
                player.addPotionEffect(new PotionEffect(ability.effect, ability.durationTicks, ability.amplifier, false, true, true));
                player.sendMessage(mini.deserialize(ability.message));
                combat.getCore().getSoundManager().play(player, "streak");
            }
        }
    }

    /** Reset activated streaks for a player (on death or quit). */
    public void reset(UUID uuid) {
        activatedStreaks.remove(uuid);
    }

    /** Get abilities for display. */
    public List<StreakAbility> getAbilities() {
        return Collections.unmodifiableList(abilities);
    }

    public static class StreakAbility {
        public final int streak;
        public final String name;
        public final PotionEffectType effect;
        public final int amplifier;
        public final int durationTicks;
        public final String message;

        public StreakAbility(int streak, String name, PotionEffectType effect, int amplifier, int durationTicks, String message) {
            this.streak = streak;
            this.name = name;
            this.effect = effect;
            this.amplifier = amplifier;
            this.durationTicks = durationTicks;
            this.message = message;
        }
    }
}
