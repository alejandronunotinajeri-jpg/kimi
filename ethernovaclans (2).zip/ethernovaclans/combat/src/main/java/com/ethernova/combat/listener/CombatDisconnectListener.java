package com.ethernova.combat.listener;

import com.ethernova.combat.EthernovaCombat;
import com.ethernova.combat.npc.CombatNPC;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class CombatDisconnectListener implements Listener {

    private final EthernovaCombat plugin;

    public CombatDisconnectListener(EthernovaCombat plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.HIGH)
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        plugin.getLogoutManager().cancelLogout(player.getUniqueId());

        if (plugin.getTagManager().isInCombat(player)) {
            plugin.getTagManager().untag(player);

            if (plugin.getConfigManager().getBoolean("combat-npc.enabled", true)) {
                try {
                    plugin.getNpcManager().spawnNPC(player);
                    // Only clear inventory AFTER NPC was successfully spawned (inventory cloned inside spawnNPC)
                    player.getInventory().clear();
                    player.getInventory().setArmorContents(new ItemStack[4]);
                } catch (Exception e) {
                    plugin.getLogger().warning("Failed to spawn combat NPC for " + player.getName() + ": " + e.getMessage());
                    // Do NOT clear inventory — NPC didn't spawn, player keeps their items
                }
            }

            plugin.getPenaltyManager().applyCombatLogPenalty(player.getUniqueId(), player.getName());
            plugin.getDeathEffectManager().broadcastCombatLogDeath(player.getName());
        }

        plugin.getProfileManager().removeProfile(player.getUniqueId());
        plugin.getKillStreakManager().cleanupPlayer(player.getUniqueId());
        plugin.getRewardManager().cleanupPlayer(player.getUniqueId());
        plugin.getAbuseManager().cleanupPlayer(player.getUniqueId());
        plugin.getNewbieManager().removeProtection(player.getUniqueId());
        if (plugin.getComboManager() != null) {
            plugin.getComboManager().clear(player.getUniqueId());
        }
        if (plugin.getDeathRecapManager() != null) {
            plugin.getDeathRecapManager().handleQuit(player.getUniqueId());
        }
        if (plugin.getRevengeManager() != null) {
            plugin.getRevengeManager().clear(player.getUniqueId());
        }
        if (plugin.getDetectionManager() != null) {
            plugin.getDetectionManager().onPlayerQuit(player.getUniqueId());
        }
        if (plugin.getStreakAbilityManager() != null) {
            plugin.getStreakAbilityManager().reset(player.getUniqueId());
        }

        // Save and unload advanced weapon stats
        if (plugin.getAdvancedStatsManager() != null) {
            plugin.getAdvancedStatsManager().unloadPlayer(player.getUniqueId());
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        // Detection tracking
        if (plugin.getDetectionManager() != null) {
            plugin.getDetectionManager().onPlayerLogin(player);
        }

        // Newbie check
        plugin.getNewbieManager().checkNewPlayer(player);

        // Profile detection
        plugin.getProfileManager().detectProfile(player);

        // Load advanced weapon stats from DB
        if (plugin.getAdvancedStatsManager() != null) {
            plugin.getAdvancedStatsManager().loadPlayer(player.getUniqueId());
        }

        // NPC reconnect
        CombatNPC npc = plugin.getNpcManager().handleReconnect(player.getUniqueId());
        if (npc != null) {
            if (npc.isKilled() && plugin.getConfigManager().getBoolean("combat-npc.kill-means-death", true)) {
                plugin.getMessageManager().send(player, "npc.killed");
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (player.isOnline()) player.setHealth(0);
                }, 5L);
            } else if (!npc.isKilled()) {
                if (npc.getInventory() != null) player.getInventory().setContents(npc.getInventory());
                if (npc.getArmor() != null) player.getInventory().setArmorContents(npc.getArmor());
                plugin.getMessageManager().send(player, "npc.despawned");
            }
        }
    }
}
