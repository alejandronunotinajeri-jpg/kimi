package com.ethernova.combat.cheat;

import com.ethernova.combat.EthernovaCombat;

public class CheatPreventionManager {

    private final EthernovaCombat plugin;

    public CheatPreventionManager(EthernovaCombat plugin) { this.plugin = plugin; }

    public boolean blockFlight() {
        return plugin.getConfigManager().getConfig().getBoolean("combat-tag.block-flight", true);
    }

    public boolean blockCommands() {
        return plugin.getConfigManager().getConfig().getBoolean("combat-tag.block-commands", true);
    }

    public boolean blockEnderPearl() {
        return plugin.getConfigManager().getConfig().getBoolean("combat-tag.block-enderpearl", true);
    }

    public boolean blockChorusFruit() {
        return plugin.getConfigManager().getConfig().getBoolean("combat-tag.block-chorus", true);
    }

    public boolean blockTeleport() {
        return plugin.getConfigManager().getConfig().getBoolean("combat-tag.block-teleport", true);
    }

    public boolean blockElytra() {
        return plugin.getConfigManager().getConfig().getBoolean("combat-tag.block-elytra", true);
    }

    public boolean blockGamemodeChange() {
        return plugin.getConfigManager().getConfig().getBoolean("combat-tag.block-gamemode", true);
    }

    public boolean blockRiptide() {
        return plugin.getConfigManager().getConfig().getBoolean("combat-tag.block-riptide", true);
    }

    public java.util.List<String> getBlockedCommands() {
        return plugin.getConfigManager().getConfig().getStringList("combat-tag.blocked-commands");
    }
}
