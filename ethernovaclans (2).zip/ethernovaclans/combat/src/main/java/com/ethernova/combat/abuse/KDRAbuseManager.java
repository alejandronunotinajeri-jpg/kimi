package com.ethernova.combat.abuse;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.entity.Player;

import java.net.InetSocketAddress;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class KDRAbuseManager {

    private final EthernovaCombat plugin;
    private final Map<UUID, List<KillRecord>> recentKills = new ConcurrentHashMap<>();

    public KDRAbuseManager(EthernovaCombat plugin) { this.plugin = plugin; }

    public boolean isAbusiveKill(Player killer, Player victim) {
        if (!plugin.getConfigManager().getConfig().getBoolean("anti-abuse.enabled", true)) return false;

        // Same IP check
        if (plugin.getConfigManager().getConfig().getBoolean("anti-abuse.block-same-ip", true)) {
            InetSocketAddress kAddr = killer.getAddress();
            InetSocketAddress vAddr = victim.getAddress();
            if (kAddr != null && vAddr != null &&
                    kAddr.getAddress().getHostAddress().equals(vAddr.getAddress().getHostAddress())) {
                plugin.getMessageManager().send(killer, "abuse.same-ip");
                return true;
            }
        }

        // Repeat kill check
        int maxRepeat = plugin.getConfigManager().getConfig().getInt("anti-abuse.max-repeat-kills", 3);
        long window = plugin.getConfigManager().getConfig().getLong("anti-abuse.repeat-window-minutes", 30) * 60_000L;

        List<KillRecord> kills = recentKills.computeIfAbsent(killer.getUniqueId(), k -> new CopyOnWriteArrayList<>());
        long now = System.currentTimeMillis();

        // Clean old
        kills.removeIf(r -> now - r.time > window);

        long count = kills.stream().filter(r -> r.victim.equals(victim.getUniqueId())).count();
        if (count >= maxRepeat) {
            plugin.getMessageManager().send(killer, "abuse.repeat-kill");
            return true;
        }

        kills.add(new KillRecord(victim.getUniqueId(), now));
        return false;
    }

    public void cleanupPlayer(UUID uuid) {
        recentKills.remove(uuid);
    }

    private record KillRecord(UUID victim, long time) {}
}
