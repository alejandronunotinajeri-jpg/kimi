package com.ethernova.combat.tag;

import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

/**
 * Fired when a player is about to be combat tagged.
 * Other plugins can cancel this to prevent the tag.
 */
public class CombatTagEvent extends Event implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();

    private final Player player;
    private final Player enemy;
    private int duration;
    private final String profile;
    private boolean cancelled;

    public CombatTagEvent(Player player, Player enemy, int duration, String profile) {
        this.player = player;
        this.enemy = enemy;
        this.duration = duration;
        this.profile = profile;
    }

    public Player getPlayer() { return player; }
    public Player getEnemy() { return enemy; }
    public int getDuration() { return duration; }
    public void setDuration(int duration) { this.duration = duration; }
    public String getProfile() { return profile; }

    @Override public boolean isCancelled() { return cancelled; }
    @Override public void setCancelled(boolean cancelled) { this.cancelled = cancelled; }
    @Override public @NotNull HandlerList getHandlers() { return HANDLERS; }
    public static HandlerList getHandlerList() { return HANDLERS; }
}
