package com.ethernova.combat.detection;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Central detection manager that coordinates MultiAccountDetector and KillFarmDetector.
 * Integrates with the SanctionManager for automated punishments.
 */
public class DetectionManager {

    private final EthernovaCombat plugin;
    private final MultiAccountDetector multiAccountDetector;
    private final KillFarmDetector killFarmDetector;
    private final SanctionManager sanctionManager;

    /** History of all detected violations (capped to prevent unbounded growth) */
    private final List<AbuseRecord> violationLog = Collections.synchronizedList(new ArrayList<>());
    private static final int MAX_VIOLATION_LOG_SIZE = 1000;

    /** Per-player violation counts for sanction escalation */
    private final Map<UUID, Integer> violationCounts = new ConcurrentHashMap<>();

    // Config toggles
    private boolean multiAccountEnabled = true;
    private boolean killFarmEnabled = true;
    private String alertChannel = "BOTH"; // CHAT, DISCORD, BOTH

    public DetectionManager(EthernovaCombat plugin) {
        this.plugin = plugin;
        this.multiAccountDetector = new MultiAccountDetector(plugin);
        this.killFarmDetector = new KillFarmDetector(plugin);
        this.sanctionManager = new SanctionManager(plugin);
        loadConfig();

        // Schedule periodic cleanup every 10 minutes to prevent unbounded memory growth
        Bukkit.getScheduler().runTaskTimer(plugin, multiAccountDetector::periodicCleanup, 20L * 600, 20L * 600);
    }

    private void loadConfig() {
        var cfg = plugin.getConfigManager().getConfig();
        multiAccountEnabled = cfg.getBoolean("detection.multi-account.enabled", true);
        killFarmEnabled = cfg.getBoolean("detection.kill-farm.enabled", true);
        alertChannel = cfg.getString("detection.alert-channel", "BOTH");
    }

    /**
     * Called when a player logs in. Tracks IP for multi-account detection.
     */
    public void onPlayerLogin(Player player) {
        if (multiAccountEnabled) {
            multiAccountDetector.onLogin(player);

            // Check for simultaneous accounts
            int simultaneous = multiAccountDetector.getSimultaneousAccounts(player);
            int threshold = plugin.getConfigManager().getInt("detection.multi-account.suspicion-threshold", 2);
            if (simultaneous > threshold) {
                alertAdmins(plugin.getMessageManager().get("detection.multi-account",
                        "{player}", player.getName(), "{count}", String.valueOf(simultaneous)),
                        AbuseRecord.AbuseType.MULTI_ACCOUNT);
            }
        }
    }

    /**
     * Called on player quit.
     */
    public void onPlayerQuit(UUID uuid) {
        multiAccountDetector.onQuit(uuid);
        violationCounts.remove(uuid);
        sanctionManager.cleanupPlayer(uuid);
    }

    /**
     * Main detection check — called on every kill.
     * Returns true if the kill should be NULLIFIED (abusive).
     */
    public boolean checkKill(Player killer, Player victim) {
        boolean abusive = false;
        AbuseRecord.AbuseType detectedType = null;
        String details = "";

        // ── Multi-account check ──────────────────────────────
        if (multiAccountEnabled && multiAccountDetector.isSameIpKill(killer, victim)) {
            detectedType = AbuseRecord.AbuseType.MULTI_ACCOUNT;
            details = plugin.getMessageManager().get("detection.same-ip", "{killer}", killer.getName(), "{victim}", victim.getName());
            abusive = true;
        }

        // ── Kill farming check ───────────────────────────────
        if (!abusive && killFarmEnabled) {
            AbuseRecord.AbuseType farmType = killFarmDetector.checkKill(
                    killer, victim, victim.getLocation());
            if (farmType != null) {
                detectedType = farmType;
                details = switch (farmType) {
                    case KILL_FARMING -> plugin.getMessageManager().get("detection.kill-farming", "{killer}", killer.getName(), "{victim}", victim.getName());
                    case LOW_GEAR_FARM -> plugin.getMessageManager().get("detection.low-gear");
                    case LOCATION_FARM -> plugin.getMessageManager().get("detection.location-farming");
                    default -> plugin.getMessageManager().get("detection.farming-detected");
                };
                abusive = true;
            }
        }

        if (abusive && detectedType != null) {
            AbuseRecord record = new AbuseRecord(
                    killer.getUniqueId(), killer.getName(), detectedType, details, System.currentTimeMillis());
            violationLog.add(record);
            // Cap log size to prevent unbounded memory growth
            while (violationLog.size() > MAX_VIOLATION_LOG_SIZE) {
                violationLog.remove(0);
            }

            // Escalate violations
            int count = violationCounts.merge(killer.getUniqueId(), 1, Integer::sum);

            // Alert admins
            alertAdmins("⚠ " + details + " (Ofensa #" + count + ")", detectedType);

            // Apply sanction
            sanctionManager.applySanction(killer, count, detectedType, details);

            plugin.getLogger().warning("[Detection] " + details);
        }

        return abusive;
    }

    /**
     * Alert online admins about a detection.
     */
    private void alertAdmins(String message, AbuseRecord.AbuseType type) {
        if ("CHAT".equals(alertChannel) || "BOTH".equals(alertChannel)) {
            String formatted = plugin.getMessageManager().get("detection.admin-alert", "{message}", message);
            for (Player admin : Bukkit.getOnlinePlayers()) {
                if (admin.hasPermission("ethernova.combat.admin")) {
                    plugin.getMessageManager().sendRaw(admin, formatted);
                }
            }
        }
        // Discord integration would go here if DISCORD or BOTH
    }

    // ── Accessors ────────────────────────────────────────────

    public MultiAccountDetector getMultiAccountDetector() { return multiAccountDetector; }
    public KillFarmDetector getKillFarmDetector() { return killFarmDetector; }
    public SanctionManager getSanctionManager() { return sanctionManager; }

    public List<AbuseRecord> getViolationLog() {
        return Collections.unmodifiableList(violationLog);
    }

    public List<AbuseRecord> getViolationLog(int page, int pageSize) {
        synchronized (violationLog) {
            int total = violationLog.size();
            if (page * pageSize >= total) return List.of();
            int start = Math.max(0, total - (page + 1) * pageSize);
            int end = Math.min(total, start + pageSize);
            if (start >= end) return List.of();
            return new ArrayList<>(violationLog.subList(start, end));
        }
    }

    public int getViolationCount(UUID uuid) {
        return violationCounts.getOrDefault(uuid, 0);
    }

    public void clearViolations(UUID uuid) {
        violationCounts.remove(uuid);
        sanctionManager.clearRecord(uuid);
    }

    public Map<UUID, Integer> getAllViolationCounts() {
        return Collections.unmodifiableMap(violationCounts);
    }

    // ── Config toggles (for GUI) ─────────────────────────────

    public boolean isMultiAccountEnabled() { return multiAccountEnabled; }
    public void setMultiAccountEnabled(boolean v) { this.multiAccountEnabled = v; }
    public boolean isKillFarmEnabled() { return killFarmEnabled; }
    public void setKillFarmEnabled(boolean v) { this.killFarmEnabled = v; }
    public String getAlertChannel() { return alertChannel; }
    public void setAlertChannel(String v) { this.alertChannel = v; }
    public void cycleAlertChannel() {
        alertChannel = switch (alertChannel) {
            case "CHAT" -> "DISCORD";
            case "DISCORD" -> "BOTH";
            default -> "CHAT";
        };
    }
}
