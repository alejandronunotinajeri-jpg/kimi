package com.ethernova.combat.module;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.plugin.Plugin;

import java.util.Collections;
import java.util.List;
import java.util.logging.Logger;

/**
 * Auto-detects ecosystem plugins and registers them as CombatModules
 * so they appear in the admin GUI module list.
 * PVP modules (FFA, Duels, Ranked, Party, Clans) get configurable combat settings.
 * Utility modules (Cosmetics, Progression, Discord) are info-only.
 */
public class EcosystemModuleDetector {

    /** Definition of a plugin to detect and register. */
    private record PluginDef(String pluginName, String moduleId, String displayName, Material icon, boolean hasCombat) {}

    /** Modules that have PVP combat and need tag configuration */
    private static final List<PluginDef> ECOSYSTEM_PLUGINS = List.of(
            new PluginDef("EthernovaFFA",         "ffa",         "Free For All",       Material.IRON_SWORD,        true),
            new PluginDef("EthernovaDuels",       "duels",       "Duelos",             Material.DIAMOND_SWORD,     true),
            new PluginDef("EthernovaRanked",      "ranked",      "Ranked",             Material.NETHERITE_SWORD,   true),
            new PluginDef("EthernovaParty",       "party",       "Party Games",        Material.CAKE,              true),
            new PluginDef("EthernovaClans",       "clans",       "Clanes",             Material.SHIELD,            true),
            new PluginDef("EthernovaCosmetics",   "cosmetics",   "Cosméticos",         Material.NETHER_STAR,       false),
            new PluginDef("EthernovaProgression", "progression", "Progresión",         Material.EXPERIENCE_BOTTLE, false),
            new PluginDef("EthernovaDiscord",     "discord",     "Discord",            Material.BELL,              false)
    );

    private final EthernovaCombat plugin;

    public EcosystemModuleDetector(EthernovaCombat plugin) {
        this.plugin = plugin;
    }

    /**
     * Scans for ecosystem plugins and registers detected ones as CombatModules.
     */
    public void detect() {
        Logger log = plugin.getLogger();
        CombatModuleRegistry registry = plugin.getModuleRegistry();
        ModuleConfigManager configManager = plugin.getModuleConfigManager();
        int found = 0;

        for (PluginDef def : ECOSYSTEM_PLUGINS) {
            Plugin target = Bukkit.getPluginManager().getPlugin(def.pluginName);
            if (target != null && target.isEnabled()) {
                if (def.hasCombat) {
                    // Ensure config exists for this module
                    configManager.getConfig(def.moduleId);
                    registry.register(new PvpModule(def, target));
                } else {
                    registry.register(new InfoModule(def, target));
                }
                found++;
                String type = def.hasCombat ? "PVP" : "info";
                log.info("  ✔ Módulo detectado: " + def.displayName + " [" + type + "]");
            }
        }

        if (found == 0) {
            log.info("  ⚠ No se detectaron módulos del ecosistema");
        } else {
            // Save config to create modules.yml with defaults for new PVP modules
            configManager.save();
            log.info("  → " + found + " módulo(s) del ecosistema conectado(s)");
        }
    }

    /**
     * A PVP module with configurable combat settings.
     */
    private static class PvpModule implements CombatModule {
        private final PluginDef def;
        private final Plugin target;

        PvpModule(PluginDef def, Plugin target) {
            this.def = def;
            this.target = target;
        }

        @Override public String getId() { return def.moduleId; }
        @Override public String getDisplayName() { return def.displayName; }
        @Override public Material getIcon() { return def.icon; }
        @Override public boolean isEnabled() { return target.isEnabled(); }
        @Override public boolean hasCombatConfig() { return true; }
        @Override public List<ModuleSetting> getSettings() { return Collections.emptyList(); }
        @Override public void buildConfigGUI(Inventory inv, String worldName) {}
        @Override public void handleClick(Player admin, int slot, ClickType click, String worldName) {}
    }

    /**
     * An info-only module (no combat settings).
     */
    private static class InfoModule implements CombatModule {
        private final PluginDef def;
        private final Plugin target;

        InfoModule(PluginDef def, Plugin target) {
            this.def = def;
            this.target = target;
        }

        @Override public String getId() { return def.moduleId; }
        @Override public String getDisplayName() { return def.displayName; }
        @Override public Material getIcon() { return def.icon; }
        @Override public boolean isEnabled() { return target.isEnabled(); }
        @Override public boolean hasCombatConfig() { return false; }
        @Override public List<ModuleSetting> getSettings() { return Collections.emptyList(); }
        @Override public void buildConfigGUI(Inventory inv, String worldName) {}
        @Override public void handleClick(Player admin, int slot, ClickType click, String worldName) {}
    }
}
