package com.ethernova.combat.world;

import java.util.*;

/**
 * Per-world combat configuration. Each world can override global settings.
 */
public class WorldCombatConfig {

    private final String worldName;
    private boolean combatTagEnabled = true;
    private int tagDuration = 15;
    private boolean keepInventory = false;
    private String logoutPenalty = "KILL"; // KILL, DROP_INVENTORY, NONE
    private boolean flyDisabled = true;
    private boolean npcSpawnOnLogout = true;
    private boolean potionRestrict = false;
    private boolean bossBarEnabled = true;
    private boolean actionBarEnabled = true;
    private int newbieProtectionMinutes = 30;
    private boolean enderPearlDeny = false;
    private int enderPearlCooldown = 16;
    private boolean lootProtection = true;
    private int lootProtectionSeconds = 30;
    private boolean craftBlockInCombat = false;
    private List<String> blockedCommands = new ArrayList<>(List.of(
            "home", "spawn", "tpa", "tpaccept", "warp", "sethome", "back"
    ));

    public WorldCombatConfig(String worldName) {
        this.worldName = worldName;
    }

    // ── Getters ──────────────────────────────────────────────
    public String getWorldName() { return worldName; }
    public boolean isCombatTagEnabled() { return combatTagEnabled; }
    public int getTagDuration() { return tagDuration; }
    public boolean isKeepInventory() { return keepInventory; }
    public String getLogoutPenalty() { return logoutPenalty; }
    public boolean isFlyDisabled() { return flyDisabled; }
    public boolean isNpcSpawnOnLogout() { return npcSpawnOnLogout; }
    public boolean isPotionRestrict() { return potionRestrict; }
    public boolean isBossBarEnabled() { return bossBarEnabled; }
    public boolean isActionBarEnabled() { return actionBarEnabled; }
    public int getNewbieProtectionMinutes() { return newbieProtectionMinutes; }
    public boolean isEnderPearlDeny() { return enderPearlDeny; }
    public int getEnderPearlCooldown() { return enderPearlCooldown; }
    public boolean isLootProtection() { return lootProtection; }
    public int getLootProtectionSeconds() { return lootProtectionSeconds; }
    public boolean isCraftBlockInCombat() { return craftBlockInCombat; }
    public List<String> getBlockedCommands() { return blockedCommands; }

    // ── Setters ──────────────────────────────────────────────
    public void setCombatTagEnabled(boolean v) { this.combatTagEnabled = v; }
    public void setTagDuration(int v) { this.tagDuration = Math.max(1, Math.min(120, v)); }
    public void setKeepInventory(boolean v) { this.keepInventory = v; }
    public void setLogoutPenalty(String v) { this.logoutPenalty = v; }
    public void setFlyDisabled(boolean v) { this.flyDisabled = v; }
    public void setNpcSpawnOnLogout(boolean v) { this.npcSpawnOnLogout = v; }
    public void setPotionRestrict(boolean v) { this.potionRestrict = v; }
    public void setBossBarEnabled(boolean v) { this.bossBarEnabled = v; }
    public void setActionBarEnabled(boolean v) { this.actionBarEnabled = v; }
    public void setNewbieProtectionMinutes(int v) { this.newbieProtectionMinutes = Math.max(0, v); }
    public void setEnderPearlDeny(boolean v) { this.enderPearlDeny = v; }
    public void setEnderPearlCooldown(int v) { this.enderPearlCooldown = Math.max(0, v); }
    public void setLootProtection(boolean v) { this.lootProtection = v; }
    public void setLootProtectionSeconds(int v) { this.lootProtectionSeconds = Math.max(0, v); }
    public void setCraftBlockInCombat(boolean v) { this.craftBlockInCombat = v; }
    public void setBlockedCommands(List<String> v) { this.blockedCommands = new ArrayList<>(v); }

    /** Cycle logout penalty: KILL → DROP_INVENTORY → NONE → KILL */
    public void cycleLogoutPenalty() {
        logoutPenalty = switch (logoutPenalty) {
            case "KILL" -> "DROP_INVENTORY";
            case "DROP_INVENTORY" -> "NONE";
            default -> "KILL";
        };
    }
}
