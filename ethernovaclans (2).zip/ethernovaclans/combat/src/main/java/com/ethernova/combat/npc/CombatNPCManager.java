package com.ethernova.combat.npc;

import com.ethernova.combat.EthernovaCombat;
import com.ethernova.core.EthernovaCore;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class CombatNPCManager {

    private final EthernovaCombat plugin;
    private final EthernovaCore core;
    private final Map<UUID, CombatNPC> npcs = new ConcurrentHashMap<>();
    /** Reverse map: entity UUID → owner UUID for O(1) lookup */
    private final Map<UUID, UUID> entityToOwner = new ConcurrentHashMap<>();
    private final boolean citizensAvailable;

    public CombatNPCManager(EthernovaCombat plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
        this.citizensAvailable = Bukkit.getPluginManager().getPlugin("Citizens") != null;
        if (citizensAvailable) {
            plugin.getLogger().info("Citizens detected — combat NPCs will use player skins.");
        } else {
            plugin.getLogger().info("Citizens not found — combat NPCs will use Zombie fallback.");
        }
    }

    public boolean isCitizensAvailable() {
        return citizensAvailable;
    }

    public void spawnNPC(Player player) {
        // Remove any pre-existing NPC for this player (prevents ghost entities)
        CombatNPC existing = npcs.remove(player.getUniqueId());
        if (existing != null) {
            entityToOwner.remove(existing.getEntityUuid());
            removeNPCEntity(existing);
        }

        int duration = plugin.getConfigManager().getInt("combat-npc.duration", 30);

        ItemStack[] inventoryContents = player.getInventory().getContents().clone();
        ItemStack[] armorContents = player.getInventory().getArmorContents().clone();
        double health = player.getHealth();

        CombatNPC npc;
        if (citizensAvailable) {
            npc = spawnCitizensNPC(player, duration, health, inventoryContents, armorContents);
        } else {
            npc = spawnZombieNPC(player, duration, health, inventoryContents, armorContents);
        }
        if (npc == null) return;

        npcs.put(player.getUniqueId(), npc);
        entityToOwner.put(npc.getEntityUuid(), player.getUniqueId());

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            CombatNPC timedOut = npcs.get(player.getUniqueId());
            if (timedOut != null && !timedOut.isKilled()) {
                removeNPCEntity(timedOut);
                entityToOwner.remove(timedOut.getEntityUuid());
                npcs.remove(player.getUniqueId());
                Player p = Bukkit.getPlayer(player.getUniqueId());
                if (p != null) plugin.getMessageManager().send(p, "npc.despawned");
            }
        }, 20L * duration);
    }

    // ── Citizens NPC (player skin) ──────────────────────────────────────

    private CombatNPC spawnCitizensNPC(Player player, int duration, double health,
                                       ItemStack[] inventory, ItemStack[] armor) {
        try {
            CitizensNPCHelper.SpawnResult result =
                    CitizensNPCHelper.spawnPlayerNPC(plugin, core, player, health, armor);
            if (result == null) {
                plugin.getLogger().warning("Citizens NPC spawn returned null, falling back to Zombie.");
                return spawnZombieNPC(player, duration, health, inventory, armor);
            }
            return new CombatNPC(player.getUniqueId(), result.entityUuid(), duration,
                    inventory, armor, player.getLocation().clone(), result.citizensNpcId());
        } catch (Exception e) {
            plugin.getLogger().warning("Citizens NPC spawn failed, falling back to Zombie: " + e.getMessage());
            return spawnZombieNPC(player, duration, health, inventory, armor);
        }
    }

    // ── Zombie fallback ─────────────────────────────────────────────────

    private CombatNPC spawnZombieNPC(Player player, int duration, double health,
                                     ItemStack[] inventory, ItemStack[] armor) {
        Zombie zombie = player.getWorld().spawn(player.getLocation(), Zombie.class, z -> {
            z.setAI(false);
            z.setCustomNameVisible(true);
            z.customName(core.getMessageManager().getMiniMessage().deserialize(
                    plugin.getMessageManager().get("npc.name-format", "{player}", player.getName())));
            z.setHealth(Math.min(health, z.getMaxHealth()));
            z.setInvulnerable(false);
            z.setSilent(true);
            z.setAdult();
            z.setCanPickupItems(false);

            // Fire resistance so the zombie doesn't burn in sunlight
            z.addPotionEffect(new PotionEffect(
                    PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, false, false, false));

            // Visual equipment matching the player
            if (armor.length > 3 && armor[3] != null) z.getEquipment().setHelmet(armor[3]);
            if (armor.length > 2 && armor[2] != null) z.getEquipment().setChestplate(armor[2]);
            if (armor.length > 1 && armor[1] != null) z.getEquipment().setLeggings(armor[1]);
            if (armor.length > 0 && armor[0] != null) z.getEquipment().setBoots(armor[0]);
            ItemStack mainHand = player.getInventory().getItemInMainHand();
            if (mainHand != null && !mainHand.getType().isAir()) {
                z.getEquipment().setItemInMainHand(mainHand);
            }
            // Prevent vanilla equipment drops (we manage drops ourselves)
            z.getEquipment().setHelmetDropChance(0f);
            z.getEquipment().setChestplateDropChance(0f);
            z.getEquipment().setLeggingsDropChance(0f);
            z.getEquipment().setBootsDropChance(0f);
            z.getEquipment().setItemInMainHandDropChance(0f);
        });

        return new CombatNPC(player.getUniqueId(), zombie.getUniqueId(), duration,
                inventory, armor, player.getLocation().clone(), -1);
    }

    // ── NPC lifecycle ───────────────────────────────────────────────────

    public void onNPCKilled(UUID ownerUuid, Player killer) {
        CombatNPC npc = npcs.get(ownerUuid);
        if (npc == null) return;
        npc.setKilled(true);

        if (plugin.getConfigManager().getBoolean("combat-npc.drop-items", true)) {
            Entity entity = Bukkit.getEntity(npc.getEntityUuid());
            org.bukkit.Location dropLoc = entity != null ? entity.getLocation()
                    : (killer != null ? killer.getLocation() : npc.getSpawnLocation());

            if (dropLoc != null) {
                if (npc.getInventory() != null) {
                    for (ItemStack item : npc.getInventory()) {
                        if (item != null && !item.getType().isAir())
                            dropLoc.getWorld().dropItemNaturally(dropLoc, item);
                    }
                }
                if (npc.getArmor() != null) {
                    for (ItemStack item : npc.getArmor()) {
                        if (item != null && !item.getType().isAir())
                            dropLoc.getWorld().dropItemNaturally(dropLoc, item);
                    }
                }

                if (killer != null) {
                    org.bukkit.Location finalDropLoc = dropLoc;
                    Bukkit.getScheduler().runTaskLater(plugin, () -> {
                        List<org.bukkit.entity.Item> nearbyItems = new ArrayList<>();
                        finalDropLoc.getWorld().getNearbyEntities(finalDropLoc, 3, 3, 3).forEach(e -> {
                            if (e instanceof org.bukkit.entity.Item item && item.getTicksLived() <= 5) nearbyItems.add(item);
                        });
                        plugin.getLootManager().protectLoot(killer.getUniqueId(), nearbyItems);
                    }, 2L);
                }
            }
        }

        removeNPCEntity(npc);
        entityToOwner.remove(npc.getEntityUuid());
        npcs.remove(ownerUuid);
    }

    public boolean isCombatNPC(Entity entity) {
        return entityToOwner.containsKey(entity.getUniqueId());
    }

    public UUID getOwnerFromNPC(Entity entity) {
        return entityToOwner.get(entity.getUniqueId());
    }

    public CombatNPC handleReconnect(UUID playerUuid) {
        CombatNPC npc = npcs.remove(playerUuid);
        if (npc != null) {
            entityToOwner.remove(npc.getEntityUuid());
            if (!npc.isKilled()) {
                removeNPCEntity(npc);
            }
        }
        return npc;
    }

    public void removeAll() {
        for (Map.Entry<UUID, CombatNPC> entry : npcs.entrySet()) {
            UUID ownerUuid = entry.getKey();
            CombatNPC npc = entry.getValue();

            // Restore inventory to owner if they're online (server shutdown)
            Player owner = Bukkit.getPlayer(ownerUuid);
            if (owner != null && owner.isOnline() && !npc.isKilled()) {
                owner.getInventory().setContents(npc.getInventory());
                if (npc.getArmor() != null) {
                    owner.getInventory().setArmorContents(npc.getArmor());
                }
            }

            removeNPCEntity(npc);
        }
        npcs.clear();
        entityToOwner.clear();
    }

    // ── Entity removal helper ───────────────────────────────────────────

    private void removeNPCEntity(CombatNPC npc) {
        if (citizensAvailable && npc.getCitizensNpcId() >= 0) {
            try {
                CitizensNPCHelper.destroyNPC(npc.getCitizensNpcId());
                return;
            } catch (Exception e) {
                plugin.getLogger().warning("Failed to destroy Citizens NPC #"
                        + npc.getCitizensNpcId() + ": " + e.getMessage());
            }
        }
        // Zombie fallback or Citizens cleanup failure
        Entity entity = Bukkit.getEntity(npc.getEntityUuid());
        if (entity != null) entity.remove();
    }
}
