package com.ethernova.combat.tag;

import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

public class CombatTag {

    private final UUID player;
    private volatile UUID enemy;
    private final AtomicInteger remainingSeconds;
    private volatile int maxDuration;
    private volatile String profile;

    public CombatTag(UUID player, UUID enemy, int durationSeconds, String profile) {
        this.player = player;
        this.enemy = enemy;
        this.remainingSeconds = new AtomicInteger(durationSeconds);
        this.maxDuration = durationSeconds;
        this.profile = profile;
    }

    public void tick() { remainingSeconds.decrementAndGet(); }
    public boolean isExpired() { return remainingSeconds.get() <= 0; }

    public void extend(int seconds, int max) {
        int newVal = Math.min(max, remainingSeconds.get() + seconds);
        remainingSeconds.set(newVal);
        maxDuration = Math.max(maxDuration, newVal);
    }

    public UUID getPlayer() { return player; }
    public UUID getEnemy() { return enemy; }
    public void setEnemy(UUID enemy) { this.enemy = enemy; }
    public int getRemainingSeconds() { return Math.max(0, remainingSeconds.get()); }
    public int getMaxDuration() { return maxDuration; }
    public String getProfile() { return profile; }
    public void setProfile(String profile) { this.profile = profile; }
}
