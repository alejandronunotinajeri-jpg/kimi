package com.ethernova.combat.bounty;

import com.ethernova.combat.EthernovaCombat;
import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.PlayerSettingsGui;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.stream.Collectors;

import org.bukkit.configuration.file.YamlConfiguration;

/**
 * BountyManager — Sistema completo de recompensas por cabeza.
 * Replica exacta del original UltimateFFA BountyManager.
 *
 * - Bounty manual: /bounty <jugador> <cantidad>
 * - Auto-bounty: se activa automáticamente en rachas (5+ kills, cada 5)
 * - GUI: 54 slots con cabezas de jugador, ranking
 * - Cobro al matar con efectos épicos (títulos, partículas doradas, broadcast)
 * - Anuncios periódicos de bounties activas
 * - Persistencia en YAML (sobrevive restarts)
 * - XP bonus al cobrar bounty
 */
public class BountyManager {

    private final EthernovaCombat combat;

    // Bounties activas: UUID del target → datos de bounty
    private final Map<UUID, BountyData> activeBounties = new ConcurrentHashMap<>();

    // Config
    private final int minBounty;
    private final int maxBounty;
    private final int autoBountyStreak;
    private final int autoBountyBase;
    private final int autoBountyPerKill;
    private final int autoBountyInterval;
    private final int announceIntervalTicks;

    // Persistence file
    private final File bountyFile;
    private YamlConfiguration bountyConfig;

    public static final String GUI_TITLE = "§c§l☠ BOUNTIES ACTIVAS ☠";

    public BountyManager(EthernovaCombat combat) {
        this.combat = combat;

        var cfg = combat.getConfigManager().getConfig();
        minBounty = cfg.getInt("bounties.min-amount", 100);
        maxBounty = cfg.getInt("bounties.max-amount", 500000);
        autoBountyStreak = cfg.getInt("bounties.auto.min-streak", 5);
        autoBountyBase = cfg.getInt("bounties.auto.base-amount", 500);
        autoBountyPerKill = cfg.getInt("bounties.auto.per-kill-bonus", 200);
        autoBountyInterval = cfg.getInt("bounties.auto.streak-interval", 5);
        announceIntervalTicks = cfg.getInt("bounties.announce-interval-ticks", 6000);

        bountyFile = new File(combat.getDataFolder(), "bounties.yml");
        loadBounties();
        startAnnouncementTask();
    }

    // ══════════════════════════════════════════
    //              BOUNTY MANUAL
    // ══════════════════════════════════════════

    /**
     * Place a bounty from one player on another.
     * @return true if placed successfully
     */
    public boolean placeBounty(Player placer, Player target, int amount) {
        if (placer.equals(target)) {
            placer.sendMessage("§c§l✗ §cNo puedes ponerte precio a ti mismo.");
            return false;
        }
        if (amount < minBounty) {
            placer.sendMessage("§c§l✗ §cLa bounty mínima es §6$" + minBounty);
            return false;
        }
        if (amount > maxBounty) {
            placer.sendMessage("§c§l✗ §cLa bounty máxima es §6$" + maxBounty);
            return false;
        }

        EthernovaCore core = combat.getCore();
        // Atomic withdraw
        if (!core.getEconomyHook().withdraw(placer, amount)) {
            placer.sendMessage("§c§l✗ §cNo tienes suficiente dinero.");
            return false;
        }

        // Accumulate bounty
        UUID targetUUID = target.getUniqueId();
        BountyData data = activeBounties.computeIfAbsent(targetUUID, k -> new BountyData(target.getName()));
        int newTotal = data.totalAmount.addAndGet(amount);
        data.contributors.merge(placer.getUniqueId(), amount, Integer::sum);
        data.targetName = target.getName();

        saveBounty(targetUUID, data);

        // Global announcement (skip players with hideBountyAlerts)
        String bountyMsg = "§c§l☠ BOUNTY §8» §e" + placer.getName() + " §fpuso §6$" + amount
                + " §fpor la cabeza de §c" + target.getName()
                + " §7[Total: §6$" + newTotal + "§7]";
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!PlayerSettingsGui.getSetting(combat.getCore(), p.getUniqueId(), "hideBountyAlerts")) {
                p.sendMessage(bountyMsg);
            }
        }

        // Effects
        placer.playSound(placer.getLocation(), Sound.BLOCK_ANVIL_USE, 0.8f, 1.2f);
        target.playSound(target.getLocation(), Sound.ENTITY_WITHER_AMBIENT, 0.5f, 1.5f);
        target.sendMessage("§c§l☠ §c¡Alguien ha puesto precio a tu cabeza! §7Bounty total: §6$" + newTotal);
        target.sendTitle("§c§l☠ BOUNTY", "§fAlguien quiere tu cabeza...", 10, 40, 10);

        return true;
    }

    /**
     * Place a bounty using UUIDs (for command compatibility).
     */
    public boolean placeBounty(UUID placerUuid, String placerName, UUID targetUuid, double amount) {
        Player placer = Bukkit.getPlayer(placerUuid);
        Player target = Bukkit.getPlayer(targetUuid);
        if (placer == null || target == null) return false;
        return placeBounty(placer, target, (int) amount);
    }

    // ══════════════════════════════════════════
    //           AUTO-BOUNTY (RACHAS)
    // ══════════════════════════════════════════

    /**
     * Called when a player reaches a killstreak milestone.
     * Places a server-funded auto-bounty.
     */
    public void checkAutoBounty(Player killer, int currentStreak) {
        if (currentStreak < autoBountyStreak) return;
        if (currentStreak % autoBountyInterval != 0) return;

        UUID killerUUID = killer.getUniqueId();
        int autoBountyAmount = autoBountyBase + (currentStreak - autoBountyStreak) * autoBountyPerKill;

        BountyData data = activeBounties.computeIfAbsent(killerUUID, k -> new BountyData(killer.getName()));
        int newAutoTotal = data.totalAmount.addAndGet(autoBountyAmount);
        data.isAutoBounty = true;
        data.targetName = killer.getName();

        saveBounty(killerUUID, data);

        String autoBountyMsg = "§4§l☠ AUTO-BOUNTY §8» §c" + killer.getName()
                + " §ftiene §c" + currentStreak + " kills §fde racha. §6$" + newAutoTotal
                + " §fpor su cabeza!";
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!PlayerSettingsGui.getSetting(combat.getCore(), p.getUniqueId(), "hideBountyAlerts")) {
                p.sendMessage(autoBountyMsg);
            }
        }

        killer.playSound(killer.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.5f, 1.5f);

        // Visual on target: red particles above head
        killer.getWorld().spawnParticle(Particle.DUST, killer.getLocation().add(0, 2.5, 0),
                30, 0.5, 0.3, 0.5, 0, new Particle.DustOptions(Color.RED, 1.5f));
    }

    // ══════════════════════════════════════════
    //          COBRO AL MATAR
    // ══════════════════════════════════════════

    /**
     * Called when a player dies. Gives bounty to killer.
     * @return total amount claimed (0 if no bounty)
     */
    public double claimBounties(UUID killerUuid, UUID victimUuid) {
        BountyData data = activeBounties.remove(victimUuid);
        if (data == null || data.totalAmount.get() <= 0) return 0;

        int amount = data.totalAmount.get();
        EthernovaCore core = combat.getCore();

        // Give money
        core.getEconomyHook().deposit(Bukkit.getOfflinePlayer(killerUuid), amount);

        // Give XP bonus
        var killerProfile = core.getProfileManager().getProfile(killerUuid);
        if (killerProfile != null) {
            killerProfile.addXP(50); // Standard XP bonus for collecting bounty
        }

        // Clear persistence
        clearBountySave(victimUuid);

        Player killer = Bukkit.getPlayer(killerUuid);
        Player victim = Bukkit.getPlayer(victimUuid);
        String victimName = victim != null ? victim.getName() : data.targetName;

        // Epic broadcast (skip players with hideBountyAlerts)
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!PlayerSettingsGui.getSetting(combat.getCore(), p.getUniqueId(), "hideBountyAlerts")) {
                p.sendMessage("");
                p.sendMessage("§4§l§m    §c§l ☠ BOUNTY COBRADA ☠ §4§l§m    ");
                p.sendMessage("§e" + (killer != null ? killer.getName() : "???") + " §fcobró §6§l$" + amount
                        + " §fpor eliminar a §c" + victimName);
                p.sendMessage("§4§l§m                                    ");
                p.sendMessage("");
            }
        }

        // Effects on killer
        if (killer != null) {
            killer.playSound(killer.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1.2f);
            killer.playSound(killer.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 0.8f);
            killer.sendTitle("§6§l$" + amount, "§a§lBOUNTY COBRADA", 5, 50, 10);

            // Gold particle rain
            new BukkitRunnable() {
                int ticks = 0;
                @Override
                public void run() {
                    if (ticks >= 40 || !killer.isOnline()) { cancel(); return; }
                    Location loc = killer.getLocation().add(0, 2, 0);
                    killer.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, loc, 5, 0.5, 0.3, 0.5, 0.1);
                    ticks += 2;
                }
            }.runTaskTimer(combat, 0L, 2L);
        }

        return amount;
    }

    // ══════════════════════════════════════════
    //            GUI DE BOUNTIES
    // ══════════════════════════════════════════

    public void openBountyGUI(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, GUI_TITLE);

        // Disco glass borders
        fillDiscoGlass(inv);

        // Info item (slot 4)
        ItemStack info = new ItemStack(Material.GOLD_INGOT);
        ItemMeta infoMeta = info.getItemMeta();
        infoMeta.setDisplayName("§6§l☠ Sistema de Bounties");
        List<String> infoLore = new ArrayList<>();
        infoLore.add("");
        infoLore.add("§7Bounties activas: §e" + activeBounties.size());
        infoLore.add("§7Total en juego: §6$" + getTotalBountyPool());
        infoLore.add("");
        infoLore.add("§fColoca una bounty con:");
        infoLore.add("§e/bounty <jugador> <cantidad>");
        infoLore.add("");
        infoLore.add("§cAuto-bounty se activa con " + autoBountyStreak + "+ kills");
        infoMeta.setLore(infoLore);
        info.setItemMeta(infoMeta);
        inv.setItem(4, info);

        // List bounties sorted by amount (max 21)
        List<Map.Entry<UUID, BountyData>> sorted = activeBounties.entrySet().stream()
                .sorted((a, b) -> Integer.compare(b.getValue().totalAmount.get(), a.getValue().totalAmount.get()))
                .limit(21)
                .collect(Collectors.toList());

        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};

        for (int i = 0; i < sorted.size() && i < slots.length; i++) {
            Map.Entry<UUID, BountyData> entry = sorted.get(i);
            BountyData data = entry.getValue();
            UUID targetUUID = entry.getKey();

            ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta skullMeta = (SkullMeta) skull.getItemMeta();

            Player targetPlayer = Bukkit.getPlayer(targetUUID);
            if (targetPlayer != null) {
                skullMeta.setOwningPlayer(targetPlayer);
            } else {
                OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(targetUUID);
                skullMeta.setOwningPlayer(offlinePlayer);
            }

            String rankPrefix;
            if (i == 0) rankPrefix = "§6§l#1 ";
            else if (i == 1) rankPrefix = "§f§l#2 ";
            else if (i == 2) rankPrefix = "§c§l#3 ";
            else rankPrefix = "§7#" + (i + 1) + " ";

            skullMeta.setDisplayName(rankPrefix + "§c" + data.targetName);
            List<String> lore = new ArrayList<>();
            lore.add("");
            lore.add("§7Bounty: §6§l$" + data.totalAmount.get());
            lore.add("§7Contribuidores: §e" + data.contributors.size());
            if (data.isAutoBounty) {
                lore.add("§c§l⚡ AUTO-BOUNTY (racha)");
            }
            lore.add("");
            boolean isOnline = targetPlayer != null && targetPlayer.isOnline();
            lore.add("§7Estado: " + (isOnline ? "§a§lONLINE" : "§c§lOFFLINE"));
            if (isOnline && targetPlayer != null) {
                var stateStr = combat.getCore().getStateManager().getState(targetUUID);
                var mapStr = combat.getCore().getStateManager().getMap(targetUUID);
                lore.add("§7Modo: §e" + stateStr);
                if (!mapStr.isEmpty()) {
                    lore.add("§7Arena: §e" + mapStr);
                }
            }
            lore.add("");
            lore.add("§7¡Elimínalo para cobrar la bounty!");
            skullMeta.setLore(lore);
            skull.setItemMeta(skullMeta);

            inv.setItem(slots[i], skull);
        }

        if (sorted.isEmpty()) {
            ItemStack empty = new ItemStack(Material.BARRIER);
            ItemMeta emptyMeta = empty.getItemMeta();
            emptyMeta.setDisplayName("§7§lNo hay bounties activas");
            List<String> emptyLore = new ArrayList<>();
            emptyLore.add("");
            emptyLore.add("§7Sé el primero en poner una:");
            emptyLore.add("§e/bounty <jugador> <cantidad>");
            emptyMeta.setLore(emptyLore);
            empty.setItemMeta(emptyMeta);
            inv.setItem(22, empty);
        }

        // Player's own bounty (if any)
        BountyData myBounty = activeBounties.get(player.getUniqueId());
        if (myBounty != null) {
            ItemStack myHead = new ItemStack(Material.SKELETON_SKULL);
            ItemMeta myMeta = myHead.getItemMeta();
            myMeta.setDisplayName("§c§l☠ Tu Bounty Activa");
            List<String> myLore = new ArrayList<>();
            myLore.add("");
            myLore.add("§7Tienes §6$" + myBounty.totalAmount.get() + " §7por tu cabeza");
            myLore.add("§c¡Cuidado! Te están buscando...");
            myMeta.setLore(myLore);
            myHead.setItemMeta(myMeta);
            inv.setItem(49, myHead);
        }

        // Back button
        ItemStack back = new ItemStack(Material.ARROW);
        ItemMeta backMeta = back.getItemMeta();
        backMeta.setDisplayName("§c← Volver");
        back.setItemMeta(backMeta);
        inv.setItem(45, back);

        player.openInventory(inv);
    }

    /**
     * Handle GUI click.
     */
    public void handleGUIClick(Player player, int slot, ItemStack item) {
        if (item == null || !item.hasItemMeta()) return;
        String name = ChatColor.stripColor(item.getItemMeta().getDisplayName());
        if (name != null && (name.contains("Volver") || name.contains("Cerrar"))) {
            player.closeInventory();
        }
    }

    private void fillDiscoGlass(Inventory inv) {
        Material[] glasses = {
                Material.RED_STAINED_GLASS_PANE, Material.ORANGE_STAINED_GLASS_PANE,
                Material.YELLOW_STAINED_GLASS_PANE, Material.LIME_STAINED_GLASS_PANE,
                Material.CYAN_STAINED_GLASS_PANE, Material.BLUE_STAINED_GLASS_PANE,
                Material.PURPLE_STAINED_GLASS_PANE, Material.MAGENTA_STAINED_GLASS_PANE,
                Material.PINK_STAINED_GLASS_PANE, Material.WHITE_STAINED_GLASS_PANE
        };
        Random random = new Random();
        int size = inv.getSize();
        int cols = 9;
        for (int i = 0; i < size; i++) {
            int row = i / cols;
            int col = i % cols;
            if (row == 0 || row == (size / cols - 1) || col == 0 || col == 8) {
                ItemStack glass = new ItemStack(glasses[random.nextInt(glasses.length)]);
                ItemMeta gm = glass.getItemMeta();
                if (gm != null) {
                    gm.setDisplayName(" ");
                    glass.setItemMeta(gm);
                }
                inv.setItem(i, glass);
            }
        }
    }

    // ══════════════════════════════════════════
    //          ANUNCIOS PERIÓDICOS
    // ══════════════════════════════════════════

    private void startAnnouncementTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                if (activeBounties.isEmpty()) return;
                if (Bukkit.getOnlinePlayers().size() < 2) return;

                Map.Entry<UUID, BountyData> highest = activeBounties.entrySet().stream()
                        .max(Comparator.comparingInt(e -> e.getValue().totalAmount.get()))
                        .orElse(null);

                if (highest == null) return;

                BountyData data = highest.getValue();
                Player target = Bukkit.getPlayer(highest.getKey());
                String status = (target != null && target.isOnline()) ? "§a§lONLINE" : "§c§lOFFLINE";

                String announceMsg = "§c§l☠ BOUNTY §8» §7Bounty más alta: §c" + data.targetName
                        + " §7— §6$" + data.totalAmount.get() + " §7[" + status + "§7]";
                for (Player p : Bukkit.getOnlinePlayers()) {
                    if (!PlayerSettingsGui.getSetting(combat.getCore(), p.getUniqueId(), "hideBountyAlerts")) {
                        p.sendMessage(announceMsg);
                    }
                }
            }
        }.runTaskTimer(combat, announceIntervalTicks, announceIntervalTicks);
    }

    // ══════════════════════════════════════════
    //          UTILIDADES
    // ══════════════════════════════════════════

    public boolean hasBounty(UUID uuid) {
        return activeBounties.containsKey(uuid) && activeBounties.get(uuid).totalAmount.get() > 0;
    }

    public double getTotalBounty(UUID uuid) {
        BountyData data = activeBounties.get(uuid);
        return data != null ? data.totalAmount.get() : 0;
    }

    public int getBountyAmount(UUID uuid) {
        BountyData data = activeBounties.get(uuid);
        return data != null ? data.totalAmount.get() : 0;
    }

    public int getActiveBountyCount() {
        return activeBounties.size();
    }

    private int getTotalBountyPool() {
        return activeBounties.values().stream().mapToInt(d -> d.totalAmount.get()).sum();
    }

    /** Get top bounties for /bounty list. */
    public List<Map.Entry<UUID, Double>> getTopBounties() {
        Map<UUID, Double> totals = new HashMap<>();
        for (Map.Entry<UUID, BountyData> e : activeBounties.entrySet()) {
            totals.put(e.getKey(), (double) e.getValue().totalAmount.get());
        }
        List<Map.Entry<UUID, Double>> sorted = new ArrayList<>(totals.entrySet());
        sorted.sort(Map.Entry.<UUID, Double>comparingByValue().reversed());
        return sorted;
    }

    // ══════════════════════════════════════════
    //        PERSISTENCIA (bounties.yml)
    // ══════════════════════════════════════════

    private void loadBounties() {
        if (!bountyFile.exists()) {
            bountyConfig = new YamlConfiguration();
            return;
        }
        bountyConfig = YamlConfiguration.loadConfiguration(bountyFile);

        if (!bountyConfig.contains("bounties")) return;

        var section = bountyConfig.getConfigurationSection("bounties");
        if (section == null) return;

        for (String key : section.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                String path = "bounties." + key;
                BountyData data = new BountyData(bountyConfig.getString(path + ".name", "Unknown"));
                data.totalAmount.set(bountyConfig.getInt(path + ".amount", 0));
                data.isAutoBounty = bountyConfig.getBoolean(path + ".auto", false);

                var contribs = bountyConfig.getConfigurationSection(path + ".contributors");
                if (contribs != null) {
                    for (String cKey : contribs.getKeys(false)) {
                        try {
                            UUID cUUID = UUID.fromString(cKey);
                            data.contributors.put(cUUID, contribs.getInt(cKey, 0));
                        } catch (Exception e) {
                            combat.getLogger().warning("Error loading bounty contributor: " + cKey);
                        }
                    }
                }

                if (data.totalAmount.get() > 0) {
                    activeBounties.put(uuid, data);
                }
            } catch (Exception e) {
                combat.getLogger().warning("[BountyManager] Error loading bounty: " + key);
            }
        }

        if (!activeBounties.isEmpty()) {
            combat.getLogger().info("[BountyManager] Loaded " + activeBounties.size() + " active bounties");
        }
    }

    private void saveBounty(UUID uuid, BountyData data) {
        String path = "bounties." + uuid.toString();
        bountyConfig.set(path + ".name", data.targetName);
        bountyConfig.set(path + ".amount", data.totalAmount.get());
        bountyConfig.set(path + ".auto", data.isAutoBounty);

        for (Map.Entry<UUID, Integer> c : data.contributors.entrySet()) {
            bountyConfig.set(path + ".contributors." + c.getKey().toString(), c.getValue());
        }

        saveBountyFile();
    }

    private void clearBountySave(UUID uuid) {
        bountyConfig.set("bounties." + uuid.toString(), null);
        saveBountyFile();
    }

    private volatile boolean bountyDirty = false;

    private void saveBountyFile() {
        if (bountyDirty) return; // already scheduled
        bountyDirty = true;
        // Snapshot the YAML content on the current thread (main thread) — thread-safe
        final String snapshot;
        synchronized (bountyFile) {
            snapshot = bountyConfig.saveToString();
        }
        Bukkit.getScheduler().runTaskAsynchronously(combat, () -> {
            try {
                synchronized (bountyFile) {
                    java.nio.file.Files.writeString(bountyFile.toPath(), snapshot);
                }
            } catch (IOException e) {
                combat.getLogger().log(Level.SEVERE, "Error saving bounties.yml", e);
            } finally {
                bountyDirty = false;
            }
        });
    }

    /** Synchronous save for shutdown — bypasses async scheduling. */
    private void saveBountyFileSync() {
        try {
            bountyConfig.save(bountyFile);
        } catch (IOException e) {
            combat.getLogger().log(Level.SEVERE, "Error saving bounties.yml on shutdown", e);
        }
    }

    /** Save all bounties synchronously (called on disable). */
    public void saveAll() {
        for (Map.Entry<UUID, BountyData> entry : activeBounties.entrySet()) {
            String path = "bounties." + entry.getKey().toString();
            BountyData data = entry.getValue();
            bountyConfig.set(path + ".name", data.targetName);
            bountyConfig.set(path + ".amount", data.totalAmount.get());
            bountyConfig.set(path + ".auto", data.isAutoBounty);
            for (Map.Entry<UUID, Integer> c : data.contributors.entrySet()) {
                bountyConfig.set(path + ".contributors." + c.getKey().toString(), c.getValue());
            }
        }
        saveBountyFileSync();
    }

    /** Clear all bounties from memory only (do NOT call clearAll on disable — use saveAll). */
    public void clearAll() {
        saveAll();
        activeBounties.clear();
    }

    // ══════════════════════════════════════════
    //          CLASE DE DATOS
    // ══════════════════════════════════════════

    private static class BountyData {
        String targetName;
        final java.util.concurrent.atomic.AtomicInteger totalAmount = new java.util.concurrent.atomic.AtomicInteger(0);
        volatile boolean isAutoBounty = false;
        final Map<UUID, Integer> contributors = new ConcurrentHashMap<>();

        BountyData(String name) {
            this.targetName = name;
        }
    }
}
