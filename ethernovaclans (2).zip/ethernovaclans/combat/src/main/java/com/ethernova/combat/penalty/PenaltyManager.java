package com.ethernova.combat.penalty;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.Bukkit;

import java.util.UUID;

public class PenaltyManager {

    private final EthernovaCombat plugin;

    public PenaltyManager(EthernovaCombat plugin) { this.plugin = plugin; }

    public void applyCombatLogPenalty(UUID uuid, String playerName) {
        var config = plugin.getConfigManager().getConfig();
        if (!config.getBoolean("combat-log.penalty.enabled", true)) return;

        // Money
        double moneyLoss = config.getDouble("combat-log.penalty.money-loss", 500);
        if (moneyLoss > 0 && plugin.getCore().getEconomyHook().isEnabled()) {
            plugin.getCore().getEconomyHook().withdrawOffline(uuid, moneyLoss);
        }

        // Power (via EventBus for Clans to pick up)
        int powerLoss = config.getInt("combat-log.penalty.power-loss", 20);
        if (powerLoss > 0) {
            plugin.getCore().getEventBus().publish(new CombatLogPenaltyEvent(uuid, playerName, powerLoss));
        }

        // Broadcast
        if (config.getBoolean("combat-log.penalty.broadcast", true)) {
            String msg = plugin.getMessageManager().get("combat.log-broadcast")
                    .replace("{player}", playerName);
            Bukkit.broadcast(plugin.getCore().getMessageManager().getMiniMessage().deserialize(msg));
        }

        // Commands (validate player name to prevent injection)
        String safeName = playerName.replaceAll("[^a-zA-Z0-9_]", "");
        for (String cmd : config.getStringList("combat-log.penalty.commands")) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("{player}", safeName));
        }
    }

    public record CombatLogPenaltyEvent(UUID playerUuid, String playerName, int powerLoss) {}
}
