package com.ethernova.combat.gui;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * Utility class for building GUI items with Adventure components.
 */
public final class GUIHelper {

    private static final MiniMessage MINI = MiniMessage.miniMessage();

    /** Rainbow stained glass pane materials matching the clan GUI style */
    private static final Material[] RAINBOW_PANES = {
            Material.RED_STAINED_GLASS_PANE,
            Material.ORANGE_STAINED_GLASS_PANE,
            Material.YELLOW_STAINED_GLASS_PANE,
            Material.LIME_STAINED_GLASS_PANE,
            Material.LIGHT_BLUE_STAINED_GLASS_PANE,
            Material.BLUE_STAINED_GLASS_PANE,
            Material.PURPLE_STAINED_GLASS_PANE,
            Material.MAGENTA_STAINED_GLASS_PANE,
            Material.PINK_STAINED_GLASS_PANE,
            Material.CYAN_STAINED_GLASS_PANE,
            Material.GREEN_STAINED_GLASS_PANE,
            Material.WHITE_STAINED_GLASS_PANE
    };

    private GUIHelper() {}

    public static ItemStack item(Material mat, String name, String... lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(MINI.deserialize("<!italic>" + name));
        if (lore.length > 0) {
            List<Component> loreList = new ArrayList<>();
            for (String line : lore) {
                loreList.add(MINI.deserialize("<!italic>" + line));
            }
            meta.lore(loreList);
        }
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack item(Material mat, String name, List<String> lore) {
        return item(mat, name, lore.toArray(new String[0]));
    }

    public static ItemStack toggle(String name, boolean enabled, String... extraLore) {
        Material mat = enabled ? Material.LIME_DYE : Material.GRAY_DYE;
        String status = enabled ? "<green>ACTIVADO</green>" : "<red>DESACTIVADO</red>";
        List<String> lore = new ArrayList<>();
        lore.add(status);
        lore.add("");
        for (String l : extraLore) lore.add(l);
        lore.add("<dark_gray>Click para cambiar</dark_gray>");
        return item(mat, name, lore.toArray(new String[0]));
    }

    public static ItemStack numberItem(Material mat, String name, int value, String unit, String... extraLore) {
        List<String> lore = new ArrayList<>();
        lore.add("<white>" + value + " " + unit + "</white>");
        lore.add("");
        for (String l : extraLore) lore.add(l);
        lore.add("<dark_gray>Click izq: +1 | Click der: -1</dark_gray>");
        lore.add("<dark_gray>Shift+Click: ±5</dark_gray>");
        return item(mat, name, lore.toArray(new String[0]));
    }

    public static ItemStack cycleItem(Material mat, String name, String currentValue, String... extraLore) {
        List<String> lore = new ArrayList<>();
        lore.add("<yellow>" + currentValue + "</yellow>");
        lore.add("");
        for (String l : extraLore) lore.add(l);
        lore.add("<dark_gray>Click para ciclar</dark_gray>");
        return item(mat, name, lore.toArray(new String[0]));
    }

    public static ItemStack backButton() {
        return item(Material.ARROW, "<gray>◀ Volver</gray>");
    }

    public static ItemStack prevPageButton() {
        return item(Material.ARROW, "<gray>◀ Página Anterior</gray>");
    }

    public static ItemStack nextPageButton() {
        return item(Material.ARROW, "<gray>Página Siguiente ▶</gray>");
    }

    /** Create a rainbow glass pane for the given slot index */
    public static ItemStack rainbowPane(int index) {
        Material pane = RAINBOW_PANES[Math.abs(index) % RAINBOW_PANES.length];
        ItemStack item = new ItemStack(pane);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.empty());
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack sectionPane(Material mat, String name) {
        ItemStack pane = new ItemStack(mat);
        ItemMeta meta = pane.getItemMeta();
        meta.displayName(MINI.deserialize("<!italic>" + name));
        pane.setItemMeta(meta);
        return pane;
    }

    public static ItemStack tabActive(String name, String desc) {
        return item(Material.LIME_DYE, "<green><bold>▶ " + name + "</bold></green>", "<gray>" + desc + "</gray>");
    }

    public static ItemStack tabInactive(Material dye, String name, String desc) {
        return item(dye, name,
                "<gray>" + desc + "</gray>",
                "<dark_gray>Click para cambiar pestaña</dark_gray>");
    }

    public static ItemStack filler() {
        ItemStack item = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.empty());
        item.setItemMeta(meta);
        return item;
    }

    /**
     * Fill ALL slots with rainbow glass panes matching the clan GUI style.
     * Content items are placed on top afterwards, overwriting the panes.
     */
    public static void fillBorder(org.bukkit.inventory.Inventory inv) {
        for (int i = 0; i < inv.getSize(); i++) {
            inv.setItem(i, rainbowPane(i));
        }
    }
}
