package com.ethernova.combat.module;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;

import java.util.List;

/**
 * Interface for ecosystem plugins that integrate with the combat system.
 * Each plugin (Clans, FFA, Duels, Party) registers a module to:
 * 1) Expose per-world configurable settings in the admin GUI
 * 2) Hook into combat tag behavior (modify duration, prevent damage, etc.)
 */
public interface CombatModule {

    /** Unique module identifier (e.g. "clans", "ffa", "duels") */
    String getId();

    /** Display name for GUIs */
    String getDisplayName();

    /** Icon material for the module list GUI */
    Material getIcon();

    /** Whether this module is currently enabled */
    boolean isEnabled();

    /** Whether this module has configurable combat settings (PVP modules) */
    default boolean hasCombatConfig() { return false; }

    /** Settings this module contributes */
    List<ModuleSetting> getSettings();

    /** Build this module's sub-menu into the provided inventory */
    void buildConfigGUI(Inventory inv, String worldName);

    /** Handle a click within this module's sub-menu */
    void handleClick(Player admin, int slot, ClickType click, String worldName);

    /**
     * Called when a combat tag is about to be applied.
     * Return a modified duration, or -1 to cancel the tag entirely.
     */
    default int modifyTagDuration(Player attacker, Player victim, int baseDuration) {
        return baseDuration;
    }

    /**
     * Return true to prevent damage between two players.
     */
    default boolean shouldPreventDamage(Player attacker, Player victim) {
        return false;
    }

    /** Called when a player gets combat tagged */
    default void onCombatTag(Player player, Player enemy) {}

    /** Called when a player's combat tag expires */
    default void onCombatExpire(Player player) {}
}
