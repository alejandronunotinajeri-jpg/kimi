package com.ethernova.combat.module;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Per-module combat configuration. Stored in modules.yml.
 * Only PVP-relevant modules (FFA, Duels, Ranked, Party, Clans) have combat settings.
 */
public class ModuleConfigManager {

    private final File configFile;
    private final Logger logger;
    private final Map<String, ModuleConfig> configs = new ConcurrentHashMap<>();

    public ModuleConfigManager(File dataFolder, Logger logger) {
        this.configFile = new File(dataFolder, "modules.yml");
        this.logger = logger;
    }

    /** Get or create config for a module */
    public ModuleConfig getConfig(String moduleId) {
        return configs.computeIfAbsent(moduleId, ModuleConfig::new);
    }

    public void load() {
        configs.clear();
        if (!configFile.exists()) return;

        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(configFile);
        ConfigurationSection modules = yaml.getConfigurationSection("modules");
        if (modules == null) return;

        for (String moduleId : modules.getKeys(false)) {
            ConfigurationSection sec = modules.getConfigurationSection(moduleId);
            if (sec == null) continue;

            ModuleConfig mc = new ModuleConfig(moduleId);
            mc.setCombatTagEnabled(sec.getBoolean("combat-tag-enabled", true));
            mc.setTagDuration(sec.getInt("tag-duration", -1));
            mc.setKeepInventory(sec.getBoolean("keep-inventory", false));
            mc.setLootProtection(sec.getBoolean("loot-protection", true));
            mc.setLogoutPenalty(sec.getString("logout-penalty", "GLOBAL"));
            mc.setFlyDisabled(sec.getBoolean("fly-disabled", true));
            mc.setBlockCommands(sec.getBoolean("block-commands", true));
            configs.put(moduleId, mc);
        }
    }

    public void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (var entry : configs.entrySet()) {
            String path = "modules." + entry.getKey();
            ModuleConfig mc = entry.getValue();
            yaml.set(path + ".combat-tag-enabled", mc.isCombatTagEnabled());
            yaml.set(path + ".tag-duration", mc.getTagDuration());
            yaml.set(path + ".keep-inventory", mc.isKeepInventory());
            yaml.set(path + ".loot-protection", mc.isLootProtection());
            yaml.set(path + ".logout-penalty", mc.getLogoutPenalty());
            yaml.set(path + ".fly-disabled", mc.isFlyDisabled());
            yaml.set(path + ".block-commands", mc.isBlockCommands());
        }
        try {
            yaml.save(configFile);
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error saving modules.yml", e);
        }
    }

    /**
     * Per-module combat settings.
     */
    public static class ModuleConfig {
        private final String moduleId;
        private boolean combatTagEnabled = true;
        private int tagDuration = -1; // -1 = use global/world default
        private boolean keepInventory = false;
        private boolean lootProtection = true;
        private String logoutPenalty = "GLOBAL"; // GLOBAL, KILL, DROP_INVENTORY, NONE
        private boolean flyDisabled = true;
        private boolean blockCommands = true;

        public ModuleConfig(String moduleId) {
            this.moduleId = moduleId;
        }

        public String getModuleId() { return moduleId; }

        public boolean isCombatTagEnabled() { return combatTagEnabled; }
        public void setCombatTagEnabled(boolean v) { this.combatTagEnabled = v; }

        /** Tag duration in seconds. -1 means use global/world default. */
        public int getTagDuration() { return tagDuration; }
        public void setTagDuration(int v) { this.tagDuration = Math.max(-1, Math.min(120, v)); }

        public boolean isKeepInventory() { return keepInventory; }
        public void setKeepInventory(boolean v) { this.keepInventory = v; }

        public boolean isLootProtection() { return lootProtection; }
        public void setLootProtection(boolean v) { this.lootProtection = v; }

        public String getLogoutPenalty() { return logoutPenalty; }
        public void setLogoutPenalty(String v) { this.logoutPenalty = v; }

        public boolean isFlyDisabled() { return flyDisabled; }
        public void setFlyDisabled(boolean v) { this.flyDisabled = v; }

        public boolean isBlockCommands() { return blockCommands; }
        public void setBlockCommands(boolean v) { this.blockCommands = v; }

        /** Cycle logout penalty: GLOBAL → KILL → DROP_INVENTORY → NONE → GLOBAL */
        public void cycleLogoutPenalty() {
            logoutPenalty = switch (logoutPenalty) {
                case "GLOBAL" -> "KILL";
                case "KILL" -> "DROP_INVENTORY";
                case "DROP_INVENTORY" -> "NONE";
                default -> "GLOBAL";
            };
        }
    }
}
