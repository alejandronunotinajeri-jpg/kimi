package com.ethernova.combat.module;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Central registry for combat modules.
 * Ecosystem plugins register their modules here on enable.
 */
public class CombatModuleRegistry {

    private final Map<String, CombatModule> modules = new ConcurrentHashMap<>();

    public void register(CombatModule module) {
        modules.put(module.getId(), module);
    }

    public void unregister(String moduleId) {
        modules.remove(moduleId);
    }

    public CombatModule getModule(String id) {
        return modules.get(id);
    }

    public Collection<CombatModule> getAll() {
        return Collections.unmodifiableCollection(modules.values());
    }

    public List<CombatModule> getEnabled() {
        return modules.values().stream()
                .filter(CombatModule::isEnabled)
                .toList();
    }

    public boolean hasModule(String id) {
        return modules.containsKey(id);
    }
}
