package com.ethernova.combat.command;

import com.ethernova.combat.EthernovaCombat;
import com.ethernova.core.leaderboard.LeaderboardManager;
import com.ethernova.core.profile.PlayerProfile;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class CombatCommand implements CommandExecutor, TabCompleter {

    private final EthernovaCombat plugin;

    public CombatCommand(EthernovaCombat plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.getMessageManager().send(sender, "general.player-only");
            return true;
        }

        if (args.length == 0 || "status".equalsIgnoreCase(args[0])) {
            showStatus(player);
        } else {
            switch (args[0].toLowerCase()) {
                case "stats" -> showStats(player);
                case "top" -> showTop(player);
                case "newbie" -> plugin.getNewbieManager().toggle(player);
                case "help" -> showHelp(player);
                default -> showHelp(player);
            }
        }
        return true;
    }

    private void showStatus(Player player) {
        boolean inCombat = plugin.getTagManager().isInCombat(player);
        int remaining = plugin.getTagManager().getRemainingSeconds(player.getUniqueId());
        int streak = plugin.getKillStreakManager().getStreak(player);
        plugin.getMessageManager().send(player, "combat.status-header");
        if (inCombat) {
            plugin.getMessageManager().send(player, "combat.status-in-combat",
                    "{remaining}", String.valueOf(remaining));
        } else {
            plugin.getMessageManager().send(player, "combat.status-not-in-combat");
        }
        plugin.getMessageManager().send(player, "combat.status-streak",
                "{streak}", String.valueOf(streak));
    }

    private void showStats(Player player) {
        PlayerProfile profile = plugin.getCore().getProfileManager().getProfile(player.getUniqueId());
        int kills = profile != null ? profile.getKills() : 0;
        int deaths = profile != null ? profile.getDeaths() : 0;
        double kdr = deaths == 0 ? kills : (double) kills / deaths;
        int streak = plugin.getKillStreakManager().getStreak(player);
        int combo = plugin.getComboManager() != null ? plugin.getComboManager().getCombo(player.getUniqueId()) : 0;
        double bounty = plugin.getBountyManager() != null ? plugin.getBountyManager().getTotalBounty(player.getUniqueId()) : 0;
        String activeProfile = plugin.getProfileManager().getActiveProfile(player);

        plugin.getMessageManager().send(player, "stats.header");
        plugin.getMessageManager().send(player, "stats.kills", "{kills}", String.valueOf(kills));
        plugin.getMessageManager().send(player, "stats.deaths", "{deaths}", String.valueOf(deaths));
        plugin.getMessageManager().send(player, "stats.kdr", "{kdr}", String.format("%.2f", kdr));
        plugin.getMessageManager().send(player, "stats.streak", "{streak}", String.valueOf(streak));
        plugin.getMessageManager().send(player, "stats.combo", "{combo}", String.valueOf(combo));
        plugin.getMessageManager().send(player, "stats.bounty", "{bounty}", String.format("%.0f", bounty));
        plugin.getMessageManager().send(player, "stats.profile", "{profile}", activeProfile);
        if (plugin.getNewbieManager().isProtected(player)) {
            plugin.getMessageManager().send(player, "stats.newbie");
        }
        plugin.getMessageManager().send(player, "stats.footer");
    }

    private void showTop(Player player) {
        LeaderboardManager lb = plugin.getCore().getLeaderboardManager();
        if (lb == null) {
            plugin.getMessageManager().send(player, "top.empty");
            return;
        }

        var top = lb.getTop("kills");
        plugin.getMessageManager().send(player, "top.header");

        if (top == null || top.isEmpty()) {
            plugin.getMessageManager().send(player, "top.empty");
        } else {
            for (int i = 0; i < Math.min(top.size(), 10); i++) {
                var entry = top.get(i);
                int rank = i + 1;
                String msgKey;
                if (rank <= 3) {
                    msgKey = "top.entry-" + rank;
                } else {
                    msgKey = "top.entry";
                }
                plugin.getMessageManager().send(player, msgKey,
                        "{rank}", String.valueOf(rank),
                        "{player}", entry.name(),
                        "{kills}", String.valueOf((long) entry.numericValue()));
            }
        }
        plugin.getMessageManager().send(player, "top.footer");
    }

    private void showHelp(Player player) {
        plugin.getMessageManager().send(player, "help.header");
        plugin.getMessageManager().send(player, "help.status");
        plugin.getMessageManager().send(player, "help.stats");
        plugin.getMessageManager().send(player, "help.top");
        plugin.getMessageManager().send(player, "help.newbie");
        plugin.getMessageManager().send(player, "help.help-cmd");
        plugin.getMessageManager().send(player, "help.bounty");
        plugin.getMessageManager().send(player, "help.logout");
        plugin.getMessageManager().send(player, "help.footer");
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) {
            return Arrays.asList("status", "stats", "top", "newbie", "help")
                    .stream().filter(s -> s.startsWith(args[0].toLowerCase()))
                    .collect(Collectors.toList());
        }
        return List.of();
    }
}
