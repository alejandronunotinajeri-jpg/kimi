package com.ethernova.combat.module;

import org.bukkit.Material;

/**
 * A single configurable setting exposed by a CombatModule.
 */
public record ModuleSetting(
        String key,
        String displayName,
        Material icon,
        SettingType type,
        Object defaultValue,
        String description
) {
    public enum SettingType {
        TOGGLE,       // boolean on/off
        INTEGER,      // click +/- to adjust
        DOUBLE,       // click +/- to adjust (decimal)
        CYCLE,        // cycle through a list of options
        STRING_LIST   // opens a sub-menu for editing a list
    }
}
