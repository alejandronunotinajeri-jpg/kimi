package com.ethernova.combat.api;

import org.bukkit.entity.Player;

import java.util.UUID;

/**
 * Public API interface for EthernovaCombat.
 * Extends core's CombatAPI for ServiceRegistry compatibility.
 *
 * <p>Obtain an instance via {@code ServiceRegistry.get(com.ethernova.core.api.CombatAPI.class)}.</p>
 */
public interface CombatAPI extends com.ethernova.core.api.CombatAPI {

    /**
     * Check if a player is currently in combat.
     *
     * @param player the player to check
     * @return {@code true} if the player is currently combat-tagged
     */
    boolean isInCombat(Player player);

    /**
     * Check if a player is currently in combat (by UUID).
     *
     * @param uuid the UUID of the player to check
     * @return {@code true} if the player is currently combat-tagged
     */
    boolean isInCombat(UUID uuid);

    /**
     * Tag two players as being in combat with each other.
     *
     * @param p1      the first player
     * @param p2      the second player
     * @param profile the combat profile to apply (e.g., "default", "ranked")
     */
    void tag(Player p1, Player p2, String profile);

    /**
     * Remove combat tag from a player.
     *
     * @param player the player to untag
     */
    void untag(Player player);

    /**
     * Get remaining combat tag seconds for a player.
     *
     * @param uuid the UUID of the player
     * @return remaining seconds of combat tag, or {@code 0} if not in combat
     */
    int getRemainingSeconds(UUID uuid);

    /**
     * Get the current kill streak count for a player.
     *
     * @param uuid the UUID of the player
     * @return the player's current kill streak count
     */
    int getKillStreak(UUID uuid);

    /**
     * Check if a player has newbie protection active.
     *
     * @param uuid the UUID of the player
     * @return {@code true} if the player currently has newbie protection
     */
    boolean isNewbieProtected(UUID uuid);
}
