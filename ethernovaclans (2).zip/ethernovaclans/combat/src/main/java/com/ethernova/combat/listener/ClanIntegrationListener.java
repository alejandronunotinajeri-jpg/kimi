package com.ethernova.combat.listener;

import com.ethernova.combat.EthernovaCombat;
import com.ethernova.core.event.ClanWarStartEvent;
import com.ethernova.core.event.ClanWarEndEvent;
import com.ethernova.core.event.PowerChangeEvent;
import com.ethernova.combat.penalty.PenaltyManager;

import java.util.UUID;

/**
 * Subscribes to Core EventBus events from EthernovaClans.
 * Adapts combat behavior based on clan context (war profile, power loss, etc.)
 */
public class ClanIntegrationListener {

    private final EthernovaCombat plugin;

    public ClanIntegrationListener(EthernovaCombat plugin) {
        this.plugin = plugin;
        registerEventSubscriptions();
    }

    private void registerEventSubscriptions() {
        var eventBus = plugin.getCore().getEventBus();

        // When a clan war starts, set "war" context for all online members
        eventBus.subscribe(ClanWarStartEvent.class, event -> {
            if (plugin.getConfigManager().getBoolean("general.debug", false)) {
                plugin.getLogger().info("[ClanIntegration] War started: " +
                        event.attackerClanName() + " vs " + event.defenderClanName());
            }
            // Context is managed by Clans plugin, Combat just reacts to it
        });

        // When a clan war ends, remove "war" context
        eventBus.subscribe(ClanWarEndEvent.class, event -> {
            if (plugin.getConfigManager().getBoolean("general.debug", false)) {
                plugin.getLogger().info("[ClanIntegration] War ended: " +
                        event.winnerClanId() + " won (" + event.reason() + ")");
            }
        });

        // Listen for combat log penalties that include power loss
        eventBus.subscribe(PenaltyManager.CombatLogPenaltyEvent.class, event -> {
            // Publish a PowerChangeEvent so Clans can react
            var profile = plugin.getCore().getProfileManager().getProfile(event.playerUuid());
            if (profile != null) {
                eventBus.publish(new PowerChangeEvent(
                        event.playerUuid(),
                        event.playerName(),
                        0, // oldPower — Clans will know the actual value
                        -event.powerLoss(), // negative = loss
                        "combat_log"
                ));
            }
        });
    }
}
