package com.ethernova.combat.world;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Manages per-world combat configurations.
 * Loads from and saves to worlds.yml in the plugin data folder.
 */
public class WorldConfigManager {

    private final EthernovaCombat plugin;
    private final Map<String, WorldCombatConfig> configs = new ConcurrentHashMap<>();
    private File configFile;

    public WorldConfigManager(EthernovaCombat plugin) {
        this.plugin = plugin;
        this.configFile = new File(plugin.getDataFolder(), "worlds.yml");
    }

    public void load() {
        configs.clear();
        if (!configFile.exists()) {
            // Create default configs for all loaded worlds
            for (World w : Bukkit.getWorlds()) {
                configs.put(w.getName(), new WorldCombatConfig(w.getName()));
            }
            save();
            return;
        }

        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(configFile);
        ConfigurationSection worlds = yaml.getConfigurationSection("worlds");
        if (worlds == null) return;

        for (String worldName : worlds.getKeys(false)) {
            ConfigurationSection ws = worlds.getConfigurationSection(worldName);
            if (ws == null) continue;

            WorldCombatConfig wc = new WorldCombatConfig(worldName);
            wc.setCombatTagEnabled(ws.getBoolean("combat-tag-enabled", true));
            wc.setTagDuration(ws.getInt("tag-duration", 15));
            wc.setKeepInventory(ws.getBoolean("keep-inventory", false));
            wc.setLogoutPenalty(ws.getString("logout-penalty", "KILL"));
            wc.setFlyDisabled(ws.getBoolean("fly-disabled", true));
            wc.setNpcSpawnOnLogout(ws.getBoolean("npc-spawn-on-logout", true));
            wc.setPotionRestrict(ws.getBoolean("potion-restrict", false));
            wc.setBossBarEnabled(ws.getBoolean("bossbar-enabled", true));
            wc.setActionBarEnabled(ws.getBoolean("actionbar-enabled", true));
            wc.setNewbieProtectionMinutes(ws.getInt("newbie-protection-minutes", 30));
            wc.setEnderPearlDeny(ws.getBoolean("enderpearl-deny", false));
            wc.setEnderPearlCooldown(ws.getInt("enderpearl-cooldown", 16));
            wc.setLootProtection(ws.getBoolean("loot-protection", true));
            wc.setLootProtectionSeconds(ws.getInt("loot-protection-seconds", 30));
            wc.setCraftBlockInCombat(ws.getBoolean("craft-block-in-combat", false));
            wc.setBlockedCommands(ws.getStringList("blocked-commands"));
            configs.put(worldName, wc);
        }

        // Ensure all current worlds have a config
        for (World w : Bukkit.getWorlds()) {
            configs.computeIfAbsent(w.getName(), WorldCombatConfig::new);
        }
    }

    public void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (var entry : configs.entrySet()) {
            String path = "worlds." + entry.getKey();
            WorldCombatConfig wc = entry.getValue();
            yaml.set(path + ".combat-tag-enabled", wc.isCombatTagEnabled());
            yaml.set(path + ".tag-duration", wc.getTagDuration());
            yaml.set(path + ".keep-inventory", wc.isKeepInventory());
            yaml.set(path + ".logout-penalty", wc.getLogoutPenalty());
            yaml.set(path + ".fly-disabled", wc.isFlyDisabled());
            yaml.set(path + ".npc-spawn-on-logout", wc.isNpcSpawnOnLogout());
            yaml.set(path + ".potion-restrict", wc.isPotionRestrict());
            yaml.set(path + ".bossbar-enabled", wc.isBossBarEnabled());
            yaml.set(path + ".actionbar-enabled", wc.isActionBarEnabled());
            yaml.set(path + ".newbie-protection-minutes", wc.getNewbieProtectionMinutes());
            yaml.set(path + ".enderpearl-deny", wc.isEnderPearlDeny());
            yaml.set(path + ".enderpearl-cooldown", wc.getEnderPearlCooldown());
            yaml.set(path + ".loot-protection", wc.isLootProtection());
            yaml.set(path + ".loot-protection-seconds", wc.getLootProtectionSeconds());
            yaml.set(path + ".craft-block-in-combat", wc.isCraftBlockInCombat());
            yaml.set(path + ".blocked-commands", wc.getBlockedCommands());
        }
        try {
            yaml.save(configFile);
        } catch (IOException e) {
            plugin.getLogger().log(Level.WARNING, "Failed to save worlds.yml", e);
        }
    }

    public WorldCombatConfig getConfig(String worldName) {
        return configs.computeIfAbsent(worldName, WorldCombatConfig::new);
    }

    public WorldCombatConfig getConfig(World world) {
        return getConfig(world.getName());
    }

    public Collection<WorldCombatConfig> getAll() {
        return Collections.unmodifiableCollection(configs.values());
    }

    public List<String> getWorldNames() {
        return new ArrayList<>(configs.keySet());
    }
}
