package com.ethernova.combat.profile;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class CombatProfileManager {

    private final EthernovaCombat plugin;
    private final Map<UUID, String> activeProfiles = new ConcurrentHashMap<>();

    public CombatProfileManager(EthernovaCombat plugin) { this.plugin = plugin; }

    public String getActiveProfile(Player player) {
        return getActiveProfile(player.getUniqueId());
    }

    public String getActiveProfile(UUID uuid) {
        return activeProfiles.getOrDefault(uuid, "survival");
    }

    public void setProfile(UUID uuid, String profile) {
        activeProfiles.put(uuid, profile);
    }

    public void removeProfile(UUID uuid) {
        activeProfiles.remove(uuid);
    }

    /**
     * Auto-detect profile based on Core context.
     */
    public void detectProfile(Player player) {
        if (plugin.getCore().getContextManager().hasContext(player.getUniqueId(), "war")) {
            setProfile(player.getUniqueId(), "war");
        } else if (plugin.getCore().getContextManager().hasContext(player.getUniqueId(), "arena")) {
            setProfile(player.getUniqueId(), "arena");
        } else if (plugin.getCore().getContextManager().hasContext(player.getUniqueId(), "ffa")) {
            setProfile(player.getUniqueId(), "ffa");
        } else {
            setProfile(player.getUniqueId(), "survival");
        }
    }
}
