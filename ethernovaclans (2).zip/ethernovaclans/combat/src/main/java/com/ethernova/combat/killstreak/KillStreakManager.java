package com.ethernova.combat.killstreak;

import com.ethernova.combat.EthernovaCombat;
import com.ethernova.core.EthernovaCore;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.entity.SmallFireball;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * KillstreakManager — Sistema de rachas con habilidades activables.
 * Replica exacta del original UltimateFFA KillstreakManager.
 *
 * Milestones: 3, 5, 10, 15, 20, 25, 30, 40, 50, post-50 cada 10.
 * Habilidades: Lightning (10), Shockwave (20), Bombardment (30), Nuke (40).
 * Fire Aspect II en espada a 50 kills.
 * Pociones permanentes (Integer.MAX_VALUE).
 */
public class KillStreakManager implements Listener {

    private final EthernovaCombat plugin;
    private final EthernovaCore core;
    private final MiniMessage mini = MiniMessage.miniMessage();

    // Racha actual de cada jugador
    private final Map<UUID, Integer> activeStreaks = new ConcurrentHashMap<>();
    // Cooldown de habilidades
    private final Map<UUID, Long> abilityCooldown = new ConcurrentHashMap<>();
    /** Track all potion effects granted by config milestones, so we can remove them all on death */
    private final Map<UUID, Set<PotionEffectType>> streakGrantedEffects = new ConcurrentHashMap<>();

    // Config
    private long abilityCooldownMs = 3000;
    private final Map<Integer, Integer> milestoneMoney = new LinkedHashMap<>();
    private boolean fireAspectEnabled = true;
    private int fireAspectLevel = 2;
    private int post50Interval = 10;
    private int post50MoneyPerKill = 1000;

    // Ability params
    private double lightningRange = 15;
    private double shockwaveRange = 8, shockwaveDamage = 4.0, shockwaveLaunchY = 1.2, shockwaveLaunchMult = 1.5;
    private int bombardRadius = 5, bombardHeight = 15, bombardDuration = 30;
    private int nukeCountdown = 3, nukeWarnRange = 20, nukeFlashRange = 15, nukeDamageRange = 10;
    private double nukeMaxDmg = 16.0, nukeMinDmg = 2.0, nukeKnockbackY = 0.8, nukeKnockbackMult = 2.0;

    public KillStreakManager(EthernovaCombat plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
        loadConfig();
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    private void loadConfig() {
        var cfg = plugin.getConfigManager().getKillStreaksConfig();
        if (cfg == null) cfg = new org.bukkit.configuration.file.YamlConfiguration();

        abilityCooldownMs = cfg.getLong("ability-cooldown-ms", 3000);

        // Milestones money (from config or defaults)
        int[] defaultKills = {3, 5, 10, 15, 20, 25, 30, 40, 50};
        int[] defaultMoney = {0, 500, 2000, 4000, 8000, 16000, 32000, 64000, 128000};
        for (int i = 0; i < defaultKills.length; i++) {
            int kills = defaultKills[i];
            milestoneMoney.put(kills, cfg.getInt("milestones." + kills + ".money", defaultMoney[i]));
        }

        fireAspectEnabled = cfg.getBoolean("milestones.50.fire-aspect", true);
        fireAspectLevel = cfg.getInt("milestones.50.fire-aspect-level", 2);
        post50Interval = cfg.getInt("post-50.interval", 10);
        post50MoneyPerKill = cfg.getInt("post-50.money-per-kill", 1000);

        lightningRange = cfg.getDouble("abilities.lightning.range", 15);
        shockwaveRange = cfg.getDouble("abilities.shockwave.range", 8);
        shockwaveDamage = cfg.getDouble("abilities.shockwave.damage", 4.0);
        shockwaveLaunchY = cfg.getDouble("abilities.shockwave.launch-y", 1.2);
        shockwaveLaunchMult = cfg.getDouble("abilities.shockwave.launch-multiplier", 1.5);
        bombardRadius = cfg.getInt("abilities.bombardment.radius", 5);
        bombardHeight = cfg.getInt("abilities.bombardment.height", 15);
        bombardDuration = cfg.getInt("abilities.bombardment.duration-ticks", 30);
        nukeCountdown = cfg.getInt("abilities.nuke.countdown", 3);
        nukeWarnRange = cfg.getInt("abilities.nuke.warn-range", 20);
        nukeFlashRange = cfg.getInt("abilities.nuke.flash-range", 15);
        nukeDamageRange = cfg.getInt("abilities.nuke.damage-range", 10);
        nukeMaxDmg = cfg.getDouble("abilities.nuke.max-damage", 16.0);
        nukeMinDmg = cfg.getDouble("abilities.nuke.min-damage", 2.0);
        nukeKnockbackY = cfg.getDouble("abilities.nuke.knockback-y", 0.8);
        nukeKnockbackMult = cfg.getDouble("abilities.nuke.knockback-multiplier", 2.0);
    }

    // ══════════════════════════════════════════
    //        MESSAGE HELPERS
    // ══════════════════════════════════════════

    /** Resolve a message from config with placeholder replacements. */
    private String msg(String path, String... replacements) {
        return plugin.getMessageManager().get(path, replacements);
    }

    /** Send a MiniMessage to a player from config path. */
    private void sendMsg(Player player, String path, String... replacements) {
        plugin.getMessageManager().send(player, path, replacements);
    }

    /** Broadcast a MiniMessage to all players from config path. */
    private void broadcastMsg(String path, String... replacements) {
        Bukkit.broadcast(mini.deserialize(msg(path, replacements)));
    }

    /** Send a title/subtitle from config paths using Adventure API. */
    private void sendConfigTitle(Player player, String titlePath, String subtitlePath,
                                 int fadeInTicks, int stayTicks, int fadeOutTicks, String... replacements) {
        Component title = mini.deserialize(msg(titlePath, replacements));
        Component subtitle = mini.deserialize(msg(subtitlePath, replacements));
        player.showTitle(Title.title(title, subtitle,
                Title.Times.times(
                        Duration.ofMillis(fadeInTicks * 50L),
                        Duration.ofMillis(stayTicks * 50L),
                        Duration.ofMillis(fadeOutTicks * 50L))));
    }

    // ══════════════════════════════════════════
    //        HANDLE KILL / DEATH / QUIT
    // ══════════════════════════════════════════

    public void addKill(Player killer) {
        if (!plugin.getConfigManager().getBoolean("killstreaks.enabled", true)) return;
        UUID uuid = killer.getUniqueId();
        int streak = activeStreaks.merge(uuid, 1, Integer::sum);

        // Track best streak in profile
        var profile = plugin.getCore().getProfileManager().getProfile(uuid);
        if (profile != null) {
            int best = 0;
            try { best = Integer.parseInt(profile.getCustom("best_streak", "0")); } catch (NumberFormatException ignored) {}
            if (streak > best) {
                profile.setCustom("best_streak", String.valueOf(streak));
            }
        }
    }

    public void checkMilestone(Player killer) {
        if (!plugin.getConfigManager().getBoolean("killstreaks.enabled", true)) return;
        int streak = getStreak(killer);
        processMilestone(killer, streak);
    }

    public void onDeath(Player victim) {
        if (!plugin.getConfigManager().getBoolean("killstreaks.reset-on-death", true)) return;
        Integer oldStreak = activeStreaks.remove(victim.getUniqueId());
        if (oldStreak != null && oldStreak >= 5) {
            sendMsg(victim, "killstreak.death-lost", "{streak}", String.valueOf(oldStreak));
        }
        removeAbilityItems(victim);
        removeStreakPotionEffects(victim);
    }

    public void cleanupPlayer(UUID uuid) {
        activeStreaks.remove(uuid);
        abilityCooldown.remove(uuid);
        streakGrantedEffects.remove(uuid);
        Player player = Bukkit.getPlayer(uuid);
        if (player != null && player.isOnline()) {
            removeStreakPotionEffects(player);
        }
    }

    /**
     * On join, clean up any stale killstreak potion effects (e.g. from crashes/unclean disconnects).
     * If the player has no active streak, remove all streak-related effects.
     */
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (!activeStreaks.containsKey(player.getUniqueId())) {
            removeStreakPotionEffects(player);
        }
    }

    /**
     * Remove all potion effects that were granted by killstreak milestones.
     * Prevents permanent effects persisting after death/quit.
     */
    private void removeStreakPotionEffects(Player player) {
        // Remove hardcoded milestone effects
        player.removePotionEffect(PotionEffectType.SPEED);
        player.removePotionEffect(PotionEffectType.REGENERATION);
        player.removePotionEffect(PotionEffectType.RESISTANCE);
        player.removePotionEffect(PotionEffectType.STRENGTH);
        // Remove all config-granted effects (e.g., INVISIBILITY, JUMP_BOOST from milestones)
        Set<PotionEffectType> granted = streakGrantedEffects.remove(player.getUniqueId());
        if (granted != null) {
            for (PotionEffectType type : granted) {
                player.removePotionEffect(type);
            }
        }
    }

    // ══════════════════════════════════════════
    //        MILESTONES Y RECOMPENSAS
    // ══════════════════════════════════════════

    private void processMilestone(Player killer, int streak) {
        Integer money = milestoneMoney.get(streak);
        String playerName = killer.getName();

        switch (streak) {
            case 3:
                sendMsg(killer, "killstreak.milestone.3.personal");
                killer.playSound(killer.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.5f);
                break;

            case 5:
                broadcastMsg("killstreak.milestone.5.broadcast", "{player}", playerName);
                giveMoney(killer, money != null ? money : 500);
                killer.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 0, true, false));
                killer.playSound(killer.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 2f);
                sendMsg(killer, "killstreak.milestone.5.reward", "{money}", String.valueOf(money != null ? money : 500));
                break;

            case 10:
                broadcastMsg("killstreak.milestone.10.broadcast", "{player}", playerName);
                giveMoney(killer, money != null ? money : 2000);
                applyConfigEffects(killer, 10);
                killer.playSound(killer.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1f, 1f);
                sendConfigTitle(killer, "killstreak.milestone.10.title", "killstreak.milestone.10.subtitle", 5, 30, 5);
                sendMsg(killer, "killstreak.milestone.10.reward", "{money}", String.valueOf(money != null ? money : 2000));
                giveAbilityItem(killer, AbilityType.LIGHTNING);
                break;

            case 15:
                broadcastMsg("killstreak.milestone.15.broadcast", "{player}", playerName);
                giveMoney(killer, money != null ? money : 4000);
                killer.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, Integer.MAX_VALUE, 0, true, false));
                sendMsg(killer, "killstreak.milestone.15.reward", "{money}", String.valueOf(money != null ? money : 4000));
                break;

            case 20:
                broadcastMsg("killstreak.milestone.20.broadcast", "{player}", playerName);
                giveMoney(killer, money != null ? money : 8000);
                applyConfigEffects(killer, 20);
                killer.getWorld().strikeLightningEffect(killer.getLocation());
                sendConfigTitle(killer, "killstreak.milestone.20.title", "killstreak.milestone.20.subtitle", 5, 30, 5);
                sendMsg(killer, "killstreak.milestone.20.reward", "{money}", String.valueOf(money != null ? money : 8000));
                giveAbilityItem(killer, AbilityType.SHOCKWAVE);
                break;

            case 25:
                broadcastMsg("killstreak.milestone.25.broadcast", "{player}", playerName);
                giveMoney(killer, money != null ? money : 16000);
                killer.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 0, true, false));
                sendMsg(killer, "killstreak.milestone.25.reward", "{money}", String.valueOf(money != null ? money : 16000));
                break;

            case 30:
                broadcastMsg("killstreak.milestone.30.broadcast", "{player}", playerName);
                giveMoney(killer, money != null ? money : 32000);
                killer.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 1, true, false));
                killer.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1, true, false));
                killer.getWorld().strikeLightningEffect(killer.getLocation());
                sendConfigTitle(killer, "killstreak.milestone.30.title", "killstreak.milestone.30.subtitle", 5, 40, 5);
                sendMsg(killer, "killstreak.milestone.30.reward", "{money}", String.valueOf(money != null ? money : 32000));
                giveAbilityItem(killer, AbilityType.BOMBARDMENT);
                break;

            case 40:
                broadcastMsg("killstreak.milestone.40.broadcast", "{player}", playerName);
                giveMoney(killer, money != null ? money : 64000);
                sendConfigTitle(killer, "killstreak.milestone.40.title", "killstreak.milestone.40.subtitle", 5, 40, 5);
                sendMsg(killer, "killstreak.milestone.40.reward", "{money}", String.valueOf(money != null ? money : 64000));
                giveAbilityItem(killer, AbilityType.NUKE);
                break;

            case 50:
                Bukkit.broadcast(Component.empty());
                broadcastMsg("killstreak.milestone.50.broadcast-header");
                broadcastMsg("killstreak.milestone.50.broadcast-player", "{player}", playerName);
                broadcastMsg("killstreak.milestone.50.broadcast-fire");
                broadcastMsg("killstreak.milestone.50.broadcast-footer");
                Bukkit.broadcast(Component.empty());
                giveMoney(killer, money != null ? money : 128000);
                applyConfigEffects(killer, 50);

                // Fire Aspect unlock
                if (fireAspectEnabled) {
                    ItemStack hand = killer.getInventory().getItemInMainHand();
                    if (hand != null && hand.getType().name().contains("SWORD")) {
                        hand.addUnsafeEnchantment(Enchantment.FIRE_ASPECT, fireAspectLevel);
                        sendMsg(killer, "killstreak.milestone.50.fire-aspect-msg");
                    }
                }

                killer.playSound(killer.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
                killer.getWorld().strikeLightningEffect(killer.getLocation());
                break;

            default:
                // Post-50: each post50Interval kills
                if (streak > 50 && streak % post50Interval == 0) {
                    broadcastMsg("killstreak.milestone.post-50.broadcast",
                            "{player}", playerName, "{streak}", String.valueOf(streak));
                    int reward = streak * post50MoneyPerKill;
                    giveMoney(killer, reward);
                    sendMsg(killer, "killstreak.milestone.post-50.reward", "{money}", String.valueOf(reward));
                }
                break;
        }
    }

    private void applyConfigEffects(Player player, int milestone) {
        var cfg = plugin.getConfigManager().getKillStreaksConfig();
        if (cfg == null) return;
        var effects = cfg.getStringList("milestones." + milestone + ".effects");
        for (String effectStr : effects) {
            String[] parts = effectStr.split(":");
            try {
                PotionEffectType type = PotionEffectType.getByName(parts[0]);
                int amplifier = parts.length > 1 ? Integer.parseInt(parts[1]) : 0;
                if (type != null) {
                    player.addPotionEffect(new PotionEffect(type, Integer.MAX_VALUE, amplifier, true, false));
                    // Track for removal on death
                    streakGrantedEffects.computeIfAbsent(player.getUniqueId(), k -> ConcurrentHashMap.newKeySet()).add(type);
                }
            } catch (Exception e) {
                plugin.getLogger().warning("[KillStreakManager] Efecto inválido: " + effectStr);
            }
        }
    }

    private void giveMoney(Player player, int amount) {
        if (amount <= 0) return;
        if (core.getEconomyHook().isEnabled()) {
            core.getEconomyHook().deposit(player, amount);
        }
    }

    // ══════════════════════════════════════════
    //        SISTEMA DE HABILIDADES ACTIVABLES
    // ══════════════════════════════════════════

    public enum AbilityType {
        LIGHTNING("§e⚡ Rayo", Material.BLAZE_ROD,
                "§7Click derecho para lanzar un rayo",
                "§7al jugador más cercano (15 bloques)"),
        SHOCKWAVE("§c💥 Onda Expansiva", Material.TNT,
                "§7Click derecho para lanzar a todos",
                "§7los jugadores cercanos por los aires"),
        BOMBARDMENT("§6☄ Bombardeo", Material.FIRE_CHARGE,
                "§7Click derecho para invocar una",
                "§7lluvia de fuego a tu alrededor"),
        NUKE("§4☢ Nuke", Material.NETHER_STAR,
                "§7Click derecho para una explosión",
                "§7masiva que daña a todos en 10 bloques");

        final String displayName;
        final Material material;
        final String desc1;
        final String desc2;

        AbilityType(String displayName, Material material, String desc1, String desc2) {
            this.displayName = displayName;
            this.material = material;
            this.desc1 = desc1;
            this.desc2 = desc2;
        }
    }

    private static final String ABILITY_TAG = "§8§l[HABILIDAD]";

    private void giveAbilityItem(Player player, AbilityType type) {
        ItemStack item = new ItemStack(type.material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ABILITY_TAG + " " + type.displayName);
        List<String> lore = new ArrayList<>();
        lore.add("");
        lore.add(type.desc1);
        lore.add(type.desc2);
        lore.add("");
        lore.add("§a§lCLICK DERECHO §apara activar");
        lore.add("§c§l¡USO ÚNICO!");
        meta.setLore(lore);
        item.setItemMeta(meta);

        // Slot 8 por defecto, buscar vacío si está ocupado
        if (player.getInventory().getItem(8) == null || player.getInventory().getItem(8).getType() == Material.AIR) {
            player.getInventory().setItem(8, item);
        } else {
            int emptySlot = player.getInventory().firstEmpty();
            if (emptySlot != -1) {
                player.getInventory().setItem(emptySlot, item);
            } else {
                player.getInventory().setItem(8, item);
            }
        }
        player.playSound(player.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1f, 0.8f);
    }

    // ══════════════════════════════════════════
    //        HANDLER DE CLICK DERECHO
    // ══════════════════════════════════════════

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player player = e.getPlayer();
        ItemStack item = e.getItem();
        if (item == null || !item.hasItemMeta() || !item.getItemMeta().hasDisplayName()) return;

        String name = item.getItemMeta().getDisplayName();
        if (!name.startsWith(ABILITY_TAG)) return;

        e.setCancelled(true);

        // Cooldown
        UUID uuid = player.getUniqueId();
        long now = System.currentTimeMillis();
        Long lastUse = abilityCooldown.get(uuid);
        if (lastUse != null && now - lastUse < abilityCooldownMs) {
            player.sendMessage("§c§l✗ §cEspera " + ((abilityCooldownMs - (now - lastUse)) / 1000 + 1) + "s más.");
            return;
        }
        abilityCooldown.put(uuid, now);

        // Determine ability type
        if (name.contains("Rayo")) {
            activateLightning(player);
        } else if (name.contains("Onda")) {
            activateShockwave(player);
        } else if (name.contains("Bombardeo")) {
            activateBombardment(player);
        } else if (name.contains("Nuke")) {
            activateNuke(player);
        } else {
            return;
        }

        // Consume item
        if (item.getAmount() > 1) {
            item.setAmount(item.getAmount() - 1);
        } else {
            if (e.getHand() == org.bukkit.inventory.EquipmentSlot.OFF_HAND) {
                player.getInventory().setItemInOffHand(null);
            } else {
                player.getInventory().setItemInMainHand(null);
            }
        }
    }

    // ══════════════════════════════════════════
    //        HABILIDADES
    // ══════════════════════════════════════════

    /** ⚡ RAYO — Cae un rayo real sobre el jugador FFA más cercano */
    private void activateLightning(Player user) {
        Player target = getNearestPlayer(user, lightningRange);
        if (target == null) {
            user.sendMessage("§c§l✗ §cNo hay jugadores cerca (" + (int) lightningRange + " bloques).");
            giveAbilityItem(user, AbilityType.LIGHTNING);
            abilityCooldown.remove(user.getUniqueId());
            return;
        }

        target.getWorld().strikeLightning(target.getLocation());
        user.sendMessage("§e§l⚡ §eUsaste §6Rayo §een §c" + target.getName());
        target.sendMessage("§e§l⚡ §c¡" + user.getName() + " §ete lanzó un Rayo!");
        Bukkit.broadcastMessage("§e§l⚡ §e" + user.getName() + " §flanzó un Rayo sobre §c" + target.getName());
    }

    /** 💥 ONDA EXPANSIVA — Lanza a todos los jugadores cercanos por los aires */
    private void activateShockwave(Player user) {
        Location center = user.getLocation();
        int affected = 0;

        for (Player nearby : center.getWorld().getPlayers()) {
            if (nearby.equals(user)) continue;
            if (nearby.getLocation().distance(center) > shockwaveRange) continue;
            if (!isInPvP(nearby)) continue;

            Vector dir = nearby.getLocation().toVector().subtract(center.toVector());
            if (dir.lengthSquared() < 0.001) dir = new Vector(0, 1, 0);
            dir = dir.normalize();
            dir.setY(shockwaveLaunchY);
            dir.multiply(shockwaveLaunchMult);
            nearby.setVelocity(dir);
            nearby.damage(shockwaveDamage, user);
            affected++;
        }

        center.getWorld().spawnParticle(Particle.EXPLOSION, center, 3, 0.5, 0.3, 0.5, 0);
        center.getWorld().spawnParticle(Particle.SWEEP_ATTACK, center, 15, 3, 0.5, 3, 0);
        center.getWorld().playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 0.8f);

        user.sendMessage("§c§l💥 §cOnda Expansiva lanzó a §e" + affected + " §cjugadores!");
        if (affected == 0) {
            user.sendMessage("§7No había nadie cerca...");
        }
    }

    /** ☄ BOMBARDEO — Lluvia de bolas de fuego */
    private void activateBombardment(Player user) {
        Location center = user.getLocation();

        user.sendMessage("§6§l☄ §6¡BOMBARDEO ACTIVADO!");
        Bukkit.broadcastMessage("§6§l☄ §e" + user.getName() + " §factivó §6§lBOMBARDEO §f¡A cubierto!");

        new BukkitRunnable() {
            int ticks = 0;
            final Random random = new Random();

            @Override
            public void run() {
                if (ticks >= bombardDuration || !user.isOnline()) { cancel(); return; }

                if (ticks % 3 == 0) {
                    for (int i = 0; i < 2; i++) {
                        Location spawnLoc = center.clone().add(
                                random.nextDouble() * bombardRadius * 2 - bombardRadius,
                                bombardHeight,
                                random.nextDouble() * bombardRadius * 2 - bombardRadius
                        );
                        SmallFireball fireball = spawnLoc.getWorld().spawn(spawnLoc, SmallFireball.class);
                        fireball.setVelocity(new Vector(0, -1.5, 0));
                        fireball.setShooter(user);
                        fireball.setIsIncendiary(false);
                        fireball.setYield(0);
                    }
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    /** ☢ NUKE — Explosión masiva con cuenta regresiva */
    private void activateNuke(Player user) {
        Location center = user.getLocation();

        Bukkit.broadcastMessage("");
        Bukkit.broadcastMessage("§4§l☢ NUKE §8» §c" + user.getName() + " §factivó una §4§lNUKE");
        Bukkit.broadcastMessage("§7¡Todos los jugadores cercanos recibirán daño!");
        Bukkit.broadcastMessage("");

        new BukkitRunnable() {
            int countdown = nukeCountdown;

            @Override
            public void run() {
                if (!user.isOnline()) { cancel(); return; }

                if (countdown > 0) {
                    for (Player p : center.getWorld().getPlayers()) {
                        if (isInPvP(p) && p.getLocation().distance(center) < nukeWarnRange) {
                            p.sendTitle("§4§l" + countdown, "§c☢ NUKE INMINENTE...", 0, 25, 0);
                            p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 2f, 0.5f);
                        }
                    }
                    countdown--;
                } else {
                    cancel();
                    detonateNuke(user, center);
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    private void detonateNuke(Player user, Location center) {
        if (!user.isOnline()) return;

        center.getWorld().createExplosion(center, 0f, false, false);
        center.getWorld().playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 3f, 0.5f);

        center.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, center, 5, 2, 2, 2, 0);
        center.getWorld().spawnParticle(Particle.FLAME, center, 200, 5, 3, 5, 0.1);
        center.getWorld().spawnParticle(Particle.LAVA, center, 50, 3, 2, 3, 0);

        // Flash blanco
        for (Player p : center.getWorld().getPlayers()) {
            if (p.getLocation().distance(center) < nukeFlashRange) {
                p.sendTitle("§f§l☢", "", 0, 5, 10);
            }
        }

        int damaged = 0;
        for (Player nearby : center.getWorld().getPlayers()) {
            if (nearby.equals(user)) continue;
            double distance = nearby.getLocation().distance(center);
            if (distance > nukeDamageRange) continue;
            if (!isInPvP(nearby)) continue;

            double damage = nukeMaxDmg * (1.0 - distance / nukeDamageRange);
            nearby.damage(Math.max(damage, nukeMinDmg), user);

            Vector dir = nearby.getLocation().toVector().subtract(center.toVector());
            if (dir.lengthSquared() < 0.001) dir = new Vector(0, 1, 0);
            dir = dir.normalize();
            dir.setY(nukeKnockbackY);
            dir.multiply(nukeKnockbackMult);
            nearby.setVelocity(dir);
            damaged++;
        }
        user.sendMessage("§4§l☢ §cNuke impactó a §e" + damaged + " §cjugadores!");
    }

    // ══════════════════════════════════════════
    //        UTILIDADES
    // ══════════════════════════════════════════

    /**
     * Checks if a player is in a PvP context (has "ffa" or similar context in core).
     */
    private boolean isInPvP(Player player) {
        return core.getContextManager().hasContext(player.getUniqueId(), "ffa");
    }

    private Player getNearestPlayer(Player source, double maxDistance) {
        Player nearest = null;
        double nearestDist = maxDistance + 1;
        for (Player p : source.getWorld().getPlayers()) {
            if (p.equals(source)) continue;
            if (!isInPvP(p)) continue;
            double dist = p.getLocation().distance(source.getLocation());
            if (dist < nearestDist && dist <= maxDistance) {
                nearest = p;
                nearestDist = dist;
            }
        }
        return nearest;
    }

    public int getStreak(UUID uuid) { return activeStreaks.getOrDefault(uuid, 0); }
    public int getStreak(Player player) { return getStreak(player.getUniqueId()); }
    public void resetStreak(UUID uuid) { activeStreaks.remove(uuid); }

    /**
     * Get streak title label (matching original UltimateFFA).
     */
    public String getStreakTitle(int streak) {
        if (streak >= 50) return "§d§lLEYENDA";
        if (streak >= 40) return "§4§lMÁQUINA";
        if (streak >= 30) return "§4§lIMPARABLE";
        if (streak >= 25) return "§c§lPELIGROSO";
        if (streak >= 20) return "§c§lEXTREMO";
        if (streak >= 15) return "§6§lLETAL";
        if (streak >= 10) return "§e§lRABIOSO";
        if (streak >= 5)  return "§a§lCOMBO";
        if (streak >= 3)  return "§3RACHA";
        return "";
    }

    /**
     * Remove ability items from a player's inventory (on death or arena leave).
     */
    public void removeAbilityItems(Player player) {
        for (int i = 0; i < player.getInventory().getSize(); i++) {
            ItemStack item = player.getInventory().getItem(i);
            if (item != null && item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
                if (item.getItemMeta().getDisplayName().startsWith(ABILITY_TAG)) {
                    player.getInventory().setItem(i, null);
                }
            }
        }
    }
}
