package com.ethernova.combat.command;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Admin combat commands: /combatadmin reload, tag, untag, status
 */
public class CombatAdminCommand implements CommandExecutor, TabCompleter {

    private final EthernovaCombat plugin;

    public CombatAdminCommand(EthernovaCombat plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("ethernova.combat.admin")) {
            plugin.getMessageManager().send(sender, "general.no-permission"); return true;
        }
        if (args.length == 0) {
            if (sender instanceof Player player) {
                plugin.getGuiManager().openMainMenu(player);
            } else {
                plugin.getMessageManager().send(sender, "admin.usage");
            }
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "gui" -> {
                if (!(sender instanceof Player player)) {
                    plugin.getMessageManager().send(sender, "admin.player-only");
                    return true;
                }
                plugin.getGuiManager().openMainMenu(player);
            }
            case "reload" -> {
                plugin.getConfigManager().reload();
                plugin.getMessageManager().load();
                plugin.getMessageManager().send(sender, "admin-gui.reload-success");
            }
            case "tag" -> {
                if (args.length < 3) { plugin.getMessageManager().send(sender, "admin.tag-usage"); return true; }
                Player p1 = Bukkit.getPlayer(args[1]);
                Player p2 = Bukkit.getPlayer(args[2]);
                if (p1 == null || p2 == null) { plugin.getMessageManager().send(sender, "admin.tag-not-found"); return true; }
                plugin.getTagManager().tag(p1, p2, "default");
                plugin.getTagManager().tag(p2, p1, "default");
                plugin.getMessageManager().send(sender, "admin.tag-success", "{player1}", p1.getName(), "{player2}", p2.getName());
            }
            case "untag" -> {
                if (args.length < 2) return true;
                Player target = Bukkit.getPlayer(args[1]);
                if (target != null) { plugin.getTagManager().untag(target); plugin.getMessageManager().send(sender, "admin.untag-success", "{target}", target.getName()); }
            }
        }
        return true;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String alias, @NotNull String[] args) {
        if (!sender.hasPermission("ethernova.combat.admin")) return List.of();
        if (args.length == 1) return Arrays.asList("reload", "tag", "untag", "gui").stream().filter(s -> s.startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        if (args.length == 2) return null;
        return List.of();
    }
}
