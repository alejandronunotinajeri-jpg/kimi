package com.ethernova.combat.npc;

import org.bukkit.Location;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public class CombatNPC {

    private final UUID playerUuid;
    private final UUID entityUuid;
    private final int duration;
    private volatile boolean killed;
    private final ItemStack[] inventory;
    private final ItemStack[] armor;
    private final Location spawnLocation;
    /** Citizens NPC registry ID, or {@code -1} if this is a Zombie-fallback NPC. */
    private final int citizensNpcId;

    public CombatNPC(UUID playerUuid, UUID entityUuid, int duration,
                     ItemStack[] inventory, ItemStack[] armor, Location spawnLocation,
                     int citizensNpcId) {
        this.playerUuid = playerUuid;
        this.entityUuid = entityUuid;
        this.duration = duration;
        this.inventory = inventory;
        this.armor = armor;
        this.spawnLocation = spawnLocation;
        this.citizensNpcId = citizensNpcId;
    }

    public UUID getPlayerUuid() { return playerUuid; }
    public UUID getEntityUuid() { return entityUuid; }
    public int getDuration() { return duration; }
    public boolean isKilled() { return killed; }
    public void setKilled(boolean killed) { this.killed = killed; }
    public ItemStack[] getInventory() { return inventory; }
    public ItemStack[] getArmor() { return armor; }
    public Location getSpawnLocation() { return spawnLocation; }
    public int getCitizensNpcId() { return citizensNpcId; }
}
