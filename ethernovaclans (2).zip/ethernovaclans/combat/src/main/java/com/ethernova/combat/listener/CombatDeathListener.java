package com.ethernova.combat.listener;

import com.ethernova.combat.EthernovaCombat;
import com.ethernova.combat.module.ModuleConfigManager;
import com.ethernova.combat.tag.CombatTagManager;
import com.ethernova.core.event.EthernovaPlayerKillEvent;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.entity.PlayerDeathEvent;

import java.util.ArrayList;

public class CombatDeathListener implements Listener {

    private final EthernovaCombat plugin;

    public CombatDeathListener(EthernovaCombat plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();

        // Skip NPC deaths (Citizens or other NPC plugins)
        if (victim.hasMetadata("NPC")) return;

        Player killer = victim.getKiller();

        plugin.getTagManager().untag(victim);

        // Check per-world keepInventory setting
        var worldConfig = plugin.getWorldConfigManager().getConfig(victim.getWorld());
        boolean keepInv = worldConfig != null && worldConfig.isKeepInventory();

        // Check per-module keepInventory override
        String victimProfile = plugin.getProfileManager().getActiveProfile(victim);
        String moduleId = CombatTagManager.profileToModuleId(victimProfile);
        ModuleConfigManager.ModuleConfig moduleConfig = null;
        if (moduleId != null && plugin.getModuleConfigManager() != null) {
            moduleConfig = plugin.getModuleConfigManager().getConfig(moduleId);
            if (moduleConfig.isKeepInventory()) keepInv = true;
        }

        if (keepInv) {
            event.getDrops().clear();
            event.setDroppedExp(0);
            event.setKeepInventory(true);
            event.setKeepLevel(true);
        }

        // Send death recap to victim
        if (plugin.getDeathRecapManager() != null) {
            plugin.getDeathRecapManager().sendRecap(victim);
        }

        // Reset streak abilities on death
        if (plugin.getStreakAbilityManager() != null) {
            plugin.getStreakAbilityManager().reset(victim.getUniqueId());
        }

        // Reset combo on death
        if (plugin.getComboManager() != null) {
            plugin.getComboManager().resetCombo(victim.getUniqueId());
        }

        if (killer == null || killer.equals(victim)) {
            // Still reset killstreak on non-PvP death
            plugin.getKillStreakManager().onDeath(victim);
            return;
        }

        String context = plugin.getProfileManager().getActiveProfile(killer);

        // Use new DetectionManager (enhanced detection) if available, fallback to legacy
        boolean abusive;
        if (plugin.getDetectionManager() != null) {
            abusive = plugin.getDetectionManager().checkKill(killer, victim);
        } else {
            abusive = plugin.getAbuseManager().isAbusiveKill(killer, victim);
        }

        // Only reset killstreak after abuse check — abusers should not grief victim's streak
        plugin.getKillStreakManager().onDeath(victim);

        if (!abusive) {
            var kp = plugin.getCore().getProfileManager().getProfile(killer.getUniqueId());
            var vp = plugin.getCore().getProfileManager().getProfile(victim.getUniqueId());
            if (kp != null) kp.addKill();
            if (vp != null) vp.addDeath();

            plugin.getKillStreakManager().addKill(killer);
            plugin.getKillStreakManager().checkMilestone(killer);

            // Streak abilities: check and apply potion buffs at streak milestones
            if (plugin.getStreakAbilityManager() != null) {
                int currentStreak = plugin.getKillStreakManager().getStreak(killer.getUniqueId());
                plugin.getStreakAbilityManager().checkAndApply(killer, currentStreak);
            }

            // Advanced weapon stats: record kill with distance
            if (plugin.getAdvancedStatsManager() != null) {
                double distance = killer.getLocation().distance(victim.getLocation());
                plugin.getAdvancedStatsManager().recordKill(
                        killer.getUniqueId(),
                        killer.getInventory().getItemInMainHand().getType(),
                        distance);
            }

            plugin.getRewardManager().processKillReward(killer, victim);
            plugin.getRewardManager().processDeathPenalty(victim);
            plugin.getDeathEffectManager().applyDeathEffects(victim, killer);
            plugin.getVisualManager().sendKillFeed(killer, victim);

            // Bounty system: claim bounties on victim + check auto-bounty on killer
            if (plugin.getBountyManager() != null) {
                plugin.getBountyManager().claimBounties(killer.getUniqueId(), victim.getUniqueId());
                int streak = plugin.getKillStreakManager().getStreak(killer.getUniqueId());
                plugin.getBountyManager().checkAutoBounty(killer, streak);
            }

            // Revenge system
            if (plugin.getRevengeManager() != null) {
                plugin.getRevengeManager().processRevenge(killer, victim);
                plugin.getRevengeManager().recordKill(killer.getUniqueId(), victim.getUniqueId());
            }

            // Publish kill event only for legitimate kills
            plugin.getCore().getEventBus().publish(new EthernovaPlayerKillEvent(
                    killer.getUniqueId(), killer.getName(),
                    victim.getUniqueId(), victim.getName(), context,
                    victim.getLocation().clone()));
        }

        plugin.getTagManager().untag(killer);

        // Loot protection: skip if keepInv is active or module disables it
        boolean lootProtEnabled = plugin.getConfigManager().getBoolean("loot-protection.enabled", true);
        if (moduleConfig != null) {
            lootProtEnabled = lootProtEnabled && moduleConfig.isLootProtection();
        }
        if (lootProtEnabled && !keepInv) {
            // Capture death location NOW before respawn teleports the victim
            final org.bukkit.Location deathLoc = victim.getLocation().clone();
            final java.util.UUID killerUuid = killer.getUniqueId();
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                var nearbyItems = new ArrayList<org.bukkit.entity.Item>();
                deathLoc.getWorld().getNearbyEntities(deathLoc, 3, 3, 3).forEach(e -> {
                    // Only protect recently-spawned items (death drops), not pre-existing ground items
                    if (e instanceof org.bukkit.entity.Item item && item.getTicksLived() <= 5) {
                        nearbyItems.add(item);
                    }
                });
                if (!nearbyItems.isEmpty()) {
                    plugin.getLootManager().protectLoot(killerUuid, nearbyItems);
                }
            }, 2L);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTotem(EntityResurrectEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (plugin.getTagManager().isInCombat(player)) {
            var enemy = plugin.getTagManager().getEnemy(player.getUniqueId());
            if (enemy != null) {
                Player enemyPlayer = Bukkit.getPlayer(enemy);
                if (enemyPlayer != null) {
                    plugin.getTagManager().tag(player, enemyPlayer,
                            plugin.getTagManager().getProfile(player.getUniqueId()));
                }
            }
        }
    }
}
