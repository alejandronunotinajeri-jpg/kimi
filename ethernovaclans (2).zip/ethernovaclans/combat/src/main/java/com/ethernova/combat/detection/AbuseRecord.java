package com.ethernova.combat.detection;

import java.util.UUID;

/**
 * Represents a detected abuse violation.
 */
public record AbuseRecord(
        UUID player,
        String playerName,
        AbuseType type,
        String details,
        long timestamp
) {
    public enum AbuseType {
        MULTI_ACCOUNT,   // Same IP killing own alt
        KILL_FARMING,    // Farming kills on same victim repeatedly
        LOCATION_FARM,   // Kills consistently at same location
        LOW_GEAR_FARM    // Killing unarmed/unarmored players repeatedly
    }
}
