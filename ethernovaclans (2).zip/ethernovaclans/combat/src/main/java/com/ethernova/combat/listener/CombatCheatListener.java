package com.ethernova.combat.listener;

import com.ethernova.combat.EthernovaCombat;
import com.ethernova.combat.tag.CombatTagManager;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.*;

public class CombatCheatListener implements Listener {

    private final EthernovaCombat plugin;

    public CombatCheatListener(EthernovaCombat plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        Player p = event.getPlayer();
        if (!plugin.getTagManager().isInCombat(p)) return;
        if (!plugin.getCheatManager().blockCommands()) return;
        if (p.hasPermission("ethernova.combat.bypass.tag")) return;

        // Check per-module block-commands setting
        String profile = plugin.getProfileManager().getActiveProfile(p);
        String moduleId = CombatTagManager.profileToModuleId(profile);
        if (moduleId != null && plugin.getModuleConfigManager() != null) {
            var mc = plugin.getModuleConfigManager().getConfig(moduleId);
            if (!mc.isBlockCommands()) return;
        }

        String cmd = event.getMessage().split(" ")[0].substring(1).toLowerCase();
        // Strip namespace prefix (e.g., "essentials:spawn" → "spawn")
        if (cmd.contains(":")) cmd = cmd.substring(cmd.indexOf(':') + 1);

        // Check per-world blocked commands, fallback to global list
        var worldConfig = plugin.getWorldConfigManager().getConfig(p.getWorld());
        var blockedList = worldConfig.getBlockedCommands().isEmpty()
                ? plugin.getCheatManager().getBlockedCommands()
                : worldConfig.getBlockedCommands();
        if (blockedList.contains(cmd)) {
            event.setCancelled(true);
            plugin.getMessageManager().send(p, "combat.cannot-command");
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onFlight(PlayerToggleFlightEvent event) {
        Player p = event.getPlayer();
        if (!plugin.getTagManager().isInCombat(p)) return;
        // Check per-world fly-disabled setting
        var worldConfig = plugin.getWorldConfigManager().getConfig(p.getWorld());
        if (!worldConfig.isFlyDisabled() && !plugin.getCheatManager().blockFlight()) return;
        // Check per-module fly-disabled setting
        String profile = plugin.getProfileManager().getActiveProfile(p);
        String moduleId = CombatTagManager.profileToModuleId(profile);
        if (moduleId != null && plugin.getModuleConfigManager() != null) {
            var mc = plugin.getModuleConfigManager().getConfig(moduleId);
            if (!mc.isFlyDisabled()) return;
        }
        if (p.hasPermission("ethernova.combat.bypass.tag")) return;
        event.setCancelled(true);
        p.setFlying(false);
        // Don't remove allowFlight — other plugins may have granted it
        plugin.getMessageManager().send(p, "combat.cannot-fly");
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent event) {
        Player p = event.getPlayer();
        if (!plugin.getTagManager().isInCombat(p)) return;
        if (p.hasPermission("ethernova.combat.bypass.tag")) return;

        var cause = event.getCause();
        if (cause == PlayerTeleportEvent.TeleportCause.ENDER_PEARL && plugin.getCheatManager().blockEnderPearl()) {
            event.setCancelled(true);
            plugin.getMessageManager().send(p, "combat.cannot-enderpearl");
        } else if (cause == PlayerTeleportEvent.TeleportCause.CHORUS_FRUIT && plugin.getCheatManager().blockChorusFruit()) {
            event.setCancelled(true);
            plugin.getMessageManager().send(p, "combat.cannot-chorus");
        } else if (cause == PlayerTeleportEvent.TeleportCause.COMMAND && plugin.getCheatManager().blockTeleport()) {
            event.setCancelled(true);
            plugin.getMessageManager().send(p, "combat.cannot-teleport");
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onGameMode(PlayerGameModeChangeEvent event) {
        Player p = event.getPlayer();
        if (!plugin.getTagManager().isInCombat(p)) return;
        if (!plugin.getCheatManager().blockGamemodeChange()) return;
        if (p.hasPermission("ethernova.combat.bypass.tag")) return;
        event.setCancelled(true);
        plugin.getMessageManager().send(p, "combat.cannot-gamemode");
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onRiptide(PlayerRiptideEvent event) {
        Player p = event.getPlayer();
        if (!plugin.getTagManager().isInCombat(p)) return;
        if (!plugin.getCheatManager().blockRiptide()) return;
        if (p.hasPermission("ethernova.combat.bypass.tag")) return;
        org.bukkit.Location loc = p.getLocation().clone();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline() && plugin.getTagManager().isInCombat(p)
                    && p.getWorld().equals(loc.getWorld())) {
                p.teleport(loc);
                plugin.getMessageManager().send(p, "combat.cannot-riptide");
            }
        }, 5L);
    }
}
