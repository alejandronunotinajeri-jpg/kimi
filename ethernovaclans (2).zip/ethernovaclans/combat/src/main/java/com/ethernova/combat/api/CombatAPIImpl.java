package com.ethernova.combat.api;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.entity.Player;

import java.util.UUID;

/**
 * Implementation of CombatAPI. Registered with ServiceRegistry on enable.
 */
public class CombatAPIImpl implements CombatAPI {

    private final EthernovaCombat plugin;

    public CombatAPIImpl(EthernovaCombat plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean isInCombat(Player player) {
        return plugin.getTagManager().isInCombat(player);
    }

    @Override
    public boolean isInCombat(UUID uuid) {
        return plugin.getTagManager().isInCombat(uuid);
    }

    @Override
    public void tag(Player p1, Player p2, String profile) {
        plugin.getTagManager().tag(p1, p2, profile);
        plugin.getTagManager().tag(p2, p1, profile);
    }

    @Override
    public void untag(Player player) {
        plugin.getTagManager().untag(player);
    }

    @Override
    public int getRemainingSeconds(UUID uuid) {
        return plugin.getTagManager().getRemainingSeconds(uuid);
    }

    @Override
    public int getKillStreak(UUID uuid) {
        return plugin.getKillStreakManager().getStreak(uuid);
    }

    @Override
    public boolean isNewbieProtected(UUID uuid) {
        return plugin.getNewbieManager().isProtected(uuid);
    }
}
