package com.ethernova.combat;

import com.ethernova.combat.abuse.KDRAbuseManager;
import com.ethernova.combat.api.CombatAPIImpl;
import com.ethernova.combat.bounty.BountyCommand;
import com.ethernova.combat.bounty.BountyManager;
import com.ethernova.combat.cheat.CheatPreventionManager;
import com.ethernova.combat.combo.ComboManager;
import com.ethernova.combat.command.CombatAdminCommand;
import com.ethernova.combat.command.CombatCommand;
import com.ethernova.combat.command.LogoutCommand;
import com.ethernova.combat.config.CombatConfigManager;
import com.ethernova.combat.death.DeathEffectManager;
import com.ethernova.combat.deathrecap.DeathRecapManager;
import com.ethernova.combat.detection.DetectionManager;
import com.ethernova.combat.gui.AdminGUIListener;
import com.ethernova.combat.gui.AdminGUIManager;
import com.ethernova.combat.killstreak.KillStreakManager;
import com.ethernova.combat.listener.*;
import com.ethernova.combat.logout.SafeLogoutManager;
import com.ethernova.combat.loot.LootProtectionManager;
import com.ethernova.combat.message.CombatMessageManager;
import com.ethernova.combat.module.CombatModuleRegistry;
import com.ethernova.combat.newbie.NewbieProtectionManager;
import com.ethernova.combat.npc.CombatNPCManager;
import com.ethernova.combat.penalty.PenaltyManager;
import com.ethernova.combat.placeholder.CombatPlaceholders;
import com.ethernova.combat.profile.CombatProfileManager;
import com.ethernova.combat.revenge.RevengeManager;
import com.ethernova.combat.reward.RewardManager;
import com.ethernova.combat.streakability.StreakAbilityManager;
import com.ethernova.combat.tag.CombatAPI;
import com.ethernova.combat.tag.CombatTagManager;
import com.ethernova.combat.visual.CombatVisualManager;
import com.ethernova.combat.world.WorldConfigManager;
import com.ethernova.core.EthernovaCore;
import com.ethernova.core.service.ServiceRegistry;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.logging.Level;

public class EthernovaCombat extends JavaPlugin {

    private static volatile EthernovaCombat instance;
    private EthernovaCore core;

    private CombatConfigManager configManager;
    private CombatMessageManager messageManager;
    private CombatTagManager tagManager;
    private KillStreakManager killStreakManager;
    private CombatNPCManager npcManager;
    private RewardManager rewardManager;
    private PenaltyManager penaltyManager;
    private NewbieProtectionManager newbieManager;
    private KDRAbuseManager abuseManager;
    private SafeLogoutManager logoutManager;
    private LootProtectionManager lootManager;
    private CheatPreventionManager cheatManager;
    private DeathEffectManager deathEffectManager;
    private CombatProfileManager profileManager;
    private CombatVisualManager visualManager;
    private CombatAPI api;

    // New systems
    private WorldConfigManager worldConfigManager;
    private CombatModuleRegistry moduleRegistry;
    private com.ethernova.combat.module.ModuleConfigManager moduleConfigManager;
    private DetectionManager detectionManager;
    private AdminGUIManager guiManager;
    private RevengeManager revengeManager;
    private DeathRecapManager deathRecapManager;
    private BountyManager bountyManager;
    private ComboManager comboManager;
    private StreakAbilityManager streakAbilityManager;
    private com.ethernova.combat.stats.AdvancedStatsManager advancedStatsManager;

    @Override
    public void onEnable() {
        instance = this;
        long start = System.currentTimeMillis();

        getLogger().info("═══════════════════════════════════════════");
        getLogger().info("  EthernovaCombat v" + getDescription().getVersion());
        getLogger().info("═══════════════════════════════════════════");

        try {
            // Core dependency
            core = (EthernovaCore) Bukkit.getPluginManager().getPlugin("EthernovaCore");
            if (core == null) {
                getLogger().severe("EthernovaCore no encontrado! Deshabilitando...");
                Bukkit.getPluginManager().disablePlugin(this);
                return;
            }
            core.registerPlugin("EthernovaCombat");

            // Config & Messages
            configManager = new CombatConfigManager(this);
            configManager.loadAll();
            messageManager = new CombatMessageManager(this);

            // Managers
            tagManager = new CombatTagManager(this, core);
            killStreakManager = new KillStreakManager(this, core);
            npcManager = new CombatNPCManager(this, core);
            rewardManager = new RewardManager(this);
            penaltyManager = new PenaltyManager(this);
            newbieManager = new NewbieProtectionManager(this);
            abuseManager = new KDRAbuseManager(this);
            logoutManager = new SafeLogoutManager(this);
            lootManager = new LootProtectionManager(this);
            cheatManager = new CheatPreventionManager(this);
            deathEffectManager = new DeathEffectManager(this);
            profileManager = new CombatProfileManager(this);
            visualManager = new CombatVisualManager(this);

            // New systems
            worldConfigManager = new WorldConfigManager(this);
            worldConfigManager.load();
            moduleRegistry = new CombatModuleRegistry();
            moduleConfigManager = new com.ethernova.combat.module.ModuleConfigManager(getDataFolder(), getLogger());
            moduleConfigManager.load();

            // Auto-detect ecosystem plugins and register them as modules
            new com.ethernova.combat.module.EcosystemModuleDetector(this).detect();

            detectionManager = new DetectionManager(this);
            guiManager = new AdminGUIManager(this);
            revengeManager = new RevengeManager(this);
            deathRecapManager = new DeathRecapManager(this);
            bountyManager = new BountyManager(this);
            comboManager = new ComboManager(this);
            streakAbilityManager = new StreakAbilityManager(this);

            // Advanced Stats
            advancedStatsManager = new com.ethernova.combat.stats.AdvancedStatsManager(this);

            // API
            api = new com.ethernova.combat.tag.CombatAPI(this);
            ServiceRegistry.register(com.ethernova.core.api.CombatAPI.class, new CombatAPIImpl(this));
            getLogger().info("✔ CombatAPI registrada en ServiceRegistry");

            // Listeners
            registerListeners();

            // Commands
            registerCommands();

            // Clan integration (EventBus subscriptions)
            new ClanIntegrationListener(this);

            // PlaceholderAPI
            if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
                new CombatPlaceholders(this).register();
                getLogger().info("PlaceholderAPI expansion registrada: %combat_...%");
            }

            long elapsed = System.currentTimeMillis() - start;
            getLogger().info("═══════════════════════════════════════════");
            getLogger().info("  EthernovaCombat habilitado en " + elapsed + "ms");
            getLogger().info("═══════════════════════════════════════════");

        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Error habilitando EthernovaCombat", e);
            Bukkit.getPluginManager().disablePlugin(this);
        }
    }

    @Override
    public void onDisable() {
        Bukkit.getScheduler().cancelTasks(this);
        ServiceRegistry.unregister(com.ethernova.core.api.CombatAPI.class);
        if (worldConfigManager != null) worldConfigManager.save();
        if (moduleConfigManager != null) moduleConfigManager.save();
        if (tagManager != null) tagManager.shutdown();
        if (visualManager != null) visualManager.shutdown();
        if (logoutManager != null) logoutManager.cancelAll();
        if (npcManager != null) npcManager.removeAll();
        if (bountyManager != null) bountyManager.clearAll();
        if (detectionManager != null) detectionManager.getSanctionManager().saveOffenseLevels();
        if (advancedStatsManager != null) advancedStatsManager.saveAll();
        if (core != null) core.unregisterPlugin("EthernovaCombat");
        instance = null;
    }

    private void registerListeners() {
        var pm = Bukkit.getPluginManager();
        pm.registerEvents(new CombatDamageListener(this), this);
        pm.registerEvents(new CombatDeathListener(this), this);
        pm.registerEvents(new CombatDisconnectListener(this), this);
        pm.registerEvents(new CombatCheatListener(this), this);
        pm.registerEvents(new CombatMoveListener(this), this);
        pm.registerEvents(new CombatItemListener(this), this);
        pm.registerEvents(new CombatNPCListener(this), this);
        pm.registerEvents(new AdminGUIListener(this, guiManager), this);
    }

    private void registerCommands() {
        CombatCommand combatCmd = new CombatCommand(this);
        var combatCmdReg = getCommand("combat");
        if (combatCmdReg != null) { combatCmdReg.setExecutor(combatCmd); combatCmdReg.setTabCompleter(combatCmd); }
        else getLogger().warning("Command 'combat' not found in plugin.yml!");

        CombatAdminCommand adminCmd = new CombatAdminCommand(this);
        var adminCmdReg = getCommand("combatadmin");
        if (adminCmdReg != null) { adminCmdReg.setExecutor(adminCmd); adminCmdReg.setTabCompleter(adminCmd); }
        else getLogger().warning("Command 'combatadmin' not found in plugin.yml!");

        var logoutCmdReg = getCommand("logout");
        if (logoutCmdReg != null) logoutCmdReg.setExecutor(new LogoutCommand(this));
        else getLogger().warning("Command 'logout' not found in plugin.yml!");

        var bountyCmdReg = getCommand("bounty");
        if (bountyCmdReg != null) {
            BountyCommand bc = new BountyCommand(this);
            bountyCmdReg.setExecutor(bc);
            bountyCmdReg.setTabCompleter(bc);
        }

        var deathRecapCmdReg = getCommand("deathrecap");
        if (deathRecapCmdReg != null) deathRecapCmdReg.setExecutor(new com.ethernova.combat.command.DeathRecapCommand(this));
    }

    // Getters
    public static EthernovaCombat getInstance() { return instance; }
    public EthernovaCore getCore() { return core; }
    public CombatConfigManager getConfigManager() { return configManager; }
    public CombatMessageManager getMessageManager() { return messageManager; }
    public CombatTagManager getTagManager() { return tagManager; }
    public KillStreakManager getKillStreakManager() { return killStreakManager; }
    public CombatNPCManager getNpcManager() { return npcManager; }
    public RewardManager getRewardManager() { return rewardManager; }
    public PenaltyManager getPenaltyManager() { return penaltyManager; }
    public NewbieProtectionManager getNewbieManager() { return newbieManager; }
    public KDRAbuseManager getAbuseManager() { return abuseManager; }
    public SafeLogoutManager getLogoutManager() { return logoutManager; }
    public LootProtectionManager getLootManager() { return lootManager; }
    public CheatPreventionManager getCheatManager() { return cheatManager; }
    public DeathEffectManager getDeathEffectManager() { return deathEffectManager; }
    public CombatProfileManager getProfileManager() { return profileManager; }
    public CombatVisualManager getVisualManager() { return visualManager; }
    public CombatAPI getApi() { return api; }
    public WorldConfigManager getWorldConfigManager() { return worldConfigManager; }
    public CombatModuleRegistry getModuleRegistry() { return moduleRegistry; }
    public com.ethernova.combat.module.ModuleConfigManager getModuleConfigManager() { return moduleConfigManager; }
    public DetectionManager getDetectionManager() { return detectionManager; }
    public AdminGUIManager getGuiManager() { return guiManager; }
    public RevengeManager getRevengeManager() { return revengeManager; }
    public DeathRecapManager getDeathRecapManager() { return deathRecapManager; }
    public BountyManager getBountyManager() { return bountyManager; }
    public ComboManager getComboManager() { return comboManager; }
    public StreakAbilityManager getStreakAbilityManager() { return streakAbilityManager; }
    public com.ethernova.combat.stats.AdvancedStatsManager getAdvancedStatsManager() { return advancedStatsManager; }
}