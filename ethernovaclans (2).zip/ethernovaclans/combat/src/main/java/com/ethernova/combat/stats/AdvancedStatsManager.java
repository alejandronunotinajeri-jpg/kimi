package com.ethernova.combat.stats;

import com.ethernova.combat.EthernovaCombat;
import com.ethernova.core.EthernovaCore;
import com.ethernova.core.storage.CoreStorageManager;
import com.ethernova.core.storage.MigrationManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Tracks advanced per-weapon kill statistics, accuracy, and combat metrics.
 * <p>
 * Features:
 * <ul>
 *   <li>Per-weapon kill tracking (sword, axe, bow, trident, etc.)</li>
 *   <li>Favorite weapon detection</li>
 *   <li>Kill distance tracking (longest kill)</li>
 *   <li>Combat session metrics (DPS, hits/misses)</li>
 *   <li>Persistent DB storage with in-memory cache</li>
 * </ul>
 * <p>
 * DB table: ethernova_weapon_stats (uuid, weapon, kills, damage_dealt)
 */
public class AdvancedStatsManager {

    private final EthernovaCombat plugin;
    private final CoreStorageManager storage;
    private final Logger logger;

    // Cache: UUID -> weapon stats
    private final Map<UUID, Map<String, WeaponStats>> playerStats = new ConcurrentHashMap<>();

    // Session tracking: UUID -> combat session
    private final Map<UUID, CombatSession> activeSessions = new ConcurrentHashMap<>();

    public AdvancedStatsManager(EthernovaCombat plugin) {
        this.plugin = plugin;
        this.storage = plugin.getCore().getStorageManager();
        this.logger = plugin.getLogger();
        runMigrations();
    }

    private void runMigrations() {
        new MigrationManager(storage, logger, "ethernova_advstats")
                .addMigration(1,
                        """
                        CREATE TABLE IF NOT EXISTS ethernova_weapon_stats (
                            uuid VARCHAR(36) NOT NULL,
                            weapon VARCHAR(32) NOT NULL,
                            kills INT DEFAULT 0,
                            damage_dealt DOUBLE DEFAULT 0,
                            longest_kill DOUBLE DEFAULT 0,
                            PRIMARY KEY (uuid, weapon)
                        )
                        """)
                .migrate();
    }

    // ═══════════════════════════════════════
    //  MODELS
    // ═══════════════════════════════════════

    public static class WeaponStats {
        private volatile int kills;
        private volatile double damageDealt;
        private volatile double longestKill;
        private volatile boolean dirty;

        public WeaponStats() {}
        public WeaponStats(int kills, double damageDealt, double longestKill) {
            this.kills = kills;
            this.damageDealt = damageDealt;
            this.longestKill = longestKill;
        }

        public int getKills() { return kills; }
        public double getDamageDealt() { return damageDealt; }
        public double getLongestKill() { return longestKill; }

        public synchronized void addKill(double distance) {
            kills++;
            if (distance > longestKill) longestKill = distance;
            dirty = true;
        }

        public synchronized void addDamage(double amount) {
            damageDealt += amount;
            dirty = true;
        }

        public boolean isDirty() { return dirty; }
        public void markClean() { dirty = false; }
    }

    public static class CombatSession {
        private int hits;
        private int misses;
        private double totalDamage;
        private long startTime;

        public CombatSession() {
            this.startTime = System.currentTimeMillis();
        }

        public void recordHit(double damage) { hits++; totalDamage += damage; }
        public void recordMiss() { misses++; }
        public int getHits() { return hits; }
        public int getMisses() { return misses; }
        public double getTotalDamage() { return totalDamage; }
        public double getAccuracy() {
            int total = hits + misses;
            return total > 0 ? (double) hits / total * 100 : 0;
        }
        public double getDPS() {
            long elapsed = Math.max(1, (System.currentTimeMillis() - startTime) / 1000);
            return totalDamage / elapsed;
        }
    }

    // ═══════════════════════════════════════
    //  TRACKING
    // ═══════════════════════════════════════

    /**
     * Record a kill with the specified weapon at the given distance.
     */
    public void recordKill(UUID killer, Material weapon, double distance) {
        String weaponName = normalizeWeapon(weapon);
        playerStats
                .computeIfAbsent(killer, k -> new ConcurrentHashMap<>())
                .computeIfAbsent(weaponName, k -> new WeaponStats())
                .addKill(distance);
    }

    /**
     * Record damage dealt with a weapon.
     */
    public void recordDamage(UUID attacker, Material weapon, double amount) {
        String weaponName = normalizeWeapon(weapon);
        playerStats
                .computeIfAbsent(attacker, k -> new ConcurrentHashMap<>())
                .computeIfAbsent(weaponName, k -> new WeaponStats())
                .addDamage(amount);

        // Also track in combat session
        CombatSession session = activeSessions.computeIfAbsent(attacker, k -> new CombatSession());
        session.recordHit(amount);
    }

    /**
     * Record a miss (attack that dealt no damage).
     */
    public void recordMiss(UUID attacker) {
        CombatSession session = activeSessions.computeIfAbsent(attacker, k -> new CombatSession());
        session.recordMiss();
    }

    /**
     * Normalize weapon material to a consistent category.
     */
    private String normalizeWeapon(Material material) {
        if (material == null) return "fist";
        String name = material.name().toLowerCase();
        if (name.contains("sword")) return "sword";
        if (name.contains("_axe")) return "axe";
        if (name.endsWith("bow") && !name.contains("cross")) return "bow";
        if (name.contains("crossbow")) return "crossbow";
        if (name.contains("trident")) return "trident";
        if (name.contains("mace")) return "mace";
        return name;
    }

    // ═══════════════════════════════════════
    //  QUERIES
    // ═══════════════════════════════════════

    /**
     * Get all weapon stats for a player.
     */
    public Map<String, WeaponStats> getWeaponStats(UUID uuid) {
        return playerStats.getOrDefault(uuid, Collections.emptyMap());
    }

    /**
     * Get the player's favorite weapon (most kills).
     */
    public String getFavoriteWeapon(UUID uuid) {
        Map<String, WeaponStats> stats = playerStats.get(uuid);
        if (stats == null || stats.isEmpty()) return "none";
        return stats.entrySet().stream()
                .max(Comparator.comparingInt(e -> e.getValue().getKills()))
                .map(Map.Entry::getKey)
                .orElse("none");
    }

    /**
     * Get total kills across all weapons.
     */
    public int getTotalKills(UUID uuid) {
        Map<String, WeaponStats> stats = playerStats.get(uuid);
        if (stats == null) return 0;
        return stats.values().stream().mapToInt(WeaponStats::getKills).sum();
    }

    /**
     * Get the longest kill distance.
     */
    public double getLongestKill(UUID uuid) {
        Map<String, WeaponStats> stats = playerStats.get(uuid);
        if (stats == null) return 0;
        return stats.values().stream().mapToDouble(WeaponStats::getLongestKill).max().orElse(0);
    }

    /**
     * Get combat session (current active session).
     */
    public CombatSession getSession(UUID uuid) {
        return activeSessions.get(uuid);
    }

    /**
     * Reset combat session (e.g., on death).
     */
    public void resetSession(UUID uuid) {
        activeSessions.remove(uuid);
    }

    // ═══════════════════════════════════════
    //  PERSISTENCE
    // ═══════════════════════════════════════

    /**
     * Load player weapon stats from DB.
     */
    public CompletableFuture<Void> loadPlayer(UUID uuid) {
        return CompletableFuture.runAsync(() -> {
            try (Connection conn = storage.getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "SELECT weapon, kills, damage_dealt, longest_kill FROM ethernova_weapon_stats WHERE uuid = ?")) {
                ps.setString(1, uuid.toString());
                ResultSet rs = ps.executeQuery();
                Map<String, WeaponStats> stats = new ConcurrentHashMap<>();
                while (rs.next()) {
                    String weapon = rs.getString("weapon");
                    stats.put(weapon, new WeaponStats(
                            rs.getInt("kills"),
                            rs.getDouble("damage_dealt"),
                            rs.getDouble("longest_kill")
                    ));
                }
                if (!stats.isEmpty()) {
                    playerStats.put(uuid, stats);
                }
            } catch (Exception e) {
                logger.log(Level.SEVERE, "Error loading weapon stats for " + uuid, e);
            }
        }, EthernovaCore.getInstance().getDbExecutor());
    }

    /**
     * Save dirty weapon stats to DB.
     */
    public CompletableFuture<Void> savePlayer(UUID uuid) {
        Map<String, WeaponStats> stats = playerStats.get(uuid);
        if (stats == null || stats.isEmpty()) return CompletableFuture.completedFuture(null);

        return CompletableFuture.runAsync(() -> {
            try (Connection conn = storage.getConnection()) {
                conn.setAutoCommit(false);
                try {
                    String sql = storage.isMySQL()
                            ? "INSERT INTO ethernova_weapon_stats (uuid, weapon, kills, damage_dealt, longest_kill) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE kills = VALUES(kills), damage_dealt = VALUES(damage_dealt), longest_kill = GREATEST(longest_kill, VALUES(longest_kill))"
                            : "INSERT INTO ethernova_weapon_stats (uuid, weapon, kills, damage_dealt, longest_kill) VALUES (?, ?, ?, ?, ?) ON CONFLICT(uuid, weapon) DO UPDATE SET kills=excluded.kills, damage_dealt=excluded.damage_dealt, longest_kill=MAX(longest_kill, excluded.longest_kill)";

                    try (PreparedStatement ps = conn.prepareStatement(sql)) {
                        List<WeaponStats> batch = new ArrayList<>();
                        for (Map.Entry<String, WeaponStats> entry : stats.entrySet()) {
                            WeaponStats ws = entry.getValue();
                            if (!ws.isDirty()) continue;
                            ps.setString(1, uuid.toString());
                            ps.setString(2, entry.getKey());
                            ps.setInt(3, ws.getKills());
                            ps.setDouble(4, ws.getDamageDealt());
                            ps.setDouble(5, ws.getLongestKill());
                            ps.addBatch();
                            batch.add(ws);
                        }
                        ps.executeBatch();
                    }
                    conn.commit();
                    // Only mark clean AFTER successful commit
                    stats.values().stream().filter(WeaponStats::isDirty).forEach(WeaponStats::markClean);
                } catch (Exception e) {
                    conn.rollback();
                    throw e;
                } finally {
                    conn.setAutoCommit(true);
                }
            } catch (Exception e) {
                logger.log(Level.SEVERE, "Error saving weapon stats for " + uuid, e);
            }
        }, EthernovaCore.getInstance().getDbExecutor());
    }

    /**
     * Unload player data, saving first.
     * Chains removal after save completes to prevent data loss.
     */
    public void unloadPlayer(UUID uuid) {
        activeSessions.remove(uuid);
        savePlayer(uuid).thenRun(() -> playerStats.remove(uuid));
    }

    /**
     * Save all dirty data (shutdown). Blocks until all saves complete.
     */
    public void saveAll() {
        List<CompletableFuture<Void>> futures = new ArrayList<>();
        for (UUID uuid : playerStats.keySet()) {
            futures.add(savePlayer(uuid));
        }
        try {
            CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).get(10, java.util.concurrent.TimeUnit.SECONDS);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error waiting for weapon stats save on shutdown", e);
        }
    }
}
