package com.ethernova.combat.death;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

public class DeathEffectManager {

    private final EthernovaCombat plugin;

    public DeathEffectManager(EthernovaCombat plugin) { this.plugin = plugin; }

    public void applyDeathEffects(Player victim, Player killer) {
        var config = plugin.getConfigManager().getConfig();
        if (!config.getBoolean("death-effects.enabled", true)) return;

        // Particle
        if (config.getBoolean("death-effects.particle", true)) {
            victim.getWorld().spawnParticle(Particle.DUST,
                    victim.getLocation().add(0, 1, 0), 30,
                    0.5, 0.5, 0.5,
                    new Particle.DustOptions(org.bukkit.Color.RED, 2));
        }

        // Sound
        String soundName = config.getString("death-effects.sound", "ENTITY_PLAYER_DEATH");
        try {
            Sound sound = Sound.valueOf(soundName);
            victim.getWorld().playSound(victim.getLocation(), sound, 1f, 1f);
        } catch (Exception ignored) {}

        // Lightning
        if (config.getBoolean("death-effects.lightning", false)) {
            victim.getWorld().strikeLightningEffect(victim.getLocation());
        }
    }

    public void broadcastCombatLogDeath(String playerName) {
        var config = plugin.getConfigManager().getConfig();
        if (!config.getBoolean("combat-log.broadcast-death", true)) return;
        String msg = plugin.getMessageManager().get("combat.log-death")
                .replace("{player}", playerName);
        Bukkit.broadcast(plugin.getCore().getMessageManager().getMiniMessage().deserialize(msg));
    }
}
