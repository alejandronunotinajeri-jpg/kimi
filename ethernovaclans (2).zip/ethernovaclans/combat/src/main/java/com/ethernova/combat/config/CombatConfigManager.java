package com.ethernova.combat.config;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.logging.Level;

public class CombatConfigManager {

    private final JavaPlugin plugin;
    private FileConfiguration config;
    private YamlConfiguration killStreaksConfig;
    private YamlConfiguration rewardsConfig;
    private YamlConfiguration profilesConfig;

    public CombatConfigManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void loadAll() {
        File configFile = new File(plugin.getDataFolder(), "config.yml");
        boolean existed = configFile.exists();

        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        config = plugin.getConfig();

        if (existed) {
            plugin.getLogger().info("config.yml existente cargado (no se sobreescribió)");
            mergeDefaults(configFile);
        } else {
            plugin.getLogger().info("config.yml creado por primera vez con valores por defecto");
        }

        killStreaksConfig = loadYaml("killstreaks.yml");
        rewardsConfig = loadYaml("rewards.yml");
        profilesConfig = loadYaml("profiles.yml");
    }

    private void mergeDefaults(File configFile) {
        try (InputStream defStream = plugin.getResource("config.yml")) {
            if (defStream == null) return;
            YamlConfiguration defaults = YamlConfiguration.loadConfiguration(
                    new InputStreamReader(defStream, StandardCharsets.UTF_8));

            Set<String> allDefaultKeys = defaults.getKeys(true);
            int added = 0;
            for (String key : allDefaultKeys) {
                if (!config.contains(key)) {
                    config.set(key, defaults.get(key));
                    added++;
                }
            }
            if (added > 0) {
                plugin.saveConfig();
                plugin.reloadConfig();
                config = plugin.getConfig();
                plugin.getLogger().info("config.yml actualizado: " + added + " clave(s) nueva(s) añadida(s)");
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error al hacer merge de config defaults", e);
        }
    }

    private YamlConfiguration loadYaml(String name) {
        File file = new File(plugin.getDataFolder(), name);
        if (!file.exists()) {
            try { plugin.saveResource(name, false); } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Could not save default resource " + name, e);
            }
        }
        return file.exists() ? YamlConfiguration.loadConfiguration(file) : new YamlConfiguration();
    }

    public FileConfiguration getConfig() { return config; }
    public YamlConfiguration getKillStreaksConfig() { return killStreaksConfig; }
    public YamlConfiguration getRewardsConfig() { return rewardsConfig; }
    public YamlConfiguration getProfilesConfig() { return profilesConfig; }

    public String getString(String path, String def) { return config.getString(path, def); }
    public int getInt(String path, int def) { return config.getInt(path, def); }
    public double getDouble(String path, double def) { return config.getDouble(path, def); }
    public boolean getBoolean(String path, boolean def) { return config.getBoolean(path, def); }
    public long getLong(String path, long def) { return config.getLong(path, def); }

    public void reload() {
        loadAll();
    }
}
