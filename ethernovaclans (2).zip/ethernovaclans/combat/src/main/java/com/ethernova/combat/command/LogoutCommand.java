package com.ethernova.combat.command;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class LogoutCommand implements CommandExecutor {

    private final EthernovaCombat plugin;

    public LogoutCommand(EthernovaCombat plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String label, @NotNull String[] args) {
        if (sender instanceof Player player) plugin.getLogoutManager().startLogout(player);
        return true;
    }
}
