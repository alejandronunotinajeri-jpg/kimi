package com.ethernova.combat.gui;

import com.ethernova.combat.EthernovaCombat;
import com.ethernova.combat.bounty.BountyManager;
import com.ethernova.combat.detection.DetectionManager;
import com.ethernova.combat.world.WorldCombatConfig;
import com.ethernova.combat.world.WorldConfigManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

import java.util.*;

/**
 * Handles all inventory click events for the Combat Admin GUI system.
 * Routes clicks to the correct handler based on which GUI screen is open.
 */
public class AdminGUIListener implements Listener {

    private final EthernovaCombat plugin;
    private final AdminGUIManager guiManager;

    public AdminGUIListener(EthernovaCombat plugin, AdminGUIManager guiManager) {
        this.plugin = plugin;
        this.guiManager = guiManager;
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (event.getPlayer() instanceof Player player) {
            guiManager.clearGUI(player.getUniqueId());
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        AdminGUIManager.GUIType guiType = guiManager.getOpenGUI(player.getUniqueId());
        if (guiType != null) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        // Handle Bounty GUI
        String title = event.getView().getTitle();
        if (title != null && org.bukkit.ChatColor.stripColor(title).contains("BOUNTIES ACTIVAS")) {
            event.setCancelled(true);
            BountyManager bm = plugin.getBountyManager();
            if (bm != null) {
                bm.handleGUIClick(player, event.getRawSlot(), event.getCurrentItem());
            }
            return;
        }

        // Handle Death Recap GUI — cancel all clicks to prevent item theft
        if (title != null && org.bukkit.ChatColor.stripColor(title).contains("Death Recap")) {
            event.setCancelled(true);
            if (plugin.getDeathRecapManager() != null) {
                plugin.getDeathRecapManager().handleGUIClick(player, event.getRawSlot(), event.getCurrentItem());
            }
            return;
        }

        AdminGUIManager.GUIType guiType = guiManager.getOpenGUI(player.getUniqueId());
        if (guiType == null) return;

        event.setCancelled(true);
        if (event.getCurrentItem() == null || event.getCurrentItem().getType().isAir()) return;

        int slot = event.getRawSlot();
        if (slot < 0 || slot >= event.getInventory().getSize()) return;

        ClickType click = event.getClick();

        switch (guiType) {
            case MAIN_MENU -> handleMainMenu(player, slot);
            case WORLD_LIST -> handleWorldList(player, slot);
            case WORLD_SETTINGS -> handleWorldSettingsGeneral(player, slot, click);
            case WORLD_SETTINGS_RESTRICTIONS -> handleWorldSettingsRestrictions(player, slot, click);
            case WORLD_SETTINGS_VISUAL -> handleWorldSettingsVisual(player, slot, click);
            case MODULE_LIST -> handleModuleList(player, slot);
            case MODULE_CONFIG -> handleModuleConfig(player, slot, click);
            case DETECTION_SETTINGS -> handleDetectionSettings(player, slot, click);
            case SUSPECT_LIST -> handleSuspectList(player, slot);
            case LOG_VIEWER -> handleLogViewer(player, slot);
            case GLOBAL_CONFIG -> handleGlobalConfigCombat(player, slot, click);
            case GLOBAL_CONFIG_VISUAL -> handleGlobalConfigVisual(player, slot, click);
            case GLOBAL_CONFIG_NPC -> handleGlobalConfigNPC(player, slot, click);
            case ACTIVE_COMBATS -> handleActiveCombats(player, slot, click);
        }
    }

    // ─── Main Menu ──────────────────────────────────────────────

    private void handleMainMenu(Player player, int slot) {
        switch (slot) {
            case 10 -> guiManager.openWorldList(player);
            case 12 -> guiManager.openGlobalConfig(player);
            case 14 -> guiManager.openModuleList(player);
            case 16 -> guiManager.openDetectionSettings(player);
            case 28 -> guiManager.openActiveCombats(player);
            case 30 -> guiManager.openSuspectList(player);
            case 32 -> {
                guiManager.setPage(player.getUniqueId(), 0);
                guiManager.openLogViewer(player);
            }
            case 34 -> {
                plugin.getWorldConfigManager().save();
                plugin.getModuleConfigManager().save();
                plugin.getConfigManager().reload();
                plugin.getMessageManager().load();
                plugin.getMessageManager().send(player, "admin-gui.config-saved");
                guiManager.openMainMenu(player);
            }
            case 49 -> player.closeInventory();
        }
    }

    // ─── World List ─────────────────────────────────────────────

    private void handleWorldList(Player player, int slot) {
        switch (slot) {
            case 45 -> guiManager.openMainMenu(player);
            case 48 -> { // Prev page
                int page = guiManager.getPage(player.getUniqueId());
                if (page > 0) {
                    guiManager.setPage(player.getUniqueId(), page - 1);
                    guiManager.openWorldList(player);
                }
            }
            case 50 -> { // Next page
                int page = guiManager.getPage(player.getUniqueId());
                guiManager.setPage(player.getUniqueId(), page + 1);
                guiManager.openWorldList(player);
            }
            default -> {
                if (slot >= 10 && slot < 45 && slot % 9 != 0 && slot % 9 != 8) {
                    WorldConfigManager wcm = plugin.getWorldConfigManager();
                    List<String> worlds = wcm.getWorldNames();
                    int page = guiManager.getPage(player.getUniqueId());
                    int pageSize = 28;
                    int index = getInnerIndex(slot, 54) + (page * pageSize);
                    if (index >= 0 && index < worlds.size()) {
                        guiManager.openWorldSettings(player, worlds.get(index));
                    }
                }
            }
        }
    }

    // ─── World Settings — General Tab ─────────────────────────

    private void handleWorldSettingsGeneral(Player player, int slot, ClickType click) {
        String worldName = guiManager.getWorldContext(player.getUniqueId());
        if (worldName == null) { guiManager.openWorldList(player); return; }

        // Tab switching
        if (slot == 4) { guiManager.openWorldSettingsRestrictions(player, worldName); return; }
        if (slot == 6) { guiManager.openWorldSettingsVisual(player, worldName); return; }

        WorldCombatConfig wc = plugin.getWorldConfigManager().getConfig(worldName);
        int delta = click.isShiftClick() ? 5 : 1;
        boolean isRight = click.isRightClick();

        switch (slot) {
            case 19 -> wc.setCombatTagEnabled(!wc.isCombatTagEnabled());
            case 20 -> wc.setTagDuration(wc.getTagDuration() + (isRight ? -delta : delta));
            case 21 -> wc.setKeepInventory(!wc.isKeepInventory());
            case 22 -> wc.cycleLogoutPenalty();
            case 23 -> wc.setNpcSpawnOnLogout(!wc.isNpcSpawnOnLogout());
            case 24 -> wc.setLootProtection(!wc.isLootProtection());
            case 25 -> wc.setLootProtectionSeconds(wc.getLootProtectionSeconds() + (isRight ? -delta : delta));
            case 40 -> {
                plugin.getWorldConfigManager().save();
                plugin.getMessageManager().send(player, "admin-gui.world-saved", "{world}", worldName);
            }
            case 45 -> { guiManager.openWorldList(player); return; }
            default -> { return; }
        }

        if (slot != 45 && slot != 40) {
            guiManager.openWorldSettingsGeneral(player, worldName);
        }
    }

    // ─── World Settings — Restrictions Tab ──────────────────────

    private void handleWorldSettingsRestrictions(Player player, int slot, ClickType click) {
        String worldName = guiManager.getWorldContext(player.getUniqueId());
        if (worldName == null) { guiManager.openWorldList(player); return; }

        // Tab switching
        if (slot == 2) { guiManager.openWorldSettingsGeneral(player, worldName); return; }
        if (slot == 6) { guiManager.openWorldSettingsVisual(player, worldName); return; }

        WorldCombatConfig wc = plugin.getWorldConfigManager().getConfig(worldName);
        int delta = click.isShiftClick() ? 5 : 1;
        boolean isRight = click.isRightClick();

        switch (slot) {
            case 19 -> wc.setFlyDisabled(!wc.isFlyDisabled());
            case 20 -> wc.setPotionRestrict(!wc.isPotionRestrict());
            case 21 -> wc.setEnderPearlDeny(!wc.isEnderPearlDeny());
            case 22 -> wc.setEnderPearlCooldown(wc.getEnderPearlCooldown() + (isRight ? -delta : delta));
            case 23 -> wc.setCraftBlockInCombat(!wc.isCraftBlockInCombat());
            case 40 -> {
                plugin.getWorldConfigManager().save();
                plugin.getMessageManager().send(player, "admin-gui.world-saved", "{world}", worldName);
            }
            case 45 -> { guiManager.openWorldList(player); return; }
            default -> { return; }
        }

        if (slot != 45 && slot != 40) {
            guiManager.openWorldSettingsRestrictions(player, worldName);
        }
    }

    // ─── World Settings — Visual Tab ────────────────────────────

    private void handleWorldSettingsVisual(Player player, int slot, ClickType click) {
        String worldName = guiManager.getWorldContext(player.getUniqueId());
        if (worldName == null) { guiManager.openWorldList(player); return; }

        // Tab switching
        if (slot == 2) { guiManager.openWorldSettingsGeneral(player, worldName); return; }
        if (slot == 4) { guiManager.openWorldSettingsRestrictions(player, worldName); return; }

        WorldCombatConfig wc = plugin.getWorldConfigManager().getConfig(worldName);
        int delta = click.isShiftClick() ? 5 : 1;
        boolean isRight = click.isRightClick();

        switch (slot) {
            case 19 -> wc.setBossBarEnabled(!wc.isBossBarEnabled());
            case 20 -> wc.setActionBarEnabled(!wc.isActionBarEnabled());
            case 22 -> wc.setNewbieProtectionMinutes(wc.getNewbieProtectionMinutes() + (isRight ? -delta : delta));
            case 40 -> {
                plugin.getWorldConfigManager().save();
                plugin.getMessageManager().send(player, "admin-gui.world-saved", "{world}", worldName);
            }
            case 45 -> { guiManager.openWorldList(player); return; }
            default -> { return; }
        }

        if (slot != 45 && slot != 40) {
            guiManager.openWorldSettingsVisual(player, worldName);
        }
    }

    // ─── Module List ────────────────────────────────────────────

    private void handleModuleList(Player player, int slot) {
        switch (slot) {
            case 45 -> guiManager.openMainMenu(player);
            case 48 -> {
                int page = guiManager.getPage(player.getUniqueId());
                if (page > 0) {
                    guiManager.setPage(player.getUniqueId(), page - 1);
                    guiManager.openModuleList(player);
                }
            }
            case 50 -> {
                int page = guiManager.getPage(player.getUniqueId());
                guiManager.setPage(player.getUniqueId(), page + 1);
                guiManager.openModuleList(player);
            }
            default -> {
                // Click on a module — open its config if it's a PVP module
                if (slot >= 10 && slot < 45 && slot % 9 != 0 && slot % 9 != 8) {
                    var modules = new java.util.ArrayList<>(plugin.getModuleRegistry().getAll());
                    int page = guiManager.getPage(player.getUniqueId());
                    int pageSize = 28;
                    int index = getInnerIndex(slot, 54) + (page * pageSize);
                    if (index >= 0 && index < modules.size()) {
                        var module = modules.get(index);
                        if (module.hasCombatConfig()) {
                            guiManager.openModuleConfig(player, module.getId());
                        }
                    }
                }
            }
        }
    }

    // ─── Module Config ──────────────────────────────────────────

    private void handleModuleConfig(Player player, int slot, ClickType click) {
        String moduleId = guiManager.getWorldContext(player.getUniqueId());
        if (moduleId == null) { guiManager.openModuleList(player); return; }

        var mc = plugin.getModuleConfigManager().getConfig(moduleId);
        int delta = click.isShiftClick() ? 5 : 1;
        boolean isRight = click.isRightClick();

        switch (slot) {
            case 19 -> mc.setCombatTagEnabled(!mc.isCombatTagEnabled());
            case 20 -> mc.setTagDuration(mc.getTagDuration() + (isRight ? -delta : delta));
            case 21 -> mc.setKeepInventory(!mc.isKeepInventory());
            case 22 -> mc.setLootProtection(!mc.isLootProtection());
            case 23 -> mc.cycleLogoutPenalty();
            case 28 -> mc.setFlyDisabled(!mc.isFlyDisabled());
            case 29 -> mc.setBlockCommands(!mc.isBlockCommands());
            case 40 -> {
                plugin.getModuleConfigManager().save();
                plugin.getMessageManager().send(player, "admin-gui.config-saved");
                guiManager.openModuleConfig(player, moduleId);
                return;
            }
            case 45 -> { guiManager.openModuleList(player); return; }
            default -> { return; }
        }

        guiManager.openModuleConfig(player, moduleId);
    }

    // ─── Detection Settings ─────────────────────────────────────

    private void handleDetectionSettings(Player player, int slot, ClickType click) {
        DetectionManager dm = plugin.getDetectionManager();
        var cfg = plugin.getConfigManager().getConfig();
        int delta = click.isShiftClick() ? 5 : 1;
        boolean isRight = click.isRightClick();

        switch (slot) {
            case 10 -> { // Multi-account toggle
                dm.setMultiAccountEnabled(!dm.isMultiAccountEnabled());
                guiManager.openDetectionSettings(player);
            }
            case 11 -> { // Suspicion threshold
                int val = cfg.getInt("detection.multi-account.suspicion-threshold", 2) + (isRight ? -delta : delta);
                cfg.set("detection.multi-account.suspicion-threshold", Math.max(1, Math.min(20, val)));
                guiManager.openDetectionSettings(player);
            }
            case 13 -> { // Kill farm toggle
                dm.setKillFarmEnabled(!dm.isKillFarmEnabled());
                guiManager.openDetectionSettings(player);
            }
            case 14 -> { // Same victim threshold
                int val = cfg.getInt("detection.kill-farm.max-kills-same-player", 3) + (isRight ? -delta : delta);
                cfg.set("detection.kill-farm.max-kills-same-player", Math.max(1, Math.min(20, val)));
                guiManager.openDetectionSettings(player);
            }
            case 15 -> { // Low gear threshold
                int val = cfg.getInt("detection.kill-farm.low-gear-threshold", 5) + (isRight ? -delta : delta);
                cfg.set("detection.kill-farm.low-gear-threshold", Math.max(1, Math.min(20, val)));
                guiManager.openDetectionSettings(player);
            }
            case 16 -> { // Alert channel cycle
                dm.cycleAlertChannel();
                guiManager.openDetectionSettings(player);
            }
            case 45 -> guiManager.openMainMenu(player); // Back
        }
    }

    // ─── Suspect List ───────────────────────────────────────────

    private void handleSuspectList(Player player, int slot) {
        switch (slot) {
            case 45 -> guiManager.openMainMenu(player);
            case 48 -> {
                int page = guiManager.getPage(player.getUniqueId());
                if (page > 0) {
                    guiManager.setPage(player.getUniqueId(), page - 1);
                    guiManager.openSuspectList(player);
                }
            }
            case 50 -> {
                int page = guiManager.getPage(player.getUniqueId());
                guiManager.setPage(player.getUniqueId(), page + 1);
                guiManager.openSuspectList(player);
            }
            default -> {
                // Clicking a suspect clears their flags
                if (slot >= 10 && slot < 45 && slot % 9 != 0 && slot % 9 != 8) {
                    DetectionManager dm = plugin.getDetectionManager();
                    Map<UUID, Integer> violations = dm.getAllViolationCounts();
                    List<Map.Entry<UUID, Integer>> sorted = new ArrayList<>(violations.entrySet());
                    sorted.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));

                    int page = guiManager.getPage(player.getUniqueId());
                    int pageSize = 28;
                    int index = getInnerIndex(slot, 54) + (page * pageSize);
                    if (index >= 0 && index < sorted.size()) {
                        UUID target = sorted.get(index).getKey();
                        dm.clearViolations(target);
                        String name = org.bukkit.Bukkit.getOfflinePlayer(target).getName();
                        plugin.getMessageManager().send(player, "admin-gui.flags-cleared",
                                "{player}", (name != null ? name : target.toString()));
                        guiManager.openSuspectList(player); // Refresh
                    }
                }
            }
        }
    }

    // ─── Log Viewer ─────────────────────────────────────────────

    private void handleLogViewer(Player player, int slot) {
        switch (slot) {
            case 45 -> guiManager.openMainMenu(player); // Back
            case 48 -> { // Previous page
                int page = guiManager.getPage(player.getUniqueId());
                if (page > 0) {
                    guiManager.setPage(player.getUniqueId(), page - 1);
                    guiManager.openLogViewer(player);
                }
            }
            case 50 -> { // Next page
                int page = guiManager.getPage(player.getUniqueId());
                guiManager.setPage(player.getUniqueId(), page + 1);
                guiManager.openLogViewer(player);
            }
        }
    }

    // ─── Global Config — Combat Tag Tab ──────────────────────────────

    private void handleGlobalConfigCombat(Player player, int slot, ClickType click) {
        var cfg = plugin.getConfigManager().getConfig();
        int delta = click.isShiftClick() ? 5 : 1;
        boolean isRight = click.isRightClick();

        // Tab switching
        if (slot == 4) { guiManager.openGlobalConfigVisual(player); return; }
        if (slot == 6) { guiManager.openGlobalConfigNPC(player); return; }

        switch (slot) {
            // Row 3: Core tag settings
            case 19 -> {
                int val = cfg.getInt("combat-tag.default-duration", 15) + (isRight ? -delta : delta);
                cfg.set("combat-tag.default-duration", Math.max(1, Math.min(120, val)));
            }
            case 20 -> {
                int val = cfg.getInt("combat-tag.max-duration", 30) + (isRight ? -delta : delta);
                cfg.set("combat-tag.max-duration", Math.max(1, Math.min(300, val)));
            }
            case 21 -> cfg.set("combat-tag.extend-on-hit", !cfg.getBoolean("combat-tag.extend-on-hit", true));
            case 23 -> cfg.set("combat-tag.block-flight", !cfg.getBoolean("combat-tag.block-flight", true));
            case 24 -> cfg.set("combat-tag.block-commands", !cfg.getBoolean("combat-tag.block-commands", true));
            case 25 -> cfg.set("combat-tag.block-enderpearl", !cfg.getBoolean("combat-tag.block-enderpearl", true));

            // Row 4: More cheat prevention
            case 28 -> cfg.set("combat-tag.block-chorus", !cfg.getBoolean("combat-tag.block-chorus", true));
            case 29 -> cfg.set("combat-tag.block-teleport", !cfg.getBoolean("combat-tag.block-teleport", true));
            case 30 -> cfg.set("combat-tag.block-elytra", !cfg.getBoolean("combat-tag.block-elytra", true));
            case 31 -> cfg.set("combat-tag.block-gamemode", !cfg.getBoolean("combat-tag.block-gamemode", true));
            case 32 -> cfg.set("combat-tag.block-riptide", !cfg.getBoolean("combat-tag.block-riptide", true));

            case 45 -> { guiManager.openMainMenu(player); return; }
            case 49 -> { saveGlobalConfig(player, cfg); return; }
            default -> { return; }
        }

        guiManager.openGlobalConfigCombat(player);
    }

    // ─── Global Config — Visual Tab ─────────────────────────────────

    private void handleGlobalConfigVisual(Player player, int slot, ClickType click) {
        var cfg = plugin.getConfigManager().getConfig();

        // Tab switching
        if (slot == 2) { guiManager.openGlobalConfigCombat(player); return; }
        if (slot == 6) { guiManager.openGlobalConfigNPC(player); return; }

        switch (slot) {
            case 19 -> cfg.set("combat-tag.bossbar.enabled", !cfg.getBoolean("combat-tag.bossbar.enabled", true));
            case 20 -> cfg.set("combat-tag.actionbar.enabled", !cfg.getBoolean("combat-tag.actionbar.enabled", true));
            case 22 -> cfg.set("visuals.combat-flash", !cfg.getBoolean("visuals.combat-flash", true));
            case 23 -> cfg.set("visuals.compass-tracking", !cfg.getBoolean("visuals.compass-tracking", true));
            case 24 -> cfg.set("visuals.combat-particles", !cfg.getBoolean("visuals.combat-particles", true));
            case 25 -> cfg.set("visuals.heartbeat", !cfg.getBoolean("visuals.heartbeat", true));
            case 28 -> cfg.set("visuals.kill-feed", !cfg.getBoolean("visuals.kill-feed", true));
            case 29 -> cfg.set("visuals.hit-effect", !cfg.getBoolean("visuals.hit-effect", true));

            case 45 -> { guiManager.openMainMenu(player); return; }
            case 49 -> { saveGlobalConfig(player, cfg); return; }
            default -> { return; }
        }

        guiManager.openGlobalConfigVisual(player);
    }

    // ─── Global Config — NPC & Penalty Tab ───────────────────────────

    private void handleGlobalConfigNPC(Player player, int slot, ClickType click) {
        var cfg = plugin.getConfigManager().getConfig();
        int delta = click.isShiftClick() ? 5 : 1;
        boolean isRight = click.isRightClick();

        // Tab switching
        if (slot == 2) { guiManager.openGlobalConfigCombat(player); return; }
        if (slot == 4) { guiManager.openGlobalConfigVisual(player); return; }

        switch (slot) {
            case 19 -> cfg.set("combat-npc.enabled", !cfg.getBoolean("combat-npc.enabled", true));
            case 20 -> {
                int val = cfg.getInt("combat-npc.duration", 30) + (isRight ? -delta : delta);
                cfg.set("combat-npc.duration", Math.max(5, Math.min(120, val)));
            }
            case 22 -> cfg.set("combat-log.penalty.enabled", !cfg.getBoolean("combat-log.penalty.enabled", true));
            case 23 -> {
                int val = cfg.getInt("combat-log.penalty.money-loss", 500) + (isRight ? -delta * 50 : delta * 50);
                cfg.set("combat-log.penalty.money-loss", Math.max(0, val));
            }
            case 24 -> {
                int val = cfg.getInt("combat-log.penalty.power-loss", 20) + (isRight ? -delta : delta);
                cfg.set("combat-log.penalty.power-loss", Math.max(0, Math.min(100, val)));
            }
            case 28 -> cfg.set("revenge.enabled", !cfg.getBoolean("revenge.enabled", true));
            case 29 -> {
                int val = cfg.getInt("revenge.money-bonus", 100) + (isRight ? -delta * 10 : delta * 10);
                cfg.set("revenge.money-bonus", Math.max(0, val));
            }
            case 30 -> cfg.set("revenge.message", !cfg.getBoolean("revenge.message", true));

            case 45 -> { guiManager.openMainMenu(player); return; }
            case 49 -> { saveGlobalConfig(player, cfg); return; }
            default -> { return; }
        }

        guiManager.openGlobalConfigNPC(player);
    }

    /**
     * Shared save logic for all Global Config tabs.
     */
    private void saveGlobalConfig(Player player, org.bukkit.configuration.file.FileConfiguration cfg) {
        try {
            cfg.save(new java.io.File(plugin.getDataFolder(), "config.yml"));
            plugin.getConfigManager().reload();
            plugin.getMessageManager().send(player, "admin-gui.global-saved");
        } catch (Exception e) {
            plugin.getMessageManager().send(player, "admin-gui.global-error", "{error}", e.getMessage());
        }
    }

    // ─── Active Combats ─────────────────────────────────────────

    private void handleActiveCombats(Player player, int slot, ClickType click) {
        switch (slot) {
            case 45 -> guiManager.openMainMenu(player);
            case 48 -> {
                int page = guiManager.getPage(player.getUniqueId());
                if (page > 0) {
                    guiManager.setPage(player.getUniqueId(), page - 1);
                    guiManager.openActiveCombats(player);
                }
            }
            case 49 -> guiManager.openActiveCombats(player); // Refresh
            case 50 -> {
                int page = guiManager.getPage(player.getUniqueId());
                guiManager.setPage(player.getUniqueId(), page + 1);
                guiManager.openActiveCombats(player);
            }
            default -> {
                if (slot >= 10 && slot < 45 && slot % 9 != 0 && slot % 9 != 8) {
                    var activeTags = plugin.getTagManager().getActiveTags();
                    List<UUID> taggedPlayers = new java.util.ArrayList<>(activeTags.keySet());

                    int page = guiManager.getPage(player.getUniqueId());
                    int pageSize = 28;
                    int index = getInnerIndex(slot, 54) + (page * pageSize);
                    if (index >= 0 && index < taggedPlayers.size()) {
                        UUID targetUuid = taggedPlayers.get(index);
                        Player target = org.bukkit.Bukkit.getPlayer(targetUuid);

                        if (click.isShiftClick()) {
                            // Force untag
                            plugin.getTagManager().untag(targetUuid);
                            plugin.getMessageManager().send(player, "admin-gui.combat-removed",
                                    "{player}", (target != null ? target.getName() : targetUuid.toString()));
                            guiManager.openActiveCombats(player);
                        } else if (target != null && target.isOnline()) {
                            // Teleport
                            player.closeInventory();
                            player.teleport(target.getLocation());
                            plugin.getMessageManager().send(player, "admin-gui.teleported", "{player}", target.getName());
                        }
                    }
                }
            }
        }
    }

    // ─── Helpers ────────────────────────────────────────────────

    /**
     * Calculate the sequential index of an inner inventory slot,
     * excluding borders (column 0, column 8, first row, last row).
     */
    private int getInnerIndex(int slot, int invSize) {
        int rows = invSize / 9;
        int index = 0;
        for (int row = 1; row < rows - 1; row++) {
            for (int col = 1; col < 8; col++) {
                int s = row * 9 + col;
                if (s == slot) return index;
                index++;
            }
        }
        return -1;
    }
}
