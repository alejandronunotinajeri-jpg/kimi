package com.ethernova.combat.loot;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.Bukkit;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class LootProtectionManager {

    private final EthernovaCombat plugin;
    private final Map<UUID, UUID> protectedItems = new ConcurrentHashMap<>();
    /** Cooldown to avoid spamming denial messages (player UUID -> next allowed msg time) */
    private final Map<UUID, Long> messageCooldowns = new ConcurrentHashMap<>();
    private static final long MSG_COOLDOWN_MS = 2000L;

    public LootProtectionManager(EthernovaCombat plugin) { this.plugin = plugin; }

    public void protectLoot(UUID killerUuid, List<Item> items) {
        int seconds = plugin.getConfigManager().getConfig().getInt("loot-protection.duration", 30);
        for (Item item : items) {
            protectedItems.put(item.getUniqueId(), killerUuid);
        }

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            for (Item item : items) protectedItems.remove(item.getUniqueId());
        }, 20L * seconds);
    }

    public boolean canPickup(UUID playerUuid, UUID itemEntityUuid) {
        UUID owner = protectedItems.get(itemEntityUuid);
        if (owner == null) return true;
        return owner.equals(playerUuid);
    }

    /** Returns true if a denial message should be shown (respects cooldown). */
    public boolean shouldShowDenialMessage(UUID playerUuid) {
        long now = System.currentTimeMillis();
        Long next = messageCooldowns.get(playerUuid);
        if (next != null && now < next) return false;
        messageCooldowns.put(playerUuid, now + MSG_COOLDOWN_MS);
        return true;
    }

    /** Clean up cooldown entries for a player. */
    public void cleanupPlayer(UUID uuid) {
        messageCooldowns.remove(uuid);
    }
}
