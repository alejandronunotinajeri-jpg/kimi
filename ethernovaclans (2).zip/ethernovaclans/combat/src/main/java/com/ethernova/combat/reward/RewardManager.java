package com.ethernova.combat.reward;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.entity.Player;

import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public class RewardManager {

    private final EthernovaCombat plugin;

    public RewardManager(EthernovaCombat plugin) { this.plugin = plugin; }

    public void processKillReward(Player killer, Player victim) {
        var config = plugin.getConfigManager().getConfig();
        if (!config.getBoolean("kill-reward.money.enabled", true)) return;

        double amount;
        String mode = config.getString("kill-reward.money.mode", "RANDOM");
        switch (mode.toUpperCase()) {
            case "FIXED" -> amount = config.getDouble("kill-reward.money.min", 50);
            case "PERCENTAGE" -> {
                if (!plugin.getCore().getEconomyHook().isEnabled()) { amount = 0; break; }
                double pct = config.getDouble("kill-reward.money.percentage", 5) / 100.0;
                double cap = config.getDouble("kill-reward.money.percentage-cap", 10000);
                amount = Math.min(plugin.getCore().getEconomyHook().getBalance(victim) * pct, cap);
            }
            default -> {
                double min = config.getDouble("kill-reward.money.min", 50);
                double max = config.getDouble("kill-reward.money.max", 200);
                amount = (min >= max) ? min : ThreadLocalRandom.current().nextDouble(min, max);
            }
        }

        // Revenge bonus is handled by RevengeManager — no duplicate logic here

        if (amount > 0 && plugin.getCore().getEconomyHook().isEnabled()) {
            plugin.getCore().getEconomyHook().deposit(killer, amount);
            plugin.getMessageManager().send(killer, "reward.money", "{amount}", String.format("%.0f", amount));
        }

        // XP
        if (config.getBoolean("kill-reward.xp.enabled", true)) {
            int xp = config.getInt("kill-reward.xp.amount", 50);
            killer.giveExp(xp);
        }

    }

    public void processDeathPenalty(Player victim) {
        var config = plugin.getConfigManager().getConfig();
        if (!config.getBoolean("death-penalty.money.enabled", false)) return;

        double amount;
        String mode = config.getString("death-penalty.money.mode", "FIXED");
        if ("PERCENTAGE".equalsIgnoreCase(mode) && plugin.getCore().getEconomyHook().isEnabled()) {
            double pct = config.getDouble("death-penalty.money.percentage", 2) / 100.0;
            amount = plugin.getCore().getEconomyHook().getBalance(victim) * pct;
        } else {
            amount = config.getDouble("death-penalty.money.amount", 100);
        }

        if (amount > 0 && plugin.getCore().getEconomyHook().isEnabled()) {
            plugin.getCore().getEconomyHook().withdraw(victim, amount);
        }

        if (config.getBoolean("death-penalty.xp.enabled", false)) {
            int levels = config.getInt("death-penalty.xp.levels", 3);
            victim.setLevel(Math.max(0, victim.getLevel() - levels));
        }
    }

    public void cleanupPlayer(UUID uuid) {
        // No per-player state to clean — revenge handled by RevengeManager
    }
}
