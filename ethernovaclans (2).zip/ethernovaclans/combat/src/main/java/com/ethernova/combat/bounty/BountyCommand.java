package com.ethernova.combat.bounty;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * /bounty <player> <amount> — place a bounty
 * /bounty list — show top bounties
 * /bounty check [player] — check bounty on a player
 */
public class BountyCommand implements CommandExecutor, TabCompleter {

    private final EthernovaCombat combat;

    public BountyCommand(EthernovaCombat combat) {
        this.combat = combat;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            combat.getMessageManager().send(sender, "general.player-only");
            return true;
        }

        BountyManager bm = combat.getBountyManager();

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "gui" -> {
                bm.openBountyGUI(player);
            }
            case "list", "top" -> {
                List<Map.Entry<UUID, Double>> top = bm.getTopBounties();
                if (top.isEmpty()) {
                    combat.getMessageManager().send(player, "bounty.none-active");
                    return true;
                }
                combat.getMessageManager().send(player, "bounty.list-header");
                int rank = 1;
                for (Map.Entry<UUID, Double> e : top) {
                    String name = Bukkit.getOfflinePlayer(e.getKey()).getName();
                    if (name == null) name = e.getKey().toString().substring(0, 8);
                    combat.getMessageManager().send(player, "bounty.list-entry",
                            "{rank}", String.valueOf(rank),
                            "{player}", name,
                            "{amount}", String.format("%.0f", e.getValue()));
                    rank++;
                    if (rank > 10) break;
                }
            }
            case "check" -> {
                Player target = args.length > 1 ? Bukkit.getPlayer(args[1]) : player;
                if (target == null) {
                    combat.getMessageManager().send(player, "general.player-not-found");
                    return true;
                }
                double total = bm.getTotalBounty(target.getUniqueId());
                if (total <= 0) {
                    combat.getMessageManager().send(player, "bounty.check-none",
                            "{player}", target.getName());
                } else {
                    combat.getMessageManager().send(player, "bounty.check-has",
                            "{player}", target.getName(),
                            "{amount}", String.format("%.0f", total));
                }
            }
            default -> {
                // /bounty <player> <amount>
                Player target = Bukkit.getPlayer(args[0]);
                if (target == null) {
                    combat.getMessageManager().send(player, "general.player-not-found");
                    return true;
                }
                if (args.length < 2) {
                    combat.getMessageManager().send(player, "bounty.usage");
                    return true;
                }
                double amount;
                try { amount = Double.parseDouble(args[1]); } catch (NumberFormatException e) {
                    combat.getMessageManager().send(player, "bounty.invalid-amount");
                    return true;
                }
                if (!bm.placeBounty(player.getUniqueId(), player.getName(), target.getUniqueId(), amount)) {
                    combat.getMessageManager().send(player, "bounty.place-failed");
                } else {
                    combat.getMessageManager().send(player, "bounty.placed",
                            "{amount}", String.format("%.0f", amount),
                            "{target}", target.getName());
                }
            }
        }
        return true;
    }

    private void sendHelp(Player player) {
        combat.getMessageManager().send(player, "bounty.help-header");
        combat.getMessageManager().send(player, "bounty.help-place");
        combat.getMessageManager().send(player, "bounty.help-list");
        combat.getMessageManager().send(player, "bounty.help-check");
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) {
            List<String> options = new java.util.ArrayList<>(List.of("list", "check", "gui"));
            Bukkit.getOnlinePlayers().forEach(p -> options.add(p.getName()));
            return filter(options, args[0]);
        }
        if (args.length == 2 && !"list".equalsIgnoreCase(args[0])) {
            if ("check".equalsIgnoreCase(args[0])) return null;
            return List.of("100", "500", "1000", "5000");
        }
        return List.of();
    }

    private List<String> filter(List<String> options, String input) {
        String lower = input.toLowerCase();
        return options.stream().filter(s -> s.toLowerCase().startsWith(lower)).collect(Collectors.toList());
    }
}
