package com.ethernova.combat.npc;

import com.ethernova.combat.EthernovaCombat;
import com.ethernova.core.EthernovaCore;
import net.citizensnpcs.api.CitizensAPI;
import net.citizensnpcs.api.npc.NPC;
import net.citizensnpcs.api.npc.NPCRegistry;
import net.citizensnpcs.api.trait.trait.Equipment;
import net.citizensnpcs.trait.SkinTrait;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

/**
 * Encapsulates all Citizens API calls.
 * <p>
 * This class is <b>only loaded by the JVM when Citizens is available</b>
 * (Java lazy class loading). Never reference it in a code path that
 * executes when Citizens is absent.
 */
public final class CitizensNPCHelper {

    private CitizensNPCHelper() {}

    /**
     * Creates and spawns a Citizens Player NPC that mirrors the given player
     * (skin, equipment, health).
     *
     * @return spawn result containing the bukkit entity UUID and Citizens NPC id,
     *         or {@code null} on failure
     */
    public static SpawnResult spawnPlayerNPC(EthernovaCombat plugin, EthernovaCore core,
                                             Player player, double health, ItemStack[] armor) {
        NPCRegistry registry = CitizensAPI.getNPCRegistry();
        NPC npc = registry.createNPC(EntityType.PLAYER, player.getName());
        npc.setProtected(false);

        // Apply player skin
        SkinTrait skinTrait = npc.getOrAddTrait(SkinTrait.class);
        skinTrait.setSkinName(player.getName());

        // Spawn at the player's current location
        npc.spawn(player.getLocation());
        Entity entity = npc.getEntity();
        if (entity == null) {
            npc.destroy();
            return null;
        }

        // Match health to the combat-logging player
        if (entity instanceof LivingEntity living) {
            living.setHealth(Math.min(health, living.getMaxHealth()));
        }

        // Visual equipment
        Equipment equipment = npc.getOrAddTrait(Equipment.class);
        if (armor.length > 3 && armor[3] != null)
            equipment.set(Equipment.EquipmentSlot.HELMET, armor[3]);
        if (armor.length > 2 && armor[2] != null)
            equipment.set(Equipment.EquipmentSlot.CHESTPLATE, armor[2]);
        if (armor.length > 1 && armor[1] != null)
            equipment.set(Equipment.EquipmentSlot.LEGGINGS, armor[1]);
        if (armor.length > 0 && armor[0] != null)
            equipment.set(Equipment.EquipmentSlot.BOOTS, armor[0]);

        ItemStack mainHand = player.getInventory().getItemInMainHand();
        if (mainHand != null && !mainHand.getType().isAir()) {
            equipment.set(Equipment.EquipmentSlot.HAND, mainHand);
        }

        return new SpawnResult(entity.getUniqueId(), npc.getId());
    }

    /**
     * Destroys (despawns + unregisters) a Citizens NPC by its registry ID.
     */
    public static void destroyNPC(int citizensNpcId) {
        NPC npc = CitizensAPI.getNPCRegistry().getById(citizensNpcId);
        if (npc != null) {
            if (npc.isSpawned()) npc.despawn();
            npc.destroy();
        }
    }

    /** Lightweight result carrier so the caller never touches Citizens types. */
    public record SpawnResult(UUID entityUuid, int citizensNpcId) {}
}
