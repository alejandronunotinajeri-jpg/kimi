package com.ethernova.combat.detection;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.entity.Player;

import java.net.InetSocketAddress;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Detects multi-account abuse:
 * - Same IP killing own alt
 * - Multiple accounts from same IP online simultaneously
 * - Session overlap patterns
 */
public class MultiAccountDetector {

    private final EthernovaCombat plugin;

    /** IP → Set of UUIDs that have logged in from that IP */
    private final Map<String, Set<UUID>> ipToPlayers = new ConcurrentHashMap<>();

    /** UUID → IP for reverse lookup */
    private final Map<UUID, String> playerIps = new ConcurrentHashMap<>();

    /** UUID → Set of detected alt UUIDs */
    private final Map<UUID, Set<UUID>> detectedAlts = new ConcurrentHashMap<>();

    public MultiAccountDetector(EthernovaCombat plugin) {
        this.plugin = plugin;
    }

    /**
     * Track a player's IP on login.
     */
    public void onLogin(Player player) {
        InetSocketAddress addr = player.getAddress();
        if (addr == null) return;
        String ip = addr.getAddress().getHostAddress();

        playerIps.put(player.getUniqueId(), ip);
        ipToPlayers.computeIfAbsent(ip, k -> ConcurrentHashMap.newKeySet()).add(player.getUniqueId());
    }

    /**
     * Check if a kill is a multi-account abuse (same IP).
     * Returns true if the killer and victim share the same IP.
     */
    public boolean isSameIpKill(Player killer, Player victim) {
        InetSocketAddress kAddr = killer.getAddress();
        InetSocketAddress vAddr = victim.getAddress();
        if (kAddr == null || vAddr == null) return false;

        String killerIp = kAddr.getAddress().getHostAddress();
        String victimIp = vAddr.getAddress().getHostAddress();

        if (killerIp.equals(victimIp)) {
            // Record the detected alt relationship
            detectedAlts.computeIfAbsent(killer.getUniqueId(), k -> ConcurrentHashMap.newKeySet())
                    .add(victim.getUniqueId());
            detectedAlts.computeIfAbsent(victim.getUniqueId(), k -> ConcurrentHashMap.newKeySet())
                    .add(killer.getUniqueId());
            return true;
        }
        return false;
    }

    /**
     * Check how many accounts are online simultaneously from the same IP.
     */
    public int getSimultaneousAccounts(Player player) {
        String ip = playerIps.get(player.getUniqueId());
        if (ip == null) return 1;
        Set<UUID> accounts = ipToPlayers.get(ip);
        if (accounts == null) return 1;

        return (int) accounts.stream()
                .filter(uuid -> org.bukkit.Bukkit.getPlayer(uuid) != null)
                .count();
    }

    /**
     * Get all known alt accounts for a player.
     */
    public Set<UUID> getAlts(UUID uuid) {
        String ip = playerIps.get(uuid);
        if (ip == null) return Set.of();
        Set<UUID> alts = ipToPlayers.getOrDefault(ip, Set.of());
        Set<UUID> result = new HashSet<>(alts);
        result.remove(uuid);
        return result;
    }

    /**
     * Get detected (confirmed via kill) alts.
     */
    public Set<UUID> getDetectedAlts(UUID uuid) {
        return detectedAlts.getOrDefault(uuid, Set.of());
    }

    /**
     * Clean up on player quit — remove from playerIps to free memory.
     * IP history in ipToPlayers is periodically pruned, not kept forever.
     */
    public void onQuit(UUID uuid) {
        playerIps.remove(uuid);
    }

    /**
     * Periodic cleanup: remove entries from ipToPlayers for players that haven't been
     * online recently. Keeps maps from growing without bound.
     */
    public void periodicCleanup() {
        // Remove IPs that have no online players associated
        ipToPlayers.entrySet().removeIf(entry -> {
            entry.getValue().removeIf(u -> org.bukkit.Bukkit.getPlayer(u) == null);
            return entry.getValue().isEmpty();
        });
        // Trim detectedAlts to remove entries for players not seen in a while
        detectedAlts.entrySet().removeIf(entry ->
                org.bukkit.Bukkit.getPlayer(entry.getKey()) == null && !playerIps.containsKey(entry.getKey()));
    }

    /**
     * Get the flag level for a player (how many alt-related incidents).
     */
    public int getFlagLevel(UUID uuid) {
        Set<UUID> alts = detectedAlts.get(uuid);
        return alts != null ? alts.size() : 0;
    }

    /**
     * Clear flags for a player.
     */
    public void clearFlags(UUID uuid) {
        detectedAlts.remove(uuid);
    }

    /**
     * Get all flagged players (those with detected alts).
     */
    public Map<UUID, Set<UUID>> getAllFlagged() {
        return Collections.unmodifiableMap(detectedAlts);
    }
}
