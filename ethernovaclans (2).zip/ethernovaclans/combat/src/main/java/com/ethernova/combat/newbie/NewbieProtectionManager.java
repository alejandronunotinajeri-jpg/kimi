package com.ethernova.combat.newbie;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class NewbieProtectionManager {

    private final EthernovaCombat plugin;
    private final Map<UUID, Long> protectedPlayers = new ConcurrentHashMap<>();

    public NewbieProtectionManager(EthernovaCombat plugin) { this.plugin = plugin; }

    public void addProtection(UUID uuid) {
        long duration = plugin.getConfigManager().getConfig()
                .getLong("newbie-protection.duration-minutes", 120) * 60_000L;
        protectedPlayers.put(uuid, System.currentTimeMillis() + duration);
    }

    public boolean isProtected(Player player) {
        return isProtected(player.getUniqueId());
    }

    public boolean isProtected(UUID uuid) {
        Long expiry = protectedPlayers.get(uuid);
        if (expiry == null) return false;
        if (System.currentTimeMillis() >= expiry) { protectedPlayers.remove(uuid); return false; }
        return true;
    }

    public void removeProtection(Player player, boolean notify) {
        protectedPlayers.remove(player.getUniqueId());
        if (notify) {
            plugin.getMessageManager().send(player, "newbie.lost");
        }
    }

    public void removeProtection(UUID uuid) {
        protectedPlayers.remove(uuid);
    }

    public void checkNewPlayer(Player player) {
        if (!plugin.getConfigManager().getConfig().getBoolean("newbie-protection.enabled", true)) return;
        if (!player.hasPlayedBefore()) {
            addProtection(player.getUniqueId());
            plugin.getMessageManager().send(player, "newbie.protected");
        }
    }

    public void toggle(Player player) {
        if (isProtected(player)) {
            removeProtection(player, false);
            plugin.getMessageManager().send(player, "newbie.disabled");
        } else {
            plugin.getMessageManager().send(player, "newbie.cannot-enable");
        }
    }
}
