package com.ethernova.combat.listener;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;

public class CombatDamageListener implements Listener {

    private final EthernovaCombat plugin;

    public CombatDamageListener(EthernovaCombat plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        Player attacker = resolveAttacker(event.getDamager());
        if (attacker == null || attacker.equals(victim)) return;

        // Check per-world combat tag setting
        var worldConfig = plugin.getWorldConfigManager().getConfig(victim.getWorld());
        if (!worldConfig.isCombatTagEnabled()) return;

        if (plugin.getNewbieManager().isProtected(victim)) {
            plugin.getMessageManager().send(attacker, "newbie.target-protected", "{player}", victim.getName());
            event.setCancelled(true);
            return;
        }
        if (plugin.getNewbieManager().isProtected(attacker)) {
            if (plugin.getConfigManager().getBoolean("newbie-protection.lose-on-attack", true)) {
                plugin.getNewbieManager().removeProtection(attacker, true);
            } else { event.setCancelled(true); return; }
        }

        String profile = plugin.getProfileManager().getActiveProfile(attacker);

        // If either player has bypass, don't tag anyone (prevents one-sided combat tag exploit)
        if (!attacker.hasPermission("ethernova.combat.bypass.tag")
                && !victim.hasPermission("ethernova.combat.bypass.tag")) {
            plugin.getTagManager().tag(attacker, victim, profile);
            plugin.getTagManager().tag(victim, attacker, profile);
        }

        plugin.getVisualManager().showHitEffect(victim.getLocation());
        plugin.getLogoutManager().onDamage(victim);
        plugin.getLogoutManager().onDamage(attacker);

        // Combo system: register hit and apply bonus damage BEFORE recording to death recap
        if (plugin.getComboManager() != null) {
            double[] comboResult = plugin.getComboManager().registerHit(attacker.getUniqueId(), victim.getUniqueId());
            int comboCount = (int) comboResult[0];
            double multiplier = comboResult[1];
            if (multiplier > 1.0) {
                event.setDamage(event.getDamage() * multiplier);
            }
            plugin.getComboManager().sendComboFeedback(attacker, comboCount);

            // Reset victim's combo since they got hit
            plugin.getComboManager().resetCombo(victim.getUniqueId());
        }

        // Death Recap: record the damage for the victim (AFTER combo bonus applied)
        if (plugin.getDeathRecapManager() != null) {
            plugin.getDeathRecapManager().recordDamage(
                    victim, attacker, event.getFinalDamage(),
                    attacker.getInventory().getItemInMainHand(),
                    com.ethernova.combat.deathrecap.DeathRecapManager.fromBukkitCause(event.getCause()));
        }

        // Advanced weapon stats: record damage dealt with weapon
        if (plugin.getAdvancedStatsManager() != null) {
            plugin.getAdvancedStatsManager().recordDamage(
                    attacker.getUniqueId(),
                    attacker.getInventory().getItemInMainHand().getType(),
                    event.getFinalDamage());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onAnyDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (event instanceof EntityDamageByEntityEvent) return;
        plugin.getLogoutManager().onDamage(player);
    }

    private Player resolveAttacker(Entity d) {
        if (d instanceof Player p) return p;
        if (d instanceof Projectile proj && proj.getShooter() instanceof Player p) return p;
        if (d instanceof Tameable t && t.getOwner() instanceof Player p) return p;
        return null;
    }
}
