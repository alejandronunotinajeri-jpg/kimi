package com.ethernova.combat.command;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class DeathRecapCommand implements CommandExecutor {

    private final EthernovaCombat plugin;

    public DeathRecapCommand(EthernovaCombat plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.getMessageManager().send(sender, "general.player-only");
            return true;
        }

        if (plugin.getDeathRecapManager() == null || !plugin.getDeathRecapManager().hasRecap(player.getUniqueId())) {
            player.sendMessage("§c§l✗ §cNo hay death recap disponible.");
            return true;
        }

        plugin.getDeathRecapManager().openRecapGUI(player);
        return true;
    }
}
