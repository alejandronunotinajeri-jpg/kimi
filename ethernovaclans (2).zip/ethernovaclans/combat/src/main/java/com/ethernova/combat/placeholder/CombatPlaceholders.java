package com.ethernova.combat.placeholder;

import com.ethernova.combat.EthernovaCombat;
import com.ethernova.core.profile.PlayerProfile;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * PlaceholderAPI expansion for EthernovaCombat.
 * Prefix: %combat_...%
 *
 * Placeholders:
 *   %combat_tagged%             — true/false: currently in combat
 *   %combat_tag_time%           — Remaining combat tag seconds (0 if not tagged)
 *   %combat_tag_enemy%          — Name of current combat enemy (empty if none)
 *   %combat_streak%             — Current killstreak
 *   %combat_best_streak%        — Best ever killstreak (from profile kills if no separate tracking)
 *   %combat_combo%              — Current combo count
 *   %combat_kills%              — Total kills
 *   %combat_deaths%             — Total deaths
 *   %combat_kdr%                — Kill/Death Ratio (2 decimals)
 *   %combat_bounty%             — Total bounty on this player
 *   %combat_bounty_formatted%   — Formatted bounty (e.g. $1,000)
 *   %combat_newbie%             — true/false: has newbie protection
 *   %combat_revenge_available%  — true/false: can get revenge on someone
 *   %combat_profile%            — Active combat profile (survival/kitpvp/etc.)
 *   %combat_tagged_count%       — Server-wide: number of players in combat
 *   %combat_violations%         — Player's anti-abuse violation count
 */
public class CombatPlaceholders extends PlaceholderExpansion {

    private final EthernovaCombat plugin;

    public CombatPlaceholders(EthernovaCombat plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "combat";
    }

    @Override
    public @NotNull String getAuthor() {
        return "Ethernova";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public @Nullable String onRequest(OfflinePlayer offlinePlayer, @NotNull String params) {
        String lower = params.toLowerCase();

        // ─── Server-wide placeholders (no player needed) ───
        if ("tagged_count".equals(lower)) {
            return String.valueOf(plugin.getTagManager().getTaggedCount());
        }

        // ─── Player-specific placeholders ───
        if (offlinePlayer == null) return "";
        UUID uuid = offlinePlayer.getUniqueId();
        Player player = offlinePlayer.isOnline() ? offlinePlayer.getPlayer() : null;

        return switch (lower) {
            case "tagged" -> String.valueOf(plugin.getTagManager().isInCombat(uuid));

            case "tag_time" -> String.valueOf(plugin.getTagManager().getRemainingSeconds(uuid));

            case "tag_enemy" -> {
                UUID enemyUuid = plugin.getTagManager().getEnemy(uuid);
                if (enemyUuid != null) {
                    Player enemy = plugin.getServer().getPlayer(enemyUuid);
                    yield enemy != null ? enemy.getName() : "";
                }
                yield "";
            }

            case "streak" -> String.valueOf(plugin.getKillStreakManager().getStreak(uuid));

            case "max_streak", "best_streak" -> {
                var profile = plugin.getCore().getProfileManager().getProfile(uuid);
                if (profile != null) {
                    yield profile.getCustom("best_streak", "0");
                }
                yield "0";
            }

            case "fighting" -> String.valueOf(plugin.getTagManager().isInCombat(uuid));

            case "combo" -> {
                if (plugin.getComboManager() != null) {
                    yield String.valueOf(plugin.getComboManager().getCombo(uuid));
                }
                yield "0";
            }

            case "kills" -> {
                PlayerProfile profile = plugin.getCore().getProfileManager().getProfile(uuid);
                yield profile != null ? String.valueOf(profile.getKills()) : "0";
            }

            case "deaths" -> {
                PlayerProfile profile = plugin.getCore().getProfileManager().getProfile(uuid);
                yield profile != null ? String.valueOf(profile.getDeaths()) : "0";
            }

            case "kdr" -> {
                PlayerProfile profile = plugin.getCore().getProfileManager().getProfile(uuid);
                if (profile != null) {
                    int kills = profile.getKills();
                    int deaths = profile.getDeaths();
                    double kdr = deaths == 0 ? kills : (double) kills / deaths;
                    yield String.format("%.2f", kdr);
                }
                yield "0.00";
            }

            case "bounty" -> {
                if (plugin.getBountyManager() != null) {
                    yield String.format("%.0f", plugin.getBountyManager().getTotalBounty(uuid));
                }
                yield "0";
            }

            case "bounty_formatted" -> {
                if (plugin.getBountyManager() != null) {
                    double bounty = plugin.getBountyManager().getTotalBounty(uuid);
                    yield "$" + String.format("%,.0f", bounty);
                }
                yield "$0";
            }

            case "newbie" -> {
                if (player != null) {
                    yield String.valueOf(plugin.getNewbieManager().isProtected(player));
                }
                yield "false";
            }

            case "profile" -> {
                if (player != null) {
                    yield plugin.getProfileManager().getActiveProfile(player);
                }
                yield "survival";
            }

            case "violations" -> {
                if (plugin.getDetectionManager() != null) {
                    yield String.valueOf(plugin.getDetectionManager().getViolationCount(uuid));
                }
                yield "0";
            }

            default -> null;
        };
    }
}
