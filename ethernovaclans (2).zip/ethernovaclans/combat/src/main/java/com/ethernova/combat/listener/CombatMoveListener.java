package com.ethernova.combat.listener;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.player.PlayerMoveEvent;

public class CombatMoveListener implements Listener {

    private final EthernovaCombat plugin;

    public CombatMoveListener(EthernovaCombat plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onGlide(EntityToggleGlideEvent event) {
        if (!(event.getEntity() instanceof Player p)) return;
        if (!plugin.getTagManager().isInCombat(p)) return;
        if (!plugin.getCheatManager().blockElytra()) return;
        if (p.hasPermission("ethernova.combat.bypass.tag")) return;
        if (event.isGliding()) {
            event.setCancelled(true);
            plugin.getMessageManager().send(p, "combat.cannot-elytra");
        }
    }

    /** Cancel safe-logout on movement if config option is enabled. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (!plugin.getConfigManager().getBoolean("safe-logout.cancel-on-move", true)) return;
        // Only care about position changes, not head rotation
        if (event.getFrom().getBlockX() == event.getTo().getBlockX()
                && event.getFrom().getBlockY() == event.getTo().getBlockY()
                && event.getFrom().getBlockZ() == event.getTo().getBlockZ()) return;
        plugin.getLogoutManager().cancelLogout(event.getPlayer().getUniqueId());
    }
}
