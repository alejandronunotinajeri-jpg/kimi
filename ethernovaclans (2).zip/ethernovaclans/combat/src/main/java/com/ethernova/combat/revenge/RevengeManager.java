package com.ethernova.combat.revenge;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks who killed each player and grants a revenge bonus
 * when a player kills the person who last killed them.
 */
public class RevengeManager {

    private final EthernovaCombat plugin;
    // Maps victim UUID → killer UUID (tracks "who killed me last")
    private final Map<UUID, UUID> lastKiller = new ConcurrentHashMap<>();

    public RevengeManager(EthernovaCombat plugin) {
        this.plugin = plugin;
    }

    /**
     * Records that killer killed victim. Must be called on every valid kill.
     */
    public void recordKill(UUID killer, UUID victim) {
        // Always update to the most recent killer so revenge targets the latest attacker
        lastKiller.put(victim, killer);
    }

    /**
     * Checks if this kill is a revenge kill (killer was previously killed by victim).
     * If so, grants the revenge bonus and clears the revenge state.
     *
     * @return true if this was a revenge kill
     */
    public boolean processRevenge(Player killer, Player victim) {
        if (!plugin.getConfigManager().getBoolean("revenge.enabled", true)) return false;

        UUID killerUuid = killer.getUniqueId();
        UUID victimUuid = victim.getUniqueId();

        UUID whoKilledMe = lastKiller.get(killerUuid);
        if (whoKilledMe != null && whoKilledMe.equals(victimUuid)) {
            // REVENGE! The killer just killed the person who last killed them
            lastKiller.remove(killerUuid);

            // Money bonus via Vault
            double bonus = plugin.getConfigManager().getDouble("revenge.money-bonus", 100);
            if (bonus > 0) {
                var economy = plugin.getCore().getEconomyHook();
                if (economy != null && economy.isEnabled()) {
                    economy.deposit(killer, bonus);
                }
            }

            // Notify
            if (plugin.getConfigManager().getBoolean("revenge.message", true)) {
                plugin.getMessageManager().send(killer, "combat.revenge",
                        "{victim}", victim.getName(),
                        "{bonus}", String.format("%.0f", bonus));
            }

            // Visual flair
            killer.playSound(killer.getLocation(), org.bukkit.Sound.UI_TOAST_CHALLENGE_COMPLETE,
                    org.bukkit.SoundCategory.MASTER, 0.7f, 1.2f);

            return true;
        }

        return false;
    }

    /**
     * Clear tracking for a player (e.g., on leave).
     */
    public void clear(UUID uuid) {
        lastKiller.remove(uuid);
        // Also remove entries where this player is the killer (stale references)
        lastKiller.values().removeIf(killerUuid -> killerUuid.equals(uuid));
    }
}
