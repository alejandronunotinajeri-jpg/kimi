package com.ethernova.combat.detection;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * 3-tier automatic sanction system for detected abuse:
 *
 * Offense 1: Kick + nullify farmed kills + warning message
 * Offense 2: Tempban 1 day + nullify kills + admin alert
 * Offense 3: Full stats reset + tempban 3 days + admin alert
 *
 * Every offense also nullifies the fraudulent kills (remove the incentive).
 */
public class SanctionManager {

    private final EthernovaCombat plugin;

    /** Tracks the current offense level for each player across the session */
    private final Map<UUID, Integer> offenseLevels = new ConcurrentHashMap<>();

    /** Tracks which kills have been nullified (to avoid double-nullifying) */
    private final Map<UUID, Integer> nullifiedKills = new ConcurrentHashMap<>();

    public SanctionManager(EthernovaCombat plugin) {
        this.plugin = plugin;
        loadOffenseLevels();
    }

    /** Load persisted offense levels from disk. */
    private void loadOffenseLevels() {
        File file = new File(plugin.getDataFolder(), "sanctions.yml");
        if (!file.exists()) return;
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        for (String key : yaml.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                offenseLevels.put(uuid, yaml.getInt(key));
            } catch (IllegalArgumentException ignored) {}
        }
    }

    /** Save offense levels to disk so they survive restarts. */
    public void saveOffenseLevels() {
        File file = new File(plugin.getDataFolder(), "sanctions.yml");
        YamlConfiguration yaml = new YamlConfiguration();
        for (var entry : offenseLevels.entrySet()) {
            yaml.set(entry.getKey().toString(), entry.getValue());
        }
        try {
            yaml.save(file);
        } catch (IOException e) {
            plugin.getLogger().log(Level.WARNING, "Failed to save sanctions", e);
        }
    }

    /**
     * Apply the appropriate sanction based on offense count.
     *
     * @param player    The offending player
     * @param offense   The offense number (1, 2, 3+)
     * @param type      The type of abuse detected
     * @param details   Human-readable details
     */
    public void applySanction(Player player, int offense, AbuseRecord.AbuseType type, String details) {
        offenseLevels.put(player.getUniqueId(), offense);
        saveOffenseLevels();

        // Always nullify the fraudulent kills
        nullifyFraudulentKills(player);

        // Run on main thread for safety
        Bukkit.getScheduler().runTask(plugin, () -> {
            switch (offense) {
                case 1 -> applyFirstOffense(player, type, details);
                case 2 -> applySecondOffense(player, type, details);
                default -> applyThirdOffense(player, type, details);
            }
        });
    }

    /**
     * Offense 1: Kick + warning
     * Player is kicked with a warning message. They can rejoin after 1 minute.
     */
    private void applyFirstOffense(Player player, AbuseRecord.AbuseType type, String details) {
        String reason = buildKickMessage(1, type);

        // Notify the player before kick
        plugin.getMessageManager().send(player, "sanction.warn-title");
        plugin.getMessageManager().send(player, "sanction.warn-nullified");
        plugin.getMessageManager().send(player, "sanction.warn-next");

        // Kick after a brief delay so they can see the message
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline()) {
                player.kick(plugin.getCore().getMessageManager().getMiniMessage().deserialize(reason));
            }
        }, 40L); // 2 seconds

        logSanction(player, 1, type, details);
    }

    /**
     * Offense 2: Tempban 1 day + nullify kills
     */
    private void applySecondOffense(Player player, AbuseRecord.AbuseType type, String details) {
        String reason = buildKickMessage(2, type);
        Duration banDuration = Duration.ofDays(1);

        // Ban (profile/UUID-based, immune to name changes)
        player.ban(
                "EthernovaCombat: Kill farming/Multi-account abuse (Ofensa #2)",
                Date.from(Instant.now().plus(banDuration)),
                "EthernovaCombat Anti-Abuse"
        );

        if (player.isOnline()) {
            player.kick(plugin.getCore().getMessageManager().getMiniMessage().deserialize(reason));
        }

        logSanction(player, 2, type, details);
    }

    /**
     * Offense 3+: Stats reset + tempban 3 days
     */
    private void applyThirdOffense(Player player, AbuseRecord.AbuseType type, String details) {
        String reason = buildKickMessage(3, type);
        Duration banDuration = Duration.ofDays(3);

        // Reset combat stats via Core profiles
        resetStats(player);

        // Ban (profile/UUID-based, immune to name changes)
        player.ban(
                "EthernovaCombat: Kill farming/Multi-account abuse (Ofensa #3+) - Stats reseteadas",
                Date.from(Instant.now().plus(banDuration)),
                "EthernovaCombat Anti-Abuse"
        );

        if (player.isOnline()) {
            player.kick(plugin.getCore().getMessageManager().getMiniMessage().deserialize(reason));
        }

        logSanction(player, 3, type, details);
    }

    /**
     * Nullify fraudulent kills by resetting the player's kill streak
     * and subtracting the farmed kills from their stats.
     */
    private void nullifyFraudulentKills(Player player) {
        UUID uuid = player.getUniqueId();

        // Reset kill streak
        plugin.getKillStreakManager().resetStreak(uuid);

        // Track nullification
        nullifiedKills.merge(uuid, 1, Integer::sum);

        // Subtract kills from Core profile (deduct farmed kills)
        var profile = plugin.getCore().getProfileManager().getProfile(uuid);
        if (profile != null) {
            int current = profile.getKills();
            int toRemove = Math.min(
                    plugin.getConfigManager().getInt("detection.sanction.kills-to-nullify", 5),
                    current);
            profile.setKills(current - toRemove);
        }
    }

    /**
     * Full stats reset for severe offenders.
     */
    private void resetStats(Player player) {
        UUID uuid = player.getUniqueId();

        // Reset Core combat profile
        var profile = plugin.getCore().getProfileManager().getProfile(uuid);
        if (profile != null) {
            profile.setKills(0);
            profile.setDeaths(0);
        }

        // Reset kill streak
        plugin.getKillStreakManager().resetStreak(uuid);

        plugin.getLogger().warning("[Sanction] Stats reseteadas para " + player.getName());
    }

    private String buildKickMessage(int offense, AbuseRecord.AbuseType type) {
        String typeStr = switch (type) {
            case MULTI_ACCOUNT -> "Multicuenta detectada";
            case KILL_FARMING -> "Farmeo de kills detectado";
            case LOW_GEAR_FARM -> "Farmeo de kills (víctimas sin equipo)";
            case LOCATION_FARM -> "Farmeo de kills (misma ubicación)";
        };

        return switch (offense) {
            case 1 -> plugin.getMessageManager().get("sanction.kick-header-1") + "\n\n" +
                    plugin.getMessageManager().get("sanction.kick-reason-1", "{reason}", typeStr) + "\n\n" +
                    plugin.getMessageManager().get("sanction.kick-sanction-1") + "\n" +
                    plugin.getMessageManager().get("sanction.kick-detail-1") + "\n\n" +
                    plugin.getMessageManager().get("sanction.kick-next-1");
            case 2 -> plugin.getMessageManager().get("sanction.kick-header-2") + "\n\n" +
                    plugin.getMessageManager().get("sanction.kick-reason-2", "{reason}", typeStr) + "\n\n" +
                    plugin.getMessageManager().get("sanction.kick-sanction-2") + "\n" +
                    plugin.getMessageManager().get("sanction.kick-detail-2") + "\n\n" +
                    plugin.getMessageManager().get("sanction.kick-next-2");
            default -> plugin.getMessageManager().get("sanction.kick-header-3") + "\n\n" +
                    plugin.getMessageManager().get("sanction.kick-reason-3", "{reason}", typeStr) + "\n\n" +
                    plugin.getMessageManager().get("sanction.kick-sanction-3") + "\n" +
                    plugin.getMessageManager().get("sanction.kick-detail-3");
        };
    }

    private void logSanction(Player player, int offense, AbuseRecord.AbuseType type, String details) {
        plugin.getLogger().warning(String.format(
                "[Sanction] %s | Ofensa #%d | Tipo: %s | %s",
                player.getName(), offense, type.name(), details));
    }

    // ── Accessors ────────────────────────────────────────────

    public int getOffenseLevel(UUID uuid) {
        return offenseLevels.getOrDefault(uuid, 0);
    }

    public void clearRecord(UUID uuid) {
        offenseLevels.remove(uuid);
        nullifiedKills.remove(uuid);
        saveOffenseLevels();
    }

    public int getNullifiedKills(UUID uuid) {
        return nullifiedKills.getOrDefault(uuid, 0);
    }

    public Map<UUID, Integer> getAllOffenses() {
        return java.util.Collections.unmodifiableMap(offenseLevels);
    }

    /** Clean up session-only data for a player who quit. Offense levels are persisted. */
    public void cleanupPlayer(UUID uuid) {
        nullifiedKills.remove(uuid);
    }
}
