package com.ethernova.combat.listener;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;

import java.util.UUID;

/**
 * Handles NPC death — drops items and marks as killed.
 */
public class CombatNPCListener implements Listener {

    private final EthernovaCombat plugin;

    public CombatNPCListener(EthernovaCombat plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.HIGH)
    public void onNPCDeath(EntityDeathEvent event) {
        if (!plugin.getNpcManager().isCombatNPC(event.getEntity())) return;

        event.getDrops().clear();
        event.setDroppedExp(0);

        UUID ownerUuid = plugin.getNpcManager().getOwnerFromNPC(event.getEntity());
        if (ownerUuid == null) return;

        Player killer = event.getEntity().getKiller();
        // Handle both player kills and environmental deaths (fire, fall, etc)
        plugin.getNpcManager().onNPCKilled(ownerUuid, killer);
    }
}
