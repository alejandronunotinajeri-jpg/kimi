package com.ethernova.combat.deathrecap;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * DeathRecapManager — Muestra un resumen detallado de cómo murió el jugador.
 * 
 * Trackea:
 * - Últimos N daños recibidos (quién, cuánto, con qué arma, tipo de daño)
 * - Killer final: nombre, HP restante, armadura, arma usada
 * - Duración del combate
 * - GUI completa de 54 slots con timeline de daño
 */
public class DeathRecapManager {

    private final EthernovaCombat plugin;

    // Historial de daño por jugador
    private final Map<UUID, List<DamageEntry>> damageHistory = new ConcurrentHashMap<>();

    // Último recap disponible por jugador
    private final Map<UUID, DeathRecap> lastRecap = new ConcurrentHashMap<>();

    // Inicio de combate
    private final Map<UUID, Long> combatStartTime = new ConcurrentHashMap<>();

    private static final int MAX_DAMAGE_ENTRIES = 15;
    public static final String GUI_TITLE = "§8» §c§lDeath Recap";

    public DeathRecapManager(EthernovaCombat plugin) {
        this.plugin = plugin;
    }

    // ══════════════════════════════════════════════════════════
    //                    DATA CLASSES
    // ══════════════════════════════════════════════════════════

    public static class DamageEntry {
        public final UUID attackerId;
        public final String attackerName;
        public final double damage;
        public final String weaponName;
        public final Material weaponType;
        public final DamageType type;
        public final long timestamp;

        public DamageEntry(UUID attackerId, String attackerName, double damage,
                           String weaponName, Material weaponType, DamageType type) {
            this.attackerId = attackerId;
            this.attackerName = attackerName;
            this.damage = damage;
            this.weaponName = weaponName;
            this.weaponType = weaponType;
            this.type = type;
            this.timestamp = System.currentTimeMillis();
        }
    }

    public enum DamageType {
        MELEE("§c⚔ Cuerpo a cuerpo"),
        PROJECTILE("§b🏹 Proyectil"),
        FIRE("§6🔥 Fuego"),
        EXPLOSION("§4💥 Explosión"),
        FALL("§7⬇ Caída"),
        MAGIC("§5✨ Magia"),
        VOID("§8⬛ Vacío"),
        COMBAT_LOG("§c📴 Desconexión"),
        OTHER("§7❓ Otro");

        public final String display;
        DamageType(String display) { this.display = display; }
    }

    public static class DeathRecap {
        public final UUID victimId;
        public final String victimName;
        public final UUID killerId;
        public final String killerName;
        public final double killerHP;
        public final ItemStack killerWeapon;
        public final ItemStack[] killerArmor;
        public final List<DamageEntry> damageLog;
        public final long combatDuration;
        public final double totalDamage;
        public final long timestamp;

        public DeathRecap(UUID victimId, String victimName, UUID killerId, String killerName,
                          double killerHP, ItemStack killerWeapon, ItemStack[] killerArmor,
                          List<DamageEntry> damageLog, long combatDuration) {
            this.victimId = victimId;
            this.victimName = victimName;
            this.killerId = killerId;
            this.killerName = killerName;
            this.killerHP = killerHP;
            this.killerWeapon = killerWeapon;
            this.killerArmor = killerArmor;
            this.damageLog = damageLog;
            this.combatDuration = combatDuration;
            this.totalDamage = damageLog.stream().mapToDouble(e -> e.damage).sum();
            this.timestamp = System.currentTimeMillis();
        }
    }

    // ══════════════════════════════════════════════════════════
    //                    DAMAGE TRACKING
    // ══════════════════════════════════════════════════════════

    public void recordDamage(Player victim, Player attacker, double damage,
                             ItemStack weapon, DamageType type) {
        UUID vid = victim.getUniqueId();
        combatStartTime.putIfAbsent(vid, System.currentTimeMillis());

        String weaponName = "§7Puños";
        Material weaponType = Material.AIR;
        if (weapon != null && weapon.getType() != Material.AIR) {
            weaponType = weapon.getType();
            if (weapon.hasItemMeta() && weapon.getItemMeta().hasDisplayName()) {
                weaponName = weapon.getItemMeta().getDisplayName();
            } else {
                weaponName = formatMaterialName(weapon.getType());
            }
        }

        DamageEntry entry = new DamageEntry(
                attacker != null ? attacker.getUniqueId() : null,
                attacker != null ? attacker.getName() : "Entorno",
                damage, weaponName, weaponType, type
        );

        List<DamageEntry> history = damageHistory.computeIfAbsent(vid, k -> new ArrayList<>());
        history.add(entry);
        while (history.size() > MAX_DAMAGE_ENTRIES) {
            history.remove(0);
        }
    }

    public void recordEnvironmentalDamage(Player victim, double damage, DamageType type) {
        recordDamage(victim, null, damage, null, type);
    }

    // ══════════════════════════════════════════════════════════
    //                    DEATH EVENT
    // ══════════════════════════════════════════════════════════

    public void generateRecap(Player victim, Player killer) {
        UUID vid = victim.getUniqueId();

        List<DamageEntry> log = damageHistory.getOrDefault(vid, new ArrayList<>());
        long combatStart = combatStartTime.getOrDefault(vid, System.currentTimeMillis());
        long duration = System.currentTimeMillis() - combatStart;

        double killerHP = 0;
        ItemStack killerWeapon = null;
        ItemStack[] killerArmor = null;
        String killerName = "Entorno";
        UUID killerId = null;

        if (killer != null) {
            killerId = killer.getUniqueId();
            killerName = killer.getName();
            killerHP = Math.round(killer.getHealth() * 10.0) / 10.0;
            killerWeapon = killer.getInventory().getItemInMainHand().clone();
            killerArmor = cloneArmor(killer.getInventory().getArmorContents());
        }

        DeathRecap recap = new DeathRecap(
                vid, victim.getName(), killerId, killerName,
                killerHP, killerWeapon, killerArmor,
                new ArrayList<>(log), duration
        );

        lastRecap.put(vid, recap);
        damageHistory.remove(vid);
        combatStartTime.remove(vid);

        sendChatRecap(victim, recap);
    }

    /**
     * Llamar desde CombatDeathListener — reemplaza sendRecap(victim)
     */
    public void sendRecap(Player victim) {
        Player killer = victim.getKiller();
        generateRecap(victim, killer);
    }

    // ══════════════════════════════════════════════════════════
    //                    CHAT RECAP
    // ══════════════════════════════════════════════════════════

    private void sendChatRecap(Player victim, DeathRecap recap) {
        new BukkitRunnable() {
            @Override
            public void run() {
                if (!victim.isOnline()) return;

                victim.sendMessage("");
                victim.sendMessage("§8§m                                              ");
                victim.sendMessage("  §c§l☠ DEATH RECAP");

                if (recap.killerId != null) {
                    victim.sendMessage("  §7Eliminado por: §f§l" + recap.killerName);
                    victim.sendMessage("  §7HP restante: §c❤ " + recap.killerHP);

                    if (recap.killerWeapon != null && recap.killerWeapon.getType() != Material.AIR) {
                        String weapName = recap.killerWeapon.hasItemMeta() && recap.killerWeapon.getItemMeta().hasDisplayName()
                                ? recap.killerWeapon.getItemMeta().getDisplayName()
                                : formatMaterialName(recap.killerWeapon.getType());
                        victim.sendMessage("  §7Arma: §e" + weapName);
                    }
                } else {
                    victim.sendMessage("  §7Muerte ambiental");
                }

                victim.sendMessage("  §7Combate: §f" + formatDuration(recap.combatDuration));
                victim.sendMessage("  §7Daño total: §c" + String.format("%.1f", recap.totalDamage) + " ❤");

                if (!recap.damageLog.isEmpty()) {
                    Map<String, Double> bySource = new LinkedHashMap<>();
                    for (DamageEntry entry : recap.damageLog) {
                        bySource.merge(entry.attackerName, entry.damage, Double::sum);
                    }

                    victim.sendMessage("");
                    victim.sendMessage("  §e§lFuentes de daño:");
                    bySource.entrySet().stream()
                            .sorted(Map.Entry.<String, Double>comparingByValue().reversed())
                            .limit(3)
                            .forEach(e -> {
                                double pct = (e.getValue() / recap.totalDamage) * 100;
                                victim.sendMessage("   §8▸ §f" + e.getKey() + " §7- §c" +
                                        String.format("%.1f", e.getValue()) + "❤ §8(§7" +
                                        String.format("%.0f", pct) + "%§8)");
                            });
                }

                victim.sendMessage("");
                victim.sendMessage("  §7§oEscribe §e§o/deathrecap §7§opara ver detalles");
                victim.sendMessage("§8§m                                              ");
                victim.sendMessage("");

                victim.playSound(victim.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.3f, 0.5f);
            }
        }.runTaskLater(plugin, 5L);
    }

    // ══════════════════════════════════════════════════════════
    //                    DETAILED GUI
    // ══════════════════════════════════════════════════════════

    public void openRecapGUI(Player player) {
        DeathRecap recap = lastRecap.get(player.getUniqueId());
        if (recap == null) {
            player.sendMessage("§c§l✗ §cNo hay death recap disponible.");
            return;
        }

        if (System.currentTimeMillis() - recap.timestamp > 300_000) {
            lastRecap.remove(player.getUniqueId());
            player.sendMessage("§c§l✗ §cTu death recap ha expirado.");
            return;
        }

        Inventory inv = Bukkit.createInventory(null, 54, GUI_TITLE);

        // === Row 0: Killer Info (slot 4) ===
        if (recap.killerId != null) {
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta hm = (SkullMeta) head.getItemMeta();
            hm.setOwningPlayer(Bukkit.getOfflinePlayer(recap.killerId));
            hm.setDisplayName("§c§l☠ " + recap.killerName);
            List<String> lore = new ArrayList<>();
            lore.add("§8§m                         ");
            lore.add("§7HP restante: §c❤ " + recap.killerHP);
            lore.add("");
            if (recap.killerWeapon != null && recap.killerWeapon.getType() != Material.AIR) {
                String wName = recap.killerWeapon.hasItemMeta() && recap.killerWeapon.getItemMeta().hasDisplayName()
                        ? recap.killerWeapon.getItemMeta().getDisplayName()
                        : formatMaterialName(recap.killerWeapon.getType());
                lore.add("§7Arma: §e" + wName);
            }
            lore.add("§7Duración: §f" + formatDuration(recap.combatDuration));
            lore.add("§7Daño total: §c" + String.format("%.1f", recap.totalDamage) + " ❤");
            lore.add("§8§m                         ");
            hm.setLore(lore);
            head.setItemMeta(hm);
            inv.setItem(4, head);
        } else {
            ItemStack skull = new ItemStack(Material.SKELETON_SKULL);
            ItemMeta sm = skull.getItemMeta();
            sm.setDisplayName("§c§lMuerte ambiental");
            sm.setLore(Arrays.asList(
                    "§7Duración: §f" + formatDuration(recap.combatDuration),
                    "§7Daño total: §c" + String.format("%.1f", recap.totalDamage) + " ❤"
            ));
            skull.setItemMeta(sm);
            inv.setItem(4, skull);
        }

        // === Row 0: Killer armor (slots 0-3) ===
        if (recap.killerArmor != null) {
            for (int i = 0; i < Math.min(4, recap.killerArmor.length); i++) {
                if (recap.killerArmor[i] != null && recap.killerArmor[i].getType() != Material.AIR) {
                    inv.setItem(i, recap.killerArmor[i].clone());
                }
            }
        }

        // === Row 0: Killer weapon (slot 5) ===
        if (recap.killerWeapon != null && recap.killerWeapon.getType() != Material.AIR) {
            inv.setItem(5, recap.killerWeapon.clone());
        }

        // === Rows 1-4: Damage Timeline (más reciente arriba) ===
        int slot = 9;
        List<DamageEntry> reversed = new ArrayList<>(recap.damageLog);
        Collections.reverse(reversed);

        for (DamageEntry entry : reversed) {
            if (slot >= 45) break;

            Material icon = getIconForDamageType(entry.type);
            ItemStack item = new ItemStack(icon);
            ItemMeta meta = item.getItemMeta();

            long secsAgo = (recap.timestamp - entry.timestamp) / 1000;
            String timeStr = secsAgo > 0 ? secsAgo + "s antes" : "golpe final";

            meta.setDisplayName(entry.type.display + " §8[§7" + timeStr + "§8]");
            List<String> lore = new ArrayList<>();
            lore.add("");
            lore.add("§7Atacante: §f" + entry.attackerName);
            lore.add("§7Daño: §c" + String.format("%.1f", entry.damage) + " ❤");
            if (entry.weaponType != Material.AIR) {
                lore.add("§7Arma: §e" + entry.weaponName);
            }
            lore.add("");
            meta.setLore(lore);
            item.setItemMeta(meta);
            inv.setItem(slot++, item);
        }

        // === Row 5: Stats summary ===
        ItemStack statsItem = new ItemStack(Material.PAPER);
        ItemMeta statsMeta = statsItem.getItemMeta();
        statsMeta.setDisplayName("§e§lResumen de Daño");
        List<String> statsLore = new ArrayList<>();
        statsLore.add("");

        Map<String, Double> bySource = new LinkedHashMap<>();
        for (DamageEntry entry : recap.damageLog) {
            bySource.merge(entry.attackerName, entry.damage, Double::sum);
        }

        bySource.entrySet().stream()
                .sorted(Map.Entry.<String, Double>comparingByValue().reversed())
                .forEach(e -> {
                    double pct = recap.totalDamage > 0 ? (e.getValue() / recap.totalDamage) * 100 : 0;
                    String bar = generateBar(pct);
                    statsLore.add("§f" + e.getKey() + " §c" + String.format("%.1f", e.getValue()) + "❤");
                    statsLore.add("  " + bar + " §7" + String.format("%.0f%%", pct));
                });

        statsLore.add("");
        statsMeta.setLore(statsLore);
        statsItem.setItemMeta(statsMeta);
        inv.setItem(49, statsItem);

        // Back button
        ItemStack back = new ItemStack(Material.ARROW);
        ItemMeta backMeta = back.getItemMeta();
        backMeta.setDisplayName("§c← Cerrar");
        back.setItemMeta(backMeta);
        inv.setItem(45, back);

        // Fill empty slots with glass
        fillBorderGlass(inv);

        player.openInventory(inv);
    }

    // ══════════════════════════════════════════════════════════
    //                    GUI HANDLER
    // ══════════════════════════════════════════════════════════

    public void handleGUIClick(Player player, int slot, ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return;
        if (item.getType() == Material.ARROW) {
            player.closeInventory();
        }
    }

    // ══════════════════════════════════════════════════════════
    //                    CLEANUP
    // ══════════════════════════════════════════════════════════

    public void handleQuit(UUID uuid) {
        damageHistory.remove(uuid);
        combatStartTime.remove(uuid);
    }

    public boolean hasRecap(UUID uuid) {
        DeathRecap recap = lastRecap.get(uuid);
        if (recap == null) return false;
        if (System.currentTimeMillis() - recap.timestamp > 300_000) {
            lastRecap.remove(uuid);
            return false;
        }
        return true;
    }

    // ══════════════════════════════════════════════════════════
    //                    UTILITIES
    // ══════════════════════════════════════════════════════════

    private Material getIconForDamageType(DamageType type) {
        return switch (type) {
            case MELEE -> Material.IRON_SWORD;
            case PROJECTILE -> Material.ARROW;
            case FIRE -> Material.BLAZE_POWDER;
            case EXPLOSION -> Material.TNT;
            case FALL -> Material.FEATHER;
            case MAGIC -> Material.SPLASH_POTION;
            case VOID -> Material.BLACK_CONCRETE;
            case COMBAT_LOG -> Material.BARRIER;
            default -> Material.PAPER;
        };
    }

    private String formatDuration(long ms) {
        long secs = ms / 1000;
        if (secs < 60) return secs + "s";
        long mins = secs / 60;
        secs %= 60;
        return mins + "m " + secs + "s";
    }

    private String formatMaterialName(Material mat) {
        String name = mat.name().replace("_", " ").toLowerCase();
        StringBuilder result = new StringBuilder();
        for (String word : name.split(" ")) {
            if (!result.isEmpty()) result.append(" ");
            result.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return result.toString();
    }

    private String generateBar(double pct) {
        int filled = (int) (pct / 5);
        int empty = 20 - filled;
        StringBuilder bar = new StringBuilder("§c");
        for (int i = 0; i < filled; i++) bar.append("█");
        bar.append("§8");
        for (int i = 0; i < empty; i++) bar.append("░");
        return bar.toString();
    }

    private ItemStack[] cloneArmor(ItemStack[] armor) {
        if (armor == null) return null;
        ItemStack[] clone = new ItemStack[armor.length];
        for (int i = 0; i < armor.length; i++) {
            clone[i] = armor[i] != null ? armor[i].clone() : null;
        }
        return clone;
    }

    private void fillBorderGlass(Inventory inv) {
        ItemStack glass = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta gm = glass.getItemMeta();
        gm.setDisplayName(" ");
        glass.setItemMeta(gm);
        for (int i = 0; i < inv.getSize(); i++) {
            if (inv.getItem(i) == null) {
                inv.setItem(i, glass);
            }
        }
    }

    public static DamageType fromBukkitCause(EntityDamageEvent.DamageCause cause) {
        return switch (cause) {
            case ENTITY_ATTACK, ENTITY_SWEEP_ATTACK -> DamageType.MELEE;
            case PROJECTILE -> DamageType.PROJECTILE;
            case FIRE, FIRE_TICK, LAVA, HOT_FLOOR -> DamageType.FIRE;
            case BLOCK_EXPLOSION, ENTITY_EXPLOSION -> DamageType.EXPLOSION;
            case FALL, FLY_INTO_WALL -> DamageType.FALL;
            case MAGIC, POISON, WITHER -> DamageType.MAGIC;
            case VOID -> DamageType.VOID;
            default -> DamageType.OTHER;
        };
    }
}
