package com.ethernova.combat.message;

import com.ethernova.combat.EthernovaCombat;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.logging.Level;

public class CombatMessageManager {

    private final EthernovaCombat plugin;
    private final MiniMessage mini = MiniMessage.miniMessage();
    private YamlConfiguration messages;
    private String prefix;

    public CombatMessageManager(EthernovaCombat plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        String lang = plugin.getConfigManager().getString("general.language", "es");
        String fileName = "messages_" + lang + ".yml";
        File file = new File(plugin.getDataFolder(), fileName);
        if (!file.exists()) {
            try { plugin.saveResource(fileName, false); }
            catch (Exception e) { plugin.getLogger().log(Level.WARNING, "Could not save resource " + fileName, e); }
        }
        if (!file.exists()) {
            fileName = "messages_es.yml";
            file = new File(plugin.getDataFolder(), fileName);
            if (!file.exists()) {
                try { plugin.saveResource(fileName, false); }
                catch (Exception e) { plugin.getLogger().log(Level.WARNING, "Could not save fallback resource", e); }
            }
        }

        messages = YamlConfiguration.loadConfiguration(file);
        try (InputStream def = plugin.getResource(fileName)) {
            if (def != null) {
                messages.setDefaults(YamlConfiguration.loadConfiguration(
                        new InputStreamReader(def, StandardCharsets.UTF_8)));
            }
        } catch (java.io.IOException ignored) {}

        prefix = messages.getString("general.prefix",
                "<gradient:#EF4444:#F97316>Combat</gradient> <dark_gray>»</dark_gray>");
    }

    public String get(String path, String... replacements) {
        String raw = messages.getString(path);
        if (raw == null) raw = "<red>[Missing: " + path + "]</red>";
        raw = raw.replace("{prefix}", prefix);
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            raw = raw.replace(replacements[i], replacements[i + 1]);
        }
        return raw;
    }

    public void send(CommandSender sender, String path, String... replacements) {
        sender.sendMessage(mini.deserialize(get(path, replacements)));
    }

    public void sendRaw(CommandSender sender, String miniMsg) {
        sender.sendMessage(mini.deserialize(miniMsg.replace("{prefix}", prefix)));
    }

    public String getRaw(String path, String... replacements) {
        return get(path, replacements);
    }
}
