package com.ethernova.combat.visual;

import com.ethernova.combat.EthernovaCombat;
import com.ethernova.core.gui.PlayerSettingsGui;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Enhanced visual effects manager for combat tag system.
 * Provides: hit particles, combat entry flash, compass tracking,
 * heartbeat sound at low HP, and combat state particles.
 */
public class CombatVisualManager {

    private final EthernovaCombat plugin;
    private BukkitTask compassTask;
    private BukkitTask particleTask;
    private final Map<UUID, Long> lastHeartbeat = new ConcurrentHashMap<>();

    public CombatVisualManager(EthernovaCombat plugin) {
        this.plugin = plugin;
        startCompassTracking();
        startCombatParticles();
    }

    // ─── Hit Effects ────────────────────────────────────────────

    public void showHitEffect(Location location) {
        if (!plugin.getConfigManager().getBoolean("visuals.hit-effect", true)) return;
        if (location.getWorld() == null) return;
        location.getWorld().spawnParticle(Particle.DAMAGE_INDICATOR,
                location.clone().add(0, 1, 0), 5, 0.3, 0.3, 0.3, 0);
    }

    public void showCritEffect(Location location) {
        if (location.getWorld() == null) return;
        location.getWorld().spawnParticle(Particle.CRIT,
                location.clone().add(0, 1.5, 0), 10, 0.3, 0.3, 0.3, 0);
    }

    // ─── Combat Entry Flash ─────────────────────────────────────

    /**
     * Red vignette-like title when entering combat.
     * Uses an empty title with red subtitle for the flash effect.
     */
    public void showCombatEntryFlash(Player player, String enemyName) {
        if (!plugin.getConfigManager().getBoolean("visuals.combat-flash", true)) return;

        Title.Times times = Title.Times.times(
                Duration.ofMillis(100),  // fade in
                Duration.ofMillis(600),  // stay
                Duration.ofMillis(300)   // fade out
        );

        player.showTitle(Title.title(
                plugin.getCore().getMessageManager().getMiniMessage().deserialize(
                        plugin.getMessageManager().get("visual.combat-entry-title")),
                plugin.getCore().getMessageManager().getMiniMessage().deserialize(
                        plugin.getMessageManager().get("visual.combat-entry-subtitle", "{enemy}", enemyName)),
                times
        ));

        // Impact sound
        player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 
                SoundCategory.MASTER, 0.3f, 1.5f);
    }

    // ─── Compass Tracking ───────────────────────────────────────

    /**
     * Points the player's compass to their combat enemy every second.
     */
    private void startCompassTracking() {
        if (!plugin.getConfigManager().getBoolean("visuals.compass-tracking", true)) return;

        compassTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            var tagMgr = plugin.getTagManager();
            for (var entry : tagMgr.getActiveTags().entrySet()) {
                Player player = Bukkit.getPlayer(entry.getKey());
                if (player == null || !player.isOnline()) continue;

                Player enemy = Bukkit.getPlayer(entry.getValue().getEnemy());
                if (enemy == null || !enemy.isOnline()) continue;

                // Only track in same world
                if (player.getWorld().equals(enemy.getWorld())) {
                    player.setCompassTarget(enemy.getLocation());
                }
            }
        }, 20L, 20L);
    }

    // ─── Combat State Particles ─────────────────────────────────

    /**
     * Shows subtle red particles around players in combat (visible to others).
     * Also plays heartbeat sound when health is low.
     */
    private void startCombatParticles() {
        particleTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            var tagMgr = plugin.getTagManager();
            boolean particlesEnabled = plugin.getConfigManager().getBoolean("visuals.combat-particles", true);
            boolean heartbeatEnabled = plugin.getConfigManager().getBoolean("visuals.heartbeat", true);

            for (var entry : tagMgr.getActiveTags().entrySet()) {
                Player player = Bukkit.getPlayer(entry.getKey());
                if (player == null || !player.isOnline()) continue;

                // Combat state particles — visible to other players
                if (particlesEnabled) {
                    Location loc = player.getLocation().add(0, 2.2, 0);
                    player.getWorld().spawnParticle(Particle.DUST,
                            loc, 3, 0.3, 0.1, 0.3, 0,
                            new Particle.DustOptions(Color.RED, 0.8f));
                }

                // Heartbeat at low HP
                if (heartbeatEnabled && player.getHealth() <= 6.0) { // 3 hearts or less
                    UUID uuid = player.getUniqueId();
                    long now = System.currentTimeMillis();
                    long interval = player.getHealth() <= 3.0 ? 500L : 1000L; // faster when lower

                    if (now - lastHeartbeat.getOrDefault(uuid, 0L) >= interval) {
                        lastHeartbeat.put(uuid, now);
                        player.playSound(player.getLocation(),
                                Sound.BLOCK_NOTE_BLOCK_BASS, SoundCategory.MASTER,
                                0.5f, 0.5f);
                        Bukkit.getScheduler().runTaskLater(plugin, () ->
                                player.playSound(player.getLocation(),
                                        Sound.BLOCK_NOTE_BLOCK_BASS, SoundCategory.MASTER,
                                        0.3f, 0.7f), 4L);
                    }
                }
            }

            // Cleanup heartbeat tracking for untagged players
            lastHeartbeat.keySet().removeIf(uuid -> !tagMgr.isInCombat(uuid));

        }, 10L, 10L); // Every 0.5 seconds
    }

    // ─── Kill Feed Enhancement ──────────────────────────────────

    /**
     * Send enhanced kill message with weapon info and distance.
     */
    public void sendKillFeed(Player killer, Player victim) {
        if (!plugin.getConfigManager().getBoolean("visuals.kill-feed", true)) return;

        String weaponName = "Puños";
        var mainHand = killer.getInventory().getItemInMainHand();
        if (mainHand.getType() != Material.AIR) {
            if (mainHand.hasItemMeta() && mainHand.getItemMeta().hasDisplayName()) {
                weaponName = net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer
                        .plainText().serialize(mainHand.getItemMeta().displayName());
            } else {
                weaponName = formatMaterial(mainHand.getType().name());
            }
        }

        // Guard against cross-world distance calculation (IllegalArgumentException)
        double distance = killer.getWorld().equals(victim.getWorld())
                ? killer.getLocation().distance(victim.getLocation()) : 0;
        int streak = plugin.getKillStreakManager().getStreak(killer);

        String feed = plugin.getMessageManager().get("visual.kill-feed",
                "{killer}", killer.getName(), "{victim}", victim.getName(), "{weapon}", weaponName);

        if (distance > 10) {
            feed += " " + plugin.getMessageManager().get("visual.kill-feed-distance",
                    "{distance}", String.format("%.1f", distance));
        }

        if (streak >= 3) {
            feed += " " + plugin.getMessageManager().get("visual.kill-feed-streak",
                    "{streak}", String.valueOf(streak));
        }

        // Send to nearby players (50 block radius) — safe cross-world check
        for (Player nearby : killer.getWorld().getPlayers()) {
            // Skip players who have hideKillChat enabled
            if (PlayerSettingsGui.getSetting(plugin.getCore(), nearby.getUniqueId(), "hideKillChat")) {
                continue;
            }
            double dKiller = nearby.getWorld().equals(killer.getWorld()) ? nearby.getLocation().distance(killer.getLocation()) : Double.MAX_VALUE;
            double dVictim = nearby.getWorld().equals(victim.getWorld()) ? nearby.getLocation().distance(victim.getLocation()) : Double.MAX_VALUE;
            if (dKiller <= 50 || dVictim <= 50) {
                plugin.getCore().getVisualManager().sendActionBar(nearby, feed);
            }
        }
    }

    private String formatMaterial(String name) {
        String[] parts = name.toLowerCase().split("_");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (!sb.isEmpty()) sb.append(" ");
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }

    // ─── Cleanup ────────────────────────────────────────────────

    public void shutdown() {
        if (compassTask != null) compassTask.cancel();
        if (particleTask != null) particleTask.cancel();
        lastHeartbeat.clear();
    }
}
