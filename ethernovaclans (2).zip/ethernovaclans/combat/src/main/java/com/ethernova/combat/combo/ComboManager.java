package com.ethernova.combat.combo;

import com.ethernova.combat.EthernovaCombat;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Combo system. Tracks consecutive hits on a single opponent.
 * Grants increasing damage bonus and visual feedback.
 */
public class ComboManager {

    private final EthernovaCombat combat;
    private final MiniMessage mini = MiniMessage.miniMessage();

    // Attacker UUID -> ComboData
    private final Map<UUID, ComboData> combos = new ConcurrentHashMap<>();

    // Config
    private int comboTimeout = 3000; // ms between hits to maintain combo
    private double comboBonusPerHit = 0.05; // 5% more damage per combo hit
    private int maxCombo = 20;

    public ComboManager(EthernovaCombat combat) {
        this.combat = combat;
        loadConfig();
    }

    private void loadConfig() {
        var config = combat.getConfigManager().getConfig();
        comboTimeout = config.getInt("combo.timeout-ms", 3000);
        comboBonusPerHit = config.getDouble("combo.bonus-per-hit", 0.05);
        maxCombo = config.getInt("combo.max-hits", 20);
    }

    /**
     * Register a hit. Returns the new combo count and damage multiplier.
     * @return [comboCount, damageMultiplier]
     */
    public double[] registerHit(UUID attackerUuid, UUID victimUuid) {
        long now = System.currentTimeMillis();
        ComboData data = combos.get(attackerUuid);

        if (data != null && data.targetUuid.equals(victimUuid) && (now - data.lastHit) <= comboTimeout) {
            // Continue combo
            data.hits = Math.min(data.hits + 1, maxCombo);
            data.lastHit = now;
        } else {
            // New combo or different target
            data = new ComboData(victimUuid, 1, now);
            combos.put(attackerUuid, data);
        }

        double multiplier = 1.0 + (data.hits * comboBonusPerHit);
        return new double[]{data.hits, multiplier};
    }

    /** Send combo feedback to the attacker. */
    public void sendComboFeedback(Player attacker, int comboCount) {
        if (comboCount < 2) return; // Only show from 2+

        String color;
        if (comboCount < 5) color = "<yellow>";
        else if (comboCount < 10) color = "<gold>";
        else if (comboCount < 15) color = "<red>";
        else color = "<dark_red><bold>";

        attacker.sendActionBar(mini.deserialize(
                color + "⚡ COMBO x" + comboCount + " <gray>(+" +
                String.format("%.0f", comboCount * comboBonusPerHit * 100) + "% daño)"
        ));

        if (comboCount % 5 == 0) {
            combat.getCore().getSoundManager().play(attacker, "combo");
        }
    }

    /** Get current combo count for an attacker. */
    public int getCombo(UUID attackerUuid) {
        ComboData data = combos.get(attackerUuid);
        if (data == null) return 0;
        if (System.currentTimeMillis() - data.lastHit > comboTimeout) {
            combos.remove(attackerUuid);
            return 0;
        }
        return data.hits;
    }

    /** Reset combo (when attacker takes a hit or dies). */
    public void resetCombo(UUID attackerUuid) {
        combos.remove(attackerUuid);
    }

    /** Clear all combos for a player (on quit). */
    public void clear(UUID uuid) {
        combos.remove(uuid);
    }

    private static class ComboData {
        UUID targetUuid;
        int hits;
        long lastHit;

        ComboData(UUID targetUuid, int hits, long lastHit) {
            this.targetUuid = targetUuid;
            this.hits = hits;
            this.lastHit = lastHit;
        }
    }
}
