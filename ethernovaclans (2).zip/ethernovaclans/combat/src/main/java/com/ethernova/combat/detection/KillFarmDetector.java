package com.ethernova.combat.detection;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Detects kill farming patterns:
 * - Same victim killed repeatedly within a time window
 * - Kills on low-gear (unarmed/unarmored) players
 * - Kills consistently at the same location
 */
public class KillFarmDetector {

    private final EthernovaCombat plugin;

    /** killer:victim → list of timestamps */
    private final Map<String, List<Long>> killHistory = new ConcurrentHashMap<>();

    /** killer → list of kill locations for pattern detection */
    private final Map<UUID, List<KillLocation>> locationHistory = new ConcurrentHashMap<>();

    public KillFarmDetector(EthernovaCombat plugin) {
        this.plugin = plugin;
        // Periodic cleanup every 10 minutes (sync to avoid concurrent modification)
        org.bukkit.Bukkit.getScheduler().runTaskTimer(plugin, this::cleanup,
                20L * 60 * 10, 20L * 60 * 10);
    }

    /**
     * Check if a kill is suspicious (farming pattern detected).
     * Returns the detection type, or null if clean.
     */
    public AbuseRecord.AbuseType checkKill(Player killer, Player victim, Location deathLocation) {
        String pairKey = killer.getUniqueId() + ":" + victim.getUniqueId();
        long now = System.currentTimeMillis();

        // ── Same victim threshold ────────────────────────────
        int maxRepeat = plugin.getConfigManager().getInt("detection.kill-farm.max-kills-same-player", 3);
        long windowMs = plugin.getConfigManager().getLong("detection.kill-farm.time-window-minutes", 30) * 60_000L;

        List<Long> kills = killHistory.computeIfAbsent(pairKey, k -> Collections.synchronizedList(new ArrayList<>()));
        kills.removeIf(t -> now - t > windowMs);
        kills.add(now);

        if (kills.size() > maxRepeat) {
            return AbuseRecord.AbuseType.KILL_FARMING;
        }

        // ── Low gear detection ───────────────────────────────
        if (plugin.getConfigManager().getBoolean("detection.kill-farm.check-low-gear", true)) {
            if (isLowGear(victim)) {
                // Count how many low-gear kills this player has done recently
                String lowGearKey = killer.getUniqueId() + ":lowgear";
                List<Long> lowGearKills = killHistory.computeIfAbsent(lowGearKey,
                        k -> Collections.synchronizedList(new ArrayList<>()));
                lowGearKills.removeIf(t -> now - t > windowMs);
                lowGearKills.add(now);

                int lowGearThreshold = plugin.getConfigManager().getInt("detection.kill-farm.low-gear-threshold", 5);
                if (lowGearKills.size() > lowGearThreshold) {
                    return AbuseRecord.AbuseType.LOW_GEAR_FARM;
                }
            }
        }

        // ── Location pattern detection ───────────────────────
        if (plugin.getConfigManager().getBoolean("detection.kill-farm.check-location", true)) {
            List<KillLocation> locs = locationHistory.computeIfAbsent(killer.getUniqueId(),
                    k -> Collections.synchronizedList(new ArrayList<>()));
            locs.removeIf(kl -> now - kl.time > windowMs);
            locs.add(new KillLocation(deathLocation.getBlockX(), deathLocation.getBlockY(),
                    deathLocation.getBlockZ(), deathLocation.getWorld() != null ? deathLocation.getWorld().getName() : "", now));

            int locThreshold = plugin.getConfigManager().getInt("detection.kill-farm.location-threshold", 5);
            double locRadius = plugin.getConfigManager().getDouble("detection.kill-farm.location-radius", 10.0);

            // Count kills near the current location
            long nearbyKills = locs.stream()
                    .filter(kl -> kl.world.equals(deathLocation.getWorld() != null ? deathLocation.getWorld().getName() : "")
                            && distanceSq(kl.x, kl.y, kl.z,
                            deathLocation.getBlockX(), deathLocation.getBlockY(), deathLocation.getBlockZ())
                            <= locRadius * locRadius)
                    .count();

            if (nearbyKills > locThreshold) {
                return AbuseRecord.AbuseType.LOCATION_FARM;
            }
        }

        return null;
    }

    /**
     * Record a kill (called after validation, not flagged).
     */
    public void recordCleanKill(UUID killer, UUID victim) {
        // Already tracked in checkKill via killHistory
    }

    /**
     * Get the number of suspicious kills for a player in the current window.
     */
    public int getSuspicionScore(UUID killer) {
        long now = System.currentTimeMillis();
        long windowMs = plugin.getConfigManager().getLong("detection.kill-farm.time-window-minutes", 30) * 60_000L;
        int score = 0;
        for (var entry : killHistory.entrySet()) {
            if (entry.getKey().startsWith(killer.toString())) {
                // Count only non-expired entries (read-only, no mutation)
                for (Long t : entry.getValue()) {
                    if (now - t <= windowMs) score++;
                }
            }
        }
        return score;
    }

    private boolean isLowGear(Player victim) {
        ItemStack[] armor = victim.getInventory().getArmorContents();
        int armorPieces = 0;
        for (ItemStack item : armor) {
            if (item != null && !item.getType().isAir()) armorPieces++;
        }
        String mainHandName = victim.getInventory().getItemInMainHand().getType().name();
        boolean hasWeapon = mainHandName.contains("SWORD")
                || (mainHandName.contains("AXE") && !mainHandName.contains("PICKAXE"));
        return armorPieces <= 1 && !hasWeapon;
    }

    private double distanceSq(int x1, int y1, int z1, int x2, int y2, int z2) {
        return (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2) + (z1 - z2) * (z1 - z2);
    }

    private void cleanup() {
        long now = System.currentTimeMillis();
        long maxAge = 60 * 60 * 1000L; // 1 hour max retention
        killHistory.entrySet().removeIf(e -> {
            e.getValue().removeIf(t -> now - t > maxAge);
            return e.getValue().isEmpty();
        });
        locationHistory.entrySet().removeIf(e -> {
            e.getValue().removeIf(kl -> now - kl.time > maxAge);
            return e.getValue().isEmpty();
        });
    }

    private record KillLocation(int x, int y, int z, String world, long time) {}
}
