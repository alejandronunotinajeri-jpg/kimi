package com.ethernova.combat.logout;

import com.ethernova.combat.EthernovaCombat;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class SafeLogoutManager {

    private final EthernovaCombat plugin;
    private final Map<UUID, BukkitTask> pending = new ConcurrentHashMap<>();

    public SafeLogoutManager(EthernovaCombat plugin) { this.plugin = plugin; }

    public void startLogout(Player player) {
        if (plugin.getTagManager().isInCombat(player)) {
            plugin.getMessageManager().send(player, "logout.in-combat");
            return;
        }
        if (pending.containsKey(player.getUniqueId())) {
            plugin.getMessageManager().send(player, "logout.already-pending");
            return;
        }

        int seconds = plugin.getConfigManager().getConfig().getInt("safe-logout.duration", 10);
        plugin.getMessageManager().send(player, "logout.started", "{time}", String.valueOf(seconds));

        BukkitTask task = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            pending.remove(player.getUniqueId());
            if (player.isOnline()) {
                plugin.getMessageManager().send(player, "logout.success");
                player.kickPlayer("Safe logout");
            }
        }, 20L * seconds);

        pending.put(player.getUniqueId(), task);
    }

    public void cancelLogout(UUID uuid) {
        BukkitTask task = pending.remove(uuid);
        if (task != null) {
            task.cancel();
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) plugin.getMessageManager().send(p, "logout.cancelled");
        }
    }

    public void onDamage(Player player) {
        if (pending.containsKey(player.getUniqueId())) {
            cancelLogout(player.getUniqueId());
        }
    }

    public void cancelAll() {
        for (UUID uuid : Map.copyOf(pending).keySet()) cancelLogout(uuid);
    }
}
