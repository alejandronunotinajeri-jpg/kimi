package com.ethernova.combat.tag;

import com.ethernova.combat.EthernovaCombat;
import com.ethernova.combat.module.CombatModule;
import com.ethernova.combat.module.CombatModuleRegistry;
import org.bukkit.entity.Player;

import java.util.UUID;

/**
 * Public API for other plugins to interact with the combat system.
 */
public class CombatAPI {

    private final EthernovaCombat plugin;

    public CombatAPI(EthernovaCombat plugin) { this.plugin = plugin; }

    public boolean isInCombat(Player player) { return plugin.getTagManager().isInCombat(player); }
    public boolean isInCombat(UUID uuid) { return plugin.getTagManager().isInCombat(uuid); }

    public void tag(Player p1, Player p2, String profile) {
        plugin.getTagManager().tag(p1, p2, profile);
        plugin.getTagManager().tag(p2, p1, profile);
    }

    public void untag(Player player) { plugin.getTagManager().untag(player); }

    public int getRemainingSeconds(UUID uuid) { return plugin.getTagManager().getRemainingSeconds(uuid); }
    public int getKillStreak(UUID uuid) { return plugin.getKillStreakManager().getStreak(uuid); }
    public boolean isNewbieProtected(UUID uuid) { return plugin.getNewbieManager().isProtected(uuid); }

    // Module system
    public void registerModule(CombatModule module) { plugin.getModuleRegistry().register(module); }
    public void unregisterModule(String moduleId) { plugin.getModuleRegistry().unregister(moduleId); }
    public CombatModuleRegistry getModuleRegistry() { return plugin.getModuleRegistry(); }
}
