package com.ethernova.combat.tag;

import com.ethernova.combat.EthernovaCombat;
import com.ethernova.core.EthernovaCore;
import com.ethernova.core.event.CombatTagChangeEvent;
import net.kyori.adventure.bossbar.BossBar;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class CombatTagManager {

    private final EthernovaCombat plugin;
    private final EthernovaCore core;
    private final Map<UUID, CombatTag> tags = new ConcurrentHashMap<>();
    private BukkitTask tickTask;

    public CombatTagManager(EthernovaCombat plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
        startTick();
    }

    /**
     * Tag a player. Returns false if cancelled by event or module config.
     */
    public boolean tag(Player player, Player enemy, String profile) {
        if (player.hasPermission("ethernova.combat.bypass.tag")) return false;

        // Check module-level combat tag setting
        String moduleId = profileToModuleId(profile);
        if (moduleId != null && plugin.getModuleConfigManager() != null) {
            var mc = plugin.getModuleConfigManager().getConfig(moduleId);
            if (!mc.isCombatTagEnabled()) return false;
        }

        UUID uuid = player.getUniqueId();
        int duration = getDuration(profile);
        int maxDuration = plugin.getConfigManager().getInt("combat-tag.max-duration", 30);

        // Fire cancellable Bukkit event
        CombatTagEvent event = new CombatTagEvent(player, enemy, duration, profile);
        Bukkit.getPluginManager().callEvent(event);
        if (event.isCancelled()) return false;
        duration = event.getDuration();

        CombatTag existing = tags.get(uuid);
        if (existing != null) {
            if (plugin.getConfigManager().getBoolean("combat-tag.extend-on-hit", true)) {
                existing.extend(duration, maxDuration);
                existing.setEnemy(enemy.getUniqueId());
                existing.setProfile(profile);
            }
            return true;
        }

        // New tag
        CombatTag tag = new CombatTag(uuid, enemy.getUniqueId(), duration, profile);
        tags.put(uuid, tag);

        // BossBar
        if (plugin.getConfigManager().getBoolean("combat-tag.bossbar.enabled", true)) {
            String format = formatBossBar(duration, enemy.getName());
            BossBar bar = core.getVisualManager().createBossBar("combat_" + uuid, format, BossBar.Color.GREEN, 1.0f);
            core.getVisualManager().showBossBar(player, "combat_" + uuid);
        }

        plugin.getMessageManager().send(player, "combat.tagged",
                "{enemy}", enemy.getName(), "{time}", String.valueOf(duration));

        // Combat entry flash effect
        plugin.getVisualManager().showCombatEntryFlash(player, enemy.getName());

        // Publish cross-module event (e.g., cosmetics removes pets)
        core.getEventBus().publish(new CombatTagChangeEvent(uuid, true, profile));

        return true;
    }

    public void untag(Player player) {
        untag(player.getUniqueId());
    }

    public void untag(UUID uuid) {
        CombatTag tag = tags.remove(uuid);
        if (tag == null) return;

        // Cleanup BossBar
        Player player = Bukkit.getPlayer(uuid);
        if (player != null && player.isOnline()) {
            core.getVisualManager().hideBossBar(player, "combat_" + uuid);
            plugin.getMessageManager().send(player, "combat.untagged");
        }
        core.getVisualManager().removeBossBar("combat_" + uuid);

        // Publish cross-module event (e.g., cosmetics restores pets)
        core.getEventBus().publish(new CombatTagChangeEvent(uuid, false, tag.getProfile()));
    }

    /**
     * Force untag all — used on plugin disable/reload.
     */
    public void untagAll() {
        for (UUID uuid : Map.copyOf(tags).keySet()) {
            untag(uuid);
        }
    }

    public boolean isInCombat(Player player) { return isInCombat(player.getUniqueId()); }
    public boolean isInCombat(UUID uuid) {
        CombatTag tag = tags.get(uuid);
        if (tag != null && tag.isExpired()) { untag(uuid); return false; }
        return tag != null;
    }

    public int getRemainingSeconds(UUID uuid) {
        CombatTag tag = tags.get(uuid);
        return tag != null && !tag.isExpired() ? tag.getRemainingSeconds() : 0;
    }

    public UUID getEnemy(UUID uuid) {
        CombatTag tag = tags.get(uuid);
        return tag != null ? tag.getEnemy() : null;
    }

    public String getProfile(UUID uuid) {
        CombatTag tag = tags.get(uuid);
        return tag != null ? tag.getProfile() : "survival";
    }

    public int getTaggedCount() { return tags.size(); }

    public Map<UUID, CombatTag> getActiveTags() { return Map.copyOf(tags); }

    private int getDuration(String profile) {
        // First check module config for override
        String moduleId = profileToModuleId(profile);
        if (moduleId != null && plugin.getModuleConfigManager() != null) {
            var mc = plugin.getModuleConfigManager().getConfig(moduleId);
            if (mc.getTagDuration() > 0) {
                return mc.getTagDuration();
            }
        }
        // Fallback to profile config → global default
        return plugin.getConfigManager().getInt("combat-tag.profiles." + profile + ".duration",
                plugin.getConfigManager().getInt("combat-tag.default-duration", 15));
    }

    /**
     * Map a combat profile name to a module ID.
     * Returns null if no mapping exists.
     */
    public static String profileToModuleId(String profile) {
        if (profile == null) return null;
        return switch (profile.toLowerCase()) {
            case "ffa" -> "ffa";
            case "arena", "duels", "duel" -> "duels";
            case "ranked" -> "ranked";
            case "party", "partygames" -> "party";
            case "war", "survival", "clans" -> "clans";
            default -> null;
        };
    }

    private String formatBossBar(int time, String enemy) {
        return plugin.getConfigManager().getString("combat-tag.bossbar.format",
                        plugin.getMessageManager().get("visual.bossbar-format"))
                .replace("{time}", String.valueOf(time))
                .replace("{enemy}", enemy);
    }

    private void startTick() {
        tickTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (var entry : Map.copyOf(tags).entrySet()) {
                UUID uuid = entry.getKey();
                CombatTag tag = entry.getValue();
                tag.tick();

                if (tag.isExpired()) {
                    untag(uuid);
                    continue;
                }

                Player player = Bukkit.getPlayer(uuid);
                if (player == null || !player.isOnline()) {
                    // Player left without quit event firing (crash) — cleanup
                    tags.remove(uuid);
                    core.getVisualManager().removeBossBar("combat_" + uuid);
                    continue;
                }

                // Update BossBar
                BossBar bar = core.getVisualManager().getBossBar("combat_" + uuid);
                if (bar != null) {
                    float progress = (float) tag.getRemainingSeconds() / tag.getMaxDuration();
                    bar.progress(Math.max(0f, Math.min(1f, progress)));

                    Player enemy = Bukkit.getPlayer(tag.getEnemy());
                    String enemyName = enemy != null ? enemy.getName() : "?";
                    bar.name(core.getMessageManager().getMiniMessage().deserialize(
                            formatBossBar(tag.getRemainingSeconds(), enemyName)));

                    // Color transitions: GREEN → YELLOW → RED as time runs out
                    if (progress <= 0.25f) bar.color(BossBar.Color.RED);
                    else if (progress <= 0.5f) bar.color(BossBar.Color.YELLOW);
                    else bar.color(BossBar.Color.GREEN);
                }

                // ActionBar
                if (plugin.getConfigManager().getBoolean("combat-tag.actionbar.enabled", true)) {
                    Player enemy = Bukkit.getPlayer(tag.getEnemy());
                    String enemyName = enemy != null ? enemy.getName() : "?";
                    String abFormat = plugin.getConfigManager().getString("combat-tag.actionbar.format",
                                    plugin.getMessageManager().get("visual.actionbar-format"))
                            .replace("{time}", String.valueOf(tag.getRemainingSeconds()))
                            .replace("{enemy}", enemyName);
                    core.getVisualManager().sendActionBar(player, abFormat);
                }
            }
        }, 20L, 20L);
    }

    public void shutdown() {
        if (tickTask != null) tickTask.cancel();
        untagAll();
    }
}
