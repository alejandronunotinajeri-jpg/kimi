package com.ethernova.combat.world;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class WorldCombatConfigTest {

    private WorldCombatConfig config;

    @BeforeEach
    void setUp() {
        config = new WorldCombatConfig("world");
    }

    @Nested
    @DisplayName("Defaults")
    class DefaultTests {
        @Test void worldName() { assertEquals("world", config.getWorldName()); }
        @Test void combatTagEnabled() { assertTrue(config.isCombatTagEnabled()); }
        @Test void tagDuration() { assertEquals(15, config.getTagDuration()); }
        @Test void keepInventory() { assertFalse(config.isKeepInventory()); }
        @Test void logoutPenalty() { assertEquals("KILL", config.getLogoutPenalty()); }
        @Test void flyDisabled() { assertTrue(config.isFlyDisabled()); }
        @Test void newbieProtection() { assertEquals(30, config.getNewbieProtectionMinutes()); }
        @Test void defaultBlockedCommands() {
            assertTrue(config.getBlockedCommands().contains("home"));
            assertTrue(config.getBlockedCommands().contains("spawn"));
        }
    }

    @Nested
    @DisplayName("setTagDuration() — clamped 1-120")
    class TagDurationTests {
        @Test void normalValue() { config.setTagDuration(30); assertEquals(30, config.getTagDuration()); }
        @Test void clampedBelow() { config.setTagDuration(-5); assertEquals(1, config.getTagDuration()); }
        @Test void clampedAbove() { config.setTagDuration(999); assertEquals(120, config.getTagDuration()); }
        @Test void boundaryMin() { config.setTagDuration(1); assertEquals(1, config.getTagDuration()); }
        @Test void boundaryMax() { config.setTagDuration(120); assertEquals(120, config.getTagDuration()); }
    }

    @Nested
    @DisplayName("setNewbieProtectionMinutes() — min 0")
    class NewbieProtTests {
        @Test void normalValue() { config.setNewbieProtectionMinutes(60); assertEquals(60, config.getNewbieProtectionMinutes()); }
        @Test void clampedBelowZero() { config.setNewbieProtectionMinutes(-10); assertEquals(0, config.getNewbieProtectionMinutes()); }
        @Test void zeroAllowed() { config.setNewbieProtectionMinutes(0); assertEquals(0, config.getNewbieProtectionMinutes()); }
    }

    @Nested
    @DisplayName("setEnderPearlCooldown() — min 0")
    class PearlCooldownTests {
        @Test void normalValue() { config.setEnderPearlCooldown(10); assertEquals(10, config.getEnderPearlCooldown()); }
        @Test void clampedBelowZero() { config.setEnderPearlCooldown(-1); assertEquals(0, config.getEnderPearlCooldown()); }
    }

    @Nested
    @DisplayName("setLootProtectionSeconds() — min 0")
    class LootProtectionTests {
        @Test void normalValue() { config.setLootProtectionSeconds(45); assertEquals(45, config.getLootProtectionSeconds()); }
        @Test void clampedBelowZero() { config.setLootProtectionSeconds(-5); assertEquals(0, config.getLootProtectionSeconds()); }
    }

    @Nested
    @DisplayName("cycleLogoutPenalty()")
    class CyclePenaltyTests {
        @Test
        void killToDropInventory() {
            config.setLogoutPenalty("KILL");
            config.cycleLogoutPenalty();
            assertEquals("DROP_INVENTORY", config.getLogoutPenalty());
        }

        @Test
        void dropInventoryToNone() {
            config.setLogoutPenalty("DROP_INVENTORY");
            config.cycleLogoutPenalty();
            assertEquals("NONE", config.getLogoutPenalty());
        }

        @Test
        void noneToKill() {
            config.setLogoutPenalty("NONE");
            config.cycleLogoutPenalty();
            assertEquals("KILL", config.getLogoutPenalty());
        }

        @Test
        void unknownDefaultsToKill() {
            config.setLogoutPenalty("UNKNOWN");
            config.cycleLogoutPenalty();
            assertEquals("KILL", config.getLogoutPenalty());
        }

        @Test
        void fullCycleReturnsToStart() {
            assertEquals("KILL", config.getLogoutPenalty());
            config.cycleLogoutPenalty(); // DROP_INVENTORY
            config.cycleLogoutPenalty(); // NONE
            config.cycleLogoutPenalty(); // KILL
            assertEquals("KILL", config.getLogoutPenalty());
        }
    }

    @Nested
    @DisplayName("setBlockedCommands()")
    class BlockedCommandsTests {
        @Test
        void replacesBlockedCommands() {
            config.setBlockedCommands(List.of("fly", "op"));
            assertEquals(2, config.getBlockedCommands().size());
            assertTrue(config.getBlockedCommands().contains("fly"));
        }

        @Test
        void defensiveCopy() {
            var list = new java.util.ArrayList<>(List.of("a", "b"));
            config.setBlockedCommands(list);
            list.add("c");
            assertEquals(2, config.getBlockedCommands().size());
        }
    }
}
