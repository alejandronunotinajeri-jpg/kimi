package com.ethernova.combat.tag;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class CombatTagTest {

    private UUID player;
    private UUID enemy;
    private CombatTag tag;

    @BeforeEach
    void setUp() {
        player = UUID.randomUUID();
        enemy = UUID.randomUUID();
        tag = new CombatTag(player, enemy, 15, "default");
    }

    @Nested
    @DisplayName("Construction & Getters")
    class ConstructionTests {
        @Test void playerIsSet() { assertEquals(player, tag.getPlayer()); }
        @Test void enemyIsSet() { assertEquals(enemy, tag.getEnemy()); }
        @Test void remainingStartsAtDuration() { assertEquals(15, tag.getRemainingSeconds()); }
        @Test void maxDurationMatchesInitial() { assertEquals(15, tag.getMaxDuration()); }
        @Test void profileIsSet() { assertEquals("default", tag.getProfile()); }
    }

    @Nested
    @DisplayName("tick()")
    class TickTests {
        @Test
        void tickDecrementsRemainingSeconds() {
            tag.tick();
            assertEquals(14, tag.getRemainingSeconds());
        }

        @Test
        void multipleTicksDecrement() {
            for (int i = 0; i < 10; i++) tag.tick();
            assertEquals(5, tag.getRemainingSeconds());
        }

        @Test
        void tickPastZeroClampedByGetter() {
            for (int i = 0; i < 20; i++) tag.tick();
            assertEquals(0, tag.getRemainingSeconds());
        }
    }

    @Nested
    @DisplayName("isExpired()")
    class ExpiryTests {
        @Test
        void notExpiredInitially() {
            assertFalse(tag.isExpired());
        }

        @Test
        void expiredAfterAllTicksElapse() {
            for (int i = 0; i < 15; i++) tag.tick();
            assertTrue(tag.isExpired());
        }

        @Test
        void notExpiredWithOneSecondRemaining() {
            for (int i = 0; i < 14; i++) tag.tick();
            assertFalse(tag.isExpired());
        }
    }

    @Nested
    @DisplayName("extend()")
    class ExtendTests {
        @Test
        void extendAddsSeconds() {
            tag.tick(); // 14
            tag.extend(5, 30);
            assertEquals(19, tag.getRemainingSeconds());
        }

        @Test
        void extendClampedToMax() {
            tag.extend(100, 20);
            assertEquals(20, tag.getRemainingSeconds());
        }

        @Test
        void maxDurationUpdatedWhenExtendExceedsPrevious() {
            tag.extend(10, 30);
            assertEquals(25, tag.getMaxDuration());
        }

        @Test
        void maxDurationNotReducedIfExtendIsSmaller() {
            tag.tick(); // 14
            tag.extend(1, 15);
            assertEquals(15, tag.getMaxDuration());
        }
    }

    @Nested
    @DisplayName("Setters")
    class SetterTests {
        @Test
        void setEnemyUpdatesEnemy() {
            UUID newEnemy = UUID.randomUUID();
            tag.setEnemy(newEnemy);
            assertEquals(newEnemy, tag.getEnemy());
        }

        @Test
        void setProfileUpdatesProfile() {
            tag.setProfile("combat_zone");
            assertEquals("combat_zone", tag.getProfile());
        }
    }
}
