# 🔍 Comprehensive Research-Only Audit — EthernovaClans

**Date:** 2025  
**Plugin:** EthernovaClans Multi-Module  
**Platform:** Paper 1.21.4, Java 21, Maven multi-module  
**Modules audited:** core, combat, cosmetics, ffa, duels, ranked, party, progression, discord, clans (src)  
**Files inspected:** 329+ Java source files, 83 resource files  

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [Critical Issues](#-critical--bugs--broken-features)
3. [High Priority](#-high--missing-core-features)
4. [Medium Priority](#-medium--quality-of-life--polish)
5. [Low Priority](#-low--nice-to-have--cleanup)
6. [Stale Audit Documents Note](#-stale-audit-documents)

---

## Executive Summary

The EthernovaClans codebase is extensive and well-structured. The modularization via Maven multi-module + ServiceRegistry + EthernovaEventBus patterns is solid. Most original UltimateFFA systems have been replicated or expanded. However, the audit identified **4 critical issues**, **9 high-priority gaps**, **10 medium-priority improvements**, and **8 low-priority cleanups**.

The most impactful finding is the **prestige config/code mismatch** where the `PrestigeManager` completely ignores its config file and uses hardcoded data. The second most impactful is the **ClanLevelManager boost stubs** that silently fail on every player join/quit.

---

## 🔴 CRITICAL — Bugs / Broken Features

### C-1: Prestige Manager Ignores Config — Hardcoded 10 Tiers vs Config's 5

| Field | Value |
|-------|-------|
| **Module** | `progression` |
| **File** | `progression/src/main/java/com/ethernova/progression/prestige/PrestigeManager.java` |
| **Lines** | 39-56 |
| **Config** | `progression/src/main/resources/config.yml` lines 29-44 |

**What's wrong:**  
`PrestigeManager.java` hardcodes `MAX_PRESTIGE = 10` with a full `PRESTIGE_DATA` array (kills 100→7500, costs $0→$3M, rewards $5K→$2.5M, bonus% 5→100, discount% 5→20) and `PRESTIGE_PREFIXES` for 10 tiers. The config file defines `prestige.max-prestige: 5` with completely different XP multipliers `{1: 1.1, 2: 1.25, 3: 1.5, 4: 2.0, 5: 3.0}`. **The config values are never read by PrestigeManager.**

**Additional conflict:** The placeholder `%progression_prestige_max%` reads from config (returns 5), while `ProgressionAPI.getMaxPrestige()` calls `PrestigeManager.getMaxPrestige()` which returns the hardcoded 10. Players see conflicting max prestige numbers.

The `ProgressionAdminGui` has a "Max Prestige" config editor (slot 16) that changes `prestige.max-prestige` in config, but PrestigeManager never reads it.

**Fix:** Read max prestige, kill requirements, costs, rewards, and multipliers from config instead of hardcoded arrays. Ensure the placeholder and API return the same value. Remove the hardcoded `PRESTIGE_DATA` and `PRESTIGE_PREFIXES` arrays and load them from config with sensible defaults.

---

### C-2: ClanLevelManager applyBoosts/removeBoosts — Empty Stubs Called on Every Join/Quit

| Field | Value |
|-------|-------|
| **Module** | `src` (clans) |
| **File** | `src/main/java/com/ethernova/clans/level/ClanLevelManager.java` |
| **Lines** | 223-230 |
| **Callers** | `src/main/java/com/ethernova/clans/listener/PlayerListener.java` lines 51, 146 |

**What's wrong:**  
```java
public void applyBoosts(Player player, Clan clan) {
    // Boosts are managed per-level in config; stub for future implementation
}
public void removeBoosts(Player player, Clan clan) {
    // Stub for future implementation
}
```
These methods are called on **every player join** (PlayerListener:51) and **every player quit** (PlayerListener:146). The clan level system calculates XP, tracks levels, fires level-up events, and even has config sections for perks (`levels.perks.N.extra-members`, `extra-max-power`, `extra-claims`) — but the potion/stat boosts promised by the level system are never applied to players.

**Fix:** Implement `applyBoosts()` to apply potion effects (Speed, Strength, Resistance, etc.) based on clan level from config. Implement `removeBoosts()` to remove those effects on quit.

---

### C-3: WarManager.acceptWar() Is a Stub — Wars Auto-Accept Without Defender Consent

| Field | Value |
|-------|-------|
| **Module** | `src` (clans) |
| **File** | `src/main/java/com/ethernova/clans/war/WarManager.java` |
| **Line** | 45 |

**What's wrong:**  
```java
// Auto-accepted in declareWar; stub for future pending-war flow
```
When a clan declares war, it is immediately accepted with no confirmation from the defending clan. There is no pending-war flow, no accept/deny mechanism, and no notification to the defending clan leader. This means any clan can force a war on any other clan without consent.

**Fix:** Implement a pending war request system: (1) `declareWar()` sends request to target clan, (2) target leader gets notification + accept/deny GUI, (3) war starts only on acceptance or auto-accepts after configurable timeout.

---

### C-4: Clan.java Pending Ally Stub — Alliance Requests Not Tracked in Clan Object

| Field | Value |
|-------|-------|
| **Module** | `src` (clans) |
| **File** | `src/main/java/com/ethernova/clans/clan/Clan.java` |
| **Line** | 269 |

**What's wrong:**  
```java
/** Pending ally requests — tracked in AllianceManager, stub here */
```
The `Clan` object doesn't track pending ally requests, delegating to `AllianceManager`. While `handleAlly()` in `ClanCommandExecutor` does call `AllianceManager.sendAllyRequest()`, the persistence of pending requests across server restarts needs verification. If `AllianceManager` stores pending requests only in memory, they are lost on restart.

**Fix:** Verify that `AllianceManager` persists pending ally requests to database/file. If not, implement persistence. Alternatively, add pending request tracking to the `Clan` object and persist with clan data.

---

## 🟡 HIGH — Missing Core Features

### H-1: No In-Game `/compare` Command

| Field | Value |
|-------|-------|
| **Module** | All |
| **File** | N/A (missing) |

**What's wrong:**  
The original UltimateFFA had a `/compare` command for comparing player stats side-by-side. The web map API has a `PlayerCompareApiHandler` at `/api/player-compare`, but there is no in-game command or GUI for player comparison.

**Fix:** Add a `/compare <player>` command that opens a side-by-side stats comparison GUI using `PlayerStatsGui` data from both players.

---

### H-2: Discord Module Has Only 4 Slash Commands — Missing Clan/Event/Tournament Features

| Field | Value |
|-------|-------|
| **Module** | `discord` |
| **Files** | `discord/src/main/java/com/ethernova/discord/bot/command/` |

**What's wrong:**  
Only 4 JDA slash commands exist: `/elo`, `/top`, `/link`, `/stats`. For a plugin with 10 modules covering clans, wars, territories, tournaments, events, parties, cosmetics, and progression, the Discord integration is minimal. Missing:
- Clan info lookup (`/clan <name>`)
- Server status / online players
- Event notifications (FFA events, tournaments)
- War declarations / results announcements
- Season end notifications
- Battle pass progress
- Party invite via Discord

**Fix:** Add at minimum: `/clan`, `/server`, event announcement webhooks, tournament start/end notifications. Use JDA's `MessageEmbed` for rich formatting.

---

### H-3: Baby Toggle for Pets Not GUI-Accessible

| Field | Value |
|-------|-------|
| **Module** | `cosmetics` |
| **File** | `cosmetics/src/main/java/com/ethernova/cosmetics/effect/PetManager.java` lines 118-120 |

**What's wrong:**  
The pet spawn code supports baby variants via the `_baby` suffix in pet IDs:
```java
boolean baby = id.endsWith("_baby");
if (baby) id = id.substring(0, id.length() - 5);
```
However, there is no GUI toggle button for baby/adult mode (unlike the head/floor toggle which exists via `PET_TOGGLE_HEAD`). Players must have a `_baby` variant registered as a separate cosmetic in the registry to get baby pets.

**Fix:** Add a `PET_TOGGLE_BABY` button in `PetVariantGui` and `CosmeticTypeGui` (alongside the existing head toggle). Store baby preference per player and apply on spawn.

---

### H-4: Normal Particle Trails Are Disabled

| Field | Value |
|-------|-------|
| **Module** | `cosmetics` |
| **File** | `cosmetics/src/main/java/com/ethernova/cosmetics/EthernovaCosmetics.java` line 101 |

**What's wrong:**  
```java
// trailHandler.start();
```
The normal walking trail handler is commented out. The elytra trail handler (`elytraTrailHandler.start()`) works fine on line 103. The comment suggests normal trails were replaced by Advanced Auras, but:
- `CosmeticType.TRAIL` is hidden from the cosmetics main menu (`hiddenTypes.contains(CosmeticType.TRAIL)`)
- Players who own trail cosmetics cannot use them
- The `TrailHandler` class exists but is dormant

**Fix:** Either (a) re-enable `trailHandler.start()` and remove TRAIL from hidden types, or (b) remove the TrailHandler class and TRAIL cosmetic type entirely, and ensure Advanced Auras cover all trail use cases. Document the decision.

---

### H-5: No Elytra Trail Preview System

| Field | Value |
|-------|-------|
| **Module** | `cosmetics` |
| **File** | `cosmetics/src/main/java/com/ethernova/cosmetics/effect/ElytraTrailHandler.java` |

**What's wrong:**  
`ElytraTrailHandler` has no `preview()` method. Unlike other cosmetic types (finishers have `previewFinisher()`, death sounds have `preview()`), elytra trails require the player to actually be gliding to see the effect. There is no way to preview before purchasing.

**Fix:** Add a `preview(Player, String trailId)` method that spawns a temporary elytra-wearing armor stand or phantom that flies in a circle with the trail particles for ~5 seconds.

---

### H-6: PrestigeManager Multipliers Not Actually Applied to Economy

| Field | Value |
|-------|-------|
| **Module** | `progression` |
| **File** | `progression/src/main/java/com/ethernova/progression/prestige/PrestigeManager.java` |
| **Related** | `core/src/main/java/com/ethernova/core/economy/EconomyManager.java` |

**What's wrong:**  
`PrestigeManager` calculates `moneyBonusPct` and `shopDiscountPct` per prestige tier (stored in `PRESTIGE_DATA`), and has getter methods like `getMoneyBonus(int prestige)` and `getShopDiscount(int prestige)`. However, it's unclear whether `EconomyManager` or the cosmetics shop GUI actually queries these values when processing transactions. The `prestigeMultipliers` map is loaded but there's no evidence of integration with the economy system.

**Fix:** Verify that `EconomyManager.addCoins()` multiplies rewards by `getPrestigeMultiplier(prestige)`. Verify that shop GUIs apply `getShopDiscount()` to prices. If not, wire these integrations.

---

### H-7: Cross-Module Achievement Tracking Gaps

| Field | Value |
|-------|-------|
| **Module** | `progression`, `cosmetics` |
| **Files** | `progression/src/main/java/com/ethernova/progression/achievement/AchievementManager.java`, `progression/src/main/java/com/ethernova/progression/listener/ProgressionListener.java` |

**What's wrong:**  
Achievement unlocks can trigger cosmetic rewards (noted at line 275 of AchievementManager: `ServiceRegistry.get(CosmeticsAPI)` is used). However, the reverse integration — cosmetics unlock events triggering achievement progress — is not evident. Achievements like "Unlock 10 cosmetics" or "Open 5 mystery boxes" would require cosmetics → progression event flow.

**Fix:** Add `EthernovaEventBus` events for cosmetic unlocks and mystery box opens. Subscribe to them in `ProgressionListener` to advance relevant achievements.

---

### H-8: Ranked Module Tournament Notifications Only Local

| Field | Value |
|-------|-------|
| **Module** | `ranked` |
| **File** | `ranked/src/main/java/com/ethernova/ranked/tournament/TournamentManager.java` |

**What's wrong:**  
Tournament start/end/round notifications are sent only to in-game players via `sendMessage()`. No Discord webhook, no cross-server notification. Given the competitive nature of tournaments, external notifications are expected.

**Fix:** Fire `EthernovaEventBus` events for tournament lifecycle (start, round, end, winner). Subscribe from the Discord module to send embeds.

---

### H-9: FFA Events "Free Cosmetics" Event — Implementation Completeness

| Field | Value |
|-------|-------|
| **Module** | `ffa` |
| **File** | `ffa/src/main/java/com/ethernova/ffa/event/FFAEventsManager.java` line 75 |

**What's wrong:**  
The `FREE_COSMETICS` event type is defined: "¡Todos los cosméticos están desbloqueados temporalmente!" This requires temporarily overriding the cosmetic ownership check for all players during the event. The event applies effects but temporarily unlocking all cosmetics requires deep integration with `PlayerCosmeticManager` — need to verify the unlock logic actually works and reverts properly when the event ends.

**Fix:** Verify that the `FREE_COSMETICS` event implementation in `applyEventEffects()` / `removeEventEffects()` properly talks to `CosmeticsAPI` to temporarily unlock and then re-lock cosmetics. Test for edge cases (player disconnects during event, event ends while player is in cosmetics GUI).

---

## 🟠 MEDIUM — Quality of Life / Polish

### M-1: Misleading "MISSING HANDLER STUBS" Section Header in ClanCommandExecutor

| Field | Value |
|-------|-------|
| **Module** | `src` (clans) |
| **File** | `src/main/java/com/ethernova/clans/command/ClanCommandExecutor.java` line 883 |

**What's wrong:**  
```java
//  MISSING HANDLER STUBS
```
The section header suggests the methods below are unimplemented stubs, but `handleAlly`, `handleEnemy`, `handleClaim`, etc. below line 883 are **fully implemented** with complete logic. This label is misleading and will confuse future maintainers.

**Fix:** Rename to `// ═══ SUBCOMMAND HANDLERS ═══` or similar.

---

### M-2: Excessive Silent Exception Swallowing in PetManager

| Field | Value |
|-------|-------|
| **Module** | `cosmetics` |
| **File** | `cosmetics/src/main/java/com/ethernova/cosmetics/effect/PetManager.java` |
| **Lines** | 225, 240, 257, 277, 289, 302, 314 |

**What's wrong:**  
Seven `catch (Exception ignored) {}` blocks silently swallow all exceptions in pet variant spawning methods (spawnCat, spawnParrot, spawnRabbit, etc.). If a pet type fails to spawn due to an API change, server misconfiguration, or 1.21.4-specific issue, there will be **zero logs** to diagnose the problem.

**Fix:** Replace `catch (Exception ignored) {}` with `catch (Exception e) { plugin.getLogger().log(Level.WARNING, "[Pets] Failed to set variant for " + type, e); }` or at minimum log at FINE level.

---

### M-3: ClanLevelManager.loadLevels() Is a No-Op

| Field | Value |
|-------|-------|
| **Module** | `src` (clans) |
| **File** | `src/main/java/com/ethernova/clans/level/ClanLevelManager.java` lines 218-220 |

**What's wrong:**  
```java
public void loadLevels() {
    // Level data is read dynamically from config, no preload needed
}
```
This method exists, is callable, but does nothing. If it's called during initialization, it gives a false sense of loading something.

**Fix:** Either remove it and its callers, or actually cache frequently-read config values (base-xp, xp-multiplier) to avoid repeated config lookups on every `getLevel()` call.

---

### M-4: ChatFormatListener and ChatListener Disabled by Default Without Clear User Guidance

| Field | Value |
|-------|-------|
| **Module** | `src` (clans) |
| **Files** | `src/main/java/com/ethernova/clans/listener/ChatFormatListener.java` line 35, `src/main/java/com/ethernova/clans/listener/ChatListener.java` line 111 |

**What's wrong:**  
Both chat listeners are intentionally disabled by default, delegating to external chat plugins via PlaceholderAPI. However, if a server admin doesn't have an external chat plugin configured, clan tags will not appear in chat at all. There's no warning or fallback.

**Fix:** During `onEnable()`, check if an external chat plugin is detected. If not, log a WARNING: "No external chat plugin detected. Enable chat formatting in config or install a chat plugin to show clan tags." Consider auto-enabling a basic chat format if no external plugin is found.

---

### M-5: Prestige Visual Effects Use Legacy Color Codes

| Field | Value |
|-------|-------|
| **Module** | `progression` |
| **File** | `progression/src/main/java/com/ethernova/progression/prestige/PrestigeManager.java` lines 57-66 |

**What's wrong:**  
`PRESTIGE_PREFIXES` uses legacy `§` color codes:
```java
"§e★", "§e★★", "§c♦ Veterano ♦", ...
```
The rest of the codebase uses MiniMessage format (`<gold>`, `<gradient:...>`, etc.). This inconsistency means prestige prefixes may not render correctly in MiniMessage-based displays and may cause issues with Adventure components.

**Fix:** Convert to MiniMessage format: `"<yellow>★"`, `"<red>♦ Veterano ♦"`, etc.

---

### M-6: KillStreakManager Uses Legacy Chat Color Codes

| Field | Value |
|-------|-------|
| **Module** | `combat` |
| **File** | `combat/src/main/java/com/ethernova/combat/killstreak/KillStreakManager.java` |
| **Lines** | 313, 320, 437, 507 |

**What's wrong:**  
Multiple strings use legacy `§` color codes (`§7Click derecho para lanzar a todos`, `Bukkit.broadcastMessage("§7¡Todos los jugadores cercanos recibirán daño!")`) instead of MiniMessage or Adventure components. `Bukkit.broadcastMessage()` is deprecated in Paper 1.21.4.

**Fix:** Convert to `Bukkit.broadcast(mini.deserialize(...))` using MiniMessage format. Replace all `§` strings with MiniMessage tags.

---

### M-7: TitleManager Uses Legacy Color Codes for All 30+ Titles

| Field | Value |
|-------|-------|
| **Module** | `cosmetics` |
| **File** | `cosmetics/src/main/java/com/ethernova/cosmetics/effect/TitleManager.java` lines 42-49+ |

**What's wrong:**  
All 30+ title definitions use `§` color codes in `loadDefaultTitles()`:
```java
reg("novato", "§7[Novato]", "§7[Novato] ", "", "COMMON", Material.WOODEN_SWORD, "DEFAULT", 0);
```
Inconsistent with the project's MiniMessage standard.

**Fix:** Convert all title prefixes/display names to MiniMessage format. Consider loading from config file instead of hardcoding.

---

### M-8: WebMapServer Has Many Broad Exception Catches

| Field | Value |
|-------|-------|
| **Module** | `src` (clans) |
| **File** | `src/main/java/com/ethernova/clans/webmap/WebMapServer.java` |
| **Lines** | Multiple (416, 419, 520, 531, 1276, 1757, 1768, 1788, 1821, 1844, 1949, etc.) |

**What's wrong:**  
`WebMapServer.java` has 20+ `catch (Exception e)` blocks. While some log properly, several silently catch and continue, or catch overly broad `Exception` instead of specific HTTP/IO exceptions. In a web server handling user requests, this can mask security issues.

**Fix:** Narrow catch blocks to specific exception types (IOException, NumberFormatException, etc.) and ensure all caught exceptions are logged at minimum WARNING level.

---

### M-9: No Confirmation for Destructive Clan Actions in Discord

| Field | Value |
|-------|-------|
| **Module** | `discord` |
| **File** | N/A (feature gap) |

**What's wrong:**  
While the in-game clan system has confirmation GUIs for dangerous actions (disband, demote, war), the Discord bot has no commands for clan management at all. If clan management Discord commands are added in the future, they must include Discord button-based confirmations.

**Fix:** When adding Discord clan commands, use JDA's `Button` and `ActionRow` for confirmation flows.

---

### M-10: Ranked Config anti-abuse same-opponent-cooldown May Be Too Short

| Field | Value |
|-------|-------|
| **Module** | `ranked` |
| **File** | `ranked/src/main/resources/config.yml` |

**What's wrong:**  
`anti-abuse.same-opponent-cooldown: 120` (2 minutes) is relatively short for a competitive ranking system. Two cooperating players could alternate wins every 2 minutes to boost ratings. Most competitive plugins use 10-30 minute cooldowns.

**Fix:** Consider increasing to `600` (10 minutes) or making it configurable with a recommendation in config comments.

---

## 🟢 LOW — Nice to Have / Cleanup

### L-1: ORIGINAL_VS_MODULAR_AUDIT.md Is Stale

| Field | Value |
|-------|-------|
| **File** | `ORIGINAL_VS_MODULAR_AUDIT.md` |

**What's wrong:**  
Many items listed as "❌ AUSENTE" have since been implemented:
- Titles → `TitleManager.java` in cosmetics (30+ titles)
- Finishers → `FinisherHandler.java` in cosmetics (8 types)
- Skins → `SkinManager.java` in cosmetics (weapon + armor skins)
- Elytra Trails → `ElytraTrailHandler.java` in cosmetics (20+ trails)
- Pets → `PetManager.java` in cosmetics (32 types with variants)
- Kit Editor → `KitEditorGui.java` in core
- Daily Rewards → `DailyRewardManager.java` in progression
- Mystery Box → `MysteryBoxGui.java` + `MysteryBoxManager` in cosmetics
- Rankings GUI → `RankingsGui.java` in core (8 categories)
- Settings GUI → `PlayerSettingsGui.java` in core
- Party Games → `PartyGamesManager.java` in party (7 game modes)
- Seasons → `SeasonManager.java` in ranked
- Referrals → `ReferralManager.java` in core
- Tournaments → `TournamentManager.java` in ranked
- Admin GUI → `AdminClanGui.java`, `ProgressionAdminGui.java`, `FFAAdminGui.java`, etc.

**Fix:** Update the audit document to reflect current implementation status, or archive it with a "STALE" warning header.

---

### L-2: Titles Hardcoded Instead of Config-Driven

| Field | Value |
|-------|-------|
| **Module** | `cosmetics` |
| **File** | `cosmetics/src/main/java/com/ethernova/cosmetics/effect/TitleManager.java` |

**What's wrong:**  
All 30+ titles are defined via `reg()` calls in `loadDefaultTitles()` with hardcoded names, prefixes, rarities, and unlock requirements. Server admins cannot add, remove, or modify titles without editing Java code.

**Fix:** Move title definitions to a `titles.yml` config file. Load on startup with hot-reload support.

---

### L-3: FinisherHandler Preview Spawns Real Zombie Entity

| Field | Value |
|-------|-------|
| **Module** | `cosmetics` |
| **File** | `cosmetics/src/main/java/com/ethernova/cosmetics/effect/FinisherHandler.java` lines 57-80 |

**What's wrong:**  
`previewFinisher()` spawns a real `Zombie` entity as a test dummy. While it's invulnerable and silent, it could interact with nearby mob caps, trigger `EntitySpawnEvent` handlers in other plugins, or fail if the world has mob spawning disabled.

**Fix:** Consider using an `ArmorStand` with a zombie head instead, or use a display entity (1.19.4+) that doesn't affect mob caps.

---

### L-4: Combat Module Broadcasts Using Deprecated Bukkit.broadcastMessage()

| Field | Value |
|-------|-------|
| **Module** | `combat` |
| **File** | `combat/src/main/java/com/ethernova/combat/killstreak/KillStreakManager.java` line 507 |

**What's wrong:**  
`Bukkit.broadcastMessage()` is deprecated in Paper 1.21.4. Should use `Bukkit.broadcast(Component)` with Adventure API.

**Fix:** Replace with `Bukkit.broadcast(mini.deserialize("<gray>¡Todos los jugadores cercanos recibirán daño!"))`.

---

### L-5: Multiple Duplicate PlaceholderExpansion Registrations in Clans

| Field | Value |
|-------|-------|
| **Module** | `src` (clans) |
| **Files** | `src/main/java/com/ethernova/clans/placeholder/ClanPlaceholderExpansion.java`, `src/main/java/com/ethernova/clans/hook/PlaceholderHook.java` |

**What's wrong:**  
Two separate PlaceholderExpansion classes exist in the clans module: `ClanPlaceholderExpansion` and `PlaceholderHook`. Both are registered on enable (line 270 of EthernovaClans). This could cause duplicate placeholder registrations or conflicts.

**Fix:** Consolidate into a single PlaceholderExpansion class. Remove the duplicate.

---

### L-6: No Graceful Handling When Optional Modules Are Missing

| Field | Value |
|-------|-------|
| **Module** | All |
| **Pattern** | `ServiceRegistry.get(XxxAPI.class)` calls |

**What's wrong:**  
Cross-module calls via `ServiceRegistry.get()` (e.g., `ServiceRegistry.get(CombatAPI.class)` in FFAListener, PartyGamesManager, etc.) may return null if a module isn't loaded. While some callers null-check, not all do consistently. A missing optional module could cause NullPointerExceptions.

**Fix:** Audit all `ServiceRegistry.get()` callers and ensure null checks. Consider a helper method: `ServiceRegistry.getOptional(Class<T>)` returning `Optional<T>`.

---

### L-7: Config Values Read on Every Call in ClanLevelManager

| Field | Value |
|-------|-------|
| **Module** | `src` (clans) |
| **File** | `src/main/java/com/ethernova/clans/level/ClanLevelManager.java` |

**What's wrong:**  
`getLevel()`, `getXPForNextLevel()`, `getCurrentLevelXP()`, and several other methods call `plugin.getConfigManager().getConfig().getDouble("levels.base-xp", 1000)` and `getDouble("levels.xp-multiplier", 1.5)` on **every invocation**. These are called frequently (on every XP check, level display, GUI render).

**Fix:** Cache `baseXP` and `xpMultiplier` in fields on load/reload. Read from cache instead of config on every call.

---

### L-8: Prestige Prefixes Should Be Loaded from Config

| Field | Value |
|-------|-------|
| **Module** | `progression` |
| **File** | `progression/src/main/java/com/ethernova/progression/prestige/PrestigeManager.java` lines 57-66 |

**What's wrong:**  
Like the title system, prestige prefixes are hardcoded Java arrays. Server admins cannot customize prestige display names, colors, or symbols without modifying source.

**Fix:** Add a `prestige.tiers` section in config with customizable prefix, kills, cost, reward per tier.

---

## 📋 Stale Audit Documents

The following existing audit documents in the workspace contain outdated information and should be updated or archived:

| Document | Status |
|----------|--------|
| `ORIGINAL_VS_MODULAR_AUDIT.md` | **Heavily stale** — lists 15+ systems as "AUSENTE" that now exist |
| `ORIGINAL_VS_MODULAR_FULL_AUDIT.md` | **Partially stale** — some findings corrected, others still valid |
| `GAP_ANALYSIS_REPORT.md` | **Partially stale** — needs re-verification |
| `GUI_AUDIT_REPORT.md` | **Review needed** |
| `BUG_AUDIT_REPORT.md` | **Review needed** |

---

## Summary Table

| Priority | Count | Key Theme |
|----------|-------|-----------|
| 🔴 Critical | 4 | Config/code mismatch, empty stubs called at runtime, war consent |
| 🟡 High | 9 | Missing features, disabled systems, limited Discord, economy gaps |
| 🟠 Medium | 10 | Code quality, legacy color codes, UX polish, balance concerns |
| 🟢 Low | 8 | Stale docs, hardcoded data, performance micro-opts, cleanup |
| **Total** | **31** | |

---

*This audit is research-only. No code changes were made.*
