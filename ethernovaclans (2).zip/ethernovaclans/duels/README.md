# EthernovaDuels

> Sistema de duelos 1v1 con kits, arenas y apuestas.

## Características

- **Duelos 1v1** — Desafía a otros jugadores con solicitudes
- **Kits** — Kits predefinidos con equipamiento y efectos
- **Arenas** — Arenas con spawns configurables, rotación automática
- **Apuestas** — Apuesta monedas en duelos
- **Espectadores** — Modo espectador para ver duelos en curso
- **Estadísticas** — Wins, losses, win rate, rachas por kit y global
- **Leaderboards** — Rankings por kit y globales
- **Cuenta regresiva** — Countdown antes de iniciar
- **Admin** — Crear/eliminar arenas, gestión por GUI

## API

```java
DuelsAPI api = ServiceRegistry.get(DuelsAPI.class);
api.isInDuel(uuid);
api.getMatch(uuid);
api.getDuelWins(uuid);
api.getDuelLosses(uuid);
api.getDuelWinRate(uuid);
api.getActiveMatches();
api.getAvailableKitIds();
api.kitExists("classic");
```

## Comandos

| Comando | Descripción |
|---------|-------------|
| `/duel <jugador>` | Enviar solicitud de duelo |
| `/duel accept` | Aceptar solicitud |
| `/duel decline` | Rechazar solicitud |
| `/duel stats` | Ver estadísticas |
| `/dueladmin` | Panel de administración |

## Placeholders

| Placeholder | Descripción |
|-------------|-------------|
| `%ethernova_duels_wins%` | Victorias |
| `%ethernova_duels_losses%` | Derrotas |
| `%ethernova_duels_winrate%` | Win rate |
| `%ethernova_duels_streak%` | Racha actual |
| `%ethernova_duels_opponent%` | Oponente actual |
