package com.ethernova.duels.listener;

import com.ethernova.core.EthernovaCore;
import com.ethernova.duels.EthernovaDuels;
import com.ethernova.duels.manager.DuelManager;
import com.ethernova.duels.model.DuelMatch;
import com.ethernova.duels.model.DuelState;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.Set;
import java.util.UUID;

public class DuelListener implements Listener {

    private final EthernovaDuels plugin;
    private final EthernovaCore core;

    private static final Set<String> ALLOWED_COMMANDS = Set.of(
            "/duel", "/duelo", "/1v1", "/msg", "/r", "/tell"
    );

    public DuelListener(EthernovaDuels plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;

        Player attacker = resolveAttacker(event);
        if (attacker == null) return;

        UUID victimUuid = victim.getUniqueId();
        UUID attackerUuid = attacker.getUniqueId();

        DuelManager dm = plugin.getDuelManager();

        // Both must be in duel context
        boolean victimInDuel = core.getContextManager().hasContext(victimUuid, "duel");
        boolean attackerInDuel = core.getContextManager().hasContext(attackerUuid, "duel");

        if (!victimInDuel && !attackerInDuel) return;

        DuelMatch victimMatch = dm.getMatch(victimUuid);
        DuelMatch attackerMatch = dm.getMatch(attackerUuid);

        // If one is in duel but attacking someone outside their match, cancel
        if (victimMatch == null || attackerMatch == null || !victimMatch.getMatchId().equals(attackerMatch.getMatchId())) {
            event.setCancelled(true);
            return;
        }

        // During countdown, no damage
        if (victimMatch.getState() == DuelState.COUNTDOWN) {
            event.setCancelled(true);
            return;
        }

        // During ENDED, cancel
        if (victimMatch.getState() == DuelState.ENDED) {
            event.setCancelled(true);
        }
    }

    /**
     * Cancel environmental damage (fire, void, lava, suffocation, fall) during countdown
     * to prevent broken match state.
     */
    @EventHandler(priority = EventPriority.HIGH)
    public void onEnvironmentDamage(EntityDamageEvent event) {
        if (event instanceof EntityDamageByEntityEvent) return; // handled by onDamage
        if (!(event.getEntity() instanceof Player player)) return;

        DuelMatch match = plugin.getDuelManager().getMatch(player.getUniqueId());
        if (match == null) return;

        if (match.getState() == DuelState.COUNTDOWN || match.getState() == DuelState.ENDED) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        UUID victimUuid = victim.getUniqueId();

        DuelManager dm = plugin.getDuelManager();
        DuelMatch match = dm.getMatch(victimUuid);

        if (match == null || match.getState() != DuelState.FIGHTING) return;

        // Prevent item drops and XP
        event.getDrops().clear();
        event.setDroppedExp(0);
        event.setKeepInventory(true);
        event.setKeepLevel(true);

        // Determine winner
        UUID winnerUuid = match.getOpponent(victimUuid);

        // Custom death message
        event.deathMessage(null);

        // Full heal winner
        Player winner = org.bukkit.Bukkit.getPlayer(winnerUuid);
        if (winner != null) {
            winner.setHealth(winner.getMaxHealth());
            winner.setFoodLevel(20);
            winner.setSaturation(20f);
        }

        // End duel
        dm.endDuel(match, winnerUuid);

        // Respawn immediately
        org.bukkit.Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (victim.isDead()) {
                victim.spigot().respawn();
            }
        }, 1L);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();

        // Remove from queue if queued
        if (plugin.getQueueManager().isInQueue(uuid)) {
            plugin.getQueueManager().forceLeaveQueue(uuid);
        }

        DuelManager dm = plugin.getDuelManager();
        DuelMatch match = dm.getMatch(uuid);

        if (match == null || match.getState() == DuelState.ENDED) return;

        // Player disconnected during duel — forfeit
        dm.endDuelByDisconnect(match, uuid);
    }

    /**
     * Restore inventory and state for players who disconnected during an active duel.
     * In lobby mode, sends to lobby instead of restoring old state.
     */
    @EventHandler(priority = EventPriority.HIGH)
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        DuelManager.PendingRestore restore = plugin.getDuelManager().consumePendingRestore(player.getUniqueId());
        if (restore == null) return;

        // Delay restore by a few ticks to ensure player is fully loaded
        org.bukkit.Bukkit.getScheduler().runTaskLater(plugin, () -> {
            // In lobby mode, CorePlayerListener already sends to lobby on join
            // so PendingRestore is only used when lobby is disabled
            var lobby = core.getLobbyManager();
            if (lobby != null && lobby.isEnabled()) return;

            player.getInventory().setContents(restore.inventory() != null ? restore.inventory() : new org.bukkit.inventory.ItemStack[0]);
            player.getInventory().setArmorContents(restore.armor() != null ? restore.armor() : new org.bukkit.inventory.ItemStack[4]);
            if (restore.location() != null) player.teleport(restore.location());
            player.setLevel(restore.level());
            player.setExp(restore.exp());
            player.setWalkSpeed(0.2f);
            player.setGameMode(org.bukkit.GameMode.SURVIVAL);
        }, 5L);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();

        if (!core.getContextManager().hasContext(uuid, "duel")) return;

        // Allow admin bypass
        if (player.hasPermission("ethernova.duels.admin")) return;

        String cmd = event.getMessage().split(" ")[0].toLowerCase();

        // Allow certain commands
        for (String allowed : ALLOWED_COMMANDS) {
            if (cmd.equals(allowed) || cmd.startsWith(allowed + " ")) return;
        }

        event.setCancelled(true);
        plugin.getMessageManager().sendMessage(player, "validation.command-blocked");
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onFoodLevelChange(FoodLevelChangeEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        UUID uuid = player.getUniqueId();

        if (!core.getContextManager().hasContext(uuid, "duel")) return;

        // Keep food level full during duels
        event.setFoodLevel(20);
        player.setSaturation(20f);
    }

    private Player resolveAttacker(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player p) return p;
        if (event.getDamager() instanceof Projectile proj && proj.getShooter() instanceof Player p) return p;
        return null;
    }
}
