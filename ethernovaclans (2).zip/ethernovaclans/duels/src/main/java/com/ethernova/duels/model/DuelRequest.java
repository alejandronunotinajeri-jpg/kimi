package com.ethernova.duels.model;

import java.util.UUID;

public record DuelRequest(
        UUID senderUuid,
        String senderName,
        UUID targetUuid,
        String kit,
        double betAmount,
        long expiresAt
) {
    public boolean isExpired() {
        return System.currentTimeMillis() >= expiresAt;
    }
}
