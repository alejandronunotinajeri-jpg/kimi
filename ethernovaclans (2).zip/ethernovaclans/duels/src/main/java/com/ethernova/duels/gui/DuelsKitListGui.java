package com.ethernova.duels.gui;

import com.ethernova.core.gui.CoreGui;
import com.ethernova.duels.EthernovaDuels;
import com.ethernova.duels.model.DuelKit;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Admin GUI — lists all duel kits with delete / create from inventory.
 */
public class DuelsKitListGui extends CoreGui {

    private final EthernovaDuels plugin;

    public DuelsKitListGui(EthernovaDuels plugin, Player player) {
        super(plugin.getCore(), player);
        this.plugin = plugin;
    }

    public void open() {
        openInventory("<gradient:#ED213A:#93291E>⚔ Kits de Duelos</gradient>", 54);
    }

    @Override
    protected void populateItems() {
        // Header
        setItem(4, createItem(Material.DIAMOND_CHESTPLATE,
                "<gold><bold>⚔ Gestión de Kits",
                List.of("", "<gray>Administra todos los kits de duelos", "")));

        var kits = plugin.getKitManager().getAllKits();
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};
        int idx = 0;

        for (DuelKit kit : kits) {
            if (idx >= slots.length) break;

            List<String> lore = new ArrayList<>();
            lore.add("");
            lore.add("<dark_gray>▎ <gray>ID: <white>" + kit.getId());

            // Armor preview
            if (kit.getArmor() != null) {
                lore.add("<dark_gray>▎ <yellow>Armadura:");
                for (int i = kit.getArmor().length - 1; i >= 0; i--) {
                    if (kit.getArmor()[i] != null) {
                        lore.add("<dark_gray>▎   <gray>▸ <white>" + formatMat(kit.getArmor()[i].getType()));
                    }
                }
            }

            // Main items preview
            if (kit.getInventory() != null) {
                lore.add("<dark_gray>▎ <yellow>Items:");
                int shown = 0;
                for (var item : kit.getInventory()) {
                    if (item != null && !item.getType().isAir() && shown < 4) {
                        lore.add("<dark_gray>▎   <gray>▸ <white>" + formatMat(item.getType()) + " x" + item.getAmount());
                        shown++;
                    }
                }
                int total = 0;
                for (var item : kit.getInventory()) {
                    if (item != null && !item.getType().isAir()) total++;
                }
                if (total > 4) lore.add("<dark_gray>▎   <gray>... y " + (total - 4) + " más");
            }

            if (!kit.getEffects().isEmpty()) {
                lore.add("<dark_gray>▎ <yellow>Efectos: <white>" + kit.getEffects().size());
            }

            lore.add("");
            lore.add("<dark_gray>▎ <red>Shift+Click → Eliminar kit");

            setItem(slots[idx], createItem(kit.getIcon(), "<gold>" + kit.getName(), lore));
            slotActions.put(slots[idx], "KIT:" + kit.getId());
            idx++;
        }

        if (kits.isEmpty()) {
            setItem(22, createItem(Material.BARRIER, "<red>No hay kits",
                    List.of("", "<gray>Usa el botón de crear")));
        }

        // Create kit from inventory button
        setItem(48, createItem(Material.EMERALD_BLOCK,
                "<green><bold>+ Crear Kit desde Inventario",
                List.of("",
                        "<dark_gray>▎ <gray>Equípate la armadura e items",
                        "<dark_gray>▎ <gray>que quieras para el kit y",
                        "<dark_gray>▎ <gray>haz click para crearlo.",
                        "",
                        "<dark_gray>▎ <yellow>Click para crear")));
        slotActions.put(48, "CREATE");

        // Back
        setItem(45, createItem(Material.ARROW, "<gray>← Volver"));
        slotActions.put(45, "BACK");

        // Close
        setItem(49, createItem(Material.BARRIER, "<red>Cerrar"));
        slotActions.put(49, "CLOSE");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.equals("CREATE")) {
            int count = plugin.getKitManager().getKitIds().size() + 1;
            String id = "custom_" + count;
            while (plugin.getKitManager().kitExists(id)) {
                count++;
                id = "custom_" + count;
            }
            String name = "<yellow>Kit #" + count;

            boolean created = plugin.getKitManager().createKitFromPlayer(id, name, player);
            if (created) {
                player.sendMessage(mini.deserialize(
                        "<green>✔ Kit '<white>" + id + "<green>' creado desde tu inventario actual."));
                playSound("success");
            } else {
                player.sendMessage(mini.deserialize("<red>✘ Error creando el kit."));
                playSound("error");
            }
            refresh();
            return true;
        }
        if (action.equals("BACK")) {
            playSound("click");
            player.closeInventory();
            Bukkit.getScheduler().runTaskLater(plugin, () -> new DuelsAdminGui(plugin, player).open(), 1L);
            return true;
        }
        if (action.startsWith("KIT:")) {
            String kitId = action.substring(4);
            if (event.isShiftClick()) {
                boolean deleted = plugin.getKitManager().deleteKit(kitId);
                if (deleted) {
                    player.sendMessage(mini.deserialize("<red>✘ Kit '" + kitId + "' eliminado."));
                    playSound("click");
                } else {
                    player.sendMessage(mini.deserialize("<red>Kit no encontrado."));
                    playSound("error");
                }
                refresh();
            }
            return true;
        }
        return false;
    }

    private void refresh() {
        player.closeInventory();
        Bukkit.getScheduler().runTaskLater(plugin, this::open, 1L);
    }

    private String formatMat(Material mat) {
        String name = mat.name().toLowerCase().replace("_", " ");
        StringBuilder sb = new StringBuilder();
        for (String word : name.split(" ")) {
            if (!word.isEmpty()) sb.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1)).append(" ");
        }
        return sb.toString().trim();
    }
}
