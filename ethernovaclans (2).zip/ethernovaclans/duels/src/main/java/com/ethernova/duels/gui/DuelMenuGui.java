package com.ethernova.duels.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.CoreGui;
import com.ethernova.duels.EthernovaDuels;
import com.ethernova.duels.message.MessageManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.List;
import java.util.UUID;

/**
 * Main /duel menu — allows players to queue for matchmaking,
 * invite a specific player, or view their stats.
 */
public class DuelMenuGui extends CoreGui {

    private final EthernovaDuels plugin;

    public DuelMenuGui(EthernovaCore core, EthernovaDuels plugin, Player player) {
        super(core, player);
        this.plugin = plugin;
    }

    private MessageManager mm() { return plugin.getMessageManager(); }

    public void open() {
        openInventory("<gradient:#ff6b6b:#ffd93d><bold>⚔ Menú de Duelos</bold></gradient>", 45);
    }

    @Override
    protected void populateItems() {
        // ── Header ──
        setItem(4, createItem(Material.IRON_SWORD,
                "<gradient:#ff6b6b:#ffd93d><bold>⚔ Duelos</bold></gradient>",
                List.of("",
                        "<dark_gray>▎ <gray>Reta a otros jugadores",
                        "<dark_gray>▎ <gray>en combates 1v1.",
                        "")));

        // ── Row 2: Main actions ──
        int queueTotal = plugin.getQueueManager().getTotalQueueSize();
        setItem(20, createItem(Material.IRON_SWORD,
                "<gradient:#ff4444:#ff8800><bold>⚔ Matchmaking</bold></gradient>",
                List.of(
                        "",
                        "<dark_gray>▎ <gray>Entra a una cola automática y",
                        "<dark_gray>▎ <gray>pelea contra un rival aleatorio.",
                        "",
                        "<dark_gray>▎ <gray>Jugadores en cola: <white>" + queueTotal,
                        "",
                        "<dark_gray>▎ <yellow>▶ Click para seleccionar kit"
                )));
        slotActions.put(20, "MATCHMAKING");

        setItem(22, createPlayerHead(player,
                "<gradient:#55ff55:#55ffff><bold>✉ Invitar Jugador</bold></gradient>",
                List.of(
                        "",
                        "<dark_gray>▎ <gray>Reta a un jugador específico",
                        "<dark_gray>▎ <gray>a un duelo 1v1.",
                        "",
                        "<dark_gray>▎ <gray>Usa: <white>/duel invite <nombre>",
                        "",
                        "<dark_gray>▎ <yellow>▶ Click para ver jugadores online"
                )));
        slotActions.put(22, "INVITE");

        var stats = plugin.getStatsManager().getCachedStats(player.getUniqueId());
        int wins = stats != null ? stats.wins() : 0;
        int losses = stats != null ? stats.losses() : 0;
        int bestStreak = stats != null ? stats.bestStreak() : 0;
        setItem(24, createItem(Material.BOOK,
                "<gradient:#aaaaff:#ff55ff><bold>📊 Estadísticas</bold></gradient>",
                List.of(
                        "",
                        "<dark_gray>▎ <gray>Victorias: <green>" + wins,
                        "<dark_gray>▎ <gray>Derrotas: <red>" + losses,
                        "<dark_gray>▎ <gray>Mejor racha: <gold>" + bestStreak,
                        "",
                        "<dark_gray>▎ <yellow>▶ Click para ver detalles"
                )));
        slotActions.put(24, "STATS");

        // ── Info row ──
        int activeDuels = plugin.getDuelManager().getActiveMatches().size();
        setItem(31, createItem(Material.CLOCK,
                "<yellow>ℹ Información",
                List.of("",
                        "<dark_gray>▎ <gray>Duelos activos: <white>" + activeDuels,
                        "<dark_gray>▎ <gray>En cola: <white>" + queueTotal,
                        "")));

        // ── Back ──
        setItem(36, createItem(Material.ARROW, "<red>← Volver", 
                List.of("<gray>Regresa al menú anterior")));
        slotActions.put(36, "BACK");

        // ── Close ──
        setItem(40, createItem(Material.BARRIER, "<red>Cerrar"));
        slotActions.put(40, "CLOSE");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        switch (action) {
            case "MATCHMAKING" -> {
                playSound("click");
                player.closeInventory();
                core.getGuiManager().unregisterGui(player.getUniqueId());
                new QueueKitGui(core, plugin, player).open();
                return true;
            }
            case "INVITE" -> {
                playSound("click");
                player.closeInventory();
                core.getGuiManager().unregisterGui(player.getUniqueId());
                new DuelInviteGui(core, plugin, player).open();
                return true;
            }
            case "STATS" -> {
                playSound("click");
                player.closeInventory();
                core.getGuiManager().unregisterGui(player.getUniqueId());
                new DuelStatsGui(core, plugin, player, player.getUniqueId(), player.getName()).open();
                return true;
            }
            case "BACK" -> {
                playSound("click");
                player.closeInventory();
                return true;
            }
        }
        return false;
    }

    // ── Helper: player head ──
    private ItemStack createPlayerHead(Player headPlayer, String displayName, List<String> lore) {
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) skull.getItemMeta();
        meta.setOwningPlayer(headPlayer);
        meta.displayName(mini.deserialize(displayName));
        meta.lore(lore.stream().map(mini::deserialize).toList());
        skull.setItemMeta(meta);
        return skull;
    }
}
