package com.ethernova.duels.model;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;

import java.util.List;

public class DuelKit {

    private final String id;
    private final String name;
    private final Material icon;
    private final List<String> description;
    private final ItemStack[] armor;
    private final ItemStack[] inventory;
    private final List<PotionEffect> effects;
    private final boolean noNaturalRegen;

    public DuelKit(String id, String name, Material icon, List<String> description,
                   ItemStack[] armor, ItemStack[] inventory, List<PotionEffect> effects,
                   boolean noNaturalRegen) {
        this.id = id;
        this.name = name;
        this.icon = icon;
        this.description = description;
        this.armor = armor;
        this.inventory = inventory;
        this.effects = effects;
        this.noNaturalRegen = noNaturalRegen;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public Material getIcon() { return icon; }
    public List<String> getDescription() { return description; }
    public ItemStack[] getArmor() { return armor; }
    public ItemStack[] getInventory() { return inventory; }
    public List<PotionEffect> getEffects() { return effects; }
    public boolean isNoNaturalRegen() { return noNaturalRegen; }

    public void applyTo(org.bukkit.entity.Player player) {
        player.getInventory().clear();
        player.getInventory().setArmorContents(armor.clone());

        // Apply cosmetic armor trims if the service is available
        com.ethernova.core.service.ArmorTrimService trimService =
                com.ethernova.core.service.ServiceRegistry.get(com.ethernova.core.service.ArmorTrimService.class);
        if (trimService != null) {
            org.bukkit.inventory.ItemStack[] trimmed = trimService.applyTrims(
                    player.getUniqueId(), player.getInventory().getArmorContents());
            player.getInventory().setArmorContents(trimmed);
        }

        for (int i = 0; i < inventory.length; i++) {
            if (inventory[i] != null) {
                player.getInventory().setItem(i, inventory[i].clone());
            }
        }
        player.getActivePotionEffects().forEach(e -> player.removePotionEffect(e.getType()));
        for (PotionEffect effect : effects) {
            player.addPotionEffect(effect);
        }
        player.setHealth(player.getMaxHealth());
        player.setFoodLevel(20);
        player.setSaturation(20f);
    }
}
