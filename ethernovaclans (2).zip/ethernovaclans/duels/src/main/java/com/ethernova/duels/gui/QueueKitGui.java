package com.ethernova.duels.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.CoreGui;
import com.ethernova.duels.EthernovaDuels;
import com.ethernova.duels.message.MessageManager;
import com.ethernova.duels.model.DuelKit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Kit selection GUI for matchmaking queue.
 * Player picks a kit → enters queue for that kit.
 */
public class QueueKitGui extends CoreGui {

    private final EthernovaDuels plugin;

    public QueueKitGui(EthernovaCore core, EthernovaDuels plugin, Player player) {
        super(core, player);
        this.plugin = plugin;
    }

    private MessageManager mm() { return plugin.getMessageManager(); }

    public void open() {
        openInventory("<gradient:#55FF55:#FFAA00>⚔ Selecciona Kit</gradient>", 36);
    }

    @Override
    protected void populateItems() {
        // Header
        setItem(4, createItem(Material.SMITHING_TABLE, "<gradient:#55FF55:#FFAA00><bold>Selecciona Kit</bold></gradient>",
                List.of("", "<dark_gray>▎ <gray>Elige un kit para la cola", "")));

        Collection<DuelKit> kits = plugin.getKitManager().getAllKits();
        int[] slots = {10, 11, 12, 13, 14, 15, 16};
        int index = 0;

        for (DuelKit kit : kits) {
            if (index >= slots.length) break;

            int slot = slots[index++];
            int queueSize = plugin.getQueueManager().getQueueSize(kit.getId());

            List<String> lore = new ArrayList<>();
            lore.add("");
            for (String line : kit.getDescription()) {
                lore.add("<dark_gray>▎ " + line);
            }
            lore.add("");
            lore.add("<dark_gray>▎ <gray>En cola: <white>" + queueSize + " jugador(es)");
            lore.add("");
            lore.add("<dark_gray>▎ <yellow>Click para entrar a la cola");

            ItemStack item = createItem(kit.getIcon(), "<gold>" + kit.getName(), lore);
            setItem(slot, item);
            slotActions.put(slot, "QUEUE_" + kit.getId());
        }

        // Close button
        setItem(31, createItem(Material.BARRIER, "<red>Cancelar"));
        slotActions.put(31, "CLOSE");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.startsWith("QUEUE_")) {
            String kitId = action.substring(6);
            playSound("click");
            player.closeInventory();
            core.getGuiManager().unregisterGui(player.getUniqueId());

            // Enter queue for selected kit
            plugin.getQueueManager().joinQueue(player, kitId);
            return true;
        }
        return false;
    }
}
