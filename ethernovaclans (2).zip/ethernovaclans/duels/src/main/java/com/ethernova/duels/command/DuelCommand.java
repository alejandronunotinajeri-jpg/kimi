package com.ethernova.duels.command;

import com.ethernova.duels.EthernovaDuels;
import com.ethernova.duels.gui.DuelGui;
import com.ethernova.duels.gui.DuelMenuGui;
import com.ethernova.duels.gui.DuelStatsGui;
import com.ethernova.duels.gui.QueueKitGui;
import com.ethernova.duels.manager.DuelManager;
import com.ethernova.duels.message.MessageManager;
import com.ethernova.duels.model.DuelMatch;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

public class DuelCommand implements TabExecutor {

    private final EthernovaDuels plugin;
    private final MiniMessage mini = MiniMessage.miniMessage();

    public DuelCommand(EthernovaDuels plugin) {
        this.plugin = plugin;
    }

    private MessageManager mm() { return plugin.getMessageManager(); }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            mm().sendMessage(sender, "general.only-players");
            return true;
        }

        if (!player.hasPermission("ethernova.duels.use")) {
            mm().sendMessage(player, "general.no-permission");
            return true;
        }

        if (args.length == 0) {
            new DuelMenuGui(plugin.getCore(), plugin, player).open();
            return true;
        }

        String sub = args[0].toLowerCase();

        return switch (sub) {
            case "accept", "aceptar" -> {
                plugin.getDuelManager().acceptRequest(player);
                yield true;
            }
            case "deny", "decline", "rechazar" -> {
                plugin.getDuelManager().declineRequest(player);
                yield true;
            }
            case "stats", "estadisticas" -> {
                handleStats(player, args);
                yield true;
            }
            case "queue", "cola" -> {
                handleQueue(player, args);
                yield true;
            }
            case "spectate", "spec", "observar" -> {
                handleSpectate(player, args);
                yield true;
            }
            case "invite", "invitar", "retar" -> {
                handleInvite(player, args);
                yield true;
            }
            case "help", "ayuda" -> {
                sendHelp(player);
                yield true;
            }
            default -> {
                handleChallenge(player, args);
                yield true;
            }
        };
    }

    private void handleChallenge(Player player, String[] args) {
        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            mm().sendMessage(player, "general.player-not-found");
            return;
        }

        String kit = "classic";
        double bet = 0;

        if (args.length >= 2) {
            if (plugin.getKitManager().kitExists(args[1])) {
                kit = args[1].toLowerCase();
            } else {
                try {
                    bet = Double.parseDouble(args[1]);
                } catch (NumberFormatException e) {
                    new DuelGui(plugin.getCore(), plugin, player, target.getUniqueId(), target.getName()).open();
                    return;
                }
            }
        }

        if (args.length >= 3) {
            try {
                bet = Double.parseDouble(args[2]);
            } catch (NumberFormatException ignored) {}
        }

        // Sanitize bet: disallow negative, NaN, Infinity
        if (bet < 0 || Double.isNaN(bet) || Double.isInfinite(bet)) bet = 0;

        plugin.getDuelManager().sendRequest(player, target, kit, bet);
    }

    private void handleStats(Player player, String[] args) {
        UUID targetUuid;
        String targetName;

        if (args.length >= 2) {
            Player target = Bukkit.getPlayer(args[1]);
            if (target == null) {
                mm().sendMessage(player, "general.player-not-found");
                return;
            }
            targetUuid = target.getUniqueId();
            targetName = target.getName();
        } else {
            targetUuid = player.getUniqueId();
            targetName = player.getName();
        }

        new DuelStatsGui(plugin.getCore(), plugin, player, targetUuid, targetName).open();
    }

    private void handleSpectate(Player player, String[] args) {
        if (!player.hasPermission("ethernova.duels.spectate")) {
            mm().sendMessage(player, "general.no-permission");
            return;
        }

        if (args.length < 2) {
            mm().sendMessage(player, "general.player-not-found");
            return;
        }

        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            mm().sendMessage(player, "general.player-not-found");
            return;
        }

        DuelManager duelManager = plugin.getDuelManager();
        DuelMatch match = duelManager.getMatch(target.getUniqueId());
        if (match == null) {
            mm().sendMessage(player, "validation.target-in-duel");
            return;
        }

        duelManager.addSpectator(player, match);
    }

    private void handleQueue(Player player, String[] args) {
        // /duel queue → open kit selection GUI for queue
        // /duel queue <kit> → queue directly for that kit
        // /duel queue cancel → leave queue
        if (args.length >= 2) {
            String sub = args[1].toLowerCase();
            if (sub.equals("cancel") || sub.equals("cancelar") || sub.equals("leave") || sub.equals("salir")) {
                plugin.getQueueManager().leaveQueue(player);
                return;
            }
            // Queue for specific kit
            if (plugin.getKitManager().kitExists(sub)) {
                plugin.getQueueManager().joinQueue(player, sub);
                return;
            }
        }
        // No kit specified → open kit selection GUI for queue
        new QueueKitGui(plugin.getCore(), plugin, player).open();
    }

    /**
     * /duel invite <name> [kit|bet]
     * Shortcut for challenging a specific player to a duel.
     */
    private void handleInvite(Player player, String[] args) {
        if (args.length < 2) {
            // No name specified → open invite GUI
            new com.ethernova.duels.gui.DuelInviteGui(plugin.getCore(), plugin, player).open();
            return;
        }

        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            mm().sendMessage(player, "general.player-not-found");
            return;
        }

        String kit = "classic";
        double bet = 0;

        if (args.length >= 3) {
            if (plugin.getKitManager().kitExists(args[2])) {
                kit = args[2].toLowerCase();
            } else {
                try {
                    bet = Double.parseDouble(args[2]);
                } catch (NumberFormatException e) {
                    // Open kit selection GUI for this target
                    new DuelGui(plugin.getCore(), plugin, player, target.getUniqueId(), target.getName()).open();
                    return;
                }
            }
        }

        if (args.length >= 4) {
            try {
                bet = Double.parseDouble(args[3]);
            } catch (NumberFormatException ignored) {}
        }

        if (bet < 0 || Double.isNaN(bet) || Double.isInfinite(bet)) bet = 0;

        plugin.getDuelManager().sendRequest(player, target, kit, bet);
    }

    private void sendHelp(Player player) {
        mm().sendMessage(player, "help.header");
        mm().sendMessage(player, "help.duel");
        mm().sendMessage(player, "help.accept");
        mm().sendMessage(player, "help.deny");
        mm().sendMessage(player, "help.stats");
        mm().sendMessage(player, "help.spectate");
        mm().sendMessage(player, "help.footer");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) return Collections.emptyList();

        if (args.length == 1) {
            List<String> completions = new ArrayList<>();
            completions.addAll(List.of("accept", "deny", "stats", "queue", "spectate", "invite", "help"));
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!p.equals(sender)) {
                    completions.add(p.getName());
                }
            }
            return filterCompletions(completions, args[0]);
        }

        if (args.length == 2) {
            String sub = args[0].toLowerCase();
            if (sub.equals("stats") || sub.equals("spectate") || sub.equals("spec") || sub.equals("invite") || sub.equals("invitar") || sub.equals("retar")) {
                return filterCompletions(
                        Bukkit.getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toList()),
                        args[1]
                );
            }
            if (sub.equals("queue") || sub.equals("cola")) {
                List<String> opts = new ArrayList<>(plugin.getKitManager().getKitIds());
                opts.add("cancel");
                return filterCompletions(opts, args[1]);
            }
            if (Bukkit.getPlayer(args[0]) != null) {
                return filterCompletions(new ArrayList<>(plugin.getKitManager().getKitIds()), args[1]);
            }
        }

        if (args.length == 3) {
            String sub = args[0].toLowerCase();
            if (sub.equals("invite") || sub.equals("invitar") || sub.equals("retar")) {
                List<String> opts = new ArrayList<>(plugin.getKitManager().getKitIds());
                opts.addAll(List.of("100", "500", "1000", "5000"));
                return filterCompletions(opts, args[2]);
            }
            if (Bukkit.getPlayer(args[0]) != null) {
                return List.of("100", "500", "1000", "5000");
            }
        }

        if (args.length == 4) {
            String sub = args[0].toLowerCase();
            if (sub.equals("invite") || sub.equals("invitar") || sub.equals("retar")) {
                return filterCompletions(List.of("100", "500", "1000", "5000"), args[3]);
            }
        }

        return Collections.emptyList();
    }

    private List<String> filterCompletions(List<String> options, String input) {
        String lower = input.toLowerCase();
        return options.stream()
                .filter(s -> s.toLowerCase().startsWith(lower))
                .sorted()
                .collect(Collectors.toList());
    }
}
