package com.ethernova.duels.gui;

import com.ethernova.core.gui.CoreGui;
import com.ethernova.duels.EthernovaDuels;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Admin GUI for EthernovaDuels — full in-game configuration.
 * Permission: ethernova.duels.admin
 */
public class DuelsAdminGui extends CoreGui {

    private final EthernovaDuels plugin;

    public DuelsAdminGui(EthernovaDuels plugin, Player player) {
        super(plugin.getCore(), player);
        this.plugin = plugin;
    }

    public void open() {
        openInventory("<gradient:#ED213A:#93291E>⚙ Duels Admin</gradient>", 54);
    }

    @Override
    protected void populateItems() {
        // ═══ Back ═══
        setItem(45, createItem(Material.ARROW, "<gray>← Volver"));
        slotActions.put(45, "BACK");

        // ═══ Header ═══
        setItem(4, createItem(Material.IRON_SWORD,
                "<gold><bold>⚙ Configuración de Duelos",
                List.of("<gray>Gestiona todos los ajustes",
                        "<gray>del sistema de duelos")));

        // ═══ Row 1: General Settings ═══
        setItem(10, createItem(Material.RED_STAINED_GLASS_PANE, "<red><bold>General"));

        setItem(11, numberItem(Material.CLOCK, "Request Timeout", "request-timeout", "seg"));
        slotActions.put(11, "INT:request-timeout:5:300");

        setItem(12, numberItem(Material.HOPPER, "Request Cooldown", "request-cooldown", "ms"));
        slotActions.put(12, "INT:request-cooldown:0:120000");

        setItem(13, numberItem(Material.TNT, "Countdown", "countdown-seconds", "seg"));
        slotActions.put(13, "INT:countdown-seconds:1:30");

        setItem(14, numberItem(Material.BARRIER, "Max Duración", "max-duration", "seg"));
        slotActions.put(14, "INT:max-duration:0:1800");

        // ═══ Row 2: Betting ═══
        setItem(19, createItem(Material.YELLOW_STAINED_GLASS_PANE,
                "<yellow><bold>Apuestas"));

        setItem(20, toggleItem("Apuestas Habilitadas", "betting.enabled"));
        slotActions.put(20, "TOGGLE:betting.enabled");

        setItem(21, doubleItem(Material.GOLD_NUGGET, "Min Apuesta", "betting.min-bet", "$"));
        slotActions.put(21, "DOUBLE:betting.min-bet:0.0:100000.0");

        setItem(22, doubleItem(Material.GOLD_INGOT, "Max Apuesta", "betting.max-bet", "$"));
        slotActions.put(22, "DOUBLE:betting.max-bet:0.0:1000000.0");

        // ═══ Row 2 continued: Language ═══
        setItem(24, createItem(Material.WRITABLE_BOOK,
                "<yellow>Idioma: <white>" + plugin.getConfig().getString("general.language", "es"),
                List.of("<yellow>Click para cambiar")));
        slotActions.put(24, "CYCLE_LANG");

        // ═══ Row 3: Arenas ═══
        setItem(28, createItem(Material.LIME_STAINED_GLASS_PANE, "<green><bold>Arenas"));

        var arenaSection = plugin.getConfig().getConfigurationSection("arenas");
        Set<String> arenaKeys = arenaSection != null ? arenaSection.getKeys(false) : Set.of();

        List<String> arenaLore = buildArenaLore(arenaKeys);
        arenaLore.add("");
        arenaLore.add("<yellow>▶ Click para gestionar arenas");
        setItem(29, createItem(Material.GRASS_BLOCK,
                "<green>Arenas Configuradas: <white>" + arenaKeys.size(),
                arenaLore));
        slotActions.put(29, "ARENA_LIST");

        // ═══ Row 3 continued: Kits ═══
        setItem(32, createItem(Material.PURPLE_STAINED_GLASS_PANE, "<light_purple><bold>Kits"));

        var kitsSection = plugin.getConfig().getConfigurationSection("kits");
        Set<String> kitKeys = kitsSection != null ? kitsSection.getKeys(false) : Set.of();

        List<String> kitLore = buildKitLore(kitKeys);
        kitLore.add("");
        kitLore.add("<yellow>▶ Click para gestionar kits");
        setItem(33, createItem(Material.DIAMOND_CHESTPLATE,
                "<light_purple>Kits Configurados: <white>" + kitKeys.size(),
                kitLore));
        slotActions.put(33, "KIT_LIST");

        // ═══ Row 4: Actions ═══
        setItem(38, createItem(Material.COMMAND_BLOCK,
                "<green>⟳ Recargar Config",
                List.of("<gray>Recarga config.yml, arenas y kits")));
        slotActions.put(38, "RELOAD");

        setItem(40, createItem(Material.BOOK, "<aqua>ℹ Información",
                List.of("<gray>Plugin: <white>EthernovaDuels",
                        "<gray>Arenas: <white>" + arenaKeys.size(),
                        "<gray>Kits: <white>" + kitKeys.size(),
                        "<gray>Duelos activos: <white>" + plugin.getDuelManager().getActiveMatches().size())));

        setItem(49, createItem(Material.BARRIER, "<red>Cerrar"));
        slotActions.put(49, "CLOSE");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.startsWith("TOGGLE:")) {
            String path = action.substring(7);
            plugin.getConfig().set(path, !plugin.getConfig().getBoolean(path, false));
            plugin.saveConfig();
            refresh();
            return true;
        }
        if (action.startsWith("INT:")) {
            String[] parts = action.substring(4).split(":");
            adjustInt(parts[0], event, Integer.parseInt(parts[1]), Integer.parseInt(parts[2]));
            return true;
        }
        if (action.startsWith("DOUBLE:")) {
            String[] parts = action.substring(7).split(":");
            adjustDouble(parts[0], event, Double.parseDouble(parts[1]), Double.parseDouble(parts[2]));
            return true;
        }
        return switch (action) {
            case "CYCLE_LANG" -> {
                String current = plugin.getConfig().getString("general.language", "es");
                plugin.getConfig().set("general.language", "es".equals(current) ? "en" : "es");
                plugin.saveConfig();
                refresh();
                yield true;
            }
            case "ARENA_LIST" -> {
                playSound("click");
                player.closeInventory();
                Bukkit.getScheduler().runTaskLater(plugin, () -> new DuelsArenaListGui(plugin, player).open(), 1L);
                yield true;
            }
            case "KIT_LIST" -> {
                playSound("click");
                player.closeInventory();
                Bukkit.getScheduler().runTaskLater(plugin, () -> new DuelsKitListGui(plugin, player).open(), 1L);
                yield true;
            }
            case "RELOAD" -> {
                plugin.reloadConfig();
                plugin.getKitManager().loadKits();
                plugin.getArenaManager().loadArenas();
                plugin.getMessageManager().load();
                playSound("success");
                player.closeInventory();
                player.sendMessage(mini.deserialize("<green>✔ Configuración de Duels recargada."));
                yield true;
            }
            case "BACK" -> {
                playSound("click");
                player.closeInventory();
                Bukkit.getScheduler().runTaskLater(plugin, () -> player.performCommand("ethernova admin"), 2L);
                yield true;
            }
            default -> false;
        };
    }

    // ═══════════════ Helpers ═══════════════

    private void adjustInt(String path, InventoryClickEvent event, int min, int max) {
        int current = plugin.getConfig().getInt(path, 0);
        int delta = event.isShiftClick() ? 10 : 1;
        if (event.isRightClick()) delta = -delta;
        plugin.getConfig().set(path, Math.max(min, Math.min(max, current + delta)));
        plugin.saveConfig();
        refresh();
    }

    private void adjustDouble(String path, InventoryClickEvent event, double min, double max) {
        double current = plugin.getConfig().getDouble(path, 0);
        double delta = event.isShiftClick() ? (event.isRightClick() ? -100.0 : 100.0) : (event.isRightClick() ? -10.0 : 10.0);
        double newVal = Math.round(Math.max(min, Math.min(max, current + delta)) * 100.0) / 100.0;
        plugin.getConfig().set(path, newVal);
        plugin.saveConfig();
        refresh();
    }

    private void refresh() {
        playSound("click");
        player.closeInventory();
        Bukkit.getScheduler().runTaskLater(plugin, this::open, 1L);
    }

    private ItemStack toggleItem(String name, String path) {
        boolean val = plugin.getConfig().getBoolean(path, false);
        return createItem(val ? Material.LIME_DYE : Material.GRAY_DYE,
                (val ? "<green>✔ " : "<red>✘ ") + name,
                List.of("<gray>Estado: " + (val ? "<green>Activado" : "<red>Desactivado"),
                        "", "<yellow>Click para " + (val ? "desactivar" : "activar")));
    }

    private ItemStack numberItem(Material mat, String name, String path, String unit) {
        int val = plugin.getConfig().getInt(path, 0);
        String suffix = unit.isEmpty() ? "" : " " + unit;
        return createItem(mat, "<gold>" + name + ": <white>" + val + suffix,
                List.of("<gray>Click izq: <green>+1", "<gray>Click der: <red>-1",
                        "<gray>Shift+Click: <yellow>±10"));
    }

    private ItemStack doubleItem(Material mat, String name, String path, String unit) {
        double val = plugin.getConfig().getDouble(path, 0);
        String suffix = unit.isEmpty() ? "" : " " + unit;
        return createItem(mat, "<gold>" + name + ": <white>" + String.format("%.0f", val) + suffix,
                List.of("<gray>Click izq: <green>+10", "<gray>Click der: <red>-10",
                        "<gray>Shift+Click: <yellow>±100"));
    }

    private List<String> buildArenaLore(Set<String> arenaKeys) {
        List<String> lore = new ArrayList<>();
        lore.add("<gray>Arenas registradas:");
        int count = 0;
        for (String name : arenaKeys) {
            if (count >= 8) { lore.add("<gray>  ... y " + (arenaKeys.size() - 8) + " más"); break; }
            lore.add("<gray>  • <white>" + name);
            count++;
        }
        if (arenaKeys.isEmpty()) lore.add("<red>  Ninguna arena configurada");
        lore.add("");
        lore.add("<dark_gray>Usa /dueladmin arena para gestionar");
        return lore;
    }

    private List<String> buildKitLore(Set<String> kitKeys) {
        List<String> lore = new ArrayList<>();
        lore.add("<gray>Kits registrados:");
        for (String name : kitKeys) {
            String displayName = plugin.getConfig().getString("kits." + name + ".name", name);
            lore.add("<gray>  • <white>" + displayName);
        }
        if (kitKeys.isEmpty()) lore.add("<red>  Ningún kit configurado");
        return lore;
    }
}
