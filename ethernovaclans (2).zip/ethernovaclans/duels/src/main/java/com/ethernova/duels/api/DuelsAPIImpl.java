package com.ethernova.duels.api;

import com.ethernova.duels.EthernovaDuels;
import com.ethernova.duels.manager.DuelStatsManager;
import com.ethernova.duels.model.DuelMatch;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * Implementation of DuelsAPI. Registered with ServiceRegistry on enable.
 */
public class DuelsAPIImpl implements DuelsAPI {

    private final EthernovaDuels plugin;

    public DuelsAPIImpl(EthernovaDuels plugin) {
        this.plugin = plugin;
    }

    // ═══════════════ Match State ═══════════════

    @Override
    public boolean isInDuel(UUID uuid) {
        return plugin.getDuelManager().isInDuel(uuid);
    }

    @Override
    public DuelMatch getMatch(UUID playerUuid) {
        return plugin.getDuelManager().getMatch(playerUuid);
    }

    @Override
    public Collection<DuelMatch> getActiveMatches() {
        return plugin.getDuelManager().getActiveMatches();
    }

    // ═══════════════ Stats (Sync Cache) ═══════════════

    @Override
    public int getDuelWins(UUID uuid) {
        DuelStatsManager.CachedDuelStats stats = plugin.getStatsManager().getCachedStats(uuid);
        return stats != null ? stats.wins() : 0;
    }

    @Override
    public int getDuelLosses(UUID uuid) {
        DuelStatsManager.CachedDuelStats stats = plugin.getStatsManager().getCachedStats(uuid);
        return stats != null ? stats.losses() : 0;
    }

    @Override
    public double getDuelWinRate(UUID uuid) {
        DuelStatsManager.CachedDuelStats stats = plugin.getStatsManager().getCachedStats(uuid);
        return stats != null ? stats.winRate() : 0.0;
    }

    @Override
    public int getDuelBestStreak(UUID uuid) {
        DuelStatsManager.CachedDuelStats stats = plugin.getStatsManager().getCachedStats(uuid);
        return stats != null ? stats.bestStreak() : 0;
    }

    // ═══════════════ Stats (Async Detailed) ═══════════════

    @Override
    public CompletableFuture<Map<String, int[]>> getDetailedStats(UUID uuid) {
        return plugin.getStatsManager().getStats(uuid);
    }

    // ═══════════════ Kit Info ═══════════════

    @Override
    public Set<String> getAvailableKitIds() {
        return plugin.getKitManager().getKitIds();
    }

    @Override
    public boolean kitExists(String kitId) {
        return plugin.getKitManager().kitExists(kitId);
    }

    // ═══════════════ Arena Info ═══════════════

    @Override
    public Set<String> getArenaNames() {
        return plugin.getArenaManager().getArenaNames();
    }

    @Override
    public int getAvailableArenaCount() {
        return (int) plugin.getArenaManager().getAllArenas().stream()
                .filter(a -> !a.inUse)
                .count();
    }
}
