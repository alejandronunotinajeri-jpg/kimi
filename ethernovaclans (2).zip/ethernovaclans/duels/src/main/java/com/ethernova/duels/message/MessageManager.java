package com.ethernova.duels.message;

import com.ethernova.duels.EthernovaDuels;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ConcurrentHashMap;

public class MessageManager {

    private final EthernovaDuels plugin;
    private final MiniMessage mini = MiniMessage.miniMessage();
    private YamlConfiguration messages;
    private final ConcurrentHashMap<String, String> cache = new ConcurrentHashMap<>();

    public MessageManager(EthernovaDuels plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        cache.clear();
        String lang = plugin.getConfig().getString("general.language", "es");
        String fileName = "messages_" + lang + ".yml";

        // Save defaults
        if (!new File(plugin.getDataFolder(), "messages_es.yml").exists()) {
            plugin.saveResource("messages_es.yml", false);
        }
        if (!new File(plugin.getDataFolder(), "messages_en.yml").exists()) {
            plugin.saveResource("messages_en.yml", false);
        }

        File file = new File(plugin.getDataFolder(), fileName);
        if (!file.exists()) {
            plugin.getLogger().warning("Language file " + fileName + " not found, falling back to messages_es.yml");
            file = new File(plugin.getDataFolder(), "messages_es.yml");
        }

        messages = YamlConfiguration.loadConfiguration(file);

        // Merge defaults from jar
        InputStream defaultStream = plugin.getResource(fileName);
        if (defaultStream == null) defaultStream = plugin.getResource("messages_es.yml");
        if (defaultStream != null) {
            YamlConfiguration defaults = YamlConfiguration.loadConfiguration(
                    new InputStreamReader(defaultStream, StandardCharsets.UTF_8));
            messages.setDefaults(defaults);
        }

        plugin.getLogger().info("Loaded language: " + lang + " (" + fileName + ")");
    }

    public String get(String path, String... replacements) {
        String msg = cache.computeIfAbsent(path, k ->
                messages.getString(k, "<red>Missing: " + k));

        for (int i = 0; i < replacements.length - 1; i += 2) {
            msg = msg.replace(replacements[i], replacements[i + 1]);
        }

        String prefix = cache.computeIfAbsent("general.prefix",
                k -> messages.getString(k, ""));
        msg = msg.replace("{prefix}", prefix);

        return msg;
    }

    public void sendMessage(CommandSender sender, String path, String... replacements) {
        String msg = get(path, replacements);
        sender.sendMessage(mini.deserialize(msg));
    }

    public void sendRaw(CommandSender sender, String raw) {
        sender.sendMessage(mini.deserialize(raw));
    }

    public Component parse(String text) {
        return mini.deserialize(text);
    }
}
