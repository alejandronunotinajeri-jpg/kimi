package com.ethernova.duels.placeholder;

import com.ethernova.duels.EthernovaDuels;
import com.ethernova.duels.manager.DuelManager;
import com.ethernova.duels.message.MessageManager;
import com.ethernova.duels.model.DuelMatch;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class DuelsPlaceholders extends PlaceholderExpansion {

    private final EthernovaDuels plugin;

    public DuelsPlaceholders(EthernovaDuels plugin) {
        this.plugin = plugin;
    }

    private MessageManager mm() { return plugin.getMessageManager(); }

    @Override
    public @NotNull String getIdentifier() { return "ethernova_duels"; }

    @Override
    public @NotNull String getAuthor() { return "Ethernova"; }

    @Override
    public @NotNull String getVersion() { return plugin.getDescription().getVersion(); }

    @Override
    public boolean persist() { return true; }

    @Override
    public @Nullable String onPlaceholderRequest(Player player, @NotNull String params) {
        if (player == null) return "";

        DuelManager dm = plugin.getDuelManager();

        return switch (params.toLowerCase()) {
            case "in_duel" -> dm.isInDuel(player.getUniqueId())
                    ? mm().get("placeholder.yes") : mm().get("placeholder.no");
            case "opponent" -> {
                DuelMatch match = dm.getMatch(player.getUniqueId());
                if (match == null) yield mm().get("placeholder.none");
                java.util.UUID oppUuid = match.getOpponent(player.getUniqueId());
                Player opp = org.bukkit.Bukkit.getPlayer(oppUuid);
                yield opp != null ? opp.getName() : mm().get("placeholder.none");
            }
            case "kit" -> {
                DuelMatch match = dm.getMatch(player.getUniqueId());
                yield match != null ? match.getKit() : mm().get("placeholder.none");
            }
            case "active_duels" -> String.valueOf(dm.getActiveMatches().size());
            case "wins" -> {
                var stats = plugin.getStatsManager().getCachedStats(player.getUniqueId());
                yield stats != null ? String.valueOf(stats.wins()) : "0";
            }
            case "losses" -> {
                var stats = plugin.getStatsManager().getCachedStats(player.getUniqueId());
                yield stats != null ? String.valueOf(stats.losses()) : "0";
            }
            case "total_duels" -> {
                var stats = plugin.getStatsManager().getCachedStats(player.getUniqueId());
                yield stats != null ? String.valueOf(stats.wins() + stats.losses()) : "0";
            }
            case "winrate" -> {
                var stats = plugin.getStatsManager().getCachedStats(player.getUniqueId());
                if (stats == null) yield "0.0%";
                int total = stats.wins() + stats.losses();
                yield total == 0 ? "0.0%" : String.format("%.1f%%", (double) stats.wins() / total * 100);
            }
            default -> null;
        };
    }
}
