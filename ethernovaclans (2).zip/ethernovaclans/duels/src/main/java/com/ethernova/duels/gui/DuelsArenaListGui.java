package com.ethernova.duels.gui;

import com.ethernova.core.gui.CoreGui;
import com.ethernova.duels.EthernovaDuels;
import com.ethernova.duels.manager.ArenaManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Admin GUI — lists all duel arenas with TP / delete / create controls.
 */
public class DuelsArenaListGui extends CoreGui {

    private final EthernovaDuels plugin;

    public DuelsArenaListGui(EthernovaDuels plugin, Player player) {
        super(plugin.getCore(), player);
        this.plugin = plugin;
    }

    public void open() {
        openInventory("<gradient:#ED213A:#93291E>⚔ Arenas de Duelos</gradient>", 54);
    }

    @Override
    protected void populateItems() {
        // Header
        setItem(4, createItem(Material.GRASS_BLOCK,
                "<gold><bold>⚔ Gestión de Arenas",
                List.of("", "<gray>Administra todas las arenas de duelos", "")));

        var arenas = plugin.getArenaManager().getAllArenas();
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};
        int idx = 0;

        for (ArenaManager.Arena arena : arenas) {
            if (idx >= slots.length) break;

            List<String> lore = new ArrayList<>();
            lore.add("");
            lore.add("<dark_gray>▎ <gray>Estado: " + (arena.inUse ? "<red>En uso" : "<green>Disponible"));
            lore.add("<dark_gray>▎ <gray>Spawn 1: <white>" + formatLoc(arena.spawn1));
            lore.add("<dark_gray>▎ <gray>Spawn 2: <white>" + formatLoc(arena.spawn2));
            if (arena.regionPos1 != null && arena.regionPos2 != null) {
                lore.add("<dark_gray>▎ <green>✔ Región de rollback configurada");
            } else {
                lore.add("<dark_gray>▎ <red>✘ Sin región de rollback");
            }
            lore.add("");
            lore.add("<dark_gray>▎ <yellow>Click → Teleport a Spawn 1");
            lore.add("<dark_gray>▎ <red>Shift+Click → Eliminar arena");

            setItem(slots[idx], createItem(Material.GRASS_BLOCK, "<gold>" + arena.name, lore));
            slotActions.put(slots[idx], "ARENA:" + arena.name);
            idx++;
        }

        if (arenas.isEmpty()) {
            setItem(22, createItem(Material.BARRIER, "<red>No hay arenas",
                    List.of("", "<gray>Usa el botón de crear o", "<gray>/dueladmin arena create <nombre>")));
        }

        // Create arena button
        setItem(48, createItem(Material.EMERALD_BLOCK,
                "<green><bold>+ Crear Arena",
                List.of("",
                        "<dark_gray>▎ <gray>Crea una nueva arena",
                        "<dark_gray>▎ <gray>en tu posición actual.",
                        "",
                        "<dark_gray>▎ <yellow>Click para crear",
                        "<dark_gray>▎ <gray>Spawns se configuran con:",
                        "<dark_gray>▎ <white>/dueladmin arena set1/set2 <nombre>")));
        slotActions.put(48, "CREATE");

        // Back
        setItem(45, createItem(Material.ARROW, "<gray>← Volver"));
        slotActions.put(45, "BACK");

        // Close
        setItem(49, createItem(Material.BARRIER, "<red>Cerrar"));
        slotActions.put(49, "CLOSE");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.equals("CREATE")) {
            int count = plugin.getArenaManager().getArenaNames().size() + 1;
            String name = "arena_" + count;
            while (plugin.getArenaManager().getArena(name) != null) {
                count++;
                name = "arena_" + count;
            }
            Location loc = player.getLocation();
            plugin.getArenaManager().createArena(name, loc, loc);
            player.sendMessage(mini.deserialize(
                    "<green>✔ Arena '<white>" + name + "<green>' creada. Configura spawns con " +
                    "<white>/dueladmin arena set1 " + name + " <green>y <white>/dueladmin arena set2 " + name));
            playSound("success");
            refresh();
            return true;
        }
        if (action.equals("BACK")) {
            playSound("click");
            player.closeInventory();
            Bukkit.getScheduler().runTaskLater(plugin, () -> new DuelsAdminGui(plugin, player).open(), 1L);
            return true;
        }
        if (action.startsWith("ARENA:")) {
            String arenaName = action.substring(6);
            var arena = plugin.getArenaManager().getArena(arenaName);
            if (arena == null) return true;

            if (event.isShiftClick()) {
                // Delete
                plugin.getArenaManager().deleteArena(arenaName);
                player.sendMessage(mini.deserialize("<red>✘ Arena '" + arenaName + "' eliminada."));
                playSound("click");
                refresh();
            } else {
                // TP
                player.teleport(arena.spawn1);
                player.sendMessage(mini.deserialize("<green>✦ Teleportado a arena: <white>" + arenaName));
                playSound("click");
                player.closeInventory();
            }
            return true;
        }
        return false;
    }

    private void refresh() {
        playSound("click");
        player.closeInventory();
        Bukkit.getScheduler().runTaskLater(plugin, this::open, 1L);
    }

    private String formatLoc(Location loc) {
        if (loc == null) return "<red>No definido";
        return String.format("%.0f, %.0f, %.0f", loc.getX(), loc.getY(), loc.getZ());
    }
}
