package com.ethernova.duels.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.CoreGui;
import com.ethernova.duels.EthernovaDuels;
import com.ethernova.duels.message.MessageManager;
import com.ethernova.duels.model.DuelKit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.*;

public class DuelStatsGui extends CoreGui {

    private final EthernovaDuels plugin;
    private final UUID targetUuid;
    private final String targetName;

    public DuelStatsGui(EthernovaCore core, EthernovaDuels plugin, Player player, UUID targetUuid, String targetName) {
        super(core, player);
        this.plugin = plugin;
        this.targetUuid = targetUuid;
        this.targetName = targetName;
    }

    private MessageManager mm() { return plugin.getMessageManager(); }

    public void open() {
        openInventory(mm().get("gui.stats.title", "{player}", targetName), 45);
    }

    @Override
    protected void populateItems() {
        // Load stats asynchronously and then populate on main thread
        plugin.getStatsManager().getStats(targetUuid).thenAccept(stats -> {
            org.bukkit.Bukkit.getScheduler().runTask(plugin, () -> {
                if (inventory == null) return;

                // Overall stats summary
                int totalWins = 0, totalLosses = 0, bestStreak = 0;
                for (int[] s : stats.values()) {
                    totalWins += s[0];
                    totalLosses += s[1];
                    bestStreak = Math.max(bestStreak, s[3]);
                }

                int totalGames = totalWins + totalLosses;
                double winRate = totalGames > 0 ? (double) totalWins / totalGames * 100 : 0;

                List<String> overallLore = List.of(
                        "<dark_gray>▎ " + mm().get("gui.stats.total-games", "{total}", String.valueOf(totalGames)),
                        "<dark_gray>▎ " + mm().get("gui.stats.wins", "{wins}", String.valueOf(totalWins)),
                        "<dark_gray>▎ " + mm().get("gui.stats.losses", "{losses}", String.valueOf(totalLosses)),
                        "<dark_gray>▎ " + mm().get("gui.stats.winrate", "{rate}", String.format("%.1f%%", winRate)),
                        "<dark_gray>▎ " + mm().get("gui.stats.best-streak", "{streak}", String.valueOf(bestStreak)),
                        "",
                        "<dark_gray>▎ " + mm().get("gui.stats.summary-footer", "{player}", targetName)
                );

                setItem(13, createItem(Material.GOLDEN_SWORD, mm().get("gui.stats.summary-title"), overallLore));

                // Per-kit stats
                int[] kitSlots = {28, 29, 30, 31, 32, 33, 34};
                int index = 0;

                for (DuelKit kit : plugin.getKitManager().getAllKits()) {
                    if (index >= kitSlots.length) break;

                    int[] kitStats = stats.getOrDefault(kit.getId(), new int[]{0, 0, 0, 0});
                    int w = kitStats[0], l = kitStats[1], streak = kitStats[2], best = kitStats[3];
                    int total = w + l;
                    double rate = total > 0 ? (double) w / total * 100 : 0;

                    List<String> kitLore = List.of(
                            "<dark_gray>▎ " + mm().get("gui.stats.kit-games", "{total}", String.valueOf(total)),
                            "<dark_gray>▎ " + mm().get("gui.stats.kit-wins", "{wins}", String.valueOf(w)),
                            "<dark_gray>▎ " + mm().get("gui.stats.kit-losses", "{losses}", String.valueOf(l)),
                            "<dark_gray>▎ " + mm().get("gui.stats.kit-winrate", "{rate}", String.format("%.1f%%", rate)),
                            "<dark_gray>▎ " + mm().get("gui.stats.kit-streak", "{streak}", String.valueOf(streak)),
                            "<dark_gray>▎ " + mm().get("gui.stats.kit-best-streak", "{streak}", String.valueOf(best))
                    );

                    setItem(kitSlots[index], createItem(kit.getIcon(), "<gold>" + kit.getName(), kitLore));
                    index++;
                }

                // Back button
                    setItem(36, createItem(Material.ARROW, "<red>← Volver", 
                            List.of("<gray>Regresa al menú anterior")));
                    slotActions.put(36, "BACK");

                    // Close button
                setItem(40, createItem(Material.BARRIER, mm().get("gui.stats.close")));
                slotActions.put(40, "CLOSE");
            });
        });
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if ("BACK".equals(action)) {
            playSound("click");
            player.closeInventory();
            return true;
        }
        return false;
    }
}
