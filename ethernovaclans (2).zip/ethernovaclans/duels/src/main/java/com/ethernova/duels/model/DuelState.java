package com.ethernova.duels.model;

public enum DuelState {
    COUNTDOWN,
    FIGHTING,
    ENDED
}
