package com.ethernova.duels.listener;

import com.ethernova.core.EthernovaCore;
import com.ethernova.duels.EthernovaDuels;
import com.ethernova.duels.manager.DuelManager;
import com.ethernova.duels.model.DuelMatch;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.UUID;

public class DuelSpectatorListener implements Listener {

    private final EthernovaDuels plugin;
    private final EthernovaCore core;

    public DuelSpectatorListener(EthernovaDuels plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onSpectatorDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (isSpectating(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onSpectatorAttack(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player player && isSpectating(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onSpectatorInteract(PlayerInteractEvent event) {
        if (isSpectating(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onSpectatorInventoryClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player player && isSpectating(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onSpectatorDrop(PlayerDropItemEvent event) {
        if (isSpectating(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onSpectatorPickup(EntityPickupItemEvent event) {
        if (event.getEntity() instanceof Player player && isSpectating(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onSpectatorBlockBreak(BlockBreakEvent event) {
        if (isSpectating(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onSpectatorBlockPlace(BlockPlaceEvent event) {
        if (isSpectating(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onSpectatorQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();

        // Check if they are spectating any match
        DuelManager dm = plugin.getDuelManager();
        for (DuelMatch match : dm.getActiveMatches()) {
            if (match.isSpectator(uuid)) {
                dm.removeSpectator(player, match);
                break;
            }
        }
    }

    private boolean isSpectating(Player player) {
        UUID uuid = player.getUniqueId();
        DuelManager dm = plugin.getDuelManager();

        // Player is in duel context but NOT a match participant
        if (!core.getContextManager().hasContext(uuid, "duel")) return false;
        DuelMatch match = dm.getMatch(uuid);
        if (match != null) return false; // They are a participant

        // Check spectator lists
        for (DuelMatch m : dm.getActiveMatches()) {
            if (m.isSpectator(uuid)) return true;
        }
        return false;
    }
}
