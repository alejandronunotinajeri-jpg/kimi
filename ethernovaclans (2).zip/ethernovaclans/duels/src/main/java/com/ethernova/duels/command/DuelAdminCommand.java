package com.ethernova.duels.command;

import com.ethernova.duels.EthernovaDuels;
import com.ethernova.duels.gui.DuelsAdminGui;
import com.ethernova.duels.manager.ArenaManager;
import com.ethernova.duels.message.MessageManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

public class DuelAdminCommand implements TabExecutor {

    private final EthernovaDuels plugin;

    public DuelAdminCommand(EthernovaDuels plugin) {
        this.plugin = plugin;
    }

    private MessageManager mm() { return plugin.getMessageManager(); }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("ethernova.duels.admin")) {
            mm().sendMessage(sender, "general.no-permission");
            return true;
        }

        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        String sub = args[0].toLowerCase();

        if ("arena".equals(sub)) {
            return handleArena(sender, args);
        }

        if ("reload".equals(sub)) {
            plugin.reloadConfig();
            plugin.getKitManager().loadKits();
            plugin.getArenaManager().loadArenas();
            plugin.getMessageManager().load();
            mm().sendMessage(sender, "admin.reload-success");
            return true;
        }

        if ("forceend".equals(sub)) {
            plugin.getDuelManager().forceEndAll();
            mm().sendMessage(sender, "admin.forceend-success");
            return true;
        }

        if ("gui".equals(sub)) {
            if (!(sender instanceof Player p)) {
                sender.sendMessage("Solo jugadores.");
                return true;
            }
            new DuelsAdminGui(plugin, p).open();
            return true;
        }

        sendHelp(sender);
        return true;
    }

    private boolean handleArena(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sendArenaHelp(sender);
            return true;
        }

        String action = args[1].toLowerCase();
        ArenaManager arenaManager = plugin.getArenaManager();

        return switch (action) {
            case "create" -> {
                if (!(sender instanceof Player player)) {
                    mm().sendMessage(sender, "admin.arena-only-players");
                    yield true;
                }
                if (args.length < 3) {
                    mm().sendMessage(sender, "admin.arena-create-usage");
                    yield true;
                }
                String name = args[2].toLowerCase();
                boolean created = arenaManager.createArena(name, player.getLocation(), player.getLocation());
                if (created) {
                    mm().sendMessage(sender, "admin.arena-created", "{name}", name);
                } else {
                    mm().sendMessage(sender, "admin.arena-exists", "{name}", name);
                }
                yield true;
            }
            case "set1", "set2" -> {
                if (!(sender instanceof Player player)) {
                    mm().sendMessage(sender, "admin.arena-set-only-players");
                    yield true;
                }
                if (args.length < 3) {
                    mm().sendMessage(sender, "admin.arena-set-usage", "{action}", action);
                    yield true;
                }
                String name = args[2].toLowerCase();
                int spawnNum = action.equals("set1") ? 1 : 2;
                boolean set = arenaManager.setSpawn(name, spawnNum, player.getLocation());
                if (set) {
                    mm().sendMessage(sender, "admin.arena-spawn-set", "{name}", name, "{number}", String.valueOf(spawnNum));
                } else {
                    mm().sendMessage(sender, "admin.arena-not-found");
                }
                yield true;
            }
            case "setregion" -> {
                if (!(sender instanceof Player player)) {
                    mm().sendMessage(sender, "admin.arena-set-only-players");
                    yield true;
                }
                if (args.length < 4) {
                    sender.sendMessage(MiniMessage.miniMessage().deserialize(
                            "<red>Uso: /dueladmin arena setregion <arena> <1|2>"));
                    yield true;
                }
                String name = args[2].toLowerCase();
                String posArg = args[3];
                if (!"1".equals(posArg) && !"2".equals(posArg)) {
                    sender.sendMessage(MiniMessage.miniMessage().deserialize(
                            "<red>Usa 1 o 2 para la esquina de la región."));
                    yield true;
                }
                ArenaManager.Arena arena = arenaManager.getArena(name);
                if (arena == null) {
                    mm().sendMessage(sender, "admin.arena-not-found");
                    yield true;
                }
                if ("1".equals(posArg)) {
                    arena.regionPos1 = player.getLocation().clone();
                } else {
                    arena.regionPos2 = player.getLocation().clone();
                }
                // Re-save
                arenaManager.setRegion(name, 
                        arena.regionPos1 != null ? arena.regionPos1 : player.getLocation(),
                        arena.regionPos2 != null ? arena.regionPos2 : player.getLocation());
                sender.sendMessage(MiniMessage.miniMessage().deserialize(
                        "<green>Esquina " + posArg + " de la región establecida para arena <yellow>" + name + "</yellow>."
                        + (arena.hasRegion() ? " <aqua>¡Región completa! Rollback activo.</aqua>" : " <gray>Falta la otra esquina.</gray>")));
                yield true;
            }
            case "delete" -> {
                if (args.length < 3) {
                    mm().sendMessage(sender, "admin.arena-delete-usage");
                    yield true;
                }
                String name = args[2].toLowerCase();
                boolean deleted = arenaManager.deleteArena(name);
                if (deleted) {
                    mm().sendMessage(sender, "admin.arena-deleted", "{name}", name);
                } else {
                    mm().sendMessage(sender, "admin.arena-not-found");
                }
                yield true;
            }
            case "list" -> {
                mm().sendMessage(sender, "admin.arena-list-header");
                for (ArenaManager.Arena arena : arenaManager.getAllArenas()) {
                    String status = arena.inUse
                            ? mm().get("admin.status-in-use")
                            : mm().get("admin.status-available");
                    mm().sendMessage(sender, "admin.arena-list-entry", "{name}", arena.name, "{status}", status);
                }
                if (arenaManager.getAllArenas().isEmpty()) {
                    mm().sendMessage(sender, "admin.arena-empty");
                }
                yield true;
            }
            default -> {
                sendArenaHelp(sender);
                yield true;
            }
        };
    }

    private void sendHelp(CommandSender sender) {
        mm().sendMessage(sender, "help-admin.header");
        mm().sendMessage(sender, "help-admin.arena-create");
        mm().sendMessage(sender, "help-admin.arena-set");
        mm().sendMessage(sender, "help-admin.arena-delete");
        mm().sendMessage(sender, "help-admin.arena-list");
        mm().sendMessage(sender, "help-admin.reload");
        mm().sendMessage(sender, "help-admin.forceend");
        mm().sendMessage(sender, "help-admin.footer");
    }

    private void sendArenaHelp(CommandSender sender) {
        mm().sendMessage(sender, "help-arena.header");
        mm().sendMessage(sender, "help-arena.create");
        mm().sendMessage(sender, "help-arena.set1");
        mm().sendMessage(sender, "help-arena.set2");
        sender.sendMessage(MiniMessage.miniMessage().deserialize(
                "<gold>/dueladmin arena setregion <arena> <1|2></gold> <gray>- Establecer esquina de región para rollback</gray>"));
        mm().sendMessage(sender, "help-arena.delete");
        mm().sendMessage(sender, "help-arena.list");
        mm().sendMessage(sender, "help-arena.footer");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("ethernova.duels.admin")) return Collections.emptyList();

        if (args.length == 1) {
            return filterCompletions(List.of("arena", "reload", "forceend", "gui"), args[0]);
        }

        if (args.length == 2 && "arena".equalsIgnoreCase(args[0])) {
            return filterCompletions(List.of("create", "set1", "set2", "setregion", "delete", "list"), args[1]);
        }

        if (args.length == 3 && "arena".equalsIgnoreCase(args[0])) {
            String action = args[1].toLowerCase();
            if (action.equals("set1") || action.equals("set2") || action.equals("setregion") || action.equals("delete")) {
                return filterCompletions(new ArrayList<>(plugin.getArenaManager().getArenaNames()), args[2]);
            }
        }

        if (args.length == 4 && "arena".equalsIgnoreCase(args[0]) && "setregion".equalsIgnoreCase(args[1])) {
            return filterCompletions(List.of("1", "2"), args[3]);
        }

        return Collections.emptyList();
    }

    private List<String> filterCompletions(List<String> options, String input) {
        String lower = input.toLowerCase();
        return options.stream()
                .filter(s -> s.toLowerCase().startsWith(lower))
                .sorted()
                .collect(Collectors.toList());
    }
}
