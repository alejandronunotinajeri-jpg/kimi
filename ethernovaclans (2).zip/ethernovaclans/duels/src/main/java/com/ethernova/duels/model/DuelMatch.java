package com.ethernova.duels.model;

import org.bukkit.Location;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class DuelMatch {

    private final UUID matchId;
    private final UUID player1;
    private final UUID player2;
    private final String kit;
    private final double betAmount;
    private volatile DuelState state;
    private final Location spawn1;
    private final Location spawn2;
    private final String arenaName;
    private final long startTime;
    private final Set<UUID> spectators = ConcurrentHashMap.newKeySet();

    // Saved inventories for restoration
    private org.bukkit.inventory.ItemStack[] savedInventory1;
    private org.bukkit.inventory.ItemStack[] savedArmor1;
    private org.bukkit.inventory.ItemStack[] savedInventory2;
    private org.bukkit.inventory.ItemStack[] savedArmor2;
    private Location savedLocation1;
    private Location savedLocation2;
    private int savedLevel1;
    private float savedExp1;
    private int savedLevel2;
    private float savedExp2;

    public DuelMatch(UUID matchId, UUID player1, UUID player2, String kit, double betAmount,
                     Location spawn1, Location spawn2, String arenaName) {
        this.matchId = matchId;
        this.player1 = player1;
        this.player2 = player2;
        this.kit = kit;
        this.betAmount = betAmount;
        this.state = DuelState.COUNTDOWN;
        this.spawn1 = spawn1;
        this.spawn2 = spawn2;
        this.arenaName = arenaName;
        this.startTime = System.currentTimeMillis();
    }

    public UUID getMatchId() { return matchId; }
    public UUID getPlayer1() { return player1; }
    public UUID getPlayer2() { return player2; }
    public String getKit() { return kit; }
    public double getBetAmount() { return betAmount; }
    public DuelState getState() { return state; }
    public Location getSpawn1() { return spawn1; }
    public Location getSpawn2() { return spawn2; }
    public String getArenaName() { return arenaName; }
    public long getStartTime() { return startTime; }

    public void setState(DuelState state) { this.state = state; }

    public boolean isParticipant(UUID uuid) {
        return player1.equals(uuid) || player2.equals(uuid);
    }

    public UUID getOpponent(UUID uuid) {
        if (player1.equals(uuid)) return player2;
        if (player2.equals(uuid)) return player1;
        return null;
    }

    public long getDurationMs() {
        return System.currentTimeMillis() - startTime;
    }

    // Spectator management
    public void addSpectator(UUID uuid) { spectators.add(uuid); }
    public void removeSpectator(UUID uuid) { spectators.remove(uuid); }
    public Set<UUID> getSpectators() { return spectators; }
    public boolean isSpectator(UUID uuid) { return spectators.contains(uuid); }

    // Inventory save/restore
    public void savePlayerState(org.bukkit.entity.Player p, int slot) {
        if (slot == 1) {
            savedInventory1 = p.getInventory().getContents().clone();
            savedArmor1 = p.getInventory().getArmorContents().clone();
            savedLocation1 = p.getLocation().clone();
            savedLevel1 = p.getLevel();
            savedExp1 = p.getExp();
        } else {
            savedInventory2 = p.getInventory().getContents().clone();
            savedArmor2 = p.getInventory().getArmorContents().clone();
            savedLocation2 = p.getLocation().clone();
            savedLevel2 = p.getLevel();
            savedExp2 = p.getExp();
        }
    }

    public void restorePlayerState(org.bukkit.entity.Player p, int slot) {
        if (slot == 1) {
            p.getInventory().setContents(savedInventory1 != null ? savedInventory1 : new org.bukkit.inventory.ItemStack[0]);
            p.getInventory().setArmorContents(savedArmor1 != null ? savedArmor1 : new org.bukkit.inventory.ItemStack[4]);
            if (savedLocation1 != null) p.teleport(savedLocation1);
            p.setLevel(savedLevel1);
            p.setExp(savedExp1);
        } else {
            p.getInventory().setContents(savedInventory2 != null ? savedInventory2 : new org.bukkit.inventory.ItemStack[0]);
            p.getInventory().setArmorContents(savedArmor2 != null ? savedArmor2 : new org.bukkit.inventory.ItemStack[4]);
            if (savedLocation2 != null) p.teleport(savedLocation2);
            p.setLevel(savedLevel2);
            p.setExp(savedExp2);
        }
    }

    public Location getSavedLocation(int slot) {
        return slot == 1 ? savedLocation1 : savedLocation2;
    }

    /** Returns the saved inventory/level/exp state for the given slot, for pending restore on rejoin. */
    public SavedState getSavedState(int slot) {
        if (slot == 1) {
            return new SavedState(savedInventory1, savedArmor1, savedLocation1, savedLevel1, savedExp1);
        } else {
            return new SavedState(savedInventory2, savedArmor2, savedLocation2, savedLevel2, savedExp2);
        }
    }

    public record SavedState(org.bukkit.inventory.ItemStack[] inventory, org.bukkit.inventory.ItemStack[] armor,
                              Location location, int level, float exp) {}

    // Spectator state save/restore
    private final java.util.Map<UUID, SpectatorState> savedSpectatorStates = new ConcurrentHashMap<>();

    private record SpectatorState(org.bukkit.inventory.ItemStack[] inventory, org.bukkit.inventory.ItemStack[] armor,
                                  Location location, int level, float exp, org.bukkit.GameMode gameMode) {}

    public void saveSpectatorState(org.bukkit.entity.Player p) {
        savedSpectatorStates.put(p.getUniqueId(), new SpectatorState(
                p.getInventory().getContents().clone(),
                p.getInventory().getArmorContents().clone(),
                p.getLocation().clone(),
                p.getLevel(), p.getExp(), p.getGameMode()
        ));
    }

    public void restoreSpectatorState(org.bukkit.entity.Player p) {
        SpectatorState state = savedSpectatorStates.remove(p.getUniqueId());
        if (state == null) {
            // Fallback: teleport to world spawn
            p.teleport(p.getWorld().getSpawnLocation());
            return;
        }
        p.getInventory().setContents(state.inventory());
        p.getInventory().setArmorContents(state.armor());
        if (state.location() != null) p.teleport(state.location());
        p.setLevel(state.level());
        p.setExp(state.exp());
        p.setGameMode(state.gameMode());
    }

    public int getPlayerSlot(UUID uuid) {
        if (player1.equals(uuid)) return 1;
        if (player2.equals(uuid)) return 2;
        return -1;
    }
}
