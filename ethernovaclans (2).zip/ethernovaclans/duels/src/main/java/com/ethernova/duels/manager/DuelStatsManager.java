package com.ethernova.duels.manager;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.storage.CoreStorageManager;
import com.ethernova.core.storage.MigrationManager;
import com.ethernova.duels.EthernovaDuels;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

public class DuelStatsManager {

    private final EthernovaDuels plugin;
    private final CoreStorageManager storage;
    private final Map<UUID, CachedDuelStats> cache = new ConcurrentHashMap<>();

    public DuelStatsManager(EthernovaDuels plugin, CoreStorageManager storage) {
        this.plugin = plugin;
        this.storage = storage;
    }

    // ── Cached aggregate stats (for PAPI placeholders) ──

    public record CachedDuelStats(int wins, int losses, int bestStreak) {
        public double winRate() {
            int total = wins + losses;
            return total == 0 ? 0 : (double) wins / total * 100;
        }
    }

    /**
     * Returns cached aggregate stats synchronously. If not loaded yet, returns null
     * and triggers an async load so the next call will have data.
     */
    public CachedDuelStats getCachedStats(UUID uuid) {
        CachedDuelStats cached = cache.get(uuid);
        if (cached == null) {
            // Trigger async load; first call returns null, subsequent ones will hit cache
            loadCacheAsync(uuid);
        }
        return cached;
    }

    public void loadCacheAsync(UUID uuid) {
        getStats(uuid).thenAccept(statsMap -> {
            int totalWins = 0, totalLosses = 0, bestStreak = 0;
            for (int[] arr : statsMap.values()) {
                totalWins += arr[0];
                totalLosses += arr[1];
                bestStreak = Math.max(bestStreak, arr[3]);
            }
            cache.put(uuid, new CachedDuelStats(totalWins, totalLosses, bestStreak));
        });
    }

    public void invalidateCache(UUID uuid) {
        cache.remove(uuid);
    }

    public void runMigrations() {
        new MigrationManager(storage, plugin.getLogger(), "ethernova_duels")
                .addMigration(1,
                        """
                        CREATE TABLE IF NOT EXISTS ethernova_duel_stats (
                            uuid VARCHAR(36) NOT NULL,
                            kit VARCHAR(64) NOT NULL,
                            wins INT DEFAULT 0,
                            losses INT DEFAULT 0,
                            win_streak INT DEFAULT 0,
                            best_streak INT DEFAULT 0,
                            PRIMARY KEY (uuid, kit)
                        )
                        """,
                        """
                        CREATE TABLE IF NOT EXISTS ethernova_duel_history (
                            id INTEGER PRIMARY KEY %AUTO%,
                            winner_uuid VARCHAR(36) NOT NULL,
                            winner_name VARCHAR(16) NOT NULL,
                            loser_uuid VARCHAR(36) NOT NULL,
                            loser_name VARCHAR(16) NOT NULL,
                            kit VARCHAR(64) NOT NULL,
                            duration_ms BIGINT NOT NULL,
                            bet_amount DOUBLE DEFAULT 0,
                            played_at BIGINT NOT NULL
                        )
                        """.replace("%AUTO%", storage.isMySQL() ? "AUTO_INCREMENT" : "AUTOINCREMENT")
                )                .addMigration(2,
                        "CREATE INDEX IF NOT EXISTS idx_duel_history_winner ON ethernova_duel_history (winner_uuid)",
                        "CREATE INDEX IF NOT EXISTS idx_duel_history_loser ON ethernova_duel_history (loser_uuid)",
                        "CREATE INDEX IF NOT EXISTS idx_duel_history_kit ON ethernova_duel_history (kit)"
                )                .migrate();
    }

    public CompletableFuture<Void> recordResult(UUID winnerUuid, String winnerName,
                                                 UUID loserUuid, String loserName,
                                                 String kit, long durationMs, double betAmount) {
        return CompletableFuture.runAsync(() -> {
            try (Connection conn = storage.getConnection()) {
                // Update winner stats
                updateStats(conn, winnerUuid, kit, true);
                // Update loser stats
                updateStats(conn, loserUuid, kit, false);
                // Insert history
                insertHistory(conn, winnerUuid, winnerName, loserUuid, loserName, kit, durationMs, betAmount);
                // Refresh cache for both players
                loadCacheAsync(winnerUuid);
                loadCacheAsync(loserUuid);
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Error guardando resultado de duelo", e);
            }
        }, EthernovaCore.getInstance().getDbExecutor()).exceptionally(ex -> {
            plugin.getLogger().log(Level.SEVERE, "Unhandled error recording duel result", ex);
            return null;
        });
    }

    private void updateStats(Connection conn, UUID uuid, String kit, boolean won) throws Exception {
        // Try update first
        String upsert;
        if (storage.isMySQL()) {
            upsert = """
                INSERT INTO ethernova_duel_stats (uuid, kit, wins, losses, win_streak, best_streak)
                VALUES (?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                    wins = wins + ?,
                    losses = losses + ?,
                    win_streak = IF(? = 1, win_streak + 1, 0),
                    best_streak = GREATEST(best_streak, IF(? = 1, win_streak, best_streak))
            """;
            try (PreparedStatement ps = conn.prepareStatement(upsert)) {
                int w = won ? 1 : 0;
                int l = won ? 0 : 1;
                ps.setString(1, uuid.toString());
                ps.setString(2, kit);
                ps.setInt(3, w);
                ps.setInt(4, l);
                ps.setInt(5, w);
                ps.setInt(6, w);
                ps.setInt(7, w);
                ps.setInt(8, l);
                ps.setInt(9, w);
                ps.setInt(10, w);
                ps.executeUpdate();
            }
        } else {
            // SQLite: check if exists
            String select = "SELECT wins, losses, win_streak, best_streak FROM ethernova_duel_stats WHERE uuid = ? AND kit = ?";
            try (PreparedStatement ps = conn.prepareStatement(select)) {
                ps.setString(1, uuid.toString());
                ps.setString(2, kit);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    int wins = rs.getInt("wins");
                    int losses = rs.getInt("losses");
                    int streak = rs.getInt("win_streak");
                    int best = rs.getInt("best_streak");

                    int newWins = wins + (won ? 1 : 0);
                    int newLosses = losses + (won ? 0 : 1);
                    int newStreak = won ? streak + 1 : 0;
                    int newBest = Math.max(best, newStreak);

                    String update = "UPDATE ethernova_duel_stats SET wins = ?, losses = ?, win_streak = ?, best_streak = ? WHERE uuid = ? AND kit = ?";
                    try (PreparedStatement up = conn.prepareStatement(update)) {
                        up.setInt(1, newWins);
                        up.setInt(2, newLosses);
                        up.setInt(3, newStreak);
                        up.setInt(4, newBest);
                        up.setString(5, uuid.toString());
                        up.setString(6, kit);
                        up.executeUpdate();
                    }
                } else {
                    String insert = "INSERT INTO ethernova_duel_stats (uuid, kit, wins, losses, win_streak, best_streak) VALUES (?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement ins = conn.prepareStatement(insert)) {
                        ins.setString(1, uuid.toString());
                        ins.setString(2, kit);
                        ins.setInt(3, won ? 1 : 0);
                        ins.setInt(4, won ? 0 : 1);
                        ins.setInt(5, won ? 1 : 0);
                        ins.setInt(6, won ? 1 : 0);
                        ins.executeUpdate();
                    }
                }
            }
        }
    }

    private void insertHistory(Connection conn, UUID winnerUuid, String winnerName,
                                UUID loserUuid, String loserName, String kit,
                                long durationMs, double betAmount) throws Exception {
        String sql = """
            INSERT INTO ethernova_duel_history (winner_uuid, winner_name, loser_uuid, loser_name, kit, duration_ms, bet_amount, played_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """;
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, winnerUuid.toString());
            ps.setString(2, winnerName);
            ps.setString(3, loserUuid.toString());
            ps.setString(4, loserName);
            ps.setString(5, kit);
            ps.setLong(6, durationMs);
            ps.setDouble(7, betAmount);
            ps.setLong(8, System.currentTimeMillis());
            ps.executeUpdate();
        }
    }

    public CompletableFuture<Map<String, int[]>> getStats(UUID uuid) {
        return CompletableFuture.supplyAsync(() -> {
            Map<String, int[]> stats = new LinkedHashMap<>();
            try (Connection conn = storage.getConnection()) {
                String sql = "SELECT kit, wins, losses, win_streak, best_streak FROM ethernova_duel_stats WHERE uuid = ? ORDER BY kit";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, uuid.toString());
                    ResultSet rs = ps.executeQuery();
                    while (rs.next()) {
                        stats.put(rs.getString("kit"), new int[]{
                                rs.getInt("wins"),
                                rs.getInt("losses"),
                                rs.getInt("win_streak"),
                                rs.getInt("best_streak")
                        });
                    }
                }
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Error obteniendo estadísticas de duelo", e);
            }
            return stats;
        }, EthernovaCore.getInstance().getDbExecutor()).exceptionally(ex -> {
            plugin.getLogger().log(Level.SEVERE, "Unhandled error loading duel stats", ex);
            return new LinkedHashMap<>();
        });
    }

    public CompletableFuture<List<LeaderboardEntry>> getLeaderboard(String kit, int limit) {
        return CompletableFuture.supplyAsync(() -> {
            List<LeaderboardEntry> leaderboard = new ArrayList<>();
            try (Connection conn = storage.getConnection()) {
                String sql;
                if (kit == null || kit.equalsIgnoreCase("global")) {
                    sql = """
                        SELECT uuid, SUM(wins) as total_wins, SUM(losses) as total_losses,
                               MAX(best_streak) as best_streak
                        FROM ethernova_duel_stats
                        GROUP BY uuid
                        ORDER BY total_wins DESC
                        LIMIT ?
                    """;
                } else {
                    sql = """
                        SELECT uuid, wins as total_wins, losses as total_losses, best_streak
                        FROM ethernova_duel_stats
                        WHERE kit = ?
                        ORDER BY wins DESC
                        LIMIT ?
                    """;
                }

                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    int paramIdx = 1;
                    if (kit != null && !kit.equalsIgnoreCase("global")) {
                        ps.setString(paramIdx++, kit);
                    }
                    ps.setInt(paramIdx, limit);
                    ResultSet rs = ps.executeQuery();

                    int rank = 1;
                    while (rs.next()) {
                        leaderboard.add(new LeaderboardEntry(
                                UUID.fromString(rs.getString("uuid")),
                                rank++,
                                rs.getInt("total_wins"),
                                rs.getInt("total_losses"),
                                rs.getInt("best_streak")
                        ));
                    }
                }
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Error obteniendo leaderboard de duelos", e);
            }
            return leaderboard;
        }, EthernovaCore.getInstance().getDbExecutor()).exceptionally(ex -> {
            plugin.getLogger().log(Level.SEVERE, "Unhandled error loading duel leaderboard", ex);
            return new ArrayList<>();
        });
    }

    public record LeaderboardEntry(UUID uuid, int rank, int wins, int losses, int bestStreak) {
        public double winRate() {
            int total = wins + losses;
            return total == 0 ? 0 : (double) wins / total * 100;
        }
    }
}
