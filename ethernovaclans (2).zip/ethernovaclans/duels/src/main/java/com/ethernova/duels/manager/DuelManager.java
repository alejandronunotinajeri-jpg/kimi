package com.ethernova.duels.manager;

import com.ethernova.core.api.CombatAPI;
import com.ethernova.core.EthernovaCore;
import com.ethernova.core.arena.ArenaRegion;
import com.ethernova.core.arena.ArenaRollbackEngine;
import com.ethernova.core.event.DuelEndEvent;
import com.ethernova.core.lobby.LobbyManager;
import com.ethernova.core.service.ServiceRegistry;
import com.ethernova.duels.EthernovaDuels;
import com.ethernova.duels.model.*;
import com.ethernova.duels.kit.KitManager;
import com.ethernova.duels.message.MessageManager;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class DuelManager {

    private final EthernovaDuels plugin;
    private final EthernovaCore core;
    private final MiniMessage mini = MiniMessage.miniMessage();

    private MessageManager mm() { return plugin.getMessageManager(); }

    // targetUUID -> DuelRequest (only most recent request per target)
    private final Map<UUID, DuelRequest> pendingRequests = new ConcurrentHashMap<>();
    // playerUUID -> DuelMatch (for fast lookup)
    private final Map<UUID, DuelMatch> activeMatches = new ConcurrentHashMap<>();
    // matchId -> BukkitTask (countdown/timeout tasks)
    private final Map<UUID, BukkitTask> matchTasks = new ConcurrentHashMap<>();
    // matchId -> BossBar
    private final Map<UUID, BossBar> matchBossBars = new ConcurrentHashMap<>();
    // Pending inventory restores for players who disconnected during a duel
    private final Map<UUID, PendingRestore> pendingRestores = new ConcurrentHashMap<>();

    public record PendingRestore(org.bukkit.inventory.ItemStack[] inventory, org.bukkit.inventory.ItemStack[] armor,
                                  org.bukkit.Location location, int level, float exp) {}

    public DuelManager(EthernovaDuels plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;

        // Purge expired requests every 5 seconds
        Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            long now = System.currentTimeMillis();
            pendingRequests.entrySet().removeIf(entry -> {
                if (entry.getValue().isExpired()) {
                    UUID targetUuid = entry.getKey();
                    UUID senderUuid = entry.getValue().senderUuid();
                    Bukkit.getScheduler().runTask(plugin, () -> {
                        Player target = Bukkit.getPlayer(targetUuid);
                        Player sender = Bukkit.getPlayer(senderUuid);
                        if (target != null) mm().sendMessage(target, "request.expired");
                        if (sender != null) mm().sendMessage(sender, "request.expired");
                    });
                    return true;
                }
                return false;
            });
        }, 100L, 100L);
    }

    // ────────────────── Request Phase ──────────────────

    public void sendRequest(Player sender, Player target, String kitId, double betAmount) {
        UUID senderUuid = sender.getUniqueId();
        UUID targetUuid = target.getUniqueId();

        // Validations
        if (senderUuid.equals(targetUuid)) {
            mm().sendMessage(sender, "validation.self-duel");
            return;
        }

        if (isInDuel(senderUuid)) {
            mm().sendMessage(sender, "validation.already-in-duel");
            return;
        }

        if (isInDuel(targetUuid)) {
            mm().sendMessage(sender, "validation.target-in-duel");
            return;
        }

        // Combat tag check
        CombatAPI combatAPI = ServiceRegistry.get(CombatAPI.class);
        if (combatAPI != null) {
            if (combatAPI.isInCombat(sender)) {
                mm().sendMessage(sender, "validation.in-combat");
                return;
            }
            if (combatAPI.isInCombat(target)) {
                mm().sendMessage(sender, "validation.target-in-combat");
                return;
            }
        }

        // Cooldown check
        if (!sender.hasPermission("ethernova.duels.bypass.cooldown") &&
            core.getCooldownManager().hasCooldown(senderUuid, "duel_request")) {
            String time = core.getCooldownManager().getRemainingFormatted(senderUuid, "duel_request");
            mm().sendMessage(sender, "validation.cooldown", "{time}", time);
            return;
        }

        // Bet validation
        if (betAmount > 0) {
            if (!plugin.getConfig().getBoolean("betting.enabled", true)) {
                betAmount = 0;
            } else {
                double minBet = plugin.getConfig().getDouble("betting.min-bet", 100);
                double maxBet = plugin.getConfig().getDouble("betting.max-bet", 50000);

                if (betAmount < minBet) {
                    mm().sendMessage(sender, "validation.bet-too-low", "{min}", core.getEconomyHook().format(minBet));
                    return;
                }
                if (betAmount > maxBet) {
                    mm().sendMessage(sender, "validation.bet-too-high", "{max}", core.getEconomyHook().format(maxBet));
                    return;
                }
                if (!core.getEconomyHook().isEnabled()) {
                    betAmount = 0;
                } else {
                    if (!core.getEconomyHook().has(sender, betAmount)) {
                        mm().sendMessage(sender, "validation.insufficient-funds");
                        return;
                    }
                    if (!core.getEconomyHook().has(target, betAmount)) {
                        mm().sendMessage(sender, "validation.insufficient-funds");
                        return;
                    }
                }
            }
        }

        // Kit validation
        KitManager kitManager = plugin.getKitManager();
        if (!kitManager.kitExists(kitId)) {
            kitId = "classic"; // fallback
        }

        int timeoutSeconds = plugin.getConfig().getInt("request-timeout", 30);
        long expiresAt = System.currentTimeMillis() + (timeoutSeconds * 1000L);

        DuelRequest request = new DuelRequest(senderUuid, sender.getName(), targetUuid, kitId, betAmount, expiresAt);
        pendingRequests.put(targetUuid, request);

        // Set cooldown
        long cooldownMs = plugin.getConfig().getLong("request-cooldown", 30000);
        core.getCooldownManager().setCooldown(senderUuid, "duel_request", cooldownMs);

        // Notify
        mm().sendMessage(sender, "request.sent", "{target}", target.getName());
        core.getSoundManager().play(sender, "click");

        String kitName = kitManager.getKit(kitId).getName();
        if (betAmount > 0) {
            mm().sendMessage(target, "request.received-bet",
                    "{sender}", sender.getName(),
                    "{kit}", kitName,
                    "{bet}", core.getEconomyHook().format(betAmount));
        } else {
            mm().sendMessage(target, "request.received",
                    "{sender}", sender.getName(),
                    "{kit}", kitName);
        }

        // Send accept/deny buttons
        String buttonsRaw = mm().get("request.accept-button");
        target.sendMessage(mini.deserialize(buttonsRaw));
        core.getSoundManager().play(target, "duel_accept");
    }

    public void acceptRequest(Player target) {
        UUID targetUuid = target.getUniqueId();
        DuelRequest request = pendingRequests.remove(targetUuid);

        if (request == null || request.isExpired()) {
            mm().sendMessage(target, "request.no-pending");
            return;
        }

        Player sender = Bukkit.getPlayer(request.senderUuid());
        if (sender == null || !sender.isOnline()) {
            mm().sendMessage(target, "general.player-not-found");
            return;
        }

        if (isInDuel(sender.getUniqueId()) || isInDuel(targetUuid)) {
            mm().sendMessage(target, "validation.already-in-duel");
            return;
        }

        // Combat tag check
        CombatAPI combatAPI = ServiceRegistry.get(CombatAPI.class);
        if (combatAPI != null) {
            if (combatAPI.isInCombat(sender)) {
                mm().sendMessage(target, "validation.sender-in-combat");
                return;
            }
            if (combatAPI.isInCombat(target)) {
                mm().sendMessage(target, "validation.in-combat");
                return;
            }
        }

        // Check arena availability
        ArenaManager.Arena arena = plugin.getArenaManager().getAvailableArena();
        if (arena == null) {
            mm().sendMessage(target, "validation.no-arena");
            mm().sendMessage(sender, "validation.no-arena");
            return;
        }

        // Withdraw bets (atomic: withdraw directly, refund on failure)
        double bet = request.betAmount();
        if (bet > 0 && core.getEconomyHook().isEnabled()) {
            if (!core.getEconomyHook().withdraw(sender, bet)) {
                mm().sendMessage(sender, "validation.insufficient-funds");
                mm().sendMessage(target, "validation.insufficient-funds");
                plugin.getArenaManager().releaseArena(arena.name);
                return;
            }
            if (!core.getEconomyHook().withdraw(target, bet)) {
                core.getEconomyHook().deposit(sender, bet); // refund first player
                mm().sendMessage(sender, "validation.insufficient-funds");
                mm().sendMessage(target, "validation.insufficient-funds");
                plugin.getArenaManager().releaseArena(arena.name);
                return;
            }
        }

        mm().sendMessage(sender, "request.accepted");
        mm().sendMessage(target, "request.accepted");

        startDuel(sender, target, request.kit(), bet, arena);
    }

    public void declineRequest(Player target) {
        UUID targetUuid = target.getUniqueId();
        DuelRequest request = pendingRequests.remove(targetUuid);

        if (request == null) {
            sendMessage(target, "request.no-pending");
            return;
        }

        sendMessage(target, "request.denied");
        Player sender = Bukkit.getPlayer(request.senderUuid());
        if (sender != null) {
            sendMessage(sender, "request.denied");
            core.getSoundManager().play(sender, "error");
        }
        core.getSoundManager().play(target, "click");
    }

    // ────────────────── Duel Phase ──────────────────

    private void startDuel(Player p1, Player p2, String kitId, double betAmount, ArenaManager.Arena arena) {
        UUID matchId = UUID.randomUUID();
        DuelMatch match = new DuelMatch(matchId, p1.getUniqueId(), p2.getUniqueId(),
                kitId, betAmount, arena.spawn1, arena.spawn2, arena.name);

        // Save player states
        match.savePlayerState(p1, 1);
        match.savePlayerState(p2, 2);

        // Register match
        activeMatches.put(p1.getUniqueId(), match);
        activeMatches.put(p2.getUniqueId(), match);

        // Start arena rollback tracking if region is defined
        if (arena.hasRegion()) {
            ArenaRollbackEngine engine = core.getArenaRollbackEngine();
            ArenaRegion region = ArenaRegion.fromCorners(arena.regionPos1, arena.regionPos2);
            engine.startTracking(arena.name, region);
        }

        // Add context
        core.getContextManager().addContext(p1.getUniqueId(), "duel");
        core.getContextManager().addContext(p2.getUniqueId(), "duel");

        // Set player state for scoreboard/PAPI
        core.getStateManager().setState(p1.getUniqueId(), "duel", arena.name);
        core.getStateManager().setState(p2.getUniqueId(), "duel", arena.name);

        // Teleport and prepare
        p1.teleport(arena.spawn1);
        p2.teleport(arena.spawn2);

        // Apply kit
        DuelKit kit = plugin.getKitManager().getKit(kitId);
        if (kit != null) {
            kit.applyTo(p1);
            kit.applyTo(p2);
        }

        // Set gamemode
        p1.setGameMode(GameMode.SURVIVAL);
        p2.setGameMode(GameMode.SURVIVAL);

        // Freeze during countdown
        p1.setWalkSpeed(0f);
        p2.setWalkSpeed(0f);

        // Create boss bar for countdown
        BossBar bossBar = BossBar.bossBar(
                mini.deserialize(mm().get("match.preparing")),
                1.0f,
                BossBar.Color.YELLOW,
                BossBar.Overlay.PROGRESS
        );
        p1.showBossBar(bossBar);
        p2.showBossBar(bossBar);
        matchBossBars.put(matchId, bossBar);

        // Start countdown
        int countdownSeconds = plugin.getConfig().getInt("countdown-seconds", 5);
        startCountdown(match, bossBar, countdownSeconds);
    }

    private void startCountdown(DuelMatch match, BossBar bossBar, int totalSeconds) {
        BukkitTask task = new BukkitRunnable() {
            int remaining = totalSeconds;

            @Override
            public void run() {
                Player p1 = Bukkit.getPlayer(match.getPlayer1());
                Player p2 = Bukkit.getPlayer(match.getPlayer2());

                if (p1 == null || p2 == null || !p1.isOnline() || !p2.isOnline()) {
                    cancel();
                    endDuelByDisconnect(match, p1 == null || !p1.isOnline() ? match.getPlayer1() : match.getPlayer2());
                    return;
                }

                if (remaining <= 0) {
                    // GO!
                    match.setState(DuelState.FIGHTING);

                    String goMsg = mm().get("match.countdown-go");
                    Component goComponent = mini.deserialize(goMsg);
                    p1.sendMessage(goComponent);
                    p2.sendMessage(goComponent);

                    bossBar.name(mini.deserialize(mm().get("match.fight")));
                    bossBar.color(BossBar.Color.GREEN);
                    bossBar.progress(1.0f);

                    // Unfreeze
                    p1.setWalkSpeed(0.2f);
                    p2.setWalkSpeed(0.2f);

                    core.getSoundManager().play(p1, "match_start");
                    core.getSoundManager().play(p2, "match_start");

                    // Remove boss bar after 1 second
                    Bukkit.getScheduler().runTaskLater(plugin, () -> {
                        p1.hideBossBar(bossBar);
                        p2.hideBossBar(bossBar);
                        matchBossBars.remove(match.getMatchId());
                    }, 20L);

                    // Schedule max duration timeout
                    int maxDuration = plugin.getConfig().getInt("max-duration", 300);
                    if (maxDuration > 0) {
                        BukkitTask timeoutTask = Bukkit.getScheduler().runTaskLater(plugin, () -> {
                            if (match.getState() == DuelState.FIGHTING) {
                                endDuelDraw(match);
                            }
                        }, maxDuration * 20L);
                        matchTasks.put(match.getMatchId(), timeoutTask);
                    }

                    cancel();
                    return;
                }

                // Countdown tick
                float progress = (float) remaining / totalSeconds;
                bossBar.progress(Math.max(0, Math.min(1, progress)));

                String countdownMsg = mm().get("match.countdown", "{seconds}", String.valueOf(remaining));
                Component countdownComponent = mini.deserialize(countdownMsg);

                p1.sendMessage(countdownComponent);
                p2.sendMessage(countdownComponent);

                // Color changes
                if (remaining <= 2) {
                    bossBar.color(BossBar.Color.RED);
                } else if (remaining <= 3) {
                    bossBar.color(BossBar.Color.YELLOW);
                }

                bossBar.name(mini.deserialize("<yellow><bold>" + remaining + "</bold>"));

                core.getSoundManager().play(p1, "countdown");
                core.getSoundManager().play(p2, "countdown");

                remaining--;
            }
        }.runTaskTimer(plugin, 0L, 20L);

        matchTasks.put(match.getMatchId(), task);
    }

    // ────────────────── End Phase ──────────────────

    public void endDuel(DuelMatch match, UUID winnerUuid) {
        if (match.getState() == DuelState.ENDED) return;
        match.setState(DuelState.ENDED);

        UUID loserUuid = match.getOpponent(winnerUuid);
        Player winner = Bukkit.getPlayer(winnerUuid);
        Player loser = Bukkit.getPlayer(loserUuid);

        String winnerName = winner != null ? winner.getName() : "???";
        String loserName = loser != null ? loser.getName() : "???";
        long durationMs = match.getDurationMs();
        String durationFormatted = formatDuration(durationMs);

        // Cancel tasks
        cancelMatchTasks(match.getMatchId());

        // Process betting
        double bet = match.getBetAmount();
        if (bet > 0 && core.getEconomyHook().isEnabled()) {
            double totalWin = bet * 2;
            core.getEconomyHook().deposit(Bukkit.getOfflinePlayer(winnerUuid), totalWin);
            if (winner != null) {
                mm().sendMessage(winner, "match.win-bet", "{amount}", core.getEconomyHook().format(totalWin));
            }
        }

        // Notify
        if (winner != null) {
            mm().sendMessage(winner, "match.win", "{loser}", loserName, "{duration}", durationFormatted);
            core.getSoundManager().play(winner, "success");
        }
        if (loser != null) {
            mm().sendMessage(loser, "match.lose", "{winner}", winnerName, "{duration}", durationFormatted);
            core.getSoundManager().play(loser, "error");
        }

        // Record stats async
        plugin.getStatsManager().recordResult(winnerUuid, winnerName, loserUuid, loserName,
                match.getKit(), durationMs, bet);

        // Publish event
        core.getEventBus().publish(new DuelEndEvent(winnerUuid, winnerName, loserUuid, loserName,
                match.getKit(), durationMs));

        // Cleanup (delayed to allow death animation)
        Bukkit.getScheduler().runTaskLater(plugin, () -> cleanupMatch(match), 40L);
    }

    public void endDuelByDisconnect(DuelMatch match, UUID disconnectedUuid) {
        if (match.getState() == DuelState.ENDED) return;
        UUID winnerUuid = match.getOpponent(disconnectedUuid);

        Player winner = winnerUuid != null ? Bukkit.getPlayer(winnerUuid) : null;
        if (winner != null) {
            String dcName = Bukkit.getOfflinePlayer(disconnectedUuid).getName();
            mm().sendMessage(winner, "match.forfeit", "{player}", dcName != null ? dcName : "???");
        }

        // Let endDuel() handle bet payment — do NOT deposit here to avoid double payment
        if (winnerUuid != null) {
            endDuel(match, winnerUuid);
        } else {
            match.setState(DuelState.ENDED);
            cancelMatchTasks(match.getMatchId());
            cleanupMatch(match);
        }
    }

    public void endDuelDraw(DuelMatch match) {
        if (match.getState() == DuelState.ENDED) return;
        match.setState(DuelState.ENDED);

        Player p1 = Bukkit.getPlayer(match.getPlayer1());
        Player p2 = Bukkit.getPlayer(match.getPlayer2());

        if (p1 != null) mm().sendMessage(p1, "match.timeout");
        if (p2 != null) mm().sendMessage(p2, "match.timeout");

        // Refund bets (use OfflinePlayer for offline-safe refund)
        double bet = match.getBetAmount();
        if (bet > 0 && core.getEconomyHook().isEnabled()) {
            core.getEconomyHook().deposit(Bukkit.getOfflinePlayer(match.getPlayer1()), bet);
            core.getEconomyHook().deposit(Bukkit.getOfflinePlayer(match.getPlayer2()), bet);
        }

        cancelMatchTasks(match.getMatchId());
        cleanupMatch(match);
    }

    private void cleanupMatch(DuelMatch match) {
        // Remove boss bars
        BossBar bar = matchBossBars.remove(match.getMatchId());
        if (bar != null) {
            Player p1 = Bukkit.getPlayer(match.getPlayer1());
            Player p2 = Bukkit.getPlayer(match.getPlayer2());
            if (p1 != null) p1.hideBossBar(bar);
            if (p2 != null) p2.hideBossBar(bar);
        }

        // Determine if lobby mode is active
        LobbyManager lobby = core.getLobbyManager();
        boolean useLobby = lobby != null && lobby.isEnabled();

        // Restore/transition player states
        Player p1 = Bukkit.getPlayer(match.getPlayer1());
        Player p2 = Bukkit.getPlayer(match.getPlayer2());

        if (p1 != null) {
            p1.setWalkSpeed(0.2f);
            p1.getActivePotionEffects().forEach(e -> p1.removePotionEffect(e.getType()));
            if (useLobby) {
                lobby.sendToLobby(p1);
            } else {
                match.restorePlayerState(p1, 1);
                p1.setHealth(p1.getMaxHealth());
                p1.setFoodLevel(20);
            }
        } else {
            if (!useLobby) {
                savePendingRestore(match, match.getPlayer1(), 1);
            }
        }

        if (p2 != null) {
            p2.setWalkSpeed(0.2f);
            p2.getActivePotionEffects().forEach(e -> p2.removePotionEffect(e.getType()));
            if (useLobby) {
                lobby.sendToLobby(p2);
            } else {
                match.restorePlayerState(p2, 2);
                p2.setHealth(p2.getMaxHealth());
                p2.setFoodLevel(20);
            }
        } else {
            if (!useLobby) {
                savePendingRestore(match, match.getPlayer2(), 2);
            }
        }

        // Remove contexts
        core.getContextManager().removeContext(match.getPlayer1(), "duel");
        core.getContextManager().removeContext(match.getPlayer2(), "duel");

        // Clear player states
        core.getStateManager().clearState(match.getPlayer1());
        core.getStateManager().clearState(match.getPlayer2());

        // Handle spectators
        for (UUID specUuid : match.getSpectators()) {
            Player spec = Bukkit.getPlayer(specUuid);
            if (spec != null) {
                removeSpectator(spec, match);
            }
        }

        // Remove from active matches
        activeMatches.remove(match.getPlayer1());
        activeMatches.remove(match.getPlayer2());

        // Rollback arena blocks/entities
        ArenaRollbackEngine engine = core.getArenaRollbackEngine();
        if (engine.isTracking(match.getArenaName())) {
            engine.rollback(match.getArenaName());
        }

        // Release arena
        plugin.getArenaManager().releaseArena(match.getArenaName());
    }

    private void cancelMatchTasks(UUID matchId) {
        BukkitTask task = matchTasks.remove(matchId);
        if (task != null) task.cancel();
    }

    // ────────────────── Spectating ──────────────────

    /**
     * Start a duel from the matchmaking queue (no request flow).
     * Called by QueueManager when two players are matched.
     */
    public void startQueuedDuel(Player p1, Player p2, String kitId, ArenaManager.Arena arena) {
        startDuel(p1, p2, kitId, 0, arena);
    }

    public boolean addSpectator(Player spectator, DuelMatch match) {
        UUID specUuid = spectator.getUniqueId();
        if (isInDuel(specUuid)) return false;

        match.addSpectator(specUuid);
        core.getContextManager().addContext(specUuid, "duel");

        // Save spectator state before clearing inventory
        match.saveSpectatorState(spectator);

        // Set spectator state
        core.getStateManager().setState(specUuid, "spectating", match.getArenaName());

        // Clear and enter spectator mode
        spectator.getInventory().clear();
        spectator.setGameMode(GameMode.SPECTATOR);

        // Teleport to arena midpoint
        org.bukkit.Location mid = match.getSpawn1().clone().add(match.getSpawn2()).multiply(0.5);
        mid.setY(Math.max(match.getSpawn1().getY(), match.getSpawn2().getY()) + 5);
        spectator.teleport(mid);

        Player target = Bukkit.getPlayer(match.getPlayer1());
        if (target != null) {
            mm().sendMessage(spectator, "spectate.start", "{player}", target.getName());
        }

        return true;
    }

    public void removeSpectator(Player spectator, DuelMatch match) {
        UUID specUuid = spectator.getUniqueId();
        match.removeSpectator(specUuid);
        core.getContextManager().removeContext(specUuid, "duel");

        // Clear spectator state
        core.getStateManager().clearState(specUuid);

        spectator.setGameMode(GameMode.SURVIVAL);

        // Send to lobby or restore saved state
        LobbyManager lobby = core.getLobbyManager();
        if (lobby != null && lobby.isEnabled()) {
            lobby.sendToLobby(spectator);
        } else {
            match.restoreSpectatorState(spectator);
        }
        mm().sendMessage(spectator, "spectate.end");
    }

    // ────────────────── Pending Restores ──────────────────

    private void savePendingRestore(DuelMatch match, UUID uuid, int slot) {
        DuelMatch.SavedState state = match.getSavedState(slot);
        pendingRestores.put(uuid, new PendingRestore(
                state.inventory(), state.armor(), state.location(), state.level(), state.exp()));
    }

    /** Called on PlayerJoinEvent to restore inventory for players who disconnected during a duel. */
    public PendingRestore consumePendingRestore(UUID uuid) {
        return pendingRestores.remove(uuid);
    }

    // ────────────────── Queries ──────────────────

    public boolean isInDuel(UUID uuid) {
        DuelMatch match = activeMatches.get(uuid);
        return match != null && match.getState() != DuelState.ENDED;
    }

    public DuelMatch getMatch(UUID playerUuid) {
        return activeMatches.get(playerUuid);
    }

    public DuelRequest getPendingRequest(UUID targetUuid) {
        return pendingRequests.get(targetUuid);
    }

    public Collection<DuelMatch> getActiveMatches() {
        // Return unique matches
        Set<UUID> seen = new HashSet<>();
        List<DuelMatch> result = new ArrayList<>();
        for (DuelMatch match : activeMatches.values()) {
            if (seen.add(match.getMatchId()) && match.getState() != DuelState.ENDED) {
                result.add(match);
            }
        }
        return result;
    }

    public void forceEndAll() {
        for (DuelMatch match : getActiveMatches()) {
            endDuelDraw(match);
        }
        pendingRequests.clear();
    }

    // ────────────────── Helpers ──────────────────

    private void sendMessage(Player player, String key, String... replacements) {
        mm().sendMessage(player, key, replacements);
    }

    private String formatDuration(long ms) {
        long seconds = ms / 1000;
        long minutes = seconds / 60;
        seconds = seconds % 60;
        if (minutes > 0) {
            return minutes + "m " + seconds + "s";
        }
        return seconds + "s";
    }
}
