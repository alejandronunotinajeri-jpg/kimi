package com.ethernova.duels;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.service.ServiceRegistry;
import com.ethernova.duels.api.DuelsAPI;
import com.ethernova.duels.api.DuelsAPIImpl;
import com.ethernova.duels.command.DuelAdminCommand;
import com.ethernova.duels.command.DuelCommand;
import com.ethernova.duels.kit.KitManager;
import com.ethernova.duels.listener.DuelListener;
import com.ethernova.duels.listener.DuelSpectatorListener;
import com.ethernova.duels.manager.ArenaManager;
import com.ethernova.duels.manager.DuelManager;
import com.ethernova.duels.manager.DuelStatsManager;
import com.ethernova.duels.message.MessageManager;
import com.ethernova.duels.placeholder.DuelsPlaceholders;
import com.ethernova.duels.queue.QueueManager;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class EthernovaDuels extends JavaPlugin {

    private static volatile EthernovaDuels instance;
    private EthernovaCore core;

    private KitManager kitManager;
    private ArenaManager arenaManager;
    private DuelStatsManager statsManager;
    private DuelManager duelManager;
    private QueueManager queueManager;
    private MessageManager messageManager;

    @Override
    public void onEnable() {
        instance = this;
        long start = System.currentTimeMillis();

        getLogger().info("═══════════════════════════════════════════");
        getLogger().info("  EthernovaDuels v" + getDescription().getVersion());
        getLogger().info("═══════════════════════════════════════════");

        try {
            // ─── Core Dependency ───
            core = (EthernovaCore) Bukkit.getPluginManager().getPlugin("EthernovaCore");
            if (core == null) {
                getLogger().severe("EthernovaCore no encontrado! Deshabilitando...");
                Bukkit.getPluginManager().disablePlugin(this);
                return;
            }
            core.registerPlugin("EthernovaDuels");

            // ─── Config ───
            saveDefaultConfig();
            reloadConfig();

            // ─── Messages ───
            messageManager = new MessageManager(this);

            // ─── Kit Manager ───
            kitManager = new KitManager(this);
            kitManager.loadKits();

            // ─── Arena Manager ───
            arenaManager = new ArenaManager(this);
            arenaManager.loadArenas();

            // ─── Stats Manager & Database ───
            statsManager = new DuelStatsManager(this, core.getStorageManager());
            statsManager.runMigrations();

            // ─── Duel Manager ───
            duelManager = new DuelManager(this, core);

            // ─── Queue Manager ───
            queueManager = new QueueManager(this, core);

            // ─── Commands ───
            var duelCmd = getCommand("duel");
            if (duelCmd != null) {
                DuelCommand executor = new DuelCommand(this);
                duelCmd.setExecutor(executor);
                duelCmd.setTabCompleter(executor);
            }

            var adminCmd = getCommand("dueladmin");
            if (adminCmd != null) {
                DuelAdminCommand executor = new DuelAdminCommand(this);
                adminCmd.setExecutor(executor);
                adminCmd.setTabCompleter(executor);
            }

            // ─── Listeners ───
            getServer().getPluginManager().registerEvents(new DuelListener(this, core), this);
            getServer().getPluginManager().registerEvents(new DuelSpectatorListener(this, core), this);

            // ─── PlaceholderAPI ───
            if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
                new DuelsPlaceholders(this).register();
                getLogger().info("PlaceholderAPI expansion registered.");
            }

            // ─── Public API ───
            ServiceRegistry.register(DuelsAPI.class, new DuelsAPIImpl(this));
            getLogger().info("✔ DuelsAPI registrada en ServiceRegistry");

            long elapsed = System.currentTimeMillis() - start;
            getLogger().info("EthernovaDuels v" + getDescription().getVersion() + " habilitado en " + elapsed + "ms");

        } catch (Exception e) {
            getLogger().log(java.util.logging.Level.SEVERE, "Error habilitando EthernovaDuels", e);
            e.printStackTrace();
            Bukkit.getPluginManager().disablePlugin(this);
        }
    }

    @Override
    public void onDisable() {
        // Force end all active duels
        if (queueManager != null) {
            queueManager.shutdown();
        }
        if (duelManager != null) {
            duelManager.forceEndAll();
        }

        // Unregister API
        ServiceRegistry.unregister(DuelsAPI.class);

        // Unregister from core
        if (core != null) {
            core.unregisterPlugin("EthernovaDuels");
        }

        instance = null;
        getLogger().info("EthernovaDuels deshabilitado.");
    }

    // ─── Getters ───
    public static EthernovaDuels getInstance() { return instance; }
    public EthernovaCore getCore() { return core; }
    public KitManager getKitManager() { return kitManager; }
    public ArenaManager getArenaManager() { return arenaManager; }
    public DuelStatsManager getStatsManager() { return statsManager; }
    public DuelManager getDuelManager() { return duelManager; }
    public QueueManager getQueueManager() { return queueManager; }
    public MessageManager getMessageManager() { return messageManager; }
}
