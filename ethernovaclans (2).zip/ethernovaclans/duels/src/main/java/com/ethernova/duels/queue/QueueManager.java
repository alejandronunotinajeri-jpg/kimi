package com.ethernova.duels.queue;

import com.ethernova.core.api.CombatAPI;
import com.ethernova.core.EthernovaCore;
import com.ethernova.core.lobby.LobbyManager;
import com.ethernova.core.service.ServiceRegistry;
import com.ethernova.duels.EthernovaDuels;
import com.ethernova.duels.manager.ArenaManager;
import com.ethernova.duels.message.MessageManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Handles matchmaking queue for unranked duels.
 * <p>
 * Flow:
 * <ol>
 *   <li>Player selects a kit (via GUI or command)</li>
 *   <li>Player enters queue: inventory cleared, cancel item in slot 8</li>
 *   <li>Player can walk around the lobby while waiting</li>
 *   <li>When 2 players queue for the same kit: match found → start duel</li>
 *   <li>Cancel: right-click cancel item → remove from queue → back to lobby</li>
 * </ol>
 */
public class QueueManager {

    private final EthernovaDuels plugin;
    private final EthernovaCore core;
    private final MiniMessage mini = MiniMessage.miniMessage();

    // Kit ID → ordered queue of player UUIDs
    private final Map<String, Queue<UUID>> kitQueues = new ConcurrentHashMap<>();
    // Player UUID → kit they're queued for (reverse lookup)
    private final Map<UUID, String> playerQueue = new ConcurrentHashMap<>();
    // Match-checking task
    private BukkitTask matchTask;

    public QueueManager(EthernovaDuels plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;

        // Periodically try to match players (every 20 ticks / 1 second)
        matchTask = Bukkit.getScheduler().runTaskTimer(plugin, this::tryMatchAll, 20L, 20L);
    }

    private MessageManager mm() { return plugin.getMessageManager(); }

    // ────────────────── Join Queue ──────────────────

    /**
     * Add a player to the matchmaking queue for a specific kit.
     */
    public void joinQueue(Player player, String kitId) {
        UUID uuid = player.getUniqueId();

        // Already in queue?
        if (playerQueue.containsKey(uuid)) {
            mm().sendMessage(player, "queue.already-in-queue");
            return;
        }

        // Already in a duel?
        if (plugin.getDuelManager().isInDuel(uuid)) {
            mm().sendMessage(player, "validation.already-in-duel");
            return;
        }

        // In combat?
        CombatAPI combatAPI = ServiceRegistry.get(CombatAPI.class);
        if (combatAPI != null && combatAPI.isInCombat(player)) {
            mm().sendMessage(player, "validation.in-combat");
            return;
        }

        // Kit exists?
        if (!plugin.getKitManager().kitExists(kitId)) {
            mm().sendMessage(player, "validation.kit-not-found");
            return;
        }

        // Add to queue
        playerQueue.put(uuid, kitId);
        kitQueues.computeIfAbsent(kitId.toLowerCase(), k -> new ConcurrentLinkedQueue<>()).add(uuid);

        // Set player state
        core.getStateManager().setState(uuid, "queue", kitId);
        core.getContextManager().addContext(uuid, "queue");

        // Clear inventory and give cancel item
        player.getInventory().clear();
        player.getActivePotionEffects().forEach(e -> player.removePotionEffect(e.getType()));
        player.setHealth(player.getMaxHealth());
        player.setFoodLevel(20);

        LobbyManager lobby = core.getLobbyManager();
        if (lobby != null) {
            ItemStack cancelItem = lobby.createQueueCancelItem();
            player.getInventory().setItem(8, cancelItem);
        }

        String kitName = plugin.getKitManager().getKit(kitId).getName();
        mm().sendMessage(player, "queue.joined", "{kit}", kitName);
        core.getSoundManager().play(player, "click");

        // Try immediate match
        tryMatch(kitId.toLowerCase());
    }

    // ────────────────── Leave Queue ──────────────────

    /**
     * Remove a player from the queue and send back to lobby.
     */
    public void leaveQueue(Player player) {
        UUID uuid = player.getUniqueId();
        String kitId = playerQueue.remove(uuid);

        if (kitId == null) {
            mm().sendMessage(player, "queue.not-in-queue");
            return;
        }

        Queue<UUID> queue = kitQueues.get(kitId.toLowerCase());
        if (queue != null) {
            queue.remove(uuid);
        }

        // Clear context
        core.getContextManager().removeContext(uuid, "queue");
        core.getStateManager().clearState(uuid);

        // Send back to lobby
        LobbyManager lobby = core.getLobbyManager();
        if (lobby != null && lobby.isEnabled()) {
            lobby.sendToLobby(player);
        } else {
            player.getInventory().clear();
        }

        mm().sendMessage(player, "queue.left");
        core.getSoundManager().play(player, "click");
    }

    /**
     * Silently remove a player from queue (disconnect, etc.) without messages.
     */
    public void forceLeaveQueue(UUID uuid) {
        String kitId = playerQueue.remove(uuid);
        if (kitId == null) return;

        Queue<UUID> queue = kitQueues.get(kitId.toLowerCase());
        if (queue != null) {
            queue.remove(uuid);
        }

        core.getContextManager().removeContext(uuid, "queue");
        core.getStateManager().clearState(uuid);
    }

    // ────────────────── Match Logic ──────────────────

    /**
     * Try to match players across all kits.
     */
    private void tryMatchAll() {
        for (String kitId : kitQueues.keySet()) {
            tryMatch(kitId);
        }
    }

    /**
     * Try to match 2 players for a given kit.
     */
    private void tryMatch(String kitId) {
        Queue<UUID> queue = kitQueues.get(kitId);
        if (queue == null || queue.size() < 2) return;

        // Check arena availability
        ArenaManager.Arena arena = plugin.getArenaManager().getAvailableArena();
        if (arena == null) return;

        // Take 2 players from queue (skip offline/already matched)
        UUID uuid1 = pollValid(queue, kitId);
        if (uuid1 == null) return;

        UUID uuid2 = pollValid(queue, kitId);
        if (uuid2 == null) {
            // Put first player back
            queue.add(uuid1);
            return;
        }

        Player p1 = Bukkit.getPlayer(uuid1);
        Player p2 = Bukkit.getPlayer(uuid2);

        if (p1 == null || p2 == null) {
            plugin.getArenaManager().releaseArena(arena.name);
            return;
        }

        // Remove from tracking
        playerQueue.remove(uuid1);
        playerQueue.remove(uuid2);
        core.getContextManager().removeContext(uuid1, "queue");
        core.getContextManager().removeContext(uuid2, "queue");

        // Notify
        mm().sendMessage(p1, "queue.match-found", "{opponent}", p2.getName());
        mm().sendMessage(p2, "queue.match-found", "{opponent}", p1.getName());
        core.getSoundManager().play(p1, "success");
        core.getSoundManager().play(p2, "success");

        // Start the duel (DuelManager handles clearing inventory, applying kit, etc.)
        plugin.getDuelManager().startQueuedDuel(p1, p2, kitId, arena);
    }

    /**
     * Poll a valid (online, still queued) player from the queue.
     */
    private UUID pollValid(Queue<UUID> queue, String kitId) {
        while (!queue.isEmpty()) {
            UUID uuid = queue.poll();
            if (uuid == null) return null;

            Player player = Bukkit.getPlayer(uuid);
            if (player != null && player.isOnline() && playerQueue.containsKey(uuid)) {
                return uuid;
            }
            // Stale entry — remove from tracking
            playerQueue.remove(uuid);
        }
        return null;
    }

    // ────────────────── Queries ──────────────────

    public boolean isInQueue(UUID uuid) {
        return playerQueue.containsKey(uuid);
    }

    public String getQueuedKit(UUID uuid) {
        return playerQueue.get(uuid);
    }

    public int getQueueSize(String kitId) {
        Queue<UUID> queue = kitQueues.get(kitId.toLowerCase());
        return queue != null ? queue.size() : 0;
    }

    public int getTotalQueueSize() {
        return playerQueue.size();
    }

    // ────────────────── Shutdown ──────────────────

    public void shutdown() {
        if (matchTask != null) {
            matchTask.cancel();
            matchTask = null;
        }

        // Send all queued players back to lobby
        for (UUID uuid : new ArrayList<>(playerQueue.keySet())) {
            Player player = Bukkit.getPlayer(uuid);
            if (player != null && player.isOnline()) {
                leaveQueue(player);
            } else {
                forceLeaveQueue(uuid);
            }
        }

        kitQueues.clear();
        playerQueue.clear();
    }
}
