package com.ethernova.duels.manager;

import com.ethernova.duels.EthernovaDuels;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class ArenaManager {

    private final EthernovaDuels plugin;
    private final Map<String, Arena> arenas = new ConcurrentHashMap<>();

    public ArenaManager(EthernovaDuels plugin) {
        this.plugin = plugin;
    }

    public void loadArenas() {
        arenas.clear();
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("arenas");
        if (section == null) return;

        for (String name : section.getKeys(false)) {
            ConfigurationSection arenaSection = section.getConfigurationSection(name);
            if (arenaSection == null) continue;

            Location spawn1 = deserializeLocation(arenaSection.getConfigurationSection("spawn1"));
            Location spawn2 = deserializeLocation(arenaSection.getConfigurationSection("spawn2"));

            if (spawn1 != null && spawn2 != null) {
                Arena arena = new Arena(name, spawn1, spawn2, false);
                arena.regionPos1 = deserializeLocation(arenaSection.getConfigurationSection("region-pos1"));
                arena.regionPos2 = deserializeLocation(arenaSection.getConfigurationSection("region-pos2"));
                arenas.put(name.toLowerCase(), arena);
                plugin.getLogger().info("Arena cargada: " + name);
            }
        }
        plugin.getLogger().info(arenas.size() + " arenas cargadas.");
    }

    public Arena getAvailableArena() {
        for (Arena arena : arenas.values()) {
            if (!arena.inUse) {
                arena.inUse = true;
                return arena;
            }
        }
        return null;
    }

    public void releaseArena(String name) {
        Arena arena = arenas.get(name.toLowerCase());
        if (arena != null) {
            arena.inUse = false;
        }
    }

    public boolean createArena(String name, Location spawn1, Location spawn2) {
        if (arenas.containsKey(name.toLowerCase())) return false;

        Arena arena = new Arena(name, spawn1, spawn2, false);
        arenas.put(name.toLowerCase(), arena);
        saveArena(name.toLowerCase(), arena);
        return true;
    }

    public boolean setSpawn(String name, int spawnNumber, Location location) {
        Arena arena = arenas.get(name.toLowerCase());
        if (arena == null) return false;

        if (spawnNumber == 1) {
            arena.spawn1 = location.clone();
        } else if (spawnNumber == 2) {
            arena.spawn2 = location.clone();
        } else {
            return false;
        }

        saveArena(name.toLowerCase(), arena);
        return true;
    }

    public boolean setRegion(String name, Location pos1, Location pos2) {
        Arena arena = arenas.get(name.toLowerCase());
        if (arena == null) return false;
        arena.regionPos1 = pos1.clone();
        arena.regionPos2 = pos2.clone();
        saveArena(name.toLowerCase(), arena);
        return true;
    }

    public boolean deleteArena(String name) {
        Arena removed = arenas.remove(name.toLowerCase());
        if (removed == null) return false;

        plugin.getConfig().set("arenas." + name.toLowerCase(), null);
        plugin.saveConfig();
        return true;
    }

    public Arena getArena(String name) {
        return arenas.get(name.toLowerCase());
    }

    public Collection<Arena> getAllArenas() {
        return Collections.unmodifiableCollection(arenas.values());
    }

    public Set<String> getArenaNames() {
        return Collections.unmodifiableSet(arenas.keySet());
    }

    private void saveArena(String name, Arena arena) {
        String path = "arenas." + name;
        serializeLocation(path + ".spawn1", arena.spawn1);
        serializeLocation(path + ".spawn2", arena.spawn2);
        if (arena.regionPos1 != null) serializeLocation(path + ".region-pos1", arena.regionPos1);
        if (arena.regionPos2 != null) serializeLocation(path + ".region-pos2", arena.regionPos2);
        plugin.saveConfig();
    }

    private void serializeLocation(String path, Location loc) {
        if (loc == null || loc.getWorld() == null) return;
        plugin.getConfig().set(path + ".world", loc.getWorld().getName());
        plugin.getConfig().set(path + ".x", loc.getX());
        plugin.getConfig().set(path + ".y", loc.getY());
        plugin.getConfig().set(path + ".z", loc.getZ());
        plugin.getConfig().set(path + ".yaw", (double) loc.getYaw());
        plugin.getConfig().set(path + ".pitch", (double) loc.getPitch());
    }

    private Location deserializeLocation(ConfigurationSection section) {
        if (section == null) return null;
        String worldName = section.getString("world");
        if (worldName == null) return null;

        var world = org.bukkit.Bukkit.getWorld(worldName);
        if (world == null) return null;

        return new Location(
                world,
                section.getDouble("x"),
                section.getDouble("y"),
                section.getDouble("z"),
                (float) section.getDouble("yaw"),
                (float) section.getDouble("pitch")
        );
    }

    public static class Arena {
        public final String name;
        public Location spawn1;
        public Location spawn2;
        public volatile boolean inUse;
        /** Region corner 1 for rollback (nullable — rollback disabled if null) */
        public Location regionPos1;
        /** Region corner 2 for rollback (nullable) */
        public Location regionPos2;

        public Arena(String name, Location spawn1, Location spawn2, boolean inUse) {
            this.name = name;
            this.spawn1 = spawn1;
            this.spawn2 = spawn2;
            this.inUse = inUse;
        }

        public boolean hasRegion() {
            return regionPos1 != null && regionPos2 != null;
        }
    }
}
