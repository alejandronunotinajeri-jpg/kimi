package com.ethernova.duels.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.CoreGui;
import com.ethernova.duels.EthernovaDuels;
import com.ethernova.duels.message.MessageManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Invite GUI — displays online players as heads so the user
 * can click one to challenge them to a duel.
 * Paginated: up to 21 players per page.
 */
public class DuelInviteGui extends CoreGui {

    private final EthernovaDuels plugin;
    private final int page;
    private final List<Player> candidates;

    public DuelInviteGui(EthernovaCore core, EthernovaDuels plugin, Player player) {
        this(core, plugin, player, 0);
    }

    public DuelInviteGui(EthernovaCore core, EthernovaDuels plugin, Player player, int page) {
        super(core, player);
        this.plugin = plugin;
        this.page = page;
        this.candidates = Bukkit.getOnlinePlayers().stream()
                .map(p -> (Player) p)
                .filter(p -> !p.equals(player))
                .sorted((a, b) -> a.getName().compareToIgnoreCase(b.getName()))
                .toList();
    }

    private MessageManager mm() { return plugin.getMessageManager(); }

    public void open() {
        openInventory("<gradient:#55ff55:#55ffff><bold>✉ Invitar a Duelo</bold></gradient>", 54);
    }

    @Override
    protected void populateItems() {
        // ── Player heads ──
        int slotsPerPage = 21;
        int startIndex = page * slotsPerPage;
        int[] contentSlots = {
                10, 11, 12, 13, 14, 15, 16,
                19, 20, 21, 22, 23, 24, 25,
                28, 29, 30, 31, 32, 33, 34
        };

        for (int i = 0; i < contentSlots.length; i++) {
            int idx = startIndex + i;
            if (idx >= candidates.size()) break;

            Player target = candidates.get(idx);
            ItemStack head = createPlayerHead(target,
                    "<green>" + target.getName(),
                    List.of(
                            "",
                            "<gray>Click para retar a duelo",
                            "<yellow>▸ Selecciona kit en el siguiente menú"
                    ));
            setItem(contentSlots[i], head);
            slotActions.put(contentSlots[i], "PLAYER_" + target.getUniqueId());
        }

        // ── Pagination ──
        int maxPages = Math.max(1, (int) Math.ceil((double) candidates.size() / slotsPerPage));
        if (page > 0) {
            setItem(48, createItem(Material.ARROW, "<yellow>← Página anterior"));
            slotActions.put(48, "PREV_PAGE");
        }
        setItem(49, createItem(Material.PAPER, "<gray>Página " + (page + 1) + "/" + maxPages));

        if (startIndex + slotsPerPage < candidates.size()) {
            setItem(50, createItem(Material.ARROW, "<yellow>Página siguiente →"));
            slotActions.put(50, "NEXT_PAGE");
        }

        // ── Back + Close ──
        setItem(45, createItem(Material.ARROW, "<gray>← Volver"));
        slotActions.put(45, "BACK");

        setItem(53, createItem(Material.BARRIER, "<red>Cerrar"));
        slotActions.put(53, "CLOSE");

        // ── Info ──
        setItem(4, createItem(Material.OAK_SIGN,
                "<white><bold>Selecciona un jugador</bold>",
                List.of(
                        "",
                        "<gray>O usa el comando:",
                        "<white>/duel invite <nombre>",
                        "<white>/duel invite <nombre> <apuesta>"
                )));
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.equals("BACK")) {
            playSound("click");
            player.closeInventory();
            core.getGuiManager().unregisterGui(player.getUniqueId());
            new DuelMenuGui(core, plugin, player).open();
            return true;
        }
        if (action.equals("PREV_PAGE")) {
            playSound("click");
            player.closeInventory();
            core.getGuiManager().unregisterGui(player.getUniqueId());
            new DuelInviteGui(core, plugin, player, page - 1).open();
            return true;
        }
        if (action.equals("NEXT_PAGE")) {
            playSound("click");
            player.closeInventory();
            core.getGuiManager().unregisterGui(player.getUniqueId());
            new DuelInviteGui(core, plugin, player, page + 1).open();
            return true;
        }
        if (action.startsWith("PLAYER_")) {
            String uuidStr = action.substring(7);
            UUID targetUuid;
            try {
                targetUuid = UUID.fromString(uuidStr);
            } catch (IllegalArgumentException e) {
                return true;
            }

            Player target = Bukkit.getPlayer(targetUuid);
            if (target == null || !target.isOnline()) {
                mm().sendMessage(player, "general.player-not-found");
                return true;
            }

            playSound("click");
            player.closeInventory();
            core.getGuiManager().unregisterGui(player.getUniqueId());

            // Open kit selection for challenging this player
            new DuelGui(core, plugin, player, targetUuid, target.getName()).open();
            return true;
        }
        return false;
    }

    // ── Helper: player head ──
    private ItemStack createPlayerHead(Player headPlayer, String displayName, List<String> lore) {
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) skull.getItemMeta();
        meta.setOwningPlayer(headPlayer);
        meta.displayName(mini.deserialize(displayName));
        meta.lore(lore.stream().map(mini::deserialize).toList());
        skull.setItemMeta(meta);
        return skull;
    }
}
