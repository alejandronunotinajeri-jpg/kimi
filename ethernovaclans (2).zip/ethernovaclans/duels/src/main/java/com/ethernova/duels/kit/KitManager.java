package com.ethernova.duels.kit;

import com.ethernova.duels.EthernovaDuels;
import com.ethernova.duels.model.DuelKit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

public class KitManager {

    private final EthernovaDuels plugin;
    private final Map<String, DuelKit> kits = new ConcurrentHashMap<>();

    public KitManager(EthernovaDuels plugin) {
        this.plugin = plugin;
    }

    public void loadKits() {
        kits.clear();
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("kits");
        if (section == null) {
            plugin.getLogger().warning("No se encontró la sección 'kits' en config.yml");
            return;
        }

        for (String kitId : section.getKeys(false)) {
            ConfigurationSection kitSection = section.getConfigurationSection(kitId);
            if (kitSection == null) continue;

            try {
                String name = kitSection.getString("name", "<white>" + kitId);
                Material icon = Material.matchMaterial(kitSection.getString("icon", "IRON_SWORD"));
                if (icon == null) icon = Material.IRON_SWORD;

                List<String> description = kitSection.getStringList("description");

                // Parse armor
                ItemStack[] armor = parseArmor(kitSection.getConfigurationSection("armor"));

                // Parse inventory items
                ItemStack[] inventory = parseInventory(kitSection.getStringList("items"));

                // Parse effects
                List<PotionEffect> effects = parseEffects(kitSection.getStringList("effects"));

                boolean noNaturalRegen = kitSection.getBoolean("no-natural-regen", false);

                DuelKit kit = new DuelKit(kitId, name, icon, description, armor, inventory, effects, noNaturalRegen);
                kits.put(kitId.toLowerCase(), kit);
                plugin.getLogger().info("Kit cargado: " + kitId);

            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Error cargando kit '" + kitId + "'", e);
            }
        }

        plugin.getLogger().info(kits.size() + " kits cargados.");
    }

    private ItemStack[] parseArmor(ConfigurationSection armorSection) {
        ItemStack[] armor = new ItemStack[4];
        if (armorSection == null) return armor;

        armor[3] = parseMaterial(armorSection.getString("helmet", ""));
        armor[2] = parseMaterial(armorSection.getString("chestplate", ""));
        armor[1] = parseMaterial(armorSection.getString("leggings", ""));
        armor[0] = parseMaterial(armorSection.getString("boots", ""));

        return armor;
    }

    private ItemStack[] parseInventory(List<String> items) {
        List<ItemStack> parsed = new ArrayList<>();
        for (String entry : items) {
            String[] parts = entry.split(":");
            Material mat = Material.matchMaterial(parts[0]);
            if (mat == null) continue;
            int amount = parts.length > 1 ? Integer.parseInt(parts[1]) : 1;
            parsed.add(new ItemStack(mat, amount));
        }

        ItemStack[] inv = new ItemStack[36];
        for (int i = 0; i < Math.min(parsed.size(), 36); i++) {
            inv[i] = parsed.get(i);
        }
        return inv;
    }

    private List<PotionEffect> parseEffects(List<String> effectStrings) {
        List<PotionEffect> effects = new ArrayList<>();
        if (effectStrings == null) return effects;

        for (String entry : effectStrings) {
            if (entry.isEmpty()) continue;
            String[] parts = entry.split(":");
            if (parts.length < 3) continue;

            PotionEffectType type = PotionEffectType.getByName(parts[0]);
            if (type == null) continue;

            int amplifier = Integer.parseInt(parts[1]);
            int durationSeconds = Integer.parseInt(parts[2]);

            effects.add(new PotionEffect(type, durationSeconds * 20, amplifier, false, false, true));
        }
        return effects;
    }

    private ItemStack parseMaterial(String name) {
        if (name == null || name.isEmpty()) return null;
        Material mat = Material.matchMaterial(name);
        return mat != null ? new ItemStack(mat) : null;
    }

    public DuelKit getKit(String id) {
        return kits.get(id.toLowerCase());
    }

    public Collection<DuelKit> getAllKits() {
        return Collections.unmodifiableCollection(kits.values());
    }

    public Set<String> getKitIds() {
        return Collections.unmodifiableSet(kits.keySet());
    }

    public boolean kitExists(String id) {
        return kits.containsKey(id.toLowerCase());
    }

    /**
     * Create a kit from a player's current inventory and save to config.
     */
    public boolean createKitFromPlayer(String id, String name, org.bukkit.entity.Player player) {
        if (kitExists(id)) return false;

        Material icon = player.getInventory().getItemInMainHand().getType();
        if (icon.isAir()) icon = Material.IRON_SWORD;

        ItemStack[] armor = player.getInventory().getArmorContents();
        ItemStack[] inv = new ItemStack[36];
        for (int i = 0; i < 36; i++) {
            ItemStack item = player.getInventory().getItem(i);
            if (item != null && !item.getType().isAir()) inv[i] = item.clone();
        }

        List<org.bukkit.potion.PotionEffect> effects = new ArrayList<>(player.getActivePotionEffects());

        DuelKit kit = new DuelKit(id, name, icon, List.of("<gray>Kit personalizado"), armor, inv, effects, false);
        kits.put(id.toLowerCase(), kit);
        saveKitToConfig(id.toLowerCase(), kit);
        return true;
    }

    /**
     * Delete a kit from memory and config.
     */
    public boolean deleteKit(String id) {
        DuelKit removed = kits.remove(id.toLowerCase());
        if (removed == null) return false;
        plugin.getConfig().set("kits." + id.toLowerCase(), null);
        plugin.saveConfig();
        return true;
    }

    private void saveKitToConfig(String id, DuelKit kit) {
        String path = "kits." + id;
        plugin.getConfig().set(path + ".name", kit.getName());
        plugin.getConfig().set(path + ".icon", kit.getIcon().name());
        plugin.getConfig().set(path + ".description", kit.getDescription());

        // Armor
        if (kit.getArmor() != null) {
            ItemStack[] a = kit.getArmor();
            if (a[3] != null) plugin.getConfig().set(path + ".armor.helmet", a[3].getType().name());
            if (a[2] != null) plugin.getConfig().set(path + ".armor.chestplate", a[2].getType().name());
            if (a[1] != null) plugin.getConfig().set(path + ".armor.leggings", a[1].getType().name());
            if (a[0] != null) plugin.getConfig().set(path + ".armor.boots", a[0].getType().name());
        }

        // Items
        List<String> items = new ArrayList<>();
        if (kit.getInventory() != null) {
            for (ItemStack item : kit.getInventory()) {
                if (item != null && !item.getType().isAir()) {
                    items.add(item.getType().name() + ":" + item.getAmount());
                }
            }
        }
        plugin.getConfig().set(path + ".items", items);

        // Effects
        List<String> effectList = new ArrayList<>();
        if (kit.getEffects() != null) {
            for (var effect : kit.getEffects()) {
                effectList.add(effect.getType().getName() + ":" + effect.getAmplifier() + ":" + (effect.getDuration() / 20));
            }
        }
        plugin.getConfig().set(path + ".effects", effectList);

        plugin.saveConfig();
    }
}
