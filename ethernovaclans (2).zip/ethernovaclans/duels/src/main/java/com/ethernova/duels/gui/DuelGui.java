package com.ethernova.duels.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.CoreGui;
import com.ethernova.duels.EthernovaDuels;
import com.ethernova.duels.message.MessageManager;
import com.ethernova.duels.model.DuelKit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

public class DuelGui extends CoreGui {

    private final EthernovaDuels plugin;
    private final UUID targetUuid;
    private final String targetName;

    public DuelGui(EthernovaCore core, EthernovaDuels plugin, Player player, UUID targetUuid, String targetName) {
        super(core, player);
        this.plugin = plugin;
        this.targetUuid = targetUuid;
        this.targetName = targetName;
    }

    private MessageManager mm() { return plugin.getMessageManager(); }

    public void open() {
        openInventory(mm().get("gui.kit-selection.title", "{target}", targetName), 36);
    }

    @Override
    protected void populateItems() {
        // Header
        setItem(4, createItem(Material.IRON_SWORD, mm().get("gui.kit-selection.title", "{target}", targetName)));

        Collection<DuelKit> kits = plugin.getKitManager().getAllKits();
        int[] slots = {10, 11, 12, 13, 14, 15, 16};
        int index = 0;

        for (DuelKit kit : kits) {
            if (index >= slots.length) break;

            int slot = slots[index++];
            List<String> lore = new ArrayList<>();
            lore.add("");
            for (String line : kit.getDescription()) {
                lore.add("<dark_gray>▎ " + line);
            }
            lore.add("");
            lore.add("<dark_gray>▎ " + mm().get("gui.kit-selection.click-to-select"));

            ItemStack item = createItem(kit.getIcon(), "<gold>" + kit.getName(), lore);
            setItem(slot, item);
            slotActions.put(slot, "KIT_" + kit.getId());
        }

        // Close button
        setItem(31, createItem(Material.BARRIER, mm().get("gui.kit-selection.cancel")));
        slotActions.put(31, "CLOSE");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.startsWith("KIT_")) {
            String kitId = action.substring(4);

            playSound("click");
            player.closeInventory();
            core.getGuiManager().unregisterGui(player.getUniqueId());

            Player target = org.bukkit.Bukkit.getPlayer(targetUuid);
            if (target == null || !target.isOnline()) {
                mm().sendMessage(player, "general.player-not-found");
                return true;
            }

            plugin.getDuelManager().sendRequest(player, target, kitId, 0);
            return true;
        }
        return false;
    }
}
