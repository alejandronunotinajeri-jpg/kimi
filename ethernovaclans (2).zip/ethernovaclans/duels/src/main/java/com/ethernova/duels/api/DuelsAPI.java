package com.ethernova.duels.api;

import com.ethernova.duels.model.DuelMatch;

import java.util.Collection;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * Public API interface for EthernovaDuels.
 *
 * <p>Provides methods for querying duel match state, player statistics,
 * kit information, and arena availability.</p>
 *
 * <p>Obtain an instance via {@code ServiceRegistry.get(DuelsAPI.class)}.</p>
 *
 * <p>All methods are thread-safe. Cached stat methods return data from an
 * in-memory cache. Async methods return {@link CompletableFuture}
 * and perform I/O off-thread.</p>
 */
public interface DuelsAPI {

    // ═══════════════ Match State ═══════════════

    /**
     * Check if a player is currently in a duel.
     *
     * @param uuid the UUID of the player
     * @return {@code true} if the player is in an active duel
     */
    boolean isInDuel(UUID uuid);

    /**
     * Get the active match for a player.
     *
     * @param playerUuid the UUID of the player
     * @return the active {@link DuelMatch}, or {@code null} if the player is not in a duel
     */
    DuelMatch getMatch(UUID playerUuid);

    /**
     * Get all currently active duel matches.
     *
     * @return an unmodifiable collection of active {@link DuelMatch} instances
     */
    Collection<DuelMatch> getActiveMatches();

    // ═══════════════ Stats (Sync Cache) ═══════════════

    /**
     * Get total duel wins from the statistics cache.
     *
     * @param uuid the UUID of the player
     * @return total duel wins
     */
    int getDuelWins(UUID uuid);

    /**
     * Get total duel losses from the statistics cache.
     *
     * @param uuid the UUID of the player
     * @return total duel losses
     */
    int getDuelLosses(UUID uuid);

    /**
     * Get the duel win rate percentage from the statistics cache.
     *
     * @param uuid the UUID of the player
     * @return the win rate as a percentage (0.0–100.0)
     */
    double getDuelWinRate(UUID uuid);

    /**
     * Get the best duel win streak from the statistics cache.
     *
     * @param uuid the UUID of the player
     * @return the highest consecutive win count recorded
     */
    int getDuelBestStreak(UUID uuid);

    // ═══════════════ Stats (Async Detailed) ═══════════════

    /**
     * Get per-kit duel statistics asynchronously.
     *
     * <p>The returned map keys are kit IDs, and values are integer arrays:
     * {@code [wins, losses, win_streak, best_streak]}.</p>
     *
     * @param uuid the UUID of the player
     * @return a {@link CompletableFuture} resolving to a map of kit ID to stats array
     */
    CompletableFuture<java.util.Map<String, int[]>> getDetailedStats(UUID uuid);

    // ═══════════════ Kit Info ═══════════════

    /**
     * Get all available duel kit identifiers.
     *
     * @return a set of kit IDs
     */
    java.util.Set<String> getAvailableKitIds();

    /**
     * Check if a kit with the given ID exists.
     *
     * @param kitId the kit identifier to check
     * @return {@code true} if the kit exists
     */
    boolean kitExists(String kitId);

    // ═══════════════ Arena Info ═══════════════

    /**
     * Get all duel arena names.
     *
     * @return a set of arena name strings
     */
    java.util.Set<String> getArenaNames();

    /**
     * Get the number of arenas currently available (not in use).
     *
     * @return the count of free arenas
     */
    int getAvailableArenaCount();
}
