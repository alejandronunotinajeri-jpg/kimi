package com.ethernova.duels.model;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class DuelRequestTest {

    @Test
    @DisplayName("Fields are accessible")
    void fields() {
        UUID sender = UUID.randomUUID();
        UUID target = UUID.randomUUID();
        DuelRequest req = new DuelRequest(sender, "Alice", target, "classic", 100.0,
                System.currentTimeMillis() + 60_000);

        assertEquals(sender, req.senderUuid());
        assertEquals("Alice", req.senderName());
        assertEquals(target, req.targetUuid());
        assertEquals("classic", req.kit());
        assertEquals(100.0, req.betAmount());
    }

    @Nested
    @DisplayName("isExpired()")
    class ExpiryTests {
        @Test
        void notExpiredWhenFuture() {
            DuelRequest req = new DuelRequest(UUID.randomUUID(), "A", UUID.randomUUID(),
                    "kit", 0, System.currentTimeMillis() + 60_000);
            assertFalse(req.isExpired());
        }

        @Test
        void expiredWhenPast() {
            DuelRequest req = new DuelRequest(UUID.randomUUID(), "A", UUID.randomUUID(),
                    "kit", 0, System.currentTimeMillis() - 1000);
            assertTrue(req.isExpired());
        }

        @Test
        void expiredAtExactTime() {
            long now = System.currentTimeMillis();
            DuelRequest req = new DuelRequest(UUID.randomUUID(), "A", UUID.randomUUID(),
                    "kit", 0, now);
            assertTrue(req.isExpired());
        }
    }
}
