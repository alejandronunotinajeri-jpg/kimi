package com.ethernova.duels.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class DuelMatchTest {

    private UUID p1, p2;
    private DuelMatch match;

    @BeforeEach
    void setUp() {
        p1 = UUID.randomUUID();
        p2 = UUID.randomUUID();
        match = new DuelMatch(UUID.randomUUID(), p1, p2, "classic", 50.0, null, null, "arena1");
    }

    @Nested
    @DisplayName("Getters")
    class GetterTests {
        @Test void player1() { assertEquals(p1, match.getPlayer1()); }
        @Test void player2() { assertEquals(p2, match.getPlayer2()); }
        @Test void kit() { assertEquals("classic", match.getKit()); }
        @Test void betAmount() { assertEquals(50.0, match.getBetAmount()); }
        @Test void arenaName() { assertEquals("arena1", match.getArenaName()); }
        @Test void initialState() { assertEquals(DuelState.COUNTDOWN, match.getState()); }
    }

    @Nested
    @DisplayName("isParticipant()")
    class ParticipantTests {
        @Test void player1IsParticipant() { assertTrue(match.isParticipant(p1)); }
        @Test void player2IsParticipant() { assertTrue(match.isParticipant(p2)); }
        @Test void randomNotParticipant() { assertFalse(match.isParticipant(UUID.randomUUID())); }
    }

    @Nested
    @DisplayName("getOpponent()")
    class OpponentTests {
        @Test void p1OpponentIsP2() { assertEquals(p2, match.getOpponent(p1)); }
        @Test void p2OpponentIsP1() { assertEquals(p1, match.getOpponent(p2)); }
        @Test void randomReturnsNull() { assertNull(match.getOpponent(UUID.randomUUID())); }
    }

    @Nested
    @DisplayName("getPlayerSlot()")
    class SlotTests {
        @Test void player1IsSlot1() { assertEquals(1, match.getPlayerSlot(p1)); }
        @Test void player2IsSlot2() { assertEquals(2, match.getPlayerSlot(p2)); }
        @Test void unknownIsNegative1() { assertEquals(-1, match.getPlayerSlot(UUID.randomUUID())); }
    }

    @Nested
    @DisplayName("State transitions")
    class StateTests {
        @Test
        void setState() {
            match.setState(DuelState.FIGHTING);
            assertEquals(DuelState.FIGHTING, match.getState());
        }

        @Test
        void fullLifecycle() {
            assertEquals(DuelState.COUNTDOWN, match.getState());
            match.setState(DuelState.FIGHTING);
            assertEquals(DuelState.FIGHTING, match.getState());
            match.setState(DuelState.ENDED);
            assertEquals(DuelState.ENDED, match.getState());
        }
    }

    @Nested
    @DisplayName("Spectators")
    class SpectatorTests {
        @Test
        void addAndCheckSpectator() {
            UUID spec = UUID.randomUUID();
            match.addSpectator(spec);
            assertTrue(match.isSpectator(spec));
        }

        @Test
        void removeSpectator() {
            UUID spec = UUID.randomUUID();
            match.addSpectator(spec);
            match.removeSpectator(spec);
            assertFalse(match.isSpectator(spec));
        }

        @Test
        void getSpectators() {
            UUID s1 = UUID.randomUUID();
            UUID s2 = UUID.randomUUID();
            match.addSpectator(s1);
            match.addSpectator(s2);
            assertEquals(2, match.getSpectators().size());
        }

        @Test
        void nonSpectatorReturnsFalse() {
            assertFalse(match.isSpectator(UUID.randomUUID()));
        }
    }

    @Nested
    @DisplayName("getDurationMs()")
    class DurationTests {
        @Test
        void durationIsPositiveImmediately() {
            assertTrue(match.getDurationMs() >= 0);
        }
    }
}
