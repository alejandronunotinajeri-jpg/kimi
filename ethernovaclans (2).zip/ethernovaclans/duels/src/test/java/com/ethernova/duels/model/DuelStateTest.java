package com.ethernova.duels.model;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DuelStateTest {

    @Test
    @DisplayName("Three states exist")
    void threeStates() {
        assertEquals(3, DuelState.values().length);
    }

    @Test
    @DisplayName("States have expected names")
    void stateNames() {
        assertNotNull(DuelState.valueOf("COUNTDOWN"));
        assertNotNull(DuelState.valueOf("FIGHTING"));
        assertNotNull(DuelState.valueOf("ENDED"));
    }
}
