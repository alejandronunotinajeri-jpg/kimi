# EthernovaClans — Deep Bug Audit Report

**Date:** 2025  
**Platform:** Minecraft Paper 1.21.4 / Java 21  
**Type:** Read-Only Static Analysis  
**Scope:** 7 plugin modules — Clans, Cosmetics, Party, Progression, Ranked, Duels, FFA (+ Core)

---

## Severity Definitions

| Severity | Meaning |
|----------|---------|
| **CRITICAL** | Data loss, economy corruption, or crash under normal operation |
| **HIGH** | Exploitable by players or causes wrong behavior under realistic conditions |
| **MEDIUM** | Bug triggers under specific (but possible) conditions |
| **LOW** | Theoretically unsafe; requires unusual circumstances to trigger |

---

## BUG #1 — CRITICAL: Progression onDisable Does Not Save Achievements or Missions

**Module:** Progression  
**File:** `progression/src/main/java/com/ethernova/progression/EthernovaProgression.java`, lines 121–130  
**Category:** Data loss on shutdown

### Description

`onDisable()` iterates online players and calls `battlePassManager.savePlayer()`, but does **not** call `achievementManager.savePlayer()` or `missionManager.savePlayer()`. Both managers load per-player data on join (confirmed at lines 102–104 in `onEnable()`), so they hold dirty in-memory state that is lost on shutdown/reload.

### Evidence

```java
// onDisable:
for (var player : Bukkit.getOnlinePlayers()) {
    if (battlePassManager != null) battlePassManager.savePlayer(player.getUniqueId());
}
// achievementManager.savePlayer() — MISSING
// missionManager.savePlayer() — MISSING
```

Compare with `onEnable()` which loads all three:
```java
achievementManager.loadPlayer(player.getUniqueId());
missionManager.loadPlayer(player.getUniqueId());
battlePassManager.loadPlayer(player.getUniqueId());
```

### Impact

All achievement progress and mission progress for every online player is silently lost on every server shutdown or `/reload`. If the auto-save task (`autoSaveTask`) hasn't run recently, hours of progress may be discarded.

---

## BUG #2 — HIGH: Duels Bet Not Refunded to Disconnected Player on Draw/Timeout

**Module:** Duels  
**File:** `duels/src/main/java/com/ethernova/duels/manager/DuelManager.java`, lines 437–449  
**Category:** Economy corruption

### Description

`endDuelDraw()` refunds bets only to online players. When a duel times out (draw), the refund is gated on `p1 != null` and `p2 != null` — where `p1`/`p2` are obtained via `Bukkit.getPlayer()`, which returns `null` for disconnected players. A player who disconnects during the timeout window permanently loses their bet.

### Evidence

```java
public void endDuelDraw(DuelMatch match) {
    ...
    Player p1 = Bukkit.getPlayer(match.getPlayer1());
    Player p2 = Bukkit.getPlayer(match.getPlayer2());
    ...
    double bet = match.getBetAmount();
    if (bet > 0 && core.getEconomyHook().isEnabled()) {
        if (p1 != null) core.getEconomyHook().deposit(p1, bet);  // p1 offline → no refund
        if (p2 != null) core.getEconomyHook().deposit(p2, bet);  // p2 offline → no refund
    }
    ...
}
```

### Impact

Players who disconnect (network issues, client crash, intentional quit) during a duel that ends in a draw lose their bet permanently. With configured max-bet at 50,000, this is significant economy loss.

### Note

`endDuel()` (the win/loss path) also uses `Bukkit.getPlayer()` for the winner at line ~377, but the winner calling `endDuel()` is more likely online. The real risk is the draw/timeout path. The fix should use `Bukkit.getOfflinePlayer(uuid)` or `EconomyHook.deposit(UUID, amount)` instead of requiring an online `Player` object.

---

## BUG #3 — HIGH: Duels onDisable Does Not Wait for Async Stats Persistence

**Module:** Duels  
**File:** `duels/src/main/java/com/ethernova/duels/EthernovaDuels.java`, lines 105–118  
**Category:** Data loss on shutdown

### Description

`onDisable()` calls `duelManager.forceEndAll()` which force-ends all active duels. Ending a duel calls `plugin.getStatsManager().recordResult(...)` which is async (runs on `CompletableFuture` / ForkJoinPool). The plugin then immediately proceeds to unregister from core and set `instance = null`. The async stat writes may not complete before the plugin's classloader is discarded.

### Evidence

```java
@Override
public void onDisable() {
    if (duelManager != null) {
        duelManager.forceEndAll();     // triggers async recordResult() calls
    }
    if (core != null) {
        core.unregisterPlugin("EthernovaDuels");  // proceeds immediately
    }
    instance = null;
}
```

### Impact

Duel results (wins, losses, ELO changes, match history) for all active duels at shutdown time may be silently lost. On a busy server with many concurrent duels, this is significant data loss.

---

## BUG #4 — MEDIUM: War Bank Loot Uses Non-Atomic Get-Then-Set on ClanBankManager

**Module:** Clans  
**File:** `src/main/java/com/ethernova/clans/war/WarManager.java`, lines 252–256  
**Category:** Race condition / economy corruption

### Description

`applyWarResults()` reads the loser's balance with `getBalance()`, computes loot, then calls `setBalance()` separately for both winner and loser. This bypasses `ClanBankManager`'s own atomic `compute()` pattern used in `deposit()`/`withdraw()`. If any other code touches the bank between the `getBalance()` and `setBalance()` calls, the intermediate update is overwritten.

### Evidence

```java
double loserBalance = plugin.getBankManager().getBalance(loser.getId());
double loot = Math.floor(loserBalance * (lootPercent / 100.0));
if (loot > 0) {
    plugin.getBankManager().setBalance(loser.getId(), loserBalance - loot);      // overwrites any concurrent deposit
    double winnerBalance = plugin.getBankManager().getBalance(winner.getId());
    plugin.getBankManager().setBalance(winner.getId(), winnerBalance + loot);    // overwrites any concurrent deposit
}
```

### Impact

If `tick()` (which calls `applyWarResults()`) runs as an async timer task, or if any clan member deposits/withdraws between these calls, the bank balance is corrupted. Even on the main thread, this is fragile if the war tick and a `/clan deposit` command run in the same tick cycle (Bukkit processes events between task executions within a tick). **Severity is MEDIUM** because Bukkit's main-thread scheduler usually serializes these, but the pattern is inherently unsafe and should use `ClanBankManager.withdraw()`/`deposit()` instead.

---

## BUG #5 — MEDIUM: Ranked RankedProfile Compound Operations Are Not Atomic

**Module:** Ranked  
**File:** `ranked/src/main/java/com/ethernova/ranked/model/RankedProfile.java`, lines 57–68  
**Category:** Data race

### Description

`addWin()` performs three non-atomic operations on volatile fields: `wins++`, `winStreak++`, and a conditional `bestWinStreak` update. Similarly, `addLoss()` performs `losses++` and `winStreak = 0`. While each field is individually `volatile`, compound operations across multiple volatile fields are NOT atomic. If `processResult()` is ever called concurrently for the same player (e.g., from two different `CompletableFuture.thenAccept` callbacks), the stats can be corrupted.

### Evidence

```java
public void addWin() {
    this.wins++;              // read-increment-write — NOT atomic
    this.winStreak++;         // same
    if (this.winStreak > this.bestWinStreak) {
        this.bestWinStreak = this.winStreak;   // TOCTOU
    }
    this.dirty = true;
}
```

### Impact

**Severity is MEDIUM** (not CRITICAL) because `processResult()` is normally called from Bukkit event handlers on the main thread, making concurrent calls unlikely. However, the code uses `CompletableFuture.thenAccept` on the default ForkJoinPool in several paths — if profile loading races with match result processing, corruption is possible. Volatile alone does NOT provide atomicity for compound operations; `synchronized` or `AtomicInteger` would be needed.

---

## BUG #6 — MEDIUM: Duels Arena.inUse Check-Then-Act Race Condition

**Module:** Duels  
**File:** `duels/src/main/java/com/ethernova/duels/manager/ArenaManager.java`, lines 42–48  
**Category:** Race condition

### Description

`getAvailableArena()` iterates arenas, checks `if (!arena.inUse)`, then sets `arena.inUse = true`. Although `inUse` is `volatile boolean`, the check-then-act sequence is not atomic. Two concurrent callers could both see `inUse == false` and both acquire the same arena.

### Evidence

```java
public Arena getAvailableArena() {
    for (Arena arena : arenas.values()) {
        if (!arena.inUse) {          // Thread A reads false
            arena.inUse = true;      // Thread B also reads false before this write
            return arena;
        }
    }
    return null;
}
```

### Impact

In normal Bukkit operation (single main thread), this is safe. But if duel creation is ever triggered from an async context (e.g., from a `CompletableFuture.thenAccept` callback), two duels could be assigned the same arena, causing player-overlap, broken duels, and stuck arenas. Should use `AtomicBoolean` with `compareAndSet()`.

---

## BUG #7 — MEDIUM: FFA handleKill Does Not Verify Same-Arena Membership

**Module:** FFA  
**File:** `ffa/src/main/java/com/ethernova/ffa/manager/FFAManager.java`, lines 222–232  
**Category:** Logic error

### Description

`handleKill()` retrieves killer and victim data from the global `activePlayers` map but does not verify both players are in the same arena. Kill rewards, streak tracking, kill messages, and the `EthernovaPlayerKillEvent` are all dispatched without arena validation.

### Evidence

```java
public void handleKill(Player killer, Player victim) {
    FFAPlayer killerData = activePlayers.get(killerUuid);
    FFAPlayer victimData = activePlayers.get(victimUuid);
    if (killerData == null || victimData == null) return;
    // No check: killerData.getArenaName().equals(victimData.getArenaName())

    killerData.addKill();
    victimData.addDeath();
    ...
    broadcastToArena(killerData.getArenaName(), killMsg);  // broadcasts to killer's arena, not victim's
    ...
}
```

### Impact

If arenas share a world or have overlapping boundaries, a kill could credit the wrong arena's stats and broadcast to only one arena. The kill message would appear in the killer's arena but not the victim's if they differ. The victim's arena would get no notification. Severity is **MEDIUM** because it requires arena proximity/overlap, which is a configuration issue — but the code should be defensive.

---

## BUG #8 — MEDIUM: Clans DecentHologramsHook Null Dereference Chain

**Module:** Clans  
**File:** `src/main/java/com/ethernova/clans/hook/DecentHologramsHook.java`, lines 95–102  
**Category:** Null pointer exception

### Description

Three chained `getConfigurationSection()` calls without null checks. If the config path `tops.holograms` exists but `tops.holograms.locations` does not, line 98 dereferences null.

### Evidence

```java
var holoSection = config.getConfig().getConfigurationSection("tops.holograms");  // line 95 — could be null
// ... no null check ...
var locations = holoSection.getConfigurationSection("locations");                 // line 98 — NPE if holoSection is null
// ... no null check ...
var locSection = locations.getConfigurationSection(category);                     // line 102 — NPE if locations is null
```

### Impact

Server crash (NPE) if the hologram configuration section is missing or partially configured. This would happen on first install before the config file is populated, or after a config file corruption.

---

## BUG #9 — MEDIUM: KillStreakManager Unchecked getConfigurationSection Returns

**Module:** Combat  
**File:** `combat/src/main/java/com/ethernova/combat/killstreak/KillStreakManager.java`, lines 42–86  
**Category:** Null pointer exception

### Description

Multiple `getConfigurationSection()` calls without null checks:
- Line 42: `getConfigurationSection("streaks")` — unchecked
- Line 46: `streaksConfig.getConfigurationSection(String.valueOf(streak))` — unchecked, passed to line 71
- Line 71: `milestone.getConfigurationSection("title")` — unchecked
- Line 86: `milestone.getConfigurationSection("rewards")` — unchecked

### Impact

NPE if `killstreaks.yml` is missing any expected section. Since killstreaks are triggered by in-game kills, this crashes the event handler mid-combat.

---

## BUG #10 — LOW: CosmeticRegistry Mystery Box Weight Section Not Null-Checked

**Module:** Cosmetics  
**File:** `cosmetics/src/main/java/com/ethernova/cosmetics/manager/CosmeticRegistry.java`, lines 104–116  
**Category:** Null pointer exception

### Description

Loading mystery boxes: `boxSection.getConfigurationSection(boxId)` is checked (`bs != null`), but the inner `bs.getConfigurationSection("weights")` at line 116 is NOT null-checked. If a mystery box entry exists in `cosmetics.yml` without a `weights` section, code will NPE.

### Evidence

```java
ConfigurationSection bs = boxSection.getConfigurationSection(boxId);  // line 107 — null-checked ✓
...
ConfigurationSection ws = bs.getConfigurationSection("weights");       // line 116 — NOT null-checked ✗
```

### Impact

NPE during plugin startup if a mystery box has no weights configured. Prevents the cosmetics plugin from loading.

---

## BUG #11 — LOW: WarManager tick() Copies Map but Has TOCTOU on endWar

**Module:** Clans  
**File:** `src/main/java/com/ethernova/clans/war/WarManager.java`, line 175 + `forceEndAllWars()`  
**Category:** Race condition / double-processing

### Description

`tick()` creates `new HashMap<>(activeWars)` to iterate safely, but between copying and calling `endWar()`, the war could have already been ended by another code path (e.g., player command, other tick processing). Similarly, `forceEndAllWars()` copies the map and iterates, calling `endWar()` per entry — if two threads or code paths call this simultaneously, the same war could be ended twice.

### Evidence

```java
// forceEndAllWars:
for (var entry : new HashMap<>(activeWars).entrySet()) {
    if (entry.getValue().involves(clan.getId())) {
        endWar(entry.getKey(), null);  // could double-call if war was ended between copy and here
    }
}
```

### Impact

Double war processing: power changes, bank loot, and war stats applied twice for the same war. LOW severity because `endWar` likely has a state guard (`if (war.isEnded()) return;`) and most calls happen on the main thread, but the pattern is inherently unsafe and I did not find such a guard in the visible code.

---

## BUG #12 — LOW: Duels Cleanup Does Not Cancel Countdown Tasks Already Scheduled

**Module:** Duels  
**File:** `duels/src/main/java/com/ethernova/duels/manager/DuelManager.java`, `cleanupMatch()` method  
**Category:** Resource leak / ghost task

### Description

`cleanupMatch()` removes entries from `activeMatches`, `matchBossBars`, and calls `cancelMatchTasks(matchId)`. However, if the match has a countdown phase that scheduled multiple `BukkitTask` entries (e.g., countdown 3, 2, 1 with separate `runTaskLater` calls), only the task stored in `matchTasks` (keyed by matchId) is cancelled. Any additional tasks scheduled during the countdown phase that aren't stored in `matchTasks` will still fire.

### Impact

Orphaned tasks may attempt to start a match that has already been cleaned up, potentially causing NPEs or confusing messages to players. LOW because the tasks would find null players/matches and likely silently fail.

---

## Summary Table

| # | Severity | Module | Bug | Line(s) |
|---|----------|--------|-----|---------|
| 1 | **CRITICAL** | Progression | Achievement/mission data not saved on disable | `EthernovaProgression.java:121-130` |
| 2 | **HIGH** | Duels | Bet not refunded to offline player on draw | `DuelManager.java:437-449` |
| 3 | **HIGH** | Duels | Async stats not awaited on disable | `EthernovaDuels.java:105-118` |
| 4 | **MEDIUM** | Clans | War loot uses non-atomic get/set on bank | `WarManager.java:252-256` |
| 5 | **MEDIUM** | Ranked | Volatile compound operations not atomic | `RankedProfile.java:57-68` |
| 6 | **MEDIUM** | Duels | Arena.inUse TOCTOU race | `ArenaManager.java:42-48` |
| 7 | **MEDIUM** | FFA | handleKill no same-arena check | `FFAManager.java:222-232` |
| 8 | **MEDIUM** | Clans | Hologram config null-chain NPE | `DecentHologramsHook.java:95-102` |
| 9 | **MEDIUM** | Combat | KillStreak config null-chain NPE | `KillStreakManager.java:42-86` |
| 10 | **LOW** | Cosmetics | Mystery box weights not null-checked | `CosmeticRegistry.java:116` |
| 11 | **LOW** | Clans | War tick TOCTOU / double-end | `WarManager.java:175, forceEndAllWars()` |
| 12 | **LOW** | Duels | Orphaned countdown tasks after cleanup | `DuelManager.java:cleanupMatch()` |

---

## Patterns Audited — No Bugs Found

The following patterns were explicitly audited and found to be correctly implemented:

- **InventoryClickEvent item theft:** All GUIs extend `CoreGui` which calls `event.setCancelled(true)` in `handleClick()` (line 47) before dispatching. Clans' `AbstractGui` and `ConfigurableGUI` also cancel clicks. **No item duplication or theft possible.**

- **PlayerQuitEvent cleanup:** All 7 modules properly handle `PlayerQuitEvent` — removing UUID-keyed map entries, saving dirty data, cleaning up contexts, and removing boss bars/trails. Verified in: `CosmeticListener:75`, `PartyListener:41`, `ProgressionListener:135`, `RankedListener:64`, `DuelListener:109`, `FFAListener:163`, Clans `PlayerListener:96`.

- **EventBus thread safety:** `EthernovaEventBus.publish()` is synchronous — it executes subscribers on the calling thread. Since `publish()` is called from Bukkit event handlers (main thread), all subscribers also run on the main thread. `Bukkit.getPlayer()` calls in EventBus subscribers (e.g., `CosmeticListener.onKillEvent()`) are safe.

- **ELO calculations:** `EloCalculator` guarantees minimum +1 for winner and maximum -1 for loser. `setElo()` enforces floor at 0 via `Math.max(0, elo)`. No negative ELO or overflow possible for realistic values.

- **XP/Level overflow:** `LevelManager` uses `long` for XP. Formula `100 * n * (1 + n/10)` produces ~55M total XP at level 100, well within `long` range. `PrestigeManager` correctly resets level and XP on prestige.

- **FFA/Duels/Party quit cleanup:** Verified that all UUID-keyed maps (`activePlayers`, `maxStreaks`, `pendingRequests`, `activeMatches`, `matchTasks`, `matchBossBars`, `playerPartyMap`, `pendingInvites`, `teleportCooldowns`) are properly cleaned on player quit.

- **Config loading with null guards:** `FFAArenaManager.loadArenas()` (line 46), `ArenaManager.loadArenas()` (line 21), `UpgradeManager.getAllDefinitions()` (line 24), `BlueprintManager` (line 62+), and `MissionManager` (line 51) all properly check `if (section == null) return` after `getConfigurationSection()` calls.

- **ClanBankManager atomicity:** `deposit()` and `withdraw()` use `ConcurrentHashMap.compute()` for atomic balance updates — correct. (Bug #4 is specifically about WarManager **bypassing** this API.)

---

*End of audit. 12 bugs identified across 6 of 7 modules (Party module: no bugs found). 1 CRITICAL, 2 HIGH, 5 MEDIUM, 4 LOW.*
