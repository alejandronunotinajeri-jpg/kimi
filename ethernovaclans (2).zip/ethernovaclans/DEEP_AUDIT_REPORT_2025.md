# 🔍 Deep Code Audit Report — EthernovaProgression, EthernovaRanked, EthernovaDuels, EthernovaFFA

**Date:** 2025  
**Scope:** 62 Java files across 4 plugins + resource files  
**Categories:** Null pointer risks, Missing registrations, SQL bugs, Logic errors, Inter-plugin connectivity, GUI bugs, Game logic, Command bugs, Resource leaks, Concurrency  

---

## Summary

| Severity | Count |
|----------|-------|
| 🔴 CRITICAL | 3 |
| 🟠 HIGH | 3 |
| 🟡 MEDIUM | 7 |
| 🟢 LOW | 5 |
| **Total** | **18** |

---

## 🔴 CRITICAL BUGS

---

### BUG #1 — FFA: Double Coin Payment (Profile + Vault)

| Field | Value |
|-------|-------|
| **Plugin** | EthernovaFFA |
| **File** | `ffa/src/main/java/com/ethernova/ffa/manager/FFAManager.java` |
| **Lines** | 250–259 (kill rewards), 355–365 (streak rewards) |
| **Category** | Logic Error / Economy |

**Description:**  
Every kill reward and killstreak reward is paid **twice** — once via `profile.addCoins(finalCoins)` and again via `core.getEconomyHook().deposit(killer, finalCoins)`. If the Core plugin's profile system is backed by the same Vault economy provider, the player receives **2× the intended coins**.

```java
// Line 253 — first payment
profile.addCoins(finalCoins);
profile.addXP(finalXp);

// Line 259 — second payment
if (core.getEconomyHook().isEnabled()) {
    core.getEconomyHook().deposit(killer, finalCoins);
}
```

The same pattern repeats for streak rewards at lines 360 and 364.

**Impact:** Infinite economy inflation. Every kill doubles the economy injection rate.

**Fix:** Remove the Vault deposit and rely solely on `profile.addCoins()`, OR remove `profile.addCoins()` and use only the Vault deposit. Choose one source of truth:

```java
// Keep only one:
var profile = core.getProfileManager().getProfile(killerUuid);
if (profile != null) {
    profile.addCoins(finalCoins);
    profile.addXP(finalXp);
}
// DELETE the economy.deposit block entirely
```

---

### BUG #2 — Duels: Disconnect Exploit — Double Bet Payout

| Field | Value |
|-------|-------|
| **Plugin** | EthernovaDuels |
| **File** | `duels/src/main/java/com/ethernova/duels/manager/DuelManager.java` |
| **Lines** | 424–429 (`endDuelByDisconnect`) + 389–392 (`endDuel`) |
| **Category** | Logic Error / Economy Exploit |

**Description:**  
When a player disconnects during a duel, `endDuelByDisconnect()` deposits `bet × 2` to the winner, then calls `endDuel()` which deposits `bet × 2` **again**. The winner receives **4× the bet** instead of 2×.

Flow:
1. `endDuelByDisconnect()`: `economy.deposit(winner, bet * 2)` — ✅ first payment
2. `endDuelByDisconnect()` calls `endDuel(match, winnerUuid)`
3. `endDuel()`: state is NOT yet `ENDED` (only set inside `endDuel`), so the guard passes
4. `endDuel()`: `economy.deposit(winner, bet * 2)` — ❌ second payment

```java
// endDuelByDisconnect — pays once here:
core.getEconomyHook().deposit(winner, bet * 2);

// Then calls endDuel which pays AGAIN:
if (winnerUuid != null) {
    endDuel(match, winnerUuid);  // <-- endDuel also deposits bet*2
}
```

**Impact:** Exploitable: two friends duel with max bet, one disconnects, winner gets 4× the bet. Net economy injection = `bet × 2` per exploit.

**Fix:** Remove the bet handling from `endDuelByDisconnect` and let `endDuel` handle it exclusively:

```java
public void endDuelByDisconnect(DuelMatch match, UUID disconnectedUuid) {
    if (match.getState() == DuelState.ENDED) return;
    UUID winnerUuid = match.getOpponent(disconnectedUuid);
    Player winner = winnerUuid != null ? Bukkit.getPlayer(winnerUuid) : null;
    if (winner != null) {
        sendMessage(winner, "duel-forfeit", "{player}", ...);
    }
    // DO NOT deposit here — let endDuel handle it
    if (winnerUuid != null) {
        endDuel(match, winnerUuid);
    } else {
        match.setState(DuelState.ENDED);
        cancelMatchTasks(match.getMatchId());
        cleanupMatch(match);
    }
}
```

---

### BUG #3 — Duels: MySQL best_streak Off-by-One

| Field | Value |
|-------|-------|
| **Plugin** | EthernovaDuels |
| **File** | `duels/src/main/java/com/ethernova/duels/manager/DuelStatsManager.java` |
| **Lines** | 76–84 |
| **Category** | SQL Bug |

**Description:**  
In the MySQL `ON DUPLICATE KEY UPDATE` clause, `win_streak` is updated first, then `best_streak` references the **already-updated** `win_streak` column (MySQL evaluates SET assignments left-to-right using updated values). This makes `best_streak` one higher than the actual streak.

```sql
ON DUPLICATE KEY UPDATE
    wins = wins + ?,
    losses = losses + ?,
    win_streak = IF(? = 1, win_streak + 1, 0),          -- ① win_streak is now old+1
    best_streak = GREATEST(best_streak, IF(? = 1, win_streak + 1, best_streak))
    --                                              ② win_streak here is already old+1
    --                                              so this computes old+2, not old+1
```

**Impact:** `best_streak` is always inflated by 1 for every win on MySQL. Leaderboards and stats display incorrect data. SQLite path is unaffected (it reads before writing).

**Fix:** Since `win_streak` is already the new value at that point, just reference it directly:

```sql
ON DUPLICATE KEY UPDATE
    wins = wins + ?,
    losses = losses + ?,
    win_streak = IF(? = 1, win_streak + 1, 0),
    best_streak = GREATEST(best_streak, IF(? = 1, win_streak, best_streak))
    --                                         ^^^^^^^^^ no +1 needed
```

---

## 🟠 HIGH BUGS

---

### BUG #4 — Progression: Async Thread Calls Bukkit.getOnlinePlayers()

| Field | Value |
|-------|-------|
| **Plugin** | EthernovaProgression |
| **File** | `progression/src/main/java/com/ethernova/progression/EthernovaProgression.java` |
| **Lines** | 162–166 |
| **Category** | Concurrency / API Violation |

**Description:**  
The `autoSaveTask` is scheduled with `runTaskTimerAsynchronously`, then iterates `Bukkit.getOnlinePlayers()` from the async thread. This violates the Bukkit API contract — the player collection can be modified by the main thread during iteration, causing `ConcurrentModificationException`.

```java
autoSaveTask = Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> {
    for (var player : Bukkit.getOnlinePlayers()) {  // ❌ async access
        battlePassManager.savePlayer(player.getUniqueId());
    }
}, 6000L, 6000L);
```

**Impact:** Random `ConcurrentModificationException` crashes during auto-save. More likely under high player counts.

**Fix:** Snapshot the UUIDs on the main thread, then process saves async:

```java
autoSaveTask = Bukkit.getScheduler().runTaskTimer(this, () -> {
    List<UUID> uuids = Bukkit.getOnlinePlayers().stream()
            .map(Player::getUniqueId)
            .toList();
    Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
        for (UUID uuid : uuids) {
            battlePassManager.savePlayer(uuid);
        }
    });
}, 6000L, 6000L);
```

---

### BUG #5 — Ranked: Tab Completion NumberFormatException

| Field | Value |
|-------|-------|
| **Plugin** | EthernovaRanked |
| **File** | `ranked/src/main/java/com/ethernova/ranked/command/RankedCommand.java` |
| **Lines** | 269–270 |
| **Category** | Command Bug / Uncaught Exception |

**Description:**  
Tab completion for `/ranked admin reset` tries to parse the next season number from the current season ID. If the season name contains no digits (e.g., `"season-one"`), `replaceAll("\\D", "")` produces `""`, and `Integer.parseInt("")` throws `NumberFormatException`, crashing tab completion for all players.

```java
completions.add("s" + (Integer.parseInt(
    plugin.getSeasonManager().getCurrentSeason().replaceAll("\\D", "")) + 1));
```

**Impact:** Tab completion crashes if season ID has no digits. Exception propagates to the client as a broken completion.

**Fix:** Wrap in try-catch:

```java
try {
    String digits = plugin.getSeasonManager().getCurrentSeason().replaceAll("\\D", "");
    if (!digits.isEmpty()) {
        completions.add("s" + (Integer.parseInt(digits) + 1));
    }
} catch (NumberFormatException ignored) {}
```

---

### BUG #6 — Progression: Missing EventBus Unsubscribe on Disable

| Field | Value |
|-------|-------|
| **Plugin** | EthernovaProgression |
| **File** | `progression/src/main/java/com/ethernova/progression/EthernovaProgression.java` (onDisable) + `ProgressionListener.java` (line 71) |
| **Category** | Resource Leak / Inter-plugin Connectivity |

**Description:**  
`ProgressionListener` subscribes to `EthernovaPlayerKillEvent` via the core EventBus at line 71, but `EthernovaProgression.onDisable()` never unsubscribes. Compare with `EthernovaRanked`, which correctly calls `rankedListener.unregister()` → `core.getEventBus().unsubscribe(...)` on disable.

```java
// ProgressionListener constructor:
core.getEventBus().subscribe(EthernovaPlayerKillEvent.class, this::onPlayerKill);

// EthernovaProgression.onDisable():
// ❌ No unsubscribe call — stale listener persists after reload
core.unregisterPlugin("EthernovaProgression");  // Does NOT unsubscribe EventBus
```

**Impact:** After a `/reload` or plugin reload, the old listener remains subscribed. Kill events fire on the stale listener referencing the old (disabled) plugin instance, causing `NullPointerException` or data corruption.

**Fix:** Add an `unregister()` method to `ProgressionListener` (like `RankedListener` has) and call it from `onDisable()`:

```java
// In ProgressionListener:
private final java.util.function.Consumer<EthernovaPlayerKillEvent> killHandler = this::onPlayerKill;

private void registerEventBusListeners() {
    core.getEventBus().subscribe(EthernovaPlayerKillEvent.class, killHandler);
}

public void unregister() {
    core.getEventBus().unsubscribe(EthernovaPlayerKillEvent.class, killHandler);
}

// In EthernovaProgression.onDisable():
if (progressionListener != null) progressionListener.unregister();
```

---

## 🟡 MEDIUM BUGS

---

### BUG #7 — FFA: Data Loss on Server Shutdown

| Field | Value |
|-------|-------|
| **Plugin** | EthernovaFFA |
| **File** | `ffa/src/main/java/com/ethernova/ffa/EthernovaFFA.java` (onDisable) |
| **Category** | Resource Leak / Data Loss |

**Description:**  
`onDisable()` calls `ffaManager.forceLeaveAll()`, which triggers `statsManager.recordSession()` for each player. `recordSession()` uses `Bukkit.getScheduler().runTaskAsynchronously()` to write to the database. During server shutdown, the async scheduler is being shut down — these tasks may never execute, losing all session stats.

**Fix:** Use synchronous DB writes in `onDisable()`, or call `recordSession()` with a synchronous variant specifically for shutdown:

```java
// In FFAStatsManager, add a synchronous save method:
public void recordSessionSync(UUID uuid, int kills, int deaths, int bestStreak, int playtimeSeconds) {
    try (Connection conn = storage.getConnection()) {
        updateStats(conn, uuid, kills, deaths, bestStreak, playtimeSeconds);
    } catch (Exception e) { ... }
}
```

---

### BUG #8 — FFA: Scoreboard Flicker from Objective Recreation

| Field | Value |
|-------|-------|
| **Plugin** | EthernovaFFA |
| **File** | `ffa/src/main/java/com/ethernova/ffa/manager/FFAScoreboardManager.java` |
| **Lines** | 99–103 (`updateBoard`) |
| **Category** | GUI Bug |

**Description:**  
Every update cycle (default: every 20 ticks), the scoreboard objective is unregistered and re-registered. This causes a visible flicker as the sidebar disappears and reappears each second.

```java
if (objective != null) {
    objective.unregister();  // ❌ causes flicker
}
objective = board.registerNewObjective(objName, Criteria.DUMMY, title, RenderType.INTEGER);
```

**Fix:** Instead of recreating the objective, update the existing teams' prefixes in-place. Only recreate if the number of lines changes:

```java
if (objective == null) {
    objective = board.registerNewObjective(objName, Criteria.DUMMY, title, RenderType.INTEGER);
    objective.setDisplaySlot(DisplaySlot.SIDEBAR);
} else {
    objective.displayName(title);
}
// Update team prefixes without unregistering the objective
```

---

### BUG #9 — FFA: SQLite recordSession Race Condition

| Field | Value |
|-------|-------|
| **Plugin** | EthernovaFFA |
| **File** | `ffa/src/main/java/com/ethernova/ffa/manager/FFAStatsManager.java` |
| **Category** | SQL Bug / Concurrency |

**Description:**  
The SQLite path uses SELECT → UPDATE/INSERT without a transaction. If two sessions for the same player save concurrently (e.g., rapid rejoin), the second SELECT reads stale data before the first UPDATE commits, causing stats to be underreported.

**Fix:** Wrap the SQLite read-modify-write in a transaction:

```java
conn.setAutoCommit(false);
try {
    // SELECT ... UPDATE/INSERT
    conn.commit();
} catch (Exception e) {
    conn.rollback();
    throw e;
} finally {
    conn.setAutoCommit(true);
}
```

---

### BUG #10 — Progression: Achievement Async Save Ordering

| Field | Value |
|-------|-------|
| **Plugin** | EthernovaProgression |
| **File** | `progression/src/main/java/com/ethernova/progression/achievement/AchievementManager.java` |
| **Lines** | 151, 173, 186 |
| **Category** | Concurrency |

**Description:**  
Each progress increment fires a separate `runTaskAsynchronously()` to save its value. The Bukkit async scheduler doesn't guarantee execution order — tasks may run on different threads. If a player quickly increments from 5→6→7, and the save for 7 runs before the save for 6, the database will end up with 6 instead of 7.

```java
// Called for each increment — no ordering guarantee
Bukkit.getScheduler().runTaskAsynchronously(plugin,
    () -> saveProgress(uuid, achievementId, newProgress, false));
```

**Fix:** Use a per-player queue or simply save the latest value with a dirty-flag approach, batching saves instead of firing one per increment.

---

### BUG #11 — Ranked: ELO Update Not Atomic

| Field | Value |
|-------|-------|
| **Plugin** | EthernovaRanked |
| **File** | `ranked/src/main/java/com/ethernova/ranked/manager/RankedManager.java` + `RankedProfile.java` |
| **Category** | Concurrency |

**Description:**  
`RankedProfile` fields are `volatile`, but compound read-modify-write operations like `profile.setElo(profile.getElo() + change)` are NOT atomic. If two kills process simultaneously for the same player (e.g., from an EventBus event published during overlapping ticks), the ELO change from one kill can be lost.

**Fix:** Use `synchronized` blocks or `AtomicInteger` for ELO:

```java
public synchronized void addElo(int delta) {
    this.elo = Math.max(0, this.elo + delta);
    this.dirty = true;
}
```

---

### BUG #12 — FFA: Scoreboard Fails for >15 Lines

| Field | Value |
|-------|-------|
| **Plugin** | EthernovaFFA |
| **File** | `ffa/src/main/java/com/ethernova/ffa/manager/FFAScoreboardManager.java` |
| **Method** | `intToChar(int)` |
| **Category** | GUI Bug |

**Description:**  
`intToChar()` maps integers 1–15 to unique color code characters. For `i > 15` (or `i < 1`), it returns `'f'` for all values, causing duplicate scoreboard entries. Lines after the 15th would overwrite each other, displaying only the last one.

The default config has 12 lines (safe), but an admin adding 4+ more lines to the config would trigger this.

**Fix:** Extend the mapping or use a different approach for unique entries:

```java
private String uniqueEntry(int i) {
    // Use invisible Unicode characters for unlimited unique entries
    return "\u00a7" + Integer.toHexString(i % 16) + (i >= 16 ? "\u00a7" + Integer.toHexString(i / 16) : "");
}
```

---

### BUG #13 — Progression: BattlePass Data Corruption on Early Auto-Save

| Field | Value |
|-------|-------|
| **Plugin** | EthernovaProgression |
| **File** | `progression/src/main/java/com/ethernova/progression/battlepass/BattlePassManager.java` (savePlayer) + `EthernovaProgression.java` (autoSaveTask) |
| **Category** | Concurrency / Data Loss |

**Description:**  
`loadPlayer()` runs asynchronously. If the `autoSaveTask` fires before `loadPlayer()` completes for a recently joined player, `savePlayer()` reads default/empty values from the `ConcurrentHashMap` (UUID not yet populated) and writes them to the DB with an UPSERT, **overwriting the player's real data**.

Timeline:
1. Player joins → `loadPlayer()` starts async DB read
2. `autoSaveTask` fires → `savePlayer()` reads `playerXP.getOrDefault(uuid, 0L)` → gets `0`
3. `savePlayer()` writes `xp=0, claimed_free="", claimed_premium=""` to DB via UPSERT
4. `loadPlayer()` completes → puts real data in memory (but DB is already corrupted)

**Fix:** Add a "loaded" flag per player and skip saving unloaded players:

```java
private final Set<UUID> loadedPlayers = ConcurrentHashMap.newKeySet();

public void loadPlayer(UUID uuid) {
    // ... after successful load:
    loadedPlayers.add(uuid);
}

public void savePlayer(UUID uuid) {
    if (!loadedPlayers.contains(uuid)) return;  // Skip if not loaded yet
    // ... existing save logic
}
```

---

## 🟢 LOW BUGS

---

### BUG #14 — Duels: No World Validation on Arena Spawn Points

| Field | Value |
|-------|-------|
| **Plugin** | EthernovaDuels |
| **File** | `duels/src/main/java/com/ethernova/duels/manager/DuelManager.java` (addSpectator) + `ArenaManager.java` |
| **Category** | Game Logic |

**Description:**  
Arena spawn points (`spawn1`, `spawn2`) are set via admin commands without validating they're in the same world. If an admin sets `spawn1` in `world` and `spawn2` in `world_nether`, the spectator midpoint calculation `spawn1.clone().add(spawn2).multiply(0.5)` throws `IllegalArgumentException` because `Location.add(Location)` requires matching worlds.

**Fix:** Validate same world in `/dueladmin arena set1` and `set2` commands.

---

### BUG #15 — Duels: Bet Withdrawal TOCTOU Race

| Field | Value |
|-------|-------|
| **Plugin** | EthernovaDuels |
| **File** | `duels/src/main/java/com/ethernova/duels/manager/DuelManager.java` |
| **Lines** | 190–198 (`acceptRequest`) |
| **Category** | Concurrency |

**Description:**  
Both players' balances are checked with `economy.has()`, then both are withdrawn with `economy.withdraw()`. Between the check and withdrawal, another plugin could modify the balance (TOCTOU race). This could result in a negative balance.

```java
if (!core.getEconomyHook().has(sender, bet) || !core.getEconomyHook().has(target, bet)) {
    // rejection
}
// ↓ Gap: balance could change between check and withdraw
core.getEconomyHook().withdraw(sender, bet);
core.getEconomyHook().withdraw(target, bet);
```

**Fix:** Use withdrawal return values to verify success and refund on failure:

```java
if (!core.getEconomyHook().withdraw(sender, bet)) {
    sendMessage(sender, "insufficient-funds");
    return;
}
if (!core.getEconomyHook().withdraw(target, bet)) {
    core.getEconomyHook().deposit(sender, bet); // refund
    sendMessage(target, "insufficient-funds");
    return;
}
```

---

### BUG #16 — Ranked: Season Reset In-Memory Race

| Field | Value |
|-------|-------|
| **Plugin** | EthernovaRanked |
| **File** | `ranked/src/main/java/com/ethernova/ranked/manager/SeasonManager.java` |
| **Category** | Concurrency |

**Description:**  
During `resetSeason()`, the DB transaction archives and deletes old data, then in-memory profiles are reset. If a ranked result processes between the DB commit and the in-memory reset, it writes new ELO data to the new season's table while the in-memory profile still holds old-season ELO.

**Fix:** Set a `volatile boolean resetting` flag that `processResult()` checks before modifying profiles.

---

### BUG #17 — FFA: Respawn Task May Fire on Dead Player

| Field | Value |
|-------|-------|
| **Plugin** | EthernovaFFA |
| **File** | `ffa/src/main/java/com/ethernova/ffa/manager/FFAManager.java` |
| **Method** | `handleDeath()` → `respawn()` |
| **Category** | Game Logic |

**Description:**  
`handleDeath()` schedules `respawn()` after a fixed delay (40 ticks). If the player hasn't clicked the respawn button yet (still on death screen), the `player.teleport()` and kit application in `respawn()` may silently fail because the player is still dead. When the player eventually clicks respawn, they'll spawn via `PlayerRespawnEvent` at the arena spawn but without a fresh kit or spawn protection.

**Fix:** Force-respawn the player before applying kit:

```java
private void respawn(Player player) {
    if (player.isDead()) {
        player.spigot().respawn();
    }
    // ... existing respawn logic
}
```

---

### BUG #18 — Duels: Both Players Disconnect = Bets Lost

| Field | Value |
|-------|-------|
| **Plugin** | EthernovaDuels |
| **File** | `duels/src/main/java/com/ethernova/duels/manager/DuelManager.java` |
| **Method** | `endDuelByDisconnect()` |
| **Category** | Game Logic / Economy |

**Description:**  
When both players disconnect simultaneously, the countdown task detects one as "disconnected" and the other as "winner". But since the "winner" is also offline, `Bukkit.getPlayer(winnerUuid)` returns `null`, and the `if (winner != null)` guard skips the bet deposit. Neither player gets their bet refunded. Both bets are permanently lost from the economy.

**Fix:** If the winner is offline, refund their bet to their offline balance or queue it:

```java
if (winner != null) {
    core.getEconomyHook().deposit(winner, bet * 2);
} else {
    // Winner offline: refund both bets to offline players
    core.getEconomyHook().depositOffline(winnerUuid, bet);
    core.getEconomyHook().depositOffline(disconnectedUuid, bet);
}
```

---

## Cross-Cutting Observations

### Pattern: Async DB saves in onDisable()
**Affects:** EthernovaProgression, EthernovaFFA  
Both plugins trigger async saves during `onDisable()`. The Bukkit scheduler stops accepting new async tasks during shutdown, meaning data written via `runTaskAsynchronously()` may be dropped. All `onDisable()` saves should be synchronous.

### Pattern: SQLite Read-Modify-Write Without Transactions
**Affects:** EthernovaDuels (`DuelStatsManager`), EthernovaFFA (`FFAStatsManager`)  
The SQLite fallback path does `SELECT → compute → UPDATE/INSERT` as separate statements. Under concurrent access, this is a classic race condition. Both should wrap in a transaction with `conn.setAutoCommit(false)`.

### Pattern: ConcurrentHashMap Limitations
**Affects:** EthernovaRanked (`RankedProfile` volatiles), EthernovaProgression (`AchievementManager` async saves)  
`ConcurrentHashMap` and `volatile` fields provide visibility guarantees but NOT atomicity for compound operations. Any read-modify-write sequence needs explicit synchronization.

---

*End of audit — 62 Java files reviewed across EthernovaProgression (20), EthernovaRanked (10), EthernovaDuels (15), EthernovaFFA (17).*
