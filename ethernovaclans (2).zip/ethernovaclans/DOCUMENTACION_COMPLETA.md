# 📖 Documentación Completa — Ecosistema Ethernova

> **Versión:** 1.0.0  
> **Plataforma:** Paper 1.21 · Java 21  
> **Arquitectura:** Maven Multi-Módulo (3 plugins)  
> **Generada:** Febrero 2026  

---

## Índice General

### Parte I — Visión General del Ecosistema
- [1. Arquitectura del Ecosistema](#1-arquitectura-del-ecosistema)
- [2. Estructura del Proyecto](#2-estructura-del-proyecto)
- [3. Compilación y Despliegue](#3-compilación-y-despliegue)
- [4. Dependencias entre Plugins](#4-dependencias-entre-plugins)

### Parte II — EthernovaCore (Plugin Base)
- [5. Resumen de EthernovaCore](#5-resumen-de-ethernovacore)
- [6. Clases de Core (18 archivos)](#6-clases-de-core)
- [7. Configuración de Core](#7-configuración-de-core)
- [8. API Pública de Core](#8-api-pública-de-core)

### Parte III — EthernovaCombat (Plugin de Combate PvP)
- [9. Resumen de EthernovaCombat](#9-resumen-de-ethernovacombat)
- [10. Clases de Combat (46 archivos)](#10-clases-de-combat)
- [11. Sistema de Combat Tag](#11-sistema-de-combat-tag)
- [12. Sistema de Detección de Abuso](#12-sistema-de-detección-de-abuso)
- [13. GUI de Administración (13 pantallas)](#13-gui-de-administración)
- [14. Configuración de Combat](#14-configuración-de-combat)

### Parte IV — EthernovaClans (Plugin Principal de Clanes)
- [15. Resumen de EthernovaClans](#15-resumen-de-ethernovaclans)
- [16. Modelo de Datos del Clan](#16-modelo-de-datos-del-clan)
- [17. Comandos (60+ subcomandos)](#17-comandos)
- [18. Los 30+ Managers](#18-los-30-managers)
- [19. Sistema GUI (32 menús)](#19-sistema-gui)
- [20. WebMap Server (47 endpoints)](#20-webmap-server)
- [21. Base de Datos (25+ tablas SQL)](#21-base-de-datos)
- [22. Configuración de Clans](#22-configuración-de-clans)

### Parte V — Referencia Rápida
- [23. Todos los Comandos](#23-todos-los-comandos)
- [24. Todos los Permisos](#24-todos-los-permisos)
- [25. Todos los Archivos de Configuración](#25-todos-los-archivos-de-configuración)
- [26. Diagramas de Flujo](#26-diagramas-de-flujo)

---

# PARTE I — VISIÓN GENERAL DEL ECOSISTEMA

---

## 1. Arquitectura del Ecosistema

El ecosistema Ethernova está compuesto por **3 plugins** que trabajan juntos para proporcionar un sistema completo de clanes con PvP avanzado:

```
┌─────────────────────────────────────────────────────────┐
│                   SERVIDOR PAPER 1.21                    │
│                                                         │
│  ┌─────────────────────────────────────────────────┐    │
│  │              EthernovaCore (Base)                │    │
│  │  ─ EventBus compartido                          │    │
│  │  ─ Perfiles de jugador (kills, deaths, KD)      │    │
│  │  ─ Sistema de economía (Vault)                  │    │
│  │  ─ Contextos (war, arena, ffa)                  │    │
│  │  ─ Cooldowns, Visuals, GUI base                 │    │
│  │  ─ Base de datos SQLite compartida              │    │
│  └────────────┬──────────────────┬──────────────────┘    │
│               │                  │                       │
│       ┌───────▼───────┐  ┌──────▼────────────────┐      │
│       │EthernovaCombat│  │  EthernovaClans       │      │
│       │               │  │                       │      │
│       │ Combat Tag    │  │ 30+ Managers          │      │
│       │ Kill Streaks  │  │ Territorios, Guerra   │      │
│       │ Rewards       │  │ Alianzas, Diplomacia  │      │
│       │ Anti-Abuse    │  │ Economía de Clan      │      │
│       │ NPC Logout    │  │ Niveles, Habilidades  │      │
│       │ Loot Protect  │  │ 32 Menús GUI          │      │
│       │ Admin GUI     │  │ WebMap API (47 eps)   │      │
│       │ Per-World Cfg │  │ Naciones, Puestos     │      │
│       └───────┬───────┘  │ Misiones, Logros      │      │
│               │          │ Temporadas, Impuestos │      │
│               └──────────┤ Espionaje, Planos     │      │
│                          │ Salarios, Escudos     │      │
│           EventBus ◄─────┤ Hologramas, Audit     │      │
│                          └───────────────────────┘      │
│                                                         │
│  Plugins externos opcionales:                           │
│  Vault, PlaceholderAPI, ProtocolLib, DecentHolograms,   │
│  WorldGuard, WorldEdit, dynmap, BlueMap, bStats         │
└─────────────────────────────────────────────────────────┘
```

### Comunicación entre Plugins

| Dirección | Mecanismo | Eventos |
|-----------|-----------|---------|
| Core ↔ Todos | `EthernovaEventBus` | Bus de eventos tipado con suscripciones `Consumer<T>` |
| Combat → Core | Perfiles | `incrementKills()`, `incrementDeaths()` en `PlayerProfile` |
| Combat → Clans | EventBus | `EthernovaPlayerKillEvent`, `PowerChangeEvent` |
| Clans → Combat | EventBus | `ClanWarStartEvent`, `ClanWarEndEvent` |
| Clans → Core | Contextos | `ContextManager.setContext("war")`, economía |

---

## 2. Estructura del Proyecto

```
ethernovaclans/
├── pom.xml                          # POM padre (Maven multi-módulo)
│
├── core/                            # EthernovaCore
│   ├── pom.xml
│   └── src/main/
│       ├── java/com/ethernova/core/
│       │   ├── EthernovaCore.java          # Main class (242 líneas)
│       │   ├── config/
│       │   │   └── CoreConfigManager.java  # Configuración YAML
│       │   ├── message/
│       │   │   └── CoreMessageManager.java # i18n MiniMessage
│       │   ├── storage/
│       │   │   └── CoreStorageManager.java # SQLite compartido
│       │   ├── profile/
│       │   │   ├── PlayerProfile.java      # Modelo de perfil
│       │   │   └── PlayerProfileManager.java
│       │   ├── context/
│       │   │   └── ContextManager.java     # Contextos de juego
│       │   ├── cooldown/
│       │   │   └── CooldownManager.java    # Sistema de cooldowns
│       │   ├── economy/
│       │   │   └── EconomyHook.java        # Integración Vault
│       │   ├── visual/
│       │   │   └── VisualManager.java      # Efectos visuales
│       │   ├── event/
│       │   │   ├── EthernovaEventBus.java  # Bus de eventos
│       │   │   ├── PowerChangeEvent.java
│       │   │   ├── EthernovaPlayerKillEvent.java
│       │   │   ├── ClanWarStartEvent.java
│       │   │   └── ClanWarEndEvent.java
│       │   ├── gui/
│       │   │   └── CoreGui.java            # GUI base abstracto
│       │   ├── listener/
│       │   │   └── CorePlayerListener.java # Eventos de jugador
│       │   └── command/
│       │       └── CoreCommand.java        # /ethernova
│       └── resources/
│           ├── plugin.yml
│           ├── config.yml
│           └── messages_es.yml / messages_en.yml
│
├── combat/                          # EthernovaCombat
│   ├── pom.xml
│   └── src/main/
│       ├── java/com/ethernova/combat/
│       │   ├── EthernovaCombat.java        # Main class (160 líneas)
│       │   ├── tag/                        # Tag engine (4 clases)
│       │   ├── config/                     # Config multi-archivo
│       │   ├── message/                    # i18n mensajes
│       │   ├── command/                    # 3 comandos
│       │   ├── listener/                   # 8 listeners
│       │   ├── cheat/                      # Prevención de trampas
│       │   ├── npc/                        # NPCs de combate
│       │   ├── penalty/                    # Penalizaciones
│       │   ├── killstreak/                 # Rachas de kills
│       │   ├── reward/                     # Recompensas
│       │   ├── revenge/                    # Sistema de venganza
│       │   ├── newbie/                     # Protección de nuevos
│       │   ├── abuse/                      # Anti-abuso legacy
│       │   ├── detection/                  # Detección avanzada (4 clases)
│       │   ├── loot/                       # Protección de botín
│       │   ├── death/                      # Efectos de muerte
│       │   ├── visual/                     # Efectos visuales
│       │   ├── profile/                    # Perfiles de combate
│       │   ├── module/                     # Sistema de módulos
│       │   ├── world/                      # Config por mundo
│       │   ├── gui/                        # 13 pantallas admin
│       │   └── logout/                     # Safe logout
│       └── resources/
│           ├── plugin.yml
│           ├── config.yml
│           ├── killstreaks.yml
│           ├── rewards.yml
│           ├── profiles.yml
│           └── messages_es.yml / messages_en.yml
│
└── src/                             # EthernovaClans
    ├── pom.xml                      # (usa parent POM)
    └── main/
        ├── java/com/ethernova/clans/
        │   ├── EthernovaClans.java         # Main class (558 líneas)
        │   ├── command/                    # 2 ejecutores + SubCommand
        │   ├── clan/                       # Modelo (Clan, ClanMember, etc.)
        │   ├── config/                     # ConfigManager
        │   ├── alliance/                   # Alianzas
        │   ├── invitation/                 # Invitaciones
        │   ├── chat/                       # Chat de clan
        │   ├── war/                        # Sistema de guerra
        │   ├── power/                      # Sistema de poder
        │   ├── territory/                  # Territorios con flags
        │   ├── siege/                      # Asedios
        │   ├── diplomacy/                  # Tratados diplomáticos
        │   ├── level/                      # Niveles de clan
        │   ├── bank/                       # Banco de clan
        │   ├── economy/                    # Vault hook
        │   ├── storage/                    # SQLite + SchemaManager
        │   ├── gui/                        # AbstractGui + 32 menús
        │   ├── listener/                   # 12 listeners
        │   ├── webmap/                     # HTTP server + renderer
        │   ├── achievement/                # Logros
        │   ├── mission/                    # Misiones
        │   ├── skill/                      # 8 habilidades
        │   ├── shop/                       # Tienda de clan
        │   ├── fly/                        # Vuelo en territorio
        │   ├── teleport/                   # Teleportes
        │   ├── salary/                     # Salarios por rol
        │   ├── shield/                     # Escudos temporales
        │   ├── nation/                     # Naciones
        │   ├── outpost/                    # 5 tipos de puestos
        │   ├── blueprint/                  # Planos de construcción
        │   ├── season/                     # Temporadas PvP
        │   ├── tax/                        # Impuestos
        │   ├── spy/                        # Espionaje
        │   ├── nametag/                    # Nametags dinámicos
        │   ├── placeholder/                # PlaceholderAPI
        │   ├── hook/                       # 7 hooks externos
        │   ├── hologram/                   # DecentHolograms
        │   ├── audit/                      # Sistema de auditoría
        │   ├── scheduledevent/             # Eventos programados
        │   ├── upgrade/                    # Mejoras de clan
        │   ├── message/                    # i18n (6 idiomas)
        │   └── util/                       # 6+ utilidades
        └── resources/
            ├── plugin.yml
            ├── config.yml
            ├── guis/                       # 34 archivos YAML de GUI
            └── messages/ (es, en, pt, fr, de, zh)

```

---

## 3. Compilación y Despliegue

### Requisitos
- **Java 21** (JDK)
- **Maven 3.9+**
- **Paper 1.21** (servidor)

### Compilar

```bash
cd ethernovaclans
mvn clean package -DskipTests
```

### JARs Generados

| JAR | Ubicación | Descripción |
|-----|-----------|-------------|
| `ethernova-core-1.0.0.jar` | `core/target/` | Plugin base (requerido) |
| `ethernova-combat-1.0.0.jar` | `combat/target/` | Plugin de combate PvP |
| `ethernova-clans-1.0.0.jar` | `target/` | Plugin principal de clanes |

### Orden de Instalación

1. Copiar los 3 JARs a `plugins/`
2. Instalar **Vault** + un plugin de economía (EssentialsX, CMI, etc.)
3. (Opcional) Instalar PlaceholderAPI, ProtocolLib, DecentHolograms, WorldGuard
4. Iniciar el servidor — los plugins se cargan en orden: Core → Combat → Clans

---

## 4. Dependencias entre Plugins

```
EthernovaCore (ninguna dependencia Ethernova)
     ↑ depend
EthernovaCombat (depende de Core)
     ↑ softdepend
EthernovaClans (softdepend de Core y Combat)
```

| Plugin | Dependencias Hard | Dependencias Soft |
|--------|-------------------|-------------------|
| **Core** | — | Vault |
| **Combat** | EthernovaCore | — |
| **Clans** | — | EthernovaCore, EthernovaCombat, Vault, PlaceholderAPI, ProtocolLib, DecentHolograms, WorldGuard, WorldEdit, dynmap, BlueMap |

---

# PARTE II — ETHERNOVACORE (PLUGIN BASE)

---

## 5. Resumen de EthernovaCore

| Propiedad | Valor |
|-----------|-------|
| **Nombre** | `EthernovaCore` |
| **Main class** | `com.ethernova.core.EthernovaCore` |
| **Archivos Java** | 18 |
| **Líneas totales** | ~1,500 |
| **API** | Paper 1.21 |
| **Soft-depend** | Vault |
| **Comando** | `/ethernova` (alias: ninguno) |
| **Permiso** | `ethernova.admin` (op) |

### Propósito
EthernovaCore es la **capa de servicios compartidos** del ecosistema. Proporciona:

- **EventBus**: Sistema de eventos tipado para comunicación inter-plugin
- **PlayerProfile**: Perfiles de jugador persistentes (kills, deaths, KD ratio)
- **ContextManager**: Contextos de juego (war, arena, ffa) que modifican comportamiento
- **CooldownManager**: Sistema de cooldowns thread-safe
- **EconomyHook**: Abstracción de Vault para operaciones económicas
- **VisualManager**: Efectos visuales compartidos (partículas, títulos)
- **CoreGui**: Clase base abstracta para GUIs de inventario
- **CoreStorageManager**: Base de datos SQLite compartida
- **CoreMessageManager**: Sistema de mensajes i18n con MiniMessage

---

## 6. Clases de Core

### 6.1 EthernovaCore.java (Main Class — 242 líneas)

Singleton. Inicializa todos los managers en orden:
1. `CoreConfigManager` — Carga `config.yml`
2. `CoreMessageManager` — Carga mensajes según idioma
3. `CoreStorageManager` — Conecta SQLite, crea tablas
4. `CooldownManager` — Instancia
5. `PlayerProfileManager` — Carga perfiles desde DB
6. `ContextManager` — Instancia
7. `EconomyHook` — Conecta con Vault (si disponible)
8. `VisualManager` — Instancia
9. `EthernovaEventBus` — Instancia
10. Registra `CorePlayerListener`
11. Registra comando `/ethernova`

**getters públicos**: `getConfigManager()`, `getMessageManager()`, `getStorageManager()`, `getProfileManager()`, `getContextManager()`, `getCooldownManager()`, `getEconomyHook()`, `getVisualManager()`, `getEventBus()`

### 6.2 CoreConfigManager (46 líneas)

| Método | Descripción |
|--------|-------------|
| `reload()` | `reloadConfig()` de Bukkit |
| `getString(key, def)` | Lectura con default |
| `getInt(key, def)` | Lectura con default |
| `getBoolean(key, def)` | Lectura con default |
| `getLanguage()` | `config.language` (default: `"es"`) |
| `isDebug()` | `config.debug` (default: `false`) |

### 6.3 CoreMessageManager (55 líneas)

Carga `messages_{lang}.yml`. Métodos:

| Método | Descripción |
|--------|-------------|
| `reload()` | Recarga el archivo de mensajes del idioma actual |
| `get(key)` | Devuelve el mensaje raw (String) |
| `send(player, key, replacements...)` | Envía mensaje formateado con MiniMessage al jugador. Reemplaza `{prefix}` automáticamente. Pares clave-valor opcionales. |
| `getPrefix()` | Devuelve el prefijo `messages.prefix` |

### 6.4 CoreStorageManager (70 líneas)

| Método | Descripción |
|--------|-------------|
| `connect()` | Abre conexión SQLite a `plugins/EthernovaCore/database.db` |
| `createTables()` | Crea tabla `player_profiles` si no existe |
| `getConnection()` | Devuelve la `Connection` activa |
| `close()` | Cierra conexión |

**Esquema de la tabla `player_profiles`:**

| Columna | Tipo | Descripción |
|---------|------|-------------|
| `uuid` | `VARCHAR(36) PK` | UUID del jugador |
| `name` | `VARCHAR(16)` | Nombre actual |
| `kills` | `INT DEFAULT 0` | Kills PvP totales |
| `deaths` | `INT DEFAULT 0` | Deaths PvP totales |
| `first_join` | `BIGINT` | Timestamp primer login |
| `last_seen` | `BIGINT` | Timestamp último login |

### 6.5 PlayerProfile (45 líneas)

Record-like class con campos:

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `uuid` | `UUID` | UUID del jugador |
| `name` | `String` | Nombre del jugador |
| `kills` | `int` | Kills totales |
| `deaths` | `int` | Deaths totales |
| `firstJoin` | `long` | Primer login (ms) |
| `lastSeen` | `long` | Último login (ms) |

Métodos: `getKDRatio()` → `double`, `incrementKills()`, `incrementDeaths()`, `setKills(int)`, `setDeaths(int)`, todos los getters/setters.

### 6.6 PlayerProfileManager (85 líneas)

| Método | Descripción |
|--------|-------------|
| `loadProfile(UUID)` | Carga perfil de SQLite, crea si no existe |
| `saveProfile(PlayerProfile)` | INSERT OR REPLACE en `player_profiles` |
| `getProfile(UUID)` | Obtiene perfil en cache (HashMap) |
| `removeProfile(UUID)` | Remueve del cache |
| `saveAll()` | Guarda todos los perfiles (onDisable) |

### 6.7 ContextManager (40 líneas)

| Método | Descripción |
|--------|-------------|
| `setContext(UUID, String)` | Establece contexto: `"war"`, `"arena"`, `"ffa"`, `"survival"` |
| `getContext(UUID)` | Obtiene contexto actual (default: `"survival"`) |
| `removeContext(UUID)` | Elimina contexto |
| `isInContext(UUID, String)` | Verifica si está en un contexto específico |

### 6.8 CooldownManager (48 líneas)

| Método | Descripción |
|--------|-------------|
| `setCooldown(UUID, String, long ms)` | Establece un cooldown nombrado |
| `hasCooldown(UUID, String)` | Verifica si el cooldown sigue activo |
| `getRemainingCooldown(UUID, String)` | Milisegundos restantes |
| `removeCooldown(UUID, String)` | Elimina cooldown |
| `clearAll(UUID)` | Limpia todos los cooldowns del jugador |

Usa `ConcurrentHashMap<String, ConcurrentHashMap<UUID, Long>>` para thread-safety.

### 6.9 EconomyHook (55 líneas)

| Método | Descripción |
|--------|-------------|
| `isEnabled()` | Vault disponible y conectado |
| `getBalance(OfflinePlayer)` | Balance actual |
| `deposit(OfflinePlayer, double)` | Depositar dinero |
| `withdraw(OfflinePlayer, double)` | Retirar dinero |
| `has(OfflinePlayer, double)` | Verificar si tiene suficiente |
| `format(double)` | Formatear cantidad como texto |

### 6.10 VisualManager (58 líneas)

| Método | Descripción |
|--------|-------------|
| `sendTitle(Player, title, subtitle, fadeIn, stay, fadeOut)` | Envía título con MiniMessage |
| `sendActionBar(Player, text)` | Envía ActionBar con MiniMessage |
| `spawnParticle(Location, Particle, count, offsets)` | Genera partículas |
| `playSound(Player, Sound, volume, pitch)` | Reproduce sonido |

### 6.11 EthernovaEventBus (50 líneas)

Bus de eventos genérico tipado:

| Método | Descripción |
|--------|-------------|
| `subscribe(Class<T>, Consumer<T>)` | Suscribirse a un tipo de evento |
| `publish(Object event)` | Publicar evento a todos los suscriptores del tipo |
| `clear()` | Limpiar todas las suscripciones |

**Eventos definidos:**

| Evento (Record) | Campos |
|-----------------|--------|
| `PowerChangeEvent` | `UUID playerUuid`, `String playerName`, `int amount`, `String reason` |
| `EthernovaPlayerKillEvent` | `UUID killerUuid`, `UUID victimUuid`, `String context` |
| `ClanWarStartEvent` | `String clan1`, `String clan2` |
| `ClanWarEndEvent` | `String clan1`, `String clan2`, `String winner` |

### 6.12 CoreGui (Clase Abstracta — 85 líneas)

Base para GUIs de inventario:

| Método | Descripción |
|--------|-------------|
| `open()` | Crea inventario y lo abre al jugador |
| `handleClick(InventoryClickEvent)` | Enruta clicks |
| `close()` | Cierra inventario |
| **abstract** `populate()` | Las subclases llenan el inventario |
| **abstract** `onClick(int slot, ClickType)` | Las subclases manejan clicks |

### 6.13 CorePlayerListener (38 líneas)

| Evento | Acción |
|--------|--------|
| `PlayerJoinEvent` | Carga perfil, actualiza nombre y `lastSeen` |
| `PlayerQuitEvent` | null-safe: guarda perfil, limpia contexto, limpia cooldowns |

### 6.14 CoreCommand (34 líneas)

| Subcomando | Permiso | Acción |
|------------|---------|--------|
| `/ethernova reload` | `ethernova.admin` | Recarga config + mensajes |
| `/ethernova` | `ethernova.admin` | Muestra versión del plugin |

---

## 7. Configuración de Core

### config.yml

| Clave | Tipo | Default | Descripción |
|-------|------|---------|-------------|
| `language` | String | `"es"` | Idioma de mensajes (`es`, `en`) |
| `debug` | boolean | `false` | Modo debug |
| `database.type` | String | `"sqlite"` | Tipo de BD (solo SQLite) |
| `database.file` | String | `"database.db"` | Archivo SQLite |

### Claves de Mensajes (messages_es.yml)

| Clave | Descripción |
|-------|-------------|
| `messages.prefix` | Prefijo para todos los mensajes `[EthernovaCore]` |
| `messages.reload` | Mensaje de recarga exitosa |
| `messages.no-permission` | Sin permisos |
| `messages.player-only` | Solo jugadores |

---

## 8. API Pública de Core

Otros plugins acceden a Core así:

```java
// Obtener instancia
EthernovaCore core = (EthernovaCore) Bukkit.getPluginManager().getPlugin("EthernovaCore");

// Perfiles
PlayerProfile profile = core.getProfileManager().getProfile(player.getUniqueId());
profile.incrementKills();

// Economía
core.getEconomyHook().deposit(player, 500.0);

// EventBus
core.getEventBus().subscribe(PowerChangeEvent.class, event -> {
    // Manejar cambio de poder
});
core.getEventBus().publish(new EthernovaPlayerKillEvent(killerUuid, victimUuid, "pvp"));

// Contextos
core.getContextManager().setContext(player.getUniqueId(), "war");

// Cooldowns
core.getCooldownManager().setCooldown(player.getUniqueId(), "teleport", 5000);

// Visuals
core.getVisualManager().sendTitle(player, "<red>¡Cuidado!", "<gray>Estás en combate", 10, 40, 10);
```

---

# PARTE III — ETHERNOVACOMBAT (PLUGIN DE COMBATE PVP)

---

## 9. Resumen de EthernovaCombat

| Propiedad | Valor |
|-----------|-------|
| **Nombre** | `EthernovaCombat` |
| **Main class** | `com.ethernova.combat.EthernovaCombat` |
| **Archivos Java** | 46 |
| **Líneas totales** | ~4,500 |
| **API** | Paper 1.21 |
| **Depend** | EthernovaCore |
| **Comandos** | `/combat`, `/combatadmin`, `/logout` |
| **Permisos** | `ethernova.combat.bypass.tag`, `ethernova.combat.admin` |
| **Paquetes** | 24 |

### Propósito
Sistema completo de combate PvP con:

- **Combat Tag**: Sistema de etiquetado con BossBar + ActionBar de 15s (configurable)
- **NPC Logout**: Villager NPC que reemplaza al jugador si se desconecta en combate
- **Kill Streaks**: Rachas con milestone rewards (dinero, efectos, títulos)
- **Kill Rewards**: Recompensas por kill (fijo/random/porcentaje del balance)
- **Revenge System**: Bonus por matar a tu último asesino
- **Newbie Protection**: Inmunidad PvP temporal para nuevos jugadores
- **Anti-Abuse**: Detección de multi-account, kill farming, location farming
- **3-Tier Sanctions**: Warn+Kick → TempBan 1d → Stats Reset + TempBan 3d
- **Loot Protection**: Ítems protegidos para el killer por 30s
- **Death Effects**: Partículas, sonidos, relámpagos en muerte PvP
- **Visual Effects**: Compass tracking, heartbeat, combat flash, kill feed
- **Per-World Config**: Cada mundo puede tener configuración independiente
- **Combat Profiles**: survival/war/arena/ffa con duración y reglas distintas
- **Module System**: API extensible para integración con otros plugins
- **Admin GUI**: 13 pantallas de administración completas
- **Safe Logout**: `/logout` con cuenta regresiva

---

## 10. Clases de Combat

### Índice Completo de 46 Clases

| # | Package | Clase | Tipo | Líneas |
|---|---------|-------|------|--------|
| 1 | `combat` | `EthernovaCombat` | JavaPlugin | ~160 |
| 2 | `combat.tag` | `CombatTag` | Data class | ~40 |
| 3 | `combat.tag` | `CombatTagManager` | Manager | ~145 |
| 4 | `combat.tag` | `CombatTagEvent` | Bukkit Event | ~42 |
| 5 | `combat.tag` | `CombatAPI` | API Facade | ~36 |
| 6 | `combat.config` | `CombatConfigManager` | Manager | ~57 |
| 7 | `combat.message` | `CombatMessageManager` | Manager | ~65 |
| 8 | `combat.command` | `CombatCommand` | CommandExecutor | ~40 |
| 9 | `combat.command` | `CombatAdminCommand` | CommandExecutor | ~70 |
| 10 | `combat.command` | `LogoutCommand` | CommandExecutor | ~17 |
| 11 | `combat.listener` | `CombatDamageListener` | Listener | ~55 |
| 12 | `combat.listener` | `CombatDeathListener` | Listener | ~75 |
| 13 | `combat.listener` | `CombatDisconnectListener` | Listener | ~65 |
| 14 | `combat.listener` | `CombatCheatListener` | Listener | ~85 |
| 15 | `combat.listener` | `CombatMoveListener` | Listener | ~22 |
| 16 | `combat.listener` | `CombatItemListener` | Listener | ~40 |
| 17 | `combat.listener` | `CombatNPCListener` | Listener | ~27 |
| 18 | `combat.listener` | `ClanIntegrationListener` | EventBus | ~50 |
| 19 | `combat.cheat` | `CheatPreventionManager` | Manager | ~45 |
| 20 | `combat.npc` | `CombatNPC` | Data class | ~32 |
| 21 | `combat.npc` | `CombatNPCManager` | Manager | ~110 |
| 22 | `combat.penalty` | `PenaltyManager` | Manager | ~42 |
| 23 | `combat.killstreak` | `KillStreakManager` | Manager | ~110 |
| 24 | `combat.reward` | `RewardManager` | Manager | ~85 |
| 25 | `combat.revenge` | `RevengeManager` | Manager | ~65 |
| 26 | `combat.newbie` | `NewbieProtectionManager` | Manager | ~55 |
| 27 | `combat.abuse` | `KDRAbuseManager` | Manager (legacy) | ~55 |
| 28 | `combat.detection` | `AbuseRecord` | Record | ~18 |
| 29 | `combat.detection` | `DetectionManager` | Manager | ~155 |
| 30 | `combat.detection` | `MultiAccountDetector` | Detector | ~100 |
| 31 | `combat.detection` | `KillFarmDetector` | Detector | ~130 |
| 32 | `combat.detection` | `SanctionManager` | Manager | ~160 |
| 33 | `combat.loot` | `LootProtectionManager` | Manager | ~30 |
| 34 | `combat.death` | `DeathEffectManager` | Manager | ~42 |
| 35 | `combat.visual` | `CombatVisualManager` | Manager | ~175 |
| 36 | `combat.profile` | `CombatProfileManager` | Manager | ~38 |
| 37 | `combat.module` | `CombatModule` | Interface | ~50 |
| 38 | `combat.module` | `ModuleSetting` | Record | ~20 |
| 39 | `combat.module` | `CombatModuleRegistry` | Registry | ~35 |
| 40 | `combat.world` | `WorldCombatConfig` | Data class | ~90 |
| 41 | `combat.world` | `WorldConfigManager` | Manager | ~110 |
| 42 | `combat.gui` | `GUIHelper` | Utility | ~140 |
| 43 | `combat.gui` | `AdminGUIManager` | Manager (937 líneas) | ~937 |
| 44 | `combat.gui` | `AdminGUIListener` | Listener | ~545 |
| 45 | `combat.logout` | `SafeLogoutManager` | Manager | ~45 |

---

## 11. Sistema de Combat Tag

### Flujo End-to-End

```
Jugador A ataca a Jugador B
     │
     ▼
CombatDamageListener.onDamage()
     ├─ ¿Config del mundo permite combat tag? → No → return
     ├─ ¿Víctima tiene protección newbie? → Sí → cancelar daño
     ├─ ¿Atacante tiene protección newbie? → Sí → quitar protección
     ├─ Detectar perfil (survival/war/arena/ffa)
     ├─ CombatTagManager.tag(A, B)  ← Bidireccional
     │   ├─ ¿Tiene permiso bypass? → return
     │   ├─ Fire CombatTagEvent (cancelable)
     │   ├─ Crear/extender CombatTag
     │   ├─ Crear BossBar con timer
     │   ├─ Enviar mensaje "tagged"
     │   └─ Mostrar flash de combate ⚔
     ├─ Mostrar partículas de hit
     └─ Cancelar safe logouts pendientes
     
     ┌───────── Tick Task (cada 1 segundo) ─────────┐
     │  Por cada tag activo:                         │
     │  • Decrementar timer                          │
     │  • Si expiró → untag()                       │
     │  • Actualizar BossBar (progreso + color)      │
     │  • Enviar ActionBar con tiempo restante       │
     └───────────────────────────────────────────────┘

Tag expira → untag()
     ├─ Remover del mapa de tags
     ├─ Ocultar + remover BossBar
     └─ Enviar mensaje "untagged"
```

### CombatTag (Data Class)

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `player` | `UUID` | UUID del jugador taggeado |
| `enemy` | `UUID` | UUID del enemigo |
| `remaining` | `AtomicInteger` | Segundos restantes (thread-safe) |
| `maxDuration` | `int` | Duración máxima |
| `profile` | `String` | Perfil activo (survival/war/arena/ffa) |
| `bossBar` | `BossBar` | Barra visual del tag |

### CombatTagManager (145 líneas)

| Método | Descripción |
|--------|-------------|
| `tag(Player, Player, String profile)` | Crea tag bidireccional con BossBar |
| `untag(UUID)` | Remueve tag y BossBar |
| `isTagged(UUID)` / `isTagged(Player)` | Verifica si está en combate |
| `getTag(UUID)` | Obtiene el CombatTag activo |
| `getEnemy(UUID)` | UUID del enemigo actual |
| `getActiveTags()` | Todos los tags activos |
| `forceUntag(UUID)` | Forzar untag (admin) |
| `untagAll()` | Remover todos los tags (onDisable) |

### Bloqueos Durante Combate

| Bloqueo | Config Key | Default |
|---------|-----------|---------|
| Vuelo | `block-flight` | ✓ |
| Comandos | `block-commands` | ✓ (home, spawn, tpa, tp, warp, back) |
| Ender Pearl | `block-enderpearl` | ✓ |
| Chorus Fruit | `block-chorus` | ✓ |
| Teleporte | `block-teleport` | ✓ |
| Elytra | `block-elytra` | ✓ |
| Gamemode | `block-gamemode` | ✓ |
| Riptide | `block-riptide` | ✓ |

---

## 12. Sistema de Detección de Abuso

### Arquitectura de 4 Capas

```
Kill ocurre
     │
     ▼
DetectionManager.checkKill(killer, victim)
     │
     ├── MultiAccountDetector
     │   └── ¿Misma IP? → MULTI_ACCOUNT
     │
     ├── KillFarmDetector
     │   ├── ¿Misma víctima > 3 veces en 30min? → KILL_FARMING
     │   ├── ¿Víctima con low gear > 5 veces? → LOW_GEAR_FARM
     │   └── ¿Kills en radio < 10 bloques > 5? → LOCATION_FARM
     │
     ▼
SanctionManager.applySanction(player, offense)
     │
     ├── Tier 1: Warning + Kick + Nullify kills
     ├── Tier 2: TempBan 1 día + Nullify + Alert admins
     └── Tier 3+: Stats Reset + TempBan 3 días + Alert
```

### Tipos de Abuso Detectados

| Tipo | Detector | Threshold | Ventana |
|------|----------|-----------|---------|
| `MULTI_ACCOUNT` | `MultiAccountDetector` | Misma IP | — |
| `KILL_FARMING` | `KillFarmDetector` | 3 kills misma víctima | 30 min |
| `LOW_GEAR_FARM` | `KillFarmDetector` | 5 kills a low-gear | — |
| `LOCATION_FARM` | `KillFarmDetector` | 5 kills en 10 bloques | — |

---

## 13. GUI de Administración

### 13 Pantallas del Admin GUI

| # | Pantalla | Comando | Descripción |
|---|----------|---------|-------------|
| 1 | **Panel Principal** | `/combatadmin` | Hub con 7 botones de navegación |
| 2 | **Mundos** | — | Lista paginada de todos los mundos |
| 3 | **Config Mundo (General)** | — | Tag, duración, keep inv, NPC, loot |
| 4 | **Config Mundo (Restricciones)** | — | Vuelo, pociones, pearls, craft, comandos |
| 5 | **Config Mundo (Visual)** | — | BossBar, ActionBar, newbie |
| 6 | **Módulos** | — | Lista de módulos del ecosistema |
| 7 | **Detección** | — | Toggles multi-account y kill farm |
| 8 | **Sospechosos** | — | Jugadores flaggeados por violaciones |
| 9 | **Logs** | — | Historial paginado de detecciones |
| 10 | **Config Global (Combat Tag)** | — | Duración, extensión, bloqueos |
| 11 | **Config Global (Visual)** | — | BossBar, ActionBar, efectos |
| 12 | **Config Global (NPC & Penalty)** | — | NPC, penalizaciones, venganza |
| 13 | **Combates Activos** | — | Dashboard en vivo (auto-refresh 3s) |

### Navegación del GUI

```
Panel Principal ─┬─ Mundos ──── Config Mundo (3 tabs)
                 ├─ Config Global (3 tabs)
                 ├─ Módulos ──── Config Módulo
                 ├─ Detección
                 ├─ Sospechosos
                 ├─ Logs
                 └─ Combates Activos
```

---

## 14. Configuración de Combat

### Archivos de Configuración

| Archivo | Descripción |
|---------|-------------|
| `config.yml` | Configuración principal (tag, NPC, penalties, anti-abuse, visuals) |
| `killstreaks.yml` | Milestones de rachas (5, 10, 25 kills) |
| `rewards.yml` | Recompensas por kill y penalidades por muerte |
| `profiles.yml` | 4 perfiles de combate (survival/war/arena/ffa) |
| `worlds.yml` | Config por mundo (generado en runtime) |
| `messages_es.yml` | Mensajes en español |
| `messages_en.yml` | Mensajes en inglés |

### Config Principal (config.yml) — Resumen

| Sección | Claves Principales |
|---------|-------------------|
| **combat-tag** | `default-duration: 15`, `max-duration: 30`, `extend-on-hit: true`, 8 bloqueos, BossBar, ActionBar |
| **combat-npc** | `enabled: true`, `duration: 30`, `drop-items: true`, `kill-means-death: true` |
| **combat-log.penalty** | `money-loss: 500`, `power-loss: 20`, `broadcast: true` |
| **newbie-protection** | `enabled: true`, `duration-minutes: 120`, `lose-on-attack: true` |
| **anti-abuse** | `block-same-ip: true`, `max-repeat-kills: 3`, `repeat-window-minutes: 30` |
| **death-effects** | `particle: true`, `sound: ENTITY_PLAYER_DEATH`, `lightning: false` |
| **visuals** | `hit-effect`, `combat-flash`, `compass-tracking`, `particles`, `heartbeat`, `kill-feed` |
| **revenge** | `enabled: true`, `money-bonus: 100` |
| **killstreaks** | `enabled: true`, `reset-on-death: true` |
| **detection** | Multi-account + Kill Farm + Sanctions + Alert channel |
| **loot-protection** | `enabled: true`, `duration: 30` |
| **safe-logout** | `duration: 10`, `cancel-on-damage: true` |

### Perfiles de Combate (profiles.yml)

| Perfil | Duración | Block Flight | Block Cmds | Streaks | Rewards | Newbie |
|--------|----------|-------------|-----------|---------|---------|--------|
| `survival` | 15s | ✓ | ✓ | ✓ | ✓ | ✓ |
| `war` | 30s | ✓ | ✓ | ✓ | ✓ | ✗ |
| `arena` | 20s | ✓ | ✓ | ✗ | ✗ | ✗ |
| `ffa` | 10s | ✓ | ✗ | ✓ | ✓ | ✗ |

### Kill Streak Milestones (killstreaks.yml)

| Racha | Broadcast | Sonido | Reward |
|-------|-----------|--------|--------|
| **5** | "🔥 {player} lleva 5 kills" | `ENTITY_PLAYER_LEVELUP` | $500 + Speed I (10s) |
| **10** | "🔥🔥 {player} lleva 10 kills" | `ENTITY_ENDER_DRAGON_GROWL` | $2000 + Speed II + Strength I + Title |
| **25** | "☠ {player} ¡LEYENDA!" | `ENTITY_WITHER_SPAWN` | $10000 + Speed III + Strength II + Lightning |

### Recompensas (rewards.yml)

| Tipo | Modo | Default |
|------|------|---------|
| Kill Money | `RANDOM` | $50–$200 |
| Kill XP | Fixed | 50 XP |
| Death Penalty Money | `FIXED` (disabled) | $100 |
| Death Penalty XP | Fixed (disabled) | 3 niveles |
| Revenge Bonus | Fixed | $100 × 2.0 multiplier |

---

# PARTE IV — ETHERNOVACLANS (PLUGIN PRINCIPAL)

---

## 15. Resumen de EthernovaClans

| Propiedad | Valor |
|-----------|-------|
| **Nombre** | `EthernovaClans` |
| **Main class** | `com.ethernova.clans.EthernovaClans` |
| **Archivos Java** | 153+ |
| **Líneas totales** | ~30,000+ |
| **API** | Paper 1.21 |
| **Soft-depend** | EthernovaCore, EthernovaCombat, Vault, PlaceholderAPI, ProtocolLib, DecentHolograms, WorldGuard, WorldEdit, dynmap, BlueMap |
| **Comandos** | `/clan` (aliases: `/c`, `/clans`), `/clanadmin` (aliases: `/cadmin`, `/ca`) |
| **Managers** | 30+ |
| **GUI Menus** | 32 |
| **SQL Tables** | 25+ |
| **WebMap Endpoints** | 47 |

### Propósito
El plugin principal del ecosistema. Sistema completo de clanes con:

- **Clanes**: Crear, gestionar, invitar, roles (Leader, Co-Leader, Officer, Member, Recruit)
- **Territorios**: Chunks claimeados con 12 flags de protección
- **Guerra**: Sistema de guerra con declaración, rendición, evento temporal
- **Alianzas**: Alianzas entre clanes con chat compartido
- **Diplomacia**: 4 tipos de tratados (comercio, defensa, no-agresión, vasallaje)
- **Asedios**: TnT + beacon para conquistar territorios enemigos
- **Poder**: Sistema de poder por jugador que limita territorios
- **Economía**: Banco de clan, impuestos, salarios por rol, tienda
- **Niveles**: 10 niveles con requisitos y beneficios progresivos
- **Habilidades**: 8 skills con niveles de proficiencia
- **Misiones**: Diarias y semanales con rewards
- **Logros**: Sistema de achievements del clan
- **Temporadas**: Ciclos competitivos con rankings
- **Naciones**: Agrupación de clanes en naciones
- **Puestos Avanzados**: 5 tipos (Mining, Farming, Military, Trading, Research)
- **Planos**: Blueprints de construcciones con placement
- **Espionaje**: SocialSpy, infiltración, reportes intel
- **GUI**: 32 menús configurables por YAML con 100+ placeholders
- **WebMap**: Servidor HTTP integrado con 47 API endpoints + terrain renderer
- **Hologramas**: Integración con DecentHolograms
- **Auditoría**: Log de todas las acciones del clan

---

## 16. Modelo de Datos del Clan

### Clan.java (Modelo Principal)

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | `String` | ID único (UUID string) |
| `name` | `String` | Nombre del clan |
| `tag` | `String` | Tag corto (3-5 chars) |
| `description` | `String` | Descripción |
| `leader` | `UUID` | UUID del líder |
| `members` | `Map<UUID, ClanMember>` | Miembros |
| `homeLocation` | `Location` | Base del clan |
| `createdAt` | `long` | Timestamp de creación |
| `level` | `int` | Nivel actual |
| `bank` | `ClanBank` | Banco del clan |
| `kills` | `int` | Kills totales PvP |
| `deaths` | `int` | Deaths totales |
| `friendlyFire` | `boolean` | Fuego amigo |
| `color` | `String` | Color del clan |

### ClanMember.java

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `uuid` | `UUID` | UUID del jugador |
| `name` | `String` | Nombre |
| `role` | `ClanRole` | Rol (LEADER, CO_LEADER, OFFICER, MEMBER, RECRUIT) |
| `rank` | `ClanRank` | Rango numérico |
| `joinedAt` | `long` | Timestamp de ingreso |
| `power` | `double` | Poder individual |
| `contribution` | `double` | Contribución económica |

### ClanRole (Enum)

| Rol | Prioridad | Descripción |
|-----|-----------|-------------|
| `LEADER` | 5 | Líder — control total |
| `CO_LEADER` | 4 | Co-líder — casi todo excepto disolver |
| `OFFICER` | 3 | Oficial — invitar, kickear reclutas, claim |
| `MEMBER` | 2 | Miembro — participar |
| `RECRUIT` | 1 | Recluta — acceso básico |

### ClanBank.java

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `balance` | `double` | Balance actual |
| `transactions` | `List<Transaction>` | Historial de transacciones |

---

## 17. Comandos

### /clan — Comando Principal (40+ Subcomandos)

| Subcomando | Args | Permiso | Descripción |
|------------|------|---------|-------------|
| `create` | `<nombre> <tag>` | `ethernova.clans.create` | Crear clan |
| `disband` | — | Leader | Disolver clan |
| `invite` | `<jugador>` | Officer+ | Invitar jugador |
| `join` | `<clan>` | — | Unirse por invitación |
| `leave` | — | — | Salir del clan |
| `kick` | `<jugador>` | Officer+ | Expulsar miembro |
| `promote` | `<jugador>` | Leader/Co-Leader | Promover rango |
| `demote` | `<jugador>` | Leader/Co-Leader | Degradar rango |
| `leader` | `<jugador>` | Leader | Transferir liderazgo |
| `info` | `[clan]` | — | Ver información |
| `list` | `[pagina]` | — | Listar clanes |
| `chat` | `[mensaje]` | — | Chat de clan |
| `allychat` | `[mensaje]` | — | Chat de aliados |
| `sethome` | — | Officer+ | Establecer base |
| `home` | — | — | Teleportarse a base |
| `claim` | — | Officer+ | Reclamar chunk |
| `unclaim` | — | Officer+ | Liberar chunk |
| `map` | — | — | Ver mapa de chunks |
| `ally` | `<clan>` | Leader/Co-Leader | Proponer alianza |
| `neutral` | `<clan>` | Leader/Co-Leader | Romper alianza |
| `enemy` | `<clan>` | Leader/Co-Leader | Declarar enemigo |
| `war` | `<clan>` | Leader | Declarar guerra |
| `surrender` | — | Leader | Rendirse en guerra |
| `deposit` | `<cantidad>` | — | Depositar al banco |
| `withdraw` | `<cantidad>` | Officer+ | Retirar del banco |
| `balance` | — | — | Ver balance del banco |
| `shop` | — | — | Abrir tienda |
| `missions` | — | — | Ver misiones |
| `achievements` | — | — | Ver logros |
| `skills` | — | — | Ver habilidades |
| `upgrade` | — | Leader | Mejorar clan |
| `fly` | — | — | Activar vuelo en territorio |
| `shield` | — | Leader | Activar escudo |
| `top` | `[pagina]` | — | Rankings |
| `gui` | — | — | Abrir menú principal |
| `outpost` | `<subcomando>` | Officer+ | Gestionar puestos |
| `nation` | `<subcomando>` | Leader | Gestionar nación |
| `treaty` | `<tipo> <clan>` | Leader | Proponer tratado |
| `description` | `<texto>` | Officer+ | Cambiar descripción |
| `color` | `<color>` | Officer+ | Cambiar color |
| `friendlyfire` | — | Leader | Toggle fuego amigo |
| `tax` | — | Leader | Ver impuestos |
| `season` | — | — | Ver temporada actual |
| `blueprint` | `<subcomando>` | Officer+ | Gestionar planos |

### /clanadmin — Comandos de Admin (18 Subcomandos)

| Subcomando | Descripción |
|------------|-------------|
| `reload` | Recarga toda la configuración |
| `forcedisband <clan>` | Disolver clan forzosamente |
| `forcewar <clan1> <clan2>` | Forzar guerra |
| `endwar <clan1> <clan2>` | Terminar guerra |
| `setlevel <clan> <nivel>` | Establecer nivel del clan |
| `setpower <jugador> <poder>` | Establecer poder del jugador |
| `spy` | Toggle modo espía |
| `socialspy` | Toggle social spy (ver chats privados) |
| `infiltrate <clan>` | Infiltrar chat de clan |
| `intel <clan>` | Generar reporte de inteligencia |
| `bypass` | Toggle bypass de restricciones |
| `unclaim <x> <z> [world]` | Liberar chunk específico |
| `setbank <clan> <cantidad>` | Establecer balance banco |
| `gui` | Abrir GUI admin |
| `season start/end/reset` | Control de temporada |
| `addachievement <clan> <id>` | Otorgar logro |
| `completeachievement <clan> <id>` | Completar logro |
| `lookup <jugador>` | Buscar info detallada |

---

## 18. Los 30+ Managers

### Managers del Modelo Base

| Manager | Archivo | Descripción |
|---------|---------|-------------|
| **ClanManager** | `clan/ClanManager.java` | CRUD de clanes, búsqueda, validación de nombres/tags |
| **ConfigManager** | `config/ConfigManager.java` | Carga `config.yml` completo, todos los getters |
| **MessageManager** | `message/MessageManager.java` | i18n con 6 idiomas, MiniMessage, placeholders |
| **StorageManager** | `storage/StorageManager.java` | SQLite con 25+ tablas, CRUD completo |
| **EconomyManager** | `economy/EconomyManager.java` | Integración Vault para transacciones |

### Managers de Sistemas de Juego

| Manager | Descripción |
|---------|-------------|
| **PowerManager** | Poder por jugador (max=10, min=-10), regen por hora, pérdida por muerte |
| **TerritoryManager** | Claim/unclaim chunks, 12 flags de protección, autoclaim, mapa visual |
| **WarManager** | Declaración, timer, kills tracker, rendición, recompensas al ganador |
| **AllianceManager** | Propuestas de alianza, aceptar/rechazar, chat compartido |
| **DiplomacyManager** | 4 tipos: TRADE, DEFENSE, NON_AGGRESSION, VASSALAGE |
| **SiegeManager** | Asedios con TNT y beacon, progreso, defensa, conquista |
| **InvitationManager** | Invitaciones con expiración, aceptar/rechazar |
| **ClanChatManager** | Chat de clan, chat de aliados, toggle mode, format |
| **ClanBankManager** | Depósitos, retiros, historial de transacciones |
| **ClanLevelManager** | 10 niveles con requisitos (miembros, kills, banco, power) |
| **ShieldManager** | Escudos temporales anti-guerra (24h, cooldown 7d) |

### Managers de Sistemas Avanzados

| Manager | Descripción |
|---------|-------------|
| **ClanSkillManager** | 8 habilidades: Mining, Farming, Combat, Archery, Defense, Speed, Luck, Wisdom |
| **MissionManager** | Misiones diarias y semanales con progreso y rewards |
| **AchievementManager** | Logros desbloqueables del clan |
| **ClanShopManager** | Tienda con ítems comprables por puntos/dinero |
| **FlyManager** | Vuelo en territorio propio con cancelación automática |
| **TeleportManager** | Delays, warmup, cancelación por movimiento/daño |
| **SalaryManager** | Pagos automáticos por rol desde el banco del clan |
| **NationManager** | Naciones (agrupaciones de clanes) con líder de nación |
| **OutpostManager** | 5 tipos de puestos: Mining, Farming, Military, Trading, Research |
| **BlueprintManager** | Planos de construcción guardados/cargados |
| **SeasonManager** | Temporadas competitivas con puntuación y rankings |
| **TaxManager** | Impuestos periódicos cobrados del banco |
| **SpyManager** | Modo espía, social spy, infiltración, reportes intel |
| **NametagManager** | Nametags dinámicos con color de clan + tag |
| **UpgradeManager** | Sistema de mejoras comprables para el clan |
| **EventScheduler** | Eventos programados (guerras automáticas, bonuses) |
| **AuditManager** | Log de todas las acciones del clan a BD |
| **HologramManager** | Integración DecentHolograms para rankings |

### Managers de Integración

| Manager | Descripción |
|---------|-------------|
| **GUIManager** | Routing de 30 menús, control de estado |
| **PlaceholderExpansion** | 50+ placeholders para PlaceholderAPI |
| **CoreHook** | Bridge con EthernovaCore (EventBus, profiles, economy) |
| **CombatHook** | Bridge con EthernovaCombat (CombatAPI) |
| **DynmapHook** | Renderizado de territorios en Dynmap |
| **BlueMapHook** | Renderizado de territorios en BlueMap |
| **WorldGuardHook** | Integración de regiones WorldGuard |
| **DiscordWebhook** | Notificaciones a Discord |
| **ConfirmationManager** | Confirmaciones de acciones destructivas |

---

## 19. Sistema GUI

### 32 Menús Configurables

Todos los menús extienden `AbstractGui` (852 líneas) y se configuran via YAML en `guis/`.

| # | Menú | Archivo YAML | Descripción |
|---|------|-------------|-------------|
| 1 | Main Menu | `main.yml` | Hub principal del clan |
| 2 | Clan Info | `info.yml` | Información detallada |
| 3 | Members | `members.yml` | Lista de miembros paginada |
| 4 | Member Detail | `member_detail.yml` | Detalle de miembro |
| 5 | Territory | `territory.yml` | Mapa de territorios |
| 6 | Wars | `wars.yml` | Guerras activas |
| 7 | Alliances | `alliances.yml` | Lista de alianzas |
| 8 | Bank | `bank.yml` | Gestión del banco |
| 9 | Shop | `shop.yml` | Tienda del clan |
| 10 | Missions | `missions.yml` | Misiones activas |
| 11 | Achievements | `achievements.yml` | Logros del clan |
| 12 | Skills | `skills.yml` | Habilidades del clan |
| 13 | Settings | `settings.yml` | Configuración del clan |
| 14 | Invite | `invite.yml` | Invitar jugadores |
| 15 | Upgrade | `upgrade.yml` | Sistema de mejoras |
| 16 | Top Clans | `top.yml` | Rankings |
| 17 | Diplomacy | `diplomacy.yml` | Tratados diplomáticos |
| 18 | Season | `season.yml` | Temporada actual |
| 19 | Outposts | `outposts.yml` | Puestos avanzados |
| 20 | Nation | `nation.yml` | Gestión de nación |
| 21 | Blueprint | `blueprint.yml` | Planos |
| 22 | Fly | `fly.yml` | Control de vuelo |
| 23 | Salary | `salary.yml` | Salarios |
| 24 | Tax | `tax.yml` | Impuestos |
| 25 | Shield | `shield.yml` | Escudo |
| 26 | Create | `create.yml` | Crear clan |
| 27 | Confirm | `confirm.yml` | Confirmaciones |
| 28 | Role Select | `role_select.yml` | Seleccionar rol |
| 29 | Color Select | `color_select.yml` | Seleccionar color |
| 30 | Flag Editor | `flag_editor.yml` | Editor de territory flags |
| 31 | Admin | `admin.yml` | Panel administrativo |
| 32 | Spy | `spy.yml` | Panel de espionaje |

### Características del Framework GUI

- **100+ Placeholders**: `{clan_name}`, `{clan_tag}`, `{clan_members}`, `{clan_power}`, `{clan_bank}`, `{clan_level}`, `{player_role}`, `{shield_status}`, `{war_count}`, etc.
- **Acciones**: `[close]`, `[open]`, `[command]`, `[console]`, `[message]`, `[sound]`, `[title]`
- **Acciones compuestas**: Separadas por `;;`
- **Requisitos**: `role:`, `level:`, `permission:`
- **Animación**: Border de cristal arcoíris configurable
- **Anti-spam**: Debounce de 200ms entre clicks
- **Skull customizado**: `skull-owner:` para cabezas de jugador

---

## 20. WebMap Server

### Servidor HTTP Integrado (2,210 líneas)

Puerto por defecto: **8095** (configurable en `config.yml`)

### 47 API Endpoints

| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | `/api/clans` | Lista todos los clanes |
| GET | `/api/clans/{id}` | Detalle de un clan |
| GET | `/api/clans/{id}/members` | Miembros de un clan |
| GET | `/api/clans/{id}/territories` | Territorios del clan |
| GET | `/api/clans/{id}/wars` | Guerras del clan |
| GET | `/api/clans/{id}/alliances` | Alianzas del clan |
| GET | `/api/clans/{id}/bank` | Estado del banco |
| GET | `/api/clans/{id}/achievements` | Logros del clan |
| GET | `/api/clans/{id}/missions` | Misiones activas |
| GET | `/api/clans/{id}/skills` | Habilidades |
| GET | `/api/clans/{id}/upgrades` | Mejoras |
| GET | `/api/clans/{id}/outposts` | Puestos avanzados |
| GET | `/api/clans/{id}/diplomacy` | Tratados diplomáticos |
| GET | `/api/players` | Lista jugadores online |
| GET | `/api/players/{uuid}` | Detalle de jugador |
| GET | `/api/players/{uuid}/clan` | Clan del jugador |
| GET | `/api/territories` | Todos los territorios |
| GET | `/api/territories/map` | Mapa de chunks |
| GET | `/api/territories/{world}/{x}/{z}` | Info de chunk específico |
| GET | `/api/wars` | Guerras activas |
| GET | `/api/wars/history` | Historial de guerras |
| GET | `/api/alliances` | Todas las alianzas |
| GET | `/api/nations` | Todas las naciones |
| GET | `/api/nations/{id}` | Detalle de nación |
| GET | `/api/top/clans` | Top clanes |
| GET | `/api/top/players` | Top jugadores |
| GET | `/api/top/power` | Top por poder |
| GET | `/api/top/kills` | Top por kills |
| GET | `/api/top/wealth` | Top por riqueza |
| GET | `/api/season` | Temporada actual |
| GET | `/api/season/rankings` | Rankings de temporada |
| GET | `/api/server` | Info del servidor |
| GET | `/api/server/stats` | Estadísticas globales |
| GET | `/api/map/render/{world}/{x}/{z}` | Render de terrain chunk |
| GET | `/api/map/overview/{world}` | Overview del mundo |
| GET | `/api/outposts` | Todos los puestos |
| GET | `/api/outposts/{type}` | Puestos por tipo |
| GET | `/api/siege` | Asedios activos |
| GET | `/api/events` | Eventos programados |
| GET | `/api/shop` | Ítems de tienda |
| GET | `/api/audit/{clan}` | Log de auditoría |
| GET | `/api/blueprints` | Planos disponibles |
| GET | `/api/taxes` | Info de impuestos |
| GET | `/api/shields` | Escudos activos |
| POST | `/api/auth/login` | Autenticación (si habilitada) |
| POST | `/api/webhook/discord` | Webhook de Discord |
| OPTIONS | `*` | CORS preflight |

### CORS & Seguridad
- Headers: `Access-Control-Allow-Origin: *`
- Content-Type: `application/json`
- Rate limiting configurable
- Auth token opcional

### TerrainRenderer
Renderiza chunks del terreno como imágenes para visualización en el mapa web. Soporta biomas, alturas, y overlay de territorios de clanes.

---

## 21. Base de Datos

### 25+ Tablas SQL (SQLite)

Gestionadas por `StorageManager` + `SchemaManager` (v6).

| Tabla | Descripción |
|-------|-------------|
| `clans` | Datos principales del clan |
| `clan_members` | Miembros de clanes |
| `clan_territories` | Chunks claimeados |
| `clan_territory_flags` | 12 flags por chunk |
| `clan_wars` | Guerras activas |
| `clan_war_history` | Historial de guerras |
| `clan_alliances` | Alianzas entre clanes |
| `clan_invitations` | Invitaciones pendientes |
| `clan_bank_transactions` | Historial bancario |
| `clan_achievements` | Progreso de logros |
| `clan_missions` | Progreso de misiones |
| `clan_skills` | Niveles de habilidades |
| `clan_shop_purchases` | Compras en tienda |
| `clan_upgrades` | Mejoras compradas |
| `clan_outposts` | Puestos avanzados |
| `clan_nations` | Naciones |
| `clan_nation_members` | Clanes en naciones |
| `clan_treaties` | Tratados diplomáticos |
| `clan_blueprints` | Planos guardados |
| `clan_seasons` | Temporadas |
| `clan_season_scores` | Puntuaciones de temporada |
| `clan_taxes` | Configuración de impuestos |
| `clan_salaries` | Configuración de salarios |
| `clan_shields` | Escudos activos |
| `clan_audit_log` | Log de auditoría |
| `clan_power` | Poder de jugadores |

### SchemaManager (Migraciones)

Versión actual: **v6**. Ejecuta migraciones incrementales:

| Versión | Cambios |
|---------|---------|
| v1 | Tablas base: clans, members, territories |
| v2 | Wars, alliances, invitations, bank |
| v3 | Achievements, missions, skills, shop |
| v4 | Nations, outposts, blueprints, seasons |
| v5 | Treaties, taxes, salaries, shields, audit |
| v6 | Territory flags, war history, season scores |

---

## 22. Configuración de Clans

### config.yml — Secciones Principales

| Sección | Descripción |
|---------|-------------|
| `clan.max-members` | Máximo de miembros (default: 20) |
| `clan.max-tag-length` | Longitud máxima del tag (5) |
| `clan.min-tag-length` | Longitud mínima del tag (2) |
| `clan.max-name-length` | Longitud máxima del nombre (24) |
| `clan.min-name-length` | Longitud mínima del nombre (3) |
| `clan.create-cost` | Costo de creación ($1000) |
| `clan.disband-confirm` | Requiere confirmación (true) |
| `power.max` | Poder máximo (10.0) |
| `power.min` | Poder mínimo (-10.0) |
| `power.start` | Poder inicial (5.0) |
| `power.per-kill` | Poder por kill (+0.5) |
| `power.per-death` | Poder por muerte (-1.0) |
| `power.regen-per-hour` | Regeneración por hora (+0.25) |
| `territory.max-claims` | Max chunks = members × power |
| `territory.home-required` | Requiere home para claim (true) |
| `war.min-members` | Miembros mínimos para guerra (3) |
| `war.duration-hours` | Duración máxima de guerra (48h) |
| `war.cooldown-hours` | Cooldown entre guerras (24h) |
| `shield.duration-hours` | Duración del escudo (24h) |
| `shield.cooldown-hours` | Cooldown del escudo (168h/7d) |
| `fly.enabled` | Vuelo en territorio (true) |
| `fly.cancel-on-combat` | Cancelar vuelo en combate (true) |
| `webmap.enabled` | Habilitar WebMap (true) |
| `webmap.port` | Puerto del WebMap (8095) |
| `level.max` | Nivel máximo (10) |

### Territory Flags (12 Flags)

| Flag | Default | Descripción |
|------|---------|-------------|
| `PVP` | `false` | Permitir PvP en territorio |
| `MONSTER_SPAWN` | `false` | Spawn de monstruos |
| `EXPLOSIONS` | `false` | Daño de explosiones |
| `FIRE_SPREAD` | `false` | Propagación de fuego |
| `BUILD` | `true` | Permitir construir (miembros) |
| `INTERACT` | `true` | Interactuar con bloques |
| `CHEST_ACCESS` | `true` | Acceso a cofres |
| `ANIMAL_DAMAGE` | `false` | Daño a animales |
| `ENDERPEARL` | `true` | Uso de ender pearl |
| `CHORUS_FRUIT` | `true` | Uso de chorus |
| `FLY` | `true` | Vuelo en territorio |
| `ENTER` | `true` | Permitir entrada |

### Idiomas Soportados (6)

| Idioma | Archivo |
|--------|---------|
| Español | `messages/messages_es.yml` (default) |
| Inglés | `messages/messages_en.yml` |
| Portugués | `messages/messages_pt.yml` |
| Francés | `messages/messages_fr.yml` |
| Alemán | `messages/messages_de.yml` |
| Chino | `messages/messages_zh.yml` |

---

# PARTE V — REFERENCIA RÁPIDA

---

## 23. Todos los Comandos

### EthernovaCore

| Comando | Permiso | Descripción |
|---------|---------|-------------|
| `/ethernova` | `ethernova.admin` | Info de versión |
| `/ethernova reload` | `ethernova.admin` | Recargar configuración |

### EthernovaCombat

| Comando | Permiso | Descripción |
|---------|---------|-------------|
| `/combat` | — | Ver estado de combate |
| `/combat status` | — | Estado detallado + racha |
| `/combat newbie` | — | Desactivar protección newbie |
| `/combatadmin` | `ethernova.combat.admin` | Abrir GUI admin |
| `/combatadmin gui` | `ethernova.combat.admin` | Abrir GUI admin |
| `/combatadmin reload` | `ethernova.combat.admin` | Recargar configuración |
| `/combatadmin tag <p1> <p2>` | `ethernova.combat.admin` | Forzar tag entre jugadores |
| `/combatadmin untag <player>` | `ethernova.combat.admin` | Quitar tag de un jugador |
| `/logout` | — | Safe logout con countdown |

### EthernovaClans

| Comando | Permiso | Descripción |
|---------|---------|-------------|
| `/clan create <nombre> <tag>` | `ethernova.clans.create` | Crear clan |
| `/clan disband` | Leader | Disolver clan |
| `/clan invite <jugador>` | Officer+ | Invitar |
| `/clan join <clan>` | — | Unirse |
| `/clan leave` | — | Salir |
| `/clan kick <jugador>` | Officer+ | Expulsar |
| `/clan promote <jugador>` | Co-Leader+ | Promover |
| `/clan demote <jugador>` | Co-Leader+ | Degradar |
| `/clan leader <jugador>` | Leader | Transferir liderazgo |
| `/clan info [clan]` | — | Ver info |
| `/clan list [página]` | — | Listar clanes |
| `/clan chat [msg]` | — | Chat de clan |
| `/clan allychat [msg]` | — | Chat aliados |
| `/clan sethome` | Officer+ | Establecer base |
| `/clan home` | — | Ir a base |
| `/clan claim` | Officer+ | Reclamar chunk |
| `/clan unclaim` | Officer+ | Liberar chunk |
| `/clan map` | — | Ver mapa |
| `/clan ally <clan>` | Co-Leader+ | Alianza |
| `/clan neutral <clan>` | Co-Leader+ | Romper alianza |
| `/clan enemy <clan>` | Co-Leader+ | Declarar enemigo |
| `/clan war <clan>` | Leader | Declarar guerra |
| `/clan surrender` | Leader | Rendirse |
| `/clan deposit <cant>` | — | Depositar |
| `/clan withdraw <cant>` | Officer+ | Retirar |
| `/clan balance` | — | Ver balance |
| `/clan shop` | — | Tienda |
| `/clan missions` | — | Misiones |
| `/clan achievements` | — | Logros |
| `/clan skills` | — | Habilidades |
| `/clan upgrade` | Leader | Mejorar clan |
| `/clan fly` | — | Vuelo |
| `/clan shield` | Leader | Escudo |
| `/clan top [página]` | — | Rankings |
| `/clan gui` | — | Menú GUI |
| `/clan outpost <sub>` | Officer+ | Puestos |
| `/clan nation <sub>` | Leader | Naciones |
| `/clan treaty <tipo> <clan>` | Leader | Tratados |
| `/clan description <texto>` | Officer+ | Descripción |
| `/clan color <color>` | Officer+ | Color |
| `/clan friendlyfire` | Leader | Fuego amigo |
| `/clan tax` | Leader | Impuestos |
| `/clan season` | — | Temporada |
| `/clan blueprint <sub>` | Officer+ | Planos |
| `/clanadmin reload` | `ethernova.clans.admin` | Recargar |
| `/clanadmin forcedisband <clan>` | `ethernova.clans.admin` | Disolver forzoso |
| `/clanadmin spy` | `ethernova.clans.spy` | Modo espía |
| `/clanadmin socialspy` | `ethernova.spy.socialspy` | Social spy |
| `/clanadmin infiltrate <clan>` | `ethernova.spy.infiltrate` | Infiltrar |
| `/clanadmin intel <clan>` | `ethernova.spy.intel` | Reporte intel |

---

## 24. Todos los Permisos

| Permiso | Plugin | Default | Descripción |
|---------|--------|---------|-------------|
| `ethernova.admin` | Core | op | Admin de Core |
| `ethernova.combat.bypass.tag` | Combat | op | Bypass de combat tag |
| `ethernova.combat.admin` | Combat | op | Admin de Combat |
| `ethernova.clans.use` | Clans | true | Uso básico de clanes |
| `ethernova.clans.admin` | Clans | op | Admin de Clanes |
| `ethernova.clans.create` | Clans | true | Crear clan |
| `ethernova.clans.bypass` | Clans | op | Bypass restricciones |
| `ethernova.clans.spy` | Clans | op | Modo espía |
| `ethernova.spy.socialspy` | Clans | op | Social spy |
| `ethernova.spy.infiltrate` | Clans | op | Infiltrar chat |
| `ethernova.spy.intel` | Clans | op | Reportes intel |
| `ethernova.clans.nation` | Clans | true | Features de nación |
| `ethernova.clans.outpost` | Clans | true | Features de puestos |

---

## 25. Todos los Archivos de Configuración

### EthernovaCore

| Archivo | Descripción |
|---------|-------------|
| `plugins/EthernovaCore/config.yml` | Configuración principal |
| `plugins/EthernovaCore/messages_es.yml` | Mensajes español |
| `plugins/EthernovaCore/messages_en.yml` | Mensajes inglés |
| `plugins/EthernovaCore/database.db` | Base de datos SQLite |

### EthernovaCombat

| Archivo | Descripción |
|---------|-------------|
| `plugins/EthernovaCombat/config.yml` | Config principal (tag, NPC, penalties, visuals) |
| `plugins/EthernovaCombat/killstreaks.yml` | Milestones de rachas |
| `plugins/EthernovaCombat/rewards.yml` | Recompensas/penalidades |
| `plugins/EthernovaCombat/profiles.yml` | 4 perfiles de combate |
| `plugins/EthernovaCombat/worlds.yml` | Config por mundo (auto-generado) |
| `plugins/EthernovaCombat/messages_es.yml` | Mensajes español |
| `plugins/EthernovaCombat/messages_en.yml` | Mensajes inglés |

### EthernovaClans

| Archivo | Descripción |
|---------|-------------|
| `plugins/EthernovaClans/config.yml` | Config principal |
| `plugins/EthernovaClans/database.db` | Base de datos SQLite |
| `plugins/EthernovaClans/guis/*.yml` | 34 archivos de GUI |
| `plugins/EthernovaClans/messages/messages_es.yml` | Español |
| `plugins/EthernovaClans/messages/messages_en.yml` | Inglés |
| `plugins/EthernovaClans/messages/messages_pt.yml` | Portugués |
| `plugins/EthernovaClans/messages/messages_fr.yml` | Francés |
| `plugins/EthernovaClans/messages/messages_de.yml` | Alemán |
| `plugins/EthernovaClans/messages/messages_zh.yml` | Chino |

---

## 26. Diagramas de Flujo

### Flujo de Muerte PvP (Completo)

```
PlayerDeathEvent
     │
     ▼
CombatDeathListener.onDeath()
     │
     ├─ Untag víctima
     ├─ Reset kill streak de víctima (si reset-on-death)
     │
     ├─ ¿Sin killer? → return
     │
     ├─ DetectionManager.checkKill(killer, victim)
     │  ├─ Multi-account check (misma IP)
     │  ├─ Kill farming check (misma víctima)
     │  ├─ Low gear check
     │  └─ Location pattern check
     │
     ├─ ¿Kill abusivo? → nullify (sin rewards, sin stats)
     │  └─ SanctionManager → tier punishment
     │
     ├─ Kill válido:
     │  ├─ Core: incrementKills() / incrementDeaths()
     │  ├─ KillStreakManager.addKill() + checkMilestone()
     │  ├─ RewardManager.processKillReward() (dinero + XP)
     │  ├─ RewardManager.processDeathPenalty() (opcional)
     │  ├─ DeathEffectManager (partículas, sonido, rayo)
     │  ├─ CombatVisualManager.sendKillFeed()
     │  ├─ RevengeManager.processRevenge() (bonus)
     │  └─ RevengeManager.recordKill()
     │
     ├─ Untag killer
     ├─ LootProtectionManager.protectLoot()
     └─ EventBus.publish(EthernovaPlayerKillEvent)
            │
            ▼
       EthernovaClans recibe → actualiza stats del clan,
       power, territorio, guerra, misiones, logros, temporada
```

### Flujo de Desconexión en Combate

```
PlayerQuitEvent (en combate)
     │
     ▼
CombatDisconnectListener.onQuit()
     ├─ Cancelar safe logout
     ├─ Untag
     ├─ CombatNPCManager.spawnNPC()
     │   ├─ Villager en ubicación → AI=false, nombre rojo
     │   ├─ Copiar inventario + armadura al NPC
     │   └─ Auto-despawn en 30s
     ├─ Limpiar inventario del jugador
     ├─ PenaltyManager.applyCombatLogPenalty()
     │   ├─ Withdraw $500
     │   ├─ EventBus → PowerChangeEvent (-20 power)
     │   ├─ Broadcast: "{player} se desconectó en combate"
     │   └─ Ejecutar comandos de consola
     └─ Broadcast muerte por combat log

     ┌─── Mientras NPC vive (30s) ───┐
     │  Otros pueden atacarlo/matarlo │
     │  Si muere → drop items         │
     │  Items protegidos para killer   │
     └────────────────────────────────┘

Jugador reconecta
     ├─ NPC fue matado → Kill al jugador (health=0)
     └─ NPC sobrevivió → Restaurar inventario
```

### Inicialización del Ecosistema

```
Servidor Paper 1.21 inicia
     │
     ├─ 1. EthernovaCore.onEnable()
     │      ├─ SQLite: database.db + tabla player_profiles
     │      ├─ ConfigManager, MessageManager
     │      ├─ ProfileManager, ContextManager, CooldownManager
     │      ├─ EconomyHook (Vault)
     │      ├─ VisualManager, EventBus
     │      └─ CorePlayerListener, CoreCommand
     │
     ├─ 2. EthernovaCombat.onEnable()
     │      ├─ Obtener EthernovaCore
     │      ├─ 4 configs: config, killstreaks, rewards, profiles
     │      ├─ CombatTagManager, CheatPreventionManager
     │      ├─ CombatNPCManager, PenaltyManager
     │      ├─ KillStreakManager, RewardManager, RevengeManager
     │      ├─ NewbieProtectionManager, KDRAbuseManager
     │      ├─ DetectionManager, LootProtectionManager
     │      ├─ DeathEffectManager, CombatVisualManager
     │      ├─ CombatProfileManager, CombatModuleRegistry
     │      ├─ WorldConfigManager, AdminGUIManager
     │      ├─ SafeLogoutManager
     │      ├─ 8 listeners Bukkit + ClanIntegrationListener
     │      └─ 3 comandos: /combat, /combatadmin, /logout
     │
     └─ 3. EthernovaClans.onEnable()
            ├─ Fase 1-4: Config, Mensajes, Storage, Economía
            ├─ Fase 5-8: ClanManager, Poder, Territorio, Guerra
            ├─ Fase 9-12: Alianzas, Invitaciones, Chat, GUI
            ├─ Fase 13-14: Niveles, Banco, Escudo, Mejoras
            ├─ Fase 15-16: Hooks (Core, Combat, Discord, Maps)
            │   ├─ CoreHook → suscribe a EventBus
            │   ├─ CombatHook → lee CombatAPI
            │   ├─ Dynmap/BlueMap hooks
            │   └─ WorldGuard hook
            ├─ Fase 17: Skills, Misiones, Logros, Tienda
            ├─ Fase 18: Naciones, Puestos, Planos
            ├─ Fase 19: Temporadas, Impuestos, Salarios
            ├─ Fase 20: Espionaje, Nametags, Placeholders
            ├─ Fase 21: WebMap server (puerto 8095)
            ├─ Fase 22: Hologramas, Auditoría
            ├─ Fase 23: Eventos programados
            ├─ 12 listeners Bukkit
            ├─ Comandos: /clan, /clanadmin
            └─ Tareas programadas (power regen, salarios, impuestos)
```

---

## Documentación Detallada por Plugin

Para documentación detallada clase por clase de cada plugin, consultar:

| Plugin | Archivo | Líneas |
|--------|---------|--------|
| **EthernovaCore** | [CORE_DOCUMENTATION.md](CORE_DOCUMENTATION.md) | 917 |
| **EthernovaCombat** | [combat/COMBAT_DOCUMENTATION.md](combat/COMBAT_DOCUMENTATION.md) | 1,930 |
| **EthernovaClans (Parte 1)** | [DOCUMENTATION_PART1.md](DOCUMENTATION_PART1.md) | 1,412 |
| **EthernovaClans (Parte 2)** | [DOCUMENTATION_PART2.md](DOCUMENTATION_PART2.md) | 1,342 |

**Total documentación**: ~6,500 líneas de documentación técnica detallada.

---

*Documentación unificada del ecosistema Ethernova — 3 plugins, 217+ clases Java, ~36,000 líneas de código.*
