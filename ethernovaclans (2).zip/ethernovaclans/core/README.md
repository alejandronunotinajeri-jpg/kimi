# EthernovaCore

> Núcleo del ecosistema Ethernova — dependencia obligatoria de todos los módulos.

## Características

- **Perfiles de jugador** — Coins, XP, nivel, estadísticas persistentes
- **Economía** — Integración con Vault + sistema propio de monedas
- **Cooldowns** — Sistema thread-safe de cooldowns por jugador/ID
- **Contextos** — Estado de jugador (combate, duelo, FFA) compartido entre plugins
- **Scoreboards** — Scoreboards dinámicos con estados (lobby, combate, duelo, etc.)
- **Boosts** — Multiplicadores globales de XP/monedas
- **Sonidos** — Registro central de sonidos con config override
- **Métricas** — bStats centralizado para todo el ecosistema
- **ServiceRegistry** — Service Locator tipado para APIs inter-plugin
- **EventBus** — Publish/subscribe para eventos entre módulos
- **CrossServerMessenger** — Plugin Messaging Channel para multi-servidor
- **i18n** — Sistema de mensajes con soporte multi-idioma
- **PlaceholderAPI** — Placeholders `%ethernova_*%`

## API

```java
CoreAPI api = ServiceRegistry.get(CoreAPI.class);
api.getProfile(uuid);
api.addCoins(uuid, 100, "reward");
api.addXP(uuid, 500);
api.setCooldown(uuid, "skill", 5000);
api.playSound(uuid, "level-up");
```

## Comandos

| Comando | Permiso | Descripción |
|---------|---------|-------------|
| `/ethernova` | `ethernova.admin` | Panel de administración |
| `/coins` | `ethernova.coins` | Ver/gestionar monedas |
| `/boost` | `ethernova.boost` | Gestionar multiplicadores |

## Configuración

```yaml
storage:
  type: mysql  # mysql, sqlite
  host: localhost
  port: 3306
  database: ethernova

server-mode: pvp_kitpvp  # pvp_kitpvp, pvp_factions, practice, etc.

metrics:
  enabled: true
```
