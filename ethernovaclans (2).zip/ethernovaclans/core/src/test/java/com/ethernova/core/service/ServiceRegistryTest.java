package com.ethernova.core.service;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for ServiceRegistry.
 */
class ServiceRegistryTest {

    @BeforeEach
    @AfterEach
    void cleanup() {
        ServiceRegistry.clearAll();
    }

    @Test
    @DisplayName("Register and retrieve a service")
    void registerAndGet() {
        ServiceRegistry.register(TestService.class, new TestServiceImpl("hello"));
        TestService service = ServiceRegistry.get(TestService.class);
        assertNotNull(service);
        assertEquals("hello", service.getValue());
    }

    @Test
    @DisplayName("Get returns null for unregistered service")
    void getUnregistered() {
        assertNull(ServiceRegistry.get(TestService.class));
    }

    @Test
    @DisplayName("isRegistered returns correct state")
    void isRegistered() {
        assertFalse(ServiceRegistry.isRegistered(TestService.class));
        ServiceRegistry.register(TestService.class, new TestServiceImpl("test"));
        assertTrue(ServiceRegistry.isRegistered(TestService.class));
    }

    @Test
    @DisplayName("Unregister removes the service")
    void unregister() {
        ServiceRegistry.register(TestService.class, new TestServiceImpl("test"));
        assertTrue(ServiceRegistry.isRegistered(TestService.class));

        ServiceRegistry.unregister(TestService.class);
        assertFalse(ServiceRegistry.isRegistered(TestService.class));
        assertNull(ServiceRegistry.get(TestService.class));
    }

    @Test
    @DisplayName("ClearAll removes all services")
    void clearAll() {
        ServiceRegistry.register(TestService.class, new TestServiceImpl("a"));
        ServiceRegistry.register(AnotherService.class, new AnotherServiceImpl());
        assertTrue(ServiceRegistry.isRegistered(TestService.class));
        assertTrue(ServiceRegistry.isRegistered(AnotherService.class));

        ServiceRegistry.clearAll();
        assertFalse(ServiceRegistry.isRegistered(TestService.class));
        assertFalse(ServiceRegistry.isRegistered(AnotherService.class));
    }

    @Test
    @DisplayName("Registration overwrites previous")
    void overwrite() {
        ServiceRegistry.register(TestService.class, new TestServiceImpl("first"));
        ServiceRegistry.register(TestService.class, new TestServiceImpl("second"));
        assertEquals("second", ServiceRegistry.get(TestService.class).getValue());
    }

    @Test
    @DisplayName("Multiple service types coexist")
    void multipleTypes() {
        ServiceRegistry.register(TestService.class, new TestServiceImpl("x"));
        ServiceRegistry.register(AnotherService.class, new AnotherServiceImpl());

        assertNotNull(ServiceRegistry.get(TestService.class));
        assertNotNull(ServiceRegistry.get(AnotherService.class));
    }

    // ─── Test helpers ───

    interface TestService {
        String getValue();
    }

    record TestServiceImpl(String value) implements TestService {
        @Override
        public String getValue() { return value; }
    }

    interface AnotherService {}
    static class AnotherServiceImpl implements AnotherService {}
}
