package com.ethernova.core.cooldown;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for CooldownManager.
 */
class CooldownManagerTest {

    private CooldownManager manager;
    private final UUID player1 = UUID.randomUUID();
    private final UUID player2 = UUID.randomUUID();

    @BeforeEach
    void setUp() {
        manager = new CooldownManager();
    }

    @Test
    @DisplayName("No cooldown initially")
    void noCooldownInitially() {
        assertFalse(manager.hasCooldown(player1, "skill"));
        assertEquals(0, manager.getRemainingMs(player1, "skill"));
    }

    @Test
    @DisplayName("Set and check active cooldown")
    void activeCooldown() {
        manager.setCooldown(player1, "skill", 5000);
        assertTrue(manager.hasCooldown(player1, "skill"));
        assertTrue(manager.getRemainingMs(player1, "skill") > 0);
        assertTrue(manager.getRemainingMs(player1, "skill") <= 5000);
    }

    @Test
    @DisplayName("Different cooldown IDs are independent")
    void independentIds() {
        manager.setCooldown(player1, "skill1", 5000);
        assertTrue(manager.hasCooldown(player1, "skill1"));
        assertFalse(manager.hasCooldown(player1, "skill2"));
    }

    @Test
    @DisplayName("Different players are independent")
    void independentPlayers() {
        manager.setCooldown(player1, "skill", 5000);
        assertTrue(manager.hasCooldown(player1, "skill"));
        assertFalse(manager.hasCooldown(player2, "skill"));
    }

    @Test
    @DisplayName("Expired cooldown returns false")
    void expiredCooldown() {
        manager.setCooldown(player1, "skill", 0); // Expires immediately
        assertFalse(manager.hasCooldown(player1, "skill"));
    }

    @Test
    @DisplayName("Remove cooldown explicitly")
    void removeCooldown() {
        manager.setCooldown(player1, "skill", 10000);
        assertTrue(manager.hasCooldown(player1, "skill"));
        manager.removeCooldown(player1, "skill");
        assertFalse(manager.hasCooldown(player1, "skill"));
    }

    @Test
    @DisplayName("ClearAll removes all cooldowns for a player")
    void clearAll() {
        manager.setCooldown(player1, "skill1", 10000);
        manager.setCooldown(player1, "skill2", 10000);
        manager.setCooldown(player2, "skill1", 10000);

        manager.clearAll(player1);

        assertFalse(manager.hasCooldown(player1, "skill1"));
        assertFalse(manager.hasCooldown(player1, "skill2"));
        assertTrue(manager.hasCooldown(player2, "skill1")); // player2 unaffected
    }

    @Test
    @DisplayName("getRemainingFormatted returns human-readable text")
    void formattedRemaining() {
        // No cooldown → "0s"
        assertEquals("0s", manager.getRemainingFormatted(player1, "x"));

        // Active cooldown → non-zero string
        manager.setCooldown(player1, "long", 7200000); // 2 hours
        String formatted = manager.getRemainingFormatted(player1, "long");
        assertNotNull(formatted);
        assertTrue(formatted.contains("h"), "Should contain hours: " + formatted);
    }

    @Test
    @DisplayName("Overwrite cooldown with new duration")
    void overwriteCooldown() {
        manager.setCooldown(player1, "skill", 1000);
        manager.setCooldown(player1, "skill", 60000);
        long remaining = manager.getRemainingMs(player1, "skill");
        assertTrue(remaining > 1000, "Should have the longer duration");
    }

    @Test
    @DisplayName("Remove from non-existent player is safe")
    void removeNonExistent() {
        assertDoesNotThrow(() -> manager.removeCooldown(player1, "x"));
        assertDoesNotThrow(() -> manager.clearAll(player1));
    }
}
