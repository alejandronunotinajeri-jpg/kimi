package com.ethernova.core.module;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;

/**
 * Detects which EthernovaX modules are installed on this server.
 * Used by Core, Lobby, and other modules to dynamically show/hide
 * features, commands, and GUI options based on what's available.
 * <p>
 * Call {@link #detect()} during onEnable (after all plugins load).
 * Query with {@link #has(String)} using short names like "ffa", "duels", etc.
 */
public class ModuleManager {

    /** Known Ethernova module names (short key → plugin name). */
    private static final Map<String, String> KNOWN_MODULES = new LinkedHashMap<>();
    static {
        KNOWN_MODULES.put("ffa",         "EthernovaFFA");
        KNOWN_MODULES.put("duels",       "EthernovaDuels");
        KNOWN_MODULES.put("ranked",      "EthernovaRanked");
        KNOWN_MODULES.put("party",       "EthernovaParty");
        KNOWN_MODULES.put("cosmetics",   "EthernovaCosmetics");
        KNOWN_MODULES.put("progression", "EthernovaProgression");
        KNOWN_MODULES.put("combat",      "EthernovaCombat");
        KNOWN_MODULES.put("clans",       "EthernovaClans");
        KNOWN_MODULES.put("lobby",       "EthernovaLobby");
        KNOWN_MODULES.put("discord",     "EthernovaDiscord");
    }

    private final JavaPlugin plugin;
    private final Map<String, Boolean> installed = new LinkedHashMap<>();

    public ModuleManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Detect all installed Ethernova modules.
     * Should be called in a delayed task (1 tick) to ensure all plugins have loaded.
     */
    public void detect() {
        Logger log = plugin.getLogger();
        installed.clear();

        for (var entry : KNOWN_MODULES.entrySet()) {
            boolean present = Bukkit.getPluginManager().isPluginEnabled(entry.getValue());
            installed.put(entry.getKey(), present);
        }

        // Log summary
        StringBuilder sb = new StringBuilder();
        sb.append("Módulos detectados: ");
        boolean first = true;
        for (var entry : installed.entrySet()) {
            if (entry.getValue()) {
                if (!first) sb.append(", ");
                sb.append(entry.getKey());
                first = false;
            }
        }
        if (first) sb.append("ninguno");
        log.info(sb.toString());
    }

    /** Check if an Ethernova module is installed by short name (e.g. "ffa", "duels"). */
    public boolean has(String shortName) {
        return installed.getOrDefault(shortName.toLowerCase(), false);
    }

    /** Check if an Ethernova module is installed by full plugin name (e.g. "EthernovaFFA"). */
    public boolean hasPlugin(String pluginName) {
        for (var entry : KNOWN_MODULES.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(pluginName)) {
                return installed.getOrDefault(entry.getKey(), false);
            }
        }
        // Fallback: check Bukkit directly
        return Bukkit.getPluginManager().isPluginEnabled(pluginName);
    }

    // ── Convenience methods ──
    public boolean hasFFA()         { return has("ffa"); }
    public boolean hasDuels()       { return has("duels"); }
    public boolean hasRanked()      { return has("ranked"); }
    public boolean hasParty()       { return has("party"); }
    public boolean hasCosmetics()   { return has("cosmetics"); }
    public boolean hasProgression() { return has("progression"); }
    public boolean hasCombat()      { return has("combat"); }
    public boolean hasClans()       { return has("clans"); }
    public boolean hasLobby()       { return has("lobby"); }
    public boolean hasDiscord()     { return has("discord"); }

    /** Get the full plugin name for a short key. */
    public static String getPluginName(String shortName) {
        return KNOWN_MODULES.getOrDefault(shortName.toLowerCase(), shortName);
    }

    /** Get all known module short names. */
    public static Set<String> getKnownModules() {
        return Collections.unmodifiableSet(KNOWN_MODULES.keySet());
    }

    /** Get all installed module short names. */
    public Set<String> getInstalledModules() {
        Set<String> result = new java.util.LinkedHashSet<>();
        for (var entry : installed.entrySet()) {
            if (entry.getValue()) result.add(entry.getKey());
        }
        return Collections.unmodifiableSet(result);
    }
}
