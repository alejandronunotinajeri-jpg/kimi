package com.ethernova.core.service;

import org.bukkit.inventory.ItemStack;
import java.util.UUID;

/**
 * Cross-module API for applying armor trim cosmetics to equipped armor.
 * Registered by the cosmetics module, consumed by FFA/Duels kit systems.
 * Uses the ServiceRegistry for decoupled cross-plugin communication.
 */
public interface ArmorTrimService {

    /**
     * Apply saved trim cosmetics to an armor array.
     *
     * @param uuid  Player UUID whose trim configuration to apply
     * @param armor Array of armor items in Bukkit order: [boots, leggings, chestplate, helmet]
     * @return Modified armor array with trims applied (same array, modified in-place)
     */
    ItemStack[] applyTrims(UUID uuid, ItemStack[] armor);
}
