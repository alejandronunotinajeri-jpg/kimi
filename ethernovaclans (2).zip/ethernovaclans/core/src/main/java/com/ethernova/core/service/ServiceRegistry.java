package com.ethernova.core.service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Type-safe service locator for cross-plugin API access.
 * Each plugin registers its API implementation here.
 * Other plugins retrieve it without direct dependency coupling.
 *
 * Usage:
 *   // Provider (in onEnable):
 *   ServiceRegistry.register(CombatAPI.class, new CombatAPIImpl());
 *
 *   // Consumer (anywhere):
 *   CombatAPI api = ServiceRegistry.get(CombatAPI.class);
 *   if (api != null) api.isInCombat(player);
 */
public final class ServiceRegistry {

    private static final Map<Class<?>, Object> services = new ConcurrentHashMap<>();
    private static final Logger logger = Logger.getLogger("EthernovaServiceRegistry");

    private ServiceRegistry() {}

    /**
     * Register a service implementation.
     * @param type The API interface class
     * @param impl The implementation instance
     */
    @SuppressWarnings("unchecked")
    public static <T> void register(Class<T> type, T impl) {
        Object previous = services.put(type, impl);
        if (previous != null) {
            logger.log(Level.WARNING, "[ServiceRegistry] Overwriting existing service for {0} (old={1}, new={2})",
                    new Object[]{type.getSimpleName(), previous.getClass().getSimpleName(), impl.getClass().getSimpleName()});
        } else {
            logger.log(Level.INFO, "[ServiceRegistry] Registered {0} -> {1}",
                    new Object[]{type.getSimpleName(), impl.getClass().getSimpleName()});
        }
    }

    /**
     * Unregister a service. Call in onDisable() to prevent classloader leaks.
     */
    public static <T> void unregister(Class<T> type) {
        Object removed = services.remove(type);
        if (removed != null) {
            logger.log(Level.INFO, "[ServiceRegistry] Unregistered {0}", type.getSimpleName());
        } else {
            logger.log(Level.FINE, "[ServiceRegistry] Unregister called for non-existent service: {0}", type.getSimpleName());
        }
    }

    /**
     * Get a registered service, or null if not available.
     */
    @SuppressWarnings("unchecked")
    public static <T> T get(Class<T> type) {
        T service = (T) services.get(type);
        if (service == null) {
            logger.log(Level.FINE, "[ServiceRegistry] Lookup missed for {0}", type.getSimpleName());
        }
        return service;
    }

    /**
     * Check if a service is registered.
     */
    public static boolean isRegistered(Class<?> type) {
        return services.containsKey(type);
    }

    /**
     * Clear all services. Only call from EthernovaCore.onDisable().
     */
    public static void clearAll() {
        int count = services.size();
        services.clear();
        logger.log(Level.INFO, "[ServiceRegistry] Cleared all services ({0} entries)", count);
    }
}
