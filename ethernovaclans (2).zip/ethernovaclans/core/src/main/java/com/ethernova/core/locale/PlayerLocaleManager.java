package com.ethernova.core.locale;

import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks per-player language preference. Uses client locale as default,
 * with optional manual override.
 */
public class PlayerLocaleManager {

    private final String defaultLanguage;
    /** Manual overrides: UUID -> language code */
    private final Map<UUID, String> overrides = new ConcurrentHashMap<>();
    /** Supported languages */
    private static final java.util.Set<String> SUPPORTED = java.util.Set.of("es", "en");

    public PlayerLocaleManager(String defaultLanguage) {
        this.defaultLanguage = defaultLanguage;
    }

    /**
     * Get the language for a player. Priority:
     * 1. Manual override
     * 2. Client locale (if supported)
     * 3. Default server language
     */
    public String getLanguage(Player player) {
        String override = overrides.get(player.getUniqueId());
        if (override != null) return override;

        // Detect from client locale (e.g., "es_mx" -> "es", "en_us" -> "en")
        String clientLocale = player.locale().getLanguage();
        if (SUPPORTED.contains(clientLocale)) return clientLocale;

        return defaultLanguage;
    }

    /** Get language for an offline player by UUID. */
    public String getLanguage(UUID uuid) {
        String override = overrides.get(uuid);
        return override != null ? override : defaultLanguage;
    }

    /** Set manual language override. */
    public void setLanguage(UUID uuid, String language) {
        if (SUPPORTED.contains(language)) {
            overrides.put(uuid, language);
        }
    }

    /** Remove manual override, reverting to auto-detection. */
    public void resetLanguage(UUID uuid) {
        overrides.remove(uuid);
    }

    /** Check if a language code is supported. */
    public boolean isSupported(String language) {
        return SUPPORTED.contains(language);
    }

    /** Get all supported languages. */
    public java.util.Set<String> getSupportedLanguages() {
        return SUPPORTED;
    }

    public void cleanup(UUID uuid) {
        overrides.remove(uuid);
    }
}
