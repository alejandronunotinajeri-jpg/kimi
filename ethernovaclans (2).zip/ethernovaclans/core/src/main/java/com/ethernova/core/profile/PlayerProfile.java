package com.ethernova.core.profile;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

public class PlayerProfile {

    private final UUID uuid;
    private volatile String name;
    private final AtomicInteger kills = new AtomicInteger();
    private final AtomicInteger deaths = new AtomicInteger();
    private volatile long playTime;
    private volatile long firstJoin;
    private volatile long lastJoin;

    // Progression
    private final AtomicInteger level = new AtomicInteger(1);
    private final AtomicInteger prestige = new AtomicInteger(0);
    private final AtomicLong xp = new AtomicLong(0);
    private final AtomicLong coinsCents = new AtomicLong(0); // Store coins as cents (long) for atomicity

    // Custom data map for other plugins to store per-player data
    private final Map<String, String> customData = new ConcurrentHashMap<>();

    public PlayerProfile(UUID uuid, String name) {
        this.uuid = uuid;
        this.name = name;
    }

    // --- Identity ---
    public UUID getUuid() { return uuid; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    // --- Combat Stats ---
    public int getKills() { return kills.get(); }
    public void setKills(int kills) { this.kills.set(kills); }
    public int getDeaths() { return deaths.get(); }
    public void setDeaths(int deaths) { this.deaths.set(deaths); }
    public void addKill() { kills.incrementAndGet(); }
    public void addDeath() { deaths.incrementAndGet(); }
    public double getKDR() { int d = deaths.get(); return d == 0 ? kills.get() : (double) kills.get() / d; }

    // --- Time ---
    public long getPlayTime() { return playTime; }
    public void setPlayTime(long playTime) { this.playTime = playTime; }
    public long getFirstJoin() { return firstJoin; }
    public void setFirstJoin(long firstJoin) { this.firstJoin = firstJoin; }
    public long getLastJoin() { return lastJoin; }
    public void setLastJoin(long lastJoin) { this.lastJoin = lastJoin; }

    // --- Progression ---
    public int getLevel() { return level.get(); }
    public void setLevel(int level) { this.level.set(level); }
    public int getPrestige() { return prestige.get(); }
    public void setPrestige(int prestige) { this.prestige.set(prestige); }
    public long getXP() { return xp.get(); }
    public void setXP(long xp) { this.xp.set(xp); }
    public long addXP(long amount) { return this.xp.addAndGet(amount); }

    // --- Economy ---
    public double getCoins() { return coinsCents.get() / 100.0; }
    public void setCoins(double coins) { this.coinsCents.set(Math.round(coins * 100)); }
    public void addCoins(double amount) { this.coinsCents.addAndGet(Math.round(amount * 100)); }

    // --- Custom Data (thread-safe KV store for other plugins) ---
    public String getCustom(String key) { return customData.get(key); }
    public String getCustom(String key, String defaultValue) { return customData.getOrDefault(key, defaultValue); }
    public void setCustom(String key, String value) { customData.put(key, value); }
    public void removeCustom(String key) { customData.remove(key); }
    public Map<String, String> getAllCustomData() { return java.util.Collections.unmodifiableMap(customData); }
    public void loadCustomData(Map<String, String> data) {
        customData.clear();
        if (data != null) customData.putAll(data);
    }
}
