package com.ethernova.core.server;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.logging.Logger;

/**
 * Detects or reads the server mode from config.
 * mode=auto tries to detect based on installed plugins.
 */
public class ServerModeManager {

    private final JavaPlugin plugin;
    private volatile ServerMode mode;

    public ServerModeManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void detect() {
        FileConfiguration config = plugin.getConfig();
        String configured = config.getString("server.mode", "auto");
        Logger log = plugin.getLogger();

        if (!"auto".equalsIgnoreCase(configured)) {
            mode = ServerMode.fromString(configured);
            log.info("Modo de servidor (manual): " + mode);
            return;
        }

        // Auto-detect based on installed plugins
        if (isPluginPresent("EthernovaFFA")) {
            mode = ServerMode.FFA;
        } else if (isPluginPresent("EthernovaClans") && !isPluginPresent("EthernovaFFA")) {
            mode = ServerMode.SURVIVAL;
        } else if (isPluginPresent("ASkyBlock") || isPluginPresent("BentoBox")
                || isPluginPresent("SuperiorSkyblock2") || isPluginPresent("IridiumSkyblock")) {
            mode = ServerMode.SKYBLOCK;
        } else if (countGamePlugins() == 0) {
            mode = ServerMode.LOBBY;
        } else {
            mode = ServerMode.SURVIVAL;
        }

        log.info("Modo de servidor (auto-detectado): " + mode);
    }

    private boolean isPluginPresent(String name) {
        return Bukkit.getPluginManager().getPlugin(name) != null;
    }

    private int countGamePlugins() {
        int count = 0;
        String[] gamePlugins = {
            "EthernovaClans", "EthernovaFFA", "EthernovaDuels",
            "EthernovaProgression", "EthernovaParty"
        };
        for (String p : gamePlugins) {
            if (isPluginPresent(p)) count++;
        }
        return count;
    }

    public ServerMode getMode() {
        return mode;
    }

    /**
     * Check if a specific feature should be enabled for the current server mode.
     * Checks config override first (features.xyz = true/false),
     * then falls back to auto-detection based on mode.
     */
    public boolean isFeatureEnabled(String featureKey, boolean defaultForMode) {
        String override = plugin.getConfig().getString("features." + featureKey, "auto");
        if ("true".equalsIgnoreCase(override)) return true;
        if ("false".equalsIgnoreCase(override)) return false;
        return defaultForMode;
    }
}
