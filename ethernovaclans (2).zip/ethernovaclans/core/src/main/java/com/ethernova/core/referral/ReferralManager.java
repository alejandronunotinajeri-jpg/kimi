package com.ethernova.core.referral;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.profile.PlayerProfile;
import com.ethernova.core.storage.CoreStorageManager;
import com.ethernova.core.storage.MigrationManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Referral system with unique codes.
 * <p>
 * Each player gets a unique referral code (REF-XXXXXXXX).
 * When a new player uses a code, both get rewards.
 * <p>
 * DB table: ethernova_referrals (referrer_uuid, referred_uuid, code, timestamp)
 */
public class ReferralManager {

    private final EthernovaCore core;
    private final CoreStorageManager storage;
    private final Logger logger;
    private final MiniMessage mini = MiniMessage.miniMessage();

    // Cache: player UUID -> their referral code
    private final Map<UUID, String> codeCache = new ConcurrentHashMap<>();
    // Cache: code -> owner UUID
    private final Map<String, UUID> reverseCodeCache = new ConcurrentHashMap<>();
    // Track who has already used a referral to prevent duplicates
    private final Map<UUID, Boolean> usedReferral = new ConcurrentHashMap<>();

    // Config
    private double referrerReward;
    private double referredReward;
    private int referrerXP;
    private int referredXP;
    private int maxReferrals;

    private static final String CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private static final int CODE_LENGTH = 8;
    private static final SecureRandom RANDOM = new SecureRandom();

    public ReferralManager(EthernovaCore core) {
        this.core = core;
        this.storage = core.getStorageManager();
        this.logger = core.getLogger();
        loadConfig();
        runMigrations();
    }

    private void loadConfig() {
        referrerReward = core.getConfig().getDouble("referral.referrer-coins", 500);
        referredReward = core.getConfig().getDouble("referral.referred-coins", 250);
        referrerXP = core.getConfig().getInt("referral.referrer-xp", 200);
        referredXP = core.getConfig().getInt("referral.referred-xp", 100);
        maxReferrals = core.getConfig().getInt("referral.max-referrals", 50);
    }

    private void runMigrations() {
        String autoInc = storage.isMySQL() ? "AUTO_INCREMENT" : "AUTOINCREMENT";
        new MigrationManager(storage, logger, "ethernova_referral")
                .addMigration(1,
                        """
                        CREATE TABLE IF NOT EXISTS ethernova_referrals (
                            id INTEGER PRIMARY KEY %AUTO%,
                            referrer_uuid VARCHAR(36) NOT NULL,
                            referred_uuid VARCHAR(36) NOT NULL UNIQUE,
                            code VARCHAR(16) NOT NULL,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                        )
                        """.replace("%AUTO%", autoInc))
                .addMigration(2,
                        """
                        CREATE TABLE IF NOT EXISTS ethernova_referral_codes (
                            uuid VARCHAR(36) PRIMARY KEY,
                            code VARCHAR(16) NOT NULL UNIQUE
                        )
                        """)
                .addMigration(3,
                        "CREATE INDEX IF NOT EXISTS idx_referrals_referrer ON ethernova_referrals (referrer_uuid)",
                        "CREATE INDEX IF NOT EXISTS idx_referrals_code ON ethernova_referrals (code)")
                .migrate();
    }

    // ═══════════════════════════════════════
    //  CODE GENERATION
    // ═══════════════════════════════════════

    /**
     * Generate a unique referral code: REF-XXXXXXXX
     */
    private String generateCode() {
        StringBuilder sb = new StringBuilder("REF-");
        for (int i = 0; i < CODE_LENGTH; i++) {
            sb.append(CHARS.charAt(RANDOM.nextInt(CHARS.length())));
        }
        return sb.toString();
    }

    /**
     * Get or create a player's referral code.
     */
    public CompletableFuture<String> getOrCreateCode(UUID uuid) {
        String cached = codeCache.get(uuid);
        if (cached != null) return CompletableFuture.completedFuture(cached);

        return CompletableFuture.supplyAsync(() -> {
            try (Connection conn = storage.getConnection()) {
                // Check if code exists
                try (PreparedStatement ps = conn.prepareStatement(
                        "SELECT code FROM ethernova_referral_codes WHERE uuid = ?")) {
                    ps.setString(1, uuid.toString());
                    ResultSet rs = ps.executeQuery();
                    if (rs.next()) {
                        String code = rs.getString("code");
                        codeCache.put(uuid, code);
                        reverseCodeCache.put(code, uuid);
                        return code;
                    }
                }

                // Generate new code
                String code = generateCode();
                try (PreparedStatement ps = conn.prepareStatement(
                        "INSERT INTO ethernova_referral_codes (uuid, code) VALUES (?, ?)")) {
                    ps.setString(1, uuid.toString());
                    ps.setString(2, code);
                    ps.executeUpdate();
                }
                codeCache.put(uuid, code);
                reverseCodeCache.put(code, uuid);
                return code;
            } catch (Exception e) {
                logger.log(Level.SEVERE, "Error getting/creating referral code", e);
                return null;
            }
        }, core.getDbExecutor());
    }

    // ═══════════════════════════════════════
    //  USE REFERRAL
    // ═══════════════════════════════════════

    /**
     * Use a referral code. Called by the referred (new) player.
     */
    public CompletableFuture<ReferralResult> useCode(Player referred, String code) {
        UUID referredUuid = referred.getUniqueId();

        // Already used a referral?
        if (usedReferral.containsKey(referredUuid)) {
            return CompletableFuture.completedFuture(ReferralResult.ALREADY_USED);
        }

        return CompletableFuture.supplyAsync(() -> {
            try (Connection conn = storage.getConnection()) {
                // Check if player already has a referral entry
                try (PreparedStatement ps = conn.prepareStatement(
                        "SELECT 1 FROM ethernova_referrals WHERE referred_uuid = ?")) {
                    ps.setString(1, referredUuid.toString());
                    if (ps.executeQuery().next()) {
                        usedReferral.put(referredUuid, true);
                        return ReferralResult.ALREADY_USED;
                    }
                }

                // Find code owner
                UUID referrerUuid = reverseCodeCache.get(code);
                if (referrerUuid == null) {
                    try (PreparedStatement ps = conn.prepareStatement(
                            "SELECT uuid FROM ethernova_referral_codes WHERE code = ?")) {
                        ps.setString(1, code);
                        ResultSet rs = ps.executeQuery();
                        if (!rs.next()) return ReferralResult.INVALID_CODE;
                        referrerUuid = UUID.fromString(rs.getString("uuid"));
                    }
                }

                // Can't refer yourself
                if (referrerUuid.equals(referredUuid)) {
                    return ReferralResult.SELF_REFERRAL;
                }

                // Check max referrals
                try (PreparedStatement ps = conn.prepareStatement(
                        "SELECT COUNT(*) FROM ethernova_referrals WHERE referrer_uuid = ?")) {
                    ps.setString(1, referrerUuid.toString());
                    ResultSet rs = ps.executeQuery();
                    if (rs.next() && rs.getInt(1) >= maxReferrals) {
                        return ReferralResult.MAX_REACHED;
                    }
                }

                // Record referral
                try (PreparedStatement ps = conn.prepareStatement(
                        "INSERT INTO ethernova_referrals (referrer_uuid, referred_uuid, code) VALUES (?, ?, ?)")) {
                    ps.setString(1, referrerUuid.toString());
                    ps.setString(2, referredUuid.toString());
                    ps.setString(3, code);
                    ps.executeUpdate();
                }

                usedReferral.put(referredUuid, true);

                // Award rewards on main thread
                final UUID finalReferrerUuid = referrerUuid;
                Bukkit.getScheduler().runTask(core, () -> {
                    // Reward referred player
                    if (core.getEconomyHook().isEnabled()) {
                        core.getEconomyHook().deposit(referred, referredReward);
                    }
                    PlayerProfile referredProfile = core.getProfileManager().getProfile(referredUuid);
                    if (referredProfile != null) {
                        referredProfile.addXP(referredXP);
                    }
                    referred.sendMessage(mini.deserialize(
                            "<green>✔ <yellow>¡Código de referido usado! Recibiste <gold>$" +
                            String.format("%,.0f", referredReward) + "</gold> y <aqua>" + referredXP + " XP</aqua>."));

                    // Reward referrer (if online)
                    Player referrer = Bukkit.getPlayer(finalReferrerUuid);
                    if (referrer != null) {
                        if (core.getEconomyHook().isEnabled()) {
                            core.getEconomyHook().deposit(referrer, referrerReward);
                        }
                        PlayerProfile referrerProfile = core.getProfileManager().getProfile(finalReferrerUuid);
                        if (referrerProfile != null) {
                            referrerProfile.addXP(referrerXP);
                        }
                        referrer.sendMessage(mini.deserialize(
                                "<green>✔ <yellow>" + referred.getName() + " usó tu código de referido! " +
                                "Recibiste <gold>$" + String.format("%,.0f", referrerReward) +
                                "</gold> y <aqua>" + referrerXP + " XP</aqua>."));
                        core.getSoundManager().play(referrer, "level-up");
                    }
                });

                return ReferralResult.SUCCESS;
            } catch (Exception e) {
                logger.log(Level.SEVERE, "Error using referral code", e);
                return ReferralResult.ERROR;
            }
        }, core.getDbExecutor());
    }

    /**
     * Get the number of successful referrals for a player.
     */
    public CompletableFuture<Integer> getReferralCount(UUID uuid) {
        return CompletableFuture.supplyAsync(() -> {
            try (Connection conn = storage.getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "SELECT COUNT(*) FROM ethernova_referrals WHERE referrer_uuid = ?")) {
                ps.setString(1, uuid.toString());
                ResultSet rs = ps.executeQuery();
                return rs.next() ? rs.getInt(1) : 0;
            } catch (Exception e) {
                logger.log(Level.SEVERE, "Error counting referrals", e);
                return 0;
            }
        }, core.getDbExecutor());
    }

    /**
     * Preload a player's data into cache.
     */
    public void loadPlayer(UUID uuid) {
        getOrCreateCode(uuid).exceptionally(ex -> {
            logger.log(java.util.logging.Level.SEVERE, "[Referral] Error pre-loading code for " + uuid, ex);
            return null;
        });
        // Check if they've used a referral
        CompletableFuture.runAsync(() -> {
            try (Connection conn = storage.getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "SELECT 1 FROM ethernova_referrals WHERE referred_uuid = ?")) {
                ps.setString(1, uuid.toString());
                if (ps.executeQuery().next()) {
                    usedReferral.put(uuid, true);
                }
            } catch (Exception e) {
                logger.warning("[Referral] Error loading referral status for " + uuid + ": " + e.getMessage());
            }
        }, core.getDbExecutor()).exceptionally(ex -> {
            logger.log(java.util.logging.Level.SEVERE, "[Referral] Unhandled error loading player " + uuid, ex);
            return null;
        });
    }

    /**
     * Cleanup player cache.
     */
    public void unloadPlayer(UUID uuid) {
        String code = codeCache.remove(uuid);
        if (code != null) reverseCodeCache.remove(code);
        usedReferral.remove(uuid);
    }

    public enum ReferralResult {
        SUCCESS, ALREADY_USED, INVALID_CODE, SELF_REFERRAL, MAX_REACHED, ERROR
    }
}
