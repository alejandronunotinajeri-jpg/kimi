package com.ethernova.core.cooldown;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class CooldownManager {

    /** UUID -> (cooldownId -> expiryTimestamp) */
    private final Map<UUID, Map<String, Long>> cooldowns = new ConcurrentHashMap<>();

    public void setCooldown(UUID uuid, String id, long durationMs) {
        cooldowns.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>())
                .put(id, System.currentTimeMillis() + durationMs);
    }

    public boolean hasCooldown(UUID uuid, String id) {
        Map<String, Long> playerCooldowns = cooldowns.get(uuid);
        if (playerCooldowns == null) return false;
        Long expiry = playerCooldowns.get(id);
        if (expiry == null) return false;
        if (System.currentTimeMillis() >= expiry) { playerCooldowns.remove(id); return false; }
        return true;
    }

    public long getRemainingMs(UUID uuid, String id) {
        Map<String, Long> playerCooldowns = cooldowns.get(uuid);
        if (playerCooldowns == null) return 0;
        Long expiry = playerCooldowns.get(id);
        if (expiry == null) return 0;
        return Math.max(0, expiry - System.currentTimeMillis());
    }

    public String getRemainingFormatted(UUID uuid, String id) {
        long ms = getRemainingMs(uuid, id);
        if (ms <= 0) return "0s";
        long s = ms / 1000;
        if (s < 60) return s + "s";
        if (s < 3600) return (s / 60) + "m " + (s % 60) + "s";
        return (s / 3600) + "h " + ((s % 3600) / 60) + "m";
    }

    public void removeCooldown(UUID uuid, String id) {
        Map<String, Long> playerCooldowns = cooldowns.get(uuid);
        if (playerCooldowns != null) playerCooldowns.remove(id);
    }

    /** O(1) per-player cleanup instead of O(n) full-map scan. */
    public void clearAll(UUID uuid) {
        cooldowns.remove(uuid);
    }
}
