package com.ethernova.core.command;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.boost.BoostManager;
import com.ethernova.core.gui.AdminGui;
import com.ethernova.core.leaderboard.LeaderboardManager;
import com.ethernova.core.profile.PlayerProfile;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.stream.Collectors;

public class CoreCommand implements CommandExecutor, TabCompleter {

    private final EthernovaCore core;
    private final MiniMessage mini = MiniMessage.miniMessage();

    private static final List<String> SUBCOMMANDS = List.of(
            "reload", "status", "debug", "boost", "profile", "lang",
            "coins", "xp", "top", "maintenance", "save", "gui", "setlobby", "backup", "help");

    public CoreCommand(EthernovaCore core) { this.core = core; }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("ethernova.admin")) {
            core.getMessageManager().send(sender, "general.no-permission");
            return true;
        }
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload" -> {
                core.getConfigManager().loadAll();
                core.getMessageManager().load();
                core.getSoundManager().loadFromConfig(core.getConfig().getConfigurationSection("sounds"));
                core.getMessageManager().send(sender, "general.reloaded");
            }
            case "status" -> sendStatus(sender);
            case "debug" -> {
                boolean current = core.getConfig().getBoolean("general.debug", false);
                core.getConfig().set("general.debug", !current);
                core.saveConfig();
                core.getMessageManager().send(sender, !current ? "admin.debug-on" : "admin.debug-off");
            }
            case "boost" -> handleBoost(sender, args);
            case "profile" -> handleProfile(sender, args);
            case "lang" -> handleLang(sender, args);
            case "coins" -> handleCoins(sender, args);
            case "xp" -> handleXP(sender, args);
            case "top" -> handleTop(sender, args);
            case "maintenance", "maint" -> handleMaintenance(sender, args);
            case "save" -> handleSave(sender);
            case "gui", "panel" -> handleGui(sender);
            case "setlobby" -> handleSetLobby(sender);
            case "backup" -> handleBackup(sender, args);
            case "help", "?" -> sendHelp(sender);
            default -> sendHelp(sender);
        }
        return true;
    }

    // ─── Help ───

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(mini.deserialize(core.getMessageManager().get("admin.help-header")));
        sender.sendMessage(mini.deserialize(core.getMessageManager().get("admin.help-reload")));
        sender.sendMessage(mini.deserialize(core.getMessageManager().get("admin.help-status")));
        sender.sendMessage(mini.deserialize(core.getMessageManager().get("admin.help-debug")));
        sender.sendMessage(mini.deserialize(core.getMessageManager().get("admin.help-boost")));
        sender.sendMessage(mini.deserialize(core.getMessageManager().get("admin.help-profile")));
        sender.sendMessage(mini.deserialize(core.getMessageManager().get("admin.help-coins")));
        sender.sendMessage(mini.deserialize(core.getMessageManager().get("admin.help-xp")));
        sender.sendMessage(mini.deserialize(core.getMessageManager().get("admin.help-top")));
        sender.sendMessage(mini.deserialize(core.getMessageManager().get("admin.help-lang")));
        sender.sendMessage(mini.deserialize(core.getMessageManager().get("admin.help-maintenance")));
        sender.sendMessage(mini.deserialize(core.getMessageManager().get("admin.help-save")));
        sender.sendMessage(mini.deserialize(core.getMessageManager().get("admin.help-gui")));
        sender.sendMessage(mini.deserialize("<gray>/ethernova backup <create|restore|list|delete> <dark_gray>- <white>Gestión de backups"));
    }

    // ─── Status ───

    private void sendStatus(CommandSender sender) {
        sender.sendMessage(mini.deserialize("<gradient:#A855F7:#6366F1><bold>EthernovaCore</bold></gradient> <gray>v" + core.getDescription().getVersion()));
        sender.sendMessage(mini.deserialize("<gray>Modo del servidor: <yellow>" + core.getServerModeManager().getMode()));

        var plugins = core.getRegisteredPlugins();
        sender.sendMessage(mini.deserialize("<gray>Plugins registrados <dark_gray>(" + plugins.size() + ")<gray>: <yellow>" +
                (plugins.isEmpty() ? "Ninguno" : String.join(", ", plugins))));

        sender.sendMessage(mini.deserialize("<gray>Jugadores online: <yellow>" + Bukkit.getOnlinePlayers().size() +
                "/" + Bukkit.getMaxPlayers()));
        sender.sendMessage(mini.deserialize("<gray>Perfiles en memoria: <yellow>" + core.getProfileManager().getAllProfiles().size()));
        sender.sendMessage(mini.deserialize("<gray>DB: <yellow>" + (core.getStorageManager().isMySQL() ? "MySQL" : "SQLite")));
        sender.sendMessage(mini.deserialize("<gray>Proxy: " + (core.getCrossServerMessenger().isProxyDetected() ? "<green>Detectado" : "<red>No")));
        sender.sendMessage(mini.deserialize("<gray>Vault: " + (core.getEconomyHook().isEnabled() ? "<green>Conectado" : "<red>No disponible")));

        var punishHook = core.getPunishmentHook();
        sender.sendMessage(mini.deserialize("<gray>Moderación: " +
                (punishHook != null && punishHook.isAvailable()
                        ? "<green>" + punishHook.getProviderName()
                        : "<dark_gray>No detectado")));

        boolean maint = core.getMaintenanceManager() != null && core.getMaintenanceManager().isEnabled();
        sender.sendMessage(mini.deserialize("<gray>Mantenimiento: " + (maint ? "<red>ACTIVO" : "<green>Inactivo")));

        var boosts = core.getBoostManager().getActiveBoosts();
        if (!boosts.isEmpty()) {
            sender.sendMessage(mini.deserialize("<gray>Boosts activos:"));
            for (var b : boosts) {
                sender.sendMessage(mini.deserialize("  <yellow>" + b.type + " <gray>x" + b.multiplier + " <dark_gray>(" +
                        core.getConfigManager().formatTime(b.getRemainingMs()) + " restante)"));
            }
        }
    }

    // ─── Boost ───

    private void handleBoost(CommandSender sender, String[] args) {
        if (args.length < 4) {
            core.getMessageManager().send(sender, "boost.usage");
            return;
        }
        String type = args[1].toLowerCase();
        double multi;
        try { multi = Double.parseDouble(args[2]); } catch (NumberFormatException e) {
            core.getMessageManager().send(sender, "boost.invalid-multiplier");
            return;
        }
        long durationMs = core.getConfigManager().parseTimeToMillis(args[3]);
        if (durationMs <= 0) {
            core.getMessageManager().send(sender, "boost.invalid-duration");
            return;
        }
        core.getBoostManager().activate(type, multi, durationMs, sender.getName());

        // Send confirmation and broadcast
        core.getMessageManager().send(sender, "boost.activated",
                "{type}", type, "{multiplier}", String.valueOf(multi),
                "{duration}", core.getConfigManager().formatTime(durationMs));

        String broadcast = core.getMessageManager().get("boost.broadcast",
                "{type}", type, "{multiplier}", String.valueOf(multi),
                "{duration}", core.getConfigManager().formatTime(durationMs));
        Bukkit.broadcast(mini.deserialize(broadcast));
    }

    // ─── Profile ───

    private void handleProfile(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(mini.deserialize("<gray>Uso: /ethernova profile <jugador>"));
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            core.getMessageManager().send(sender, "general.player-not-found");
            return;
        }
        PlayerProfile p = core.getProfileManager().getProfile(target.getUniqueId());
        if (p == null) {
            core.getMessageManager().send(sender, "general.player-not-found");
            return;
        }
        sender.sendMessage(mini.deserialize("<dark_gray><strikethrough>         </strikethrough></dark_gray> <gradient:#A855F7:#6366F1>" + p.getName() + "</gradient> <dark_gray><strikethrough>         </strikethrough></dark_gray>"));
        sender.sendMessage(mini.deserialize("<gray>Nivel: <yellow>" + p.getLevel() + " <dark_gray>| <gray>Prestigio: <yellow>" + p.getPrestige()));
        sender.sendMessage(mini.deserialize("<gray>XP: <yellow>" + p.getXP() + " <dark_gray>| <gray>Monedas: <gold>" + String.format("%.2f", p.getCoins())));
        sender.sendMessage(mini.deserialize("<gray>Kills: <yellow>" + p.getKills() + " <dark_gray>| <gray>Deaths: <yellow>" + p.getDeaths() + " <dark_gray>| <gray>KDR: <yellow>" + String.format("%.2f", p.getKDR())));
        sender.sendMessage(mini.deserialize("<gray>Tiempo jugado: <yellow>" + core.getConfigManager().formatTime(p.getPlayTime())));
        sender.sendMessage(mini.deserialize("<gray>Primera conexión: <yellow>" + formatTimestamp(p.getFirstJoin())));
        sender.sendMessage(mini.deserialize("<gray>Última conexión: <yellow>" + formatTimestamp(p.getLastJoin())));

        // Show leaderboard positions
        if (core.getLeaderboardManager() != null) {
            int killRank = core.getLeaderboardManager().getRank("kills", target.getUniqueId());
            int coinsRank = core.getLeaderboardManager().getRank("coins", target.getUniqueId());
            int levelRank = core.getLeaderboardManager().getRank("level", target.getUniqueId());
            StringBuilder ranks = new StringBuilder("<gray>Rankings: ");
            if (killRank > 0) ranks.append("<yellow>#").append(killRank).append(" kills <dark_gray>| ");
            if (coinsRank > 0) ranks.append("<gold>#").append(coinsRank).append(" coins <dark_gray>| ");
            if (levelRank > 0) ranks.append("<aqua>#").append(levelRank).append(" level");
            sender.sendMessage(mini.deserialize(ranks.toString()));
        }
    }

    // ─── Coins ───

    private void handleCoins(CommandSender sender, String[] args) {
        if (args.length < 3) {
            core.getMessageManager().send(sender, "coins.usage");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            core.getMessageManager().send(sender, "general.player-not-found");
            return;
        }
        PlayerProfile profile = core.getProfileManager().getProfile(target.getUniqueId());
        if (profile == null) {
            core.getMessageManager().send(sender, "general.player-not-found");
            return;
        }

        String action = args[2].toLowerCase();

        if ("check".equals(action)) {
            core.getMessageManager().send(sender, "coins.balance",
                    "{player}", target.getName(), "{amount}", String.format("%.2f", profile.getCoins()));
            return;
        }

        if (args.length < 4) {
            core.getMessageManager().send(sender, "coins.usage");
            return;
        }

        double amount;
        try { amount = Double.parseDouble(args[3]); } catch (NumberFormatException e) {
            core.getMessageManager().send(sender, "general.invalid-amount");
            return;
        }

        switch (action) {
            case "add" -> {
                profile.addCoins(amount);
                core.getMessageManager().send(sender, "coins.added",
                        "{player}", target.getName(), "{amount}", String.format("%.2f", amount));
            }
            case "remove" -> {
                if (profile.getCoins() < amount) {
                    core.getMessageManager().send(sender, "coins.insufficient");
                    return;
                }
                profile.addCoins(-amount);
                core.getMessageManager().send(sender, "coins.removed",
                        "{player}", target.getName(), "{amount}", String.format("%.2f", amount));
            }
            case "set" -> {
                profile.setCoins(amount);
                core.getMessageManager().send(sender, "coins.set",
                        "{player}", target.getName(), "{amount}", String.format("%.2f", amount));
            }
            default -> core.getMessageManager().send(sender, "coins.usage");
        }
    }

    // ─── XP ───

    private void handleXP(CommandSender sender, String[] args) {
        if (args.length < 4) {
            core.getMessageManager().send(sender, "xp.usage");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            core.getMessageManager().send(sender, "general.player-not-found");
            return;
        }
        PlayerProfile profile = core.getProfileManager().getProfile(target.getUniqueId());
        if (profile == null) {
            core.getMessageManager().send(sender, "general.player-not-found");
            return;
        }

        long amount;
        try { amount = Long.parseLong(args[3]); } catch (NumberFormatException e) {
            core.getMessageManager().send(sender, "general.invalid-amount");
            return;
        }

        switch (args[2].toLowerCase()) {
            case "add" -> {
                core.getCoreAPI().addXP(target.getUniqueId(), amount);
                core.getMessageManager().send(sender, "xp.added",
                        "{player}", target.getName(), "{amount}", String.valueOf(amount));
            }
            case "set" -> {
                profile.setXP(amount);
                core.getMessageManager().send(sender, "xp.set",
                        "{player}", target.getName(), "{amount}", String.valueOf(amount));
            }
            default -> core.getMessageManager().send(sender, "xp.usage");
        }
    }

    // ─── Top / Leaderboard ───

    private void handleTop(CommandSender sender, String[] args) {
        if (core.getLeaderboardManager() == null) {
            sender.sendMessage(mini.deserialize("<red>Leaderboard no disponible."));
            return;
        }
        if (args.length < 2) {
            core.getMessageManager().send(sender, "leaderboard.types");
            return;
        }
        String type = args[1].toLowerCase();
        if (!LeaderboardManager.VALID_TYPES.contains(type)) {
            core.getMessageManager().send(sender, "leaderboard.types");
            return;
        }

        var entries = core.getLeaderboardManager().getTop(type);
        if (entries.isEmpty()) {
            core.getMessageManager().send(sender, "leaderboard.no-data");
            return;
        }

        sender.sendMessage(mini.deserialize(core.getMessageManager().get("leaderboard.header",
                "{type}", type.toUpperCase())));
        for (int i = 0; i < entries.size(); i++) {
            var entry = entries.get(i);
            String medal = switch (i) {
                case 0 -> "<gold>⭐ ";
                case 1 -> "<gray>⭐ ";
                case 2 -> "<#CD7F32>⭐ ";
                default -> "";
            };
            sender.sendMessage(mini.deserialize(medal + core.getMessageManager().get("leaderboard.entry",
                    "{position}", String.valueOf(i + 1),
                    "{player}", entry.name(),
                    "{value}", entry.displayValue())));
        }
        sender.sendMessage(mini.deserialize(core.getMessageManager().get("leaderboard.footer")));
    }

    // ─── Maintenance ───

    private void handleMaintenance(CommandSender sender, String[] args) {
        if (core.getMaintenanceManager() == null) return;

        if (args.length >= 2) {
            String sub = args[1].toLowerCase();
            switch (sub) {
                case "on" -> core.getMaintenanceManager().enable(0);
                case "off" -> core.getMaintenanceManager().disable();
                case "countdown" -> {
                    int seconds = 30;
                    if (args.length >= 3) {
                        try { seconds = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
                    }
                    core.getMaintenanceManager().enable(seconds);
                    sender.sendMessage(mini.deserialize("<yellow>Mantenimiento en " + seconds + "s..."));
                }
                default -> core.getMaintenanceManager().toggle();
            }
        } else {
            core.getMaintenanceManager().toggle();
        }
    }

    // ─── Save ───

    private void handleSave(CommandSender sender) {
        Bukkit.getScheduler().runTaskAsynchronously(core, () -> {
            core.getProfileManager().saveAll();
            int count = core.getProfileManager().getAllProfiles().size();
            Bukkit.getScheduler().runTask(core, () ->
                    core.getMessageManager().send(sender, "admin.save-complete",
                            "{count}", String.valueOf(count)));
        });
    }

    // ─── GUI ───

    private void handleGui(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            core.getMessageManager().send(sender, "general.players-only");
            return;
        }
        new AdminGui(core, player).open();
    }

    // ─── Set Lobby ───

    private void handleSetLobby(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            core.getMessageManager().send(sender, "general.players-only");
            return;
        }
        if (!core.getLobbyManager().isEnabled()) {
            sender.sendMessage(mini.deserialize("<red>EthernovaLobby no está instalado o el lobby no está habilitado."));
            sender.sendMessage(mini.deserialize("<gray>Instala el plugin EthernovaLobby y habilita el lobby en su config.yml."));
            return;
        }

        core.getLobbyManager().setLobbySpawn(player.getLocation());
        core.getLobbyManager().loadConfig(); // Reload to pick up new spawn
        sender.sendMessage(mini.deserialize("<green>Spawn del lobby establecido en tu ubicación actual."));

        // Send player to lobby to verify items
        core.getLobbyManager().sendToLobby(player);
        sender.sendMessage(mini.deserialize("<gray>Lobby activado. Items del lobby aplicados."));
    }

    // ─── Lang ───

    private void handleLang(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            core.getMessageManager().send(sender, "general.players-only");
            return;
        }
        if (args.length < 2) {
            sender.sendMessage(mini.deserialize("<gray>Idioma actual: <yellow>" + core.getLocaleManager().getLanguage(player)));
            sender.sendMessage(mini.deserialize("<gray>Uso: /ethernova lang <es|en|auto>"));
            return;
        }
        String lang = args[1].toLowerCase();
        if ("auto".equals(lang)) {
            core.getLocaleManager().resetLanguage(player.getUniqueId());
            sender.sendMessage(mini.deserialize("<green>Idioma restablecido a auto-detección."));
        } else if (core.getLocaleManager().isSupported(lang)) {
            core.getLocaleManager().setLanguage(player.getUniqueId(), lang);
            sender.sendMessage(mini.deserialize("<green>Idioma cambiado a: <yellow>" + lang));
        } else {
            sender.sendMessage(mini.deserialize("<red>Idioma no soportado. Disponibles: " +
                    String.join(", ", core.getLocaleManager().getSupportedLanguages())));
        }
    }

    // ─── Backup ───

    private void handleBackup(CommandSender sender, String[] args) {
        var bm = core.getBackupManager();
        if (bm == null) {
            sender.sendMessage(mini.deserialize("<red>Backup manager no disponible."));
            return;
        }

        if (args.length < 2) {
            sender.sendMessage(mini.deserialize("<gray>Uso:"));
            sender.sendMessage(mini.deserialize("  <yellow>/ethernova backup create [nombre] <dark_gray>- Crear backup"));
            sender.sendMessage(mini.deserialize("  <yellow>/ethernova backup restore <nombre> <dark_gray>- Restaurar backup"));
            sender.sendMessage(mini.deserialize("  <yellow>/ethernova backup list <dark_gray>- Listar backups"));
            sender.sendMessage(mini.deserialize("  <yellow>/ethernova backup delete <nombre> <dark_gray>- Eliminar backup"));
            return;
        }

        switch (args[1].toLowerCase()) {
            case "create" -> bm.createBackup(sender, args.length >= 3 ? args[2] : null);
            case "restore" -> {
                if (args.length < 3) {
                    sender.sendMessage(mini.deserialize("<red>Uso: /ethernova backup restore <nombre>"));
                    return;
                }
                bm.restoreBackup(sender, args[2]);
            }
            case "list" -> bm.listBackups(sender);
            case "delete" -> {
                if (args.length < 3) {
                    sender.sendMessage(mini.deserialize("<red>Uso: /ethernova backup delete <nombre>"));
                    return;
                }
                bm.deleteBackup(sender, args[2]);
            }
            default -> sender.sendMessage(mini.deserialize("<red>Sub-comando inválido. Usa: create, restore, list, delete"));
        }
    }

    // ─── Utilities ───

    private String formatTimestamp(long millis) {
        if (millis <= 0) return "N/A";
        java.time.Instant instant = java.time.Instant.ofEpochMilli(millis);
        java.time.LocalDateTime dt = java.time.LocalDateTime.ofInstant(instant, java.time.ZoneId.systemDefault());
        return dt.format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
    }

    // ─── Tab Completion ───

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String alias, @NotNull String[] args) {
        if (!sender.hasPermission("ethernova.admin")) return List.of();

        if (args.length == 1) {
            return filterStartsWith(SUBCOMMANDS, args[0]);
        }

        if (args.length == 2) {
            return switch (args[0].toLowerCase()) {
                case "boost" -> filterStartsWith(List.of("xp", "money", "drops", "kills"), args[1]);
                case "profile", "coins", "xp" -> null; // Show online player names
                case "lang" -> filterStartsWith(List.of("es", "en", "auto"), args[1]);
                case "top" -> filterStartsWith(List.of("kills", "deaths", "kdr", "coins", "level", "playtime", "xp"), args[1]);
                case "maintenance", "maint" -> filterStartsWith(List.of("on", "off", "countdown"), args[1]);
                case "backup" -> filterStartsWith(List.of("create", "restore", "list", "delete"), args[1]);
                default -> List.of();
            };
        }

        if (args.length == 3) {
            return switch (args[0].toLowerCase()) {
                case "boost" -> List.of("1.5", "2.0", "3.0");
                case "coins" -> filterStartsWith(List.of("add", "remove", "set", "check"), args[2]);
                case "xp" -> filterStartsWith(List.of("add", "set"), args[2]);
                case "maintenance", "maint" -> {
                    if ("countdown".equalsIgnoreCase(args[1])) yield List.of("10", "30", "60");
                    yield List.of();
                }
                case "backup" -> {
                    if ("restore".equalsIgnoreCase(args[1]) || "delete".equalsIgnoreCase(args[1])) {
                        yield filterStartsWith(core.getBackupManager() != null
                                ? core.getBackupManager().getBackupNames() : List.of(), args[2]);
                    }
                    yield List.of();
                }
                default -> List.of();
            };
        }

        if (args.length == 4) {
            return switch (args[0].toLowerCase()) {
                case "boost" -> List.of("5m", "15m", "30m", "1h", "2h");
                case "coins" -> List.of("100", "500", "1000");
                case "xp" -> List.of("100", "500", "1000", "5000");
                default -> List.of();
            };
        }

        return List.of();
    }

    private List<String> filterStartsWith(List<String> options, String input) {
        String lower = input.toLowerCase();
        return options.stream().filter(s -> s.toLowerCase().startsWith(lower)).collect(Collectors.toList());
    }
}
