package com.ethernova.core.storage;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;

public class CoreStorageManager {

    private final JavaPlugin plugin;
    private HikariDataSource dataSource;

    public CoreStorageManager(JavaPlugin plugin) { this.plugin = plugin; }

    public void initialize() {
        var config = plugin.getConfig();
        String type = config.getString("database.type", "SQLITE").toUpperCase();
        HikariConfig hc = new HikariConfig();
        hc.setPoolName("EthernovaCore-Pool");

        if ("MYSQL".equals(type)) {
            String host = config.getString("database.mysql.host", "localhost");
            int port = config.getInt("database.mysql.port", 3306);
            String db = config.getString("database.mysql.database", "ethernova");
            hc.setJdbcUrl("jdbc:mysql://" + host + ":" + port + "/" + db + "?useSSL=false&autoReconnect=true");
            hc.setUsername(config.getString("database.mysql.username", "root"));
            hc.setPassword(config.getString("database.mysql.password", ""));
            hc.setMaximumPoolSize(config.getInt("database.mysql.pool-size", 10));
        } else {
            File dbFile = new File(plugin.getDataFolder(), "ethernova.db");
            dbFile.getParentFile().mkdirs();
            hc.setJdbcUrl("jdbc:sqlite:" + dbFile.getAbsolutePath());
            hc.setMaximumPoolSize(1);
            hc.setConnectionTimeout(60000);
            hc.addDataSourceProperty("journal_mode", "WAL");
            hc.addDataSourceProperty("synchronous", "NORMAL");
            hc.addDataSourceProperty("busy_timeout", "30000");
        }

        dataSource = new HikariDataSource(hc);

        // Enable WAL mode for SQLite for better concurrency
        if (!isMySQL()) {
            try (Connection conn = dataSource.getConnection();
                 java.sql.Statement stmt = conn.createStatement()) {
                stmt.execute("PRAGMA journal_mode=WAL");
                stmt.execute("PRAGMA synchronous=NORMAL");
                stmt.execute("PRAGMA busy_timeout=30000");
            } catch (SQLException e) {
                plugin.getLogger().warning("Could not set SQLite PRAGMA: " + e.getMessage());
            }
        }
        createTables();
    }

    private void createTables() {
        try (Connection conn = dataSource.getConnection();
             java.sql.Statement stmt = conn.createStatement()) {
            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS ethernova_profiles (
                    uuid VARCHAR(36) PRIMARY KEY,
                    name VARCHAR(16),
                    kills INT DEFAULT 0,
                    deaths INT DEFAULT 0,
                    play_time BIGINT DEFAULT 0,
                    first_join BIGINT DEFAULT 0,
                    last_join BIGINT DEFAULT 0,
                    level INT DEFAULT 1,
                    prestige INT DEFAULT 0,
                    xp BIGINT DEFAULT 0,
                    coins DOUBLE DEFAULT 0
                )
            """);
            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS ethernova_profile_data (
                    uuid VARCHAR(36) NOT NULL,
                    data_key VARCHAR(128) NOT NULL,
                    data_value TEXT,
                    PRIMARY KEY (uuid, data_key)
                )
            """);
            // Performance indexes
            stmt.executeUpdate("CREATE INDEX IF NOT EXISTS idx_profiles_name ON ethernova_profiles (name)");
        } catch (SQLException e) {
            plugin.getLogger().log(java.util.logging.Level.SEVERE, "Failed to create tables", e);
        }
    }

    public Connection getConnection() throws SQLException {
        if (dataSource == null || dataSource.isClosed()) {
            throw new SQLException("DataSource is not available. Was initialize() called successfully?");
        }
        return dataSource.getConnection();
    }
    public boolean isMySQL() { return dataSource != null && dataSource.getJdbcUrl().startsWith("jdbc:mysql"); }
    public void close() { if (dataSource != null && !dataSource.isClosed()) dataSource.close(); }
}
