package com.ethernova.core.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.profile.PlayerProfile;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Rich player profile GUI — shows identity, combat stats, economy, progression,
 * rankings, and time stats in a polished 54-slot layout.
 * Opened by clicking the player head in the Main Menu.
 */
public class ProfileGui extends CoreGui {

    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");

    public ProfileGui(EthernovaCore core, Player player) {
        super(core, player);
    }

    public void open() {
        openInventory("<gradient:#FF6B6B:#4ECDC4>♦ Perfil de " + player.getName() + "</gradient>", 54);
    }

    @Override
    protected void populateItems() {
        PlayerProfile p = core.getProfileManager().getProfile(player.getUniqueId());
        if (p == null) return;

        // ═══ Fill with glass ═══
        ItemStack fill = createItem(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 54; i++) setItem(i, fill);

        // Accent rows
        ItemStack darkFill = createItem(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 9; i++) setItem(i, darkFill);      // top row
        for (int i = 45; i < 54; i++) setItem(i, darkFill);     // bottom row

        // ═══════════════════════════════════════════════════════
        // Row 0: Player Head (center) + Name Banner
        // ═══════════════════════════════════════════════════════
        ItemStack yellowGlass = createItem(Material.YELLOW_STAINED_GLASS_PANE, "<yellow>━━━");
        setItem(2, yellowGlass);
        setItem(3, yellowGlass);
        setItem(5, yellowGlass);
        setItem(6, yellowGlass);

        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta skullMeta = (SkullMeta) head.getItemMeta();
        if (skullMeta != null) {
            skullMeta.setOwningPlayer(player);
            skullMeta.displayName(mini.deserialize("<gradient:gold:yellow><bold>★ " + player.getName() + " ★</bold></gradient>"));

            // Time info
            String firstJoinStr = p.getFirstJoin() > 0 ? DATE_FORMAT.format(new Date(p.getFirstJoin())) : "Desconocido";
            String playTimeStr = core.getConfigManager().formatTime(p.getPlayTime());

            skullMeta.lore(List.of(
                    mini.deserialize(""),
                    mini.deserialize("<dark_gray>▎ <gray>Nivel: <yellow>" + p.getLevel() + " <dark_gray>│ <gray>Prestigio: <light_purple>" + p.getPrestige()),
                    mini.deserialize("<dark_gray>▎ <gray>Monedas: <gold>$" + String.format("%,.0f", p.getCoins())),
                    mini.deserialize(""),
                    mini.deserialize("<dark_gray>▎ <gray>Primera conexión: <yellow>" + firstJoinStr),
                    mini.deserialize("<dark_gray>▎ <gray>Tiempo jugado: <aqua>" + playTimeStr),
                    mini.deserialize("")
            ));
            head.setItemMeta(skullMeta);
        }
        setItem(4, head);

        // ═══════════════════════════════════════════════════════
        // Row 1: Combat Stats
        // ═══════════════════════════════════════════════════════
        double kdr = p.getKDR();
        int bestStreak = 0;
        try { bestStreak = Integer.parseInt(p.getCustom("best_killstreak", "0")); } catch (Exception ignored) {}
        int wins = 0;
        try { wins = Integer.parseInt(p.getCustom("duel_wins", "0")); } catch (Exception ignored) {}
        int losses = 0;
        try { losses = Integer.parseInt(p.getCustom("duel_losses", "0")); } catch (Exception ignored) {}

        setItem(10, createItem(Material.DIAMOND_SWORD, "<red><bold>⚔ Combate",
                List.of("",
                        "<dark_gray>▎ <gray>Kills: <green>" + String.format("%,d", p.getKills()),
                        "<dark_gray>▎ <gray>Muertes: <red>" + String.format("%,d", p.getDeaths()),
                        "<dark_gray>▎ <gray>KDR: <yellow>" + String.format("%.2f", kdr),
                        "",
                        "<dark_gray>▎ <gray>Mejor racha: <gold>" + bestStreak,
                        "")));

        setItem(12, createItem(Material.IRON_SWORD, "<gold><bold>⚔ Duelos",
                List.of("",
                        "<dark_gray>▎ <gray>Victorias: <green>" + wins,
                        "<dark_gray>▎ <gray>Derrotas: <red>" + losses,
                        "<dark_gray>▎ <gray>Winrate: <yellow>" + (wins + losses > 0 ? String.format("%.1f%%", wins * 100.0 / (wins + losses)) : "N/A"),
                        "")));

        // ═══════════════════════════════════════════════════════
        // Row 1: Progression
        // ═══════════════════════════════════════════════════════
        setItem(14, createItem(Material.EXPERIENCE_BOTTLE, "<green><bold>✦ Progresión",
                List.of("",
                        "<dark_gray>▎ <gray>Nivel: <yellow>" + p.getLevel(),
                        "<dark_gray>▎ <gray>XP: <aqua>" + String.format("%,d", p.getXP()),
                        "<dark_gray>▎ <gray>Prestigio: <light_purple>" + p.getPrestige(),
                        "")));

        setItem(16, createItem(Material.GOLD_INGOT, "<gold><bold>$ Economía",
                List.of("",
                        "<dark_gray>▎ <gray>Monedas: <gold>$" + String.format("%,.0f", p.getCoins()),
                        "")));

        // ═══════════════════════════════════════════════════════
        // Row 2: Separator
        // ═══════════════════════════════════════════════════════
        ItemStack separator = createItem(Material.ORANGE_STAINED_GLASS_PANE, "<gold>━━━");
        for (int i = 18; i <= 26; i++) setItem(i, separator);

        // ═══════════════════════════════════════════════════════
        // Row 3: Rankings
        // ═══════════════════════════════════════════════════════
        if (core.getLeaderboardManager() != null) {
            int killRank = core.getLeaderboardManager().getRank("kills", player.getUniqueId());
            int coinsRank = core.getLeaderboardManager().getRank("coins", player.getUniqueId());
            int levelRank = core.getLeaderboardManager().getRank("level", player.getUniqueId());

            setItem(29, createItem(Material.GOLD_BLOCK, "<gold><bold>♛ Rankings",
                    List.of("",
                            "<dark_gray>▎ <gray>Kills: " + formatRank(killRank),
                            "<dark_gray>▎ <gray>Monedas: " + formatRank(coinsRank),
                            "<dark_gray>▎ <gray>Nivel: " + formatRank(levelRank),
                            "")));
        } else {
            setItem(29, createItem(Material.GOLD_BLOCK, "<gold><bold>♛ Rankings",
                    List.of("", "<dark_gray>▎ <dark_gray>No disponible", "")));
        }

        // ═══════════════════════════════════════════════════════
        // Row 3: Quick actions
        // ═══════════════════════════════════════════════════════
        setItem(31, createItem(Material.COMPASS, "<yellow><bold>★ Misiones",
                List.of("", "<dark_gray>▎ <yellow>Click para ver misiones", "")));
        slotActions.put(31, "MISSIONS");

        setItem(33, createItem(Material.DIAMOND, "<aqua><bold>✦ Logros",
                List.of("", "<dark_gray>▎ <yellow>Click para ver logros", "")));
        slotActions.put(33, "ACHIEVEMENTS");

        // ═══════════════════════════════════════════════════════
        // Row 4: Extra info
        // ═══════════════════════════════════════════════════════
        setItem(37, createItem(Material.REDSTONE, "<red><bold>⚙ Configuración",
                List.of("", "<dark_gray>▎ <yellow>Click para ajustar", "")));
        slotActions.put(37, "SETTINGS");

        setItem(39, createItem(Material.PAPER, "<white><bold>✎ Estadísticas",
                List.of("", "<dark_gray>▎ <yellow>Click para ver detalle", "")));
        slotActions.put(39, "STATS");

        setItem(41, createItem(Material.ENDER_CHEST, "<light_purple><bold>✦ Cosméticos",
                List.of("", "<dark_gray>▎ <yellow>Click para abrir", "")));
        slotActions.put(41, "COSMETICS");

        // ═══════════════════════════════════════════════════════
        // Row 5: Back
        // ═══════════════════════════════════════════════════════
        setItem(49, createItem(Material.ARROW, "<red>← Volver al Menú"));
        slotActions.put(49, "BACK");
    }

    private String formatRank(int rank) {
        if (rank <= 0) return "<dark_gray>Sin ranking";
        if (rank == 1) return "<gold><bold>#1";
        if (rank == 2) return "<white>#2";
        if (rank == 3) return "<#CD7F32>#3";
        return "<yellow>#" + rank;
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        playSound("click");
        switch (action) {
            case "MISSIONS" -> {
                player.closeInventory();
                player.performCommand("missions");
            }
            case "ACHIEVEMENTS" -> {
                player.closeInventory();
                player.performCommand("achievements");
            }
            case "SETTINGS" -> {
                player.closeInventory();
                new PlayerSettingsGui(core, player).open();
            }
            case "STATS" -> {
                player.closeInventory();
                new PlayerStatsGui(core, player).open();
            }
            case "COSMETICS" -> {
                player.closeInventory();
                player.performCommand("cosmetics");
            }
            case "BACK" -> {
                player.closeInventory();
            }
        }
        return true;
    }
}
