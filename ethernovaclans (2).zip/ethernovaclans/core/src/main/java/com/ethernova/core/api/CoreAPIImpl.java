package com.ethernova.core.api;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.event.CoinsChangeEvent;
import com.ethernova.core.event.LevelUpEvent;
import com.ethernova.core.profile.PlayerProfile;
import com.ethernova.core.server.ServerMode;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.UUID;

/**
 * Implementation of CoreAPI. Registered with ServiceRegistry on enable.
 */
public class CoreAPIImpl implements CoreAPI {

    private final EthernovaCore core;

    public CoreAPIImpl(EthernovaCore core) {
        this.core = core;
    }

    @Override
    public ServerMode getServerMode() {
        return core.getServerModeManager().getMode();
    }

    @Override
    public boolean isFeatureEnabled(String feature, boolean defaultForMode) {
        return core.getServerModeManager().isFeatureEnabled(feature, defaultForMode);
    }

    @Override
    public PlayerProfile getProfile(UUID uuid) {
        return core.getProfileManager().getProfile(uuid);
    }

    @Override
    public double getBoostMultiplier(String boostType) {
        return core.getBoostManager().getMultiplier(boostType);
    }

    @Override
    public void addCoins(UUID uuid, double amount, String reason) {
        PlayerProfile profile = core.getProfileManager().getProfile(uuid);
        if (profile == null) return;
        double old = profile.getCoins();
        double boosted = amount * core.getBoostManager().getMultiplier("money");
        profile.addCoins(boosted);
        core.getEventBus().publish(new CoinsChangeEvent(uuid, old, profile.getCoins(), reason));
    }

    @Override
    public synchronized boolean removeCoins(UUID uuid, double amount, String reason) {
        PlayerProfile profile = core.getProfileManager().getProfile(uuid);
        if (profile == null) return false;
        double old = profile.getCoins();
        if (old < amount) return false;
        profile.addCoins(-amount);
        core.getEventBus().publish(new CoinsChangeEvent(uuid, old, profile.getCoins(), reason));
        return true;
    }

    @Override
    public double getCoins(UUID uuid) {
        PlayerProfile profile = core.getProfileManager().getProfile(uuid);
        return profile != null ? profile.getCoins() : 0;
    }

    @Override
    public void addXP(UUID uuid, long xp) {
        PlayerProfile profile = core.getProfileManager().getProfile(uuid);
        if (profile == null) return;
        long boostedXP = (long) (xp * core.getBoostManager().getMultiplier("xp"));
        int oldLevel = profile.getLevel();
        profile.addXP(boostedXP);

        // Check level-ups using formula: XP for level n = 100 * n * (1 + n/10)
        int maxLevel = 100; // Sensible hard cap
        int newLevel = oldLevel;
        while (newLevel < maxLevel && profile.getXP() >= getTotalXPForLevel(newLevel + 1)) {
            newLevel++;
        }
        if (newLevel > oldLevel) {
            profile.setLevel(newLevel);
            Player player = Bukkit.getPlayer(uuid);
            String name = player != null ? player.getName() : profile.getName();
            core.getEventBus().publish(new LevelUpEvent(uuid, name, oldLevel, newLevel));
        }
    }

    /** Total XP accumulated from level 1 to the given level. Same formula as LevelManager. */
    private long getTotalXPForLevel(int level) {
        long total = 0;
        for (int i = 1; i < level; i++) {
            total += (long) (100.0 * i * (1.0 + i / 10.0));
        }
        return total;
    }

    @Override
    public String getMessage(String path, String... replacements) {
        return core.getMessageManager().get(path, replacements);
    }

    @Override
    public void playSound(UUID uuid, String soundKey) {
        Player player = Bukkit.getPlayer(uuid);
        if (player != null) core.getSoundManager().play(player, soundKey);
    }

    @Override
    public void setCooldown(UUID uuid, String id, long durationMs) {
        core.getCooldownManager().setCooldown(uuid, id, durationMs);
    }

    @Override
    public boolean hasCooldown(UUID uuid, String id) {
        return core.getCooldownManager().hasCooldown(uuid, id);
    }

    @Override
    public void addContext(UUID uuid, String context) {
        core.getContextManager().addContext(uuid, context);
    }

    @Override
    public void removeContext(UUID uuid, String context) {
        core.getContextManager().removeContext(uuid, context);
    }

    @Override
    public boolean hasContext(UUID uuid, String context) {
        return core.getContextManager().hasContext(uuid, context);
    }
}
