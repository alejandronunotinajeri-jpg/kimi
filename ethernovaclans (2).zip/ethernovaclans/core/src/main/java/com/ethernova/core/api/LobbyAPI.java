package com.ethernova.core.api;

import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

/**
 * Public API interface for the lobby system.
 * Lives in core so all modules can reference it without depending on the lobby module.
 * The lobby module registers the implementation via ServiceRegistry on enable.
 * <p>
 * When the lobby module is NOT installed, ServiceRegistry.get(LobbyAPI.class) returns null
 * and core's proxy LobbyManager handles graceful no-ops.
 */
public interface LobbyAPI {

    /** Whether the lobby system is active and configured. */
    boolean isEnabled();

    /** Send a player to the lobby: teleport, clear state, give items. */
    void sendToLobby(Player player);

    /** Give lobby hotbar items to a player. */
    void giveLobbyItems(Player player);

    /** Whether a player is currently in lobby state. */
    boolean isInLobbyState(Player player);

    /** Clean up tracking data for a player (call on quit). */
    void cleanupPlayer(UUID uuid);

    /** Get remaining double-jump cooldown seconds, or 0. */
    long getDoubleJumpCooldown(UUID uuid);

    /** Set the double-jump cooldown for a player. */
    void setDoubleJumpCooldown(UUID uuid);

    /** Deactivate PvP lobby mode for a player. */
    void deactivatePvpMode(Player player);

    /** Create a queue cancel item. */
    ItemStack createQueueCancelItem();

    /** Check if an item is the queue cancel item. */
    boolean isQueueCancelItem(ItemStack item);

    /** Get the action string from a lobby item, or null. */
    String getLobbyItemAction(ItemStack item);

    /** Get the lobby spawn location. */
    Location getLobbySpawn();

    /** Set the lobby spawn and save to config. */
    void setLobbySpawn(Location location);

    /** Reload lobby config. */
    void loadConfig();

    /** Stop tasks, clean up (call on disable). */
    void shutdown();

    /** Get the PersistentData key for lobby item actions. */
    NamespacedKey getLobbyItemKey();

    /** Get the PersistentData key for queue cancel items. */
    NamespacedKey getQueueCancelKey();
}
