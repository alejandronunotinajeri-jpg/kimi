package com.ethernova.core.event;

import java.util.UUID;

/**
 * Published on the EthernovaEventBus when a clan war begins.
 */
public record ClanWarStartEvent(
        UUID attackerClanId,
        String attackerClanName,
        UUID defenderClanId,
        String defenderClanName
) {}
