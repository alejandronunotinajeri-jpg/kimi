package com.ethernova.core.state;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks the current "state" and "map/arena" of each player.
 * <p>
 * States: lobby, ffa, duel, ranked, spectating — or any custom string.
 * Map: arena / territory / world name (or empty).
 * <p>
 * Used by:
 * <ul>
 *   <li>PlaceholderAPI: {@code %ethernova_state%}, {@code %ethernova_map%}</li>
 *   <li>EthernovaScoreboardManager: selects which board to show per player</li>
 *   <li>External scoreboard plugins (FeatherBoard, TAB, etc.) via PAPI conditions</li>
 * </ul>
 */
public class PlayerStateManager {

    private final Map<UUID, String> states = new ConcurrentHashMap<>();
    private final Map<UUID, String> maps = new ConcurrentHashMap<>();

    /**
     * Set the player's state and map.
     *
     * @param uuid  Player UUID
     * @param state State identifier (e.g. "ffa", "duel", "ranked", "lobby")
     * @param map   Map/arena name, or null/empty for none
     */
    public void setState(UUID uuid, String state, String map) {
        if (state == null || state.isEmpty()) {
            states.remove(uuid);
            maps.remove(uuid);
        } else {
            states.put(uuid, state.toLowerCase());
            if (map != null && !map.isEmpty()) {
                maps.put(uuid, map);
            } else {
                maps.remove(uuid);
            }
        }
    }

    /**
     * Set the player's state without a map.
     */
    public void setState(UUID uuid, String state) {
        setState(uuid, state, null);
    }

    /**
     * Clear the player's state (reverts to "lobby").
     */
    public void clearState(UUID uuid) {
        states.remove(uuid);
        maps.remove(uuid);
    }

    /**
     * Get the current state. Returns "lobby" if not explicitly set.
     */
    public String getState(UUID uuid) {
        return states.getOrDefault(uuid, "lobby");
    }

    /**
     * Get the current map/arena. Returns empty string if none.
     */
    public String getMap(UUID uuid) {
        return maps.getOrDefault(uuid, "");
    }

    /**
     * Cleanup on player quit.
     */
    public void cleanup(UUID uuid) {
        states.remove(uuid);
        maps.remove(uuid);
    }
}
