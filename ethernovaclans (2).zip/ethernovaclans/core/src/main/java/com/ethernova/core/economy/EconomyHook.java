package com.ethernova.core.economy;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.UUID;

public class EconomyHook {

    private volatile Economy economy;
    private volatile boolean enabled;
    private volatile boolean initialized;

    public EconomyHook() {
        tryInit();
    }

    private void tryInit() {
        if (initialized) return;
        if (Bukkit.getPluginManager().getPlugin("Vault") != null) {
            RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
            if (rsp != null) { economy = rsp.getProvider(); enabled = true; initialized = true; }
        }
    }

    private void ensureInit() { if (!initialized) tryInit(); }

    public boolean isEnabled() { ensureInit(); return enabled; }
    public double getBalance(Player p) { ensureInit(); return enabled ? economy.getBalance(p) : 0; }
    public double getBalance(OfflinePlayer p) { ensureInit(); return enabled ? economy.getBalance(p) : 0; }
    public boolean has(Player p, double amount) { ensureInit(); return enabled && economy.has(p, amount); }
    public boolean has(OfflinePlayer p, double amount) { ensureInit(); return enabled && economy.has(p, amount); }
    public boolean withdraw(Player p, double amount) { ensureInit(); return enabled && economy.withdrawPlayer(p, amount).transactionSuccess(); }
    public boolean withdraw(OfflinePlayer p, double amount) { ensureInit(); return enabled && economy.withdrawPlayer(p, amount).transactionSuccess(); }
    public boolean deposit(Player p, double amount) { ensureInit(); return enabled && economy.depositPlayer(p, amount).transactionSuccess(); }
    public boolean deposit(OfflinePlayer p, double amount) { ensureInit(); return enabled && economy.depositPlayer(p, amount).transactionSuccess(); }

    public boolean withdrawOffline(UUID uuid, double amount) {
        ensureInit();
        if (!enabled) return false;
        OfflinePlayer op = Bukkit.getOfflinePlayer(uuid);
        return economy.withdrawPlayer(op, amount).transactionSuccess();
    }

    public String format(double amount) { ensureInit(); return enabled ? economy.format(amount) : "$" + String.format("%.2f", amount); }
}
