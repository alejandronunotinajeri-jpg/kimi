package com.ethernova.core.messaging;

import com.ethernova.core.EthernovaCore;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.messaging.PluginMessageListener;
import org.jetbrains.annotations.NotNull;

import java.io.*;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.BiConsumer;
import java.util.logging.Level;

/**
 * Cross-server messaging using BungeeCord/Velocity plugin messaging channel.
 * Falls back to no-op when not on a proxy network.
 *
 * Usage:
 *   // Send to all servers:
 *   messenger.broadcast("ethernova:combat", "player_tagged", data);
 *
 *   // Listen:
 *   messenger.subscribe("ethernova:combat", (subchannel, payload) -> { ... });
 */
public class CrossServerMessenger implements PluginMessageListener {

    private static final String BUNGEE_CHANNEL = "BungeeCord";
    private static final String ETHERNOVA_CHANNEL = "ethernova:main";

    private final EthernovaCore core;
    private final Map<String, List<BiConsumer<String, byte[]>>> handlers = new ConcurrentHashMap<>();
    private final Queue<PendingMessage> pendingMessages = new ConcurrentLinkedQueue<>();
    private volatile boolean proxyDetected = false;

    /** Max queued messages when no player is online. Prevents unbounded memory use. */
    private static final int MAX_PENDING = 100;

    private record PendingMessage(String channel, byte[] data) {}

    public CrossServerMessenger(EthernovaCore core) {
        this.core = core;
    }

    public void enable() {
        // Register BungeeCord channel for proxy detection
        core.getServer().getMessenger().registerOutgoingPluginChannel(core, BUNGEE_CHANNEL);
        core.getServer().getMessenger().registerIncomingPluginChannel(core, BUNGEE_CHANNEL, this);

        // Register our custom channel
        core.getServer().getMessenger().registerOutgoingPluginChannel(core, ETHERNOVA_CHANNEL);
        core.getServer().getMessenger().registerIncomingPluginChannel(core, ETHERNOVA_CHANNEL, this);

        // Try to detect proxy by sending a GetServer request
        Bukkit.getScheduler().runTaskLater(core, () -> {
            Player p = getAnyPlayer();
            if (p != null) {
                try {
                    ByteArrayOutputStream buf = new ByteArrayOutputStream();
                    DataOutputStream out = new DataOutputStream(buf);
                    out.writeUTF("GetServer");
                    p.sendPluginMessage(core, BUNGEE_CHANNEL, buf.toByteArray());
                } catch (IOException ignored) {}
            }
        }, 40L);

        core.getLogger().info("Sistema de mensajería cross-server iniciado");
    }

    public void disable() {
        core.getServer().getMessenger().unregisterOutgoingPluginChannel(core, BUNGEE_CHANNEL);
        core.getServer().getMessenger().unregisterIncomingPluginChannel(core, BUNGEE_CHANNEL, this);
        core.getServer().getMessenger().unregisterOutgoingPluginChannel(core, ETHERNOVA_CHANNEL);
        core.getServer().getMessenger().unregisterIncomingPluginChannel(core, ETHERNOVA_CHANNEL, this);
        handlers.clear();
    }

    /**
     * Subscribe to messages on a specific subchannel.
     */
    public void subscribe(String subchannel, BiConsumer<String, byte[]> handler) {
        handlers.computeIfAbsent(subchannel, k -> new CopyOnWriteArrayList<>()).add(handler);
    }

    /**
     * Broadcast a message to ALL servers through BungeeCord Forward.
     * If no player is online, the message is queued and sent when a player joins.
     */
    public void broadcast(String subchannel, byte[] payload) {
        try {
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            DataOutputStream out = new DataOutputStream(buf);
            out.writeUTF("Forward");
            out.writeUTF("ALL");
            out.writeUTF(subchannel);
            out.writeShort(payload.length);
            out.write(payload);
            sendOrQueue(BUNGEE_CHANNEL, buf.toByteArray());
        } catch (IOException e) {
            core.getLogger().log(Level.WARNING, "Error broadcasting message on " + subchannel, e);
        }
    }

    /**
     * Send a message to a specific server.
     * If no player is online, the message is queued and sent when a player joins.
     */
    public void sendToServer(String serverName, String subchannel, byte[] payload) {
        try {
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            DataOutputStream out = new DataOutputStream(buf);
            out.writeUTF("Forward");
            out.writeUTF(serverName);
            out.writeUTF(subchannel);
            out.writeShort(payload.length);
            out.write(payload);
            sendOrQueue(BUNGEE_CHANNEL, buf.toByteArray());
        } catch (IOException e) {
            core.getLogger().log(Level.WARNING, "Error sending message to " + serverName, e);
        }
    }

    /**
     * Send raw data on the ethernova channel.
     * If no player is online, the message is queued and sent when a player joins.
     */
    public void sendDirect(String subchannel, byte[] payload) {
        try {
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            DataOutputStream out = new DataOutputStream(buf);
            out.writeUTF(subchannel);
            out.writeInt(payload.length);
            out.write(payload);
            sendOrQueue(ETHERNOVA_CHANNEL, buf.toByteArray());
        } catch (IOException e) {
            core.getLogger().log(Level.WARNING, "Error sending direct message on " + subchannel, e);
        }
    }

    @Override
    public void onPluginMessageReceived(@NotNull String channel, @NotNull Player player, byte @NotNull [] message) {
        try {
            DataInputStream in = new DataInputStream(new ByteArrayInputStream(message));

            if (BUNGEE_CHANNEL.equals(channel)) {
                String subchannel = in.readUTF();
                if ("GetServer".equals(subchannel)) {
                    String serverName = in.readUTF();
                    proxyDetected = true;
                    core.getLogger().info("Proxy detectado. Servidor: " + serverName);
                    return;
                }
                // BungeeCord Forward responses arrive with format:
                // subchannel(UTF) [already read above] | short(dataLength) | byte[data]
                // Parse the length-prefixed payload properly
                if (in.available() >= 2) {
                    short len = in.readShort();
                    byte[] payload = new byte[len];
                    in.readFully(payload);
                    dispatchHandlers(subchannel, payload);
                } else {
                    dispatchHandlers(subchannel, readRemaining(in));
                }
            } else if (ETHERNOVA_CHANNEL.equals(channel)) {
                String subchannel = in.readUTF();
                int len = in.readInt();
                byte[] payload = new byte[len];
                in.readFully(payload);
                dispatchHandlers(subchannel, payload);
            }
        } catch (IOException e) {
            core.getLogger().log(Level.FINE, "Error parsing plugin message on " + channel, e);
        }
    }

    private void dispatchHandlers(String subchannel, byte[] data) {
        List<BiConsumer<String, byte[]>> list = handlers.get(subchannel);
        if (list != null) {
            for (BiConsumer<String, byte[]> handler : list) {
                try {
                    handler.accept(subchannel, data);
                } catch (Exception e) {
                    core.getLogger().log(Level.WARNING, "Error in message handler for " + subchannel, e);
                }
            }
        }
    }

    private byte[] readRemaining(DataInputStream in) throws IOException {
        byte[] remaining = new byte[in.available()];
        in.readFully(remaining);
        return remaining;
    }

    private Player getAnyPlayer() {
        var online = Bukkit.getOnlinePlayers();
        return online.isEmpty() ? null : online.iterator().next();
    }

    /**
     * Send a plugin message immediately if a player is online, otherwise queue it.
     */
    private void sendOrQueue(String channel, byte[] data) {
        Player p = getAnyPlayer();
        if (p != null) {
            p.sendPluginMessage(core, channel, data);
        } else {
            if (pendingMessages.size() < MAX_PENDING) {
                pendingMessages.add(new PendingMessage(channel, data));
            } else {
                core.getLogger().fine("Message queue full, dropping cross-server message");
            }
        }
    }

    /**
     * Drain all pending messages. Call from a PlayerJoinEvent listener
     * so that messages queued while the server was empty get sent.
     */
    public void drainPending(Player player) {
        PendingMessage msg;
        while ((msg = pendingMessages.poll()) != null) {
            try {
                player.sendPluginMessage(core, msg.channel(), msg.data());
            } catch (Exception e) {
                core.getLogger().log(Level.FINE, "Error draining pending message", e);
            }
        }
    }

    public boolean isProxyDetected() { return proxyDetected; }
}
