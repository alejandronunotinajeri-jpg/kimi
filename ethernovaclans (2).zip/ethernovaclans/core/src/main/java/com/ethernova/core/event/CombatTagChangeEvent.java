package com.ethernova.core.event;

import java.util.UUID;

/**
 * Published on the EthernovaEventBus when a player's combat tag state changes.
 * Allows cross-module reactions (e.g., cosmetics removing pets on combat entry).
 *
 * @param playerUuid the tagged/untagged player
 * @param tagged     true if entering combat, false if leaving combat
 * @param profile    the combat profile context (e.g., "ffa", "duel")
 */
public record CombatTagChangeEvent(UUID playerUuid, boolean tagged, String profile) {}
