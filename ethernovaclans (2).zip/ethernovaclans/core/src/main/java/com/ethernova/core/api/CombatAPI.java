package com.ethernova.core.api;

import org.bukkit.entity.Player;

import java.util.UUID;

/**
 * Public API interface for combat tag queries.
 * Lives in core so all modules can reference it without depending on combat module.
 *
 * <p>Obtain an instance via {@code ServiceRegistry.get(CombatAPI.class)}.</p>
 * The combat module registers the implementation on enable.
 */
public interface CombatAPI {

    boolean isInCombat(Player player);

    boolean isInCombat(UUID uuid);

    void tag(Player p1, Player p2, String profile);

    void untag(Player player);

    int getRemainingSeconds(UUID uuid);

    int getKillStreak(UUID uuid);

    boolean isNewbieProtected(UUID uuid);
}
