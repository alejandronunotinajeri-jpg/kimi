package com.ethernova.core.gui.animation;

import com.ethernova.core.EthernovaCore;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages premium GUI animations beyond the rainbow border.
 * <p>
 * <b>Item Reveal:</b> When a GUI opens, content items appear one by one in a cascading
 * pattern (glass pane → actual item) with subtle click sounds.
 * <p>
 * <b>Page Transition:</b> When navigating pages in paginated GUIs, content area gets
 * a brief glass-pane wipe before new items appear.
 * <p>
 * All effects are configurable and respect player settings.
 * <pre>
 * gui:
 *   animations:
 *     item-reveal: true
 *     item-reveal-speed: 1     # ticks between each item reveal
 *     page-transition: true
 *     page-transition-duration: 3  # ticks for transition glass display
 * </pre>
 */
public class GuiAnimationManager {

    private final EthernovaCore core;
    private final boolean itemRevealEnabled;
    private final int itemRevealSpeed;
    private final boolean pageTransitionEnabled;
    private final int pageTransitionDuration;

    /** Active reveal animations — prevents double-triggering. */
    private final Set<UUID> activeReveals = ConcurrentHashMap.newKeySet();

    /** Active transition animations. */
    private final Map<UUID, BukkitTask> activeTransitions = new ConcurrentHashMap<>();

    public GuiAnimationManager(EthernovaCore core) {
        this.core = core;
        this.itemRevealEnabled = core.getConfig().getBoolean("gui.animations.item-reveal", true);
        this.itemRevealSpeed = core.getConfig().getInt("gui.animations.item-reveal-speed", 1);
        this.pageTransitionEnabled = core.getConfig().getBoolean("gui.animations.page-transition", true);
        this.pageTransitionDuration = core.getConfig().getInt("gui.animations.page-transition-duration", 3);
    }

    // ══════════════════════════════════════════════════════════
    //  ITEM REVEAL ANIMATION
    // ══════════════════════════════════════════════════════════

    /**
     * Animate items appearing in the inventory one by one.
     * Call this after populateItems() has placed all items.
     *
     * @param player     the viewer
     * @param inventory  the inventory to animate
     * @param contentSlots slots that contain content items (non-border)
     * @param borderSlots  slots that are part of the border
     */
    public void playItemReveal(Player player, Inventory inventory, Set<Integer> contentSlots,
                                List<Integer> borderSlots) {
        if (!itemRevealEnabled) return;
        if (!isAnimationsEnabled(player)) return;
        if (activeReveals.contains(player.getUniqueId())) return;

        activeReveals.add(player.getUniqueId());

        // Snapshot content items and replace with glass panes
        Map<Integer, ItemStack> originalItems = new LinkedHashMap<>();
        Set<Integer> borderSet = new HashSet<>(borderSlots);

        for (int slot = 0; slot < inventory.getSize(); slot++) {
            if (borderSet.contains(slot)) continue;
            ItemStack item = inventory.getItem(slot);
            if (item != null && item.getType() != Material.AIR) {
                originalItems.put(slot, item.clone());
                inventory.setItem(slot, createRevealPane());
            }
        }

        if (originalItems.isEmpty()) {
            activeReveals.remove(player.getUniqueId());
            return;
        }

        // Sort slots for a nice cascade pattern (top-left to bottom-right)
        List<Integer> sortedSlots = new ArrayList<>(originalItems.keySet());
        sortedSlots.sort(Comparator.comparingInt(s -> (s / 9) * 100 + (s % 9)));

        // Reveal items in fast cascade (2 items per tick for premium feel)
        int speed = Math.max(1, itemRevealSpeed);
        for (int i = 0; i < sortedSlots.size(); i++) {
            final int slot = sortedSlots.get(i);
            final ItemStack original = originalItems.get(slot);
            final boolean isLast = (i == sortedSlots.size() - 1);
            final int index = i;

            Bukkit.getScheduler().runTaskLater(core, () -> {
                if (!player.isOnline() || inventory.getViewers().isEmpty()) {
                    activeReveals.remove(player.getUniqueId());
                    return;
                }
                inventory.setItem(slot, original);
                // Subtle sound every 4th item to avoid spam
                if (index % 4 == 0) {
                    player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.1f, 1.9f);
                }

                if (isLast) {
                    activeReveals.remove(player.getUniqueId());
                }
            }, (long) (i / 2 + 1) * speed);
        }
    }

    // ══════════════════════════════════════════════════════════
    //  PAGE TRANSITION ANIMATION
    // ══════════════════════════════════════════════════════════

    /**
     * Play a brief wipe transition before new page content appears.
     * Call this BEFORE placing new page items.
     *
     * @param player    the viewer
     * @param inventory the inventory
     * @param contentSlots slots in the content area
     * @param onComplete callback to run after transition finishes (populate new page)
     */
    public void playPageTransition(Player player, Inventory inventory,
                                    int[] contentSlots, Runnable onComplete) {
        if (!pageTransitionEnabled || !isAnimationsEnabled(player)) {
            onComplete.run();
            return;
        }

        // Cancel any existing transition
        BukkitTask existing = activeTransitions.remove(player.getUniqueId());
        if (existing != null) existing.cancel();

        // Fill content area with transition panes
        Material transitionMat = Material.BLACK_STAINED_GLASS_PANE;
        ItemStack pane = createTransitionPane(transitionMat);
        for (int slot : contentSlots) {
            if (slot >= 0 && slot < inventory.getSize()) {
                inventory.setItem(slot, pane);
            }
        }

        player.playSound(player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.4f, 1.2f);

        // After brief delay, run the completion callback to populate new content
        BukkitTask task = Bukkit.getScheduler().runTaskLater(core, () -> {
            activeTransitions.remove(player.getUniqueId());
            if (player.isOnline()) {
                onComplete.run();
            }
        }, Math.max(1, pageTransitionDuration));

        activeTransitions.put(player.getUniqueId(), task);
    }

    // ══════════════════════════════════════════════════════════
    //  PLAYER CHECK
    // ══════════════════════════════════════════════════════════

    /**
     * Check if player has GUI animations enabled in their settings.
     */
    private boolean isAnimationsEnabled(Player player) {
        return core.getProfileManager().getDataBoolean(
                player.getUniqueId(), "setting.guiAnimations", true);
    }

    // ══════════════════════════════════════════════════════════
    //  ITEM BUILDERS
    // ══════════════════════════════════════════════════════════

    private ItemStack createRevealPane() {
        ItemStack item = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(net.kyori.adventure.text.Component.empty());
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack createTransitionPane(Material material) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(net.kyori.adventure.text.Component.empty());
            item.setItemMeta(meta);
        }
        return item;
    }

    // ══════════════════════════════════════════════════════════
    //  CLEANUP
    // ══════════════════════════════════════════════════════════

    /**
     * Cancel all ongoing animations for a player. Call on GUI close.
     */
    public void cancelAnimations(UUID playerId) {
        activeReveals.remove(playerId);
        BukkitTask task = activeTransitions.remove(playerId);
        if (task != null) task.cancel();
    }

    /**
     * Shutdown all animations. Call on plugin disable.
     */
    public void shutdown() {
        activeReveals.clear();
        for (BukkitTask task : activeTransitions.values()) {
            task.cancel();
        }
        activeTransitions.clear();
    }

    // ══════════════════════════════════════════════════════════
    //  GETTERS
    // ══════════════════════════════════════════════════════════

    public boolean isItemRevealEnabled() { return itemRevealEnabled; }
    public boolean isPageTransitionEnabled() { return pageTransitionEnabled; }
}
