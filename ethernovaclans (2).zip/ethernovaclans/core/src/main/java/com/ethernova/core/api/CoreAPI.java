package com.ethernova.core.api;

import com.ethernova.core.profile.PlayerProfile;
import com.ethernova.core.server.ServerMode;

import java.util.UUID;

/**
 * Public API interface for EthernovaCore.
 *
 * <p>Provides access to core features such as player profiles, economy (coins),
 * XP, messaging, sounds, cooldowns, and player context management.</p>
 *
 * <p>Obtain an instance via {@code ServiceRegistry.get(CoreAPI.class)}
 * without directly depending on EthernovaCore internals.</p>
 *
 * <p>All methods are thread-safe and may be called from any thread.</p>
 */
public interface CoreAPI {

    /**
     * Get the current server mode.
     *
     * @return the active {@link ServerMode}
     */
    ServerMode getServerMode();

    /**
     * Check if a feature is enabled for the current server mode.
     *
     * @param feature        the feature identifier to check
     * @param defaultForMode the default value if the feature is not explicitly configured
     * @return {@code true} if the feature is enabled
     */
    boolean isFeatureEnabled(String feature, boolean defaultForMode);

    /**
     * Get a player profile.
     *
     * @param uuid the UUID of the player
     * @return the player's {@link PlayerProfile}, or {@code null} if not loaded
     */
    PlayerProfile getProfile(UUID uuid);

    /**
     * Get the active multiplier for a boost type.
     *
     * @param boostType the boost type identifier (e.g., "xp", "coins")
     * @return the active multiplier, or {@code 1.0} when no boost is active
     */
    double getBoostMultiplier(String boostType);

    /**
     * Add coins to a player's balance.
     *
     * @param uuid   the UUID of the player
     * @param amount the amount of coins to add (must be positive)
     * @param reason a description for audit/logging purposes
     */
    void addCoins(UUID uuid, double amount, String reason);

    /**
     * Remove coins from a player's balance.
     *
     * @param uuid   the UUID of the player
     * @param amount the amount of coins to remove (must be positive)
     * @param reason a description for audit/logging purposes
     * @return {@code true} if the transaction succeeded, {@code false} if insufficient balance
     */
    boolean removeCoins(UUID uuid, double amount, String reason);

    /**
     * Get a player's coin balance.
     *
     * @param uuid the UUID of the player
     * @return the player's current coin balance
     */
    double getCoins(UUID uuid);

    /**
     * Add XP to a player, possibly triggering a level-up.
     *
     * @param uuid the UUID of the player
     * @param xp   the amount of XP to add (must be positive)
     */
    void addXP(UUID uuid, long xp);

    /**
     * Get a configured message string with placeholders replaced.
     *
     * @param path         the message path in the messages configuration
     * @param replacements pairs of placeholder-value replacements applied in order
     * @return the formatted message string
     */
    String getMessage(String path, String... replacements);

    /**
     * Play a registered sound for a player.
     *
     * @param uuid     the UUID of the player
     * @param soundKey the sound key identifier from the sounds configuration
     */
    void playSound(UUID uuid, String soundKey);

    /**
     * Set a cooldown for a player.
     *
     * @param uuid       the UUID of the player
     * @param id         the cooldown identifier
     * @param durationMs the cooldown duration in milliseconds
     */
    void setCooldown(UUID uuid, String id, long durationMs);

    /**
     * Check if a player has an active cooldown.
     *
     * @param uuid the UUID of the player
     * @param id   the cooldown identifier
     * @return {@code true} if the cooldown is still active
     */
    boolean hasCooldown(UUID uuid, String id);

    /**
     * Add a context tag to a player (e.g., "combat", "duel", "ffa").
     *
     * @param uuid    the UUID of the player
     * @param context the context identifier to add
     */
    void addContext(UUID uuid, String context);

    /**
     * Remove a context tag from a player.
     *
     * @param uuid    the UUID of the player
     * @param context the context identifier to remove
     */
    void removeContext(UUID uuid, String context);

    /**
     * Check if a player has a specific context tag.
     *
     * @param uuid    the UUID of the player
     * @param context the context identifier to check
     * @return {@code true} if the player currently has the specified context
     */
    boolean hasContext(UUID uuid, String context);
}
