package com.ethernova.core.arena;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.*;
import org.bukkit.plugin.Plugin;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Tracks block changes and entities within arena regions, and provides
 * rollback (restoration) with double-pass liquid handling.
 * <p>
 * Flow:
 * <ol>
 *   <li>{@link #startTracking(String, ArenaRegion)} — begins recording changes for an arena id</li>
 *   <li>The {@link ArenaRollbackListener} feeds block/entity events into {@link #recordBlockChange(String, Block)}
 *       and {@link #recordEntity(String, Entity)}</li>
 *   <li>{@link #rollback(String)} — restores arena in two passes (clear liquids → restore blocks → cleanup entities)</li>
 * </ol>
 * <p>
 * Thread-safety: all public methods are safe to call from Bukkit main thread.
 */
public class ArenaRollbackEngine {

    private final Plugin plugin;
    private final Map<String, ArenaSession> sessions = new ConcurrentHashMap<>();

    /** Types of entities to remove during rollback */
    private static final Set<EntityType> CLEANUP_ENTITY_TYPES = Set.of(
            EntityType.END_CRYSTAL, EntityType.TNT,
            EntityType.FALLING_BLOCK, EntityType.ARROW, EntityType.SPECTRAL_ARROW,
            EntityType.TRIDENT, EntityType.FIREBALL, EntityType.SMALL_FIREBALL,
            EntityType.DRAGON_FIREBALL, EntityType.WITHER_SKULL,
            EntityType.ITEM, EntityType.EXPERIENCE_ORB,
            EntityType.WIND_CHARGE, EntityType.BREEZE_WIND_CHARGE,
            EntityType.ENDER_PEARL, EntityType.EGG, EntityType.SNOWBALL,
            EntityType.POTION, EntityType.FIREWORK_ROCKET,
            EntityType.BLOCK_DISPLAY, EntityType.INTERACTION
    );

    public ArenaRollbackEngine(Plugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Begin tracking an arena. Any previous session with the same id is discarded.
     */
    public void startTracking(String arenaId, ArenaRegion region) {
        sessions.put(arenaId.toLowerCase(), new ArenaSession(region));
        plugin.getLogger().fine("Arena rollback tracking started: " + arenaId);
    }

    /**
     * Stop tracking an arena without performing rollback.
     */
    public void stopTracking(String arenaId) {
        sessions.remove(arenaId.toLowerCase());
    }

    /**
     * Whether tracking is active for an arena.
     */
    public boolean isTracking(String arenaId) {
        return sessions.containsKey(arenaId.toLowerCase());
    }

    /**
     * Get the region being tracked for an arena.
     */
    public ArenaRegion getRegion(String arenaId) {
        ArenaSession session = sessions.get(arenaId.toLowerCase());
        return session != null ? session.region : null;
    }

    /**
     * Record the original state of a block before it is modified.
     * Only records the first change per position (the original state).
     */
    public void recordBlockChange(String arenaId, Block block) {
        ArenaSession session = sessions.get(arenaId.toLowerCase());
        if (session == null) return;
        if (!session.region.contains(block)) return;

        long key = posKey(block.getX(), block.getY(), block.getZ());
        // putIfAbsent — keep only the original state
        session.originalBlocks.putIfAbsent(key, block.getBlockData().clone());
    }

    /**
     * Record an entity spawned inside the arena for later cleanup.
     */
    public void recordEntity(String arenaId, Entity entity) {
        ArenaSession session = sessions.get(arenaId.toLowerCase());
        if (session == null) return;
        if (!session.region.contains(entity.getLocation())) return;
        session.trackedEntities.add(entity.getUniqueId());
    }

    /**
     * Find which arena (if any) contains the given block.
     */
    public String findArenaForBlock(Block block) {
        for (var entry : sessions.entrySet()) {
            if (entry.getValue().region.contains(block)) {
                return entry.getKey();
            }
        }
        return null;
    }

    /**
     * Find which arena (if any) contains the given location.
     */
    public String findArenaForLocation(Location loc) {
        for (var entry : sessions.entrySet()) {
            if (entry.getValue().region.contains(loc)) {
                return entry.getKey();
            }
        }
        return null;
    }

    /**
     * Perform full arena rollback with double-pass liquid restoration.
     * <p>
     * Pass 1: Set all changed blocks to AIR (kills liquid sources and flows).
     * Wait 2 ticks for server to propagate liquid removal.
     * Pass 2: Restore all original block states.
     * Then: Remove tracked + region entities.
     *
     * @param arenaId  the arena to rollback
     * @param thenRestart if true, immediately restart tracking after rollback
     */
    public void rollback(String arenaId, boolean thenRestart) {
        String key = arenaId.toLowerCase();
        ArenaSession session = sessions.remove(key);
        if (session == null) return;

        if (session.originalBlocks.isEmpty()) {
            // Nothing changed — just cleanup entities
            cleanupEntities(session);
            if (thenRestart) startTracking(arenaId, session.region);
            return;
        }

        World world = session.region.world();
        Map<Long, BlockData> originals = session.originalBlocks;

        try {
            // ── Pass 1: Set everything to AIR ──
            for (var entry : originals.entrySet()) {
                long pos = entry.getKey();
                int x = posX(pos), y = posY(pos), z = posZ(pos);
                Block block = world.getBlockAt(x, y, z);
                if (block.getType() != Material.AIR) {
                    block.setType(Material.AIR, false);
                }
            }

            // ── Wait 2 ticks for liquid de-propagation ──
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                try {
                    // ── Pass 2: Restore original blocks ──
                    for (var entry : originals.entrySet()) {
                        long pos = entry.getKey();
                        int x = posX(pos), y = posY(pos), z = posZ(pos);
                        Block block = world.getBlockAt(x, y, z);
                        block.setBlockData(entry.getValue(), true);
                    }

                    // ── Pass 3: Entity cleanup ──
                    cleanupEntities(session);

                    plugin.getLogger().fine("Arena rollback complete: " + arenaId
                            + " (" + originals.size() + " blocks restored)");
                } catch (Exception e) {
                    plugin.getLogger().log(Level.WARNING, "Error during arena rollback pass 2: " + arenaId, e);
                }

                if (thenRestart) startTracking(arenaId, session.region);
            }, 2L);

        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error during arena rollback pass 1: " + arenaId, e);
            if (thenRestart) startTracking(arenaId, session.region);
        }
    }

    /**
     * Convenience: rollback without restarting tracking.
     */
    public void rollback(String arenaId) {
        rollback(arenaId, false);
    }

    /**
     * Clean up all tracked entities + any cleanup-type entities still in the region.
     */
    private void cleanupEntities(ArenaSession session) {
        ArenaRegion region = session.region;
        World world = region.world();

        // Remove specifically tracked entities
        for (UUID entityId : session.trackedEntities) {
            Entity entity = Bukkit.getEntity(entityId);
            if (entity != null && !entity.isDead()) {
                entity.remove();
            }
        }

        // Sweep the region for any remaining cleanup-type entities
        // Use a bounding box slightly larger to catch entities at edges
        for (Entity entity : world.getEntities()) {
            if (entity instanceof Player) continue;
            Location loc = entity.getLocation();
            if (!region.contains(loc)) continue;

            if (CLEANUP_ENTITY_TYPES.contains(entity.getType())
                    || entity instanceof Item
                    || entity instanceof ExperienceOrb
                    || entity instanceof Arrow
                    || entity instanceof AbstractArrow) {
                entity.remove();
            }
        }
    }

    /**
     * Force rollback ALL active sessions (e.g. on server shutdown).
     */
    public void rollbackAll() {
        for (String arenaId : new ArrayList<>(sessions.keySet())) {
            ArenaSession session = sessions.remove(arenaId);
            if (session == null || session.originalBlocks.isEmpty()) continue;

            World world = session.region.world();
            // Synchronous single-pass restore (shutdown — no time for double-pass)
            for (var entry : session.originalBlocks.entrySet()) {
                long pos = entry.getKey();
                int x = posX(pos), y = posY(pos), z = posZ(pos);
                try {
                    Block block = world.getBlockAt(x, y, z);
                    block.setBlockData(entry.getValue(), false);
                } catch (Exception ignored) {
                    // World may be unloading
                }
            }
            cleanupEntities(session);
        }
    }

    /**
     * Get the number of changed blocks in a session (for stats/debug).
     */
    public int getChangedBlockCount(String arenaId) {
        ArenaSession session = sessions.get(arenaId.toLowerCase());
        return session != null ? session.originalBlocks.size() : 0;
    }

    // ── Position encoding: pack x/y/z into a long ──
    // x: bits 42-63 (22 bits, signed → ±2M), y: bits 0-9 (10 bits, 0-1023), z: bits 10-41 (22 bits, signed)
    private static long posKey(int x, int y, int z) {
        return ((long) x & 0x3FFFFF) << 42 | ((long) z & 0x3FFFFF) << 10 | ((long) y & 0x3FF);
    }

    private static int posX(long key) {
        int raw = (int) (key >> 42) & 0x3FFFFF;
        return (raw & 0x200000) != 0 ? raw | ~0x3FFFFF : raw; // sign extend
    }

    private static int posY(long key) {
        return (int) (key & 0x3FF);
    }

    private static int posZ(long key) {
        int raw = (int) (key >> 10) & 0x3FFFFF;
        return (raw & 0x200000) != 0 ? raw | ~0x3FFFFF : raw; // sign extend
    }

    // ── Internal session data ──

    private static class ArenaSession {
        final ArenaRegion region;
        /** Map of position → original BlockData (before first change) */
        final Map<Long, BlockData> originalBlocks = new ConcurrentHashMap<>();
        /** UUIDs of entities spawned during the session */
        final Set<UUID> trackedEntities = ConcurrentHashMap.newKeySet();

        ArenaSession(ArenaRegion region) {
            this.region = region;
        }
    }
}
