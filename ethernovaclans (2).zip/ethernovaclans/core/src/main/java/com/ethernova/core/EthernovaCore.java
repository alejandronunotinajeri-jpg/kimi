package com.ethernova.core;

import com.ethernova.core.api.CoreAPI;
import com.ethernova.core.api.CoreAPIImpl;
import com.ethernova.core.arena.ArenaRollbackEngine;
import com.ethernova.core.arena.ArenaRollbackListener;
import com.ethernova.core.boost.BoostManager;
import com.ethernova.core.config.CoreConfigManager;
import com.ethernova.core.context.ContextManager;
import com.ethernova.core.cooldown.CooldownManager;
import com.ethernova.core.economy.EconomyHook;
import com.ethernova.core.economy.EconomyManager;
import com.ethernova.core.event.EthernovaEventBus;
import com.ethernova.core.gui.GuiManager;
import com.ethernova.core.leaderboard.LeaderboardManager;
import com.ethernova.core.lobby.LobbyManager;
import com.ethernova.core.locale.PlayerLocaleManager;
import com.ethernova.core.module.ModuleManager;
import com.ethernova.core.maintenance.MaintenanceManager;
import com.ethernova.core.message.CoreMessageManager;
import com.ethernova.core.messaging.CrossServerMessenger;
import com.ethernova.core.metrics.EthernovaMetrics;
import com.ethernova.core.placeholder.EthernovaPlaceholders;
import com.ethernova.core.profile.PlayerProfileManager;
import com.ethernova.core.server.ServerModeManager;
import com.ethernova.core.scoreboard.EthernovaScoreboardManager;
import com.ethernova.core.service.ServiceRegistry;
import com.ethernova.core.sound.SoundManager;
import com.ethernova.core.state.PlayerStateManager;
import com.ethernova.core.storage.CoreStorageManager;
import com.ethernova.core.storage.MigrationManager;
import com.ethernova.core.visual.VisualManager;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Collections;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

public class EthernovaCore extends JavaPlugin {

    private static volatile EthernovaCore instance;
    private ExecutorService dbExecutor;
    private CoreConfigManager configManager;
    private CoreMessageManager messageManager;
    private CoreStorageManager storageManager;
    private PlayerProfileManager profileManager;
    private ContextManager contextManager;
    private EthernovaEventBus eventBus;
    private EconomyHook economyHook;
    private EconomyManager economyManager;
    private VisualManager visualManager;
    private CooldownManager cooldownManager;
    private ServerModeManager serverModeManager;
    private BoostManager boostManager;
    private CrossServerMessenger crossServerMessenger;
    private SoundManager soundManager;
    private PlayerLocaleManager localeManager;
    private GuiManager guiManager;
    private LeaderboardManager leaderboardManager;
    private MaintenanceManager maintenanceManager;
    private PlayerStateManager stateManager;
    private EthernovaScoreboardManager scoreboardManager;
    private EthernovaMetrics metrics;
    private CoreAPIImpl coreAPI;
    private ArenaRollbackEngine arenaRollbackEngine;
    private LobbyManager lobbyManager;
    private ModuleManager moduleManager;
    private com.ethernova.core.referral.ReferralManager referralManager;
    private com.ethernova.core.optimization.OptimizationManager optimizationManager;
    private com.ethernova.core.config.ConfigBackupManager backupManager;
    private com.ethernova.core.hook.PunishmentHook punishmentHook;
    private com.ethernova.core.gui.animation.GuiAnimationManager guiAnimationManager;
    private final Set<String> registeredPlugins = java.util.concurrent.ConcurrentHashMap.newKeySet();

    @Override
    public void onEnable() {
        long start = System.currentTimeMillis();
        instance = this; // Set early so other managers can access during startup

        // Phase 1: Config & Messages
        configManager = new CoreConfigManager(this);
        configManager.loadAll();
        String lang = getConfig().getString("general.language", "es");
        messageManager = new CoreMessageManager(this);
        localeManager = new PlayerLocaleManager(lang);
        soundManager = new SoundManager(getLogger());
        soundManager.loadFromConfig(getConfig().getConfigurationSection("sounds"));

        // Phase 1.5: Shared DB executor
        int dbThreads = getConfig().getInt("database.pool-size", 4);
        dbExecutor = Executors.newFixedThreadPool(dbThreads, r -> {
            Thread t = new Thread(r, "EthernovaDB");
            t.setDaemon(true);
            return t;
        });

        // Phase 2: Database
        storageManager = new CoreStorageManager(this);
        storageManager.initialize();
        runCoreMigrations();

        // Phase 3: Core Managers
        profileManager = new PlayerProfileManager(this);
        contextManager = new ContextManager();
        eventBus = new EthernovaEventBus();
        economyHook = new EconomyHook();
        economyManager = new EconomyManager(this);
        visualManager = new VisualManager();
        visualManager.init(this);
        cooldownManager = new CooldownManager();
        boostManager = new BoostManager(this);
        boostManager.start();
        maintenanceManager = new MaintenanceManager(this);

        // Phase 4: Server Mode Detection
        serverModeManager = new ServerModeManager(this);
        serverModeManager.detect();

        // Phase 5: Cross-server Messaging
        crossServerMessenger = new CrossServerMessenger(this);
        crossServerMessenger.enable();

        // Phase 6: GUI Manager
        guiManager = new GuiManager(this);
        getServer().getPluginManager().registerEvents(guiManager, this);

        // Phase 6.5: State & Scoreboard
        stateManager = new PlayerStateManager();
        scoreboardManager = new EthernovaScoreboardManager(this);
        scoreboardManager.start();

        // Phase 6.8: Arena Rollback Engine
        arenaRollbackEngine = new ArenaRollbackEngine(this);
        getServer().getPluginManager().registerEvents(new ArenaRollbackListener(arenaRollbackEngine), this);

        // Phase 6.9: Lobby Manager (proxy — real implementation in EthernovaLobby module)
        lobbyManager = new LobbyManager();

        // Phase 6.10: Referral Manager
        referralManager = new com.ethernova.core.referral.ReferralManager(this);

        // Phase 6.11: Optimization Manager
        optimizationManager = new com.ethernova.core.optimization.OptimizationManager(this);

        // Phase 6.12: Config Backup Manager
        backupManager = new com.ethernova.core.config.ConfigBackupManager(this);

        // Phase 6.13: Punishment Hook (LiteBans / AdvancedBan)
        punishmentHook = new com.ethernova.core.hook.PunishmentHook(this);

        // Phase 6.14: GUI Animation Manager
        guiAnimationManager = new com.ethernova.core.gui.animation.GuiAnimationManager(this);

        // Phase 7: Listeners
        getServer().getPluginManager().registerEvents(new com.ethernova.core.listener.CorePlayerListener(this), this);

        // Phase 8: Commands
        var cmd = getCommand("ethernova");
        if (cmd != null) {
            var exec = new com.ethernova.core.command.CoreCommand(this);
            cmd.setExecutor(exec);
            cmd.setTabCompleter(exec);
        }

        // Phase 8.1: Player commands (lobby/menu moved to EthernovaLobby module)
        var playerCmd = new com.ethernova.core.command.CorePlayerCommand(this);
        String[] playerCommands = {"kiteditor", "settings", "rankings"};
        for (String pcmd : playerCommands) {
            var c = getCommand(pcmd);
            if (c != null) {
                c.setExecutor(playerCmd);
                c.setTabCompleter(playerCmd);
            }
        }

        // Phase 9: PlaceholderAPI
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new EthernovaPlaceholders(this).register();
            getLogger().info("PlaceholderAPI expansion registrada");
        }

        // Phase 10: Register API
        coreAPI = new CoreAPIImpl(this);
        ServiceRegistry.register(CoreAPI.class, coreAPI);

        // Phase 11: Leaderboard system
        leaderboardManager = new LeaderboardManager(this);
        leaderboardManager.start();

        // Phase 12: Auto-save task
        int saveInterval = getConfig().getInt("profiles.auto-save-interval", 300) * 20;
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> profileManager.saveAll(), saveInterval, saveInterval);

        // Phase 13: Metrics
        metrics = new EthernovaMetrics(this);

        // Phase 14: Module detection (delayed 1 tick so all plugins finish loading)
        moduleManager = new ModuleManager(this);
        Bukkit.getScheduler().runTaskLater(this, () -> moduleManager.detect(), 1L);

        long elapsed = System.currentTimeMillis() - start;
        getLogger().info("EthernovaCore v" + getDescription().getVersion() + " habilitado en " + elapsed + "ms (modo: " + serverModeManager.getMode() + ")");
    }

    @Override
    public void onDisable() {
        // Cancel all scheduled tasks first to prevent races with save
        Bukkit.getScheduler().cancelTasks(this);
        if (guiAnimationManager != null) guiAnimationManager.shutdown();
        if (lobbyManager != null) lobbyManager.shutdown();
        if (optimizationManager != null) optimizationManager.shutdown();
        if (arenaRollbackEngine != null) arenaRollbackEngine.rollbackAll();
        ServiceRegistry.unregister(CoreAPI.class);
        if (scoreboardManager != null) scoreboardManager.stop();
        if (leaderboardManager != null) leaderboardManager.stop();
        if (maintenanceManager != null) maintenanceManager.cancelCountdown();
        if (boostManager != null) boostManager.stop();
        if (crossServerMessenger != null) crossServerMessenger.disable();
        if (eventBus != null) eventBus.clearAll();
        if (profileManager != null) profileManager.saveAll();
        if (visualManager != null) visualManager.cleanup();
        if (dbExecutor != null) {
            dbExecutor.shutdown();
            try {
                if (!dbExecutor.awaitTermination(10, TimeUnit.SECONDS)) {
                    dbExecutor.shutdownNow();
                    getLogger().warning("DB executor did not terminate in time, forced shutdown");
                }
            } catch (InterruptedException e) {
                dbExecutor.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
        if (storageManager != null) storageManager.close();
        ServiceRegistry.clearAll();
        instance = null;
    }

    private void runCoreMigrations() {
        new MigrationManager(storageManager, getLogger(), "ethernova_core")
            .addMigration(1,
                "CREATE TABLE IF NOT EXISTS ethernova_profiles (uuid VARCHAR(36) PRIMARY KEY, name VARCHAR(16), kills INT DEFAULT 0, deaths INT DEFAULT 0, play_time BIGINT DEFAULT 0, first_join BIGINT DEFAULT 0, last_join BIGINT DEFAULT 0, level INT DEFAULT 1, prestige INT DEFAULT 0, xp BIGINT DEFAULT 0, coins DOUBLE DEFAULT 0)",
                "CREATE TABLE IF NOT EXISTS ethernova_profile_data (uuid VARCHAR(36) NOT NULL, data_key VARCHAR(128) NOT NULL, data_value TEXT, PRIMARY KEY (uuid, data_key))")
            .addLenientMigration(2,
                // Add columns that may be missing on databases created before level/prestige/xp/coins existed.
                // Lenient: each statement is tried independently; if the column already exists the error is silently skipped.
                "ALTER TABLE ethernova_profiles ADD COLUMN level INT DEFAULT 1",
                "ALTER TABLE ethernova_profiles ADD COLUMN prestige INT DEFAULT 0",
                "ALTER TABLE ethernova_profiles ADD COLUMN xp BIGINT DEFAULT 0",
                "ALTER TABLE ethernova_profiles ADD COLUMN coins DOUBLE DEFAULT 0")
            .migrate();
    }

    // --- Getters ---
    public static EthernovaCore getInstance() { return instance; }
    public ExecutorService getDbExecutor() { return dbExecutor; }
    public CoreConfigManager getConfigManager() { return configManager; }
    public CoreMessageManager getMessageManager() { return messageManager; }
    public CoreStorageManager getStorageManager() { return storageManager; }
    public PlayerProfileManager getProfileManager() { return profileManager; }
    public ContextManager getContextManager() { return contextManager; }
    public EthernovaEventBus getEventBus() { return eventBus; }
    public EconomyHook getEconomyHook() { return economyHook; }
    public EconomyManager getEconomyManager() { return economyManager; }
    public VisualManager getVisualManager() { return visualManager; }
    public CooldownManager getCooldownManager() { return cooldownManager; }
    public ServerModeManager getServerModeManager() { return serverModeManager; }
    public BoostManager getBoostManager() { return boostManager; }
    public CrossServerMessenger getCrossServerMessenger() { return crossServerMessenger; }
    public SoundManager getSoundManager() { return soundManager; }
    public PlayerLocaleManager getLocaleManager() { return localeManager; }
    public GuiManager getGuiManager() { return guiManager; }
    public LeaderboardManager getLeaderboardManager() { return leaderboardManager; }
    public MaintenanceManager getMaintenanceManager() { return maintenanceManager; }
    public PlayerStateManager getStateManager() { return stateManager; }
    public EthernovaScoreboardManager getScoreboardManager() { return scoreboardManager; }
    public CoreAPIImpl getCoreAPI() { return coreAPI; }
    public EthernovaMetrics getMetrics() { return metrics; }
    public ArenaRollbackEngine getArenaRollbackEngine() { return arenaRollbackEngine; }
    public LobbyManager getLobbyManager() { return lobbyManager; }
    public ModuleManager getModuleManager() { return moduleManager; }
    public com.ethernova.core.referral.ReferralManager getReferralManager() { return referralManager; }
    public com.ethernova.core.optimization.OptimizationManager getOptimizationManager() { return optimizationManager; }
    public com.ethernova.core.config.ConfigBackupManager getBackupManager() { return backupManager; }
    public com.ethernova.core.hook.PunishmentHook getPunishmentHook() { return punishmentHook; }
    public com.ethernova.core.gui.animation.GuiAnimationManager getGuiAnimationManager() { return guiAnimationManager; }

    public void registerPlugin(String name) { registeredPlugins.add(name); }
    public void unregisterPlugin(String name) { registeredPlugins.remove(name); }
    public Set<String> getRegisteredPlugins() { return Collections.unmodifiableSet(registeredPlugins); }
}