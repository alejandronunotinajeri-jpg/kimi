package com.ethernova.core.event;

import java.util.UUID;

/** Fired when a duel ends. */
public record DuelEndEvent(UUID winnerUuid, String winnerName, UUID loserUuid, String loserName,
                           String kit, long durationMs) {}
