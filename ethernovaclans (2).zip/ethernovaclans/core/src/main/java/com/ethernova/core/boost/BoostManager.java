package com.ethernova.core.boost;

import com.ethernova.core.EthernovaCore;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Global server boost system. Any plugin can activate a temporary multiplier
 * (e.g., Double Money, Double XP) that all plugins can read.
 *
 * Usage:
 *   boostManager.activate("money", 2.0, 30*60*1000L, "admin"); // 2x money for 30 min
 *   double mult = boostManager.getMultiplier("money"); // returns 2.0 while active
 */
public class BoostManager {

    private final EthernovaCore core;
    private final Map<String, ActiveBoost> activeBoosts = new ConcurrentHashMap<>();
    private BukkitTask cleanupTask;

    public BoostManager(EthernovaCore core) {
        this.core = core;
    }

    public void start() {
        // Cleanup expired boosts every 5 seconds
        cleanupTask = Bukkit.getScheduler().runTaskTimer(core, this::cleanup, 100L, 100L);
    }

    public void stop() {
        if (cleanupTask != null) cleanupTask.cancel();
        activeBoosts.clear();
    }

    /**
     * Activate a boost. If a boost of the same type exists, the higher multiplier wins.
     * @param type   Boost category (e.g., "money", "xp", "drops")
     * @param multi  Multiplier (e.g., 2.0 for double)
     * @param durationMs Duration in milliseconds
     * @param source Who activated it (admin name, event name, etc.)
     */
    public void activate(String type, double multi, long durationMs, String source) {
        long expiry = System.currentTimeMillis() + durationMs;
        ActiveBoost existing = activeBoosts.get(type);

        // Use higher multiplier or extend duration
        if (existing != null && existing.expiry > System.currentTimeMillis()) {
            if (multi > existing.multiplier) {
                activeBoosts.put(type, new ActiveBoost(type, multi, expiry, source));
            } else if (expiry > existing.expiry) {
                activeBoosts.put(type, new ActiveBoost(type, existing.multiplier, expiry, existing.source));
            }
        } else {
            activeBoosts.put(type, new ActiveBoost(type, multi, expiry, source));
        }

        // Publish event so other plugins can react
        core.getEventBus().publish(new BoostActivatedEvent(type, multi, durationMs, source));

        core.getLogger().info("Boost activado: " + type + " x" + multi + " por " +
                core.getConfigManager().formatTime(durationMs) + " (fuente: " + source + ")");
    }

    /**
     * Deactivate a boost early.
     */
    public void deactivate(String type) {
        ActiveBoost removed = activeBoosts.remove(type);
        if (removed != null) {
            core.getEventBus().publish(new BoostDeactivatedEvent(type, removed.source));
        }
    }

    /**
     * Get the current multiplier for a boost type.
     * Returns 1.0 if no active boost.
     */
    public double getMultiplier(String type) {
        ActiveBoost boost = activeBoosts.get(type);
        if (boost == null || boost.expiry <= System.currentTimeMillis()) return 1.0;
        return boost.multiplier;
    }

    /**
     * Check if a boost type is active.
     */
    public boolean isActive(String type) {
        ActiveBoost boost = activeBoosts.get(type);
        return boost != null && boost.expiry > System.currentTimeMillis();
    }

    /**
     * Get remaining time in ms for a boost.
     */
    public long getRemainingMs(String type) {
        ActiveBoost boost = activeBoosts.get(type);
        if (boost == null) return 0;
        return Math.max(0, boost.expiry - System.currentTimeMillis());
    }

    /**
     * Get all currently active boosts.
     */
    public Collection<ActiveBoost> getActiveBoosts() {
        cleanup();
        return Collections.unmodifiableCollection(activeBoosts.values());
    }

    private void cleanup() {
        long now = System.currentTimeMillis();
        activeBoosts.entrySet().removeIf(e -> {
            if (e.getValue().expiry <= now) {
                core.getEventBus().publish(new BoostDeactivatedEvent(e.getKey(), e.getValue().source));
                return true;
            }
            return false;
        });
    }

    /**
     * Data class for an active boost.
     */
    public static class ActiveBoost {
        public final String type;
        public final double multiplier;
        public final long expiry;
        public final String source;

        public ActiveBoost(String type, double multiplier, long expiry, String source) {
            this.type = type;
            this.multiplier = multiplier;
            this.expiry = expiry;
            this.source = source;
        }

        public long getRemainingMs() {
            return Math.max(0, expiry - System.currentTimeMillis());
        }
    }

    /** Event published when a boost activates. */
    public record BoostActivatedEvent(String type, double multiplier, long durationMs, String source) {}

    /** Event published when a boost expires or is deactivated. */
    public record BoostDeactivatedEvent(String type, String source) {}
}
