package com.ethernova.core.profile;

import com.ethernova.core.EthernovaCore;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

public class PlayerProfileManager {

    private final EthernovaCore core;
    private final Map<UUID, PlayerProfile> profiles = new ConcurrentHashMap<>();

    public PlayerProfileManager(EthernovaCore core) { this.core = core; }

    public PlayerProfile getProfile(UUID uuid) { return profiles.get(uuid); }

    public PlayerProfile getOrCreate(UUID uuid, String name) {
        PlayerProfile existing = profiles.get(uuid);
        if (existing != null) { existing.setName(name); return existing; }
        PlayerProfile loaded = loadFromDB(uuid);
        if (loaded != null) { loaded.setName(name); }
        else {
            loaded = new PlayerProfile(uuid, name);
            loaded.setFirstJoin(System.currentTimeMillis());
        }
        PlayerProfile prev = profiles.putIfAbsent(uuid, loaded);
        return prev != null ? prev : loaded;
    }

    /** Register a pre-created profile if none exists yet. Safe for main thread. */
    public void registerIfAbsent(UUID uuid, PlayerProfile profile) {
        profiles.putIfAbsent(uuid, profile);
    }

    /** Merge persisted DB data into an existing in-memory profile. Safe for async.
     *  Uses additive merge for counters so in-memory progress earned between
     *  registerIfAbsent() and this call is not silently overwritten. */
    public void mergeFromDB(UUID uuid, String name) {
        PlayerProfile dbProfile = loadFromDB(uuid);
        if (dbProfile == null) return;
        PlayerProfile current = profiles.get(uuid);
        if (current == null) return;
        current.setName(name);
        // Additive merge for stats — in-memory starts at 0, so adding DB values is correct.
        // If player earned kills/deaths between register and merge, those are preserved.
        current.setKills(current.getKills() + dbProfile.getKills());
        current.setDeaths(current.getDeaths() + dbProfile.getDeaths());
        // For play time, first join, last join: use DB values (these don't change in the gap)
        current.setPlayTime(dbProfile.getPlayTime());
        current.setFirstJoin(dbProfile.getFirstJoin());
        if (current.getLastJoin() == 0) current.setLastJoin(dbProfile.getLastJoin());
        // For level/prestige/xp/coins: use max to preserve any in-memory progress
        current.setLevel(Math.max(current.getLevel(), dbProfile.getLevel()));
        current.setPrestige(Math.max(current.getPrestige(), dbProfile.getPrestige()));
        current.setXP(Math.max(current.getXP(), dbProfile.getXP()));
        current.setCoins(Math.max(current.getCoins(), dbProfile.getCoins()));
        current.loadCustomData(dbProfile.getAllCustomData());
    }

    public void save(PlayerProfile profile) {
        String sql = core.getStorageManager().isMySQL()
            ? "INSERT INTO ethernova_profiles (uuid,name,kills,deaths,play_time,first_join,last_join,level,prestige,xp,coins) VALUES (?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name),kills=VALUES(kills),deaths=VALUES(deaths),play_time=VALUES(play_time),last_join=VALUES(last_join),level=VALUES(level),prestige=VALUES(prestige),xp=VALUES(xp),coins=VALUES(coins)"
            : "INSERT INTO ethernova_profiles (uuid,name,kills,deaths,play_time,first_join,last_join,level,prestige,xp,coins) VALUES (?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(uuid) DO UPDATE SET name=excluded.name,kills=excluded.kills,deaths=excluded.deaths,play_time=excluded.play_time,last_join=excluded.last_join,level=excluded.level,prestige=excluded.prestige,xp=excluded.xp,coins=excluded.coins";
        try (Connection conn = core.getStorageManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            setProfileParams(ps, profile);
            ps.executeUpdate();
        } catch (Exception e) {
            core.getLogger().log(Level.WARNING, "Failed to save profile for " + profile.getUuid(), e);
        }
        saveCustomData(profile);
    }

    private void setProfileParams(PreparedStatement ps, PlayerProfile profile) throws java.sql.SQLException {
        ps.setString(1, profile.getUuid().toString());
        ps.setString(2, profile.getName());
        ps.setInt(3, profile.getKills());
        ps.setInt(4, profile.getDeaths());
        ps.setLong(5, profile.getPlayTime());
        ps.setLong(6, profile.getFirstJoin());
        ps.setLong(7, profile.getLastJoin());
        ps.setInt(8, profile.getLevel());
        ps.setInt(9, profile.getPrestige());
        ps.setLong(10, profile.getXP());
        ps.setDouble(11, profile.getCoins());
    }

    private PlayerProfile loadFromDB(UUID uuid) {
        try (Connection conn = core.getStorageManager().getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM ethernova_profiles WHERE uuid = ?")) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    PlayerProfile p = new PlayerProfile(uuid, rs.getString("name"));
                    p.setKills(rs.getInt("kills"));
                    p.setDeaths(rs.getInt("deaths"));
                    p.setPlayTime(rs.getLong("play_time"));
                    p.setFirstJoin(rs.getLong("first_join"));
                    p.setLastJoin(rs.getLong("last_join"));
                    p.setLevel(rs.getInt("level"));
                    p.setPrestige(rs.getInt("prestige"));
                    p.setXP(rs.getLong("xp"));
                    p.setCoins(rs.getDouble("coins"));
                    loadCustomData(p);
                    return p;
                }
            }
        } catch (Exception e) {
            core.getLogger().log(Level.WARNING, "Failed to load profile for " + uuid, e);
        }
        return null;
    }

    private void loadCustomData(PlayerProfile profile) {
        try (Connection conn = core.getStorageManager().getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT data_key, data_value FROM ethernova_profile_data WHERE uuid = ?")) {
            ps.setString(1, profile.getUuid().toString());
            Map<String, String> data = new java.util.HashMap<>();
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    data.put(rs.getString("data_key"), rs.getString("data_value"));
                }
            }
            profile.loadCustomData(data);
        } catch (Exception e) {
            core.getLogger().log(Level.FINE, "Could not load custom data for " + profile.getUuid(), e);
        }
    }

    private void saveCustomData(PlayerProfile profile) {
        Map<String, String> data = profile.getAllCustomData();
        if (data.isEmpty()) return;
        String sql = core.getStorageManager().isMySQL()
            ? "INSERT INTO ethernova_profile_data (uuid, data_key, data_value) VALUES (?,?,?) ON DUPLICATE KEY UPDATE data_value=VALUES(data_value)"
            : "INSERT INTO ethernova_profile_data (uuid, data_key, data_value) VALUES (?,?,?) ON CONFLICT(uuid, data_key) DO UPDATE SET data_value=excluded.data_value";
        try (Connection conn = core.getStorageManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            for (Map.Entry<String, String> entry : data.entrySet()) {
                ps.setString(1, profile.getUuid().toString());
                ps.setString(2, entry.getKey());
                ps.setString(3, entry.getValue());
                ps.addBatch();
            }
            ps.executeBatch();
        } catch (Exception e) {
            core.getLogger().log(Level.WARNING, "Failed to save custom data for " + profile.getUuid(), e);
        }
    }

    public void remove(UUID uuid) { profiles.remove(uuid); }

    public void saveAll() {
        if (profiles.isEmpty()) return;
        String sql = core.getStorageManager().isMySQL()
            ? "INSERT INTO ethernova_profiles (uuid,name,kills,deaths,play_time,first_join,last_join,level,prestige,xp,coins) VALUES (?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name),kills=VALUES(kills),deaths=VALUES(deaths),play_time=VALUES(play_time),last_join=VALUES(last_join),level=VALUES(level),prestige=VALUES(prestige),xp=VALUES(xp),coins=VALUES(coins)"
            : "INSERT INTO ethernova_profiles (uuid,name,kills,deaths,play_time,first_join,last_join,level,prestige,xp,coins) VALUES (?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(uuid) DO UPDATE SET name=excluded.name,kills=excluded.kills,deaths=excluded.deaths,play_time=excluded.play_time,last_join=excluded.last_join,level=excluded.level,prestige=excluded.prestige,xp=excluded.xp,coins=excluded.coins";
        try (Connection conn = core.getStorageManager().getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                for (PlayerProfile profile : profiles.values()) {
                    setProfileParams(ps, profile);
                    ps.addBatch();
                }
                ps.executeBatch();
            }
            conn.commit();
        } catch (Exception e) {
            core.getLogger().log(Level.WARNING, "Failed to batch-save profiles", e);
            // Rollback is handled automatically when Connection.close() is called
            // on a non-committed transaction with try-with-resources
        }
        // Save custom data for all
        for (PlayerProfile profile : profiles.values()) {
            saveCustomData(profile);
        }
    }

    public java.util.Collection<PlayerProfile> getAllProfiles() {
        return java.util.Collections.unmodifiableCollection(profiles.values());
    }

    // ═══════════════ Convenience helpers ═══════════════

    /**
     * Get a raw string value from a player's custom data.
     */
    public String getData(UUID uuid, String key) {
        PlayerProfile p = profiles.get(uuid);
        if (p == null) return null;
        return p.getCustom(key);
    }

    /**
     * Get a boolean from a player's custom data, with default.
     */
    public boolean getDataBoolean(UUID uuid, String key, boolean def) {
        PlayerProfile p = profiles.get(uuid);
        if (p == null) return def;
        String val = p.getCustom(key);
        return val == null ? def : Boolean.parseBoolean(val);
    }

    /**
     * Set custom data key for a player.
     */
    public void setData(UUID uuid, String key, String value) {
        PlayerProfile p = profiles.get(uuid);
        if (p != null) p.setCustom(key, value);
    }

    /**
     * Add coins to a player's profile.
     */
    public void addCoins(UUID uuid, double amount) {
        PlayerProfile p = profiles.get(uuid);
        if (p != null) p.addCoins(amount);
    }
}
