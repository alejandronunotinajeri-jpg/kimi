package com.ethernova.core.event;

import org.bukkit.Location;

import java.util.UUID;

public record EthernovaPlayerKillEvent(
        UUID killerUuid, String killerName,
        UUID victimUuid, String victimName,
        String context,
        Location victimLocation
) {}
