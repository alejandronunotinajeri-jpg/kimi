package com.ethernova.core.event;

import java.util.UUID;

/** Fired when a player's coins change. */
public record CoinsChangeEvent(UUID playerUuid, double oldAmount, double newAmount, String reason) {}
