package com.ethernova.core.lobby;

import com.ethernova.core.api.LobbyAPI;
import com.ethernova.core.service.ServiceRegistry;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

/**
 * Proxy/facade for the lobby system that delegates to {@link LobbyAPI}.
 * <p>
 * This class lives in core so that all modules (duels, ffa, party, etc.) can
 * continue using {@code core.getLobbyManager()} without depending on the lobby module.
 * <p>
 * When the EthernovaLobby plugin is installed, the real implementation registers
 * via {@link ServiceRegistry} and this proxy delegates to it.
 * When the lobby module is NOT installed, all methods are safe no-ops.
 */
public class LobbyManager {

    /** Special action value for PvP sword hold-to-activate mechanic. */
    public static final String PVP_SWORD_ACTION = "PVP_SWORD";

    private LobbyAPI getAPI() {
        return ServiceRegistry.get(LobbyAPI.class);
    }

    // ────────────────── Delegated Methods ──────────────────

    public boolean isEnabled() {
        LobbyAPI api = getAPI();
        return api != null && api.isEnabled();
    }

    public void sendToLobby(Player player) {
        LobbyAPI api = getAPI();
        if (api != null) api.sendToLobby(player);
    }

    public void giveLobbyItems(Player player) {
        LobbyAPI api = getAPI();
        if (api != null) api.giveLobbyItems(player);
    }

    public boolean isInLobbyState(Player player) {
        LobbyAPI api = getAPI();
        return api != null && api.isInLobbyState(player);
    }

    public void cleanupPlayer(UUID uuid) {
        LobbyAPI api = getAPI();
        if (api != null) api.cleanupPlayer(uuid);
    }

    public long getDoubleJumpCooldown(UUID uuid) {
        LobbyAPI api = getAPI();
        return api != null ? api.getDoubleJumpCooldown(uuid) : 0;
    }

    public void setDoubleJumpCooldown(UUID uuid) {
        LobbyAPI api = getAPI();
        if (api != null) api.setDoubleJumpCooldown(uuid);
    }

    public void deactivatePvpMode(Player player) {
        LobbyAPI api = getAPI();
        if (api != null) api.deactivatePvpMode(player);
    }

    public ItemStack createQueueCancelItem() {
        LobbyAPI api = getAPI();
        return api != null ? api.createQueueCancelItem() : null;
    }

    public boolean isQueueCancelItem(ItemStack item) {
        LobbyAPI api = getAPI();
        return api != null && api.isQueueCancelItem(item);
    }

    public String getLobbyItemAction(ItemStack item) {
        LobbyAPI api = getAPI();
        return api != null ? api.getLobbyItemAction(item) : null;
    }

    public Location getLobbySpawn() {
        LobbyAPI api = getAPI();
        return api != null ? api.getLobbySpawn() : null;
    }

    public void setLobbySpawn(Location location) {
        LobbyAPI api = getAPI();
        if (api != null) api.setLobbySpawn(location);
    }

    public void loadConfig() {
        LobbyAPI api = getAPI();
        if (api != null) api.loadConfig();
    }

    public void shutdown() {
        LobbyAPI api = getAPI();
        if (api != null) api.shutdown();
    }

    public NamespacedKey getLobbyItemKey() {
        LobbyAPI api = getAPI();
        return api != null ? api.getLobbyItemKey() : null;
    }

    public NamespacedKey getQueueCancelKey() {
        LobbyAPI api = getAPI();
        return api != null ? api.getQueueCancelKey() : null;
    }
}
