package com.ethernova.core.leaderboard;

import com.ethernova.core.EthernovaCore;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Cached leaderboard system. Periodically refreshes top-N from database.
 * Available types: kills, deaths, kdr, coins, level, playtime, xp
 */
public class LeaderboardManager {

    private final EthernovaCore core;
    private final Map<String, List<LeaderboardEntry>> cache = new ConcurrentHashMap<>();
    private BukkitTask refreshTask;
    private int topSize = 10;

    public static final Set<String> VALID_TYPES = Set.of(
            "kills", "deaths", "kdr", "coins", "level", "playtime", "xp");

    public LeaderboardManager(EthernovaCore core) {
        this.core = core;
        this.topSize = core.getConfig().getInt("leaderboard.top-size", 10);
    }

    public void start() {
        int intervalSeconds = core.getConfig().getInt("leaderboard.refresh-interval", 120);
        long intervalTicks = intervalSeconds * 20L;

        // Initial async load
        Bukkit.getScheduler().runTaskAsynchronously(core, this::refreshAll);

        // Periodic refresh
        refreshTask = Bukkit.getScheduler().runTaskTimerAsynchronously(core,
                this::refreshAll, intervalTicks, intervalTicks);
    }

    public void stop() {
        if (refreshTask != null) refreshTask.cancel();
        cache.clear();
    }

    public void refreshAll() {
        for (String type : VALID_TYPES) {
            try {
                List<LeaderboardEntry> entries = fetchFromDB(type);
                cache.put(type, entries);
            } catch (Exception e) {
                core.getLogger().log(Level.WARNING, "Failed to refresh leaderboard: " + type, e);
            }
        }
    }

    /**
     * Get cached leaderboard for a type.
     */
    public List<LeaderboardEntry> getTop(String type) {
        return cache.getOrDefault(type.toLowerCase(), List.of());
    }

    /**
     * Get a player's rank (1-based) for a type. Returns -1 if not found.
     */
    public int getRank(String type, UUID uuid) {
        List<LeaderboardEntry> list = cache.get(type.toLowerCase());
        if (list == null) return -1;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).uuid().equals(uuid)) return i + 1;
        }
        return -1;
    }

    /** Whitelist of valid SQL column names for leaderboard queries. */
    private static final Set<String> SAFE_COLUMNS = Set.of(
            "kills", "deaths", "coins", "level", "play_time", "xp");

    private List<LeaderboardEntry> fetchFromDB(String type) throws Exception {
        String column = switch (type) {
            case "kills" -> "kills";
            case "deaths" -> "deaths";
            case "coins" -> "coins";
            case "level" -> "level";
            case "playtime" -> "play_time";
            case "xp" -> "xp";
            case "kdr" -> "kills"; // We'll compute KDR in Java
            default -> throw new IllegalArgumentException("Invalid type: " + type);
        };

        // Defense-in-depth: validate column against whitelist before SQL concatenation
        if (!SAFE_COLUMNS.contains(column)) {
            throw new IllegalArgumentException("Unsafe column name: " + column);
        }

        List<LeaderboardEntry> entries = new ArrayList<>();

        if ("kdr".equals(type)) {
            // KDR requires both kills and deaths
            String sql = "SELECT uuid, name, kills, deaths FROM ethernova_profiles " +
                    "WHERE kills > 0 ORDER BY CASE WHEN deaths = 0 THEN kills ELSE (kills * 1.0) / deaths END DESC LIMIT ?";
            try (Connection conn = core.getStorageManager().getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, topSize);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        int kills = rs.getInt("kills");
                        int deaths = rs.getInt("deaths");
                        double kdr = deaths == 0 ? kills : (double) kills / deaths;
                        entries.add(new LeaderboardEntry(
                                UUID.fromString(rs.getString("uuid")),
                                rs.getString("name"),
                                String.format("%.2f", kdr),
                                kdr));
                    }
                }
            }
        } else {
            String sql = "SELECT uuid, name, " + column + " FROM ethernova_profiles ORDER BY " + column + " DESC LIMIT ?";
            try (Connection conn = core.getStorageManager().getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, topSize);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        double numericValue = rs.getDouble(column);
                        String displayValue = switch (type) {
                            case "coins" -> String.format("%.2f", numericValue);
                            case "playtime" -> core.getConfigManager().formatTime((long) numericValue);
                            default -> String.valueOf((long) numericValue);
                        };
                        entries.add(new LeaderboardEntry(
                                UUID.fromString(rs.getString("uuid")),
                                rs.getString("name"),
                                displayValue,
                                numericValue));
                    }
                }
            }
        }

        return Collections.unmodifiableList(entries);
    }

    /**
     * A single leaderboard entry.
     */
    public record LeaderboardEntry(UUID uuid, String name, String displayValue, double numericValue) {}
}
