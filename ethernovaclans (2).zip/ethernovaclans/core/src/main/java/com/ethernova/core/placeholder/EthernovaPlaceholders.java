package com.ethernova.core.placeholder;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.boost.BoostManager;
import com.ethernova.core.leaderboard.LeaderboardManager;
import com.ethernova.core.profile.PlayerProfile;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * PlaceholderAPI expansion for Ethernova.
 * Placeholders:
 *   %ethernova_kills%           — Player kills
 *   %ethernova_deaths%          — Player deaths
 *   %ethernova_kdr%             — Kill/Death ratio
 *   %ethernova_level%           — Current level
 *   %ethernova_prestige%        — Current prestige
 *   %ethernova_coins%           — Coins (formatted)
 *   %ethernova_xp%              — Current XP
 *   %ethernova_xp_needed%       — XP needed for next level
 *   %ethernova_level_progress%  — Level progress bar (10 chars)
 *   %ethernova_playtime%        — Play time in seconds
 *   %ethernova_playtime_formatted% — Play time (Xh Xm Xs)
 *   %ethernova_name%            — Player name from profile
 *   %ethernova_server_mode%     — Server mode
 *   %ethernova_online%          — Online player count
 *   %ethernova_max_players%     — Max players
 *   %ethernova_maintenance%     — Maintenance status
 *   %ethernova_boost_<type>%    — Boost multiplier
 *   %ethernova_boost_<type>_time% — Boost remaining time
 *   %ethernova_rank_<type>%     — Leaderboard rank (kills, coins, level, etc.)
 *   %ethernova_top_<type>_<n>_name%  — Name at position n
 *   %ethernova_top_<type>_<n>_value% — Value at position n
 */
public class EthernovaPlaceholders extends PlaceholderExpansion {

    private final EthernovaCore core;

    public EthernovaPlaceholders(EthernovaCore core) {
        this.core = core;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "ethernova";
    }

    @Override
    public @NotNull String getAuthor() {
        return "Ethernova";
    }

    @Override
    public @NotNull String getVersion() {
        return core.getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public @Nullable String onRequest(OfflinePlayer player, @NotNull String params) {
        String lower = params.toLowerCase();

        // ─── State placeholders ───
        if ("state".equals(lower)) {
            if (player == null) return "lobby";
            return core.getStateManager().getState(player.getUniqueId());
        }
        if ("map".equals(lower)) {
            if (player == null) return "";
            return core.getStateManager().getMap(player.getUniqueId());
        }

        // ─── Server-wide placeholders ───
        if ("server_mode".equals(lower)) {
            return core.getServerModeManager().getMode().name();
        }
        if ("online".equals(lower)) {
            return String.valueOf(core.getServer().getOnlinePlayers().size());
        }
        if ("max_players".equals(lower)) {
            return String.valueOf(core.getServer().getMaxPlayers());
        }
        if ("maintenance".equals(lower)) {
            return core.getMaintenanceManager() != null && core.getMaintenanceManager().isEnabled() ? "true" : "false";
        }

        // ─── Boost placeholders ───
        if (lower.startsWith("boost_")) {
            String boostKey = lower.substring(6);
            if (boostKey.endsWith("_time")) {
                String type = boostKey.substring(0, boostKey.length() - 5);
                long remaining = core.getBoostManager().getRemainingMs(type);
                return core.getConfigManager().formatTime(remaining);
            }
            return String.format("%.1f", core.getBoostManager().getMultiplier(boostKey));
        }

        // ─── Leaderboard placeholders: top_<type>_<n>_name / top_<type>_<n>_value ───
        if (lower.startsWith("top_") && core.getLeaderboardManager() != null) {
            return handleTopPlaceholder(lower.substring(4));
        }

        // ─── Rank placeholders: rank_<type> ───
        if (lower.startsWith("rank_") && player != null && core.getLeaderboardManager() != null) {
            String type = lower.substring(5);
            int rank = core.getLeaderboardManager().getRank(type, player.getUniqueId());
            return rank > 0 ? "#" + rank : "-";
        }

        // ─── Player-specific placeholders ───
        if (player == null) return "";
        PlayerProfile profile = core.getProfileManager().getProfile(player.getUniqueId());
        if (profile == null) return "";

        return switch (lower) {
            case "kills" -> String.valueOf(profile.getKills());
            case "deaths" -> String.valueOf(profile.getDeaths());
            case "kdr" -> String.format("%.2f", profile.getKDR());
            case "level" -> String.valueOf(profile.getLevel());
            case "prestige" -> String.valueOf(profile.getPrestige());
            case "coins" -> String.format("%.2f", profile.getCoins());
            case "xp" -> String.valueOf(profile.getXP());
            case "xp_needed" -> {
                long needed = getXPForNextLevel(profile.getLevel()) - profile.getXP();
                yield String.valueOf(Math.max(0, needed));
            }
            case "level_progress" -> {
                long totalForNext = getXPForNextLevel(profile.getLevel());
                long totalForCurrent = profile.getLevel() > 1 ? getXPForNextLevel(profile.getLevel() - 1) : 0;
                long range = totalForNext - totalForCurrent;
                long progress = profile.getXP() - totalForCurrent;
                double pct = range > 0 ? Math.min(1.0, (double) progress / range) : 1.0;
                int filled = (int) (pct * 10);
                yield "█".repeat(filled) + "░".repeat(10 - filled) + " " + (int)(pct * 100) + "%";
            }
            case "playtime" -> String.valueOf(profile.getPlayTime() / 1000);
            case "playtime_formatted" -> core.getConfigManager().formatTime(profile.getPlayTime());
            case "name" -> profile.getName();
            default -> null;
        };
    }

    /**
     * Handle top_<type>_<n>_name and top_<type>_<n>_value
     */
    private String handleTopPlaceholder(String remainder) {
        // remainder: "kills_1_name" or "coins_3_value"
        for (String type : LeaderboardManager.VALID_TYPES) {
            if (remainder.startsWith(type + "_")) {
                String rest = remainder.substring(type.length() + 1); // "1_name" or "3_value"
                int underscoreIdx = rest.indexOf('_');
                if (underscoreIdx <= 0) return null;
                try {
                    int position = Integer.parseInt(rest.substring(0, underscoreIdx)) - 1;
                    String field = rest.substring(underscoreIdx + 1);
                    var entries = core.getLeaderboardManager().getTop(type);
                    if (position < 0 || position >= entries.size()) return "-";
                    var entry = entries.get(position);
                    return switch (field) {
                        case "name" -> entry.name();
                        case "value" -> entry.displayValue();
                        default -> null;
                    };
                } catch (NumberFormatException e) {
                    return null;
                }
            }
        }
        return null;
    }

    /** Total XP from level 1 to reach the given level (same formula as CoreAPIImpl). */
    private long getXPForNextLevel(int level) {
        long total = 0;
        for (int i = 1; i <= level; i++) {
            total += (long) (100.0 * i * (1.0 + i / 10.0));
        }
        return total;
    }
}
