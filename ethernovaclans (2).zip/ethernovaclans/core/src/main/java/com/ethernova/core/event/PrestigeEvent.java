package com.ethernova.core.event;

import java.util.UUID;

/** Fired when a player prestiges. */
public record PrestigeEvent(UUID playerUuid, String playerName, int oldPrestige, int newPrestige) {}
