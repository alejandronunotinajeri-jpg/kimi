package com.ethernova.core.gui;

import com.ethernova.core.EthernovaCore;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Kit Editor GUI — allows players to rearrange their PvP kit layout.
 * Replicates the original UltimateFFA kit editor.
 * Players can drag-and-drop items within the GUI to customize their hotbar layout.
 * The layout is saved per-player and applied when entering FFA/Duels.
 */
public class KitEditorGui extends CoreGui {

    /**
     * Default kit layout: 9 hotbar slots mapped to item types.
     * Players can rearrange these to their preference.
     */
    private static final Map<Integer, KitSlot> DEFAULT_KIT = Map.of(
            0, new KitSlot("sword", Material.DIAMOND_SWORD, "Espada"),
            1, new KitSlot("bow", Material.BOW, "Arco"),
            2, new KitSlot("gapple", Material.GOLDEN_APPLE, "Manzana Dorada"),
            3, new KitSlot("rod", Material.FISHING_ROD, "Caña de Pescar"),
            4, new KitSlot("potion_speed", Material.POTION, "Poción de Velocidad"),
            5, new KitSlot("potion_heal", Material.SPLASH_POTION, "Poción de Curación"),
            6, new KitSlot("ender_pearl", Material.ENDER_PEARL, "Perla de Ender"),
            7, new KitSlot("blocks", Material.COBBLESTONE, "Bloques"),
            8, new KitSlot("arrows", Material.ARROW, "Flechas")
    );

    public record KitSlot(String id, Material material, String name) {}

    private final Map<Integer, KitSlot> currentLayout;

    public KitEditorGui(EthernovaCore core, Player player) {
        super(core, player);
        this.currentLayout = loadLayout(player.getUniqueId());
    }

    public void open() {
        openInventory("<gradient:aqua:green>✎ Editor de Kit</gradient>", 45);
    }

    @Override
    protected void populateItems() {
        // Row 2 (slots 9-17): Informational header
        setItem(13, createItem(Material.BOOK, "<yellow>Instrucciones",
                List.of("<gray>Haz click en un slot de tu hotbar",
                        "<gray>y luego en otro para intercambiarlos.",
                        " ",
                        "<yellow>Tu kit personalizado se",
                        "<yellow>aplica en FFA y Duelos.")));

        // Row 2 (slots 10-16): Current hotbar layout — first 7 items
        for (int i = 0; i < 9; i++) {
            KitSlot slot = currentLayout.get(i);
            if (slot != null) {
                int guiSlot = i < 7 ? (10 + i) : (19 + (i - 7));
                setItem(guiSlot, createItem(slot.material, "<aqua>" + slot.name,
                        List.of("<gray>Slot " + (i + 1),
                                " ",
                                "<yellow>Click para seleccionar")));
                slotActions.put(guiSlot, "SELECT:" + i);
            }
        }

        // Row 4: Preset buttons
        setItem(29, createItem(Material.CHEST, "<gold>Kit Predeterminado",
                List.of("<gray>Restaurar el kit original")));
        slotActions.put(29, "RESET");

        setItem(31, createItem(Material.NETHER_STAR, "<green>Guardar Kit",
                List.of("<gray>Guardar tu diseño actual")));
        slotActions.put(31, "SAVE");

        setItem(33, createItem(Material.ARROW, "<yellow>← Menú Principal"));
        slotActions.put(33, "BACK");

        // Bottom: Close
        setItem(40, createItem(Material.BARRIER, "<red>Cerrar"));
        slotActions.put(40, "CLOSE");
    }

    private int selectedSlot = -1;

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.startsWith("SELECT:")) {
            int kitSlot = Integer.parseInt(action.substring(7));
            if (selectedSlot == -1) {
                selectedSlot = kitSlot;
                player.sendMessage(mini.deserialize(
                        "<yellow>Slot " + (kitSlot + 1) + " seleccionado. Click en otro slot para intercambiar."));
                playSound("click");
            } else {
                // Swap the two slots
                KitSlot a = currentLayout.get(selectedSlot);
                KitSlot b = currentLayout.get(kitSlot);
                if (a != null) currentLayout.put(kitSlot, a);
                if (b != null) currentLayout.put(selectedSlot, b);
                selectedSlot = -1;
                player.sendMessage(mini.deserialize("<green>✔ Slots intercambiados."));
                player.playSound(player.getLocation(), Sound.ENTITY_ITEM_PICKUP, 0.5f, 1.5f);
                // Refresh
                open();
            }
            return true;
        }

        switch (action) {
            case "RESET" -> {
                currentLayout.clear();
                currentLayout.putAll(DEFAULT_KIT);
                player.sendMessage(mini.deserialize("<yellow>Kit restaurado al predeterminado."));
                playSound("click");
                open();
            }
            case "SAVE" -> {
                saveLayout(player.getUniqueId(), currentLayout);
                player.sendMessage(mini.deserialize("<green>✔ Kit guardado exitosamente."));
                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.5f, 1.5f);
            }
            case "BACK" -> {
                playSound("click");
                player.closeInventory();
            }
        }
        return true;
    }

    /**
     * Load a player's custom kit layout from profile data.
     */
    private Map<Integer, KitSlot> loadLayout(UUID uuid) {
        Map<Integer, KitSlot> layout = new HashMap<>(DEFAULT_KIT);
        var profile = core.getProfileManager().getProfile(uuid);
        if (profile == null) return layout;

        String data = profile.getCustom("kit_layout");
        if (data == null || data.isEmpty()) return layout;

        try {
            // Format: "0:sword,1:bow,2:gapple,..."
            for (String entry : data.split(",")) {
                String[] parts = entry.split(":");
                int slotIdx = Integer.parseInt(parts[0]);
                String slotId = parts[1];
                // Find the KitSlot with this id from defaults
                for (KitSlot ks : DEFAULT_KIT.values()) {
                    if (ks.id.equals(slotId)) {
                        layout.put(slotIdx, ks);
                        break;
                    }
                }
            }
        } catch (Exception e) {
            core.getLogger().fine("Error parsing kit layout for " + uuid + ": " + e.getMessage());
        }
        return layout;
    }

    /**
     * Save a player's custom kit layout to profile data.
     */
    private void saveLayout(UUID uuid, Map<Integer, KitSlot> layout) {
        StringBuilder sb = new StringBuilder();
        for (var entry : layout.entrySet()) {
            if (!sb.isEmpty()) sb.append(",");
            sb.append(entry.getKey()).append(":").append(entry.getValue().id);
        }
        core.getProfileManager().setData(uuid, "kit_layout", sb.toString());
    }

    /**
     * Get a player's saved kit layout.
     * Used by FFA/Duels modules to apply the custom layout.
     */
    public static Map<Integer, KitSlot> getPlayerLayout(EthernovaCore core, UUID uuid) {
        Map<Integer, KitSlot> layout = new HashMap<>(DEFAULT_KIT);
        var profile = core.getProfileManager().getProfile(uuid);
        if (profile == null) return layout;

        String data = profile.getCustom("kit_layout");
        if (data == null || data.isEmpty()) return layout;

        try {
            for (String entry : data.split(",")) {
                String[] parts = entry.split(":");
                int slotIdx = Integer.parseInt(parts[0]);
                String slotId = parts[1];
                for (KitSlot ks : DEFAULT_KIT.values()) {
                    if (ks.id.equals(slotId)) {
                        layout.put(slotIdx, ks);
                        break;
                    }
                }
            }
        } catch (Exception e) {
            core.getLogger().fine("Error parsing kit layout for " + uuid + ": " + e.getMessage());
        }
        return layout;
    }
}
