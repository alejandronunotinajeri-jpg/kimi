package com.ethernova.core.gui;

import com.ethernova.core.EthernovaCore;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

/**
 * Player Settings GUI — 20 toggles organized into 4 visual categories.
 * <p>
 * Uses the actual Material icon (as in the original UltimateFFA) with enchant glow for
 * enabled items. Time is a 3-state cycle (Day / Night / Server) matching the original.
 * <p>
 * Settings are consumed by other subsystems via the O(1) {@link #getSetting} static utility.
 *
 * <h3>Categories</h3>
 * <ul>
 *   <li><b>General:</b> scoreboard, allowRequests, allowSpectators, time, lobbyVisibility, killSounds</li>
 *   <li><b>Visual:</b> hideOthersAuras, hideOthersEffects, hideOthersTrails, hideOthersPets, reducedParticles, bloodEffects</li>
 *   <li><b>Chat:</b> hideKillChat, hideBountyAlerts, hideOthersMessages, hideLevelUpMessages</li>
 *   <li><b>Gameplay:</b> actionBarStats, damageIndicators, autoPickup, showLevel</li>
 * </ul>
 */
public class PlayerSettingsGui extends CoreGui {

    // ─────────────────────── Setting Definition ───────────────────────

    /**
     * Describes a single boolean setting. Immutable.
     * @param requiredPlugin if non-null, this setting is only shown when the given plugin is registered.
     */
    private record SettingDef(String key, String name, String description,
                              Material icon, boolean defaultValue, Category category,
                              String requiredPlugin) {
        /** Convenience constructor for settings that are always visible (no plugin dependency). */
        SettingDef(String key, String name, String description, Material icon, boolean defaultValue, Category category) {
            this(key, name, description, icon, defaultValue, category, null);
        }
    }

    private enum Category {
        GENERAL   ("<yellow>⚙ General",            Material.COMPARATOR,          "<gray>Ajustes generales del juego"),
        VISUAL    ("<light_purple>✦ Visual",        Material.SPYGLASS,            "<gray>Efectos visuales de otros jugadores"),
        CHAT      ("<aqua>✉ Chat",                  Material.OAK_SIGN,            "<gray>Mensajes y notificaciones"),
        GAMEPLAY  ("<green>⚔ Gameplay",             Material.DIAMOND_SWORD,       "<gray>Mecánicas de juego");

        final String displayName;
        final Material icon;
        final String subtitle;

        Category(String displayName, Material icon, String subtitle) {
            this.displayName = displayName;
            this.icon = icon;
            this.subtitle = subtitle;
        }
    }

    /** All settings in display order. */
    private static final SettingDef[] SETTINGS;

    /** O(1) lookup: key → index into SETTINGS. */
    private static final Map<String, Integer> KEY_INDEX;

    static {
        SETTINGS = new SettingDef[]{
            // ── General (row 2) ──
            new SettingDef("scoreboard",       "Scoreboard",              "Muestra u oculta la tabla lateral",           Material.PAINTING,       true,  Category.GENERAL),
            new SettingDef("allowRequests",     "Solicitudes de Duelo",    "Permite que otros te desafíen a duelos",       Material.WRITABLE_BOOK,  true,  Category.GENERAL, "EthernovaDuels"),
            new SettingDef("allowSpectators",   "Permitir Espectadores",   "Permite que otros vean tus duelos",            Material.ENDER_EYE,      true,  Category.GENERAL, "EthernovaDuels"),
            new SettingDef("lobbyVisibility",   "Visibilidad en Lobby",    "Ver a otros jugadores en el lobby",            Material.GLASS,          true,  Category.GENERAL),
            new SettingDef("killSounds",        "Sonidos de Kill",         "Escuchar sonidos al eliminar jugadores",       Material.NOTE_BLOCK,     true,  Category.GENERAL, "EthernovaCombat"),

            // ── Visual (row 3) ──
            new SettingDef("hideOthersAuras",   "Ocultar Auras",           "Oculta las auras de otros jugadores",         Material.BLAZE_POWDER,   false, Category.VISUAL, "EthernovaCosmetics"),
            new SettingDef("hideOthersEffects", "Ocultar Efectos de Kill", "Oculta efectos de kill de otros",             Material.GOLDEN_SWORD,   false, Category.VISUAL, "EthernovaCosmetics"),
            new SettingDef("hideOthersTrails",  "Ocultar Trails",          "Oculta los trails de proyectiles ajenos",     Material.ARROW,          false, Category.VISUAL, "EthernovaCosmetics"),
            new SettingDef("hideOthersPets",    "Ocultar Mascotas",        "Oculta las mascotas de otros jugadores",      Material.LEAD,           false, Category.VISUAL, "EthernovaCosmetics"),
            new SettingDef("reducedParticles",  "Partículas Reducidas",    "Reduce la cantidad de partículas mostradas",  Material.REDSTONE,       false, Category.VISUAL),
            new SettingDef("bloodEffects",      "Efectos de Sangre",       "Partículas de sangre al hacer daño",          Material.RED_DYE,        true,  Category.VISUAL, "EthernovaCombat"),

            // ── Chat (row 4) ──
            new SettingDef("hideKillChat",       "Ocultar Chat de Kills",   "Oculta mensajes de kills en el chat global",  Material.IRON_SWORD,    false, Category.CHAT, "EthernovaFFA"),
            new SettingDef("hideBountyAlerts",    "Ocultar Alertas Bounty",  "Oculta las alertas de recompensas",           Material.GOLD_INGOT,    false, Category.CHAT, "EthernovaFFA"),
            new SettingDef("hideOthersMessages",  "Ocultar Mensajes Muerte","Oculta mensajes de muerte personalizados",   Material.PAPER,          false, Category.CHAT, "EthernovaFFA"),
            new SettingDef("hideLevelUpMessages", "Ocultar Level Up",       "Oculta mensajes de subida de nivel ajenos",   Material.EXPERIENCE_BOTTLE, false, Category.CHAT, "EthernovaProgression"),

            // ── Gameplay (row 5) ──
            new SettingDef("actionBarStats",    "ActionBar Stats",         "Muestra vida, monedas y streak en la barra",  Material.NAME_TAG,       true,  Category.GAMEPLAY, "EthernovaFFA"),
            new SettingDef("damageIndicators",   "Indicadores de Daño",    "Números flotantes de daño al golpear",        Material.GOLDEN_AXE,     true,  Category.GAMEPLAY, "EthernovaCombat"),
            new SettingDef("autoPickup",         "Auto Recoger",           "Recoger drops automáticamente al kill",       Material.HOPPER,         true,  Category.GAMEPLAY, "EthernovaFFA"),
            new SettingDef("showLevel",          "Mostrar Nivel",          "Tu nivel visible sobre tu cabeza",            Material.ANVIL,          true,  Category.GAMEPLAY),
            new SettingDef("guiAnimations",      "Animaciones GUI",        "Efectos premium al abrir menús y páginas",    Material.FIREWORK_ROCKET, true,  Category.GAMEPLAY),
        };

        KEY_INDEX = new HashMap<>(SETTINGS.length * 2);
        for (int i = 0; i < SETTINGS.length; i++) {
            KEY_INDEX.put(SETTINGS[i].key(), i);
        }
    }

    // ─────────────────────── Time 3-state ───────────────────────

    /** Time states matching original: Day (6000), Night (18000), Server (-1). */
    private static final long[] TIME_STATES = {6000L, 18000L, -1L};
    private static final String[] TIME_NAMES = {"☀ Día", "\uD83C\uDF19 Noche", "\uD83C\uDF0E Servidor"};
    private static final String[] TIME_COLORS = {"<yellow>", "<dark_purple>", "<aqua>"};

    // ─────────────────────── Layout ───────────────────────

    /** Slot positions per category (shifted right so label at row start). */
    private static final int[][] CATEGORY_SLOTS = {
        {11, 12, 13, 14, 15},           // General (5 items) — row 2
        {20, 21, 22, 23, 24, 25},       // Visual (6 items) — row 3
        {29, 30, 31, 32},               // Chat (4 items) — row 4
        {38, 39, 40, 41, 42},           // Gameplay (5 items) — row 5
    };

    /** Slot for the category label (first content slot of each row). */
    private static final int[] CATEGORY_LABEL_SLOTS = {10, 19, 28, 37};

    /**
     * Concrete block colors per category for visual distinction.
     */
    private static final Material[] CATEGORY_GLASS = {
        Material.YELLOW_CONCRETE,
        Material.MAGENTA_CONCRETE,
        Material.CYAN_CONCRETE,
        Material.LIME_CONCRETE
    };

    // ─────────────────────── Constructor & Open ───────────────────────

    public PlayerSettingsGui(EthernovaCore core, Player player) {
        super(core, player);
    }

    public void open() {
        openInventory("<dark_gray>⚙ Ajustes Personales", 54);
    }

    // ─────────────────────── Items ───────────────────────

    @Override
    protected void populateItems() {
        UUID uuid = player.getUniqueId();
        var pm = core.getProfileManager();

        // ── Header item (center of top row) ──
        setItem(4, createItem(Material.REDSTONE_TORCH, "<gradient:#ff6b6b:#ffd93d><bold>⚙ Configuración",
                List.of("",
                        "<gray>Personaliza tu experiencia",
                        "<gray>en <gradient:#00d4ff:#00ff88>Ethernova</gradient><gray>.", "",
                        "<dark_gray>▸ <white>Click en cada icono para cambiar",
                        "<dark_gray>▸ <white>Las opciones se guardan al instante")));

        // ── Category labels + settings (skip settings whose plugin is not loaded) ──
        Set<String> registered = core.getRegisteredPlugins();
        int settingIdx = 0;
        for (Category cat : Category.values()) {
            int[] slots = CATEGORY_SLOTS[cat.ordinal()];
            int slotIdx = 0;

            // First pass: determine visible settings for this category
            int visibleCount = 0;
            int peekIdx = settingIdx;
            while (peekIdx < SETTINGS.length && SETTINGS[peekIdx].category() == cat) {
                SettingDef def = SETTINGS[peekIdx++];
                if (def.requiredPlugin() == null || registered.contains(def.requiredPlugin())) {
                    visibleCount++;
                }
            }

            // Skip entire category if no visible settings
            if (visibleCount == 0) {
                settingIdx = peekIdx;
                continue;
            }

            int labelSlot = CATEGORY_LABEL_SLOTS[cat.ordinal()];
            setItem(labelSlot, createItem(CATEGORY_GLASS[cat.ordinal()], cat.displayName,
                    List.of(cat.subtitle)));

            while (settingIdx < SETTINGS.length && SETTINGS[settingIdx].category() == cat) {
                SettingDef def = SETTINGS[settingIdx];
                settingIdx++;

                // Filter out settings from uninstalled plugins
                if (def.requiredPlugin() != null && !registered.contains(def.requiredPlugin())) {
                    continue;
                }

                if (slotIdx >= slots.length) break;
                int slot = slots[slotIdx++];

                boolean value = pm.getDataBoolean(uuid, "setting." + def.key(), def.defaultValue());
                setItem(slot, createToggleItem(def, value));
                slotActions.put(slot, "TOGGLE:" + (settingIdx - 1));
            }
        }

        // ── Time button (special 3-state) ──
        long currentTime = getPlayerTimeState(uuid, pm);
        int timeIdx = getTimeIndex(currentTime);
        setItem(16, createTimeItem(timeIdx));
        slotActions.put(16, "TIME");

        // ── Bottom bar actions ──
        setItem(45, createItem(Material.ARROW, "<red>← Volver",
                List.of("<gray>Regresa al menú principal")));
        slotActions.put(45, "BACK");

        setItem(49, createItem(Material.KNOWLEDGE_BOOK, "<aqua>ℹ Información",
                List.of("<gray>Estas opciones afectan solo",
                        "<gray>tu experiencia personal.", "",
                        "<gray>Todos los cambios se guardan",
                        "<gray>automáticamente.")));

        setItem(53, createItem(Material.BARRIER, "<red><bold>⚠ Reset",
                List.of("<gray>Restaura TODOS los ajustes", "<gray>a su valor predeterminado.", "",
                        "<red>» <white>No se puede deshacer")));
        slotActions.put(53, "RESET");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        UUID uuid = player.getUniqueId();
        var pm = core.getProfileManager();

        //  ── Toggle boolean ──
        if (action.startsWith("TOGGLE:")) {
            int idx = Integer.parseInt(action.substring(7));
            SettingDef def = SETTINGS[idx];

            boolean current = pm.getDataBoolean(uuid, "setting." + def.key(), def.defaultValue());
            boolean newVal = !current;
            pm.setData(uuid, "setting." + def.key(), String.valueOf(newVal));

            // Immediate sound feedback
            if (newVal == def.defaultValue()) {
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.0f);
            } else {
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 0.7f);
            }

            // ── Immediate effect application ──
            applySettingImmediately(def.key(), newVal);

            // Status message
            String tag = newVal ? "<green>✔ " : "<red>✘ ";
            String state = newVal ? "<green>activado" : "<red>desactivado";
            player.sendMessage(mini.deserialize(tag + "<white>" + def.name() + " " + state));

            open(); // Refresh
            return true;
        }

        // ── Time 3-state cycle ──
        if ("TIME".equals(action)) {
            long current = getPlayerTimeState(uuid, pm);
            int idx = (getTimeIndex(current) + 1) % TIME_STATES.length;
            long newTime = TIME_STATES[idx];

            pm.setData(uuid, "setting.time", String.valueOf(newTime));

            // Apply immediately
            if (newTime == -1L) {
                player.resetPlayerTime();
            } else {
                player.setPlayerTime(newTime, false);
            }

            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 0.7f, 1.2f);
            player.sendMessage(mini.deserialize(
                    TIME_COLORS[idx] + "⏰ Tiempo personal: <white>" + TIME_NAMES[idx]));

            open();
            return true;
        }

        // ── Back ──
        if ("BACK".equals(action)) {
            playSound("click");
            player.closeInventory();
            return true;
        }

        // ── Reset all ──
        if ("RESET".equals(action)) {
            for (SettingDef def : SETTINGS) {
                pm.setData(uuid, "setting." + def.key(), String.valueOf(def.defaultValue()));
            }
            pm.setData(uuid, "setting.time", String.valueOf(-1L));
            player.resetPlayerTime();

            // Reapply lobby visibility default
            for (Player other : Bukkit.getOnlinePlayers()) {
                if (!other.equals(player)) player.showPlayer(core, other);
            }

            player.sendMessage(mini.deserialize("<green>✔ <white>Todas las configuraciones han sido restablecidas."));
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.5f, 1.5f);
            open();
            return true;
        }

        return true;
    }

    // ─────────────────────── Item Builders ───────────────────────

    /**
     * Create a toggle item using the actual setting icon (not dye).
     * Enabled items get enchant glow.
     */
    private ItemStack createToggleItem(SettingDef def, boolean enabled) {
        ItemStack item = new ItemStack(def.icon());
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        String color = enabled ? "<green>" : "<red>";
        String indicator = enabled ? " <green>✔" : " <red>✘";
        meta.displayName(mini.deserialize(color + def.name() + indicator));

        List<String> lore = new ArrayList<>();
        lore.add("");
        lore.add("<gray>" + def.description());
        lore.add("");
        if (enabled) {
            lore.add("<green>▎ <white>Activado");
        } else {
            lore.add("<red>▎ <white>Desactivado");
        }
        lore.add("");
        lore.add("<dark_gray>» <yellow>Click para " + (enabled ? "<red>desactivar" : "<green>activar"));
        meta.lore(lore.stream().map(mini::deserialize).toList());

        if (enabled) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }

        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        item.setItemMeta(meta);
        return item;
    }

    /**
     * Create the time cycle item showing current state.
     */
    private ItemStack createTimeItem(int timeIdx) {
        ItemStack item = new ItemStack(Material.CLOCK);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.displayName(mini.deserialize("<gold>Tiempo Personal"));

        List<String> lore = new ArrayList<>();
        lore.add("<dark_gray>─────────────────");
        lore.add("<gray>Cambia la hora del mundo para ti.");
        lore.add("");
        for (int i = 0; i < TIME_NAMES.length; i++) {
            String prefix = (i == timeIdx) ? "<white>» " + TIME_COLORS[i] + "<bold>" : "<dark_gray>  ";
            lore.add(prefix + TIME_NAMES[i]);
        }
        lore.add("");
        lore.add("<yellow>Click para cambiar");
        meta.lore(lore.stream().map(mini::deserialize).toList());

        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        item.setItemMeta(meta);
        return item;
    }

    // ─────────────────────── Immediate Effects ───────────────────────

    private void applySettingImmediately(String key, boolean value) {
        switch (key) {
            case "scoreboard" -> {
                if (!value) {
                    // Remove scoreboard immediately; re-enable happens on next tick
                    player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
                }
            }
            case "lobbyVisibility" -> {
                for (Player other : Bukkit.getOnlinePlayers()) {
                    if (other.equals(player)) continue;
                    if (value) player.showPlayer(core, other);
                    else player.hidePlayer(core, other);
                }
            }
            case "showLevel" -> {
                // Level visibility will be checked next scoreboard tick
            }
            default -> { /* Other settings are checked by their respective systems each tick */ }
        }
    }

    // ─────────────────────── Time Helpers ───────────────────────

    private long getPlayerTimeState(UUID uuid, com.ethernova.core.profile.PlayerProfileManager pm) {
        String raw = pm.getData(uuid, "setting.time");
        if (raw == null) return -1L;
        try {
            return Long.parseLong(raw);
        } catch (NumberFormatException e) {
            return -1L;
        }
    }

    private int getTimeIndex(long time) {
        for (int i = 0; i < TIME_STATES.length; i++) {
            if (TIME_STATES[i] == time) return i;
        }
        return TIME_STATES.length - 1; // Default: Server
    }

    // ─────────────────────── Static API ───────────────────────

    /**
     * O(1) check whether a player has a boolean setting enabled.
     * Thread-safe. Usable from any module with a core reference.
     */
    public static boolean getSetting(EthernovaCore core, UUID uuid, String settingKey) {
        Integer idx = KEY_INDEX.get(settingKey);
        boolean defaultVal = idx != null ? SETTINGS[idx].defaultValue() : true;
        return core.getProfileManager().getDataBoolean(uuid, "setting." + settingKey, defaultVal);
    }

    /**
     * Get the player's personal time value (-1 = server, 6000 = day, 18000 = night).
     */
    public static long getTimeSetting(EthernovaCore core, UUID uuid) {
        String raw = core.getProfileManager().getData(uuid, "setting.time");
        if (raw == null) return -1L;
        try { return Long.parseLong(raw); }
        catch (NumberFormatException e) { return -1L; }
    }

    /**
     * Get all setting keys and their defaults. Useful for bulk operations.
     */
    public static Map<String, Boolean> getAllDefaults() {
        Map<String, Boolean> map = new LinkedHashMap<>(SETTINGS.length);
        for (SettingDef def : SETTINGS) map.put(def.key(), def.defaultValue());
        return Collections.unmodifiableMap(map);
    }
}
