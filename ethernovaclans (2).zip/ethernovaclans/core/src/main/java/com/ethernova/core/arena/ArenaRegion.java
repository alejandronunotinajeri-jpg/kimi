package com.ethernova.core.arena;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;

/**
 * Immutable cuboid region defined by two corners in the same world.
 * Used for arena rollback tracking.
 */
public record ArenaRegion(World world, int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {

    /**
     * Create from two arbitrary corner locations. Automatically normalizes min/max.
     */
    public static ArenaRegion fromCorners(Location pos1, Location pos2) {
        if (pos1.getWorld() == null || pos2.getWorld() == null) {
            throw new IllegalArgumentException("Both locations must have a non-null world");
        }
        if (!pos1.getWorld().equals(pos2.getWorld())) {
            throw new IllegalArgumentException("Both locations must be in the same world");
        }
        return new ArenaRegion(
                pos1.getWorld(),
                Math.min(pos1.getBlockX(), pos2.getBlockX()),
                Math.min(pos1.getBlockY(), pos2.getBlockY()),
                Math.min(pos1.getBlockZ(), pos2.getBlockZ()),
                Math.max(pos1.getBlockX(), pos2.getBlockX()),
                Math.max(pos1.getBlockY(), pos2.getBlockY()),
                Math.max(pos1.getBlockZ(), pos2.getBlockZ())
        );
    }

    /**
     * Whether the given block is inside this region.
     */
    public boolean contains(Block block) {
        if (!block.getWorld().equals(world)) return false;
        int x = block.getX(), y = block.getY(), z = block.getZ();
        return x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ;
    }

    /**
     * Whether the given location is inside this region.
     */
    public boolean contains(Location loc) {
        if (loc.getWorld() == null || !loc.getWorld().equals(world)) return false;
        int x = loc.getBlockX(), y = loc.getBlockY(), z = loc.getBlockZ();
        return x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ;
    }

    /**
     * Total block count in this region.
     */
    public long volume() {
        return (long) (maxX - minX + 1) * (maxY - minY + 1) * (maxZ - minZ + 1);
    }
}
