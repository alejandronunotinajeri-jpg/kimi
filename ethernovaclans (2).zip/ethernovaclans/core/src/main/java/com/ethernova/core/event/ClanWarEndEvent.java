package com.ethernova.core.event;

import java.util.UUID;

/**
 * Published on the EthernovaEventBus when a clan war ends.
 */
public record ClanWarEndEvent(
        UUID winnerClanId,
        UUID loserClanId,
        String reason
) {}
