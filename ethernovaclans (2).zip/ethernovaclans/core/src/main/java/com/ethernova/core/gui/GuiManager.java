package com.ethernova.core.gui;

import com.ethernova.core.EthernovaCore;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/**
 * Manages GUI click routing and chat-based input capture.
 * Register once in EthernovaCore.
 */
public class GuiManager implements Listener {

    private final EthernovaCore core;
    private final Map<UUID, CoreGui> openGuis = new ConcurrentHashMap<>();
    private final Map<UUID, ChatInput> chatInputs = new ConcurrentHashMap<>();

    public GuiManager(EthernovaCore core) {
        this.core = core;
    }

    /** Register a GUI as open for a player. */
    public void registerGui(Player player, CoreGui gui) {
        openGuis.put(player.getUniqueId(), gui);
    }

    /** Remove GUI tracking for a player. */
    public void unregisterGui(UUID uuid) {
        openGuis.remove(uuid);
    }

    /**
     * Capture the player's next chat message as input.
     * Closes inventory if open, sends prompt, sets timeout.
     *
     * @param player   The player
     * @param prompt   MiniMessage prompt to display
     * @param timeoutTicks Ticks before timeout (0 = no timeout)
     * @param callback Consumer receiving the input string (or null on timeout/cancel)
     */
    public void requestChatInput(Player player, String prompt, int timeoutTicks, Consumer<String> callback) {
        UUID uuid = player.getUniqueId();
        // Cancel existing input request if any
        ChatInput existing = chatInputs.remove(uuid);
        if (existing != null && existing.timeoutTask != null) existing.timeoutTask.cancel();

        player.closeInventory();
        player.sendMessage(MiniMessage.miniMessage().deserialize(prompt));
        player.sendMessage(MiniMessage.miniMessage().deserialize("<gray>Escribe <yellow>cancelar</yellow> para cancelar."));

        ChatInput input = new ChatInput(callback, null);
        if (timeoutTicks > 0) {
            BukkitTask task = Bukkit.getScheduler().runTaskLater(core, () -> {
                ChatInput ci = chatInputs.remove(uuid);
                if (ci != null) {
                    player.sendMessage(MiniMessage.miniMessage().deserialize("<red>Tiempo agotado."));
                    ci.callback.accept(null);
                }
            }, timeoutTicks);
            input = new ChatInput(callback, task);
        }
        chatInputs.put(uuid, input);
    }

    // --- Listeners ---

    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        CoreGui gui = openGuis.get(player.getUniqueId());
        if (gui != null) {
            gui.handleClick(event);
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (event.getPlayer() instanceof Player player) {
            CoreGui gui = openGuis.get(player.getUniqueId());
            if (gui != null) {
                // Only remove if the closed inventory matches the registered GUI's inventory.
                // When transitioning between GUIs (A -> B), B is registered before A's close fires.
                // We must NOT remove B when A's InventoryCloseEvent fires.
                if (gui.inventory == event.getInventory()) {
                    openGuis.remove(player.getUniqueId());
                    gui.stopAnimation();
                }
            }
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncPlayerChatEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        ChatInput input = chatInputs.remove(uuid);
        if (input == null) return;

        event.setCancelled(true);
        if (input.timeoutTask != null) input.timeoutTask.cancel();

        String message = event.getMessage().trim();
        if ("cancelar".equalsIgnoreCase(message) || "cancel".equalsIgnoreCase(message)) {
            Bukkit.getScheduler().runTask(core, () -> {
                event.getPlayer().sendMessage(MiniMessage.miniMessage().deserialize("<red>Cancelado."));
                input.callback.accept(null);
            });
        } else {
            Bukkit.getScheduler().runTask(core, () -> input.callback.accept(message));
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        openGuis.remove(uuid);
        ChatInput input = chatInputs.remove(uuid);
        if (input != null && input.timeoutTask != null) input.timeoutTask.cancel();
    }

    private record ChatInput(Consumer<String> callback, BukkitTask timeoutTask) {}
}
