package com.ethernova.core.scoreboard;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.profile.PlayerProfile;
import com.ethernova.core.state.PlayerStateManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.*;

import com.ethernova.core.gui.PlayerSettingsGui;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Lightweight state-based scoreboard system.
 * <p>
 * Disabled by default ({@code scoreboard.enabled: false}).
 * When enabled, shows a different sidebar scoreboard per player-state (lobby, ffa, duel, etc.)
 * with optional per-arena overrides. Lines support MiniMessage + PlaceholderAPI.
 * <p>
 * Designed to coexist with external scoreboard plugins — if disabled, does nothing.
 */
public class EthernovaScoreboardManager {

    private final EthernovaCore plugin;
    private final MiniMessage mini = MiniMessage.miniMessage();
    private final Map<UUID, Scoreboard> playerBoards = new ConcurrentHashMap<>();
    private BukkitTask updateTask;
    private boolean enabled;
    private boolean hasPapi;
    private boolean tabListEnabled;
    private boolean healthBelowName;
    private String tabListFormat;

    // Cached board definitions loaded from config
    private final Map<String, BoardConfig> boards = new HashMap<>();
    private int updateInterval;
    private int teamMirrorCounter = 0;

    public EthernovaScoreboardManager(EthernovaCore plugin) {
        this.plugin = plugin;
        this.hasPapi = Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null;
        reload();
    }

    /**
     * (Re)load all board definitions from config.
     */
    public void reload() {
        enabled = plugin.getConfig().getBoolean("scoreboard.enabled", false);
        updateInterval = plugin.getConfig().getInt("scoreboard.update-interval", 20);
        tabListEnabled = plugin.getConfig().getBoolean("scoreboard.tab-list.enabled", true);
        tabListFormat = plugin.getConfig().getString("scoreboard.tab-list.format", "<gray>[<aqua>Lv{level}</aqua>] {rank_prefix}{player}");
        healthBelowName = plugin.getConfig().getBoolean("scoreboard.health-below-name", true);
        boards.clear();

        var boardsSection = plugin.getConfig().getConfigurationSection("scoreboard.boards");
        if (boardsSection == null) return;

        for (String stateKey : boardsSection.getKeys(false)) {
            var section = boardsSection.getConfigurationSection(stateKey);
            if (section == null) continue;

            String title = section.getString("title", "<gold><bold>ETHERNOVA");
            List<String> lines = section.getStringList("lines");
            BoardConfig config = new BoardConfig(title, lines);

            // Per-arena overrides
            var perArenaSection = section.getConfigurationSection("per-arena");
            if (perArenaSection != null) {
                for (String arena : perArenaSection.getKeys(false)) {
                    var arenaSection = perArenaSection.getConfigurationSection(arena);
                    if (arenaSection != null) {
                        String arenaTitle = arenaSection.getString("title", title);
                        List<String> arenaLines = arenaSection.getStringList("lines");
                        if (!arenaLines.isEmpty()) {
                            config.arenaOverrides.put(arena.toLowerCase(), new BoardConfig(arenaTitle, arenaLines));
                        }
                    }
                }
            }

            boards.put(stateKey.toLowerCase(), config);
        }
    }

    /**
     * Start the periodic update task.
     */
    public void start() {
        if (!enabled) return;
        if (updateTask != null) updateTask.cancel();
        updateTask = Bukkit.getScheduler().runTaskTimer(plugin, this::updateAll, 20L, updateInterval);
    }

    /**
     * Stop the update task and restore all players to the main scoreboard.
     */
    public void stop() {
        if (updateTask != null) {
            updateTask.cancel();
            updateTask = null;
        }
        restoreAll();
    }

    private void updateAll() {
        if (!enabled) return;
        PlayerStateManager stateManager = plugin.getStateManager();
        teamMirrorCounter++;

        for (Player player : Bukkit.getOnlinePlayers()) {
            UUID uuid = player.getUniqueId();

            // Skip players who disabled their scoreboard
            if (!PlayerSettingsGui.getSetting(plugin, uuid, "scoreboard")) {
                removeBoard(player);
                continue;
            }

            String state = stateManager.getState(uuid);
            String map = stateManager.getMap(uuid);

            BoardConfig config = findBoard(state, map);
            if (config == null) {
                removeBoard(player);
                continue;
            }

            Scoreboard board = playerBoards.get(uuid);
            if (board == null) {
                board = Bukkit.getScoreboardManager().getNewScoreboard();
                mirrorTeams(board);
                playerBoards.put(uuid, board);
                player.setScoreboard(board);
            } else if (teamMirrorCounter % 5 == 0) {
                // Re-mirror teams every 5 cycles to pick up nametag changes
                mirrorTeams(board);
            }

            updateBoard(player, board, config);

            // Health below name
            if (healthBelowName) {
                updateHealthObjective(board);
            }

            // Tab list playerListName format
            if (tabListEnabled) {
                updateTabListName(player);
            }
        }
    }

    /**
     * Find the appropriate board config for a state + map.
     */
    private BoardConfig findBoard(String state, String map) {
        BoardConfig config = boards.get(state);
        if (config == null) return null;

        if (map != null && !map.isEmpty()) {
            BoardConfig override = config.arenaOverrides.get(map.toLowerCase());
            if (override != null) return override;
        }
        return config;
    }

    /**
     * Update the sidebar scoreboard for a single player.
     */
    private void updateBoard(Player player, Scoreboard board, BoardConfig config) {
        String objName = "ethernova_sb";
        Objective obj = board.getObjective(objName);
        if (obj != null) obj.unregister();

        Component title = mini.deserialize(parsePlaceholders(player, config.title));
        obj = board.registerNewObjective(objName, Criteria.DUMMY, title, RenderType.INTEGER);
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);

        List<String> lines = config.lines;
        int score = lines.size();

        for (String line : lines) {
            String resolved = parsePlaceholders(player, line);
            if (resolved.isEmpty() || resolved.isBlank()) {
                resolved = " ".repeat(score);
            }

            Component lineComp = mini.deserialize(resolved);
            String teamName = "ln_" + score;
            Team team = board.getTeam(teamName);
            if (team == null) {
                team = board.registerNewTeam(teamName);
            }
            String entry = "§" + intToChar(score);
            team.addEntry(entry);
            team.prefix(lineComp);
            team.suffix(Component.empty());
            obj.getScore(entry).setScore(score);
            score--;
        }
    }

    /**
     * Mirror nametag teams from main scoreboard to a per-player scoreboard.
     * This keeps clan tags and other team-based nametags visible.
     */
    private void mirrorTeams(Scoreboard target) {
        Scoreboard main = Bukkit.getScoreboardManager().getMainScoreboard();
        for (Team mainTeam : main.getTeams()) {
            // Only mirror ethernova-related teams (ec_ prefix) and others
            Team newTeam = target.getTeam(mainTeam.getName());
            if (newTeam == null) {
                // Don't create teams that start with "ln_" (our sidebar teams)
                if (mainTeam.getName().startsWith("ln_")) continue;
                newTeam = target.registerNewTeam(mainTeam.getName());
            }
            newTeam.prefix(mainTeam.prefix());
            newTeam.suffix(mainTeam.suffix());
            try {
                net.kyori.adventure.text.format.TextColor tc = mainTeam.color();
                if (tc instanceof net.kyori.adventure.text.format.NamedTextColor ntc) {
                    newTeam.color(ntc);
                } else {
                    newTeam.color(net.kyori.adventure.text.format.NamedTextColor.nearestTo(tc));
                }
            } catch (Exception e) {
                plugin.getLogger().fine("Team color sync failed: " + e.getMessage());
            }
            newTeam.setOption(Team.Option.NAME_TAG_VISIBILITY,
                    mainTeam.getOption(Team.Option.NAME_TAG_VISIBILITY));

            // Mirror entries
            Set<String> mainEntries = mainTeam.getEntries();
            Set<String> targetEntries = newTeam.getEntries();
            for (String entry : mainEntries) {
                if (!targetEntries.contains(entry)) newTeam.addEntry(entry);
            }
            for (String entry : targetEntries) {
                if (!mainEntries.contains(entry) && !entry.startsWith("§")) {
                    newTeam.removeEntry(entry);
                }
            }
        }

        // Remove teams that were deleted from main
        for (Team targetTeam : new ArrayList<>(target.getTeams())) {
            if (targetTeam.getName().startsWith("ln_")) continue; // Our sidebar teams
            if (main.getTeam(targetTeam.getName()) == null) {
                targetTeam.unregister();
            }
        }
    }

    /**
     * Parse PAPI placeholders if available.
     */
    private String parsePlaceholders(Player player, String text) {
        if (hasPapi) {
            try {
                return me.clip.placeholderapi.PlaceholderAPI.setPlaceholders(player, text);
            } catch (Exception e) {
                plugin.getLogger().fine("PAPI placeholder parse failed: " + e.getMessage());
            }
        }
        return text;
    }

    /**
     * Remove the custom scoreboard from a player, restoring the main one.
     */
    public void removeBoard(Player player) {
        UUID uuid = player.getUniqueId();
        if (playerBoards.containsKey(uuid)) {
            player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
            playerBoards.remove(uuid);
        }
    }

    /**
     * Cleanup on player quit.
     */
    public void onPlayerQuit(UUID uuid) {
        playerBoards.remove(uuid);
    }

    /**
     * Restore all players to the main scoreboard.
     */
    private void restoreAll() {
        Scoreboard main = Bukkit.getScoreboardManager().getMainScoreboard();
        for (var entry : playerBoards.entrySet()) {
            Player player = Bukkit.getPlayer(entry.getKey());
            if (player != null && player.isOnline()) {
                player.setScoreboard(main);
            }
        }
        playerBoards.clear();
    }

    public boolean isEnabled() { return enabled; }

    /**
     * Update the tab list display name for a player.
     * Format supports: {player}, {level}, {prestige}, {rank_prefix}, {kills}, {deaths}
     */
    private void updateTabListName(Player player) {
        UUID uuid = player.getUniqueId();
        PlayerProfile profile = plugin.getProfileManager().getProfile(uuid);
        if (profile == null) return;

        String format = tabListFormat;
        format = format.replace("{player}", player.getName());
        format = format.replace("{level}", String.valueOf(profile.getLevel()));
        format = format.replace("{prestige}", String.valueOf(profile.getPrestige()));
        format = format.replace("{kills}", String.valueOf(profile.getKills()));
        format = format.replace("{deaths}", String.valueOf(profile.getDeaths()));

        // Rank prefix from profile data or default
        String rankPrefix = profile.getCustom("rank_prefix");
        format = format.replace("{rank_prefix}", rankPrefix != null ? rankPrefix : "");

        // Level color based on level tier
        String levelColor = getLevelColor(profile.getLevel());
        format = format.replace("{level_color}", levelColor);

        String resolved = parsePlaceholders(player, format);
        player.playerListName(mini.deserialize(resolved));
    }

    /**
     * Set up the health below name objective on a scoreboard.
     */
    private void updateHealthObjective(Scoreboard board) {
        String objName = "en_health";
        Objective obj = board.getObjective(objName);
        if (obj == null) {
            obj = board.registerNewObjective(objName, Criteria.HEALTH,
                    mini.deserialize("<red>❤"), RenderType.HEARTS);
            obj.setDisplaySlot(DisplaySlot.BELOW_NAME);
        }
    }

    /**
     * Get color code for a level tier.
     */
    private String getLevelColor(int level) {
        if (level >= 100) return "<light_purple>";
        if (level >= 75) return "<gold>";
        if (level >= 50) return "<red>";
        if (level >= 25) return "<yellow>";
        if (level >= 10) return "<green>";
        return "<gray>";
    }

    /**
     * Map integer 0-21 to unique color code char for scoreboard entries.
     * Supports up to 22 lines (§0 through §r and §k-§o formatting codes).
     */
    private char intToChar(int i) {
        return switch (i) {
            case 1 -> '0'; case 2 -> '1'; case 3 -> '2'; case 4 -> '3';
            case 5 -> '4'; case 6 -> '5'; case 7 -> '6'; case 8 -> '7';
            case 9 -> '8'; case 10 -> '9'; case 11 -> 'a'; case 12 -> 'b';
            case 13 -> 'c'; case 14 -> 'd'; case 15 -> 'e'; case 16 -> 'f';
            case 17 -> 'k'; case 18 -> 'l'; case 19 -> 'm'; case 20 -> 'n';
            case 21 -> 'o'; case 22 -> 'r';
            default -> 'f';
        };
    }

    /**
     * Internal board configuration loaded from YAML.
     */
    static class BoardConfig {
        final String title;
        final List<String> lines;
        final Map<String, BoardConfig> arenaOverrides = new HashMap<>();

        BoardConfig(String title, List<String> lines) {
            this.title = title;
            this.lines = lines;
        }
    }
}
