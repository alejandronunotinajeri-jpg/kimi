package com.ethernova.core.metrics;

import com.ethernova.core.EthernovaCore;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;

import javax.net.ssl.HttpsURLConnection;
import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.zip.GZIPOutputStream;

/**
 * Centralized bStats Metrics for the entire Ethernova ecosystem.
 * Reports aggregated data from all active modules (Core, Combat, Clans, etc.)
 * to bStats.org for anonymous usage statistics.
 * <p>
 * Server operators can disable this via {@code metrics.enabled: false} in Core config.
 */
public class EthernovaMetrics {

    private static final String BSTATS_URL = "https://bStats.org/submitData/bukkit";
    private static final int PROTOCOL_VERSION = 2;

    private final EthernovaCore core;
    private final boolean enabled;
    private final int pluginId;
    private final String serverUUID;
    private final Map<String, Callable<Map<String, Object>>> customCharts = new ConcurrentHashMap<>();

    public EthernovaMetrics(EthernovaCore core) {
        this.core = core;
        this.enabled = core.getConfig().getBoolean("metrics.enabled", true);
        this.pluginId = core.getConfig().getInt("metrics.plugin-id", 0);

        // Persistent server UUID (shared bStats config)
        File configFile = new File(core.getDataFolder().getParentFile(), "bStats/config.yml");
        if (configFile.exists()) {
            YamlConfiguration bstatsConf = YamlConfiguration.loadConfiguration(configFile);
            serverUUID = bstatsConf.getString("serverUuid", UUID.randomUUID().toString());
        } else {
            serverUUID = UUID.randomUUID().toString();
            try {
                configFile.getParentFile().mkdirs();
                YamlConfiguration bstatsConf = new YamlConfiguration();
                bstatsConf.set("enabled", true);
                bstatsConf.set("serverUuid", serverUUID);
                bstatsConf.set("logFailedRequests", false);
                bstatsConf.save(configFile);
            } catch (Exception ignored) {}
        }

        if (enabled) {
            registerDefaultCharts();
            startSubmitting();
            core.getLogger().info("✔ bStats metrics habilitado (ecosystem-wide)");
        }
    }

    private void registerDefaultCharts() {
        // Active modules
        addChart("active_modules", () -> {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("value", core.getRegisteredPlugins().size());
            return map;
        });

        // Module list (advanced pie)
        addChart("module_list", () -> {
            Map<String, Object> map = new LinkedHashMap<>();
            for (String module : core.getRegisteredPlugins()) {
                map.put(module, 1);
            }
            return map;
        });

        // Storage type
        addChart("storage_type", () -> {
            Map<String, Object> map = new HashMap<>();
            map.put("value", core.getStorageManager().isMySQL() ? "MySQL" : "SQLite");
            return map;
        });

        // Server mode
        addChart("server_mode", () -> {
            Map<String, Object> map = new HashMap<>();
            map.put("value", core.getServerModeManager().getMode().name());
            return map;
        });

        // Language
        addChart("language", () -> {
            Map<String, Object> map = new HashMap<>();
            map.put("value", core.getConfig().getString("general.language", "es"));
            return map;
        });

        // Total online players
        addChart("online_players", () -> {
            Map<String, Object> map = new HashMap<>();
            map.put("value", Bukkit.getOnlinePlayers().size());
            return map;
        });

        // Java version
        addChart("java_version", () -> {
            Map<String, Object> map = new HashMap<>();
            map.put("value", System.getProperty("java.version"));
            return map;
        });

        // GUI rainbow
        addChart("gui_rainbow", () -> {
            Map<String, Object> map = new HashMap<>();
            map.put("value", core.getConfig().getBoolean("gui.rainbow-border", true) ? "Enabled" : "Disabled");
            return map;
        });
    }

    /**
     * Register a custom chart from any module.
     * Call this from your module's onEnable to add module-specific metrics.
     *
     * @param chartId unique chart identifier (must match bStats dashboard config)
     * @param dataCallable supplier that returns chart data
     */
    public void addChart(String chartId, Callable<Map<String, Object>> dataCallable) {
        customCharts.put(chartId, dataCallable);
    }

    /**
     * Remove a chart (call on module disable).
     */
    public void removeChart(String chartId) {
        customCharts.remove(chartId);
    }

    private void startSubmitting() {
        Bukkit.getScheduler().runTaskTimerAsynchronously(core, this::submitData,
                20L * 60 * 5, 20L * 60 * 30); // 5 min initial, 30 min interval
    }

    private void submitData() {
        try {
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("serverUUID", serverUUID);
            data.put("playerAmount", Bukkit.getOnlinePlayers().size());
            data.put("onlineMode", Bukkit.getOnlineMode() ? 1 : 0);
            data.put("bukkitVersion", Bukkit.getVersion());
            data.put("bukkitName", Bukkit.getName());
            data.put("javaVersion", System.getProperty("java.version"));
            data.put("osName", System.getProperty("os.name"));
            data.put("osArch", System.getProperty("os.arch"));
            data.put("osVersion", System.getProperty("os.version"));
            data.put("coreCount", Runtime.getRuntime().availableProcessors());

            Map<String, Object> pluginData = new LinkedHashMap<>();
            pluginData.put("pluginName", "EthernovaCore");
            pluginData.put("id", pluginId);
            pluginData.put("pluginVersion", core.getDescription().getVersion());

            List<Map<String, Object>> charts = new ArrayList<>();
            for (var entry : customCharts.entrySet()) {
                try {
                    Map<String, Object> chartData = entry.getValue().call();
                    if (chartData != null && !chartData.isEmpty()) {
                        Map<String, Object> chart = new LinkedHashMap<>();
                        chart.put("chartId", entry.getKey());
                        chart.put("data", chartData);
                        charts.add(chart);
                    }
                } catch (Exception ignored) {}
            }
            pluginData.put("customCharts", charts);
            data.put("plugins", List.of(pluginData));

            sendData(toJson(data));
        } catch (Exception e) {
            if (core.getConfig().getBoolean("general.debug", false)) {
                core.getLogger().log(Level.WARNING, "bStats submission failed", e);
            }
        }
    }

    private void sendData(String jsonData) throws Exception {
        URL url = new URL(BSTATS_URL);
        HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
        byte[] compressed = compress(jsonData);

        conn.setRequestMethod("POST");
        conn.addRequestProperty("Accept", "application/json");
        conn.addRequestProperty("Connection", "close");
        conn.addRequestProperty("Content-Encoding", "gzip");
        conn.addRequestProperty("Content-Length", String.valueOf(compressed.length));
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("User-Agent", "MC-Server/" + PROTOCOL_VERSION);
        conn.setDoOutput(true);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(compressed);
        }
        int responseCode = conn.getResponseCode();
        conn.getInputStream().close();
        conn.disconnect();
        if (responseCode < 200 || responseCode >= 300) {
            if (core.getConfig().getBoolean("general.debug", false)) {
                core.getLogger().warning("bStats returned HTTP " + responseCode);
            }
        }
    }

    private byte[] compress(String str) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (GZIPOutputStream gzos = new GZIPOutputStream(baos)) {
            gzos.write(str.getBytes(StandardCharsets.UTF_8));
        }
        return baos.toByteArray();
    }

    @SuppressWarnings("unchecked")
    private String toJson(Map<String, Object> map) {
        StringBuilder sb = new StringBuilder("{");
        boolean first = true;
        for (var entry : map.entrySet()) {
            if (!first) sb.append(",");
            first = false;
            sb.append("\"").append(escapeJson(entry.getKey())).append("\":");
            appendValue(sb, entry.getValue());
        }
        sb.append("}");
        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    private void appendValue(StringBuilder sb, Object value) {
        if (value == null) {
            sb.append("null");
        } else if (value instanceof Map) {
            sb.append(toJson((Map<String, Object>) value));
        } else if (value instanceof List) {
            sb.append("[");
            boolean first = true;
            for (Object item : (List<?>) value) {
                if (!first) sb.append(",");
                first = false;
                appendValue(sb, item);
            }
            sb.append("]");
        } else if (value instanceof Number || value instanceof Boolean) {
            sb.append(value);
        } else {
            sb.append("\"").append(escapeJson(value.toString())).append("\"");
        }
    }

    private String escapeJson(String str) {
        return str.replace("\\", "\\\\").replace("\"", "\\\"")
                  .replace("\n", "\\n").replace("\r", "\\r");
    }

    public boolean isEnabled() { return enabled; }
}
