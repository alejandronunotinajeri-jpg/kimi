package com.ethernova.core.listener;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.profile.PlayerProfile;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import com.ethernova.core.gui.PlayerSettingsGui;

import java.time.Duration;
import java.util.UUID;

public class CorePlayerListener implements Listener {

    private final EthernovaCore core;
    private final MiniMessage mini = MiniMessage.miniMessage();

    public CorePlayerListener(EthernovaCore core) { this.core = core; }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onLogin(PlayerLoginEvent event) {
        // Block login during maintenance for non-admins
        if (core.getMaintenanceManager() != null && core.getMaintenanceManager().isEnabled()) {
            if (!event.getPlayer().hasPermission("ethernova.admin")) {
                event.disallow(PlayerLoginEvent.Result.KICK_OTHER,
                        mini.deserialize(core.getMessageManager().get("maintenance.kick-message")));
            }
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        String name = player.getName();

        boolean isFirstJoin = !player.hasPlayedBefore();

        // Drain any pending cross-server messages that were queued while no player was online
        if (core.getCrossServerMessenger() != null) {
            Bukkit.getScheduler().runTaskLater(core, () -> {
                if (player.isOnline()) {
                    core.getCrossServerMessenger().drainPending(player);
                }
            }, 20L); // 1 second delay to let connection stabilize
        }

        // Create empty profile immediately so it's never null on join tick
        PlayerProfile profile = new PlayerProfile(uuid, name);
        long now = System.currentTimeMillis();
        profile.setLastJoin(now);
        if (isFirstJoin) profile.setFirstJoin(now);
        core.getProfileManager().registerIfAbsent(uuid, profile);

        // Merge DB data asynchronously
        Bukkit.getScheduler().runTaskAsynchronously(core, () -> {
            core.getProfileManager().mergeFromDB(uuid, name);
        });

        // Welcome experience (delayed 5 ticks to let client fully load)
        Bukkit.getScheduler().runTaskLater(core, () -> {
            if (!player.isOnline()) return;

            if (isFirstJoin) {
                // First join — special welcome
                String title = core.getMessageManager().get("join.first-join-title").replace("{player}", name);
                String subtitle = core.getMessageManager().get("join.first-join-subtitle").replace("{player}", name);
                player.showTitle(Title.title(
                        mini.deserialize(title), mini.deserialize(subtitle),
                        Title.Times.times(Duration.ofMillis(500), Duration.ofMillis(3000), Duration.ofMillis(1000))));
                core.getSoundManager().play(player, "level_up");

                // Broadcast first join
                String broadcast = core.getMessageManager().get("join.first-join-broadcast")
                        .replace("{player}", name);
                Bukkit.broadcast(mini.deserialize(broadcast));
            } else {
                // Returning player — welcome back
                String title = core.getMessageManager().get("join.welcome-title").replace("{player}", name);
                String subtitle = core.getMessageManager().get("join.welcome-subtitle").replace("{player}", name);
                player.showTitle(Title.title(
                        mini.deserialize(title), mini.deserialize(subtitle),
                        Title.Times.times(Duration.ofMillis(250), Duration.ofMillis(2000), Duration.ofMillis(500))));
                core.getSoundManager().play(player, "click");
            }

            // Hide other players if lobbyVisibility is disabled
            if (!PlayerSettingsGui.getSetting(core, uuid, "lobbyVisibility")) {
                for (Player other : Bukkit.getOnlinePlayers()) {
                    if (!other.getUniqueId().equals(uuid)) {
                        player.hidePlayer(core, other);
                    }
                }
            }

            // Send to lobby if lobby system is enabled
            if (core.getLobbyManager() != null && core.getLobbyManager().isEnabled()) {
                core.getLobbyManager().sendToLobby(player);
            }
        }, 5L);

        // Custom join message
        event.joinMessage(null); // Suppress default
        String joinMsg = core.getMessageManager().get("join.join-message").replace("{player}", name);
        Bukkit.broadcast(mini.deserialize(joinMsg));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        String name = player.getName();
        PlayerProfile profile = core.getProfileManager().getProfile(uuid);

        // Update play time
        if (profile != null && profile.getLastJoin() > 0) {
            long sessionTime = System.currentTimeMillis() - profile.getLastJoin();
            if (sessionTime > 0 && sessionTime < 86400000L) { // Sanity: max 24h session
                profile.setPlayTime(profile.getPlayTime() + sessionTime);
            }
        }

        // Remove from memory synchronously to prevent race with rapid reconnect
        core.getProfileManager().remove(uuid);
        core.getContextManager().clearAll(uuid);
        core.getCooldownManager().clearAll(uuid);
        core.getLocaleManager().cleanup(uuid);
        core.getStateManager().cleanup(uuid);
        core.getScoreboardManager().onPlayerQuit(uuid);
        core.getEconomyManager().cleanupPlayer(uuid);
        if (core.getLobbyManager() != null) {
            core.getLobbyManager().cleanupPlayer(uuid);
        }
        if (core.getReferralManager() != null) {
            core.getReferralManager().unloadPlayer(uuid);
        }

        if (profile != null) {
            // Save async (profile snapshot is safe — already removed from map)
            Bukkit.getScheduler().runTaskAsynchronously(core, () -> {
                core.getProfileManager().save(profile);
            });
        }

        // Custom quit message
        event.quitMessage(null); // Suppress default
        String quitMsg = core.getMessageManager().get("join.quit-message").replace("{player}", name);
        Bukkit.broadcast(mini.deserialize(quitMsg));
    }
}
