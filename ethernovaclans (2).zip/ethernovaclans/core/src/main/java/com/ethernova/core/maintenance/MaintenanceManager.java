package com.ethernova.core.maintenance;

import com.ethernova.core.EthernovaCore;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

/**
 * Toggleable maintenance mode. When enabled:
 * - Non-admin players are kicked
 * - New logins are denied (handled by CorePlayerListener)
 * - Optional countdown before activation
 */
public class MaintenanceManager {

    private final EthernovaCore core;
    private final MiniMessage mini = MiniMessage.miniMessage();
    private volatile boolean enabled = false;
    private BukkitTask countdownTask;

    public MaintenanceManager(EthernovaCore core) {
        this.core = core;
    }

    public boolean isEnabled() {
        return enabled;
    }

    /**
     * Toggle maintenance mode immediately.
     */
    public void toggle() {
        if (enabled) {
            disable();
        } else {
            enable(0);
        }
    }

    /**
     * Enable maintenance mode with optional countdown.
     * @param countdownSeconds 0 for immediate, >0 for countdown
     */
    public void enable(int countdownSeconds) {
        if (countdownTask != null) {
            countdownTask.cancel();
            countdownTask = null;
        }

        if (countdownSeconds <= 0) {
            activateNow();
            return;
        }

        // Countdown
        final int[] remaining = {countdownSeconds};
        countdownTask = Bukkit.getScheduler().runTaskTimer(core, () -> {
            if (remaining[0] <= 0) {
                countdownTask.cancel();
                countdownTask = null;
                activateNow();
                return;
            }

            // Broadcast at specific intervals
            if (remaining[0] <= 5 || remaining[0] == 10 || remaining[0] == 30 || remaining[0] == 60) {
                String msg = core.getMessageManager().get("maintenance.broadcast")
                        .replace("{seconds}", String.valueOf(remaining[0]));
                Bukkit.broadcast(mini.deserialize(msg));
            }

            remaining[0]--;
        }, 0L, 20L);
    }

    private void activateNow() {
        enabled = true;
        String kickMsg = core.getMessageManager().get("maintenance.kick-message");

        // Kick non-admin players
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!player.hasPermission("ethernova.admin")) {
                player.kick(mini.deserialize(kickMsg));
            }
        }

        String broadcast = core.getMessageManager().get("maintenance.enabled");
        Bukkit.broadcast(mini.deserialize(broadcast));
        core.getLogger().warning("Modo mantenimiento ACTIVADO");
    }

    public void disable() {
        if (countdownTask != null) {
            countdownTask.cancel();
            countdownTask = null;
        }
        enabled = false;
        String broadcast = core.getMessageManager().get("maintenance.disabled");
        Bukkit.broadcast(mini.deserialize(broadcast));
        core.getLogger().info("Modo mantenimiento DESACTIVADO");
    }

    public void cancelCountdown() {
        if (countdownTask != null) {
            countdownTask.cancel();
            countdownTask = null;
        }
    }
}
