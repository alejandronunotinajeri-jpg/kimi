package com.ethernova.core.context;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks inter-plugin contexts for players (e.g., "war", "arena", "ffa").
 * Combat plugin checks these to apply different tag profiles.
 */
public class ContextManager {

    private final Map<UUID, Set<String>> contexts = new ConcurrentHashMap<>();

    public void addContext(UUID uuid, String context) {
        contexts.computeIfAbsent(uuid, k -> ConcurrentHashMap.newKeySet()).add(context);
    }

    public void removeContext(UUID uuid, String context) {
        Set<String> set = contexts.get(uuid);
        if (set != null) set.remove(context);
    }

    public boolean hasContext(UUID uuid, String context) {
        Set<String> set = contexts.get(uuid);
        return set != null && set.contains(context);
    }

    public Set<String> getContexts(UUID uuid) {
        Set<String> set = contexts.get(uuid);
        return set != null ? java.util.Collections.unmodifiableSet(set) : Set.of();
    }

    public void clearAll(UUID uuid) {
        contexts.remove(uuid);
    }
}
