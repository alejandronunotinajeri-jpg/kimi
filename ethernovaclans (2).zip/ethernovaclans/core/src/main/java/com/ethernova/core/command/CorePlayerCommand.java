package com.ethernova.core.command;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.KitEditorGui;
import com.ethernova.core.gui.PlayerSettingsGui;
import com.ethernova.core.gui.RankingsGui;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Handles player-facing commands:
 * /kiteditor - Kit customization
 * /settings - Player settings
 * /rankings - Leaderboards
 * Note: /lobby and /menu moved to EthernovaLobby module
 */
public class CorePlayerCommand implements CommandExecutor, TabCompleter {

    private final EthernovaCore core;
    private final MiniMessage mini = MiniMessage.miniMessage();

    public CorePlayerCommand(EthernovaCore core) {
        this.core = core;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(mini.deserialize("<red>Este comando solo puede ser usado por jugadores."));
            return true;
        }

        String cmd = command.getName().toLowerCase();

        return switch (cmd) {
            case "kiteditor", "kit" -> handleKitEditor(player);
            case "settings", "opciones", "ajustes" -> handleSettings(player);
            case "rankings", "top", "ranking" -> handleRankings(player, args);
            default -> false;
        };
    }

    private boolean handleKitEditor(Player player) {
        var gui = new KitEditorGui(core, player);
        core.getGuiManager().registerGui(player, gui);
        gui.open();
        return true;
    }

    private boolean handleSettings(Player player) {
        var gui = new PlayerSettingsGui(core, player);
        core.getGuiManager().registerGui(player, gui);
        gui.open();
        return true;
    }

    private boolean handleRankings(Player player, String[] args) {
        var gui = new RankingsGui(core, player);
        core.getGuiManager().registerGui(player, gui);
        gui.open();
        return true;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                 @NotNull String alias, @NotNull String[] args) {
        String cmd = command.getName().toLowerCase();

        if ("rankings".equals(cmd) || "top".equals(cmd) || "ranking".equals(cmd)) {
            if (args.length == 1) {
                List<String> cats = List.of("kills", "deaths", "kdr", "coins", "level", "wins", "killstreak");
                return cats.stream()
                        .filter(s -> s.startsWith(args[0].toLowerCase()))
                        .sorted()
                        .collect(Collectors.toList());
            }
        }

        return Collections.emptyList();
    }
}
