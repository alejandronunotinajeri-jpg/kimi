package com.ethernova.core.event;

import java.util.UUID;

/**
 * Published on the EthernovaEventBus when a player's power changes.
 */
public record PowerChangeEvent(
        UUID playerUuid,
        String playerName,
        double oldPower,
        double newPower,
        String reason
) {}
