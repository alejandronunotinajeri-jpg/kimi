package com.ethernova.core.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.leaderboard.LeaderboardManager;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Rankings GUI — displays top players across different categories.
 * Replicates the original UltimateFFA rankings GUI.
 * Categories: Kills, Deaths, KDR, Money, ELO, Wins, Level, Killstreaks.
 */
public class RankingsGui extends CoreGui {

    private String currentCategory = "kills";

    private static final Map<String, RankingCategory> CATEGORIES = Map.of(
            "kills", new RankingCategory("Top Kills", Material.DIAMOND_SWORD, "kills"),
            "deaths", new RankingCategory("Top Muertes", Material.SKELETON_SKULL, "deaths"),
            "kdr", new RankingCategory("Top KDR", Material.BOW, "kdr"),
            "coins", new RankingCategory("Top Monedas", Material.GOLD_INGOT, "coins"),
            "level", new RankingCategory("Top Nivel", Material.EXPERIENCE_BOTTLE, "level"),
            "wins", new RankingCategory("Top Victorias", Material.GOLDEN_APPLE, "wins"),
            "killstreak", new RankingCategory("Top Rachás", Material.BLAZE_POWDER, "max_killstreak")
    );

    private record RankingCategory(String displayName, Material icon, String statKey) {}

    public RankingsGui(EthernovaCore core, Player player) {
        super(core, player);
    }

    public void open() {
        openInventory("<gradient:gold:yellow>♛ Rankings — " + CATEGORIES.getOrDefault(currentCategory,
                CATEGORIES.get("kills")).displayName + "</gradient>", 54);
    }

    @Override
    protected void populateItems() {
        // Header
        setItem(4, createItem(Material.GOLDEN_HELMET,
                "<gradient:gold:yellow><bold>♫ Rankings</bold></gradient>",
                List.of("", "<gray>Selecciona una categoría para", "<gray>ver los mejores jugadores")));

        // Row 2: category selector (slots 10-16)
        int catSlot = 10;
        for (var entry : CATEGORIES.entrySet()) {
            if (catSlot > 16) break;
            RankingCategory cat = entry.getValue();
            boolean selected = entry.getKey().equals(currentCategory);
            Material mat = selected ? Material.LIME_DYE : cat.icon;
            setItem(catSlot, createItem(mat, (selected ? "<green>" : "<gray>") + cat.displayName,
                    List.of(selected ? "<yellow>▶ Seleccionado" : "<gray>Click para ver")));
            slotActions.put(catSlot, "CAT:" + entry.getKey());
            catSlot++;
        }

        // Main area (slots 19-43): Top 10 players
        LeaderboardManager lbm = core.getLeaderboardManager();
        RankingCategory cat = CATEGORIES.getOrDefault(currentCategory, CATEGORIES.get("kills"));

        List<LeaderboardManager.LeaderboardEntry> top = lbm.getTop(cat.statKey);

        String[] medals = {"<gold>🥇", "<gray>🥈", "<#CD7F32>🥉", "<white>④", "<white>⑤",
                "<white>⑥", "<white>⑦", "<white>⑧", "<white>⑨", "<white>⑩"};

        for (int i = 0; i < Math.min(top.size(), 10); i++) {
            LeaderboardManager.LeaderboardEntry entry = top.get(i);
            int slot = 19 + i + (i >= 7 ? 2 : 0); // Row 3: 19-25 (7), Row 4: 28-30 (3)

            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            if (meta != null) {
                // Try to set skull owner
                try {
                    var offlinePlayer = Bukkit.getOfflinePlayer(entry.uuid());
                    meta.setOwningPlayer(offlinePlayer);
                } catch (Exception ignored) {}

                String medal = i < medals.length ? medals[i] : "<white>#" + (i + 1);
                meta.displayName(mini.deserialize(medal + " <white>" + entry.name()));

                List<Component> lore = new ArrayList<>();
                lore.add(mini.deserialize("<gray>" + cat.displayName + ": <yellow>" + entry.displayValue()));
                lore.add(mini.deserialize(" "));
                lore.add(mini.deserialize("<dark_gray>Posición #" + (i + 1)));
                meta.lore(lore);
                head.setItemMeta(meta);
            }
            setItem(slot, head);
        }

        if (top.isEmpty()) {
            setItem(22, createItem(Material.BARRIER, "<red>Sin datos",
                    List.of("<gray>No hay datos de ranking aún")));
        }

        // Bottom: Back button + your rank
        setItem(45, createItem(Material.ARROW, "<yellow>← Menú Principal"));
        slotActions.put(45, "BACK");

        setItem(49, createItem(Material.COMPASS, "<aqua>Tu posición",
                List.of("<gray>Click para ver tu posición", "<gray>en este ranking")));
        slotActions.put(49, "MY_RANK");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.startsWith("CAT:")) {
            String category = action.substring(4);
            if (CATEGORIES.containsKey(category)) {
                currentCategory = category;
                playSound("click");
                open(); // Reopen with new category
            }
            return true;
        }

        switch (action) {
            case "BACK" -> {
                playSound("click");
                player.closeInventory();
            }
            case "MY_RANK" -> {
                playSound("click");
                RankingCategory cat = CATEGORIES.getOrDefault(currentCategory, CATEGORIES.get("kills"));
                int position = core.getLeaderboardManager().getRank(
                        cat.statKey, player.getUniqueId());
                player.sendMessage(mini.deserialize(
                        "<gold>♛ <yellow>Tu posición en <white>" + cat.displayName +
                                "<yellow>: <gold>#" + (position > 0 ? position : "N/A")));
            }
        }
        return true;
    }
}
