package com.ethernova.core.storage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Automatic database migration system. Tracks schema version in a metadata table
 * and applies migrations sequentially. Each plugin registers its own migrations.
 *
 * Usage:
 *   MigrationManager mm = new MigrationManager(storageManager, logger, "ethernova_core");
 *   mm.addMigration(1, "CREATE TABLE IF NOT EXISTS ...");
 *   mm.addMigration(2, "ALTER TABLE ... ADD COLUMN ...");
 *   mm.migrate();
 */
public class MigrationManager {

    private final CoreStorageManager storage;
    private final Logger logger;
    private final String namespace;
    private final java.util.List<Migration> migrations = new java.util.ArrayList<>();

    public MigrationManager(CoreStorageManager storage, Logger logger, String namespace) {
        this.storage = storage;
        this.logger = logger;
        this.namespace = namespace;
    }

    /**
     * Add a migration. Version numbers must be sequential starting from 1.
     */
    public MigrationManager addMigration(int version, String... sqls) {
        migrations.add(new Migration(version, false, sqls));
        return this;
    }

    /**
     * Add a lenient migration where each SQL is executed independently.
     * Individual statement failures are logged as warnings but do not abort the migration.
     * Useful for idempotent DDL like ALTER TABLE ADD COLUMN that may already exist.
     */
    public MigrationManager addLenientMigration(int version, String... sqls) {
        migrations.add(new Migration(version, true, sqls));
        return this;
    }

    /**
     * Execute any pending migrations.
     */
    public void migrate() {
        try (Connection conn = storage.getConnection()) {
            ensureMetaTable(conn);
            int currentVersion = getCurrentVersion(conn);
            int applied = 0;

            for (Migration m : migrations) {
                if (m.version > currentVersion) {
                    logger.info("[" + namespace + "] Aplicando migración v" + m.version + (m.lenient ? " (lenient)" : "") + "...");
                    try {
                        conn.setAutoCommit(false);
                        if (m.lenient) {
                            // Lenient: each SQL runs independently; failures are warned but don't abort
                            for (String sql : m.sqls) {
                                try (Statement stmt = conn.createStatement()) {
                                    stmt.execute(sql);
                                } catch (Exception sqlEx) {
                                    logger.log(Level.FINE, "[" + namespace + "] Lenient SQL skipped (already applied?): " + sql, sqlEx);
                                }
                            }
                        } else {
                            try (Statement stmt = conn.createStatement()) {
                                for (String sql : m.sqls) {
                                    stmt.execute(sql);
                                }
                            }
                        }
                        setVersion(conn, m.version);
                        conn.commit();
                        applied++;
                    } catch (Exception e) {
                        conn.rollback();
                        logger.log(Level.SEVERE, "[" + namespace + "] Migración v" + m.version + " falló, rollback aplicado", e);
                        throw e;
                    } finally {
                        conn.setAutoCommit(true);
                    }
                }
            }

            if (applied > 0) {
                logger.info("[" + namespace + "] " + applied + " migración(es) aplicada(s). Versión actual: " + getMaxMigrationVersion());
            } else {
                logger.info("[" + namespace + "] Base de datos al día (v" + currentVersion + ")");
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, "[" + namespace + "] Error en sistema de migraciones", e);
        }
    }

    private void ensureMetaTable(Connection conn) throws java.sql.SQLException {
        try (Statement stmt = conn.createStatement()) {
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS ethernova_schema_versions (
                    namespace VARCHAR(64) PRIMARY KEY,
                    version INT NOT NULL DEFAULT 0,
                    updated_at BIGINT NOT NULL DEFAULT 0
                )
            """);
        }
    }

    private int getCurrentVersion(Connection conn) throws java.sql.SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT version FROM ethernova_schema_versions WHERE namespace = ?")) {
            ps.setString(1, namespace);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt("version") : 0;
            }
        }
    }

    private void setVersion(Connection conn, int version) throws java.sql.SQLException {
        String sql = storage.isMySQL()
            ? "INSERT INTO ethernova_schema_versions (namespace, version, updated_at) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE version=VALUES(version), updated_at=VALUES(updated_at)"
            : "INSERT INTO ethernova_schema_versions (namespace, version, updated_at) VALUES (?, ?, ?) ON CONFLICT(namespace) DO UPDATE SET version=excluded.version, updated_at=excluded.updated_at";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, namespace);
            ps.setInt(2, version);
            ps.setLong(3, System.currentTimeMillis());
            ps.executeUpdate();
        }
    }

    private int getMaxMigrationVersion() {
        return migrations.stream().mapToInt(m -> m.version).max().orElse(0);
    }

    private record Migration(int version, boolean lenient, String[] sqls) {}
}
