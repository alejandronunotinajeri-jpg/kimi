package com.ethernova.core.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.boost.BoostManager;
import com.ethernova.core.profile.PlayerProfile;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

/**
 * Admin GUI panel for server management. Shows:
 * - Server status (mode, players, DB, uptime)
 * - Active boosts with controls
 * - Quick actions (maintenance, save, reload)
 * - Registered plugins
 */
public class AdminGui extends CoreGui {

    public AdminGui(EthernovaCore core, Player player) {
        super(core, player);
    }

    public void open() {
        openInventory("<gradient:#A855F7:#6366F1><bold>⚙ Panel de Admin</bold></gradient>", 54);
    }

    @Override
    protected void populateItems() {
        // ═══════════════ HEADER ═══════════════
        setItem(4, createItem(Material.COMPASS,
                "<gradient:#A855F7:#6366F1><bold>⚙ Panel de Admin</bold></gradient>",
                List.of("",
                        "<dark_gray>▎ <gray>Gestiona el servidor",
                        "<dark_gray>▎ <gray>y todos los módulos")));

        // ═══════════════ ROW 1: SERVER INFO (slots 10-16) ═══════════════
        setItem(10, createItem(Material.COMPASS,
                "<gradient:#A855F7:#6366F1><bold>⚙ Servidor</bold></gradient>",
                List.of("",
                        "<dark_gray>▎ <gray>Modo: <white>" + core.getServerModeManager().getMode(),
                        "<dark_gray>▎ <gray>Versión: <white>" + core.getDescription().getVersion())));

        int online = Bukkit.getOnlinePlayers().size();
        int max = Bukkit.getMaxPlayers();
        setItem(11, createItem(Material.PLAYER_HEAD,
                "<green><bold>👥 Jugadores</bold>",
                List.of("",
                        "<dark_gray>▎ <gray>Online: <green>" + online + "<gray>/" + max,
                        "<dark_gray>▎ <gray>Perfiles: <yellow>" + core.getProfileManager().getAllProfiles().size())));

        String dbType = core.getStorageManager().isMySQL() ? "<green>MySQL" : "<yellow>SQLite";
        setItem(12, createItem(Material.LECTERN,
                "<aqua><bold>💾 Base de Datos</bold>",
                List.of("",
                        "<dark_gray>▎ <gray>Tipo: " + dbType)));

        Set<String> plugins = core.getRegisteredPlugins();
        List<String> pluginLore = new ArrayList<>();
        pluginLore.add("");
        for (String p : plugins) { pluginLore.add("<dark_gray>▎ <yellow>• <white>" + p); }
        if (plugins.isEmpty()) pluginLore.add("<dark_gray>▎ <dark_gray>Ninguno");
        setItem(13, createItem(Material.BOOKSHELF,
                "<gold><bold>📦 Módulos</bold> <dark_gray>(" + plugins.size() + ")", pluginLore));

        boolean proxy = core.getCrossServerMessenger().isProxyDetected();
        setItem(14, createItem(proxy ? Material.ENDER_PEARL : Material.FIRE_CHARGE,
                proxy ? "<green><bold>🌐 Proxy Activo</bold>" : "<red><bold>🌐 Sin Proxy</bold>",
                List.of("",
                        "<dark_gray>▎ <gray>BungeeCord/Velocity: " + (proxy ? "<green>✔" : "<red>✘"))));

        boolean econ = core.getEconomyHook().isEnabled();
        setItem(15, createItem(econ ? Material.GOLD_INGOT : Material.IRON_INGOT,
                econ ? "<gold><bold>💰 Vault</bold> <green>✔" : "<gray><bold>💰 Vault</bold> <red>✘",
                List.of("",
                        "<dark_gray>▎ <gray>Economy: " + (econ ? "<green>Conectado" : "<red>Sin conexión"))));

        setItem(16, createItem(Material.WRITABLE_BOOK,
                "<yellow><bold>🌍 Idioma</bold>",
                List.of("",
                        "<dark_gray>▎ <gray>Global: <white>" + core.getConfig().getString("general.language", "es"),
                        "<dark_gray>▎ <gray>Disponibles: <white>" + String.join(", ", core.getLocaleManager().getSupportedLanguages()))));

        // ═══════════════ ROW 2: BOOSTS (slots 19-25) ═══════════════
        Collection<BoostManager.ActiveBoost> boosts = core.getBoostManager().getActiveBoosts();
        if (boosts.isEmpty()) {
            setItem(22, createItem(Material.GRAY_DYE,
                    "<gray>Sin Boosts Activos",
                    List.of("", "<dark_gray>Usa /ethernova boost para activar")));
        } else {
            int slot = 19;
            for (BoostManager.ActiveBoost boost : boosts) {
                if (slot > 25) break;
                String remaining = core.getConfigManager().formatTime(boost.getRemainingMs());
                setItem(slot, createItem(Material.EXPERIENCE_BOTTLE,
                        "<gradient:#FFD700:#FFA500><bold>⚡ " + boost.type.toUpperCase() + "</bold></gradient>",
                        List.of("",
                                "<dark_gray>▎ <gray>Multiplicador: <gold>x" + boost.multiplier,
                                "<dark_gray>▎ <gray>Restante: <yellow>" + remaining,
                                "<dark_gray>▎ <gray>Fuente: <white>" + boost.source,
                                "",
                                "<red>✘ Click para desactivar")));
                slotActions.put(slot, "DEACTIVATE_BOOST:" + boost.type);
                slot++;
            }
        }

        // ═══════════════ ROW 3: QUICK ACTIONS (slots 28-34) ═══════════════
        setItem(28, createItem(Material.COMMAND_BLOCK,
                "<green><bold>⟳ Recargar</bold>",
                List.of("", "<gray>Recarga config.yml y mensajes")));
        slotActions.put(28, "RELOAD");

        setItem(29, createItem(Material.ENDER_CHEST,
                "<aqua><bold>💾 Guardar</bold>",
                List.of("", "<gray>Fuerza guardado de perfiles")));
        slotActions.put(29, "SAVE_ALL");

        boolean maint = core.getMaintenanceManager() != null && core.getMaintenanceManager().isEnabled();
        setItem(30, createItem(maint ? Material.REDSTONE_TORCH : Material.LEVER,
                maint ? "<red><bold>⚠ Mantenimiento ON</bold>" : "<green><bold>Mantenimiento OFF</bold>",
                List.of("",
                        "<dark_gray>▎ <gray>Estado: " + (maint ? "<red>ACTIVO" : "<green>Inactivo"),
                        "", "<yellow>▸ Click para toggle")));
        slotActions.put(30, "TOGGLE_MAINTENANCE");

        boolean debug = core.getConfig().getBoolean("general.debug", false);
        setItem(31, createItem(debug ? Material.REDSTONE_LAMP : Material.SOUL_LANTERN,
                "<yellow><bold>Debug</bold> " + (debug ? "<green>ON" : "<red>OFF"),
                List.of("", "<yellow>▸ Click para toggle")));
        slotActions.put(31, "TOGGLE_DEBUG");

        setItem(33, createItem(Material.GOLDEN_APPLE,
                "<gold><bold>⟳ Leaderboards</bold>",
                List.of("", "<gray>Fuerza actualización de rankings")));
        slotActions.put(33, "REFRESH_LEADERBOARDS");

        // ═══════════════ ROW 4: PLUGIN ADMIN GUIs (slots 37-43 centered) ═══════════════
        List<PluginEntry> pluginEntries = new ArrayList<>();
        if (isPluginRegistered("EthernovaCombat"))
            pluginEntries.add(new PluginEntry(Material.IRON_SWORD, "<gradient:#ED213A:#93291E><bold>⚔ Combat</bold></gradient>", "combatadmin gui"));
        if (isPluginRegistered("EthernovaCosmetics"))
            pluginEntries.add(new PluginEntry(Material.FIREWORK_ROCKET, "<gradient:#FF6B6B:#FFD93D><bold>✦ Cosmetics</bold></gradient>", "cosmetics admin"));
        if (isPluginRegistered("EthernovaParty"))
            pluginEntries.add(new PluginEntry(Material.CAKE, "<gradient:#7F7FD5:#86A8E7><bold>🎉 Party</bold></gradient>", "party admin"));
        if (isPluginRegistered("EthernovaProgression"))
            pluginEntries.add(new PluginEntry(Material.EXPERIENCE_BOTTLE, "<gradient:#11998E:#38EF7D><bold>📈 Progression</bold></gradient>", "level admin"));
        if (isPluginRegistered("EthernovaRanked"))
            pluginEntries.add(new PluginEntry(Material.DIAMOND_SWORD, "<gradient:#F7971E:#FFD200><bold>⚔ Ranked</bold></gradient>", "ranked admin gui"));
        if (isPluginRegistered("EthernovaDuels"))
            pluginEntries.add(new PluginEntry(Material.GOLDEN_SWORD, "<gradient:#ED213A:#93291E><bold>⚔ Duels</bold></gradient>", "dueladmin gui"));
        if (isPluginRegistered("EthernovaFFA"))
            pluginEntries.add(new PluginEntry(Material.NETHERITE_SWORD, "<gradient:#FC466B:#3F5EFB><bold>💀 FFA</bold></gradient>", "ffaadmin gui"));
        if (isPluginRegistered("EthernovaClans"))
            pluginEntries.add(new PluginEntry(Material.SHIELD, "<gradient:#A855F7:#6366F1><bold>🏰 Clans</bold></gradient>", "clanadmin gui"));

        // Center the plugin entries in the row (slots 37-43)
        int totalPlugins = pluginEntries.size();
        int startSlot = 37 + Math.max(0, (7 - totalPlugins) / 2);
        for (int i = 0; i < totalPlugins && (startSlot + i) <= 43; i++) {
            PluginEntry entry = pluginEntries.get(i);
            int slot = startSlot + i;
            setItem(slot, createItem(entry.icon, entry.name,
                    List.of("", "<yellow>▸ Click para abrir panel")));
            slotActions.put(slot, "PLUGIN:" + entry.command);
        }

        // ═══════════════ BOTTOM BAR ═══════════════
        setItem(49, createItem(Material.BARRIER, "<red>Cerrar"));
        slotActions.put(49, "CLOSE");
    }

    private record PluginEntry(Material icon, String name, String command) {}

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        switch (action) {
            case "RELOAD" -> {
                playSound("click");
                core.getConfigManager().loadAll();
                core.getMessageManager().load();
                core.getSoundManager().loadFromConfig(core.getConfig().getConfigurationSection("sounds"));
                player.closeInventory();
                core.getMessageManager().send(player, "general.reloaded");
                return true;
            }
            case "SAVE_ALL" -> {
                playSound("success");
                Bukkit.getScheduler().runTaskAsynchronously(core, () -> {
                    core.getProfileManager().saveAll();
                    Bukkit.getScheduler().runTask(core, () -> {
                        int count = core.getProfileManager().getAllProfiles().size();
                        core.getMessageManager().send(player, "admin.save-complete",
                                "{count}", String.valueOf(count));
                    });
                });
                return true;
            }
            case "TOGGLE_MAINTENANCE" -> {
                playSound("click");
                if (core.getMaintenanceManager() != null) {
                    core.getMaintenanceManager().toggle();
                    // Refresh GUI
                    player.closeInventory();
                    Bukkit.getScheduler().runTaskLater(core, this::open, 2L);
                }
                return true;
            }
            case "TOGGLE_DEBUG" -> {
                playSound("click");
                boolean current = core.getConfig().getBoolean("general.debug", false);
                core.getConfig().set("general.debug", !current);
                core.saveConfig();
                player.closeInventory();
                Bukkit.getScheduler().runTaskLater(core, this::open, 2L);
                return true;
            }
            case "REFRESH_LEADERBOARDS" -> {
                playSound("success");
                if (core.getLeaderboardManager() != null) {
                    Bukkit.getScheduler().runTaskAsynchronously(core, () -> {
                        core.getLeaderboardManager().refreshAll();
                        Bukkit.getScheduler().runTask(core, () ->
                                player.sendMessage(mini.deserialize("<green>Leaderboards actualizados.")));
                    });
                }
                return true;
            }
            default -> {
                if (action.startsWith("DEACTIVATE_BOOST:")) {
                    String boostType = action.substring("DEACTIVATE_BOOST:".length());
                    core.getBoostManager().deactivate(boostType);
                    playSound("click");
                    player.closeInventory();
                    Bukkit.getScheduler().runTaskLater(core, this::open, 2L);
                    return true;
                }
                if (action.startsWith("PLUGIN:")) {
                    String cmd = action.substring("PLUGIN:".length());
                    playSound("click");
                    player.closeInventory();
                    Bukkit.getScheduler().runTaskLater(core, () -> player.performCommand(cmd), 2L);
                    return true;
                }
            }
        }
        return false;
    }

    private boolean isPluginRegistered(String pluginName) {
        return core.getRegisteredPlugins().contains(pluginName);
    }
}
