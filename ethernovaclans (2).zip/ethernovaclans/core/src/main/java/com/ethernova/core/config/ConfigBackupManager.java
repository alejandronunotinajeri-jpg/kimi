package com.ethernova.core.config;

import com.ethernova.core.EthernovaCore;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;

import java.io.*;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;
import java.util.logging.Level;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Manages export/import (backup/restore) of all Ethernova plugin configurations.
 * <p>
 * Backups are stored as ZIP files in {@code plugins/EthernovaCore/backups/}.
 * Each backup contains all .yml files from every Ethernova module data folder.
 * A metadata file ({@code backup-info.yml}) stores timestamp, version, and file list.
 */
public class ConfigBackupManager {

    private static final String BACKUP_DIR = "backups";
    private static final String METADATA_FILE = "backup-info.yml";
    private static final MiniMessage MINI = MiniMessage.miniMessage();

    /** Prefixes for Ethernova plugin data folders. */
    private static final String[] ETHERNOVA_PREFIXES = {
        "EthernovaCore", "EthernovaClans", "EthernovaCombat",
        "EthernovaCosmetics", "EthernovaParty", "EthernovaProgression",
        "EthernovaRanked", "EthernovaDuels", "EthernovaFFA", "EthernovaDiscord"
    };

    private final EthernovaCore core;
    private final Path backupDir;

    public ConfigBackupManager(EthernovaCore core) {
        this.core = core;
        this.backupDir = core.getDataFolder().toPath().resolve(BACKUP_DIR);
        try {
            Files.createDirectories(backupDir);
        } catch (IOException e) {
            core.getLogger().log(Level.WARNING, "No se pudo crear directorio de backups", e);
        }
    }

    // ══════════════════════════════════════════════════════════
    //  CREATE BACKUP
    // ══════════════════════════════════════════════════════════

    /**
     * Create a backup of all Ethernova configurations.
     *
     * @param sender   who triggered the backup (for feedback messages)
     * @param backupName optional name; if null, auto-generates from timestamp
     */
    public void createBackup(CommandSender sender, String backupName) {
        Bukkit.getScheduler().runTaskAsynchronously(core, () -> {
            try {
                if (backupName == null || backupName.isBlank()) {
                    String timestamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date());
                    doCreateBackup(sender, "backup_" + timestamp);
                } else {
                    // Sanitize name
                    String safeName = backupName.replaceAll("[^a-zA-Z0-9_\\-]", "_");
                    doCreateBackup(sender, safeName);
                }
            } catch (Exception e) {
                core.getLogger().log(Level.SEVERE, "Error creating backup", e);
                sendMessage(sender, "<red>✘ Error al crear backup: " + e.getMessage());
            }
        });
    }

    private void doCreateBackup(CommandSender sender, String name) throws IOException {
        Path zipFile = backupDir.resolve(name + ".zip");

        // Prevent overwriting
        if (Files.exists(zipFile)) {
            sendMessage(sender, "<red>✘ Ya existe un backup con ese nombre: <white>" + name);
            return;
        }

        File pluginsDir = core.getDataFolder().getParentFile();
        int totalFiles = 0;
        long totalSize = 0;
        List<String> includedFiles = new ArrayList<>();

        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFile.toFile()))) {
            zos.setLevel(9); // Maximum compression

            for (String prefix : ETHERNOVA_PREFIXES) {
                File moduleDir = new File(pluginsDir, prefix);
                if (!moduleDir.exists() || !moduleDir.isDirectory()) continue;

                // Collect all .yml files recursively
                List<File> ymlFiles = collectYmlFiles(moduleDir);
                for (File yml : ymlFiles) {
                    String entryName = prefix + "/" + moduleDir.toPath().relativize(yml.toPath()).toString()
                            .replace('\\', '/');
                    ZipEntry entry = new ZipEntry(entryName);
                    entry.setTime(yml.lastModified());
                    zos.putNextEntry(entry);

                    Files.copy(yml.toPath(), zos);
                    zos.closeEntry();

                    totalFiles++;
                    totalSize += yml.length();
                    includedFiles.add(entryName);
                }
            }

            // Write metadata
            String metadata = buildMetadata(name, totalFiles, totalSize, includedFiles);
            ZipEntry metaEntry = new ZipEntry(METADATA_FILE);
            zos.putNextEntry(metaEntry);
            zos.write(metadata.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            zos.closeEntry();
        }

        long zipSize = Files.size(zipFile);
        sendMessage(sender, "<green>✔ Backup creado: <white>" + name + ".zip");
        sendMessage(sender, "<gray>  Archivos: <yellow>" + totalFiles +
                " <dark_gray>| <gray>Tamaño ZIP: <yellow>" + formatSize(zipSize));
        sendMessage(sender, "<gray>  Ubicación: <dark_gray>" + zipFile.toString());
    }

    // ══════════════════════════════════════════════════════════
    //  RESTORE BACKUP
    // ══════════════════════════════════════════════════════════

    /**
     * Restore configurations from a backup ZIP.
     *
     * @param sender     who triggered the restore
     * @param backupName name of the backup (without .zip extension)
     */
    public void restoreBackup(CommandSender sender, String backupName) {
        Bukkit.getScheduler().runTaskAsynchronously(core, () -> {
            try {
                doRestoreBackup(sender, backupName);
            } catch (Exception e) {
                core.getLogger().log(Level.SEVERE, "Error restoring backup", e);
                sendMessage(sender, "<red>✘ Error al restaurar backup: " + e.getMessage());
            }
        });
    }

    private void doRestoreBackup(CommandSender sender, String name) throws IOException {
        Path zipFile = backupDir.resolve(name + ".zip");
        if (!Files.exists(zipFile)) {
            sendMessage(sender, "<red>✘ Backup no encontrado: <white>" + name);
            return;
        }

        File pluginsDir = core.getDataFolder().getParentFile();
        int restoredFiles = 0;
        int skippedFiles = 0;

        try (ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile.toFile()))) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                if (entry.isDirectory() || METADATA_FILE.equals(entry.getName())) {
                    zis.closeEntry();
                    continue;
                }

                // Validate the entry path is within an Ethernova folder
                String entryName = entry.getName();
                boolean valid = false;
                for (String prefix : ETHERNOVA_PREFIXES) {
                    if (entryName.startsWith(prefix + "/")) {
                        valid = true;
                        break;
                    }
                }

                if (!valid) {
                    skippedFiles++;
                    zis.closeEntry();
                    continue;
                }

                // Security: prevent path traversal
                Path targetPath = pluginsDir.toPath().resolve(entryName).normalize();
                if (!targetPath.startsWith(pluginsDir.toPath())) {
                    skippedFiles++;
                    zis.closeEntry();
                    continue;
                }

                // Create parent directories
                Files.createDirectories(targetPath.getParent());

                // Write file
                try (OutputStream os = Files.newOutputStream(targetPath)) {
                    zis.transferTo(os);
                }
                restoredFiles++;
                zis.closeEntry();
            }
        }

        sendMessage(sender, "<green>✔ Backup restaurado: <white>" + name);
        sendMessage(sender, "<gray>  Archivos restaurados: <yellow>" + restoredFiles);
        if (skippedFiles > 0) {
            sendMessage(sender, "<yellow>  Archivos omitidos: <red>" + skippedFiles);
        }
        sendMessage(sender, "<yellow>⚠ Ejecuta <white>/ethernova reload <yellow>para aplicar los cambios.");
    }

    // ══════════════════════════════════════════════════════════
    //  LIST BACKUPS
    // ══════════════════════════════════════════════════════════

    /**
     * List all available backups.
     */
    public void listBackups(CommandSender sender) {
        try {
            if (!Files.exists(backupDir)) {
                sendMessage(sender, "<yellow>No hay backups disponibles.");
                return;
            }

            List<Path> zips;
            try (var stream = Files.list(backupDir)) {
                zips = stream
                        .filter(p -> p.toString().endsWith(".zip"))
                        .sorted(Comparator.comparing((Path p) -> {
                            try { return Files.getLastModifiedTime(p).toInstant(); }
                            catch (IOException e) { return Instant.EPOCH; }
                        }).reversed())
                        .toList();
            }

            if (zips.isEmpty()) {
                sendMessage(sender, "<yellow>No hay backups disponibles.");
                return;
            }

            sendMessage(sender, "<gradient:#A855F7:#6366F1><bold>Backups disponibles</bold></gradient> <gray>(" + zips.size() + ")");
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            for (Path zip : zips) {
                String fileName = zip.getFileName().toString();
                String name = fileName.substring(0, fileName.length() - 4); // Remove .zip
                long size = Files.size(zip);
                long modified = Files.getLastModifiedTime(zip).toMillis();
                sendMessage(sender, "<gray> ▸ <yellow>" + name +
                        " <dark_gray>| <gray>" + formatSize(size) +
                        " <dark_gray>| <gray>" + sdf.format(new Date(modified)));
            }
        } catch (IOException e) {
            core.getLogger().log(Level.WARNING, "Error listing backups", e);
            sendMessage(sender, "<red>✘ Error al listar backups: " + e.getMessage());
        }
    }

    /**
     * Delete a backup.
     */
    public void deleteBackup(CommandSender sender, String backupName) {
        Path zipFile = backupDir.resolve(backupName + ".zip");
        if (!Files.exists(zipFile)) {
            sendMessage(sender, "<red>✘ Backup no encontrado: <white>" + backupName);
            return;
        }
        try {
            Files.delete(zipFile);
            sendMessage(sender, "<green>✔ Backup eliminado: <white>" + backupName);
        } catch (IOException e) {
            sendMessage(sender, "<red>✘ Error al eliminar backup: " + e.getMessage());
        }
    }

    // ══════════════════════════════════════════════════════════
    //  GET BACKUP NAMES (for tab completion)
    // ══════════════════════════════════════════════════════════

    /**
     * Returns a list of backup names (without .zip extension) for tab completion.
     */
    public List<String> getBackupNames() {
        if (!Files.exists(backupDir)) return List.of();
        try (var stream = Files.list(backupDir)) {
            return stream
                    .filter(p -> p.toString().endsWith(".zip"))
                    .map(p -> {
                        String f = p.getFileName().toString();
                        return f.substring(0, f.length() - 4);
                    })
                    .toList();
        } catch (IOException e) {
            return List.of();
        }
    }

    // ══════════════════════════════════════════════════════════
    //  UTILITIES
    // ══════════════════════════════════════════════════════════

    private List<File> collectYmlFiles(File dir) {
        List<File> result = new ArrayList<>();
        File[] files = dir.listFiles();
        if (files == null) return result;
        for (File f : files) {
            if (f.isDirectory()) {
                result.addAll(collectYmlFiles(f));
            } else if (f.getName().endsWith(".yml") || f.getName().endsWith(".yaml")) {
                result.add(f);
            }
        }
        return result;
    }

    private String buildMetadata(String name, int fileCount, long totalSize, List<String> files) {
        StringBuilder sb = new StringBuilder();
        sb.append("# Ethernova Configuration Backup\n");
        sb.append("backup-name: \"").append(name).append("\"\n");
        sb.append("timestamp: \"").append(Instant.now().toString()).append("\"\n");
        sb.append("core-version: \"").append(core.getDescription().getVersion()).append("\"\n");
        sb.append("server-version: \"").append(Bukkit.getVersion()).append("\"\n");
        sb.append("file-count: ").append(fileCount).append("\n");
        sb.append("total-size: ").append(totalSize).append("\n");
        sb.append("files:\n");
        for (String f : files) {
            sb.append("  - \"").append(f).append("\"\n");
        }
        return sb.toString();
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        return String.format("%.1f MB", bytes / (1024.0 * 1024.0));
    }

    private void sendMessage(CommandSender sender, String message) {
        Bukkit.getScheduler().runTask(core, () -> sender.sendMessage(MINI.deserialize(message)));
    }
}
