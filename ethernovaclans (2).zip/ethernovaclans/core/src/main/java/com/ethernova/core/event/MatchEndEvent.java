package com.ethernova.core.event;

import java.util.UUID;

/** Fired when an FFA match/round ends. */
public record MatchEndEvent(UUID winnerUuid, String winnerName, int totalPlayers,
                            String arenaName, long durationMs) {}
