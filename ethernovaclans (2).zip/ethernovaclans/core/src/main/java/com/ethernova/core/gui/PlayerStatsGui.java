package com.ethernova.core.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.profile.PlayerProfile;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Player Statistics GUI — 45-slot GUI showing combat stats, progression, economy, and rankings.
 */
public class PlayerStatsGui extends CoreGui {

    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy HH:mm");

    public PlayerStatsGui(EthernovaCore core, Player player) {
        super(core, player);
    }

    public void open() {
        openInventory("<gradient:#A855F7:#6366F1>✎ Tus Estadísticas</gradient>", 45);
    }

    @Override
    protected void populateItems() {
        PlayerProfile p = core.getProfileManager().getProfile(player.getUniqueId());
        if (p == null) return;

        // ═══ Player Head — Center top (slot 4) ═══
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta skullMeta = (SkullMeta) head.getItemMeta();
        if (skullMeta != null) {
            skullMeta.setOwningPlayer(player);
            skullMeta.displayName(mini.deserialize("<gradient:gold:yellow>★ " + player.getName() + " ★</gradient>"));
            skullMeta.lore(List.of(
                    mini.deserialize(" "),
                    mini.deserialize("<gray>Nivel: <yellow>" + p.getLevel()),
                    mini.deserialize("<gray>Prestigio: <light_purple>" + p.getPrestige()),
                    mini.deserialize("<gray>XP: <aqua>" + p.getXP()),
                    mini.deserialize(" "),
                    mini.deserialize("<gray>Primera conexión:"),
                    mini.deserialize("<yellow>" + formatTimestamp(p.getFirstJoin()))
            ));
            head.setItemMeta(skullMeta);
        }
        setItem(4, head);

        // ═══ Row 2: Combat Stats ═══
        double kdr = p.getDeaths() == 0 ? p.getKills() : (double) p.getKills() / p.getDeaths();

        setItem(10, createItem(Material.IRON_SWORD, "<red>⚔ Kills",
                List.of(" ", "<gray>Total: <yellow>" + p.getKills(), " ")));

        setItem(12, createItem(Material.SKELETON_SKULL, "<gray>☠ Muertes",
                List.of(" ", "<gray>Total: <yellow>" + p.getDeaths(), " ")));

        setItem(14, createItem(Material.GOLDEN_SWORD, "<gold>⚡ KDR",
                List.of(" ", "<gray>Ratio: <yellow>" + String.format("%.2f", kdr), " ")));

        setItem(16, createItem(Material.BLAZE_POWDER, "<yellow>🔥 Tiempo Jugado",
                List.of(" ", "<gray>Total: <yellow>" + core.getConfigManager().formatTime(p.getPlayTime()), " ")));

        // ═══ Row 3: Progression & Economy ═══
        setItem(19, createItem(Material.EXPERIENCE_BOTTLE, "<green>✦ Nivel",
                List.of(" ",
                        "<gray>Nivel: <yellow>" + p.getLevel(),
                        "<gray>Prestigio: <light_purple>" + p.getPrestige(),
                        "<gray>XP: <aqua>" + p.getXP(),
                        " ")));

        setItem(21, createItem(Material.GOLD_INGOT, "<gold>$ Monedas",
                List.of(" ", "<gray>Balance: <gold>" + String.format("%.2f", p.getCoins()), " ")));

        // ═══ Row 3 right: Rankings ═══
        StringBuilder rankInfo = new StringBuilder();
        if (core.getLeaderboardManager() != null) {
            int killRank = core.getLeaderboardManager().getRank("kills", player.getUniqueId());
            int coinsRank = core.getLeaderboardManager().getRank("coins", player.getUniqueId());
            int levelRank = core.getLeaderboardManager().getRank("level", player.getUniqueId());

            setItem(25, createItem(Material.GOLD_BLOCK, "<gold>♛ Tus Rankings",
                    List.of(" ",
                            "<gray>Kills: " + (killRank > 0 ? "<yellow>#" + killRank : "<dark_gray>Sin ranking"),
                            "<gray>Monedas: " + (coinsRank > 0 ? "<gold>#" + coinsRank : "<dark_gray>Sin ranking"),
                            "<gray>Nivel: " + (levelRank > 0 ? "<aqua>#" + levelRank : "<dark_gray>Sin ranking"),
                            " ")));
        } else {
            setItem(25, createItem(Material.GOLD_BLOCK, "<gold>♛ Rankings",
                    List.of(" ", "<dark_gray>No disponible", " ")));
        }

        // ═══ Row 4: Quick links ═══
        setItem(30, createItem(Material.PAPER, "<white>♛ Ver Rankings Globales",
                List.of(" ", "<yellow>Click para abrir", " ")));
        slotActions.put(30, "RANKINGS");

        setItem(32, createItem(Material.REDSTONE, "<red>⚙ Configuración",
                List.of(" ", "<yellow>Click para abrir", " ")));
        slotActions.put(32, "SETTINGS");

        // Bottom center: Back
        setItem(40, createItem(Material.ARROW, "<yellow>← Volver al Menú"));
        slotActions.put(40, "BACK");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        playSound("click");

        switch (action) {
            case "RANKINGS" -> {
                player.closeInventory();
                new RankingsGui(core, player).open();
            }
            case "SETTINGS" -> {
                player.closeInventory();
                new PlayerSettingsGui(core, player).open();
            }
            case "BACK" -> {
                player.closeInventory();
            }
        }
        return true;
    }

    private String formatTimestamp(long millis) {
        if (millis <= 0) return "Desconocido";
        return DATE_FORMAT.format(new Date(millis));
    }
}
