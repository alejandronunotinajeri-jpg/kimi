package com.ethernova.core.gui;

import com.ethernova.core.EthernovaCore;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.List;

/**
 * Yes/No confirmation GUI dialog.
 * Usage: new ConfirmationGui(core, player, "¿Confirmar?", List.of("linea1"), () -> { onConfirm }, () -> { onDeny }).open();
 */
public class ConfirmationGui extends CoreGui {

    private final String question;
    private final List<String> details;
    private final Runnable onConfirm;
    private final Runnable onDeny;

    public ConfirmationGui(EthernovaCore core, Player player, String question, List<String> details,
                           Runnable onConfirm, Runnable onDeny) {
        super(core, player);
        this.question = question;
        this.details = details;
        this.onConfirm = onConfirm;
        this.onDeny = onDeny != null ? onDeny : () -> player.closeInventory();
    }

    public void open() {
        openInventory("<dark_gray>Confirmación", 27);
    }

    @Override
    protected void populateItems() {
        // Question info in center
        setItem(13, createItem(Material.PAPER, question, details));

        // Confirm (green wool) on left
        setItem(11, createItem(Material.LIME_WOOL, "<green><bold>✔ Confirmar",
                List.of("<gray>Click para confirmar")));
        slotActions.put(11, "CONFIRM");

        // Deny (red wool) on right
        setItem(15, createItem(Material.RED_WOOL, "<red><bold>✘ Cancelar",
                List.of("<gray>Click para cancelar")));
        slotActions.put(15, "DENY");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        player.closeInventory();
        return switch (action) {
            case "CONFIRM" -> {
                playSound("success");
                onConfirm.run();
                yield true;
            }
            case "DENY" -> {
                playSound("click");
                onDeny.run();
                yield true;
            }
            default -> false;
        };
    }
}
