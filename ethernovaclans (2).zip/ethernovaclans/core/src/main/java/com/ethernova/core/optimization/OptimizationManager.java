package com.ethernova.core.optimization;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryUsage;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.logging.Logger;

/**
 * Server performance monitoring and optimization manager.
 * <p>
 * Features:
 * <ul>
 *   <li>TPS monitoring with rolling average</li>
 *   <li>Memory usage tracking</li>
 *   <li>Automatic GC suggestion on low memory</li>
 *   <li>Lag spike detection and logging</li>
 *   <li>Performance report for admins</li>
 * </ul>
 */
public class OptimizationManager {

    private final JavaPlugin plugin;
    private final Logger logger;

    // TPS tracking
    private final Deque<Double> tpsHistory = new ArrayDeque<>();
    private long lastTickTime;
    private BukkitTask tpsTask;
    private BukkitTask monitorTask;

    // Config
    private static final int TPS_HISTORY_SIZE = 60; // 1 minute of data (1 sample/sec)
    private static final double LOW_TPS_THRESHOLD = 18.0;
    private static final double CRITICAL_TPS_THRESHOLD = 15.0;
    private static final double MEMORY_WARNING_PERCENT = 85.0;

    // Stats
    private volatile double currentTPS = 20.0;
    private volatile int lagSpikes = 0;
    private volatile long lastLagSpike = 0;
    private volatile boolean lowTpsWarned = false;

    public OptimizationManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.logger = plugin.getLogger();
        startMonitoring();
    }

    // ═══════════════════════════════════════
    //  TPS MONITORING
    // ═══════════════════════════════════════

    private void startMonitoring() {
        lastTickTime = System.nanoTime();

        // TPS calculation task - runs every 20 ticks (1 second)
        tpsTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            long now = System.nanoTime();
            long elapsed = now - lastTickTime;
            lastTickTime = now;

            // Calculate TPS from elapsed nanoseconds
            double seconds = elapsed / 1_000_000_000.0;
            double tps = Math.min(20.0, 20.0 / seconds);
            currentTPS = tps;

            synchronized (tpsHistory) {
                tpsHistory.addLast(tps);
                if (tpsHistory.size() > TPS_HISTORY_SIZE) {
                    tpsHistory.removeFirst();
                }
            }

            // Lag spike detection
            if (tps < CRITICAL_TPS_THRESHOLD) {
                lagSpikes++;
                lastLagSpike = System.currentTimeMillis();
                if (!lowTpsWarned) {
                    logger.warning("⚠ Lag detectado: TPS=" + String.format("%.1f", tps));
                    lowTpsWarned = true;
                }
            } else if (tps >= LOW_TPS_THRESHOLD) {
                lowTpsWarned = false;
            }
        }, 20L, 20L);

        // Memory monitoring - every 5 minutes
        monitorTask = Bukkit.getScheduler().runTaskTimer(plugin, this::checkMemory, 6000L, 6000L);
    }

    private void checkMemory() {
        MemoryMXBean memBean = ManagementFactory.getMemoryMXBean();
        MemoryUsage heapUsage = memBean.getHeapMemoryUsage();
        long used = heapUsage.getUsed();
        long max = heapUsage.getMax();
        double percent = (double) used / max * 100;

        if (percent >= MEMORY_WARNING_PERCENT) {
            logger.warning(String.format("⚠ Memoria alta: %.1f%% (%dMB / %dMB)",
                    percent, used / 1024 / 1024, max / 1024 / 1024));
        }
    }

    // ═══════════════════════════════════════
    //  PUBLIC API
    // ═══════════════════════════════════════

    /**
     * Get current TPS.
     */
    public double getCurrentTPS() {
        return currentTPS;
    }

    /**
     * Get average TPS over the last N seconds.
     */
    public double getAverageTPS(int seconds) {
        synchronized (tpsHistory) {
            if (tpsHistory.isEmpty()) return 20.0;
            int count = Math.min(seconds, tpsHistory.size());
            double sum = 0;
            int i = 0;
            for (Double tps : tpsHistory) {
                if (i >= tpsHistory.size() - count) sum += tps;
                i++;
            }
            return sum / count;
        }
    }

    /**
     * Get average TPS over the last minute.
     */
    public double getAverageTPS() {
        return getAverageTPS(60);
    }

    /**
     * Get TPS as a colored string for display.
     */
    public String getTPSColored() {
        double tps = currentTPS;
        String color;
        if (tps >= 19.5) color = "<green>";
        else if (tps >= LOW_TPS_THRESHOLD) color = "<yellow>";
        else if (tps >= CRITICAL_TPS_THRESHOLD) color = "<gold>";
        else color = "<red>";
        return color + String.format("%.1f", tps);
    }

    /**
     * Get memory usage info.
     */
    public MemoryInfo getMemoryInfo() {
        MemoryUsage heapUsage = ManagementFactory.getMemoryMXBean().getHeapMemoryUsage();
        long used = heapUsage.getUsed() / 1024 / 1024;
        long max = heapUsage.getMax() / 1024 / 1024;
        long free = max - used;
        double percent = (double) heapUsage.getUsed() / heapUsage.getMax() * 100;
        return new MemoryInfo(used, max, free, percent);
    }

    /**
     * Get number of lag spikes since server start.
     */
    public int getLagSpikes() { return lagSpikes; }

    /**
     * Get time of last lag spike.
     */
    public long getLastLagSpike() { return lastLagSpike; }

    /**
     * Get a full performance report string.
     */
    public String getPerformanceReport() {
        MemoryInfo mem = getMemoryInfo();
        return String.format(
                """
                <gold>═══ Performance Report ═══
                <yellow>TPS: %s <gray>(1min: <yellow>%.1f<gray>, 5min: <yellow>%.1f<gray>)
                <yellow>Memoria: <white>%dMB / %dMB <gray>(%.1f%%)
                <yellow>Lag spikes: <white>%d
                <yellow>Entidades: <white>%d
                <yellow>Jugadores: <white>%d / %d
                <yellow>Uptime: <white>%s
                <gold>═══════════════════════""",
                getTPSColored(),
                getAverageTPS(60),
                getAverageTPS(300),
                mem.usedMB(), mem.maxMB(), mem.percent(),
                lagSpikes,
                getEntityCount(),
                Bukkit.getOnlinePlayers().size(), Bukkit.getMaxPlayers(),
                getUptime()
        );
    }

    private int getEntityCount() {
        return Bukkit.getWorlds().stream()
                .mapToInt(w -> w.getEntities().size())
                .sum();
    }

    private String getUptime() {
        long uptimeMs = ManagementFactory.getRuntimeMXBean().getUptime();
        long hours = uptimeMs / 3_600_000;
        long minutes = (uptimeMs % 3_600_000) / 60_000;
        return hours + "h " + minutes + "m";
    }

    /**
     * Check if server is experiencing lag.
     */
    public boolean isLagging() {
        return currentTPS < LOW_TPS_THRESHOLD;
    }

    /**
     * Check if server is in critical lag state.
     */
    public boolean isCritical() {
        return currentTPS < CRITICAL_TPS_THRESHOLD;
    }

    public void shutdown() {
        if (tpsTask != null) tpsTask.cancel();
        if (monitorTask != null) monitorTask.cancel();
    }

    public record MemoryInfo(long usedMB, long maxMB, long freeMB, double percent) {}
}
