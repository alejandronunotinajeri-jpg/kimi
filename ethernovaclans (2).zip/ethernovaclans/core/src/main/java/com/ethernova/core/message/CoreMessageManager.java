package com.ethernova.core.message;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.logging.Level;

public class CoreMessageManager {

    private final JavaPlugin plugin;
    private final MiniMessage mini = MiniMessage.miniMessage();
    private volatile YamlConfiguration messages;
    private volatile String prefix;

    public CoreMessageManager(JavaPlugin plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        String lang = plugin.getConfig().getString("general.language", "es");
        String fileName = "messages_" + lang + ".yml";
        File file = new File(plugin.getDataFolder(), fileName);
        if (!file.exists()) try { plugin.saveResource(fileName, false); } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Could not save default language file " + fileName, e);
        }
        if (!file.exists()) { fileName = "messages_es.yml"; file = new File(plugin.getDataFolder(), fileName); }

        messages = YamlConfiguration.loadConfiguration(file);
        try (InputStream def = plugin.getResource(fileName)) {
            if (def != null) messages.setDefaults(YamlConfiguration.loadConfiguration(new InputStreamReader(def, StandardCharsets.UTF_8)));
        } catch (java.io.IOException ignored) {}
        prefix = messages.getString("general.prefix", "<gradient:#A855F7:#6366F1>Ethernova</gradient> <dark_gray>»</dark_gray>");
    }

    public MiniMessage getMiniMessage() { return mini; }

    public String get(String path, String... replacements) {
        String raw = messages.getString(path, "<red>[Missing: " + path + "]</red>");
        raw = raw.replace("{prefix}", prefix);
        for (int i = 0; i + 1 < replacements.length; i += 2) raw = raw.replace(replacements[i], replacements[i + 1]);
        return raw;
    }

    public void send(CommandSender sender, String path, String... replacements) {
        sender.sendMessage(mini.deserialize(get(path, replacements)));
    }
}