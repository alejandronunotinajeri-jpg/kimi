package com.ethernova.core.event;

import org.bukkit.Bukkit;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;
import java.util.logging.Level;

public class EthernovaEventBus {

    @SuppressWarnings("rawtypes")
    private final Map<Class<?>, List<Consumer>> listeners = new ConcurrentHashMap<>();

    @SuppressWarnings("unchecked")
    public <T> void subscribe(Class<T> type, Consumer<T> listener) {
        listeners.computeIfAbsent(type, k -> new CopyOnWriteArrayList<>()).add(listener);
    }

    public <T> void unsubscribe(Class<T> type, Consumer<T> listener) {
        List<Consumer> list = listeners.get(type);
        if (list != null) list.remove(listener);
    }

    /** Remove all listeners for a specific event type. */
    public void clearListeners(Class<?> type) {
        listeners.remove(type);
    }

    /** Remove ALL listeners (call on plugin disable to prevent classloader leaks). */
    public void clearAll() {
        listeners.clear();
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public void publish(Object event) {
        List<Consumer> list = listeners.get(event.getClass());
        if (list != null) {
            for (Consumer c : list) {
                try { c.accept(event); } catch (Exception e) {
                    Bukkit.getLogger().log(Level.WARNING, "EventBus subscriber error for " + event.getClass().getSimpleName(), e);
                }
            }
        }
    }
}
