package com.ethernova.core.event;

import java.util.UUID;

/** Fired when a player levels up. */
public record LevelUpEvent(UUID playerUuid, String playerName, int oldLevel, int newLevel) {}
