package com.ethernova.core.config;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

public class CoreConfigManager {

    private static final Pattern TIME_PATTERN = Pattern.compile("(\\d+)\\s*([smhd])", Pattern.CASE_INSENSITIVE);

    private final JavaPlugin plugin;
    private volatile FileConfiguration config;

    public CoreConfigManager(JavaPlugin plugin) { this.plugin = plugin; }

    public void loadAll() {
        File configFile = new File(plugin.getDataFolder(), "config.yml");
        boolean existed = configFile.exists();

        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        config = plugin.getConfig();

        if (existed) {
            plugin.getLogger().info("config.yml existente cargado (no se sobreescribió)");
            mergeDefaults(configFile);
        } else {
            plugin.getLogger().info("config.yml creado por primera vez con valores por defecto");
        }
    }

    private void mergeDefaults(File configFile) {
        try (InputStream defStream = plugin.getResource("config.yml")) {
            if (defStream == null) return;
            YamlConfiguration defaults = YamlConfiguration.loadConfiguration(
                    new InputStreamReader(defStream, StandardCharsets.UTF_8));

            Set<String> allDefaultKeys = defaults.getKeys(true);
            int added = 0;
            for (String key : allDefaultKeys) {
                if (!config.contains(key)) {
                    config.set(key, defaults.get(key));
                    added++;
                }
            }
            if (added > 0) {
                plugin.saveConfig();
                plugin.reloadConfig();
                config = plugin.getConfig();
                plugin.getLogger().info("config.yml actualizado: " + added + " clave(s) nueva(s) añadida(s)");
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error al hacer merge de config defaults", e);
        }
    }

    public FileConfiguration getConfig() { return config; }
    public String getString(String path, String def) { return config.getString(path, def); }
    public int getInt(String path, int def) { return config.getInt(path, def); }
    public boolean getBoolean(String path, boolean def) { return config.getBoolean(path, def); }

    /**
     * Parse time strings like "30s", "5m", "2h", "1d" to milliseconds.
     */
    public long parseTimeToMillis(String input) {
        if (input == null || input.isBlank()) return 0;
        Matcher matcher = TIME_PATTERN.matcher(input.trim());
        long total = 0;
        while (matcher.find()) {
            long val = Long.parseLong(matcher.group(1));
            switch (matcher.group(2).toLowerCase()) {
                case "s" -> total += val * 1000L;
                case "m" -> total += val * 60000L;
                case "h" -> total += val * 3600000L;
                case "d" -> total += val * 86400000L;
            }
        }
        if (total == 0) {
            try { total = Long.parseLong(input.trim()) * 1000L; } catch (NumberFormatException ignored) {}
        }
        return total;
    }

    /**
     * Format milliseconds to human readable "Xh Xm Xs".
     */
    public String formatTime(long millis) {
        long seconds = millis / 1000;
        if (seconds <= 0) return "0s";
        long h = seconds / 3600;
        long m = (seconds % 3600) / 60;
        long s = seconds % 60;
        StringBuilder sb = new StringBuilder();
        if (h > 0) sb.append(h).append("h ");
        if (m > 0) sb.append(m).append("m ");
        if (s > 0 || sb.isEmpty()) sb.append(s).append("s");
        return sb.toString().trim();
    }
}
