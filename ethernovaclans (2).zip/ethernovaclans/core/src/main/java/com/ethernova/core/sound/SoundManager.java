package com.ethernova.core.sound;

import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * Configurable sound registry. Plugins register sound events and admins
 * can override the actual Sound, volume, and pitch in config.yml.
 *
 * Config format (sounds section):
 *   sounds:
 *     kill:
 *       sound: ENTITY_EXPERIENCE_ORB_PICKUP
 *       volume: 1.0
 *       pitch: 1.2
 *     death:
 *       enabled: false
 */
public class SoundManager {

    private final Map<String, SoundEntry> sounds = new ConcurrentHashMap<>();
    private final Logger logger;

    public SoundManager(Logger logger) {
        this.logger = logger;
        registerDefaults();
    }

    private void registerDefaults() {
        register("click", Sound.UI_BUTTON_CLICK, 0.5f, 1f);
        register("success", Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.5f);
        register("error", Sound.ENTITY_VILLAGER_NO, 0.5f, 1f);
        register("kill", Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
        register("death", Sound.ENTITY_WITHER_HURT, 0.6f, 0.8f);
        register("streak", Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.8f, 1f);
        register("level_up", Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        register("prestige", Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 0.8f);
        register("reward", Sound.ENTITY_ITEM_PICKUP, 0.7f, 1.3f);
        register("countdown", Sound.BLOCK_NOTE_BLOCK_PLING, 0.8f, 1f);
        register("match_start", Sound.ENTITY_ENDER_DRAGON_GROWL, 0.5f, 1.2f);
        register("match_end", Sound.ENTITY_FIREWORK_ROCKET_BLAST, 0.8f, 1f);
        register("teleport", Sound.ENTITY_ENDERMAN_TELEPORT, 0.6f, 1f);
        register("denied", Sound.ENTITY_VILLAGER_NO, 0.5f, 1f);
        register("gui_open", Sound.BLOCK_CHEST_OPEN, 0.3f, 1.2f);
        register("gui_close", Sound.BLOCK_CHEST_CLOSE, 0.3f, 1.2f);
        register("boost_activate", Sound.BLOCK_BEACON_ACTIVATE, 0.8f, 1f);
        register("chat_mention", Sound.BLOCK_NOTE_BLOCK_BELL, 0.5f, 1.5f);
        register("duel_accept", Sound.ENTITY_PLAYER_LEVELUP, 0.5f, 1.5f);
        register("combo", Sound.ENTITY_ITEM_BREAK, 0.4f, 1.5f);
    }

    /** Register a new sound with defaults. */
    public void register(String key, Sound sound, float volume, float pitch) {
        sounds.put(key.toLowerCase(), new SoundEntry(sound, volume, pitch, true));
    }

    /** Load overrides from a ConfigurationSection. */
    public void loadFromConfig(ConfigurationSection section) {
        if (section == null) return;
        for (String key : section.getKeys(false)) {
            ConfigurationSection entry = section.getConfigurationSection(key);
            if (entry == null) continue;

            boolean enabled = entry.getBoolean("enabled", true);
            SoundEntry existing = sounds.get(key.toLowerCase());

            if (!enabled) {
                sounds.put(key.toLowerCase(), new SoundEntry(
                        existing != null ? existing.sound : Sound.UI_BUTTON_CLICK, 0, 0, false));
                continue;
            }

            String soundName = entry.getString("sound",
                    existing != null ? existing.sound.name() : "UI_BUTTON_CLICK");
            float volume = (float) entry.getDouble("volume",
                    existing != null ? existing.volume : 0.5);
            float pitch = (float) entry.getDouble("pitch",
                    existing != null ? existing.pitch : 1.0);

            try {
                Sound sound = Sound.valueOf(soundName.toUpperCase());
                sounds.put(key.toLowerCase(), new SoundEntry(sound, volume, pitch, true));
            } catch (IllegalArgumentException e) {
                logger.warning("Sonido inválido para '" + key + "': " + soundName);
            }
        }
    }

    /** Play a registered sound for a player. */
    public void play(Player player, String key) {
        SoundEntry entry = sounds.get(key.toLowerCase());
        if (entry == null || !entry.enabled) return;
        player.playSound(player.getLocation(), entry.sound, entry.volume, entry.pitch);
    }

    /** Play a registered sound at a location (audible to nearby players). */
    public void playAt(Location location, String key) {
        SoundEntry entry = sounds.get(key.toLowerCase());
        if (entry == null || !entry.enabled || location.getWorld() == null) return;
        location.getWorld().playSound(location, entry.sound, entry.volume, entry.pitch);
    }

    /** Check if a sound key is registered. */
    public boolean isRegistered(String key) {
        return sounds.containsKey(key.toLowerCase());
    }

    /** Check if a sound key is enabled. */
    public boolean isEnabled(String key) {
        SoundEntry entry = sounds.get(key.toLowerCase());
        return entry != null && entry.enabled;
    }

    private record SoundEntry(Sound sound, float volume, float pitch, boolean enabled) {}
}
