package com.ethernova.core.gui;

import com.ethernova.core.EthernovaCore;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;
import java.util.stream.Collectors;

import org.bukkit.scheduler.BukkitTask;

/**
 * Base GUI framework for Ethernova plugins.
 * Subclasses define items via populateItems() and handle clicks via processAction().
 * Supports rainbow glass pane borders with animated disco effect (configurable via gui.rainbow-border).
 */
public abstract class CoreGui {

    protected static final Material[] RAINBOW_PANES = {
        Material.RED_STAINED_GLASS_PANE, Material.ORANGE_STAINED_GLASS_PANE,
        Material.YELLOW_STAINED_GLASS_PANE, Material.LIME_STAINED_GLASS_PANE,
        Material.GREEN_STAINED_GLASS_PANE, Material.CYAN_STAINED_GLASS_PANE,
        Material.LIGHT_BLUE_STAINED_GLASS_PANE, Material.BLUE_STAINED_GLASS_PANE,
        Material.PURPLE_STAINED_GLASS_PANE, Material.MAGENTA_STAINED_GLASS_PANE,
        Material.PINK_STAINED_GLASS_PANE, Material.WHITE_STAINED_GLASS_PANE
    };

    protected final EthernovaCore core;
    protected final Player player;
    protected final MiniMessage mini = MiniMessage.miniMessage();
    protected final Map<Integer, String> slotActions = new HashMap<>();
    protected final Set<Integer> protectedSlots = new HashSet<>();
    protected Inventory inventory;
    private int animationOffset = 0;
    private BukkitTask animationTask;
    private List<Integer> borderSlots;
    protected boolean trackProtected = false;

    protected CoreGui(EthernovaCore core, Player player) {
        this.core = core;
        this.player = player;
    }

    protected void openInventory(String title, int size) {
        stopAnimation();
        inventory = Bukkit.createInventory(null, size, deserializeText(replacePlaceholders(title)));
        slotActions.clear();
        protectedSlots.clear();
        trackProtected = false;
        fillBorders();
        trackProtected = true;
        populateItems();
        core.getGuiManager().registerGui(player, this);
        player.openInventory(inventory);
        startAnimation();

        // Item reveal animation (after inventory is shown)
        var animMgr = core.getGuiAnimationManager();
        if (animMgr != null && borderSlots != null) {
            animMgr.playItemReveal(player, inventory, protectedSlots, borderSlots);
        }
    }

    protected abstract void populateItems();

    protected abstract boolean processAction(String action, int slot, InventoryClickEvent event);

    /**
     * Deserialize text to a Component, auto-detecting legacy §-codes vs MiniMessage.
     * If the string contains § characters, it uses the legacy serializer;
     * otherwise it uses MiniMessage.
     */
    protected Component deserializeText(String text) {
        if (text == null || text.isEmpty()) return Component.empty();
        if (text.contains("§")) {
            return LegacyComponentSerializer.legacySection().deserialize(text);
        }
        return mini.deserialize(text);
    }

    public void handleClick(InventoryClickEvent event) {
        event.setCancelled(true);
        int slot = event.getRawSlot();
        String action = slotActions.get(slot);
        if (action == null) return;
        if ("CLOSE".equals(action)) {
            player.closeInventory();
            return;
        }
        processAction(action, slot, event);
    }

    protected void setItem(int slot, ItemStack item) {
        if (inventory != null && slot >= 0 && slot < inventory.getSize()) {
            inventory.setItem(slot, item);
            if (trackProtected) {
                protectedSlots.add(slot);
            }
        }
    }

    protected ItemStack createItem(Material material, String name) {
        return createItem(material, name, null);
    }

    protected ItemStack createItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(deserializeText(replacePlaceholders(name)));
            if (lore != null) {
                meta.lore(lore.stream()
                        .map(l -> deserializeText(replacePlaceholders(l)))
                        .collect(Collectors.toList()));
            }
            item.setItemMeta(meta);
        }
        return item;
    }

    protected void fillBorders() {
        if (inventory == null) return;
        boolean rainbow = core.getConfig().getBoolean("gui.rainbow-border", true);
        borderSlots = new ArrayList<>();
        for (int i = 0; i < inventory.getSize(); i++) {
            if (i < 9 || i >= inventory.getSize() - 9 || i % 9 == 0 || i % 9 == 8) {
                borderSlots.add(i);
                if (rainbow) {
                    Material mat = RAINBOW_PANES[(i + animationOffset) % RAINBOW_PANES.length];
                    inventory.setItem(i, createItem(mat, " "));
                } else {
                    inventory.setItem(i, createItem(Material.GRAY_STAINED_GLASS_PANE, " "));
                }
            }
        }
    }

    protected void startAnimation() {
        if (inventory == null || borderSlots == null || borderSlots.isEmpty()) return;
        if (!core.getConfig().getBoolean("gui.rainbow-border", true)) return;
        int speed = core.getConfig().getInt("gui.animation-speed", 4);
        if (speed <= 0) return;
        animationTask = Bukkit.getScheduler().runTaskTimer(core, () -> {
            if (inventory.getViewers().isEmpty()) {
                stopAnimation();
                return;
            }
            animationOffset++;
            for (int slot : borderSlots) {
                // Skip any border slot where a real item was placed
                if (protectedSlots.contains(slot)) continue;
                Material mat = RAINBOW_PANES[(slot + animationOffset) % RAINBOW_PANES.length];
                inventory.setItem(slot, createItem(mat, " "));
            }
        }, speed, speed);
    }

    public void stopAnimation() {
        if (animationTask != null) {
            animationTask.cancel();
            animationTask = null;
        }
        // Cancel GUI animations too
        var animMgr = core.getGuiAnimationManager();
        if (animMgr != null) {
            animMgr.cancelAnimations(player.getUniqueId());
        }
    }

    protected void playSound(String soundName) {
        try {
            switch (soundName.toLowerCase()) {
                case "click" -> player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, 1f);
                case "success" -> player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.5f, 1.5f);
                case "error" -> player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.5f, 1f);
                default -> {
                    Sound sound = Sound.valueOf(soundName.toUpperCase());
                    player.playSound(player.getLocation(), sound, 0.5f, 1f);
                }
            }
        } catch (IllegalArgumentException e) {
            core.getLogger().log(java.util.logging.Level.FINE, "Invalid sound name: " + soundName, e);
        }
    }

    protected String replacePlaceholders(String text) {
        if (text == null) return "";
        return text.replace("{player}", player.getName());
    }

    /** Called when a "BACK" action is triggered. Subclasses can override. */
    protected void onBack() {
        player.closeInventory();
    }

    public Player getPlayer() { return player; }
}
