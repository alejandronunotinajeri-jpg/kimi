package com.ethernova.core.hook;

import com.ethernova.core.EthernovaCore;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Integration hook for punishment plugins (LiteBans, AdvancedBan, BanManager).
 * Uses reflection to avoid hard compile-time dependencies.
 * <p>
 * All methods return safe defaults (false/null) if no punishment plugin is detected.
 * <p>
 * Configuration toggles in core config.yml:
 * <pre>
 * integrations:
 *   punishment:
 *     enabled: true
 *     block-clan-creation-if-banned: true
 *     block-party-invite-if-banned: true
 *     respect-mute-in-clan-chat: true
 * </pre>
 */
public class PunishmentHook {

    private enum Provider { NONE, LITEBANS, ADVANCEDBAN }

    private final EthernovaCore core;
    private final boolean enabled;
    private final boolean blockClanCreation;
    private final boolean blockPartyInvite;
    private final boolean respectMute;

    private Provider provider = Provider.NONE;

    // LiteBans reflection cache
    private Object liteBansDatabase;
    private Method liteBansIsBanned;
    private Method liteBansIsMuted;

    // AdvancedBan reflection cache
    private Class<?> abPunishmentManager;
    private Method abGetPunishment;
    private Method abGetMute;

    public PunishmentHook(EthernovaCore core) {
        this.core = core;
        this.enabled = core.getConfig().getBoolean("integrations.punishment.enabled", true);
        this.blockClanCreation = core.getConfig().getBoolean("integrations.punishment.block-clan-creation-if-banned", true);
        this.blockPartyInvite = core.getConfig().getBoolean("integrations.punishment.block-party-invite-if-banned", true);
        this.respectMute = core.getConfig().getBoolean("integrations.punishment.respect-mute-in-clan-chat", true);

        if (!enabled) return;

        detectProvider();
    }

    private void detectProvider() {
        // Try LiteBans first (most popular)
        Plugin liteBans = Bukkit.getPluginManager().getPlugin("LiteBans");
        if (liteBans != null && liteBans.isEnabled()) {
            try {
                Class<?> dbClass = Class.forName("litebans.api.Database");
                Method getInstance = dbClass.getMethod("get");
                liteBansDatabase = getInstance.invoke(null);
                liteBansIsBanned = dbClass.getMethod("isPlayerBanned", UUID.class, String.class);
                liteBansIsMuted = dbClass.getMethod("isPlayerMuted", UUID.class, String.class);
                provider = Provider.LITEBANS;
                core.getLogger().info("✔ PunishmentHook: LiteBans detectado");
                return;
            } catch (Exception e) {
                core.getLogger().log(Level.FINE, "LiteBans API load failed", e);
            }
        }

        // Try AdvancedBan
        Plugin advancedBan = Bukkit.getPluginManager().getPlugin("AdvancedBan");
        if (advancedBan != null && advancedBan.isEnabled()) {
            try {
                abPunishmentManager = Class.forName("me.leoko.advancedban.manager.PunishmentManager");
                Method getInst = abPunishmentManager.getMethod("get");
                abGetPunishment = abPunishmentManager.getMethod("getBan", String.class);
                abGetMute = abPunishmentManager.getMethod("getMute", String.class);
                provider = Provider.ADVANCEDBAN;
                core.getLogger().info("✔ PunishmentHook: AdvancedBan detectado");
                return;
            } catch (Exception e) {
                core.getLogger().log(Level.FINE, "AdvancedBan API load failed", e);
            }
        }

        core.getLogger().info("○ PunishmentHook: Ningún plugin de moderación detectado (opcional)");
    }

    // ══════════════════════════════════════════════════════════
    //  PUBLIC API
    // ══════════════════════════════════════════════════════════

    /**
     * Check if a player is currently banned.
     * Returns false if no punishment plugin is available.
     */
    public boolean isBanned(UUID uuid) {
        if (!enabled || provider == Provider.NONE) return false;
        try {
            return switch (provider) {
                case LITEBANS -> (boolean) liteBansIsBanned.invoke(liteBansDatabase, uuid, null);
                case ADVANCEDBAN -> {
                    Method getInst = abPunishmentManager.getMethod("get");
                    Object mgr = getInst.invoke(null);
                    Object result = abGetPunishment.invoke(mgr, uuid.toString().replace("-", ""));
                    yield result != null;
                }
                default -> false;
            };
        } catch (Exception e) {
            if (core.getConfig().getBoolean("general.debug", false)) {
                core.getLogger().log(Level.WARNING, "Error checking ban status for " + uuid, e);
            }
            return false;
        }
    }

    /**
     * Check if a player is currently muted.
     * Returns false if no punishment plugin is available.
     */
    public boolean isMuted(UUID uuid) {
        if (!enabled || provider == Provider.NONE) return false;
        try {
            return switch (provider) {
                case LITEBANS -> (boolean) liteBansIsMuted.invoke(liteBansDatabase, uuid, null);
                case ADVANCEDBAN -> {
                    Method getInst = abPunishmentManager.getMethod("get");
                    Object mgr = getInst.invoke(null);
                    Object result = abGetMute.invoke(mgr, uuid.toString().replace("-", ""));
                    yield result != null;
                }
                default -> false;
            };
        } catch (Exception e) {
            if (core.getConfig().getBoolean("general.debug", false)) {
                core.getLogger().log(Level.WARNING, "Error checking mute status for " + uuid, e);
            }
            return false;
        }
    }

    /**
     * Get the ban reason for a player. Returns null if not banned.
     */
    public String getBanReason(UUID uuid) {
        if (!enabled || provider == Provider.NONE) return null;
        try {
            return switch (provider) {
                case LITEBANS -> {
                    // LiteBans doesn't expose reason directly in simple API,
                    // so we just confirm they are banned
                    if (isBanned(uuid)) yield "Baneado (consulta /baninfo)";
                    yield null;
                }
                case ADVANCEDBAN -> {
                    Method getInst = abPunishmentManager.getMethod("get");
                    Object mgr = getInst.invoke(null);
                    Object punishment = abGetPunishment.invoke(mgr, uuid.toString().replace("-", ""));
                    if (punishment == null) yield null;
                    Method getReason = punishment.getClass().getMethod("getReason");
                    yield (String) getReason.invoke(punishment);
                }
                default -> null;
            };
        } catch (Exception e) {
            return null;
        }
    }

    // ══════════════════════════════════════════════════════════
    //  CONFIG QUERY METHODS (for modules to check policy)
    // ══════════════════════════════════════════════════════════

    /** Should clan creation be blocked if the player is banned? */
    public boolean shouldBlockClanCreation() { return enabled && blockClanCreation; }

    /** Should party invitations be blocked if the target is banned? */
    public boolean shouldBlockPartyInvite() { return enabled && blockPartyInvite; }

    /** Should muted players be prevented from using clan/party chat? */
    public boolean shouldRespectMute() { return enabled && respectMute; }

    /** Is any punishment provider detected? */
    public boolean isAvailable() { return provider != Provider.NONE; }

    /** Get the detected provider name. */
    public String getProviderName() {
        return switch (provider) {
            case LITEBANS -> "LiteBans";
            case ADVANCEDBAN -> "AdvancedBan";
            case NONE -> "Ninguno";
        };
    }

    /** Is the hook enabled in config? */
    public boolean isEnabled() { return enabled; }
}
