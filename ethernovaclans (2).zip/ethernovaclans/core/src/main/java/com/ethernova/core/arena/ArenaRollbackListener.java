package com.ethernova.core.arena;

import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;

/**
 * Bukkit listener that feeds block and entity changes into the {@link ArenaRollbackEngine}.
 * <p>
 * Captures:
 * <ul>
 *   <li>Block place / break</li>
 *   <li>Liquid flow ({@code BlockFromToEvent})</li>
 *   <li>Block explosions (entity + block)</li>
 *   <li>Fire spread and burn</li>
 *   <li>Block form (cobblestone from lava+water, obsidian, snow, ice)</li>
 *   <li>Block fade (ice melt, snow melt)</li>
 *   <li>Piston extend / retract</li>
 *   <li>Entity change block (falling sand, enderman, etc.)</li>
 *   <li>Entity spawn (end crystals, TNT, projectiles, items within arena)</li>
 * </ul>
 */
public class ArenaRollbackListener implements Listener {

    private final ArenaRollbackEngine engine;

    public ArenaRollbackListener(ArenaRollbackEngine engine) {
        this.engine = engine;
    }

    // ══════════════════════════════════════
    //  BLOCK EVENTS
    // ══════════════════════════════════════

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent e) {
        recordBlock(e.getBlock());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent e) {
        recordBlock(e.getBlock());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockFromTo(BlockFromToEvent e) {
        // Record the destination block (where liquid flows into)
        recordBlock(e.getToBlock());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        recordBlock(e.getBlock());
        for (Block b : e.blockList()) {
            recordBlock(b);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        for (Block b : e.blockList()) {
            recordBlock(b);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBurn(BlockBurnEvent e) {
        recordBlock(e.getBlock());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockSpread(BlockSpreadEvent e) {
        // Fire spread, mushroom growth, etc.
        recordBlock(e.getBlock());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockForm(BlockFormEvent e) {
        // Cobblestone from lava+water, obsidian, snow layers, ice
        recordBlock(e.getBlock());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockFade(BlockFadeEvent e) {
        // Ice melting, snow melting, farmland drying
        recordBlock(e.getBlock());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent e) {
        recordBlock(e.getBlock());
        for (Block b : e.getBlocks()) {
            recordBlock(b);
            // Also record destination
            recordBlock(b.getRelative(e.getDirection()));
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent e) {
        recordBlock(e.getBlock());
        for (Block b : e.getBlocks()) {
            recordBlock(b);
            recordBlock(b.getRelative(e.getDirection()));
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityChangeBlock(EntityChangeBlockEvent e) {
        // Falling sand landing, enderman placing/picking, wither breaking, etc.
        recordBlock(e.getBlock());
    }

    // ══════════════════════════════════════
    //  ENTITY EVENTS
    // ══════════════════════════════════════

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntitySpawn(EntitySpawnEvent e) {
        Entity entity = e.getEntity();
        if (entity instanceof Player) return;

        String arenaId = engine.findArenaForLocation(entity.getLocation());
        if (arenaId != null) {
            engine.recordEntity(arenaId, entity);
        }
    }

    // ══════════════════════════════════════
    //  HELPER
    // ══════════════════════════════════════

    private void recordBlock(Block block) {
        String arenaId = engine.findArenaForBlock(block);
        if (arenaId != null) {
            engine.recordBlockChange(arenaId, block);
        }
    }
}
