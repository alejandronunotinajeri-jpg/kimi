package com.ethernova.core.gui;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;

/**
 * Paginated GUI framework. Displays items in pages with navigation.
 * Subclasses provide items via getPageItems() and handle clicks via onItemClick().
 */
public abstract class PaginatedGui extends CoreGui {

    protected int currentPage = 0;
    protected int totalPages = 1;

    /** Slots available for paginated content (center of inventory, avoiding borders). */
    protected static final int[] CONTENT_SLOTS = {
        10, 11, 12, 13, 14, 15, 16,
        19, 20, 21, 22, 23, 24, 25,
        28, 29, 30, 31, 32, 33, 34,
        37, 38, 39, 40, 41, 42, 43
    };

    protected PaginatedGui(com.ethernova.core.EthernovaCore core, Player player) {
        super(core, player);
    }

    protected void openPaginated(String title, int page) {
        stopAnimation();
        this.currentPage = Math.max(0, page);
        List<PageItem> allItems = getPageItems();
        this.totalPages = Math.max(1, (int) Math.ceil((double) allItems.size() / CONTENT_SLOTS.length));
        if (currentPage >= totalPages) currentPage = totalPages - 1;

        slotActions.clear();
        protectedSlots.clear();
        trackProtected = false;
        inventory = Bukkit.createInventory(null, 54, mini.deserialize(replacePlaceholders(title)));
        fillBorders();
        trackProtected = true;

        // Place content items for current page
        int startIndex = currentPage * CONTENT_SLOTS.length;
        for (int i = 0; i < CONTENT_SLOTS.length; i++) {
            int dataIndex = startIndex + i;
            if (dataIndex < allItems.size()) {
                PageItem pi = allItems.get(dataIndex);
                setItem(CONTENT_SLOTS[i], pi.item);
                slotActions.put(CONTENT_SLOTS[i], pi.action);
            }
        }

        // Navigation
        if (currentPage > 0) {
            setItem(45, createItem(Material.ARROW, getPrevPageLabel()));
            slotActions.put(45, "PAGE_PREV");
        }

        setItem(49, createItem(Material.PAPER, getPageInfoLabel(currentPage + 1, totalPages)));

        if (currentPage < totalPages - 1) {
            setItem(53, createItem(Material.ARROW, getNextPageLabel()));
            slotActions.put(53, "PAGE_NEXT");
        }

        // Back button
        setItem(48, createItem(Material.BARRIER, getBackLabel()));
        slotActions.put(48, "BACK");

        // Hook for subclasses to add extra items
        onPostRender();

        core.getGuiManager().registerGui(player, this);
        player.openInventory(inventory);
        startAnimation();

        // Item reveal animation
        var animMgr = core.getGuiAnimationManager();
        if (animMgr != null) {
            animMgr.playItemReveal(player, inventory, protectedSlots, new java.util.ArrayList<>());
        }
    }

    @Override
    protected void populateItems() {
        // Handled by openPaginated
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        return switch (action) {
            case "PAGE_PREV" -> {
                playSound("click");
                openPaginated(getTitle(), currentPage - 1);
                yield true;
            }
            case "PAGE_NEXT" -> {
                playSound("click");
                openPaginated(getTitle(), currentPage + 1);
                yield true;
            }
            case "BACK" -> {
                playSound("click");
                onBack();
                yield true;
            }
            default -> onItemClick(action, slot, event);
        };
    }

    /** Return the title for the paginated inventory. */
    protected abstract String getTitle();

    /** Return ALL items across all pages. The framework handles pagination. */
    protected abstract List<PageItem> getPageItems();

    /** Handle a click on a content item. Return true if handled. */
    protected abstract boolean onItemClick(String action, int slot, InventoryClickEvent event);

    /** Override to customize navigation labels. */
    protected String getPrevPageLabel() { return "<yellow>◀ Página anterior"; }
    protected String getNextPageLabel() { return "<yellow>Página siguiente ▶"; }
    protected String getBackLabel() { return "<red>Volver"; }
    protected String getPageInfoLabel(int current, int total) { return "<gray>Página " + current + "/" + total; }

    /** Hook for subclasses to add extra items to the bottom bar after rendering. */
    protected void onPostRender() { }

    /**
     * A single item in a paginated list.
     */
    public static class PageItem {
        public final ItemStack item;
        public final String action;

        public PageItem(ItemStack item, String action) {
            this.item = item;
            this.action = action;
        }
    }
}
