package com.ethernova.core.server;

/**
 * Represents the detected or configured server-mode.
 * Plugins read this to adapt their features accordingly.
 */
public enum ServerMode {
    SURVIVAL,
    FFA,
    SKYBLOCK,
    LOBBY,
    CREATIVE,
    PRISON,
    PRACTICE,
    CUSTOM;

    public boolean isPvP() {
        return this == FFA || this == PRACTICE || this == SURVIVAL;
    }

    public boolean hasTerritory() {
        return this == SURVIVAL || this == SKYBLOCK;
    }

    public boolean hasEconomy() {
        return this != CREATIVE && this != LOBBY;
    }

    public boolean isMinigame() {
        return this == FFA || this == PRACTICE;
    }

    public static ServerMode fromString(String name) {
        if (name == null || name.isBlank()) return SURVIVAL;
        try {
            return valueOf(name.toUpperCase().trim());
        } catch (IllegalArgumentException e) {
            return CUSTOM;
        }
    }
}
