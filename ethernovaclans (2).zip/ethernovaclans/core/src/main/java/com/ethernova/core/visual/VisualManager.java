package com.ethernova.core.visual;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Enhanced visual effects manager. Provides:
 * - Boss bars (create, show, hide, auto-expire)
 * - Titles with configurable timings
 * - Timed action bars with auto-expiry
 * - Countdown sequences
 * - Particle effects
 */
public class VisualManager {

    private final MiniMessage mini = MiniMessage.miniMessage();
    private final Map<String, BossBar> bossBars = new ConcurrentHashMap<>();
    private final Map<UUID, BukkitTask> actionBarTasks = new ConcurrentHashMap<>();
    private JavaPlugin plugin;

    /**
     * Initialize with plugin reference for scheduler tasks.
     */
    public void init(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    // ─── Boss Bars ───

    public BossBar createBossBar(String id, String text, BossBar.Color color, float progress) {
        BossBar bar = BossBar.bossBar(mini.deserialize(text), progress, color, BossBar.Overlay.PROGRESS);
        BossBar old = bossBars.put(id, bar);
        if (old != null) {
            for (Player p : Bukkit.getOnlinePlayers()) p.hideBossBar(old);
        }
        return bar;
    }

    /**
     * Create a boss bar that auto-expires after a duration.
     */
    public BossBar createTimedBossBar(String id, String text, BossBar.Color color, long durationTicks) {
        BossBar bar = createBossBar(id, text, color, 1.0f);
        if (plugin != null && durationTicks > 0) {
            // Animated progress decrease
            final long startTick = Bukkit.getCurrentTick();
            BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
                long elapsed = Bukkit.getCurrentTick() - startTick;
                float progress = Math.max(0, 1.0f - (float) elapsed / durationTicks);
                bar.progress(progress);
                if (elapsed >= durationTicks) {
                    removeBossBar(id);
                }
            }, 1L, 1L);

            // Store task for cleanup
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                task.cancel();
                removeBossBar(id);
            }, durationTicks + 1);
        }
        return bar;
    }

    public BossBar getBossBar(String id) { return bossBars.get(id); }

    public void showBossBar(Player player, String id) {
        BossBar bar = bossBars.get(id);
        if (bar != null) player.showBossBar(bar);
    }

    public void hideBossBar(Player player, String id) {
        BossBar bar = bossBars.get(id);
        if (bar != null) player.hideBossBar(bar);
    }

    /**
     * Show a boss bar to all online players.
     */
    public void showBossBarAll(String id) {
        BossBar bar = bossBars.get(id);
        if (bar != null) {
            for (Player p : Bukkit.getOnlinePlayers()) p.showBossBar(bar);
        }
    }

    /**
     * Update boss bar text dynamically.
     */
    public void updateBossBar(String id, String text) {
        BossBar bar = bossBars.get(id);
        if (bar != null) bar.name(mini.deserialize(text));
    }

    /**
     * Update boss bar progress (0.0 to 1.0).
     */
    public void updateBossBarProgress(String id, float progress) {
        BossBar bar = bossBars.get(id);
        if (bar != null) bar.progress(Math.max(0, Math.min(1, progress)));
    }

    public void removeBossBar(String id) {
        BossBar bar = bossBars.remove(id);
        if (bar != null) {
            for (Player viewer : Bukkit.getOnlinePlayers()) {
                viewer.hideBossBar(bar);
            }
        }
    }

    public void removeAllBossBars() {
        for (BossBar bar : bossBars.values()) {
            for (Player viewer : Bukkit.getOnlinePlayers()) {
                viewer.hideBossBar(bar);
            }
        }
        bossBars.clear();
    }

    // ─── Titles ───

    public void sendTitle(Player player, String title, String subtitle) {
        player.showTitle(Title.title(mini.deserialize(title), mini.deserialize(subtitle)));
    }

    /**
     * Send title with custom timings (in ticks).
     */
    public void sendTitle(Player player, String title, String subtitle,
                          int fadeInTicks, int stayTicks, int fadeOutTicks) {
        player.showTitle(Title.title(
                mini.deserialize(title),
                mini.deserialize(subtitle),
                Title.Times.times(
                        Duration.ofMillis(fadeInTicks * 50L),
                        Duration.ofMillis(stayTicks * 50L),
                        Duration.ofMillis(fadeOutTicks * 50L))));
    }

    /**
     * Run a countdown title sequence (3, 2, 1, GO!).
     * @param player     Target player
     * @param seconds    Countdown from N to 1
     * @param goMessage  Message shown at the end (e.g., "¡GO!")
     * @param onComplete Runnable executed when countdown finishes (on main thread)
     */
    public void sendCountdown(Player player, int seconds, String goMessage, Runnable onComplete) {
        if (plugin == null) return;
        for (int i = seconds; i >= 1; i--) {
            final int count = i;
            String color = count <= 1 ? "<green>" : count <= 2 ? "<yellow>" : "<red>";
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!player.isOnline()) return;
                sendTitle(player, color + "<bold>" + count, "", 2, 18, 0);
                player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_NOTE_BLOCK_PLING, 0.8f, 1.0f);
            }, (long) (seconds - count) * 20L);
        }
        // Final "GO!" message
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) return;
            sendTitle(player, "<green><bold>" + goMessage, "", 0, 20, 10);
            player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.5f);
            if (onComplete != null) onComplete.run();
        }, (long) seconds * 20L);
    }

    /**
     * Run countdown for all online players.
     */
    public void sendCountdownAll(int seconds, String goMessage, Runnable onComplete) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            sendCountdown(player, seconds, goMessage, null);
        }
        if (plugin != null && onComplete != null) {
            Bukkit.getScheduler().runTaskLater(plugin, onComplete, (long) seconds * 20L);
        }
    }

    // ─── Action Bar ───

    public void sendActionBar(Player player, String message) {
        player.sendActionBar(mini.deserialize(message));
    }

    /**
     * Send an action bar that persists for a duration (re-sent every second).
     * @param player       Target player
     * @param message      MiniMessage text
     * @param durationTicks Duration in ticks (20 = 1 second)
     */
    public void sendTimedActionBar(Player player, String message, long durationTicks) {
        if (plugin == null) {
            sendActionBar(player, message);
            return;
        }

        UUID uuid = player.getUniqueId();
        // Cancel existing timed actionbar
        BukkitTask existing = actionBarTasks.remove(uuid);
        if (existing != null) existing.cancel();

        final long endTick = Bukkit.getCurrentTick() + durationTicks;
        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, new Runnable() {
            @Override
            public void run() {
                Player p = Bukkit.getPlayer(uuid);
                if (p == null || !p.isOnline() || Bukkit.getCurrentTick() >= endTick) {
                    BukkitTask t = actionBarTasks.remove(uuid);
                    if (t != null) t.cancel();
                    return;
                }
                p.sendActionBar(mini.deserialize(message));
            }
        }, 0L, 15L); // Re-send every 15 ticks (~0.75s)

        actionBarTasks.put(uuid, task);

        // Auto-cleanup
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            BukkitTask t = actionBarTasks.remove(uuid);
            if (t != null) t.cancel();
        }, durationTicks + 1);
    }

    /**
     * Clear any timed action bar for a player.
     */
    public void clearActionBar(Player player) {
        BukkitTask task = actionBarTasks.remove(player.getUniqueId());
        if (task != null) task.cancel();
        player.sendActionBar(mini.deserialize(""));
    }

    // ─── Particle Effects ───

    public void spawnLightning(Location location) {
        if (location.getWorld() != null) location.getWorld().strikeLightningEffect(location);
    }

    public void spawnBloodEffect(Location location) {
        if (location.getWorld() == null) return;
        location.getWorld().spawnParticle(org.bukkit.Particle.BLOCK, location.clone().add(0, 1, 0),
                30, 0.3, 0.5, 0.3, 0.1, org.bukkit.Material.REDSTONE_BLOCK.createBlockData());
    }

    /**
     * Cleanup all scheduled tasks.
     */
    public void cleanup() {
        for (BukkitTask task : actionBarTasks.values()) {
            task.cancel();
        }
        actionBarTasks.clear();
        removeAllBossBars();
    }
}
