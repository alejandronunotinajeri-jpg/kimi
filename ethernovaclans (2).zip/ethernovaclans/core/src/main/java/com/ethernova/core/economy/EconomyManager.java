package com.ethernova.core.economy;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.profile.PlayerProfile;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Advanced economy manager with earning sources, multiplier stacking,
 * inflation control, and rich tax. Wraps EconomyHook for Vault integration.
 */
public class EconomyManager {

    private final EthernovaCore core;
    private final MiniMessage mini = MiniMessage.miniMessage();

    /** Active multipliers per type. */
    private final Map<MultiplierType, Double> globalMultipliers = new EnumMap<>(MultiplierType.class);

    /** Per-player temporary multipliers (boosts). */
    private final Map<UUID, Map<MultiplierType, BoostEntry>> playerBoosts = new ConcurrentHashMap<>();

    /** Economy config values. */
    private double richThreshold = 100_000;
    private double richTaxRate = 0.02; // 2% tax per earning above threshold
    private double inflationCap = 5.0; // Max combined multiplier
    private boolean taxEnabled = true;

    /**
     * Sources of income with base amounts.
     */
    public enum EarningSource {
        // Combat
        KILL(50, "Kill"),
        ASSIST(20, "Asistencia"),
        STREAK_3(75, "Racha x3"),
        STREAK_5(150, "Racha x5"),
        STREAK_10(400, "Racha x10"),
        STREAK_15(750, "Racha x15"),
        STREAK_20(1500, "Racha x20"),
        STREAK_25(3000, "Racha x25"),
        HEADSHOT(15, "Headshot"),
        MULTIKILL_DOUBLE(30, "Doble Kill"),
        MULTIKILL_TRIPLE(60, "Triple Kill"),
        MULTIKILL_QUAD(100, "Cuádruple Kill"),
        MULTIKILL_PENTA(200, "Penta Kill"),
        BOUNTY_COLLECTED(0, "Recompensa Cobrada"), // variable amount
        FIRST_BLOOD(100, "Primera Sangre"),

        // Events
        EVENT_WIN(5000, "Ganar Evento"),
        EVENT_PARTICIPATION(500, "Participar en Evento"),
        EVENT_TOP3(2000, "Top 3 Evento"),

        // Economy
        VOTE(200, "Voto"),
        DAILY_REWARD(0, "Recompensa Diaria"), // variable
        MISSION_COMPLETE(0, "Misión Completa"), // variable
        ACHIEVEMENT_REWARD(0, "Logro"), // variable
        BATTLEPASS_REWARD(0, "Pase de Batalla"), // variable
        LEVEL_UP(0, "Subir de Nivel"), // variable

        // Party
        PARTY_GAME_WIN(300, "Ganar Juego de Party"),
        PARTY_GAME_PARTICIPATION(50, "Participar Juego de Party"),

        // Duels
        DUEL_WIN(200, "Ganar Duelo"),
        RANKED_WIN(500, "Ganar Ranked"),
        RANKED_LOSS(50, "Derrota Ranked"),

        // Misc
        REFERRAL(1000, "Referido"),
        PLAYTIME_BONUS(25, "Bonus Tiempo de Juego"),
        MYSTERY_BOX(0, "Caja Misteriosa"), // variable
        TOURNAMENT_WIN(10000, "Ganar Torneo"),
        TOURNAMENT_TOP3(5000, "Top 3 Torneo"),
        LOOT_PICKUP(10, "Loot Recogido"),
        CUSTOM(0, "Personalizado"); // variable amount

        private final double baseAmount;
        private final String displayName;

        EarningSource(double baseAmount, String displayName) {
            this.baseAmount = baseAmount;
            this.displayName = displayName;
        }

        public double getBaseAmount() { return baseAmount; }
        public String getDisplayName() { return displayName; }
    }

    /**
     * Types of multipliers that stack multiplicatively.
     */
    public enum MultiplierType {
        EVENT("Evento"),
        PRESTIGE("Prestigio"),
        BOOST("Boost"),
        CLAN("Clan");

        private final String displayName;
        MultiplierType(String displayName) { this.displayName = displayName; }
        public String getDisplayName() { return displayName; }
    }

    private record BoostEntry(double multiplier, long expiresAt) {
        boolean isExpired() { return System.currentTimeMillis() >= expiresAt; }
    }

    public EconomyManager(EthernovaCore core) {
        this.core = core;
        loadConfig();
        // Initialize default global multipliers
        for (MultiplierType type : MultiplierType.values()) {
            globalMultipliers.put(type, 1.0);
        }
    }

    private void loadConfig() {
        var config = core.getConfig();
        richThreshold = config.getDouble("economy.rich-threshold", 100_000);
        richTaxRate = config.getDouble("economy.rich-tax-rate", 0.02);
        inflationCap = config.getDouble("economy.inflation-cap", 5.0);
        taxEnabled = config.getBoolean("economy.tax-enabled", true);
    }

    /**
     * Give money to a player from a specific source, applying all multipliers.
     * @return The actual amount given after multipliers and tax.
     */
    public double giveMoney(Player player, EarningSource source) {
        return giveMoney(player, source, source.getBaseAmount());
    }

    /**
     * Give a custom amount from a specific source, applying all multipliers.
     * @return The actual amount given after multipliers and tax.
     */
    public double giveMoney(Player player, EarningSource source, double baseAmount) {
        if (baseAmount <= 0) return 0;
        UUID uuid = player.getUniqueId();

        // Calculate combined multiplier
        double combinedMultiplier = getCombinedMultiplier(uuid);

        // Apply multiplier with inflation cap
        double finalAmount = baseAmount * Math.min(combinedMultiplier, inflationCap);

        // Apply rich tax
        if (taxEnabled) {
            PlayerProfile profile = core.getProfileManager().getProfile(uuid);
            if (profile != null && profile.getCoins() >= richThreshold) {
                double taxAmount = finalAmount * richTaxRate;
                finalAmount -= taxAmount;
            }
        }

        // Round to 2 decimals
        finalAmount = Math.round(finalAmount * 100.0) / 100.0;

        // Give via Vault (single source of truth for economy)
        if (finalAmount > 0) {
            EconomyHook hook = core.getEconomyHook();
            if (hook.isEnabled()) {
                hook.deposit(player, finalAmount);
            }
        }

        return finalAmount;
    }

    /**
     * Get the combined multiplier for a player from all sources.
     */
    public double getCombinedMultiplier(UUID uuid) {
        double multiplier = 1.0;

        // Global multipliers
        for (var entry : globalMultipliers.entrySet()) {
            multiplier *= entry.getValue();
        }

        // Player-specific boosts
        Map<MultiplierType, BoostEntry> boosts = playerBoosts.get(uuid);
        if (boosts != null) {
            Iterator<Map.Entry<MultiplierType, BoostEntry>> it = boosts.entrySet().iterator();
            while (it.hasNext()) {
                var entry = it.next();
                if (entry.getValue().isExpired()) {
                    it.remove();
                } else {
                    multiplier *= entry.getValue().multiplier();
                }
            }
        }

        // Core boost manager (stacks with the above)
        double boostManagerMultiplier = core.getBoostManager().getMultiplier("money");
        multiplier *= boostManagerMultiplier;

        return multiplier;
    }

    /**
     * Set a global multiplier for a type.
     */
    public void setGlobalMultiplier(MultiplierType type, double multiplier) {
        globalMultipliers.put(type, multiplier);
    }

    /**
     * Reset a global multiplier back to 1.0.
     */
    public void resetGlobalMultiplier(MultiplierType type) {
        globalMultipliers.put(type, 1.0);
    }

    /**
     * Get the current global multiplier for a type.
     */
    public double getGlobalMultiplier(MultiplierType type) {
        return globalMultipliers.getOrDefault(type, 1.0);
    }

    /**
     * Purchase a personal boost for a player.
     * @param player The player
     * @param type The multiplier type
     * @param multiplier The multiplier value (e.g. 2.0 for 2x)
     * @param durationMinutes Duration in minutes
     * @param cost Cost in coins
     * @return true if purchased successfully
     */
    public boolean purchaseBoost(Player player, MultiplierType type, double multiplier,
                                  int durationMinutes, double cost) {
        UUID uuid = player.getUniqueId();
        PlayerProfile profile = core.getProfileManager().getProfile(uuid);
        if (profile == null || profile.getCoins() < cost) {
            player.sendMessage(mini.deserialize("<red>No tienes suficientes monedas. Necesitas " +
                    String.format("%.0f", cost) + " monedas."));
            return false;
        }

        // Check if player already has this boost type
        Map<MultiplierType, BoostEntry> boosts = playerBoosts.computeIfAbsent(uuid, k -> new EnumMap<>(MultiplierType.class));
        BoostEntry existing = boosts.get(type);
        if (existing != null && !existing.isExpired()) {
            player.sendMessage(mini.deserialize("<red>Ya tienes un boost de " + type.getDisplayName() +
                    " activo. Espera a que expire."));
            return false;
        }

        // Deduct cost via Vault (single source of truth)
        EconomyHook hook = core.getEconomyHook();
        if (hook.isEnabled()) {
            if (!hook.withdraw(player, cost)) {
                player.sendMessage(mini.deserialize("<red>No se pudo descontar el costo."));
                return false;
            }
        } else {
            profile.addCoins(-cost);
        }

        // Apply boost
        long expiresAt = System.currentTimeMillis() + (durationMinutes * 60_000L);
        boosts.put(type, new BoostEntry(multiplier, expiresAt));

        player.sendMessage(mini.deserialize(
                "<green>✔ <yellow>Boost " + type.getDisplayName() + " x" +
                        String.format("%.1f", multiplier) + " activado por " + durationMinutes + " minutos!"));
        core.getSoundManager().play(player, "success");

        return true;
    }

    /**
     * Give a free boost to a player (no cost).
     */
    public void grantBoost(UUID uuid, MultiplierType type, double multiplier, int durationMinutes) {
        Map<MultiplierType, BoostEntry> boosts = playerBoosts.computeIfAbsent(uuid, k -> new EnumMap<>(MultiplierType.class));
        long expiresAt = System.currentTimeMillis() + (durationMinutes * 60_000L);
        boosts.put(type, new BoostEntry(multiplier, expiresAt));
    }

    /**
     * Check if a player has an active boost of a type.
     */
    public boolean hasActiveBoost(UUID uuid, MultiplierType type) {
        Map<MultiplierType, BoostEntry> boosts = playerBoosts.get(uuid);
        if (boosts == null) return false;
        BoostEntry entry = boosts.get(type);
        return entry != null && !entry.isExpired();
    }

    /**
     * Get remaining time of a boost in seconds.
     */
    public long getBoostRemainingSeconds(UUID uuid, MultiplierType type) {
        Map<MultiplierType, BoostEntry> boosts = playerBoosts.get(uuid);
        if (boosts == null) return 0;
        BoostEntry entry = boosts.get(type);
        if (entry == null || entry.isExpired()) return 0;
        return (entry.expiresAt() - System.currentTimeMillis()) / 1000;
    }

    /**
     * Get a formatted display of all active multipliers for a player.
     */
    public List<String> getMultiplierInfo(UUID uuid) {
        List<String> info = new ArrayList<>();
        double total = 1.0;

        for (MultiplierType type : MultiplierType.values()) {
            double global = globalMultipliers.getOrDefault(type, 1.0);
            if (global != 1.0) {
                info.add("<yellow>" + type.getDisplayName() + " (Global): <white>x" + String.format("%.1f", global));
                total *= global;
            }
        }

        Map<MultiplierType, BoostEntry> boosts = playerBoosts.get(uuid);
        if (boosts != null) {
            for (var entry : boosts.entrySet()) {
                if (!entry.getValue().isExpired()) {
                    long remaining = (entry.getValue().expiresAt() - System.currentTimeMillis()) / 1000;
                    String time = remaining > 60 ? (remaining / 60) + "m" : remaining + "s";
                    info.add("<aqua>" + entry.getKey().getDisplayName() + " (Personal): <white>x" +
                            String.format("%.1f", entry.getValue().multiplier()) + " <gray>(" + time + ")");
                    total *= entry.getValue().multiplier();
                }
            }
        }

        info.add(" ");
        info.add("<gold>Multiplicador Total: <white>x" + String.format("%.2f", Math.min(total, inflationCap)));
        if (total > inflationCap) {
            info.add("<red>(Limitado por cap de inflación: x" + String.format("%.1f", inflationCap) + ")");
        }

        return info;
    }

    /**
     * Clean up expired boosts for a player.
     */
    public void cleanupPlayer(UUID uuid) {
        playerBoosts.remove(uuid);
    }

    /**
     * Get the rich threshold.
     */
    public double getRichThreshold() { return richThreshold; }

    /**
     * Get the rich tax rate.
     */
    public double getRichTaxRate() { return richTaxRate; }
}
