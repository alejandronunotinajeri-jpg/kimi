# EthernovaFFA

> Free-For-All: arenas multijugador de combate libre.

## Características

- **Arenas FFA** — Múltiples arenas con spawns configurables
- **Kits** — Kits predefinidos con armadura, armas y efectos
- **Spawn Protection** — Protección temporal al spawnear (invulnerabilidad + partículas)
- **Estadísticas** — Kills, deaths, KDR, rachas, tiempo de juego
- **Leaderboards** — Rankings globales por kills
- **Sesiones** — Tracking de sesión (kills/deaths por sesión)
- **Admin** — Crear/eliminar arenas, configurar spawns por GUI

## API

```java
FFAAPI api = ServiceRegistry.get(FFAAPI.class);
api.isInFFA(uuid);
api.getPlayerArena(uuid);
api.getPlayerKillStreak(uuid);
api.getPlayerCount("arena1");
api.getTotalPlayers();
api.getFFAKills(uuid);
api.getKDR(uuid);
api.isSpawnProtected(uuid);
api.getEnabledArenaNames();
```

## Comandos

| Comando | Descripción |
|---------|-------------|
| `/ffa join <arena>` | Unirse a una arena |
| `/ffa leave` | Salir del FFA |
| `/ffa list` | Listar arenas |
| `/ffa stats` | Ver estadísticas |
| `/ffa kit <kit>` | Cambiar kit |
| `/ffaadmin` | Panel de administración |

## Placeholders

| Placeholder | Descripción |
|-------------|-------------|
| `%ethernova_ffa_kills%` | Kills totales |
| `%ethernova_ffa_deaths%` | Deaths totales |
| `%ethernova_ffa_kdr%` | Kill/Death ratio |
| `%ethernova_ffa_streak%` | Mejor racha |
| `%ethernova_ffa_arena%` | Arena actual |
