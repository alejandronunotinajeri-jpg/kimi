package com.ethernova.ffa.gui;

import com.ethernova.core.gui.CoreGui;
import com.ethernova.ffa.EthernovaFFA;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/**
 * Admin GUI for EthernovaFFA — full in-game configuration.
 * Permission: ethernova.ffa.admin
 */
public class FFAAdminGui extends CoreGui {

    private final EthernovaFFA plugin;
    private int page = 0;
    private static final int MAX_PAGES = 2;

    public FFAAdminGui(EthernovaFFA plugin, Player player) {
        super(plugin.getCore(), player);
        this.plugin = plugin;
    }

    public void open() {
        openInventory("<gradient:#FC466B:#3F5EFB>⚙ FFA Admin</gradient> <gray>(Pág. " + (page + 1) + "/" + MAX_PAGES + ")", 54);
    }

    @Override
    protected void populateItems() {
        // ── Back ──
        setItem(48, createItem(Material.ARROW, "<gray>← Volver"));
        slotActions.put(48, "BACK");

        if (page == 0) populatePage1();
        else populatePage2();

        // ═══ Navigation ═══
        if (page > 0) {
            setItem(45, createItem(Material.ARROW, "<yellow>← Página Anterior"));
            slotActions.put(45, "PREV_PAGE");
        }
        if (page < MAX_PAGES - 1) {
            setItem(53, createItem(Material.ARROW, "<yellow>Página Siguiente →"));
            slotActions.put(53, "NEXT_PAGE");
        }

        setItem(49, createItem(Material.COMMAND_BLOCK,
                "<green>⟳ Recargar Config", List.of("<gray>Recarga config.yml y mensajes")));
        slotActions.put(49, "RELOAD");
    }

    private void populatePage1() {
        setItem(4, createItem(Material.NETHERITE_SWORD,
                "<gold><bold>⚙ FFA Config",
                List.of("<gray>Página 1: General, Respawn y Recompensas")));

        // ═══ Row 1: General ═══
        setItem(10, createItem(Material.RED_STAINED_GLASS_PANE, "<red><bold>General"));

        setItem(11, toggleItem("Auto-Join", "general.auto-join"));
        slotActions.put(11, "TOGGLE:general.auto-join");

        setItem(12, numberItem(Material.PLAYER_HEAD, "Max Players", "general.max-global-players", ""));
        slotActions.put(12, "INT:general.max-global-players:0:200");

        setItem(13, createItem(Material.WRITABLE_BOOK,
                "<yellow>Idioma: <white>" + plugin.getConfig().getString("general.language", "es"),
                List.of("<yellow>Click para cambiar")));
        slotActions.put(13, "CYCLE_LANG");

        // ═══ Row 1 continued: Respawn ═══
        setItem(15, createItem(Material.CYAN_STAINED_GLASS_PANE, "<aqua><bold>Respawn"));

        setItem(16, numberItem(Material.CLOCK, "Respawn Delay", "respawn.delay-ticks", "ticks"));
        slotActions.put(16, "INT:respawn.delay-ticks:0:200");

        // ═══ Row 2: Respawn continued ═══
        setItem(19, numberItem(Material.SHIELD, "Spawn Protection", "respawn.spawn-protection-seconds", "seg"));
        slotActions.put(19, "INT:respawn.spawn-protection-seconds:0:60");

        setItem(20, toggleItem("Glowing Protection", "respawn.glowing-on-protection"));
        slotActions.put(20, "TOGGLE:respawn.glowing-on-protection");

        // ═══ Row 2 continued: Kits ═══
        setItem(22, createItem(Material.YELLOW_STAINED_GLASS_PANE, "<yellow><bold>Kits"));

        setItem(23, toggleItem("Kit Change Alive", "kits.allow-kit-change-alive"));
        slotActions.put(23, "TOGGLE:kits.allow-kit-change-alive");

        setItem(24, createItem(Material.DIAMOND_CHESTPLATE,
                "<gold>Default Kit: <white>" + plugin.getConfig().getString("kits.default-kit", "warrior"),
                List.of("<gray>Kit por defecto al entrar",
                        "",
                        "<yellow>Click para cambiar")));
        slotActions.put(24, "CYCLE_KIT");

        // ═══ Row 3: Rewards ═══
        setItem(28, createItem(Material.GREEN_STAINED_GLASS_PANE, "<green><bold>Recompensas"));

        setItem(29, doubleItem(Material.GOLD_INGOT, "Coins/Kill", "rewards.coins-per-kill", "$"));
        slotActions.put(29, "DOUBLE:rewards.coins-per-kill:0.0:10000.0");

        setItem(30, numberItem(Material.EXPERIENCE_BOTTLE, "XP/Kill", "rewards.xp-per-kill", "XP"));
        slotActions.put(30, "INT:rewards.xp-per-kill:0:1000");

        setItem(31, doubleItem(Material.DIAMOND, "Coins/Streak", "rewards.coins-per-streak-milestone", "$"));
        slotActions.put(31, "DOUBLE:rewards.coins-per-streak-milestone:0.0:10000.0");

        setItem(32, numberItem(Material.NETHER_STAR, "XP/Streak", "rewards.xp-per-streak-milestone", "XP"));
        slotActions.put(32, "INT:rewards.xp-per-streak-milestone:0:5000");

        // ═══ Row 3 continued: Killstreaks ═══
        setItem(34, createItem(Material.MAGENTA_STAINED_GLASS_PANE, "<light_purple><bold>Killstreaks"));

        // ═══ Row 4: Killstreaks ═══
        setItem(37, numberItem(Material.BLAZE_POWDER, "Milestone Interval", "killstreak.milestone-interval", "kills"));
        slotActions.put(37, "INT:killstreak.milestone-interval:1:50");

        setItem(38, toggleItem("Broadcast Streaks", "killstreak.broadcast"));
        slotActions.put(38, "TOGGLE:killstreak.broadcast");

        // ═══ Row 4 continued: Quick Management ═══
        setItem(41, createItem(Material.GRASS_BLOCK,
                "<green><bold>⚔ Gestionar Arenas",
                List.of("", "<dark_gray>▎ <gray>Ver, crear y eliminar arenas FFA",
                        "", "<yellow>▶ Click para abrir")));
        slotActions.put(41, "ARENA_LIST");

        setItem(42, createItem(Material.DIAMOND_CHESTPLATE,
                "<light_purple><bold>🛡 Gestionar Kits",
                List.of("", "<dark_gray>▎ <gray>Ver, crear y eliminar kits FFA",
                        "", "<yellow>▶ Click para abrir")));
        slotActions.put(42, "KIT_LIST");
    }

    private void populatePage2() {
        setItem(4, createItem(Material.NETHERITE_SWORD,
                "<gold><bold>⚙ FFA Config",
                List.of("<gray>Página 2: Protecciones")));

        // ═══ Row 1: Protection ═══
        setItem(10, createItem(Material.PURPLE_STAINED_GLASS_PANE, "<light_purple><bold>Protecciones"));

        setItem(11, toggleItem("Block Break", "protection.prevent-block-break"));
        slotActions.put(11, "TOGGLE:protection.prevent-block-break");

        setItem(12, toggleItem("Block Place", "protection.prevent-block-place"));
        slotActions.put(12, "TOGGLE:protection.prevent-block-place");

        setItem(13, toggleItem("Hunger", "protection.prevent-hunger"));
        slotActions.put(13, "TOGGLE:protection.prevent-hunger");

        setItem(14, toggleItem("Item Drop", "protection.prevent-item-drop"));
        slotActions.put(14, "TOGGLE:protection.prevent-item-drop");

        setItem(15, toggleItem("Item Pickup", "protection.prevent-item-pickup"));
        slotActions.put(15, "TOGGLE:protection.prevent-item-pickup");

        setItem(16, toggleItem("Fall Damage", "protection.prevent-fall-damage"));
        slotActions.put(16, "TOGGLE:protection.prevent-fall-damage");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.startsWith("TOGGLE:")) {
            String path = action.substring(7);
            plugin.getConfig().set(path, !plugin.getConfig().getBoolean(path, false));
            plugin.saveConfig();
            refresh();
            return true;
        }
        if (action.startsWith("INT:")) {
            String[] parts = action.substring(4).split(":");
            adjustInt(parts[0], event, Integer.parseInt(parts[1]), Integer.parseInt(parts[2]));
            return true;
        }
        if (action.startsWith("DOUBLE:")) {
            String[] parts = action.substring(7).split(":");
            adjustDouble(parts[0], event, Double.parseDouble(parts[1]), Double.parseDouble(parts[2]));
            return true;
        }
        return switch (action) {
            case "PREV_PAGE" -> { page = Math.max(0, page - 1); refresh(); yield true; }
            case "NEXT_PAGE" -> { page = Math.min(MAX_PAGES - 1, page + 1); refresh(); yield true; }
            case "CYCLE_LANG" -> {
                String current = plugin.getConfig().getString("general.language", "es");
                plugin.getConfig().set("general.language", "es".equals(current) ? "en" : "es");
                plugin.saveConfig();
                refresh();
                yield true;
            }
            case "CYCLE_KIT" -> {
                var kitNames = plugin.getKitManager().getKitIds();
                if (!kitNames.isEmpty()) {
                    String current = plugin.getConfig().getString("kits.default-kit", "warrior");
                    var nameList = new java.util.ArrayList<>(kitNames);
                    int idx = nameList.indexOf(current);
                    String next = nameList.get((idx + 1) % nameList.size());
                    plugin.getConfig().set("kits.default-kit", next);
                    plugin.saveConfig();
                }
                refresh();
                yield true;
            }
            case "ARENA_LIST" -> {
                playSound("click");
                player.closeInventory();
                Bukkit.getScheduler().runTaskLater(plugin, () -> new FFAArenaListGui(plugin, player).open(), 1L);
                yield true;
            }
            case "KIT_LIST" -> {
                playSound("click");
                player.closeInventory();
                Bukkit.getScheduler().runTaskLater(plugin, () -> new FFAKitListGui(plugin, player).open(), 1L);
                yield true;
            }
            case "RELOAD" -> {
                plugin.reloadConfig();
                plugin.getArenaManager().loadArenas();
                plugin.getKitManager().loadKits();
                plugin.getMessageManager().load();
                playSound("success");
                player.closeInventory();
                player.sendMessage(mini.deserialize("<green>✔ Configuración de FFA recargada."));
                yield true;
            }
            case "BACK" -> {
                playSound("click");
                player.closeInventory();
                Bukkit.getScheduler().runTaskLater(plugin, () -> player.performCommand("ethernova admin"), 2L);
                yield true;
            }
            default -> false;
        };
    }

    // ═══════════════ Helpers ═══════════════

    private void adjustInt(String path, InventoryClickEvent event, int min, int max) {
        int current = plugin.getConfig().getInt(path, 0);
        int delta = event.isShiftClick() ? 10 : 1;
        if (event.isRightClick()) delta = -delta;
        plugin.getConfig().set(path, Math.max(min, Math.min(max, current + delta)));
        plugin.saveConfig();
        refresh();
    }

    private void adjustDouble(String path, InventoryClickEvent event, double min, double max) {
        double current = plugin.getConfig().getDouble(path, 0);
        double delta = event.isShiftClick() ? 10.0 : 1.0;
        if (event.isRightClick()) delta = -delta;
        double newVal = Math.round(Math.max(min, Math.min(max, current + delta)) * 100.0) / 100.0;
        plugin.getConfig().set(path, newVal);
        plugin.saveConfig();
        refresh();
    }

    private void refresh() {
        playSound("click");
        player.closeInventory();
        Bukkit.getScheduler().runTaskLater(plugin, this::open, 1L);
    }

    private ItemStack toggleItem(String name, String path) {
        boolean val = plugin.getConfig().getBoolean(path, false);
        return createItem(val ? Material.LIME_DYE : Material.GRAY_DYE,
                (val ? "<green>✔ " : "<red>✘ ") + name,
                List.of("<gray>Estado: " + (val ? "<green>Activado" : "<red>Desactivado"),
                        "", "<yellow>Click para " + (val ? "desactivar" : "activar")));
    }

    private ItemStack numberItem(Material mat, String name, String path, String unit) {
        int val = plugin.getConfig().getInt(path, 0);
        String suffix = unit.isEmpty() ? "" : " " + unit;
        return createItem(mat, "<gold>" + name + ": <white>" + val + suffix,
                List.of("<gray>Click izq: <green>+1", "<gray>Click der: <red>-1",
                        "<gray>Shift+Click: <yellow>±10"));
    }

    private ItemStack doubleItem(Material mat, String name, String path, String unit) {
        double val = plugin.getConfig().getDouble(path, 0);
        String suffix = unit.isEmpty() ? "" : " " + unit;
        return createItem(mat, "<gold>" + name + ": <white>" + String.format("%.1f", val) + suffix,
                List.of("<gray>Click izq: <green>+1", "<gray>Click der: <red>-1",
                        "<gray>Shift+Click: <yellow>±10"));
    }
}
