package com.ethernova.ffa.model;

import org.bukkit.Location;

import java.util.UUID;

/**
 * Active FFA player session state. In-memory only, not persisted.
 */
public class FFAPlayer {

    private final UUID uuid;
    private final String arenaName;
    private int kills;
    private int deaths;
    private int killStreak;
    private final long joinTime;
    private boolean alive;
    private Location lastDeathLoc;
    private String selectedKit;

    public FFAPlayer(UUID uuid, String arenaName) {
        this.uuid = uuid;
        this.arenaName = arenaName;
        this.kills = 0;
        this.deaths = 0;
        this.killStreak = 0;
        this.joinTime = System.currentTimeMillis();
        this.alive = true;
        this.lastDeathLoc = null;
        this.selectedKit = null;
    }

    public UUID getUuid() { return uuid; }
    public String getArenaName() { return arenaName; }

    public int getKills() { return kills; }
    public void addKill() { kills++; killStreak++; }

    public int getDeaths() { return deaths; }
    public void addDeath() { deaths++; killStreak = 0; }

    public int getKillStreak() { return killStreak; }
    public void resetKillStreak() { killStreak = 0; }

    public long getJoinTime() { return joinTime; }

    public long getSessionDuration() { return System.currentTimeMillis() - joinTime; }

    public boolean isAlive() { return alive; }
    public void setAlive(boolean alive) { this.alive = alive; }

    public Location getLastDeathLoc() { return lastDeathLoc; }
    public void setLastDeathLoc(Location lastDeathLoc) { this.lastDeathLoc = lastDeathLoc; }

    public String getSelectedKit() { return selectedKit; }
    public void setSelectedKit(String selectedKit) { this.selectedKit = selectedKit; }

    public double getKDR() {
        return deaths == 0 ? kills : (double) kills / deaths;
    }
}
