package com.ethernova.ffa.manager;

import com.ethernova.ffa.EthernovaFFA;
import com.ethernova.ffa.model.FFAArena;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Manages loading, saving, creating and deleting FFA arenas from arenas.yml.
 */
public class FFAArenaManager {

    private final EthernovaFFA plugin;
    private final Map<String, FFAArena> arenas = new ConcurrentHashMap<>();
    private File arenaFile;
    private FileConfiguration arenaConfig;

    public FFAArenaManager(EthernovaFFA plugin) {
        this.plugin = plugin;
    }

    public void loadArenas() {
        arenas.clear();
        arenaFile = new File(plugin.getDataFolder(), "arenas.yml");
        if (!arenaFile.exists()) {
            try {
                plugin.getDataFolder().mkdirs();
                arenaFile.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().log(Level.SEVERE, "No se pudo crear arenas.yml", e);
                return;
            }
        }
        arenaConfig = YamlConfiguration.loadConfiguration(arenaFile);

        ConfigurationSection section = arenaConfig.getConfigurationSection("arenas");
        if (section == null) {
            plugin.getLogger().info("No hay arenas configuradas.");
            return;
        }

        for (String key : section.getKeys(false)) {
            ConfigurationSection arenaSec = section.getConfigurationSection(key);
            if (arenaSec == null) continue;

            int maxPlayers = arenaSec.getInt("max-players", 50);
            boolean enabled = arenaSec.getBoolean("enabled", true);
            String kitId = arenaSec.getString("kit-id", null);

            List<Location> spawnPoints = new ArrayList<>();
            ConfigurationSection spawnsSec = arenaSec.getConfigurationSection("spawns");
            if (spawnsSec != null) {
                for (String spawnKey : spawnsSec.getKeys(false)) {
                    ConfigurationSection spawnSec = spawnsSec.getConfigurationSection(spawnKey);
                    if (spawnSec == null) continue;
                    Location loc = deserializeLocation(spawnSec);
                    if (loc != null) spawnPoints.add(loc);
                }
            }

            FFAArena arena = new FFAArena(key, spawnPoints, maxPlayers, enabled, kitId);

            // Load region for rollback
            ConfigurationSection rp1 = arenaSec.getConfigurationSection("region-pos1");
            ConfigurationSection rp2 = arenaSec.getConfigurationSection("region-pos2");
            if (rp1 != null) arena.setRegionPos1(deserializeLocation(rp1));
            if (rp2 != null) arena.setRegionPos2(deserializeLocation(rp2));

            arenas.put(key.toLowerCase(), arena);
        }

        plugin.getLogger().info("Cargadas " + arenas.size() + " arena(s) FFA.");
    }

    public void saveArenas() {
        if (arenaConfig == null || arenaFile == null) return;

        arenaConfig.set("arenas", null); // Clear

        for (FFAArena arena : arenas.values()) {
            String path = "arenas." + arena.getName();
            arenaConfig.set(path + ".max-players", arena.getMaxPlayers());
            arenaConfig.set(path + ".enabled", arena.isEnabled());
            if (arena.getKitId() != null) {
                arenaConfig.set(path + ".kit-id", arena.getKitId());
            }

            List<Location> spawns = arena.getSpawnPoints();
            for (int i = 0; i < spawns.size(); i++) {
                String spawnPath = path + ".spawns." + i;
                serializeLocation(arenaConfig, spawnPath, spawns.get(i));
            }

            // Save region if set
            if (arena.getRegionPos1() != null) {
                serializeLocation(arenaConfig, path + ".region-pos1", arena.getRegionPos1());
            }
            if (arena.getRegionPos2() != null) {
                serializeLocation(arenaConfig, path + ".region-pos2", arena.getRegionPos2());
            }
        }

        try {
            arenaConfig.save(arenaFile);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "No se pudo guardar arenas.yml", e);
        }
    }

    public FFAArena createArena(String name) {
        String key = name.toLowerCase();
        if (arenas.containsKey(key)) return null;

        FFAArena arena = new FFAArena(name);
        arenas.put(key, arena);
        saveArenas();
        return arena;
    }

    public boolean deleteArena(String name) {
        FFAArena removed = arenas.remove(name.toLowerCase());
        if (removed != null) {
            saveArenas();
            return true;
        }
        return false;
    }

    public FFAArena getArena(String name) {
        return arenas.get(name.toLowerCase());
    }

    public Collection<FFAArena> getAllArenas() {
        return Collections.unmodifiableCollection(arenas.values());
    }

    public List<FFAArena> getEnabledArenas() {
        List<FFAArena> list = new ArrayList<>();
        for (FFAArena arena : arenas.values()) {
            if (arena.isEnabled() && arena.hasSpawnPoints()) {
                list.add(arena);
            }
        }
        return list;
    }

    public List<String> getArenaNames() {
        return new ArrayList<>(arenas.keySet());
    }

    // ── Location serialization ──

    private void serializeLocation(FileConfiguration config, String path, Location loc) {
        config.set(path + ".world", loc.getWorld().getName());
        config.set(path + ".x", loc.getX());
        config.set(path + ".y", loc.getY());
        config.set(path + ".z", loc.getZ());
        config.set(path + ".yaw", (double) loc.getYaw());
        config.set(path + ".pitch", (double) loc.getPitch());
    }

    private Location deserializeLocation(ConfigurationSection sec) {
        String worldName = sec.getString("world");
        if (worldName == null) return null;
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            plugin.getLogger().warning("Mundo no encontrado: " + worldName);
            return null;
        }
        double x = sec.getDouble("x");
        double y = sec.getDouble("y");
        double z = sec.getDouble("z");
        float yaw = (float) sec.getDouble("yaw", 0);
        float pitch = (float) sec.getDouble("pitch", 0);
        return new Location(world, x, y, z, yaw, pitch);
    }
}
