package com.ethernova.ffa.manager;

import com.ethernova.core.api.CombatAPI;
import com.ethernova.core.EthernovaCore;
import com.ethernova.core.arena.ArenaRegion;
import com.ethernova.core.arena.ArenaRollbackEngine;
import com.ethernova.core.event.EthernovaPlayerKillEvent;
import com.ethernova.core.gui.PlayerSettingsGui;
import com.ethernova.core.lobby.LobbyManager;
import com.ethernova.core.service.ServiceRegistry;
import com.ethernova.ffa.EthernovaFFA;
import com.ethernova.ffa.message.MessageManager;
import com.ethernova.ffa.model.FFAArena;
import com.ethernova.ffa.model.FFAKit;
import com.ethernova.ffa.model.FFAPlayer;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Central FFA lifecycle manager. Handles join, leave, kill, death, respawn.
 */
public class FFAManager {

    private final EthernovaFFA plugin;
    private final EthernovaCore core;
    private final MiniMessage mini = MiniMessage.miniMessage();

    private MessageManager mm() { return plugin.getMessageManager(); }

    // Active FFA players by UUID
    private final Map<UUID, FFAPlayer> activePlayers = new ConcurrentHashMap<>();
    // Track max killstreak per session for stats
    private final Map<UUID, Integer> maxStreaks = new ConcurrentHashMap<>();
    // O(1) player count per arena
    private final Map<String, AtomicInteger> arenaPlayerCounts = new ConcurrentHashMap<>();
    // Periodic rollback tasks per arena
    private final Map<String, BukkitTask> rollbackTasks = new ConcurrentHashMap<>();

    public FFAManager(EthernovaFFA plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
        // Start rollback tracking for all arenas with regions
        Bukkit.getScheduler().runTaskLater(plugin, this::initRollbackTracking, 20L);
    }

    // ═══════════════════════════════════════
    //  ARENA ROLLBACK
    // ═══════════════════════════════════════

    private void initRollbackTracking() {
        for (FFAArena arena : plugin.getArenaManager().getAllArenas()) {
            if (arena.hasRegion() && arena.isEnabled()) {
                startPeriodicRollback(arena);
            }
        }
    }

    private void startPeriodicRollback(FFAArena arena) {
        ArenaRollbackEngine engine = core.getArenaRollbackEngine();
        ArenaRegion region = ArenaRegion.fromCorners(arena.getRegionPos1(), arena.getRegionPos2());
        engine.startTracking(arena.getName(), region);

        int intervalMinutes = plugin.getConfig().getInt("arena-reset.interval-minutes", 5);
        long intervalTicks = intervalMinutes * 60L * 20L;

        BukkitTask old = rollbackTasks.remove(arena.getName().toLowerCase());
        if (old != null) old.cancel();

        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            int changedBlocks = engine.getChangedBlockCount(arena.getName());
            if (changedBlocks == 0) return; // No cambios, skip

            // Broadcast warning
            broadcastToArena(arena.getName(),
                    "<yellow>⚠ Restaurando arena en 5 segundos... <gray>(" + changedBlocks + " bloques)</gray>");

            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                engine.rollback(arena.getName(), true); // rollback + restart tracking
                broadcastToArena(arena.getName(), "<green>✔ Arena restaurada.");
            }, 100L); // 5 seconds after warning
        }, intervalTicks, intervalTicks);

        rollbackTasks.put(arena.getName().toLowerCase(), task);
        plugin.getLogger().info("Rollback periódico activado para arena '" + arena.getName()
                + "' cada " + intervalMinutes + " min");
    }

    /**
     * Called from admin command when region is set/changed.
     */
    public void restartRollbackTracking(FFAArena arena) {
        // Stop old
        BukkitTask old = rollbackTasks.remove(arena.getName().toLowerCase());
        if (old != null) old.cancel();
        ArenaRollbackEngine engine = core.getArenaRollbackEngine();
        engine.stopTracking(arena.getName());

        // Start fresh
        if (arena.hasRegion() && arena.isEnabled()) {
            startPeriodicRollback(arena);
        }
    }

    /**
     * Stop all periodic rollback tasks (shutdown).
     */
    public void stopRollbackTasks() {
        for (BukkitTask task : rollbackTasks.values()) {
            task.cancel();
        }
        rollbackTasks.clear();
    }

    // ═══════════════════════════════════════
    //  JOIN
    // ═══════════════════════════════════════

    public boolean joinArena(Player player, String arenaName) {
        UUID uuid = player.getUniqueId();

        // Already in FFA?
        if (activePlayers.containsKey(uuid)) {
            mm().sendMessage(player, "ffa.already-in-ffa");
            return false;
        }

        // In combat? Can't join while fighting
        CombatAPI combatAPI = ServiceRegistry.get(CombatAPI.class);
        if (combatAPI != null && combatAPI.isInCombat(player)) {
            mm().sendMessage(player, "ffa.in-combat");
            return false;
        }

        // Arena exists?
        FFAArena arena = plugin.getArenaManager().getArena(arenaName);
        if (arena == null) {
            mm().sendMessage(player, "ffa.arena-not-found");
            return false;
        }

        // Arena enabled?
        if (!arena.isEnabled()) {
            mm().sendMessage(player, "ffa.arena-disabled");
            return false;
        }

        // Arena has spawns?
        if (!arena.hasSpawnPoints()) {
            mm().sendMessage(player, "ffa.arena-not-found");
            return false;
        }

        // Arena full?
        int maxPlayers = arena.getMaxPlayers();
        if (maxPlayers > 0 && getPlayerCount(arenaName) >= maxPlayers) {
            mm().sendMessage(player, "ffa.arena-full");
            return false;
        }

        // Create session
        FFAPlayer ffaPlayer = new FFAPlayer(uuid, arenaName);

        // Determine kit
        String kitId = arena.getKitId(); // Arena-forced kit
        if (kitId == null) {
            kitId = plugin.getConfig().getString("kits.default-kit", "warrior");
        }
        ffaPlayer.setSelectedKit(kitId);

        activePlayers.put(uuid, ffaPlayer);
        maxStreaks.put(uuid, 0);
        arenaPlayerCounts.computeIfAbsent(arenaName.toLowerCase(), k -> new AtomicInteger()).incrementAndGet();

        // Register context
        core.getContextManager().addContext(uuid, "ffa");

        // Set player state for scoreboard/PAPI
        core.getStateManager().setState(uuid, "ffa", arenaName);

        // Teleport to random spawn
        Location spawn = arena.getSpawnPoint();
        if (spawn != null) {
            player.teleport(spawn);
        }

        // Apply kit
        applyKit(player, ffaPlayer);

        // Game mode
        player.setGameMode(GameMode.SURVIVAL);

        // Spawn protection
        plugin.getSpawnProtectionManager().protect(player);

        // Broadcast join
        String joinMsg = mm().get("ffa.join", "{player}", player.getName(), "{arena}", arenaName);
        broadcastToArena(arenaName, joinMsg);

        // Sound
        core.getSoundManager().play(player, "teleport");

        return true;
    }

    // ═══════════════════════════════════════
    //  LEAVE
    // ═══════════════════════════════════════

    public boolean leaveArena(Player player) {
        UUID uuid = player.getUniqueId();

        // Can't leave while in combat
        CombatAPI combatAPI = ServiceRegistry.get(CombatAPI.class);
        if (combatAPI != null && combatAPI.isInCombat(player)) {
            mm().sendMessage(player, "ffa.in-combat");
            return false;
        }

        FFAPlayer ffaPlayer = activePlayers.remove(uuid);
        if (ffaPlayer == null) {
            mm().sendMessage(player, "ffa.not-in-ffa");
            return false;
        }

        leaveArenaInternal(player, ffaPlayer);

        // Send to lobby if enabled
        LobbyManager lobby = core.getLobbyManager();
        if (lobby != null && lobby.isEnabled()) {
            lobby.sendToLobby(player);
        } else {
            // Legacy: just clear player state
            player.getInventory().clear();
            player.getActivePotionEffects().forEach(e -> player.removePotionEffect(e.getType()));
            player.setHealth(player.getMaxHealth());
            player.setFoodLevel(20);
            player.setSaturation(20f);
            player.setFireTicks(0);
            player.setGameMode(GameMode.SURVIVAL);
        }

        return true;
    }

    /**
     * Internal cleanup shared between leaveArena and handleDeath-with-lobby.
     */
    private void leaveArenaInternal(Player player, FFAPlayer ffaPlayer) {
        UUID uuid = player.getUniqueId();
        activePlayers.remove(uuid);

        // Decrement arena counter
        AtomicInteger count = arenaPlayerCounts.get(ffaPlayer.getArenaName().toLowerCase());
        if (count != null) count.decrementAndGet();

        // Track best streak
        int maxStreak = maxStreaks.getOrDefault(uuid, 0);
        int bestStreak = Math.max(maxStreak, ffaPlayer.getKillStreak());
        maxStreaks.remove(uuid);

        // Remove context
        core.getContextManager().removeContext(uuid, "ffa");

        // Clear player state
        core.getStateManager().clearState(uuid);

        // Remove spawn protection
        plugin.getSpawnProtectionManager().forceRemove(uuid);

        // Persist stats async
        plugin.getStatsManager().recordSession(
                uuid, player.getName(),
                ffaPlayer.getKills(), ffaPlayer.getDeaths(),
                bestStreak, ffaPlayer.getSessionDuration()
        );

        // Broadcast leave
        String leaveMsg = mm().get("ffa.leave", "{player}", player.getName());
        broadcastToArena(ffaPlayer.getArenaName(), leaveMsg);
    }

    /**
     * Force leave without messages (for disconnects).
     */
    public void forceLeave(UUID uuid) {
        FFAPlayer ffaPlayer = activePlayers.remove(uuid);
        if (ffaPlayer == null) return;

        // Untag from combat
        CombatAPI combatAPI = ServiceRegistry.get(CombatAPI.class);
        if (combatAPI != null) {
            Player player2 = Bukkit.getPlayer(uuid);
            if (player2 != null) combatAPI.untag(player2);
        }

        // Decrement arena counter
        AtomicInteger count = arenaPlayerCounts.get(ffaPlayer.getArenaName().toLowerCase());
        if (count != null) count.decrementAndGet();

        int maxStreak = maxStreaks.getOrDefault(uuid, 0);
        int bestStreak = Math.max(maxStreak, ffaPlayer.getKillStreak());
        maxStreaks.remove(uuid);

        // Remove context
        core.getContextManager().removeContext(uuid, "ffa");

        // Clear player state
        core.getStateManager().clearState(uuid);

        // Remove spawn protection
        plugin.getSpawnProtectionManager().forceRemove(uuid);

        // Persist stats async
        Player player = Bukkit.getPlayer(uuid);
        String name = player != null ? player.getName() : uuid.toString().substring(0, 8);

        plugin.getStatsManager().recordSession(
                uuid, name,
                ffaPlayer.getKills(), ffaPlayer.getDeaths(),
                bestStreak, ffaPlayer.getSessionDuration()
        );
    }

    /**
     * Force leave all players (on disable).
     */
    public void forceLeaveAll() {
        for (UUID uuid : new ArrayList<>(activePlayers.keySet())) {
            Player player = Bukkit.getPlayer(uuid);
            if (player != null && player.isOnline()) {
                leaveArena(player);
            } else {
                forceLeave(uuid);
            }
        }
    }

    // ═══════════════════════════════════════
    //  KILL / DEATH
    // ═══════════════════════════════════════

    public void handleKill(Player killer, Player victim) {
        UUID killerUuid = killer.getUniqueId();
        UUID victimUuid = victim.getUniqueId();

        FFAPlayer killerData = activePlayers.get(killerUuid);
        FFAPlayer victimData = activePlayers.get(victimUuid);
        if (killerData == null || victimData == null) return;

        // Update stats
        killerData.addKill();
        victimData.addDeath();

        // Track max streak
        int currentMaxStreak = maxStreaks.getOrDefault(killerUuid, 0);
        if (killerData.getKillStreak() > currentMaxStreak) {
            maxStreaks.put(killerUuid, killerData.getKillStreak());
        }

        // Rewards
        double coinReward = plugin.getConfig().getDouble("rewards.coins-per-kill", 10.0);
        int xpReward = plugin.getConfig().getInt("rewards.xp-per-kill", 25);

        // Apply boost multipliers
        double coinMulti = core.getBoostManager().getMultiplier("money");
        double xpMulti = core.getBoostManager().getMultiplier("xp");

        // Apply FFA event multipliers (DOUBLE_MONEY, TRIPLE_MONEY, DOUBLE_XP)
        coinMulti *= plugin.getEventsManager().getMoneyMultiplier();
        xpMulti *= plugin.getEventsManager().getXPMultiplier();

        double finalCoins = coinReward * coinMulti;
        long finalXp = (long) (xpReward * xpMulti);

        // Give rewards via Vault economy (single source of truth)
        if (core.getEconomyHook().isEnabled()) {
            core.getEconomyHook().deposit(killer, finalCoins);
        }

        // Give XP via core profile
        var profile = core.getProfileManager().getProfile(killerUuid);
        if (profile != null) {
            profile.addXP(finalXp);
        }

        // Kill message (skip for players with hideKillChat enabled)
        String killMsg = mm().get("ffa.kill",
                "{killer}", killer.getName(),
                "{victim}", victim.getName(),
                "{killstreak}", String.valueOf(killerData.getKillStreak()));
        broadcastToArenaFiltered(killerData.getArenaName(), killMsg, "hideKillChat");

        // Kill sound (only if killer has killSounds enabled)
        if (PlayerSettingsGui.getSetting(core, killerUuid, "killSounds")) {
            core.getSoundManager().play(killer, "kill");
        }

        // Publish core event
        core.getEventBus().publish(new EthernovaPlayerKillEvent(
                killerUuid, killer.getName(),
                victimUuid, victim.getName(),
                "ffa",
                victim.getLocation().clone()
        ));

        // Full heal + food + new kit for killer
        killer.setHealth(killer.getMaxHealth());
        killer.setFoodLevel(20);
        killer.setSaturation(20f);
        applyKit(killer, killerData);

        // Killstreak milestones
        checkKillstreak(killer, killerData);
    }

    public void handleDeath(Player victim) {
        UUID uuid = victim.getUniqueId();
        FFAPlayer ffaPlayer = activePlayers.get(uuid);
        if (ffaPlayer == null) return;

        // Guard against double-death (PlayerDeathEvent firing twice)
        if (!ffaPlayer.isAlive()) return;

        ffaPlayer.setAlive(false);
        ffaPlayer.setLastDeathLoc(victim.getLocation().clone());

        // Death sound
        core.getSoundManager().play(victim, "death");

        // Check if lobby mode is active: death → leave FFA → lobby
        LobbyManager lobby = core.getLobbyManager();
        if (lobby != null && lobby.isEnabled()) {
            // Remove from FFA and send to lobby after respawn tick
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!victim.isOnline()) return;
                // Force leave FFA (clears stats, removes context)
                leaveArenaInternal(victim, ffaPlayer);
                // Send to lobby with items
                lobby.sendToLobby(victim);
            }, 2L); // 2 ticks after death to allow respawn
            return;
        }

        // Legacy mode: respawn in arena
        int delayTicks = plugin.getConfig().getInt("respawn.delay-ticks", 40);
        int delaySecs = delayTicks / 20;
        mm().sendMessage(victim, "ffa.death", "{delay}", String.valueOf(delaySecs));

        Bukkit.getScheduler().runTaskLater(plugin, () -> respawn(victim), delayTicks);
    }

    private void respawn(Player player) {
        UUID uuid = player.getUniqueId();
        FFAPlayer ffaPlayer = activePlayers.get(uuid);
        if (ffaPlayer == null) return;
        if (!player.isOnline()) return;

        FFAArena arena = plugin.getArenaManager().getArena(ffaPlayer.getArenaName());
        if (arena == null) return;

        // Teleport to random spawn different from death location
        Location spawn = arena.getSpawnPointExcluding(ffaPlayer.getLastDeathLoc());
        if (spawn != null) {
            player.teleport(spawn);
        }

        // Re-apply kit
        applyKit(player, ffaPlayer);

        // Mark alive
        ffaPlayer.setAlive(true);

        // Apply spawn protection
        plugin.getSpawnProtectionManager().protect(player);
    }

    private void checkKillstreak(Player killer, FFAPlayer data) {
        int milestone = plugin.getConfig().getInt("killstreak.milestone-interval", 5);
        int streak = data.getKillStreak();

        if (streak > 0 && streak % milestone == 0) {
            // Broadcast killstreak
            if (plugin.getConfig().getBoolean("killstreak.broadcast", true)) {
                String streakMsg = mm().get("ffa.killstreak",
                        "{player}", killer.getName(),
                        "{streak}", String.valueOf(streak));
                broadcastToArena(data.getArenaName(), streakMsg);
            }

            // Streak sound
            core.getSoundManager().play(killer, "streak");

            // Streak rewards
            double streakCoins = plugin.getConfig().getDouble("rewards.coins-per-streak-milestone", 50.0);
            int streakXp = plugin.getConfig().getInt("rewards.xp-per-streak-milestone", 100);
            double multi = (double) streak / milestone;
            double coinMulti = core.getBoostManager().getMultiplier("money");
            double xpMulti = core.getBoostManager().getMultiplier("xp");

            double finalCoins = streakCoins * multi * coinMulti;
            long finalXp = (long) (streakXp * multi * xpMulti);

            // Give coins via Vault only (single source of truth)
            if (core.getEconomyHook().isEnabled()) {
                core.getEconomyHook().deposit(killer, finalCoins);
            }

            // Give XP via core profile
            var profile = core.getProfileManager().getProfile(killer.getUniqueId());
            if (profile != null) {
                profile.addXP(finalXp);
            }
        }
    }

    // ═══════════════════════════════════════
    //  KIT
    // ═══════════════════════════════════════

    public void applyKit(Player player, FFAPlayer ffaPlayer) {
        String kitId = ffaPlayer.getSelectedKit();
        FFAKit kit = plugin.getKitManager().getKit(kitId);
        if (kit == null) {
            kit = plugin.getKitManager().getDefaultKit();
        }
        kit.apply(player);
    }

    public void changeKit(Player player, String kitId) {
        FFAPlayer ffaPlayer = activePlayers.get(player.getUniqueId());
        if (ffaPlayer == null) return;

        boolean allowAlive = plugin.getConfig().getBoolean("kits.allow-kit-change-alive", false);
        if (ffaPlayer.isAlive() && !allowAlive) {
            mm().sendMessage(player, "ffa.kit-change-not-allowed");
            return;
        }

        ffaPlayer.setSelectedKit(kitId);
        FFAKit kit = plugin.getKitManager().getKit(kitId);
        if (kit != null) {
            kit.apply(player);
            mm().sendMessage(player, "ffa.kit-applied", "{kit}", kit.getName());
            core.getSoundManager().play(player, "click");
        }
    }

    // ═══════════════════════════════════════
    //  QUERIES
    // ═══════════════════════════════════════

    public FFAPlayer getFFAPlayer(UUID uuid) {
        return activePlayers.get(uuid);
    }

    public boolean isInFFA(UUID uuid) {
        return activePlayers.containsKey(uuid);
    }

    public int getPlayerCount(String arenaName) {
        AtomicInteger count = arenaPlayerCounts.get(arenaName.toLowerCase());
        return count != null ? Math.max(0, count.get()) : 0;
    }

    public int getTotalPlayers() {
        return activePlayers.size();
    }

    public Collection<FFAPlayer> getPlayersInArena(String arenaName) {
        List<FFAPlayer> list = new ArrayList<>();
        for (FFAPlayer p : activePlayers.values()) {
            if (p.getArenaName().equalsIgnoreCase(arenaName)) list.add(p);
        }
        return list;
    }

    // ═══════════════════════════════════════
    //  MESSAGING
    // ═══════════════════════════════════════

    private void broadcastToArena(String arenaName, String message) {
        String prefix = mm().get("general.prefix");
        Component comp = mini.deserialize(prefix + message);
        for (FFAPlayer ffaPlayer : activePlayers.values()) {
            if (ffaPlayer.getArenaName().equalsIgnoreCase(arenaName)) {
                Player player = Bukkit.getPlayer(ffaPlayer.getUuid());
                if (player != null && player.isOnline()) {
                    player.sendMessage(comp);
                }
            }
        }
    }

    /**
     * Broadcast to arena but skip players who have the given setting enabled (for "hide" toggles).
     */
    private void broadcastToArenaFiltered(String arenaName, String message, String hideSettingKey) {
        String prefix = mm().get("general.prefix");
        Component comp = mini.deserialize(prefix + message);
        for (FFAPlayer ffaPlayer : activePlayers.values()) {
            if (ffaPlayer.getArenaName().equalsIgnoreCase(arenaName)) {
                Player player = Bukkit.getPlayer(ffaPlayer.getUuid());
                if (player != null && player.isOnline()) {
                    // Skip if player has the hide setting enabled
                    if (PlayerSettingsGui.getSetting(core, ffaPlayer.getUuid(), hideSettingKey)) {
                        continue;
                    }
                    player.sendMessage(comp);
                }
            }
        }
    }

    private void sendMessage(Player player, String key, String... replacements) {
        mm().sendMessage(player, key, replacements);
    }
}
