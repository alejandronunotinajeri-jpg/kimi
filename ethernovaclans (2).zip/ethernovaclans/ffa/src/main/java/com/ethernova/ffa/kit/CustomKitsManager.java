package com.ethernova.ffa.kit;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.storage.CoreStorageManager;
import com.ethernova.core.storage.MigrationManager;
import com.ethernova.ffa.EthernovaFFA;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Player-created custom kits. Each player can save up to 3 custom kits
 * from their current inventory layout.
 * <p>
 * DB table: ethernova_custom_kits (uuid, slot, name, data)
 */
public class CustomKitsManager {

    private final EthernovaFFA plugin;
    private final CoreStorageManager storage;
    private final Logger logger;
    private final MiniMessage mini = MiniMessage.miniMessage();

    private static final int MAX_KITS = 3;

    // Cache: UUID -> (slot -> kit)
    private final Map<UUID, Map<Integer, CustomKit>> playerKits = new ConcurrentHashMap<>();

    public CustomKitsManager(EthernovaFFA plugin, CoreStorageManager storage) {
        this.plugin = plugin;
        this.storage = storage;
        this.logger = plugin.getLogger();
        runMigrations();
    }

    private void runMigrations() {
        new MigrationManager(storage, logger, "ethernova_customkits")
                .addMigration(1,
                        """
                        CREATE TABLE IF NOT EXISTS ethernova_custom_kits (
                            uuid VARCHAR(36) NOT NULL,
                            slot INT NOT NULL,
                            name VARCHAR(32) NOT NULL,
                            data TEXT NOT NULL,
                            PRIMARY KEY (uuid, slot)
                        )
                        """)
                .migrate();
    }

    // ═══════════════════════════════════════
    //  CUSTOM KIT MODEL
    // ═══════════════════════════════════════

    public record CustomKit(String name, int slot, ItemStack[] contents, ItemStack[] armor) {
        public boolean isEmpty() {
            return contents == null || contents.length == 0;
        }
    }

    // ═══════════════════════════════════════
    //  SAVE / LOAD / DELETE
    // ═══════════════════════════════════════

    /**
     * Save the player's current inventory as a custom kit.
     */
    public boolean saveKit(Player player, int slot, String name) {
        UUID uuid = player.getUniqueId();

        if (slot < 1 || slot > MAX_KITS) {
            player.sendMessage(mini.deserialize("<red>Slot inválido. Usa 1-" + MAX_KITS + "."));
            return false;
        }

        if (name.length() > 32) {
            player.sendMessage(mini.deserialize("<red>El nombre es muy largo (máx 32 caracteres)."));
            return false;
        }

        PlayerInventory inv = player.getInventory();
        ItemStack[] contents = inv.getStorageContents().clone();
        ItemStack[] armor = inv.getArmorContents().clone();

        // Check not empty
        boolean hasItems = false;
        for (ItemStack item : contents) {
            if (item != null && item.getType() != Material.AIR) { hasItems = true; break; }
        }
        if (!hasItems) {
            player.sendMessage(mini.deserialize("<red>Tu inventario está vacío."));
            return false;
        }

        CustomKit kit = new CustomKit(name, slot, contents, armor);
        playerKits.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>()).put(slot, kit);

        // Persist async
        persistKit(uuid, slot, name, contents, armor);

        player.sendMessage(mini.deserialize(
                "<green>✔ Kit <yellow>" + name + "</yellow> guardado en slot <gold>#" + slot + "</gold>."));
        return true;
    }

    /**
     * Apply a custom kit to the player.
     */
    public boolean applyKit(Player player, int slot) {
        UUID uuid = player.getUniqueId();
        Map<Integer, CustomKit> kits = playerKits.get(uuid);
        if (kits == null || !kits.containsKey(slot)) {
            player.sendMessage(mini.deserialize("<red>No tienes un kit en el slot #" + slot + "."));
            return false;
        }

        CustomKit kit = kits.get(slot);
        player.getInventory().clear();
        player.getInventory().setStorageContents(kit.contents());
        if (kit.armor() != null) {
            player.getInventory().setArmorContents(kit.armor());
            // Apply cosmetic armor trims
            com.ethernova.core.service.ArmorTrimService trimService =
                    com.ethernova.core.service.ServiceRegistry.get(com.ethernova.core.service.ArmorTrimService.class);
            if (trimService != null) {
                org.bukkit.inventory.ItemStack[] trimmed = trimService.applyTrims(
                        uuid, player.getInventory().getArmorContents());
                player.getInventory().setArmorContents(trimmed);
            }
        }
        player.sendMessage(mini.deserialize("<green>✔ Kit <yellow>" + kit.name() + "</yellow> aplicado."));
        return true;
    }

    /**
     * Delete a custom kit.
     */
    public boolean deleteKit(Player player, int slot) {
        UUID uuid = player.getUniqueId();
        Map<Integer, CustomKit> kits = playerKits.get(uuid);
        if (kits == null || !kits.containsKey(slot)) {
            player.sendMessage(mini.deserialize("<red>No tienes un kit en el slot #" + slot + "."));
            return false;
        }

        kits.remove(slot);
        deleteKitDB(uuid, slot);

        player.sendMessage(mini.deserialize("<green>✔ Kit eliminado del slot #" + slot + "."));
        return true;
    }

    /**
     * List a player's custom kits.
     */
    public List<CustomKit> getKits(UUID uuid) {
        Map<Integer, CustomKit> kits = playerKits.get(uuid);
        if (kits == null) return Collections.emptyList();
        return new ArrayList<>(kits.values());
    }

    /**
     * Get the number of kits a player has.
     */
    public int getKitCount(UUID uuid) {
        Map<Integer, CustomKit> kits = playerKits.get(uuid);
        return kits != null ? kits.size() : 0;
    }

    public int getMaxKits() { return MAX_KITS; }

    // ═══════════════════════════════════════
    //  PLAYER LOAD / UNLOAD
    // ═══════════════════════════════════════

    public CompletableFuture<Void> loadPlayer(UUID uuid) {
        return CompletableFuture.runAsync(() -> {
            try (Connection conn = storage.getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "SELECT slot, name, data FROM ethernova_custom_kits WHERE uuid = ?")) {
                ps.setString(1, uuid.toString());
                ResultSet rs = ps.executeQuery();

                Map<Integer, CustomKit> kits = new ConcurrentHashMap<>();
                while (rs.next()) {
                    int slot = rs.getInt("slot");
                    String name = rs.getString("name");
                    String data = rs.getString("data");
                    ItemStack[][] parsed = deserializeContentsAndArmor(data);
                    kits.put(slot, new CustomKit(name, slot, parsed[0], parsed[1]));
                }
                if (!kits.isEmpty()) {
                    playerKits.put(uuid, kits);
                }
            } catch (Exception e) {
                logger.log(Level.SEVERE, "Error loading custom kits for " + uuid, e);
            }
        }, EthernovaCore.getInstance().getDbExecutor()).exceptionally(ex -> {
            logger.log(Level.SEVERE, "Unhandled error loading custom kits for " + uuid, ex);
            return null;
        });
    }

    public void unloadPlayer(UUID uuid) {
        playerKits.remove(uuid);
    }

    // ═══════════════════════════════════════
    //  PERSISTENCE
    // ═══════════════════════════════════════

    private void persistKit(UUID uuid, int slot, String name, ItemStack[] contents, ItemStack[] armor) {
        CompletableFuture.runAsync(() -> {
            try (Connection conn = storage.getConnection()) {
                String data = serializeContentsAndArmor(contents, armor);
                String sql = storage.isMySQL()
                        ? "INSERT INTO ethernova_custom_kits (uuid, slot, name, data) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE name = VALUES(name), data = VALUES(data)"
                        : "INSERT OR REPLACE INTO ethernova_custom_kits (uuid, slot, name, data) VALUES (?, ?, ?, ?)";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, uuid.toString());
                    ps.setInt(2, slot);
                    ps.setString(3, name);
                    ps.setString(4, data);
                    ps.executeUpdate();
                }
            } catch (Exception e) {
                logger.log(Level.SEVERE, "Error saving custom kit", e);
            }
        }, EthernovaCore.getInstance().getDbExecutor()).exceptionally(ex -> {
            logger.log(Level.SEVERE, "Unhandled error persisting custom kit", ex);
            return null;
        });
    }

    private void deleteKitDB(UUID uuid, int slot) {
        CompletableFuture.runAsync(() -> {
            try (Connection conn = storage.getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "DELETE FROM ethernova_custom_kits WHERE uuid = ? AND slot = ?")) {
                ps.setString(1, uuid.toString());
                ps.setInt(2, slot);
                ps.executeUpdate();
            } catch (Exception e) {
                logger.log(Level.SEVERE, "Error deleting custom kit", e);
            }
        }, EthernovaCore.getInstance().getDbExecutor()).exceptionally(ex -> {
            logger.log(Level.SEVERE, "Unhandled error deleting custom kit", ex);
            return null;
        });
    }

    /**
     * Serialize contents + armor to Base64 string for DB storage.
     * Format: writes contents length, contents items, then armor length, armor items.
     */
    private String serializeContentsAndArmor(ItemStack[] contents, ItemStack[] armor) {
        try {
            org.bukkit.util.io.BukkitObjectOutputStream out;
            java.io.ByteArrayOutputStream byteOut = new java.io.ByteArrayOutputStream();
            out = new org.bukkit.util.io.BukkitObjectOutputStream(byteOut);
            out.writeInt(contents.length);
            for (ItemStack item : contents) {
                out.writeObject(item);
            }
            // Write armor after contents
            ItemStack[] safeArmor = armor != null ? armor : new ItemStack[4];
            out.writeInt(safeArmor.length);
            for (ItemStack item : safeArmor) {
                out.writeObject(item);
            }
            out.close();
            return Base64.getEncoder().encodeToString(byteOut.toByteArray());
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error serializing kit", e);
            return "";
        }
    }

    /**
     * Deserialize Base64 string back to contents + armor arrays.
     * Returns [contents, armor]. Backwards-compatible: old data without armor returns empty armor.
     */
    private ItemStack[][] deserializeContentsAndArmor(String data) {
        if (data == null || data.isEmpty()) return new ItemStack[][]{ new ItemStack[0], new ItemStack[4] };
        try {
            byte[] bytes = Base64.getDecoder().decode(data);
            java.io.ByteArrayInputStream byteIn = new java.io.ByteArrayInputStream(bytes);
            org.bukkit.util.io.BukkitObjectInputStream in = new org.bukkit.util.io.BukkitObjectInputStream(byteIn);
            int contentsLen = in.readInt();
            ItemStack[] contents = new ItemStack[contentsLen];
            for (int i = 0; i < contentsLen; i++) {
                contents[i] = (ItemStack) in.readObject();
            }
            // Try to read armor (may not exist in old data)
            ItemStack[] armor = new ItemStack[4];
            try {
                if (in.available() > 0) {
                    int armorLen = in.readInt();
                    armor = new ItemStack[armorLen];
                    for (int i = 0; i < armorLen; i++) {
                        armor[i] = (ItemStack) in.readObject();
                    }
                }
            } catch (Exception ignored) {
                // Old format without armor, armor stays empty
            }
            in.close();
            return new ItemStack[][]{ contents, armor };
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error deserializing kit", e);
            return new ItemStack[][]{ new ItemStack[0], new ItemStack[4] };
        }
    }
}
