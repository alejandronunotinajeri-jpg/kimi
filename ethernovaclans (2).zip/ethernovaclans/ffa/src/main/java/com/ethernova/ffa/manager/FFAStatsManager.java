package com.ethernova.ffa.manager;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.storage.CoreStorageManager;
import com.ethernova.core.storage.MigrationManager;
import com.ethernova.ffa.EthernovaFFA;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Persistent FFA stats per player. Database table: ethernova_ffa_stats.
 * Includes in-memory cache for fast PAPI placeholder access.
 */
public class FFAStatsManager {

    private final EthernovaFFA plugin;
    private final CoreStorageManager storage;
    private final Map<UUID, CachedFFAStats> cache = new ConcurrentHashMap<>();

    public FFAStatsManager(EthernovaFFA plugin, CoreStorageManager storage) {
        this.plugin = plugin;
        this.storage = storage;
    }

    // ── Cached stats for sync PAPI access ──

    public record CachedFFAStats(int kills, int deaths, int bestStreak, int gamesPlayed) {
        public double getKDR() {
            return deaths == 0 ? kills : (double) kills / deaths;
        }
    }

    /** Synchronous cache access for placeholders. Returns null if not yet loaded. */
    public CachedFFAStats getCachedStats(UUID uuid) {
        CachedFFAStats cached = cache.get(uuid);
        if (cached == null) loadCacheAsync(uuid);
        return cached;
    }

    public void loadCacheAsync(UUID uuid) {
        getStats(uuid).thenAccept(stats -> {
            cache.put(uuid, new CachedFFAStats(stats[0], stats[1], stats[2], stats[3]));
        });
    }

    public void invalidateCache(UUID uuid) { cache.remove(uuid); }

    public void runMigrations() {
        new MigrationManager(storage, plugin.getLogger(), "ethernova_ffa")
                .addMigration(1,
                        """
                        CREATE TABLE IF NOT EXISTS ethernova_ffa_stats (
                            uuid VARCHAR(36) PRIMARY KEY,
                            name VARCHAR(16) NOT NULL,
                            kills INT DEFAULT 0,
                            deaths INT DEFAULT 0,
                            best_kill_streak INT DEFAULT 0,
                            games_played INT DEFAULT 0,
                            total_playtime BIGINT DEFAULT 0
                        )
                        """
                )
                .migrate();
    }

    /**
     * Record a session's stats when player leaves FFA.
     */
    public CompletableFuture<Void> recordSession(UUID uuid, String name, int kills, int deaths,
                                                   int bestStreak, long sessionDuration) {
        return CompletableFuture.runAsync(() -> {
            try (Connection conn = storage.getConnection()) {
                if (storage.isMySQL()) {
                    String sql = """
                        INSERT INTO ethernova_ffa_stats (uuid, name, kills, deaths, best_kill_streak, games_played, total_playtime)
                        VALUES (?, ?, ?, ?, ?, 1, ?)
                        ON DUPLICATE KEY UPDATE
                            name = VALUES(name),
                            kills = kills + VALUES(kills),
                            deaths = deaths + VALUES(deaths),
                            best_kill_streak = GREATEST(best_kill_streak, VALUES(best_kill_streak)),
                            games_played = games_played + 1,
                            total_playtime = total_playtime + VALUES(total_playtime)
                    """;
                    try (PreparedStatement ps = conn.prepareStatement(sql)) {
                        ps.setString(1, uuid.toString());
                        ps.setString(2, name);
                        ps.setInt(3, kills);
                        ps.setInt(4, deaths);
                        ps.setInt(5, bestStreak);
                        ps.setLong(6, sessionDuration);
                        ps.executeUpdate();
                    }
                } else {
                    // SQLite: check if exists
                    String select = "SELECT kills, deaths, best_kill_streak, games_played, total_playtime FROM ethernova_ffa_stats WHERE uuid = ?";
                    try (PreparedStatement ps = conn.prepareStatement(select)) {
                        ps.setString(1, uuid.toString());
                        ResultSet rs = ps.executeQuery();

                        if (rs.next()) {
                            int oldKills = rs.getInt("kills");
                            int oldDeaths = rs.getInt("deaths");
                            int oldBest = rs.getInt("best_kill_streak");
                            int oldGames = rs.getInt("games_played");
                            long oldPlaytime = rs.getLong("total_playtime");

                            String update = "UPDATE ethernova_ffa_stats SET name = ?, kills = ?, deaths = ?, best_kill_streak = ?, games_played = ?, total_playtime = ? WHERE uuid = ?";
                            try (PreparedStatement up = conn.prepareStatement(update)) {
                                up.setString(1, name);
                                up.setInt(2, oldKills + kills);
                                up.setInt(3, oldDeaths + deaths);
                                up.setInt(4, Math.max(oldBest, bestStreak));
                                up.setInt(5, oldGames + 1);
                                up.setLong(6, oldPlaytime + sessionDuration);
                                up.setString(7, uuid.toString());
                                up.executeUpdate();
                            }
                        } else {
                            String insert = "INSERT INTO ethernova_ffa_stats (uuid, name, kills, deaths, best_kill_streak, games_played, total_playtime) VALUES (?, ?, ?, ?, ?, 1, ?)";
                            try (PreparedStatement ins = conn.prepareStatement(insert)) {
                                ins.setString(1, uuid.toString());
                                ins.setString(2, name);
                                ins.setInt(3, kills);
                                ins.setInt(4, deaths);
                                ins.setInt(5, bestStreak);
                                ins.setLong(6, sessionDuration);
                                ins.executeUpdate();
                            }
                        }
                    }
                }
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Error guardando estadísticas FFA de " + name, e);
            }
            // Refresh cache after save
            loadCacheAsync(uuid);
        }, EthernovaCore.getInstance().getDbExecutor()).exceptionally(ex -> {
            plugin.getLogger().log(Level.SEVERE, "Unhandled error recording FFA session", ex);
            return null;
        });
    }

    /**
     * Get stats for a specific player.
     * Returns: [kills, deaths, bestKillStreak, gamesPlayed, totalPlaytime]
     */
    public CompletableFuture<int[]> getStats(UUID uuid) {
        return CompletableFuture.supplyAsync(() -> {
            try (Connection conn = storage.getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "SELECT kills, deaths, best_kill_streak, games_played, total_playtime FROM ethernova_ffa_stats WHERE uuid = ?")) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return new int[]{
                                rs.getInt("kills"),
                                rs.getInt("deaths"),
                                rs.getInt("best_kill_streak"),
                                rs.getInt("games_played"),
                                (int) (rs.getLong("total_playtime") / 1000) // seconds
                        };
                    }
                }
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Error cargando stats FFA de " + uuid, e);
            }
            return new int[]{0, 0, 0, 0, 0};
        }, EthernovaCore.getInstance().getDbExecutor()).exceptionally(ex -> {
            plugin.getLogger().log(Level.SEVERE, "Unhandled error loading FFA stats", ex);
            return new int[]{0, 0, 0, 0, 0};
        });
    }

    /**
     * Leaderboard entry.
     */
    public record LeaderboardEntry(UUID uuid, String name, int kills, int deaths, int bestStreak) {
        public double getKDR() {
            return deaths == 0 ? kills : (double) kills / deaths;
        }
    }

    /**
     * Get top players by kills.
     */
    public CompletableFuture<List<LeaderboardEntry>> getLeaderboard(int limit) {
        return CompletableFuture.supplyAsync(() -> {
            List<LeaderboardEntry> list = new ArrayList<>();
            try (Connection conn = storage.getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "SELECT uuid, name, kills, deaths, best_kill_streak FROM ethernova_ffa_stats ORDER BY kills DESC LIMIT ?")) {
                ps.setInt(1, limit);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        list.add(new LeaderboardEntry(
                                UUID.fromString(rs.getString("uuid")),
                                rs.getString("name"),
                                rs.getInt("kills"),
                                rs.getInt("deaths"),
                                rs.getInt("best_kill_streak")
                        ));
                    }
                }
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Error cargando leaderboard FFA", e);
            }
            return list;
        }, EthernovaCore.getInstance().getDbExecutor()).exceptionally(ex -> {
            plugin.getLogger().log(Level.SEVERE, "Unhandled error loading FFA leaderboard", ex);
            return new ArrayList<>();
        });
    }

    /**
     * Get a player's rank in the leaderboard (by kills).
     */
    public CompletableFuture<Integer> getRank(UUID uuid) {
        return CompletableFuture.supplyAsync(() -> {
            try (Connection conn = storage.getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "SELECT COUNT(*) + 1 AS rank FROM ethernova_ffa_stats WHERE kills > COALESCE((SELECT kills FROM ethernova_ffa_stats WHERE uuid = ?), -1)")) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return rs.getInt("rank");
                }
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Error obteniendo rank FFA de " + uuid, e);
            }
            return -1;
        }, EthernovaCore.getInstance().getDbExecutor()).exceptionally(ex -> {
            plugin.getLogger().log(Level.SEVERE, "Unhandled error loading FFA rank", ex);
            return -1;
        });
    }
}
