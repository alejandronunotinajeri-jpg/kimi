package com.ethernova.ffa.message;

import com.ethernova.ffa.EthernovaFFA;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Internationalised message manager for EthernovaFFA.
 * Loads messages from messages_{lang}.yml and caches parsed values.
 */
public class MessageManager {

    private final EthernovaFFA plugin;
    private final MiniMessage mini = MiniMessage.miniMessage();
    private final Map<String, String> cache = new ConcurrentHashMap<>();
    private YamlConfiguration messages;

    public MessageManager(EthernovaFFA plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        cache.clear();

        // Save defaults if missing
        if (!new File(plugin.getDataFolder(), "messages_es.yml").exists()) {
            plugin.saveResource("messages_es.yml", false);
        }
        if (!new File(plugin.getDataFolder(), "messages_en.yml").exists()) {
            plugin.saveResource("messages_en.yml", false);
        }

        String lang = plugin.getConfig().getString("general.language", "es");
        File file = new File(plugin.getDataFolder(), "messages_" + lang + ".yml");
        if (!file.exists()) {
            plugin.getLogger().warning("Archivo de mensajes no encontrado: " + file.getName() + " — usando español.");
            file = new File(plugin.getDataFolder(), "messages_es.yml");
        }
        messages = YamlConfiguration.loadConfiguration(file);
        plugin.getLogger().info("Mensajes cargados: " + file.getName());
    }

    /**
     * Get a raw MiniMessage string by key, with optional placeholder replacements.
     * Replacements are pairs: "{key}", "value", "{key2}", "value2", ...
     */
    public String get(String path, String... replacements) {
        String raw = cache.computeIfAbsent(path, k ->
                messages.getString(k, "<red>Missing: " + k));

        // Avoid infinite recursion: don't replace {prefix} when resolving the prefix itself
        String result;
        if ("general.prefix".equals(path)) {
            result = raw;
        } else {
            String prefix = cache.computeIfAbsent("general.prefix", k ->
                    messages.getString(k, ""));
            result = raw.replace("{prefix}", prefix);
        }

        for (int i = 0; i + 1 < replacements.length; i += 2) {
            result = result.replace(replacements[i], replacements[i + 1]);
        }
        return result;
    }

    /**
     * Parse a MiniMessage string into an Adventure Component.
     */
    public Component parse(String miniMessageStr) {
        return mini.deserialize(miniMessageStr);
    }

    /**
     * Send a prefixed message to a CommandSender.
     */
    public void sendMessage(CommandSender sender, String key, String... replacements) {
        String prefix = get("general.prefix");
        String msg = get(key, replacements);
        sender.sendMessage(mini.deserialize(prefix + msg));
    }

    /**
     * Send a raw message (no prefix) to a CommandSender.
     */
    public void sendRaw(CommandSender sender, String key, String... replacements) {
        sender.sendMessage(mini.deserialize(get(key, replacements)));
    }
}
