package com.ethernova.ffa.placeholder;

import com.ethernova.ffa.EthernovaFFA;
import com.ethernova.ffa.model.FFAPlayer;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * PlaceholderAPI expansion for EthernovaFFA.
 * Placeholders: %ethernovaffa_in_ffa%, %ethernovaffa_kills%, %ethernovaffa_deaths%,
 * %ethernovaffa_killstreak%, %ethernovaffa_arena%, %ethernovaffa_kit%, %ethernovaffa_players%
 */
public class FFAPlaceholders extends PlaceholderExpansion {

    private final EthernovaFFA plugin;

    public FFAPlaceholders(EthernovaFFA plugin) {
        this.plugin = plugin;
    }

    @Override public @NotNull String getIdentifier() { return "ethernovaffa"; }
    @Override public @NotNull String getAuthor() { return "Ethernova Team"; }
    @Override public @NotNull String getVersion() { return plugin.getDescription().getVersion(); }
    @Override public boolean persist() { return true; }

    @Override
    public @Nullable String onPlaceholderRequest(Player player, @NotNull String params) {
        if (player == null) return "";

        FFAPlayer fp = plugin.getFFAManager().getFFAPlayer(player.getUniqueId());
        String yes = plugin.getMessageManager().get("placeholder.yes");
        String no = plugin.getMessageManager().get("placeholder.no");
        String none = plugin.getMessageManager().get("placeholder.none");

        return switch (params.toLowerCase()) {
            case "in_ffa" -> fp != null ? yes : no;
            case "kills" -> fp != null ? String.valueOf(fp.getKills()) : "0";
            case "deaths" -> fp != null ? String.valueOf(fp.getDeaths()) : "0";
            case "killstreak" -> fp != null ? String.valueOf(fp.getKillStreak()) : "0";
            case "kdr" -> fp != null ? String.format("%.2f", fp.getKDR()) : "0.00";
            case "arena" -> fp != null ? fp.getArenaName() : none;
            case "kit" -> fp != null ? fp.getSelectedKit() : none;
            case "players" -> String.valueOf(plugin.getFFAManager().getTotalPlayers());
            default -> {
                String lower = params.toLowerCase();
                if (lower.startsWith("kills_")) {
                    String arena = lower.substring(6);
                    if (fp != null && fp.getArenaName().equalsIgnoreCase(arena)) {
                        yield String.valueOf(fp.getKills());
                    }
                    yield "0";
                }
                if (lower.startsWith("deaths_")) {
                    String arena = lower.substring(7);
                    if (fp != null && fp.getArenaName().equalsIgnoreCase(arena)) {
                        yield String.valueOf(fp.getDeaths());
                    }
                    yield "0";
                }
                yield null;
            }
        };
    }
}
