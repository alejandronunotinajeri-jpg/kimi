package com.ethernova.ffa.listener;

import com.ethernova.core.api.CombatAPI;
import com.ethernova.core.EthernovaCore;
import com.ethernova.core.service.ServiceRegistry;
import com.ethernova.ffa.EthernovaFFA;
import com.ethernova.ffa.model.FFAPlayer;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

import java.util.UUID;

/**
 * Core FFA event listener: PvP, death, join, quit, block protection, hunger.
 */
public class FFAListener implements Listener {

    private final EthernovaFFA plugin;
    private final EthernovaCore core;

    public FFAListener(EthernovaFFA plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
    }

    // ═══════════════════════════════════════
    //  PVP DAMAGE
    // ═══════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        if (!plugin.getFFAManager().isInFFA(victim.getUniqueId())) return;

        Player attacker = resolveAttacker(event);
        if (attacker == null) return;
        if (!plugin.getFFAManager().isInFFA(attacker.getUniqueId())) {
            event.setCancelled(true);
            return;
        }

        UUID attackerUuid = attacker.getUniqueId();
        UUID victimUuid = victim.getUniqueId();

        // Spawn protection check: protected players can't deal or take damage
        if (plugin.getSpawnProtectionManager().isProtected(victimUuid)) {
            event.setCancelled(true);
            return;
        }
        if (plugin.getSpawnProtectionManager().isProtected(attackerUuid)) {
            event.setCancelled(true);
            return;
        }

        // Tag both players in combat
        CombatAPI combatAPI = ServiceRegistry.get(CombatAPI.class);
        if (combatAPI != null) {
            combatAPI.tag(attacker, victim, "ffa");
        }
    }

    /**
     * Resolve the attacking player from the event (direct or projectile).
     */
    private Player resolveAttacker(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player player) {
            return player;
        }
        if (event.getDamager() instanceof Projectile projectile) {
            if (projectile.getShooter() instanceof Player shooter) {
                return shooter;
            }
        }
        return null;
    }

    // ═══════════════════════════════════════
    //  PLAYER DEATH
    // ═══════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        UUID victimUuid = victim.getUniqueId();

        if (!plugin.getFFAManager().isInFFA(victimUuid)) return;

        // Prevent drops and death message
        event.getDrops().clear();
        event.setDroppedExp(0);
        event.deathMessage(null);

        // Keep inventory clear (handled by respawn)
        event.setKeepInventory(true);
        event.setKeepLevel(true);

        // Get killer
        Player killer = victim.getKiller();
        if (killer != null && plugin.getFFAManager().isInFFA(killer.getUniqueId())) {
            plugin.getFFAManager().handleKill(killer, victim);
        }

        // Handle death for victim
        plugin.getFFAManager().handleDeath(victim);

        // Untag both from combat
        CombatAPI combatAPI = ServiceRegistry.get(CombatAPI.class);
        if (combatAPI != null) {
            combatAPI.untag(victim);
            if (killer != null) {
                combatAPI.untag(killer);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getFFAManager().isInFFA(player.getUniqueId())) return;

        // In lobby mode, death removes the player from FFA,
        // so set respawn to lobby spawn
        var lobby = core.getLobbyManager();
        if (lobby != null && lobby.isEnabled()) {
            var lobbySpawn = lobby.getLobbySpawn();
            if (lobbySpawn != null) {
                event.setRespawnLocation(lobbySpawn);
            }
            return;
        }

        // Legacy mode: respawn in arena
        FFAPlayer ffaPlayer = plugin.getFFAManager().getFFAPlayer(player.getUniqueId());
        if (ffaPlayer == null) return;

        // Set respawn location to arena spawn
        var arena = plugin.getArenaManager().getArena(ffaPlayer.getArenaName());
        if (arena != null && arena.hasSpawnPoints()) {
            var spawn = arena.getSpawnPointExcluding(ffaPlayer.getLastDeathLoc());
            if (spawn != null) {
                event.setRespawnLocation(spawn);
            }
        }
    }

    // ═══════════════════════════════════════
    //  FALL DAMAGE
    // ═══════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (!plugin.getFFAManager().isInFFA(player.getUniqueId())) return;

        if (event.getCause() == EntityDamageEvent.DamageCause.FALL
                && plugin.getConfig().getBoolean("protection.prevent-fall-damage", false)) {
            event.setCancelled(true);
        }
    }

    // ═══════════════════════════════════════
    //  PLAYER JOIN / QUIT
    // ═══════════════════════════════════════

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        if (plugin.getConfig().getBoolean("general.auto-join", false)) {
            String defaultArena = plugin.getConfig().getString("general.default-arena", "principal");
            // Delay to let other plugins load player data
            org.bukkit.Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (event.getPlayer().isOnline()) {
                    plugin.getFFAManager().joinArena(event.getPlayer(), defaultArena);
                }
            }, 20L);
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        if (plugin.getFFAManager().isInFFA(uuid)) {
            plugin.getFFAManager().forceLeave(uuid);
        }
        // Cleanup FFA subsystem data
        plugin.getArenaRotationManager().cleanupPlayer(uuid);
        plugin.getCustomKitsManager().unloadPlayer(uuid);
        plugin.getEventsManager().cleanupPlayer(uuid);
    }

    // ═══════════════════════════════════════
    //  HUNGER
    // ═══════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFoodLevelChange(FoodLevelChangeEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (!plugin.getFFAManager().isInFFA(player.getUniqueId())) return;

        if (plugin.getConfig().getBoolean("protection.prevent-hunger", true)) {
            event.setCancelled(true);
            player.setFoodLevel(20);
            player.setSaturation(20f);
        }
    }

    // ═══════════════════════════════════════
    //  BLOCK PROTECTION
    // ═══════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        if (!plugin.getFFAManager().isInFFA(event.getPlayer().getUniqueId())) return;
        if (plugin.getConfig().getBoolean("protection.prevent-block-break", true)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        if (!plugin.getFFAManager().isInFFA(event.getPlayer().getUniqueId())) return;
        if (plugin.getConfig().getBoolean("protection.prevent-block-place", true)) {
            event.setCancelled(true);
        }
    }
}
