package com.ethernova.ffa.listener;

import com.ethernova.ffa.EthernovaFFA;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;

/**
 * Handles item interactions in FFA: dropping, picking up, consuming.
 */
public class FFAItemListener implements Listener {

    private final EthernovaFFA plugin;

    public FFAItemListener(EthernovaFFA plugin) {
        this.plugin = plugin;
    }

    // ═══════════════════════════════════════
    //  ITEM DROP
    // ═══════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerDropItem(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getFFAManager().isInFFA(player.getUniqueId())) return;

        if (plugin.getConfig().getBoolean("protection.prevent-item-drop", true)) {
            event.setCancelled(true);
        }
    }

    // ═══════════════════════════════════════
    //  ITEM PICKUP
    // ═══════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityPickupItem(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (!plugin.getFFAManager().isInFFA(player.getUniqueId())) return;

        if (plugin.getConfig().getBoolean("protection.prevent-item-pickup", true)) {
            event.setCancelled(true);
        }
    }

    // ═══════════════════════════════════════
    //  ITEM CONSUMPTION (Potions, food, etc.)
    // ═══════════════════════════════════════

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerItemConsume(PlayerItemConsumeEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getFFAManager().isInFFA(player.getUniqueId())) return;

        ItemStack item = event.getItem();

        // Handle golden apples and other healing items
        if (item.getType() == org.bukkit.Material.GOLDEN_APPLE
                || item.getType() == org.bukkit.Material.ENCHANTED_GOLDEN_APPLE) {
            // Let normal behavior happen, just play sound
            plugin.getCore().getSoundManager().play(player, "reward");
        }

        // Handle potions
        if (item.getItemMeta() instanceof PotionMeta potionMeta) {
            PotionType type = potionMeta.getBasePotionType();
            if (type != null && (type == PotionType.HEALING || type == PotionType.STRONG_HEALING
                    || type == PotionType.REGENERATION || type == PotionType.STRONG_REGENERATION)) {
                plugin.getCore().getSoundManager().play(player, "reward");
            }
        }
    }

    // ═══════════════════════════════════════
    //  OFFHAND SWAP
    // ═══════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerSwapHandItems(PlayerSwapHandItemsEvent event) {
        // Allow offhand swap in FFA (for shields, etc.)
        // No action needed — just ensure event is not accidentally cancelled elsewhere.
    }
}
