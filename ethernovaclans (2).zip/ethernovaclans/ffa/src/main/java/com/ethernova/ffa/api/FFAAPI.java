package com.ethernova.ffa.api;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * Public API interface for EthernovaFFA.
 *
 * <p>Provides methods for querying FFA player state, arena information,
 * statistics, and available kits.</p>
 *
 * <p>Obtain an instance via {@code ServiceRegistry.get(FFAAPI.class)}.</p>
 *
 * <p>All methods are thread-safe. Cached stat methods return data from an
 * in-memory cache and are safe to call on the main thread. Async methods
 * return {@link CompletableFuture} and perform I/O off-thread.</p>
 */
public interface FFAAPI {

    // ═══════════════ Player State ═══════════════

    /**
     * Check if a player is currently in an FFA arena.
     *
     * @param uuid the UUID of the player
     * @return {@code true} if the player is in an FFA arena
     */
    boolean isInFFA(UUID uuid);

    /**
     * Get the arena name a player is currently in.
     *
     * @param uuid the UUID of the player
     * @return the arena name, or {@code null} if the player is not in any FFA arena
     */
    String getPlayerArena(UUID uuid);

    /**
     * Get the current kill streak for a player in their active FFA session.
     *
     * @param uuid the UUID of the player
     * @return the current kill streak count, or {@code 0} if not in FFA
     */
    int getPlayerKillStreak(UUID uuid);

    /**
     * Get the current session kill count for a player in FFA.
     *
     * @param uuid the UUID of the player
     * @return the number of kills in the current session, or {@code 0} if not in FFA
     */
    int getPlayerKills(UUID uuid);

    /**
     * Get the current session death count for a player in FFA.
     *
     * @param uuid the UUID of the player
     * @return the number of deaths in the current session, or {@code 0} if not in FFA
     */
    int getPlayerDeaths(UUID uuid);

    /**
     * Check if a player currently has spawn protection.
     *
     * @param uuid the UUID of the player
     * @return {@code true} if the player has spawn protection active
     */
    boolean isSpawnProtected(UUID uuid);

    // ═══════════════ Arena Info ═══════════════

    /**
     * Get the number of players in a specific arena.
     *
     * @param arenaName the name of the arena
     * @return the player count, or {@code 0} if the arena does not exist
     */
    int getPlayerCount(String arenaName);

    /**
     * Get the total number of FFA players across all arenas.
     *
     * @return the total player count
     */
    int getTotalPlayers();

    /**
     * Get the names of all enabled FFA arenas.
     *
     * @return an unmodifiable list of enabled arena names
     */
    List<String> getEnabledArenaNames();

    // ═══════════════ Stats (Sync Cache) ═══════════════

    /**
     * Get total FFA kills from the statistics cache.
     *
     * @param uuid the UUID of the player
     * @return total lifetime FFA kills
     */
    int getFFAKills(UUID uuid);

    /**
     * Get total FFA deaths from the statistics cache.
     *
     * @param uuid the UUID of the player
     * @return total lifetime FFA deaths
     */
    int getFFADeaths(UUID uuid);

    /**
     * Get the FFA kill/death ratio from the statistics cache.
     *
     * @param uuid the UUID of the player
     * @return the K/D ratio, or {@code 0.0} if there are no deaths
     */
    double getKDR(UUID uuid);

    /**
     * Get the best FFA kill streak ever achieved, from the statistics cache.
     *
     * @param uuid the UUID of the player
     * @return the highest kill streak recorded
     */
    int getFFABestStreak(UUID uuid);

    // ═══════════════ Stats (Async Detailed) ═══════════════

    /**
     * Get detailed FFA statistics asynchronously.
     *
     * <p>The returned array contains:
     * {@code [kills, deaths, bestKillStreak, gamesPlayed, totalPlaytimeSec]}.</p>
     *
     * @param uuid the UUID of the player
     * @return a {@link CompletableFuture} resolving to an {@code int[]} of detailed stats
     */
    CompletableFuture<int[]> getDetailedStats(UUID uuid);

    /**
     * Get a player's leaderboard rank asynchronously.
     *
     * @param uuid the UUID of the player
     * @return a {@link CompletableFuture} resolving to the 1-based rank position
     */
    CompletableFuture<Integer> getRank(UUID uuid);

    // ═══════════════ Kit Info ═══════════════

    /**
     * Get all available FFA kit identifiers.
     *
     * @return a list of kit IDs
     */
    List<String> getAvailableKitIds();

    /**
     * Check if a kit with the given ID exists.
     *
     * @param kitId the kit identifier to check
     * @return {@code true} if the kit exists
     */
    boolean kitExists(String kitId);
}
