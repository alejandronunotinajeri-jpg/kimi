package com.ethernova.ffa.api;

import com.ethernova.ffa.EthernovaFFA;
import com.ethernova.ffa.manager.FFAStatsManager;
import com.ethernova.ffa.model.FFAArena;
import com.ethernova.ffa.model.FFAPlayer;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * Implementation of FFAAPI. Registered with ServiceRegistry on enable.
 */
public class FFAAPIImpl implements FFAAPI {

    private final EthernovaFFA plugin;

    public FFAAPIImpl(EthernovaFFA plugin) {
        this.plugin = plugin;
    }

    // ═══════════════ Player State ═══════════════

    @Override
    public boolean isInFFA(UUID uuid) {
        return plugin.getFFAManager().isInFFA(uuid);
    }

    @Override
    public String getPlayerArena(UUID uuid) {
        FFAPlayer fp = plugin.getFFAManager().getFFAPlayer(uuid);
        return fp != null ? fp.getArenaName() : null;
    }

    @Override
    public int getPlayerKillStreak(UUID uuid) {
        FFAPlayer fp = plugin.getFFAManager().getFFAPlayer(uuid);
        return fp != null ? fp.getKillStreak() : 0;
    }

    @Override
    public int getPlayerKills(UUID uuid) {
        FFAPlayer fp = plugin.getFFAManager().getFFAPlayer(uuid);
        return fp != null ? fp.getKills() : 0;
    }

    @Override
    public int getPlayerDeaths(UUID uuid) {
        FFAPlayer fp = plugin.getFFAManager().getFFAPlayer(uuid);
        return fp != null ? fp.getDeaths() : 0;
    }

    @Override
    public boolean isSpawnProtected(UUID uuid) {
        return plugin.getSpawnProtectionManager().isProtected(uuid);
    }

    // ═══════════════ Arena Info ═══════════════

    @Override
    public int getPlayerCount(String arenaName) {
        return plugin.getFFAManager().getPlayerCount(arenaName);
    }

    @Override
    public int getTotalPlayers() {
        return plugin.getFFAManager().getTotalPlayers();
    }

    @Override
    public List<String> getEnabledArenaNames() {
        return plugin.getArenaManager().getEnabledArenas().stream()
                .map(FFAArena::getName)
                .toList();
    }

    // ═══════════════ Stats (Sync Cache) ═══════════════

    @Override
    public int getFFAKills(UUID uuid) {
        FFAStatsManager.CachedFFAStats stats = plugin.getStatsManager().getCachedStats(uuid);
        return stats != null ? stats.kills() : 0;
    }

    @Override
    public int getFFADeaths(UUID uuid) {
        FFAStatsManager.CachedFFAStats stats = plugin.getStatsManager().getCachedStats(uuid);
        return stats != null ? stats.deaths() : 0;
    }

    @Override
    public double getKDR(UUID uuid) {
        FFAStatsManager.CachedFFAStats stats = plugin.getStatsManager().getCachedStats(uuid);
        return stats != null ? stats.getKDR() : 0.0;
    }

    @Override
    public int getFFABestStreak(UUID uuid) {
        FFAStatsManager.CachedFFAStats stats = plugin.getStatsManager().getCachedStats(uuid);
        return stats != null ? stats.bestStreak() : 0;
    }

    // ═══════════════ Stats (Async Detailed) ═══════════════

    @Override
    public CompletableFuture<int[]> getDetailedStats(UUID uuid) {
        return plugin.getStatsManager().getStats(uuid);
    }

    @Override
    public CompletableFuture<Integer> getRank(UUID uuid) {
        return plugin.getStatsManager().getRank(uuid);
    }

    // ═══════════════ Kit Info ═══════════════

    @Override
    public List<String> getAvailableKitIds() {
        return plugin.getKitManager().getKitIds();
    }

    @Override
    public boolean kitExists(String kitId) {
        return plugin.getKitManager().kitExists(kitId);
    }
}
