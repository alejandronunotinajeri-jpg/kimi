package com.ethernova.ffa.event;

import com.ethernova.core.EthernovaCore;
import com.ethernova.ffa.EthernovaFFA;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import com.ethernova.ffa.manager.FFAManager;
import com.ethernova.ffa.model.FFAPlayer;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;

/**
 * FFA Events Manager — manages 15 server-wide event types.
 * Events auto-schedule on a timer and provide special gameplay modifiers.
 * Matches the original UltimateFFA EventsManager functionality.
 */
public class FFAEventsManager {

    private final EthernovaFFA plugin;
    private final EthernovaCore core;
    private final MiniMessage mini = MiniMessage.miniMessage();

    private EventType activeEvent = null;
    private BukkitTask eventTask;
    private BukkitTask schedulerTask;
    private long eventStartTime;
    private int eventDuration; // seconds
    private int schedulerInterval; // seconds between auto events
    private int schedulerCooldown; // current countdown
    private boolean autoSchedulerEnabled;

    // Event-specific data
    private final Set<UUID> infectedPlayers = ConcurrentHashMap.newKeySet();
    private UUID juggernautUUID;
    private final Map<UUID, Integer> eventKills = new ConcurrentHashMap<>();
    private final List<Entity> spawnedEntities = Collections.synchronizedList(new ArrayList<>());
    /** Saved armor sets for Juggernaut event — restored when event ends or role transfers */
    private final Map<UUID, ItemStack[]> savedArmorSets = new ConcurrentHashMap<>();

    /**
     * 15 Event Types matching the original UltimateFFA.
     */
    public enum EventType {
        DOUBLE_MONEY("Dinero Doble", Material.GOLD_INGOT, "<yellow>", 300,
                "¡Todas las ganancias de monedas se duplican!"),
        TRIPLE_MONEY("Dinero Triple", Material.GOLD_BLOCK, "<gold>", 180,
                "¡Todas las ganancias de monedas se triplican!"),
        FIRE_RAIN("Lluvia de Fuego", Material.FIRE_CHARGE, "<red>", 120,
                "¡Meteoros caen del cielo!"),
        BOSS_FIGHT("Pelea de Jefe", Material.WITHER_SKELETON_SKULL, "<dark_red>", 300,
                "¡Un jefe poderoso ha aparecido!"),
        SPEED_EVENT("Evento de Velocidad", Material.SUGAR, "<aqua>", 180,
                "¡Todos obtienen velocidad extrema!"),
        ARMOR_EVENT("Sin Armadura", Material.CHAINMAIL_CHESTPLATE, "<dark_gray>", 180,
                "¡Todos pelean sin armadura!"),
        LOOT_RAIN("Lluvia de Loot", Material.CHEST, "<green>", 120,
                "¡Items caen del cielo!"),
        KILL_STREAK("Matanza", Material.DIAMOND_SWORD, "<dark_red>", 300,
                "¡Kills dan recompensas extra!"),
        FREE_COSMETICS("Cosméticos Gratis", Material.NETHER_STAR, "<light_purple>", 300,
                "¡Todos los cosméticos están desbloqueados temporalmente!"),
        DOUBLE_XP("XP Doble", Material.EXPERIENCE_BOTTLE, "<green>", 300,
                "¡Todas las ganancias de XP se duplican!"),
        BLOOD_MOON("Luna de Sangre", Material.RED_STAINED_GLASS, "<dark_red>", 240,
                "¡La noche trae un poder oscuro... ¡Daño aumentado!"),
        EXPLOSIVE_FFA("FFA Explosivo", Material.TNT, "<red>", 180,
                "¡Las kills causan explosiones!"),
        INFECTION("Infección", Material.ROTTEN_FLESH, "<dark_green>", 240,
                "¡Un jugador infectado contagia al matar!"),
        JUGGERNAUT("Juggernaut", Material.NETHERITE_CHESTPLATE, "<dark_purple>", 300,
                "¡Un jugador es el Juggernaut super poderoso!"),
        FREE_FOR_ALL_PLUS("FFA+", Material.GOLDEN_SWORD, "<gold>", 240,
                "¡FFA con equipamiento mejorado para todos!");

        private final String displayName;
        private final Material icon;
        private final String color;
        private final int defaultDuration;
        private final String description;

        EventType(String displayName, Material icon, String color, int defaultDuration, String description) {
            this.displayName = displayName;
            this.icon = icon;
            this.color = color;
            this.defaultDuration = defaultDuration;
            this.description = description;
        }

        public String getDisplayName() { return displayName; }
        public Material getIcon() { return icon; }
        public String getColor() { return color; }
        public int getDefaultDuration() { return defaultDuration; }
        public String getDescription() { return description; }
    }

    public FFAEventsManager(EthernovaFFA plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
        loadConfig();
    }

    private void loadConfig() {
        var config = plugin.getConfig();
        schedulerInterval = config.getInt("events.scheduler-interval", 900); // 15 min default
        autoSchedulerEnabled = config.getBoolean("events.auto-scheduler", true);
        schedulerCooldown = schedulerInterval;
    }

    /**
     * Start the auto-scheduler that picks random events.
     */
    public void startScheduler() {
        if (schedulerTask != null) schedulerTask.cancel();
        if (!autoSchedulerEnabled) return;

        schedulerCooldown = schedulerInterval;
        schedulerTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (activeEvent != null) return; // Don't schedule while event is active
            schedulerCooldown--;
            if (schedulerCooldown <= 0) {
                // Only start events if there are FFA players
                if (getFFAOnlinePlayers().isEmpty()) {
                    schedulerCooldown = 30; // Retry in 30 seconds
                    return;
                }
                // Pick a random event
                EventType[] types = EventType.values();
                EventType chosen = types[ThreadLocalRandom.current().nextInt(types.length)];
                startEvent(chosen);
                schedulerCooldown = schedulerInterval;
            }

            // Announce countdown at specific intervals (only to FFA players)
            if (activeEvent == null && schedulerCooldown == 60) {
                broadcastFFA("<yellow>⚡ <gold>Un evento comenzará en <yellow>1 minuto<gold>...");
            } else if (activeEvent == null && schedulerCooldown == 30) {
                broadcastFFA("<yellow>⚡ <gold>Un evento comenzará en <yellow>30 segundos<gold>...");
            } else if (activeEvent == null && schedulerCooldown == 10) {
                broadcastFFA("<yellow>⚡ <gold>Un evento comenzará en <yellow>10 segundos<gold>...");
            }
        }, 20L, 20L); // Every second
    }

    /**
     * Stop the auto-scheduler.
     */
    public void stopScheduler() {
        if (schedulerTask != null) {
            schedulerTask.cancel();
            schedulerTask = null;
        }
    }

    /**
     * Start a specific event.
     */
    public boolean startEvent(EventType type) {
        if (activeEvent != null) {
            return false;
        }

        activeEvent = type;
        eventStartTime = System.currentTimeMillis();
        eventDuration = type.getDefaultDuration();
        eventKills.clear();
        infectedPlayers.clear();
        juggernautUUID = null;

        // Broadcast start (only to FFA players)
        broadcastFFA(type.getColor() + "═════════════════════════════════");
        broadcastFFA(type.getColor() + "⚡ EVENTO: " + type.getDisplayName());
        broadcastFFA(type.getColor() + type.getDescription());
        broadcastFFA(type.getColor() + "Duración: " + (eventDuration / 60) + " minutos");
        broadcastFFA(type.getColor() + "═════════════════════════════════");

        // Show title to FFA players only
        for (Player p : getFFAOnlinePlayers()) {
            p.showTitle(Title.title(
                    mini.deserialize(type.getColor() + "<bold>⚡ " + type.getDisplayName()),
                    mini.deserialize("<gray>" + type.getDescription()),
                    Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(3), Duration.ofMillis(500))
            ));
            p.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.6f, 1.2f);
        }

        // Apply event-specific effects
        applyEventStart(type);

        // Start event timer
        eventTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            long elapsed = (System.currentTimeMillis() - eventStartTime) / 1000;
            long remaining = eventDuration - elapsed;

            if (remaining <= 0) {
                endEvent();
                return;
            }

            // Event tick logic
            tickEvent(type, remaining);

            // Warning messages (FFA only)
            if (remaining == 60) broadcastFFA(type.getColor() + "⚠ El evento termina en 1 minuto!");
            else if (remaining == 30) broadcastFFA(type.getColor() + "⚠ El evento termina en 30 segundos!");
            else if (remaining == 10) broadcastFFA(type.getColor() + "⚠ El evento termina en 10 segundos!");
        }, 20L, 20L);

        plugin.getLogger().info("Evento iniciado: " + type.name());
        return true;
    }

    /**
     * Apply event-specific start effects.
     */
    private void applyEventStart(EventType type) {
        switch (type) {
            case SPEED_EVENT -> {
                for (Player p : getFFAOnlinePlayers()) {
                    p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, eventDuration * 20, 2, false, false));
                }
            }
            case BLOOD_MOON -> {
                for (Player p : getFFAOnlinePlayers()) {
                    p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, eventDuration * 20, 1, false, false));
                    p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, eventDuration * 20, 0, false, false));
                }
                // Set time to night
                for (World w : Bukkit.getWorlds()) {
                    w.setTime(18000);
                }
            }
            case INFECTION -> {
                // Pick a random FFA player as patient zero
                List<Player> online = getFFAOnlinePlayers();
                if (!online.isEmpty()) {
                    Player zero = online.get(ThreadLocalRandom.current().nextInt(online.size()));
                    infectedPlayers.add(zero.getUniqueId());
                    zero.sendMessage(mini.deserialize("<dark_green><bold>¡Eres el paciente cero! Mata a otros para infectarlos."));
                    zero.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, eventDuration * 20, 1, false, true));
                    zero.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, eventDuration * 20, 0, false, true));
                    FFAPlayer zeroData = plugin.getFFAManager().getFFAPlayer(zero.getUniqueId());
                    String arenaInfo = zeroData != null ? " <dark_green>en la arena <yellow>" + zeroData.getArenaName() : "";
                    broadcastFFA("<dark_green>☣ <yellow>" + zero.getName() + " <dark_green>es el paciente cero!" + arenaInfo);
                }
            }
            case JUGGERNAUT -> {
                List<Player> online = getFFAOnlinePlayers();
                if (!online.isEmpty()) {
                    Player jugg = online.get(ThreadLocalRandom.current().nextInt(online.size()));
                    juggernautUUID = jugg.getUniqueId();
                    jugg.sendMessage(mini.deserialize("<dark_purple><bold>¡Eres el Juggernaut! Tienes poderes aumentados."));
                    jugg.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, eventDuration * 20, 1, false, true));
                    jugg.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, eventDuration * 20, 1, false, true));
                    jugg.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, eventDuration * 20, 1, false, true));
                    jugg.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, eventDuration * 20, 0, false, true));
                    // Save original armor before giving netherite
                    savedArmorSets.put(jugg.getUniqueId(), jugg.getInventory().getArmorContents().clone());
                    // Give netherite armor
                    jugg.getInventory().setHelmet(new ItemStack(Material.NETHERITE_HELMET));
                    jugg.getInventory().setChestplate(new ItemStack(Material.NETHERITE_CHESTPLATE));
                    jugg.getInventory().setLeggings(new ItemStack(Material.NETHERITE_LEGGINGS));
                    jugg.getInventory().setBoots(new ItemStack(Material.NETHERITE_BOOTS));
                    // Apply cosmetic armor trims
                    com.ethernova.core.service.ArmorTrimService trimService =
                            com.ethernova.core.service.ServiceRegistry.get(com.ethernova.core.service.ArmorTrimService.class);
                    if (trimService != null) {
                        ItemStack[] trimmed = trimService.applyTrims(
                                jugg.getUniqueId(), jugg.getInventory().getArmorContents());
                        jugg.getInventory().setArmorContents(trimmed);
                    }
                    // Announce with arena name
                    FFAPlayer juggData = plugin.getFFAManager().getFFAPlayer(jugg.getUniqueId());
                    String arenaName = juggData != null ? juggData.getArenaName() : "desconocida";
                    broadcastFFA("<dark_purple>⚔ <yellow>" + jugg.getName() + " <dark_purple>es el Juggernaut en la arena <yellow>" + arenaName + "<dark_purple>! ¡Mátalo para obtener recompensas!");
                }
            }
            case FREE_FOR_ALL_PLUS -> {
                for (Player p : getFFAOnlinePlayers()) {
                    p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, eventDuration * 20, 0, false, false));
                    p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, eventDuration * 20, 0, false, false));
                }
            }
            case BOSS_FIGHT -> {
                spawnBoss();
            }
            default -> {}
        }
    }

    /**
     * Per-second tick for active events.
     */
    private void tickEvent(EventType type, long remaining) {
        switch (type) {
            case FIRE_RAIN -> {
                if (remaining % 3 == 0) { // Every 3 seconds
                    for (Player p : getFFAOnlinePlayers()) {
                        Location loc = p.getLocation().add(
                                ThreadLocalRandom.current().nextDouble(-8, 8),
                                15,
                                ThreadLocalRandom.current().nextDouble(-8, 8)
                        );
                        World world = p.getWorld();
                        world.spawnParticle(Particle.LAVA, loc, 10, 1, 0.5, 1, 0.1);
                        // Spawn a falling fire entity nearby
                        if (ThreadLocalRandom.current().nextInt(3) == 0) {
                            FallingBlock fb = world.spawnFallingBlock(loc, Material.MAGMA_BLOCK.createBlockData());
                            fb.setDropItem(false);
                            fb.setHurtEntities(true);
                            fb.setVelocity(new Vector(0, -0.5, 0));
                            spawnedEntities.add(fb);
                        }
                    }
                }
            }
            case LOOT_RAIN -> {
                if (remaining % 5 == 0) { // Every 5 seconds
                    Material[] lootItems = {
                            Material.GOLDEN_APPLE, Material.ENDER_PEARL, Material.ARROW,
                            Material.SPLASH_POTION, Material.GOLD_INGOT, Material.DIAMOND,
                            Material.COBBLESTONE, Material.COOKED_BEEF
                    };
                    for (Player p : getFFAOnlinePlayers()) {
                        Location loc = p.getLocation().add(
                                ThreadLocalRandom.current().nextDouble(-5, 5),
                                10,
                                ThreadLocalRandom.current().nextDouble(-5, 5)
                        );
                        Material mat = lootItems[ThreadLocalRandom.current().nextInt(lootItems.length)];
                        p.getWorld().dropItem(loc, new ItemStack(mat, 1));
                    }
                }
            }
            default -> {}
        }
    }

    /**
     * Spawn a boss entity for BOSS_FIGHT event.
     */
    private void spawnBoss() {
        // Find a populated area (FFA players only)
        List<Player> online = getFFAOnlinePlayers();
        if (online.isEmpty()) return;

        Player target = online.get(ThreadLocalRandom.current().nextInt(online.size()));
        Location loc = target.getLocation().add(0, 2, 0);
        World world = loc.getWorld();

        // Spawn a Wither Skeleton as the boss
        WitherSkeleton boss = (WitherSkeleton) world.spawnEntity(loc, EntityType.WITHER_SKELETON);
        boss.customName(mini.deserialize("<dark_red><bold>⚔ JEFE ETHERNOVA ⚔"));
        boss.setCustomNameVisible(true);
        boss.getEquipment().setItemInMainHand(new ItemStack(Material.NETHERITE_SWORD));
        boss.getEquipment().setHelmet(new ItemStack(Material.NETHERITE_HELMET));
        boss.getEquipment().setChestplate(new ItemStack(Material.NETHERITE_CHESTPLATE));
        boss.getEquipment().setLeggings(new ItemStack(Material.NETHERITE_LEGGINGS));
        boss.getEquipment().setBoots(new ItemStack(Material.NETHERITE_BOOTS));
        boss.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1, false, false));
        boss.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 2, false, false));
        boss.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, false, false));

        // Set high health
        var maxHealthAttr = boss.getAttribute(Attribute.MAX_HEALTH);
        if (maxHealthAttr != null) {
            maxHealthAttr.setBaseValue(500);
            boss.setHealth(500);
        }

        spawnedEntities.add(boss);
        broadcastFFA("<dark_red>☠ ¡Un jefe ha aparecido cerca de <yellow>" + target.getName() + "<dark_red>! ¡Destrúyelo para obtener recompensas!");
    }

    /**
     * End the currently active event.
     */
    public void endEvent() {
        if (activeEvent == null) return;

        EventType endingEvent = activeEvent;

        // Broadcast end (FFA only)
        broadcastFFA(endingEvent.getColor() + "═════════════════════════════════");
        broadcastFFA(endingEvent.getColor() + "⚡ EVENTO TERMINADO: " + endingEvent.getDisplayName());

        // Event-specific cleanup and rewards
        applyEventEnd(endingEvent);

        broadcastFFA(endingEvent.getColor() + "═════════════════════════════════");

        // Show title (FFA only)
        for (Player p : getFFAOnlinePlayers()) {
            p.showTitle(Title.title(
                    mini.deserialize("<gray>Evento Terminado"),
                    mini.deserialize(endingEvent.getColor() + endingEvent.getDisplayName()),
                    Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(2), Duration.ofMillis(300))
            ));
            p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1f);
        }

        // Cancel timer
        if (eventTask != null) {
            eventTask.cancel();
            eventTask = null;
        }

        // Cleanup
        cleanupEntities();
        infectedPlayers.clear();
        juggernautUUID = null;
        savedArmorSets.clear();
        activeEvent = null;
        eventKills.clear();

        plugin.getLogger().info("Evento terminado: " + endingEvent.name());
    }

    /**
     * Apply event-specific end effects and give rewards.
     */
    private void applyEventEnd(EventType type) {
        switch (type) {
            case SPEED_EVENT, BLOOD_MOON, FREE_FOR_ALL_PLUS -> {
                for (Player p : getFFAOnlinePlayers()) {
                    p.removePotionEffect(PotionEffectType.SPEED);
                    p.removePotionEffect(PotionEffectType.STRENGTH);
                    p.removePotionEffect(PotionEffectType.NIGHT_VISION);
                    p.removePotionEffect(PotionEffectType.REGENERATION);
                }
            }
            case KILL_STREAK -> {
                // Reward top killer
                if (!eventKills.isEmpty()) {
                    UUID topKiller = eventKills.entrySet().stream()
                            .max(Map.Entry.comparingByValue())
                            .map(Map.Entry::getKey).orElse(null);
                    if (topKiller != null) {
                        Player top = Bukkit.getPlayer(topKiller);
                        int kills = eventKills.getOrDefault(topKiller, 0);
                        if (top != null) {
                            core.getProfileManager().addCoins(topKiller, kills * 100.0);
                            broadcastFFA("<gold>🏆 <yellow>" + top.getName() + " <gold>fue el mayor asesino con <yellow>" + kills + " kills<gold>!");
                        }
                    }
                }
            }
            case INFECTION -> {
                int infectedCount = infectedPlayers.size();
                int totalPlayers = getFFAOnlinePlayers().size();
                broadcastFFA("<dark_green>☣ Infectados: <yellow>" + infectedCount + "/" + totalPlayers);
                // Reward survivors
                for (Player p : getFFAOnlinePlayers()) {
                    if (!infectedPlayers.contains(p.getUniqueId())) {
                        core.getProfileManager().addCoins(p.getUniqueId(), 500);
                        p.sendMessage(mini.deserialize("<green>✔ ¡Sobreviviste a la infección! +500 monedas"));
                    }
                }
                // Remove effects
                for (UUID uuid : infectedPlayers) {
                    Player p = Bukkit.getPlayer(uuid);
                    if (p != null) {
                        p.removePotionEffect(PotionEffectType.SPEED);
                        p.removePotionEffect(PotionEffectType.GLOWING);
                    }
                }
            }
            case JUGGERNAUT -> {
                if (juggernautUUID != null) {
                    Player jugg = Bukkit.getPlayer(juggernautUUID);
                    if (jugg != null) {
                        jugg.removePotionEffect(PotionEffectType.RESISTANCE);
                        jugg.removePotionEffect(PotionEffectType.STRENGTH);
                        jugg.removePotionEffect(PotionEffectType.REGENERATION);
                        jugg.removePotionEffect(PotionEffectType.GLOWING);
                        // Restore original armor
                        ItemStack[] savedArmor = savedArmorSets.remove(juggernautUUID);
                        if (savedArmor != null) {
                            jugg.getInventory().setArmorContents(savedArmor);
                        }
                        int juggKills = eventKills.getOrDefault(juggernautUUID, 0);
                        if (juggKills > 0) {
                            core.getProfileManager().addCoins(juggernautUUID, juggKills * 200.0);
                            broadcastFFA("<dark_purple>⚔ El Juggernaut <yellow>" + jugg.getName() +
                                    " <dark_purple>consiguió <yellow>" + juggKills + " kills<dark_purple>!");
                        }
                    } else {
                        savedArmorSets.remove(juggernautUUID);
                    }
                }
            }
            default -> {}
        }
    }

    /**
     * Handle a kill during an active event.
     * Called from the combat listener.
     */
    public void handleEventKill(Player killer, Player victim) {
        if (activeEvent == null) return;

        eventKills.merge(killer.getUniqueId(), 1, Integer::sum);

        switch (activeEvent) {
            case DOUBLE_MONEY, TRIPLE_MONEY -> {} // Multiplier already applied via FFAManager.handleKill → getMoneyMultiplier()
            case KILL_STREAK -> {
                int kills = eventKills.getOrDefault(killer.getUniqueId(), 0);
                double bonus = kills * 25.0;
                core.getProfileManager().addCoins(killer.getUniqueId(), bonus);
                killer.sendMessage(mini.deserialize("<gold>⚡ Kill #" + kills + " en el evento! +" +
                        String.format("%.0f", bonus) + " monedas bonus"));
            }
            case EXPLOSIVE_FFA -> {
                // Create explosion at victim's location
                Location loc = victim.getLocation();
                loc.getWorld().createExplosion(loc, 2.0f, false, false);
                loc.getWorld().spawnParticle(Particle.EXPLOSION, loc, 5, 1, 1, 1, 0.1);
            }
            case INFECTION -> {
                if (infectedPlayers.contains(killer.getUniqueId())) {
                    infectedPlayers.add(victim.getUniqueId());
                    victim.sendMessage(mini.deserialize("<dark_green><bold>☣ ¡Has sido infectado!"));
                    victim.addPotionEffect(new PotionEffect(PotionEffectType.SPEED,
                            getRemainingTicks(), 1, false, true));
                    victim.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING,
                            getRemainingTicks(), 0, false, true));
                    broadcastFFA("<dark_green>☣ <yellow>" + victim.getName() + " <dark_green>ha sido infectado! Total: " +
                            infectedPlayers.size());
                }
            }
            case JUGGERNAUT -> {
                if (victim.getUniqueId().equals(juggernautUUID)) {
                    // Killer becomes the new juggernaut
                    broadcastFFA("<dark_purple>⚔ <yellow>" + killer.getName() + " <dark_purple>ha matado al Juggernaut y toma su lugar!");
                    core.getProfileManager().addCoins(killer.getUniqueId(), 1000);

                    // Restore old juggernaut's armor
                    ItemStack[] oldArmor = savedArmorSets.remove(victim.getUniqueId());
                    if (oldArmor != null) {
                        victim.getInventory().setArmorContents(oldArmor);
                    }

                    // Remove effects from old juggernaut
                    victim.removePotionEffect(PotionEffectType.RESISTANCE);
                    victim.removePotionEffect(PotionEffectType.STRENGTH);
                    victim.removePotionEffect(PotionEffectType.REGENERATION);
                    victim.removePotionEffect(PotionEffectType.GLOWING);

                    // Save new juggernaut's armor and apply netherite
                    savedArmorSets.put(killer.getUniqueId(), killer.getInventory().getArmorContents().clone());

                    // Apply to new juggernaut
                    juggernautUUID = killer.getUniqueId();
                    int remaining = getRemainingTicks();
                    killer.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, remaining, 1, false, true));
                    killer.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, remaining, 1, false, true));
                    killer.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, remaining, 1, false, true));
                    killer.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, remaining, 0, false, true));
                    killer.getInventory().setHelmet(new ItemStack(Material.NETHERITE_HELMET));
                    killer.getInventory().setChestplate(new ItemStack(Material.NETHERITE_CHESTPLATE));
                    killer.getInventory().setLeggings(new ItemStack(Material.NETHERITE_LEGGINGS));
                    killer.getInventory().setBoots(new ItemStack(Material.NETHERITE_BOOTS));
                }
            }
            case BLOOD_MOON -> {
                // Extra damage already applied via STRENGTH effect
                core.getProfileManager().addCoins(killer.getUniqueId(), 25);
            }
            default -> {}
        }
    }

    /**
     * Get remaining event time in ticks.
     */
    private int getRemainingTicks() {
        long elapsed = (System.currentTimeMillis() - eventStartTime) / 1000;
        return (int) Math.max(0, (eventDuration - elapsed) * 20);
    }

    /**
     * Remove all spawned entities.
     */
    private void cleanupEntities() {
        synchronized (spawnedEntities) {
            for (Entity e : spawnedEntities) {
                if (e != null && !e.isDead()) {
                    e.remove();
                }
            }
            spawnedEntities.clear();
        }
    }

    /**
     * Force stop any active event (admin command).
     */
    public void forceStop() {
        if (activeEvent != null) {
            broadcastFFA("<red>⚠ El evento ha sido detenido por un administrador.");
            endEvent();
        }
    }

    /**
     * Get only the online players currently in FFA arenas.
     */
    private List<Player> getFFAOnlinePlayers() {
        FFAManager ffaManager = plugin.getFFAManager();
        List<Player> result = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (ffaManager.isInFFA(p.getUniqueId())) {
                result.add(p);
            }
        }
        return result;
    }

    /**
     * Broadcast a message only to players in FFA.
     */
    private void broadcastFFA(String message) {
        Component comp = mini.deserialize(message);
        for (Player p : getFFAOnlinePlayers()) {
            p.sendMessage(comp);
        }
    }

    /**
     * Broadcast a message to all online players.
     */
    private void broadcast(String message) {
        Component comp = mini.deserialize(message);
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.sendMessage(comp);
        }
    }

    /**
     * Cleanup on plugin disable.
     */
    public void cleanup() {
        if (activeEvent != null) endEvent();
        stopScheduler();
        cleanupEntities();
    }

    // --- Getters ---
    public EventType getActiveEvent() { return activeEvent; }
    public boolean isEventActive() { return activeEvent != null; }
    public boolean isEventActive(EventType type) { return activeEvent == type; }
    public long getEventStartTime() { return eventStartTime; }
    public int getEventDuration() { return eventDuration; }
    public int getSchedulerCooldown() { return schedulerCooldown; }
    public Set<UUID> getInfectedPlayers() { return Collections.unmodifiableSet(infectedPlayers); }
    public UUID getJuggernautUUID() { return juggernautUUID; }
    public Map<UUID, Integer> getEventKills() { return Collections.unmodifiableMap(eventKills); }

    /**
     * Check if a specific multiplier event is active.
     */
    public double getMoneyMultiplier() {
        if (activeEvent == EventType.DOUBLE_MONEY) return 2.0;
        if (activeEvent == EventType.TRIPLE_MONEY) return 3.0;
        return 1.0;
    }

    public double getXPMultiplier() {
        if (activeEvent == EventType.DOUBLE_XP) return 2.0;
        return 1.0;
    }

    public boolean isInfected(UUID uuid) {
        return infectedPlayers.contains(uuid);
    }

    public boolean isJuggernaut(UUID uuid) {
        return uuid.equals(juggernautUUID);
    }

    /**
     * Remove player-specific event data on quit.
     */
    public void cleanupPlayer(UUID uuid) {
        eventKills.remove(uuid);
        infectedPlayers.remove(uuid);
        savedArmorSets.remove(uuid);
        if (uuid.equals(juggernautUUID)) {
            // Transfer juggernaut role to a random FFA player
            juggernautUUID = null;
            List<Player> online = getFFAOnlinePlayers();
            online.removeIf(p -> p.getUniqueId().equals(uuid));
            if (!online.isEmpty() && activeEvent == EventType.JUGGERNAUT) {
                Player newJugg = online.get(ThreadLocalRandom.current().nextInt(online.size()));
                juggernautUUID = newJugg.getUniqueId();
                int remaining = getRemainingTicks();
                savedArmorSets.put(newJugg.getUniqueId(), newJugg.getInventory().getArmorContents().clone());
                newJugg.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, remaining, 1, false, true));
                newJugg.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, remaining, 1, false, true));
                newJugg.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, remaining, 1, false, true));
                newJugg.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, remaining, 0, false, true));
                newJugg.getInventory().setHelmet(new ItemStack(Material.NETHERITE_HELMET));
                newJugg.getInventory().setChestplate(new ItemStack(Material.NETHERITE_CHESTPLATE));
                newJugg.getInventory().setLeggings(new ItemStack(Material.NETHERITE_LEGGINGS));
                newJugg.getInventory().setBoots(new ItemStack(Material.NETHERITE_BOOTS));
                broadcastFFA("<dark_purple>⚔ <yellow>" + newJugg.getName() + " <dark_purple>es el nuevo Juggernaut!");
            }
        }
    }
}
