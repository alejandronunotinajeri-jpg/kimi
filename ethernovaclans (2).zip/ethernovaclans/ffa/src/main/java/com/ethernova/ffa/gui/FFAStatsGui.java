package com.ethernova.ffa.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.CoreGui;
import com.ethernova.ffa.EthernovaFFA;
import com.ethernova.ffa.message.MessageManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.List;
import java.util.UUID;

/**
 * Show player FFA stats in a GUI. CoreGui based.
 */
public class FFAStatsGui extends CoreGui {

    private final EthernovaFFA plugin;
    private final UUID targetUuid;
    private final String targetName;

    public FFAStatsGui(EthernovaCore core, EthernovaFFA plugin, Player player,
                       UUID targetUuid, String targetName) {
        super(core, player);
        this.plugin = plugin;
        this.targetUuid = targetUuid;
        this.targetName = targetName;
    }

    private MessageManager mm() { return plugin.getMessageManager(); }

    public void open() {
        openInventory(mm().get("gui.stats.title", "{player}", targetName), 45);
    }

    @Override
    protected void populateItems() {
        // Load stats async, then populate on main thread
        plugin.getStatsManager().getStats(targetUuid).thenAccept(stats -> {
            plugin.getStatsManager().getRank(targetUuid).thenAccept(rank -> {
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (inventory == null) return;

                    int kills = stats[0];
                    int deaths = stats[1];
                    int bestStreak = stats[2];
                    int gamesPlayed = stats[3];
                    int playtimeSeconds = stats[4];

                    double kdr = deaths == 0 ? kills : (double) kills / deaths;
                    String playtimeStr = formatPlaytime(playtimeSeconds);

                    // ── Main stats head ──
                    List<String> mainLore = List.of(
                            "",
                            "<dark_gray>▎ " + mm().get("gui.stats.ranking", "{rank}", rank > 0 ? String.valueOf(rank) : "?"),
                            "",
                            "<dark_gray>▎ " + mm().get("gui.stats.main-kills", "{kills}", String.valueOf(kills)),
                            "<dark_gray>▎ " + mm().get("gui.stats.main-deaths", "{deaths}", String.valueOf(deaths)),
                            "<dark_gray>▎ " + mm().get("gui.stats.main-kdr", "{kdr}", String.format("%.2f", kdr)),
                            "",
                            "<dark_gray>▎ " + mm().get("gui.stats.main-streak", "{streak}", String.valueOf(bestStreak)),
                            "<dark_gray>▎ " + mm().get("gui.stats.main-games", "{games}", String.valueOf(gamesPlayed)),
                            "<dark_gray>▎ " + mm().get("gui.stats.main-playtime", "{playtime}", playtimeStr),
                            ""
                    );
                    setItem(13, createItem(Material.PLAYER_HEAD, "<gold><bold>" + targetName, mainLore));

                    // ── Kill stats ──
                    List<String> killLore = List.of(
                            "",
                            "<dark_gray>▎ " + mm().get("gui.stats.kills-desc"),
                            "<dark_gray>▎ " + mm().get("gui.stats.kills-line", "{kills}", String.valueOf(kills)),
                            ""
                    );
                    setItem(20, createItem(Material.DIAMOND_SWORD, mm().get("gui.stats.kills-title"), killLore));

                    // ── Death stats ──
                    List<String> deathLore = List.of(
                            "",
                            "<dark_gray>▎ " + mm().get("gui.stats.deaths-desc"),
                            "<dark_gray>▎ " + mm().get("gui.stats.deaths-line", "{deaths}", String.valueOf(deaths)),
                            ""
                    );
                    setItem(22, createItem(Material.SKELETON_SKULL, mm().get("gui.stats.deaths-title"), deathLore));

                    // ── KDR ──
                    List<String> kdrLore = List.of(
                            "",
                            "<dark_gray>▎ " + mm().get("gui.stats.kdr-desc"),
                            "<dark_gray>▎ " + mm().get("gui.stats.kdr-line", "{kdr}", String.format("%.2f", kdr)),
                            ""
                    );
                    setItem(24, createItem(Material.GOLDEN_SWORD, mm().get("gui.stats.kdr-title"), kdrLore));

                    // ── Best streak ──
                    List<String> streakLore = List.of(
                            "",
                            "<dark_gray>▎ " + mm().get("gui.stats.streak-desc"),
                            "<dark_gray>▎ " + mm().get("gui.stats.streak-line", "{streak}", String.valueOf(bestStreak)),
                            ""
                    );
                    setItem(30, createItem(Material.BLAZE_POWDER, mm().get("gui.stats.streak-title"), streakLore));

                    // ── Games played ──
                    List<String> gamesLore = List.of(
                            "",
                            "<dark_gray>▎ " + mm().get("gui.stats.games-desc"),
                            "<dark_gray>▎ " + mm().get("gui.stats.games-line", "{games}", String.valueOf(gamesPlayed)),
                            ""
                    );
                    setItem(32, createItem(Material.BOOK, mm().get("gui.stats.games-title"), gamesLore));

                    // ── Back ──
                    setItem(36, createItem(Material.ARROW, "<red>← Volver", 
                            List.of("<gray>Regresa al menú anterior")));
                    slotActions.put(36, "BACK");

                    // ── Close ──
                    setItem(40, createItem(Material.BARRIER, mm().get("gui.stats.close")));
                    slotActions.put(40, "CLOSE");
                });
            });
        });
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if ("BACK".equals(action)) {
            playSound("click");
            player.closeInventory();
            return true;
        }
        return false;
    }

    private String formatPlaytime(int totalSeconds) {
        if (totalSeconds < 60) return totalSeconds + "s";
        int hours = totalSeconds / 3600;
        int minutes = (totalSeconds % 3600) / 60;
        int seconds = totalSeconds % 60;
        if (hours > 0) {
            return hours + "h " + minutes + "m";
        }
        return minutes + "m " + seconds + "s";
    }
}
