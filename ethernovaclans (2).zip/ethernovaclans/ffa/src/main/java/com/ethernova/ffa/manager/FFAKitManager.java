package com.ethernova.ffa.manager;

import com.ethernova.ffa.EthernovaFFA;
import com.ethernova.ffa.model.FFAKit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages FFA kits. Loads defaults and supports config-based customization.
 */
public class FFAKitManager {

    private final EthernovaFFA plugin;
    private final Map<String, FFAKit> kits = new ConcurrentHashMap<>();

    public FFAKitManager(EthernovaFFA plugin) {
        this.plugin = plugin;
    }

    public void loadKits() {
        kits.clear();
        registerDefaults();
        loadCustomKits();
        plugin.getLogger().info("Cargados " + kits.size() + " kits FFA.");
    }

    /**
     * Load custom kits from config.yml custom-kits section.
     */
    private void loadCustomKits() {
        var section = plugin.getConfig().getConfigurationSection("custom-kits");
        if (section == null) return;
        for (String kitId : section.getKeys(false)) {
            var kitSec = section.getConfigurationSection(kitId);
            if (kitSec == null) continue;
            try {
                String name = kitSec.getString("name", kitId);
                Material icon = Material.matchMaterial(kitSec.getString("icon", "IRON_SWORD"));
                if (icon == null) icon = Material.IRON_SWORD;
                ItemStack[] armor = parseArmor(kitSec);
                ItemStack[] inv = parseInventory(kitSec.getStringList("items"));
                // No effects for custom kits (keep simple)
                kits.put(kitId.toLowerCase(), new FFAKit(kitId, name, icon, armor, inv, java.util.List.of()));
            } catch (Exception e) {
                plugin.getLogger().warning("Error cargando kit custom '" + kitId + "': " + e.getMessage());
            }
        }
    }

    private ItemStack[] parseArmor(org.bukkit.configuration.ConfigurationSection sec) {
        ItemStack[] armor = new ItemStack[4];
        var armorSec = sec.getConfigurationSection("armor");
        if (armorSec == null) return armor;
        armor[0] = parseMat(armorSec.getString("boots"));
        armor[1] = parseMat(armorSec.getString("leggings"));
        armor[2] = parseMat(armorSec.getString("chestplate"));
        armor[3] = parseMat(armorSec.getString("helmet"));
        return armor;
    }

    private ItemStack[] parseInventory(java.util.List<String> items) {
        ItemStack[] inv = new ItemStack[36];
        int i = 0;
        for (String entry : items) {
            if (i >= 36) break;
            String[] parts = entry.split(":");
            Material mat = Material.matchMaterial(parts[0]);
            if (mat == null) continue;
            int amount = parts.length > 1 ? Integer.parseInt(parts[1]) : 1;
            inv[i++] = new ItemStack(mat, amount);
        }
        return inv;
    }

    private ItemStack parseMat(String name) {
        if (name == null || name.isEmpty()) return null;
        Material mat = Material.matchMaterial(name);
        return mat != null ? new ItemStack(mat) : null;
    }

    private void registerDefaults() {
        // ── Warrior: Iron armor, diamond sword ──
        kits.put("warrior", new FFAKit(
                "warrior",
                "<gradient:#ff6600:#ff3300>Guerrero</gradient>",
                Material.DIAMOND_SWORD,
                new ItemStack[]{
                        new ItemStack(Material.IRON_BOOTS),
                        new ItemStack(Material.IRON_LEGGINGS),
                        new ItemStack(Material.IRON_CHESTPLATE),
                        new ItemStack(Material.IRON_HELMET)
                },
                createWarriorInventory(),
                List.of()
        ));

        // ── Archer: Chainmail armor, bow, arrows ──
        kits.put("archer", new FFAKit(
                "archer",
                "<gradient:#00ff88:#00cc66>Arquero</gradient>",
                Material.BOW,
                new ItemStack[]{
                        new ItemStack(Material.CHAINMAIL_BOOTS),
                        new ItemStack(Material.CHAINMAIL_LEGGINGS),
                        new ItemStack(Material.CHAINMAIL_CHESTPLATE),
                        new ItemStack(Material.CHAINMAIL_HELMET)
                },
                createArcherInventory(),
                List.of()
        ));

        // ── Tank: Diamond armor, iron sword ──
        kits.put("tank", new FFAKit(
                "tank",
                "<gradient:#5555ff:#3333cc>Tanque</gradient>",
                Material.DIAMOND_CHESTPLATE,
                new ItemStack[]{
                        enchant(new ItemStack(Material.DIAMOND_BOOTS), Enchantment.PROTECTION, 2),
                        enchant(new ItemStack(Material.DIAMOND_LEGGINGS), Enchantment.PROTECTION, 2),
                        enchant(new ItemStack(Material.DIAMOND_CHESTPLATE), Enchantment.PROTECTION, 2),
                        enchant(new ItemStack(Material.DIAMOND_HELMET), Enchantment.PROTECTION, 2)
                },
                createTankInventory(),
                List.of(new PotionEffect(PotionEffectType.SLOWNESS, Integer.MAX_VALUE, 0, false, false, true))
        ));

        // ── Berserker: Leather armor, netherite sword, speed ──
        kits.put("berserker", new FFAKit(
                "berserker",
                "<gradient:#ff0000:#cc0000>Berserker</gradient>",
                Material.NETHERITE_SWORD,
                new ItemStack[]{
                        new ItemStack(Material.LEATHER_BOOTS),
                        new ItemStack(Material.LEATHER_LEGGINGS),
                        new ItemStack(Material.LEATHER_CHESTPLATE),
                        new ItemStack(Material.LEATHER_HELMET)
                },
                createBerserkerInventory(),
                List.of(
                        new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1, false, false, true),
                        new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 0, false, false, true)
                )
        ));

        // ── Healer: Iron armor, splash heal pots, regen ──
        kits.put("healer", new FFAKit(
                "healer",
                "<gradient:#ff69b4:#ff1493>Sanador</gradient>",
                Material.SPLASH_POTION,
                new ItemStack[]{
                        new ItemStack(Material.IRON_BOOTS),
                        new ItemStack(Material.IRON_LEGGINGS),
                        new ItemStack(Material.IRON_CHESTPLATE),
                        new ItemStack(Material.IRON_HELMET)
                },
                createHealerInventory(),
                List.of(new PotionEffect(PotionEffectType.REGENERATION, Integer.MAX_VALUE, 0, false, false, true))
        ));
    }

    // ── Inventory builders ──

    private ItemStack[] createWarriorInventory() {
        ItemStack[] inv = new ItemStack[36];
        inv[0] = enchant(new ItemStack(Material.DIAMOND_SWORD), Enchantment.SHARPNESS, 1);
        inv[1] = new ItemStack(Material.GOLDEN_APPLE, 3);
        inv[2] = new ItemStack(Material.COOKED_BEEF, 16);
        return inv;
    }

    private ItemStack[] createArcherInventory() {
        ItemStack[] inv = new ItemStack[36];
        inv[0] = new ItemStack(Material.IRON_SWORD);
        ItemStack bow = new ItemStack(Material.BOW);
        enchant(bow, Enchantment.POWER, 2);
        enchant(bow, Enchantment.INFINITY, 1);
        inv[1] = bow;
        inv[2] = new ItemStack(Material.GOLDEN_APPLE, 2);
        inv[9] = new ItemStack(Material.ARROW, 1);
        return inv;
    }

    private ItemStack[] createTankInventory() {
        ItemStack[] inv = new ItemStack[36];
        inv[0] = enchant(new ItemStack(Material.IRON_SWORD), Enchantment.SHARPNESS, 2);
        inv[1] = new ItemStack(Material.GOLDEN_APPLE, 5);
        inv[2] = new ItemStack(Material.COOKED_BEEF, 32);
        inv[3] = new ItemStack(Material.SHIELD);
        return inv;
    }

    private ItemStack[] createBerserkerInventory() {
        ItemStack[] inv = new ItemStack[36];
        inv[0] = enchant(new ItemStack(Material.NETHERITE_SWORD), Enchantment.SHARPNESS, 3);
        inv[1] = new ItemStack(Material.GOLDEN_APPLE, 2);
        return inv;
    }

    private ItemStack[] createHealerInventory() {
        ItemStack[] inv = new ItemStack[36];
        inv[0] = new ItemStack(Material.IRON_SWORD);
        inv[1] = new ItemStack(Material.GOLDEN_APPLE, 3);

        // Splash healing potions
        for (int i = 2; i <= 6; i++) {
            inv[i] = createSplashHealingPotion();
        }

        // Regen potions in second row
        for (int i = 9; i <= 11; i++) {
            inv[i] = createRegenPotion();
        }

        return inv;
    }

    private ItemStack createSplashHealingPotion() {
        ItemStack potion = new ItemStack(Material.SPLASH_POTION);
        PotionMeta meta = (PotionMeta) potion.getItemMeta();
        if (meta != null) {
            meta.setBasePotionType(PotionType.STRONG_HEALING);
            potion.setItemMeta(meta);
        }
        return potion;
    }

    private ItemStack createRegenPotion() {
        ItemStack potion = new ItemStack(Material.POTION);
        PotionMeta meta = (PotionMeta) potion.getItemMeta();
        if (meta != null) {
            meta.setBasePotionType(PotionType.STRONG_REGENERATION);
            potion.setItemMeta(meta);
        }
        return potion;
    }

    private ItemStack enchant(ItemStack item, Enchantment enchantment, int level) {
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.addEnchant(enchantment, level, true);
            item.setItemMeta(meta);
        }
        return item;
    }

    // ── Public API ──

    public FFAKit getKit(String id) {
        return kits.get(id.toLowerCase());
    }

    public FFAKit getDefaultKit() {
        String defaultId = plugin.getConfig().getString("kits.default-kit", "warrior");
        FFAKit kit = kits.get(defaultId.toLowerCase());
        if (kit != null) return kit;
        return kits.isEmpty() ? null : kits.values().iterator().next();
    }

    public Collection<FFAKit> getAllKits() {
        return Collections.unmodifiableCollection(kits.values());
    }

    public List<String> getKitIds() {
        return new ArrayList<>(kits.keySet());
    }

    public boolean kitExists(String id) {
        return kits.containsKey(id.toLowerCase());
    }

    /**
     * Create a kit from a player's current inventory and save to config.
     */
    public boolean createKitFromPlayer(String id, String name, org.bukkit.entity.Player player) {
        if (kitExists(id)) return false;

        Material icon = player.getInventory().getItemInMainHand().getType();
        if (icon.isAir()) icon = Material.IRON_SWORD;

        ItemStack[] armor = new ItemStack[4];
        ItemStack[] pArmor = player.getInventory().getArmorContents();
        for (int i = 0; i < 4 && i < pArmor.length; i++) {
            armor[i] = pArmor[i] != null ? pArmor[i].clone() : null;
        }

        ItemStack[] inv = new ItemStack[36];
        for (int i = 0; i < 36; i++) {
            ItemStack item = player.getInventory().getItem(i);
            if (item != null && !item.getType().isAir()) inv[i] = item.clone();
        }

        FFAKit kit = new FFAKit(id, name, icon, armor, inv, java.util.List.of());
        kits.put(id.toLowerCase(), kit);
        saveKitToConfig(id.toLowerCase(), kit);
        return true;
    }

    /**
     * Delete a kit from memory and config.
     */
    public boolean deleteKit(String id) {
        FFAKit removed = kits.remove(id.toLowerCase());
        if (removed == null) return false;
        // Only delete from config if it's a custom kit
        plugin.getConfig().set("custom-kits." + id.toLowerCase(), null);
        plugin.saveConfig();
        return true;
    }

    private void saveKitToConfig(String id, FFAKit kit) {
        String path = "custom-kits." + id;
        plugin.getConfig().set(path + ".name", kit.getName());
        plugin.getConfig().set(path + ".icon", kit.getIcon().name());
        if (kit.getArmor() != null) {
            ItemStack[] a = kit.getArmor();
            if (a[3] != null) plugin.getConfig().set(path + ".armor.helmet", a[3].getType().name());
            if (a[2] != null) plugin.getConfig().set(path + ".armor.chestplate", a[2].getType().name());
            if (a[1] != null) plugin.getConfig().set(path + ".armor.leggings", a[1].getType().name());
            if (a[0] != null) plugin.getConfig().set(path + ".armor.boots", a[0].getType().name());
        }
        java.util.List<String> items = new java.util.ArrayList<>();
        if (kit.getInventory() != null) {
            for (ItemStack item : kit.getInventory()) {
                if (item != null && !item.getType().isAir()) {
                    items.add(item.getType().name() + ":" + item.getAmount());
                }
            }
        }
        plugin.getConfig().set(path + ".items", items);
        plugin.saveConfig();
    }
}
