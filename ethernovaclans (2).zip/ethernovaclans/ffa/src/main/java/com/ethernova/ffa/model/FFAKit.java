package com.ethernova.ffa.model;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;

import java.util.Collections;
import java.util.List;

/**
 * Kit definition for FFA. Apply method equips the player with the kit.
 */
public class FFAKit {

    private final String id;
    private final String name;
    private final Material icon;
    private final ItemStack[] armor;
    private final ItemStack[] inventory;
    private final List<PotionEffect> effects;

    public FFAKit(String id, String name, Material icon, ItemStack[] armor,
                  ItemStack[] inventory, List<PotionEffect> effects) {
        this.id = id;
        this.name = name;
        this.icon = icon;
        this.armor = armor;
        this.inventory = inventory;
        this.effects = effects != null ? effects : Collections.emptyList();
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public Material getIcon() { return icon; }
    public ItemStack[] getArmor() { return armor; }
    public ItemStack[] getInventory() { return inventory; }
    public List<PotionEffect> getEffects() { return Collections.unmodifiableList(effects); }

    /**
     * Apply this kit to a player: clear inventory, set armor, hotbar, effects.
     */
    public void apply(Player player) {
        // Clear everything
        player.getInventory().clear();
        player.getActivePotionEffects().forEach(e -> player.removePotionEffect(e.getType()));

        // Set armor
        if (armor != null) {
            ItemStack[] cloned = new ItemStack[armor.length];
            for (int i = 0; i < armor.length; i++) {
                cloned[i] = armor[i] != null ? armor[i].clone() : null;
            }
            player.getInventory().setArmorContents(cloned);

            // Apply cosmetic armor trims if the service is available
            com.ethernova.core.service.ArmorTrimService trimService =
                    com.ethernova.core.service.ServiceRegistry.get(com.ethernova.core.service.ArmorTrimService.class);
            if (trimService != null) {
                org.bukkit.inventory.ItemStack[] trimmed = trimService.applyTrims(
                        player.getUniqueId(), player.getInventory().getArmorContents());
                player.getInventory().setArmorContents(trimmed);
            }
        }

        // Set inventory items
        if (inventory != null) {
            for (int i = 0; i < inventory.length && i < 36; i++) {
                if (inventory[i] != null) {
                    player.getInventory().setItem(i, inventory[i].clone());
                }
            }
        }

        // Apply potion effects
        for (PotionEffect effect : effects) {
            player.addPotionEffect(effect);
        }

        // Full heal
        player.setHealth(player.getMaxHealth());
        player.setFoodLevel(20);
        player.setSaturation(20f);
        player.setFireTicks(0);
    }
}
