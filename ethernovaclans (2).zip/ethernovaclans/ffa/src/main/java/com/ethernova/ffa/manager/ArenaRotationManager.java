package com.ethernova.ffa.manager;

import com.ethernova.core.EthernovaCore;
import com.ethernova.ffa.EthernovaFFA;
import com.ethernova.ffa.model.FFAArena;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * Manages arena rotation: "Arena of the Day", voting system, and timed rotation.
 * <p>
 * Features:
 * <ul>
 *   <li>Daily featured arena with bonus XP/coins</li>
 *   <li>Player voting for next arena</li>
 *   <li>Automatic rotation on a configurable interval</li>
 *   <li>Arena weighting based on player count and votes</li>
 * </ul>
 */
public class ArenaRotationManager {

    private final EthernovaFFA plugin;
    private final EthernovaCore core;
    private final Logger logger;
    private final MiniMessage mini = MiniMessage.miniMessage();

    // Current featured arena
    private volatile String featuredArena;
    private volatile LocalDate featuredDate;

    // Voting
    private final Map<UUID, String> playerVotes = new ConcurrentHashMap<>();
    private volatile boolean votingOpen = false;

    // Rotation task
    private BukkitTask rotationTask;

    // Config
    private int rotationIntervalMinutes;
    private double bonusXpMultiplier;
    private double bonusCoinMultiplier;

    public ArenaRotationManager(EthernovaFFA plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
        this.logger = plugin.getLogger();
        loadConfig();
        selectDailyArena();
        startRotationTask();
    }

    private void loadConfig() {
        rotationIntervalMinutes = plugin.getConfig().getInt("arena-rotation.interval-minutes", 60);
        bonusXpMultiplier = plugin.getConfig().getDouble("arena-rotation.bonus-xp-multiplier", 1.5);
        bonusCoinMultiplier = plugin.getConfig().getDouble("arena-rotation.bonus-coin-multiplier", 1.5);
    }

    // ═══════════════════════════════════════
    //  DAILY ARENA
    // ═══════════════════════════════════════

    /**
     * Select the daily featured arena. Changes once per day.
     */
    private void selectDailyArena() {
        LocalDate today = LocalDate.now();
        if (featuredDate != null && featuredDate.equals(today) && featuredArena != null) {
            return; // Already selected for today
        }

        List<FFAArena> enabledArenas = plugin.getArenaManager().getAllArenas().stream()
                .filter(FFAArena::isEnabled)
                .filter(FFAArena::hasSpawnPoints)
                .toList();

        if (enabledArenas.isEmpty()) {
            featuredArena = null;
            featuredDate = today;
            return;
        }

        // Use date-based seed for deterministic daily selection
        Random rng = new Random(today.toEpochDay());
        FFAArena selected = enabledArenas.get(rng.nextInt(enabledArenas.size()));
        featuredArena = selected.getName();
        featuredDate = today;
        logger.info("Arena del día: " + featuredArena);
    }

    /**
     * Get the currently featured arena name.
     */
    public String getFeaturedArena() {
        selectDailyArena(); // Refresh if day changed
        return featuredArena;
    }

    /**
     * Check if an arena is the featured arena.
     */
    public boolean isFeatured(String arenaName) {
        selectDailyArena();
        return arenaName != null && arenaName.equalsIgnoreCase(featuredArena);
    }

    /**
     * Get the bonus XP multiplier for the featured arena.
     */
    public double getBonusXpMultiplier() { return bonusXpMultiplier; }

    /**
     * Get the bonus coin multiplier for the featured arena.
     */
    public double getBonusCoinMultiplier() { return bonusCoinMultiplier; }

    // ═══════════════════════════════════════
    //  VOTING
    // ═══════════════════════════════════════

    /**
     * Open voting for the next arena rotation.
     */
    public void openVoting() {
        playerVotes.clear();
        votingOpen = true;

        for (Player p : Bukkit.getOnlinePlayers()) {
            if (plugin.getFFAManager().isInFFA(p.getUniqueId())) {
                p.sendMessage(mini.deserialize(
                        "<gold>⚔ <yellow>¡Votación abierta! Usa <green>/ffa vote <arena></green> para votar la siguiente arena."));
            }
        }
    }

    /**
     * Cast a vote for an arena.
     */
    public boolean vote(Player player, String arenaName) {
        if (!votingOpen) {
            player.sendMessage(mini.deserialize("<red>No hay votación activa."));
            return false;
        }

        FFAArena arena = plugin.getArenaManager().getArena(arenaName);
        if (arena == null || !arena.isEnabled() || !arena.hasSpawnPoints()) {
            player.sendMessage(mini.deserialize("<red>Arena no válida."));
            return false;
        }

        playerVotes.put(player.getUniqueId(), arenaName.toLowerCase());
        player.sendMessage(mini.deserialize("<green>✔ Votaste por <yellow>" + arenaName + "</yellow>."));
        core.getSoundManager().play(player, "click");
        return true;
    }

    /**
     * Close voting and return the winning arena.
     */
    public String closeVoting() {
        votingOpen = false;

        if (playerVotes.isEmpty()) return null;

        // Count votes
        Map<String, Integer> voteCounts = new HashMap<>();
        for (String arena : playerVotes.values()) {
            voteCounts.merge(arena, 1, Integer::sum);
        }

        // Find winner
        String winner = voteCounts.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(null);

        playerVotes.clear();
        return winner;
    }

    /**
     * Get vote counts per arena.
     */
    public Map<String, Integer> getVoteCounts() {
        Map<String, Integer> counts = new HashMap<>();
        for (String arena : playerVotes.values()) {
            counts.merge(arena, 1, Integer::sum);
        }
        return counts;
    }

    public boolean isVotingOpen() { return votingOpen; }

    // ═══════════════════════════════════════
    //  ROTATION TASK
    // ═══════════════════════════════════════

    private void startRotationTask() {
        if (rotationIntervalMinutes <= 0) return;

        long intervalTicks = rotationIntervalMinutes * 60L * 20L;
        rotationTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            // Open voting 5 minutes before rotation
            if (!votingOpen) {
                openVoting();
                // Close and apply after 5 minutes
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    String winner = closeVoting();
                    if (winner != null) {
                        broadcastRotation(winner);
                    }
                }, 5 * 60 * 20L); // 5 minutes
            }
        }, intervalTicks, intervalTicks);
    }

    private void broadcastRotation(String arenaName) {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (plugin.getFFAManager().isInFFA(p.getUniqueId())) {
                p.sendMessage(mini.deserialize(
                        "<gold>⚔ <yellow>La arena votada es <green>" + arenaName + "</green>! Únete con <white>/ffa join " + arenaName));
            }
        }
    }

    /**
     * List available arenas with player counts and featured status.
     */
    public List<ArenaInfo> getArenaList() {
        List<ArenaInfo> infos = new ArrayList<>();
        for (FFAArena arena : plugin.getArenaManager().getAllArenas()) {
            if (!arena.isEnabled() || !arena.hasSpawnPoints()) continue;
            int players = plugin.getFFAManager().getPlayerCount(arena.getName());
            boolean featured = isFeatured(arena.getName());
            infos.add(new ArenaInfo(arena.getName(), players, arena.getMaxPlayers(), featured));
        }
        return infos;
    }

    public record ArenaInfo(String name, int players, int maxPlayers, boolean featured) {}

    /**
     * Remove a player's vote on quit.
     */
    public void cleanupPlayer(UUID uuid) {
        playerVotes.remove(uuid);
    }

    public void shutdown() {
        if (rotationTask != null) {
            rotationTask.cancel();
            rotationTask = null;
        }
        playerVotes.clear();
    }
}
