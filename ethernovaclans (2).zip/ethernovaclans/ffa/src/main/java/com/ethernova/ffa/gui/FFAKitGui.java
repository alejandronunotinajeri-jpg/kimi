package com.ethernova.ffa.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.CoreGui;
import com.ethernova.ffa.EthernovaFFA;
import com.ethernova.ffa.message.MessageManager;
import com.ethernova.ffa.model.FFAKit;
import com.ethernova.ffa.model.FFAPlayer;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Kit selection GUI. Shows all available kits with preview icons.
 */
public class FFAKitGui extends CoreGui {

    private final EthernovaFFA plugin;

    public FFAKitGui(EthernovaCore core, EthernovaFFA plugin, Player player) {
        super(core, player);
        this.plugin = plugin;
    }

    private MessageManager mm() { return plugin.getMessageManager(); }

    public void open() {
        openInventory(mm().get("gui.kit-selection.title"), 45);
    }

    @Override
    protected void populateItems() {
        // Header
        setItem(4, createItem(Material.DIAMOND_SWORD, mm().get("gui.kit-selection.title")));

        var kits = plugin.getKitManager().getAllKits();
        FFAPlayer ffaPlayer = plugin.getFFAManager().getFFAPlayer(player.getUniqueId());
        String currentKit = ffaPlayer != null ? ffaPlayer.getSelectedKit() : "";

        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};
        int index = 0;

        for (FFAKit kit : kits) {
            if (index >= slots.length) break;

            boolean selected = kit.getId().equalsIgnoreCase(currentKit);

            List<String> lore = new ArrayList<>();
            lore.add("");

            // Armor preview
            lore.add("<dark_gray>▎ " + mm().get("gui.kit-selection.armor"));
            if (kit.getArmor() != null) {
                for (int i = kit.getArmor().length - 1; i >= 0; i--) {
                    if (kit.getArmor()[i] != null) {
                        lore.add("<dark_gray>▎   <dark_gray>▸ <white>" + formatMaterial(kit.getArmor()[i].getType()));
                    }
                }
            }

            lore.add("");
            lore.add("<dark_gray>▎ " + mm().get("gui.kit-selection.weapons"));
            if (kit.getInventory() != null) {
                for (int i = 0; i < Math.min(4, kit.getInventory().length); i++) {
                    if (kit.getInventory()[i] != null) {
                        lore.add("<dark_gray>▎   <dark_gray>▸ <white>" + formatMaterial(kit.getInventory()[i].getType()));
                    }
                }
            }

            // Effects
            if (!kit.getEffects().isEmpty()) {
                lore.add("");
                lore.add("<dark_gray>▎ " + mm().get("gui.kit-selection.effects"));
                for (var effect : kit.getEffects()) {
                    String name = effect.getType().getKey().getKey().replace("_", " ");
                    lore.add("<dark_gray>▎   <dark_gray>▸ <aqua>" + name + " " + toRoman(effect.getAmplifier() + 1));
                }
            }

            lore.add("");
            if (selected) {
                lore.add("<dark_gray>▎ " + mm().get("gui.kit-selection.selected"));
            } else {
                lore.add("<dark_gray>▎ " + mm().get("gui.kit-selection.click-to-select"));
            }

            String displayName = selected
                    ? "<green><bold>" + kit.getName() + "</bold>"
                    : "<gold>" + kit.getName();

            setItem(slots[index], createItem(kit.getIcon(), displayName, lore));
            slotActions.put(slots[index], "KIT:" + kit.getId());
            index++;
        }

        // Back button
        setItem(36, createItem(Material.ARROW, "<red>← Volver", 
                List.of("<gray>Regresa al menú anterior")));
        slotActions.put(36, "BACK");

        // Close button
        setItem(40, createItem(Material.BARRIER, mm().get("gui.kit-selection.close")));
        slotActions.put(40, "CLOSE");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if ("BACK".equals(action)) {
            playSound("click");
            player.closeInventory();
            return true;
        }
        if (action.startsWith("KIT:")) {
            String kitId = action.substring(4);
            plugin.getFFAManager().changeKit(player, kitId);
            playSound("click");
            // Refresh GUI
            open();
            return true;
        }
        return false;
    }

    private String formatMaterial(Material material) {
        String name = material.name().toLowerCase().replace("_", " ");
        // Capitalize each word
        StringBuilder sb = new StringBuilder();
        for (String word : name.split(" ")) {
            if (!sb.isEmpty()) sb.append(" ");
            sb.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return sb.toString();
    }

    private String toRoman(int num) {
        return switch (num) {
            case 1 -> "I";
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            default -> String.valueOf(num);
        };
    }
}
