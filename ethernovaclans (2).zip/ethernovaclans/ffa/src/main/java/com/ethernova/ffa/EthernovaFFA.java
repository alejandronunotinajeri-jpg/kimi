package com.ethernova.ffa;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.service.ServiceRegistry;
import com.ethernova.ffa.api.FFAAPI;
import com.ethernova.ffa.api.FFAAPIImpl;
import com.ethernova.ffa.command.FFAAdminCommand;
import com.ethernova.ffa.command.FFACommand;
import com.ethernova.ffa.listener.FFAItemListener;
import com.ethernova.ffa.listener.FFAListener;
import com.ethernova.ffa.event.FFAEventsManager;
import com.ethernova.ffa.kit.CustomKitsManager;
import com.ethernova.ffa.manager.*;
import com.ethernova.ffa.message.MessageManager;
import com.ethernova.ffa.placeholder.FFAPlaceholders;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class EthernovaFFA extends JavaPlugin {

    private static volatile EthernovaFFA instance;
    private EthernovaCore core;

    private FFAArenaManager arenaManager;
    private FFAKitManager kitManager;
    private FFAStatsManager statsManager;
    private FFAManager ffaManager;
    private SpawnProtectionManager spawnProtectionManager;
    private FFAEventsManager eventsManager;
    private ArenaRotationManager arenaRotationManager;
    private CustomKitsManager customKitsManager;
    private MessageManager messageManager;

    @Override
    public void onEnable() {
        instance = this;
        long start = System.currentTimeMillis();

        getLogger().info("═══════════════════════════════════════════");
        getLogger().info("  EthernovaFFA v" + getDescription().getVersion());
        getLogger().info("═══════════════════════════════════════════");

        try {
            // ─── Core Dependency ───
            core = (EthernovaCore) Bukkit.getPluginManager().getPlugin("EthernovaCore");
            if (core == null) {
                getLogger().severe("EthernovaCore no encontrado! Deshabilitando...");
                Bukkit.getPluginManager().disablePlugin(this);
                return;
            }
            core.registerPlugin("EthernovaFFA");

            // ─── Config ───
            saveDefaultConfig();
            reloadConfig();

            // ─── Message Manager ───
            messageManager = new MessageManager(this);

            // ─── PlaceholderAPI ───
            if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
                new FFAPlaceholders(this).register();
                getLogger().info("PlaceholderAPI expansión registrada.");
            }

            // ─── Arena Manager ───
            arenaManager = new FFAArenaManager(this);
            arenaManager.loadArenas();

            // ─── Kit Manager ───
            kitManager = new FFAKitManager(this);
            kitManager.loadKits();

            // ─── Stats Manager & Database ───
            statsManager = new FFAStatsManager(this, core.getStorageManager());
            statsManager.runMigrations();

            // ─── Spawn Protection Manager ───
            spawnProtectionManager = new SpawnProtectionManager(this);
            spawnProtectionManager.start();

            // ─── FFA Manager (central lifecycle) ───
            ffaManager = new FFAManager(this, core);

            // ─── Arena Rotation ───
            arenaRotationManager = new ArenaRotationManager(this, core);

            // ─── Custom Kits ───
            customKitsManager = new CustomKitsManager(this, core.getStorageManager());

            // ─── Events Manager ───
            eventsManager = new FFAEventsManager(this, core);
            eventsManager.startScheduler();

            // ─── Commands ───
            var ffaCmd = getCommand("ffa");
            if (ffaCmd != null) {
                FFACommand executor = new FFACommand(this);
                ffaCmd.setExecutor(executor);
                ffaCmd.setTabCompleter(executor);
            }

            var adminCmd = getCommand("ffaadmin");
            if (adminCmd != null) {
                FFAAdminCommand executor = new FFAAdminCommand(this);
                adminCmd.setExecutor(executor);
                adminCmd.setTabCompleter(executor);
            }

            // ─── Listeners ───
            getServer().getPluginManager().registerEvents(new FFAListener(this, core), this);
            getServer().getPluginManager().registerEvents(new FFAItemListener(this), this);

            // ─── Public API ───
            ServiceRegistry.register(FFAAPI.class, new FFAAPIImpl(this));
            getLogger().info("✔ FFAAPI registrada en ServiceRegistry");

            long elapsed = System.currentTimeMillis() - start;
            getLogger().info("EthernovaFFA v" + getDescription().getVersion() + " habilitado en " + elapsed + "ms");

        } catch (Exception e) {
            getLogger().log(java.util.logging.Level.SEVERE, "Error habilitando EthernovaFFA", e);
            e.printStackTrace();
            Bukkit.getPluginManager().disablePlugin(this);
        }
    }

    @Override
    public void onDisable() {
        // Force leave all active players
        if (ffaManager != null) {
            ffaManager.stopRollbackTasks();
            ffaManager.forceLeaveAll();
        }

        // Stop spawn protection
        if (spawnProtectionManager != null) {
            spawnProtectionManager.stop();
        }

        // Cleanup events
        if (eventsManager != null) {
            eventsManager.cleanup();
        }

        // Cleanup arena rotation
        if (arenaRotationManager != null) {
            arenaRotationManager.shutdown();
        }

        // Save arenas
        if (arenaManager != null) {
            arenaManager.saveArenas();
        }

        // Unregister API
        ServiceRegistry.unregister(FFAAPI.class);

        // Unregister from core
        if (core != null) {
            core.unregisterPlugin("EthernovaFFA");
        }

        instance = null;
        getLogger().info("EthernovaFFA deshabilitado.");
    }

    // ─── Getters ───
    public static EthernovaFFA getInstance() { return instance; }
    public EthernovaCore getCore() { return core; }
    public FFAArenaManager getArenaManager() { return arenaManager; }
    public FFAKitManager getKitManager() { return kitManager; }
    public FFAStatsManager getStatsManager() { return statsManager; }
    public FFAManager getFFAManager() { return ffaManager; }
    public SpawnProtectionManager getSpawnProtectionManager() { return spawnProtectionManager; }
    public FFAEventsManager getEventsManager() { return eventsManager; }
    public ArenaRotationManager getArenaRotationManager() { return arenaRotationManager; }
    public CustomKitsManager getCustomKitsManager() { return customKitsManager; }
    public MessageManager getMessageManager() { return messageManager; }
}
