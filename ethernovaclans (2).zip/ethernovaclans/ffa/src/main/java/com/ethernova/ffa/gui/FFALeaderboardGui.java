package com.ethernova.ffa.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.PaginatedGui;
import com.ethernova.ffa.EthernovaFFA;
import com.ethernova.ffa.manager.FFAStatsManager;
import com.ethernova.ffa.message.MessageManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * FFA Leaderboard GUI. PaginatedGui based with player heads.
 */
public class FFALeaderboardGui extends PaginatedGui {

    private final EthernovaFFA plugin;
    private volatile List<PageItem> cachedItems;

    public FFALeaderboardGui(EthernovaCore core, EthernovaFFA plugin, Player player) {
        super(core, player);
        this.plugin = plugin;
    }

    private MessageManager mm() { return plugin.getMessageManager(); }

    public void open() {
        // Load leaderboard async first
        plugin.getStatsManager().getLeaderboard(100).thenAccept(entries -> {
            Bukkit.getScheduler().runTask(plugin, () -> {
                cachedItems = new ArrayList<>();
                int rank = 1;
                for (FFAStatsManager.LeaderboardEntry entry : entries) {
                    cachedItems.add(createLeaderboardItem(rank, entry));
                    rank++;
                }
                if (cachedItems.isEmpty()) {
                    cachedItems.add(new PageItem(
                            createItem(Material.BARRIER, mm().get("gui.leaderboard.no-stats")),
                            "NONE"
                    ));
                }
                openPaginated(getTitle(), 0);
            });
        });
    }

    @Override
    protected String getTitle() {
        return mm().get("gui.leaderboard.title");
    }

    @Override
    protected List<PageItem> getPageItems() {
        return cachedItems != null ? cachedItems : List.of();
    }

    @Override
    protected boolean onItemClick(String action, int slot, InventoryClickEvent event) {
        if (action.startsWith("PLAYER:")) {
            String uuidStr = action.substring(7);
            try {
                UUID targetUuid = UUID.fromString(uuidStr);
                String name = Bukkit.getOfflinePlayer(targetUuid).getName();
                if (name == null) name = mm().get("gui.leaderboard.unknown-name");
                new FFAStatsGui(core, plugin, player, targetUuid, name).open();
                playSound("click");
            } catch (IllegalArgumentException ignored) {}
            return true;
        }
        return false;
    }

    private PageItem createLeaderboardItem(int rank, FFAStatsManager.LeaderboardEntry entry) {
        // Create player head
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        if (meta != null) {
            meta.setOwningPlayer(Bukkit.getOfflinePlayer(entry.uuid()));
            
            // Rank color
            String rankColor = switch (rank) {
                case 1 -> "<gold><bold>";
                case 2 -> "<gray><bold>";
                case 3 -> "<#cd7f32><bold>";
                default -> "<white>";
            };

            meta.displayName(mini.deserialize(rankColor + "#" + rank + "</bold> " + entry.name()));

            double kdr = entry.getKDR();
            List<String> lore = List.of(
                    "",
                    mm().get("gui.leaderboard.kills", "{kills}", String.valueOf(entry.kills())),
                    mm().get("gui.leaderboard.deaths", "{deaths}", String.valueOf(entry.deaths())),
                    mm().get("gui.leaderboard.kdr", "{kdr}", String.format("%.2f", kdr)),
                    mm().get("gui.leaderboard.best-streak", "{streak}", String.valueOf(entry.bestStreak())),
                    "",
                    mm().get("gui.leaderboard.click-to-view")
            );
            meta.lore(lore.stream().map(l -> mini.deserialize(l)).toList());
            head.setItemMeta(meta);
        }

        return new PageItem(head, "PLAYER:" + entry.uuid().toString());
    }

    @Override
    protected void onBack() {
        player.closeInventory();
    }
}
