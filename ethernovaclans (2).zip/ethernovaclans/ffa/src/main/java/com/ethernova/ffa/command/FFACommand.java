package com.ethernova.ffa.command;

import com.ethernova.ffa.EthernovaFFA;
import com.ethernova.ffa.gui.FFAKitGui;
import com.ethernova.ffa.gui.FFALeaderboardGui;
import com.ethernova.ffa.gui.FFAStatsGui;
import com.ethernova.ffa.message.MessageManager;
import com.ethernova.ffa.model.FFAArena;
import com.ethernova.ffa.model.FFAPlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.stream.Collectors;

/**
 * /ffa command: join, leave, stats, kits, top, arenas
 */
public class FFACommand implements CommandExecutor, TabCompleter {

    private final EthernovaFFA plugin;

    public FFACommand(EthernovaFFA plugin) {
        this.plugin = plugin;
    }

    private MessageManager mm() { return plugin.getMessageManager(); }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            mm().sendMessage(sender, "general.only-players");
            return true;
        }

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        String sub = args[0].toLowerCase();
        return switch (sub) {
            case "join", "unirse" -> handleJoin(player, args);
            case "leave", "salir" -> handleLeave(player);
            case "stats", "estadisticas" -> handleStats(player);
            case "kits", "kit" -> handleKits(player);
            case "top", "leaderboard" -> handleTop(player);
            case "arenas", "arena" -> handleArenas(player);
            case "help", "ayuda" -> { sendHelp(player); yield true; }
            default -> {
                sendHelp(player);
                yield true;
            }
        };
    }

    private boolean handleJoin(Player player, String[] args) {
        if (!player.hasPermission("ethernova.ffa.play")) {
            mm().sendMessage(player, "general.no-permission");
            return true;
        }

        String arenaName;
        if (args.length >= 2) {
            arenaName = args[1].toLowerCase();
        } else {
            arenaName = plugin.getConfig().getString("general.default-arena", "principal");
        }

        plugin.getFFAManager().joinArena(player, arenaName);
        return true;
    }

    private boolean handleLeave(Player player) {
        plugin.getFFAManager().leaveArena(player);
        return true;
    }

    private boolean handleStats(Player player) {
        new FFAStatsGui(plugin.getCore(), plugin, player, player.getUniqueId(), player.getName()).open();
        return true;
    }

    private boolean handleKits(Player player) {
        FFAPlayer ffaPlayer = plugin.getFFAManager().getFFAPlayer(player.getUniqueId());
        if (ffaPlayer == null) {
            mm().sendMessage(player, "ffa.not-in-ffa");
            return true;
        }
        new FFAKitGui(plugin.getCore(), plugin, player).open();
        return true;
    }

    private boolean handleTop(Player player) {
        new FFALeaderboardGui(plugin.getCore(), plugin, player).open();
        return true;
    }

    private boolean handleArenas(Player player) {
        var arenas = plugin.getArenaManager().getAllArenas();
        if (arenas.isEmpty()) {
            mm().sendMessage(player, "arena.no-arenas");
            return true;
        }

        mm().sendMessage(player, "arena.list-header");
        for (FFAArena arena : arenas) {
            int players = plugin.getFFAManager().getPlayerCount(arena.getName());
            String status = arena.isEnabled() ? "<green>✔" : "<red>✘";
            mm().sendRaw(player, "arena.list-entry",
                    "{status}", status,
                    "{name}", arena.getName(),
                    "{players}", String.valueOf(players),
                    "{max}", String.valueOf(arena.getMaxPlayers()),
                    "{spawns}", String.valueOf(arena.getSpawnCount()));
        }
        return true;
    }

    private void sendHelp(Player player) {
        mm().sendRaw(player, "help.header");
        mm().sendRaw(player, "help.join");
        mm().sendRaw(player, "help.leave");
        mm().sendRaw(player, "help.kits");
        mm().sendRaw(player, "help.stats");
        mm().sendRaw(player, "help.top");
        mm().sendRaw(player, "help.arenas");
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                      @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player)) return List.of();

        if (args.length == 1) {
            List<String> subs = List.of("join", "leave", "stats", "kits", "top", "arenas", "help");
            return filterCompletions(subs, args[0]);
        }

        if (args.length == 2 && args[0].equalsIgnoreCase("join")) {
            return filterCompletions(plugin.getArenaManager().getArenaNames(), args[1]);
        }

        return List.of();
    }

    private List<String> filterCompletions(List<String> options, String input) {
        String lower = input.toLowerCase();
        return options.stream()
                .filter(s -> s.toLowerCase().startsWith(lower))
                .collect(Collectors.toList());
    }
}
