package com.ethernova.ffa.gui;

import com.ethernova.core.gui.CoreGui;
import com.ethernova.ffa.EthernovaFFA;
import com.ethernova.ffa.model.FFAKit;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;

import java.util.ArrayList;
import java.util.List;

/**
 * Admin GUI — lists all FFA kits with preview, delete & create controls.
 */
public class FFAKitListGui extends CoreGui {

    private final EthernovaFFA plugin;

    public FFAKitListGui(EthernovaFFA plugin, Player player) {
        super(plugin.getCore(), player);
        this.plugin = plugin;
    }

    public void open() {
        openInventory("<gradient:#FC466B:#3F5EFB>🛡 Kits FFA</gradient>", 54);
    }

    @Override
    protected void populateItems() {
        // Header
        setItem(4, createItem(Material.DIAMOND_CHESTPLATE,
                "<gold><bold>🛡 Gestión de Kits FFA",
                List.of("", "<gray>Administra todos los kits FFA", "")));

        var kits = plugin.getKitManager().getAllKits();
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};
        int idx = 0;

        for (FFAKit kit : kits) {
            if (idx >= slots.length) break;

            List<String> lore = new ArrayList<>();
            lore.add("");
            lore.add("<dark_gray>▎ <gray>ID: <white>" + kit.getId());

            // Armor preview
            StringBuilder armorStr = new StringBuilder();
            if (kit.getArmor() != null) {
                for (ItemStack armor : kit.getArmor()) {
                    if (armor != null && armor.getType() != Material.AIR) {
                        if (!armorStr.isEmpty()) armorStr.append(", ");
                        armorStr.append(formatMaterial(armor.getType()));
                    }
                }
            }
            if (!armorStr.isEmpty()) {
                lore.add("<dark_gray>▎ <gray>Armadura: <white>" + armorStr);
            }

            // Item preview (first 4 items)
            if (kit.getInventory() != null) {
                int itemCount = 0;
                StringBuilder itemStr = new StringBuilder();
                for (ItemStack item : kit.getInventory()) {
                    if (item != null && item.getType() != Material.AIR) {
                        itemCount++;
                        if (itemStr.length() < 80) {
                            if (!itemStr.isEmpty()) itemStr.append(", ");
                            itemStr.append(formatMaterial(item.getType()));
                        }
                    }
                }
                if (itemCount > 0) {
                    lore.add("<dark_gray>▎ <gray>Items: <white>" + itemStr);
                }
            }

            // Effects
            if (kit.getEffects() != null && !kit.getEffects().isEmpty()) {
                lore.add("<dark_gray>▎ <gray>Efectos: <white>" + kit.getEffects().size());
                for (PotionEffect eff : kit.getEffects()) {
                    lore.add("<dark_gray>   ▸ <aqua>" + formatEffect(eff.getType().getKey().getKey())
                            + " " + toRoman(eff.getAmplifier() + 1));
                }
            }

            lore.add("");
            lore.add("<dark_gray>▎ <yellow>Click → Equipar kit");
            lore.add("<dark_gray>▎ <red>Shift+Click → Eliminar");

            setItem(slots[idx], createItem(kit.getIcon() != null ? kit.getIcon() : Material.IRON_CHESTPLATE,
                    "<gold>" + kit.getName(), lore));
            slotActions.put(slots[idx], "KIT:" + kit.getId());
            idx++;
        }

        if (kits.isEmpty()) {
            setItem(22, createItem(Material.BARRIER, "<red>No hay kits",
                    List.of("", "<gray>Usa el botón de crear para añadir uno")));
        }

        // Create kit from inventory button
        setItem(48, createItem(Material.EMERALD_BLOCK,
                "<green><bold>+ Crear Kit",
                List.of("",
                        "<dark_gray>▎ <gray>Crea un nuevo kit con tu",
                        "<dark_gray>▎ <gray>inventario y armadura actual.",
                        "",
                        "<dark_gray>▎ <yellow>Click para crear")));
        slotActions.put(48, "CREATE");

        // Back
        setItem(45, createItem(Material.ARROW, "<gray>← Volver"));
        slotActions.put(45, "BACK");

        // Close
        setItem(49, createItem(Material.BARRIER, "<red>Cerrar"));
        slotActions.put(49, "CLOSE");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.equals("CREATE")) {
            int count = plugin.getKitManager().getAllKits().size() + 1;
            String id = "custom_" + count;
            while (plugin.getKitManager().kitExists(id)) {
                count++;
                id = "custom_" + count;
            }
            String displayName = "Kit Custom #" + count;
            boolean ok = plugin.getKitManager().createKitFromPlayer(id, displayName, player);
            if (ok) {
                player.sendMessage(mini.deserialize(
                        "<green>✔ Kit '<white>" + displayName + "<green>' creado desde tu inventario."));
                playSound("success");
            } else {
                player.sendMessage(mini.deserialize("<red>✘ Error creando el kit."));
                playSound("error");
            }
            refresh();
            return true;
        }
        if (action.equals("BACK")) {
            playSound("click");
            player.closeInventory();
            Bukkit.getScheduler().runTaskLater(plugin, () -> new FFAAdminGui(plugin, player).open(), 1L);
            return true;
        }
        if (action.startsWith("KIT:")) {
            String kitId = action.substring(4);
            if (event.isShiftClick()) {
                if (plugin.getKitManager().deleteKit(kitId)) {
                    player.sendMessage(mini.deserialize("<red>✘ Kit '" + kitId + "' eliminado."));
                } else {
                    player.sendMessage(mini.deserialize("<red>No se pudo eliminar ese kit (puede ser default)."));
                }
                playSound("click");
                refresh();
            } else {
                // Equip kit preview
                FFAKit kit = plugin.getKitManager().getKit(kitId);
                if (kit != null) {
                    kit.apply(player);
                    player.sendMessage(mini.deserialize("<green>✦ Kit '<white>" + kit.getName() + "<green>' equipado."));
                    playSound("click");
                    player.closeInventory();
                }
            }
            return true;
        }
        return false;
    }

    private void refresh() {
        player.closeInventory();
        Bukkit.getScheduler().runTaskLater(plugin, this::open, 1L);
    }

    private String formatMaterial(Material mat) {
        String name = mat.name().toLowerCase().replace("_", " ");
        return name.substring(0, 1).toUpperCase() + name.substring(1);
    }

    private String formatEffect(String key) {
        String name = key.replace("_", " ");
        return name.substring(0, 1).toUpperCase() + name.substring(1);
    }

    private String toRoman(int num) {
        return switch (num) {
            case 1 -> "I";
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            default -> String.valueOf(num);
        };
    }
}
