package com.ethernova.ffa.command;

import com.ethernova.ffa.EthernovaFFA;
import com.ethernova.ffa.gui.FFAAdminGui;
import com.ethernova.ffa.message.MessageManager;
import com.ethernova.ffa.model.FFAArena;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.stream.Collectors;

/**
 * /ffaadmin command: arena management, kit, reload
 */
public class FFAAdminCommand implements CommandExecutor, TabCompleter {

    private final EthernovaFFA plugin;

    public FFAAdminCommand(EthernovaFFA plugin) {
        this.plugin = plugin;
    }

    private MessageManager mm() { return plugin.getMessageManager(); }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("ethernova.ffa.admin")) {
            mm().sendMessage(sender, "general.no-permission");
            return true;
        }

        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        String sub = args[0].toLowerCase();
        return switch (sub) {
            case "arena" -> handleArena(sender, args);
            case "kit" -> handleKit(sender, args);
            case "reload" -> handleReload(sender);
            case "gui" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("Solo jugadores.");
                    yield true;
                }
                new FFAAdminGui(plugin, p).open();
                yield true;
            }
            default -> {
                sendHelp(sender);
                yield true;
            }
        };
    }

    // ═══════════════════════════════════════
    //  ARENA subcommands
    // ═══════════════════════════════════════

    private boolean handleArena(CommandSender sender, String[] args) {
        if (args.length < 2) {
            mm().sendMessage(sender, "arena.arena-usage");
            return true;
        }

        String action = args[1].toLowerCase();
        return switch (action) {
            case "create" -> arenaCreate(sender, args);
            case "addspawn" -> arenaAddSpawn(sender, args);
            case "delete" -> arenaDelete(sender, args);
            case "list" -> arenaList(sender);
            case "enable" -> arenaSetEnabled(sender, args, true);
            case "disable" -> arenaSetEnabled(sender, args, false);
            case "setmax" -> arenaSetMax(sender, args);
            case "setregion" -> arenaSetRegion(sender, args);
            default -> {
                mm().sendMessage(sender, "general.unknown-action", "{action}", action);
                yield true;
            }
        };
    }

    private boolean arenaCreate(CommandSender sender, String[] args) {
        if (args.length < 3) {
            mm().sendMessage(sender, "arena.create-usage");
            return true;
        }
        String name = args[2].toLowerCase();
        FFAArena arena = plugin.getArenaManager().createArena(name);
        if (arena == null) {
            mm().sendMessage(sender, "arena.exists");
            return true;
        }
        mm().sendMessage(sender, "arena.created", "{name}", name);
        return true;
    }

    private boolean arenaAddSpawn(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            mm().sendMessage(sender, "arena.addspawn-only-players");
            return true;
        }
        if (args.length < 3) {
            mm().sendMessage(sender, "arena.addspawn-usage");
            return true;
        }
        String name = args[2].toLowerCase();
        FFAArena arena = plugin.getArenaManager().getArena(name);
        if (arena == null) {
            mm().sendMessage(sender, "arena.not-found", "{name}", name);
            return true;
        }
        arena.addSpawnPoint(player.getLocation());
        plugin.getArenaManager().saveArenas();
        mm().sendMessage(sender, "arena.addspawn-success",
                "{count}", String.valueOf(arena.getSpawnCount()),
                "{name}", name);
        return true;
    }

    private boolean arenaDelete(CommandSender sender, String[] args) {
        if (args.length < 3) {
            mm().sendMessage(sender, "arena.delete-usage");
            return true;
        }
        String name = args[2].toLowerCase();
        if (plugin.getArenaManager().deleteArena(name)) {
            mm().sendMessage(sender, "arena.deleted", "{name}", name);
        } else {
            mm().sendMessage(sender, "arena.not-found", "{name}", name);
        }
        return true;
    }

    private boolean arenaList(CommandSender sender) {
        var arenas = plugin.getArenaManager().getAllArenas();
        if (arenas.isEmpty()) {
            mm().sendMessage(sender, "arena.no-arenas-admin");
            return true;
        }
        mm().sendMessage(sender, "arena.list-header");
        for (FFAArena arena : arenas) {
            int players = plugin.getFFAManager().getPlayerCount(arena.getName());
            String status = arena.isEnabled() ? "<green>✔" : "<red>✘";
            String kit = arena.getKitId() != null ? arena.getKitId() : "libre";
            mm().sendRaw(sender, "arena.list-entry-admin",
                    "{status}", status,
                    "{name}", arena.getName(),
                    "{players}", String.valueOf(players),
                    "{max}", String.valueOf(arena.getMaxPlayers()),
                    "{spawns}", String.valueOf(arena.getSpawnCount()),
                    "{kit}", kit);
        }
        return true;
    }

    private boolean arenaSetEnabled(CommandSender sender, String[] args, boolean enabled) {
        if (args.length < 3) {
            mm().sendMessage(sender, enabled ? "arena.enable-usage" : "arena.disable-usage");
            return true;
        }
        String name = args[2].toLowerCase();
        FFAArena arena = plugin.getArenaManager().getArena(name);
        if (arena == null) {
            mm().sendMessage(sender, "arena.not-found", "{name}", name);
            return true;
        }
        arena.setEnabled(enabled);
        plugin.getArenaManager().saveArenas();
        mm().sendMessage(sender, enabled ? "arena.enabled" : "arena.disabled", "{name}", name);
        return true;
    }

    private boolean arenaSetMax(CommandSender sender, String[] args) {
        if (args.length < 4) {
            mm().sendMessage(sender, "arena.setmax-usage");
            return true;
        }
        String name = args[2].toLowerCase();
        FFAArena arena = plugin.getArenaManager().getArena(name);
        if (arena == null) {
            mm().sendMessage(sender, "arena.not-found", "{name}", name);
            return true;
        }
        try {
            int max = Integer.parseInt(args[3]);
            arena.setMaxPlayers(max);
            plugin.getArenaManager().saveArenas();
            mm().sendMessage(sender, "arena.setmax-success", "{name}", name, "{max}", String.valueOf(max));
        } catch (NumberFormatException e) {
            mm().sendMessage(sender, "general.invalid-number", "{value}", args[3]);
        }
        return true;
    }

    private boolean arenaSetRegion(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Solo jugadores.");
            return true;
        }
        if (args.length < 4) {
            sender.sendMessage(MiniMessage.miniMessage().deserialize(
                    "<red>Uso: /ffaadmin arena setregion <arena> <1|2>"));
            return true;
        }
        String name = args[2].toLowerCase();
        String posArg = args[3];
        if (!"1".equals(posArg) && !"2".equals(posArg)) {
            sender.sendMessage(MiniMessage.miniMessage().deserialize(
                    "<red>Usa 1 o 2 para la esquina de la región."));
            return true;
        }
        FFAArena arena = plugin.getArenaManager().getArena(name);
        if (arena == null) {
            mm().sendMessage(sender, "arena.not-found", "{name}", name);
            return true;
        }
        if ("1".equals(posArg)) {
            arena.setRegionPos1(player.getLocation());
        } else {
            arena.setRegionPos2(player.getLocation());
        }
        plugin.getArenaManager().saveArenas();

        // If both region corners set and tracking is active, restart tracking with new region
        if (arena.hasRegion()) {
            plugin.getFFAManager().restartRollbackTracking(arena);
        }

        sender.sendMessage(MiniMessage.miniMessage().deserialize(
                "<green>Esquina " + posArg + " de la región establecida para arena <yellow>" + name + "</yellow>."
                + (arena.hasRegion() ? " <aqua>¡Región completa! Rollback periódico activo.</aqua>" : " <gray>Falta la otra esquina.</gray>")));
        return true;
    }

    // ═══════════════════════════════════════
    //  KIT subcommand
    // ═══════════════════════════════════════

    private boolean handleKit(CommandSender sender, String[] args) {
        if (args.length < 2) {
            mm().sendMessage(sender, "admin.kit-usage");
            return true;
        }
        String kitId = args[1].toLowerCase();
        if (!plugin.getKitManager().kitExists(kitId)) {
            mm().sendMessage(sender, "admin.kit-not-found", "{kit}", kitId);
            mm().sendMessage(sender, "admin.kit-available", "{kits}", String.join(", ", plugin.getKitManager().getKitIds()));
            return true;
        }
        plugin.getConfig().set("kits.default-kit", kitId);
        plugin.saveConfig();
        mm().sendMessage(sender, "admin.kit-set", "{kit}", kitId);
        return true;
    }

    // ═══════════════════════════════════════
    //  RELOAD
    // ═══════════════════════════════════════

    private boolean handleReload(CommandSender sender) {
        // Force-leave all players before reloading to prevent orphaned sessions
        plugin.getFFAManager().forceLeaveAll();
        plugin.reloadConfig();
        plugin.getMessageManager().load();
        plugin.getArenaManager().loadArenas();
        plugin.getKitManager().loadKits();
        mm().sendMessage(sender, "general.reload-success");
        return true;
    }

    // ═══════════════════════════════════════
    //  HELP
    // ═══════════════════════════════════════

    private void sendHelp(CommandSender sender) {
        mm().sendRaw(sender, "help-admin.header");
        mm().sendRaw(sender, "help-admin.arena-create");
        mm().sendRaw(sender, "help-admin.arena-addspawn");
        mm().sendRaw(sender, "help-admin.arena-delete");
        mm().sendRaw(sender, "help-admin.arena-list");
        mm().sendRaw(sender, "help-admin.arena-enable-disable");
        mm().sendRaw(sender, "help-admin.arena-setmax");
        mm().sendRaw(sender, "help-admin.kit");
        mm().sendRaw(sender, "help-admin.reload");
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                      @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("ethernova.ffa.admin")) return List.of();

        if (args.length == 1) {
            return filterCompletions(List.of("arena", "kit", "reload", "gui"), args[0]);
        }

        if (args.length == 2) {
            if (args[0].equalsIgnoreCase("arena")) {
                return filterCompletions(List.of("create", "addspawn", "delete", "list", "enable", "disable", "setmax", "setregion"), args[1]);
            }
            if (args[0].equalsIgnoreCase("kit")) {
                return filterCompletions(plugin.getKitManager().getKitIds(), args[1]);
            }
        }

        if (args.length == 3 && args[0].equalsIgnoreCase("arena")) {
            String action = args[1].toLowerCase();
            if (List.of("addspawn", "delete", "enable", "disable", "setmax", "setregion").contains(action)) {
                return filterCompletions(plugin.getArenaManager().getArenaNames(), args[2]);
            }
        }

        if (args.length == 4 && args[0].equalsIgnoreCase("arena") && "setregion".equalsIgnoreCase(args[1])) {
            return filterCompletions(List.of("1", "2"), args[3]);
        }

        return List.of();
    }

    private List<String> filterCompletions(List<String> options, String input) {
        String lower = input.toLowerCase();
        return options.stream()
                .filter(s -> s.toLowerCase().startsWith(lower))
                .collect(Collectors.toList());
    }
}
