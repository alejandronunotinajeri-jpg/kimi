package com.ethernova.ffa.model;

import org.bukkit.Location;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Represents an FFA arena definition loaded from config.
 */
public class FFAArena {

    private final String name;
    private final List<Location> spawnPoints;
    private int maxPlayers;
    private boolean enabled;
    private String kitId;
    /** Region corner 1 for periodic rollback (nullable — rollback disabled if null) */
    private Location regionPos1;
    /** Region corner 2 for periodic rollback (nullable) */
    private Location regionPos2;

    public FFAArena(String name) {
        this.name = name;
        this.spawnPoints = Collections.synchronizedList(new ArrayList<>());
        this.maxPlayers = 50;
        this.enabled = true;
        this.kitId = null;
    }

    public FFAArena(String name, List<Location> spawnPoints, int maxPlayers, boolean enabled, String kitId) {
        this.name = name;
        this.spawnPoints = Collections.synchronizedList(new ArrayList<>(spawnPoints));
        this.maxPlayers = maxPlayers;
        this.enabled = enabled;
        this.kitId = kitId;
    }

    public String getName() { return name; }

    public Location getSpawnPoint() {
        List<Location> snapshot = List.copyOf(spawnPoints);
        if (snapshot.isEmpty()) return null;
        return snapshot.get(ThreadLocalRandom.current().nextInt(snapshot.size()));
    }

    /**
     * Get a random spawn point different from the excluded location.
     * Falls back to any random spawn if only one exists.
     */
    public Location getSpawnPointExcluding(Location exclude) {
        List<Location> snapshot = List.copyOf(spawnPoints);
        if (snapshot.isEmpty()) return null;
        if (snapshot.size() == 1) return snapshot.getFirst();

        List<Location> candidates = new ArrayList<>();
        for (Location loc : snapshot) {
            if (exclude == null || !java.util.Objects.equals(loc.getWorld(), exclude.getWorld())
                    || loc.distanceSquared(exclude) > 25) { // >5 blocks away
                candidates.add(loc);
            }
        }
        if (candidates.isEmpty()) {
            // All spawns are near exclude, just pick random
            return snapshot.get(ThreadLocalRandom.current().nextInt(snapshot.size()));
        }
        return candidates.get(ThreadLocalRandom.current().nextInt(candidates.size()));
    }

    public List<Location> getSpawnPoints() { return Collections.unmodifiableList(spawnPoints); }

    public void addSpawnPoint(Location loc) { spawnPoints.add(loc.clone()); }

    public void removeSpawnPoint(int index) {
        if (index >= 0 && index < spawnPoints.size()) spawnPoints.remove(index);
    }

    public void clearSpawnPoints() { spawnPoints.clear(); }

    public int getMaxPlayers() { return maxPlayers; }
    public void setMaxPlayers(int maxPlayers) { this.maxPlayers = maxPlayers; }

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }

    public String getKitId() { return kitId; }
    public void setKitId(String kitId) { this.kitId = kitId; }

    public Location getRegionPos1() { return regionPos1; }
    public void setRegionPos1(Location loc) { this.regionPos1 = loc != null ? loc.clone() : null; }

    public Location getRegionPos2() { return regionPos2; }
    public void setRegionPos2(Location loc) { this.regionPos2 = loc != null ? loc.clone() : null; }

    public boolean hasRegion() { return regionPos1 != null && regionPos2 != null; }

    public boolean hasSpawnPoints() { return !spawnPoints.isEmpty(); }

    public int getSpawnCount() { return spawnPoints.size(); }
}
