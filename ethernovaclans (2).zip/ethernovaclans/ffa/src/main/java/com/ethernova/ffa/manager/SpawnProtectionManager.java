package com.ethernova.ffa.manager;

import com.ethernova.ffa.EthernovaFFA;
import com.ethernova.ffa.model.FFAPlayer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages spawn protection (invincibility frames) after respawn.
 * Players with active protection glow and cannot deal or receive damage.
 */
public class SpawnProtectionManager {

    private final EthernovaFFA plugin;
    private final Map<UUID, Long> protectedPlayers = new ConcurrentHashMap<>();
    private final Set<UUID> protectedSet = ConcurrentHashMap.newKeySet();
    /** Generation counter per player to prevent stale scheduled tasks from removing new protection. */
    private final Map<UUID, Integer> protectionGeneration = new ConcurrentHashMap<>();
    private BukkitTask cleanupTask;

    public SpawnProtectionManager(EthernovaFFA plugin) {
        this.plugin = plugin;
    }

    public void start() {
        // Check for expired protections every 10 ticks (0.5s)
        cleanupTask = Bukkit.getScheduler().runTaskTimer(plugin, this::cleanupExpired, 10L, 10L);
    }

    public void stop() {
        if (cleanupTask != null) cleanupTask.cancel();
        // Remove glowing from all protected players
        for (UUID uuid : protectedSet) {
            Player player = Bukkit.getPlayer(uuid);
            if (player != null && player.isOnline()) {
                player.removePotionEffect(PotionEffectType.GLOWING);
            }
        }
        protectedPlayers.clear();
        protectedSet.clear();
    }

    /**
     * Apply spawn protection to a player.
     */
    public void protect(Player player) {
        int seconds = plugin.getConfig().getInt("respawn.spawn-protection-seconds", 5);
        if (seconds <= 0) return;

        UUID uuid = player.getUniqueId();
        long expiryTime = System.currentTimeMillis() + (seconds * 1000L);
        protectedPlayers.put(uuid, expiryTime);
        protectedSet.add(uuid);

        // Increment generation so stale scheduled tasks from previous protect() calls are ignored
        int gen = protectionGeneration.merge(uuid, 1, Integer::sum);

        // Apply glowing effect
        if (plugin.getConfig().getBoolean("respawn.glowing-on-protection", true)) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, seconds * 20, 0, false, false, true));
        }

        // Message
        plugin.getMessageManager().sendMessage(player, "ffa.spawn-protection-start",
                "{seconds}", String.valueOf(seconds));

        // Schedule removal — only if generation still matches (no newer protect() call happened)
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (protectionGeneration.getOrDefault(uuid, -1) == gen) {
                removeProtection(uuid);
            }
        }, seconds * 20L);
    }

    /**
     * Remove spawn protection from a player.
     */
    public void removeProtection(UUID uuid) {
        if (protectedPlayers.remove(uuid) != null) {
            protectedSet.remove(uuid);
            Player player = Bukkit.getPlayer(uuid);
            if (player != null && player.isOnline()) {
                player.removePotionEffect(PotionEffectType.GLOWING);

                // Only send message if they are in FFA
                FFAPlayer ffaPlayer = plugin.getFFAManager().getFFAPlayer(uuid);
                if (ffaPlayer != null) {
                    plugin.getMessageManager().sendMessage(player, "ffa.spawn-protection-end");
                }
            }
        }
    }

    /**
     * Check if a player is currently protected.
     */
    public boolean isProtected(UUID uuid) {
        if (!protectedSet.contains(uuid)) return false;
        Long expiry = protectedPlayers.get(uuid);
        if (expiry == null) return false;
        if (System.currentTimeMillis() > expiry) {
            removeProtection(uuid);
            return false;
        }
        return true;
    }

    /**
     * Force remove protection (e.g., when player leaves FFA).
     */
    public void forceRemove(UUID uuid) {
        protectedPlayers.remove(uuid);
        protectedSet.remove(uuid);
        Player player = Bukkit.getPlayer(uuid);
        if (player != null) {
            player.removePotionEffect(PotionEffectType.GLOWING);
        }
    }

    private void cleanupExpired() {
        long now = System.currentTimeMillis();
        protectedPlayers.entrySet().removeIf(entry -> {
            if (now > entry.getValue()) {
                protectedSet.remove(entry.getKey());
                Player player = Bukkit.getPlayer(entry.getKey());
                if (player != null && player.isOnline()) {
                    player.removePotionEffect(PotionEffectType.GLOWING);
                }
                return true;
            }
            return false;
        });
    }
}
