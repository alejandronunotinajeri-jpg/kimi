package com.ethernova.ffa.gui;

import com.ethernova.core.gui.CoreGui;
import com.ethernova.ffa.EthernovaFFA;
import com.ethernova.ffa.model.FFAArena;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Admin GUI — lists all FFA arenas with TP / delete / create / toggle controls.
 */
public class FFAArenaListGui extends CoreGui {

    private final EthernovaFFA plugin;

    public FFAArenaListGui(EthernovaFFA plugin, Player player) {
        super(plugin.getCore(), player);
        this.plugin = plugin;
    }

    public void open() {
        openInventory("<gradient:#FC466B:#3F5EFB>⚔ Arenas FFA</gradient>", 54);
    }

    @Override
    protected void populateItems() {
        // Header
        setItem(4, createItem(Material.GRASS_BLOCK,
                "<gold><bold>⚔ Gestión de Arenas FFA",
                List.of("", "<gray>Administra todas las arenas FFA", "")));

        var arenas = plugin.getArenaManager().getAllArenas();
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};
        int idx = 0;

        for (FFAArena arena : arenas) {
            if (idx >= slots.length) break;

            List<String> lore = new ArrayList<>();
            lore.add("");
            lore.add("<dark_gray>▎ <gray>Estado: " + (arena.isEnabled() ? "<green>Habilitada" : "<red>Deshabilitada"));
            lore.add("<dark_gray>▎ <gray>Spawns: <white>" + arena.getSpawnPoints().size());
            lore.add("<dark_gray>▎ <gray>Max jugadores: <white>" + arena.getMaxPlayers());
            if (arena.getKitId() != null) {
                lore.add("<dark_gray>▎ <gray>Kit: <white>" + arena.getKitId());
            }
            lore.add("<dark_gray>▎ <gray>Jugadores: <white>" + plugin.getFFAManager().getPlayersInArena(arena.getName()).size());
            if (arena.getRegionPos1() != null && arena.getRegionPos2() != null) {
                lore.add("<dark_gray>▎ <green>✔ Región de rollback");
            }
            lore.add("");
            lore.add("<dark_gray>▎ <yellow>Click → Teleport");
            lore.add("<dark_gray>▎ <aqua>Click der. → Toggle enable");
            lore.add("<dark_gray>▎ <red>Shift+Click → Eliminar");

            Material icon = arena.isEnabled() ? Material.GRASS_BLOCK : Material.BEDROCK;
            setItem(slots[idx], createItem(icon, "<gold>" + arena.getName(), lore));
            slotActions.put(slots[idx], "ARENA:" + arena.getName());
            idx++;
        }

        if (arenas.isEmpty()) {
            setItem(22, createItem(Material.BARRIER, "<red>No hay arenas",
                    List.of("", "<gray>Usa el botón de crear o", "<gray>/ffaadmin arena create <nombre>")));
        }

        // Create arena button
        setItem(48, createItem(Material.EMERALD_BLOCK,
                "<green><bold>+ Crear Arena",
                List.of("",
                        "<dark_gray>▎ <gray>Crea una nueva arena FFA.",
                        "<dark_gray>▎ <gray>Agrega spawns con:",
                        "<dark_gray>▎ <white>/ffaadmin arena addspawn <nombre>",
                        "",
                        "<dark_gray>▎ <yellow>Click para crear")));
        slotActions.put(48, "CREATE");

        // Back
        setItem(45, createItem(Material.ARROW, "<gray>← Volver"));
        slotActions.put(45, "BACK");

        // Close
        setItem(49, createItem(Material.BARRIER, "<red>Cerrar"));
        slotActions.put(49, "CLOSE");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.equals("CREATE")) {
            int count = plugin.getArenaManager().getArenaNames().size() + 1;
            String name = "ffa_arena_" + count;
            while (plugin.getArenaManager().getArena(name) != null) {
                count++;
                name = "ffa_arena_" + count;
            }
            FFAArena arena = plugin.getArenaManager().createArena(name);
            if (arena != null) {
                // Add player's current location as first spawn
                arena.addSpawnPoint(player.getLocation());
                plugin.getArenaManager().saveArenas();
                player.sendMessage(mini.deserialize(
                        "<green>✔ Arena FFA '<white>" + name + "<green>' creada con 1 spawn. " +
                                "Agrega más con <white>/ffaadmin arena addspawn " + name));
                playSound("success");
            } else {
                player.sendMessage(mini.deserialize("<red>✘ Error creando la arena."));
                playSound("error");
            }
            refresh();
            return true;
        }
        if (action.equals("BACK")) {
            playSound("click");
            player.closeInventory();
            Bukkit.getScheduler().runTaskLater(plugin, () -> new FFAAdminGui(plugin, player).open(), 1L);
            return true;
        }
        if (action.startsWith("ARENA:")) {
            String arenaName = action.substring(6);
            FFAArena arena = plugin.getArenaManager().getArena(arenaName);
            if (arena == null) return true;

            if (event.isShiftClick()) {
                // Delete
                plugin.getArenaManager().deleteArena(arenaName);
                player.sendMessage(mini.deserialize("<red>✘ Arena '" + arenaName + "' eliminada."));
                playSound("click");
                refresh();
            } else if (event.isRightClick()) {
                // Toggle enable/disable
                arena.setEnabled(!arena.isEnabled());
                plugin.getArenaManager().saveArenas();
                String status = arena.isEnabled() ? "<green>habilitada" : "<red>deshabilitada";
                player.sendMessage(mini.deserialize("<yellow>Arena '" + arenaName + "' " + status + "."));
                playSound("click");
                refresh();
            } else {
                // TP to first spawn
                if (arena.hasSpawnPoints()) {
                    player.teleport(arena.getSpawnPoints().get(0));
                    player.sendMessage(mini.deserialize("<green>✦ Teleportado a arena: <white>" + arenaName));
                } else {
                    player.sendMessage(mini.deserialize("<red>Arena sin spawn points."));
                }
                playSound("click");
                player.closeInventory();
            }
            return true;
        }
        return false;
    }

    private void refresh() {
        player.closeInventory();
        Bukkit.getScheduler().runTaskLater(plugin, this::open, 1L);
    }
}
