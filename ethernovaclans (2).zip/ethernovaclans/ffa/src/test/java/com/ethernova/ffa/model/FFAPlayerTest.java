package com.ethernova.ffa.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class FFAPlayerTest {

    private UUID uuid;
    private FFAPlayer player;

    @BeforeEach
    void setUp() {
        uuid = UUID.randomUUID();
        player = new FFAPlayer(uuid, "arena1");
    }

    @Nested
    @DisplayName("Construction")
    class ConstructionTests {
        @Test void uuid() { assertEquals(uuid, player.getUuid()); }
        @Test void arenaName() { assertEquals("arena1", player.getArenaName()); }
        @Test void zeroKills() { assertEquals(0, player.getKills()); }
        @Test void zeroDeaths() { assertEquals(0, player.getDeaths()); }
        @Test void zeroStreak() { assertEquals(0, player.getKillStreak()); }
        @Test void alive() { assertTrue(player.isAlive()); }
        @Test void noKit() { assertNull(player.getSelectedKit()); }
        @Test void noDeathLoc() { assertNull(player.getLastDeathLoc()); }
    }

    @Nested
    @DisplayName("addKill()")
    class KillTests {
        @Test
        void incrementsKills() {
            player.addKill();
            assertEquals(1, player.getKills());
        }

        @Test
        void incrementsStreak() {
            player.addKill();
            player.addKill();
            assertEquals(2, player.getKillStreak());
        }

        @Test
        void multipleKills() {
            for (int i = 0; i < 10; i++) player.addKill();
            assertEquals(10, player.getKills());
            assertEquals(10, player.getKillStreak());
        }
    }

    @Nested
    @DisplayName("addDeath()")
    class DeathTests {
        @Test
        void incrementsDeaths() {
            player.addDeath();
            assertEquals(1, player.getDeaths());
        }

        @Test
        void resetsStreak() {
            player.addKill();
            player.addKill();
            player.addDeath();
            assertEquals(0, player.getKillStreak());
        }
    }

    @Nested
    @DisplayName("getKDR()")
    class KDRTests {
        @Test
        void zeroDeathsReturnsKills() {
            player.addKill();
            player.addKill();
            assertEquals(2.0, player.getKDR());
        }

        @Test
        void zeroKillsZeroDeaths() {
            assertEquals(0.0, player.getKDR());
        }

        @Test
        void normalRatio() {
            player.addKill();
            player.addKill();
            player.addKill();
            player.addDeath();
            assertEquals(3.0, player.getKDR(), 0.01);
        }

        @Test
        void oneToOneRatio() {
            player.addKill();
            player.addDeath();
            assertEquals(1.0, player.getKDR(), 0.01);
        }

        @Test
        void zeroKillsWithDeaths() {
            player.addDeath();
            player.addDeath();
            assertEquals(0.0, player.getKDR(), 0.01);
        }
    }

    @Nested
    @DisplayName("Session duration")
    class SessionTests {
        @Test
        void durationNonNegative() {
            assertTrue(player.getSessionDuration() >= 0);
        }
    }

    @Nested
    @DisplayName("Setters")
    class SetterTests {
        @Test
        void setAlive() {
            player.setAlive(false);
            assertFalse(player.isAlive());
        }

        @Test
        void setSelectedKit() {
            player.setSelectedKit("warrior");
            assertEquals("warrior", player.getSelectedKit());
        }

        @Test
        void resetKillStreak() {
            player.addKill();
            player.addKill();
            player.resetKillStreak();
            assertEquals(0, player.getKillStreak());
        }
    }
}
