# EthernovaClans Plugin — Technical Documentation (Part 1 of 2)

> Module: `src/` (main plugin)
> Package root: `com.ethernova.clans`
> API: Bukkit/Paper 1.21 · Java 21
> Generated: 2026-02-10

---

## Table of Contents

1. [plugin.yml — Commands & Permissions](#1-pluginyml)
2. [EthernovaClans.java — Main Class](#2-ethernovaclansjava)
3. [command/ — Command Executors](#3-command-package)
4. [clan/ — Clan Model Layer](#4-clan-package)
5. [config/ — Configuration](#5-config-package)
6. [alliance/ — Alliance Management](#6-alliance-package)
7. [invitation/ — Invitation Management](#7-invitation-package)
8. [chat/ — Chat Channels](#8-chat-package)
9. [war/ — War System](#9-war-package)
10. [power/ — Power System](#10-power-package)
11. [territory/ — Territory System](#11-territory-package)
12. [siege/ — Siege Mechanics](#12-siege-package)
13. [diplomacy/ — Diplomacy & Treaties](#13-diplomacy-package)
14. [level/ — Clan Leveling](#14-level-package)
15. [bank/ — Clan Bank](#15-bank-package)
16. [economy/ — Vault Economy](#16-economy-package)
17. [storage/ — Database & Schema](#17-storage-package)

---

## 1. plugin.yml

**Plugin Name:** `EthernovaClans`
**Main Class:** `com.ethernova.clans.EthernovaClans`
**API Version:** `1.21`

### Soft Dependencies
`EthernovaCore`, `EthernovaCombat`, `Vault`, `PlaceholderAPI`, `ProtocolLib`, `DecentHolograms`, `WorldGuard`, `WorldEdit`, `dynmap`, `BlueMap`

### Registered Commands

| Command | Aliases | Description | Permission |
|---------|---------|-------------|------------|
| `/clan` | `/c`, `/clans` | Main clan command | — |
| `/clanadmin` | `/cadmin`, `/ca` | Admin commands | `ethernova.clans.admin` |

### Permissions

| Permission | Default | Description |
|------------|---------|-------------|
| `ethernova.clans.use` | `true` | Basic clan usage |
| `ethernova.clans.admin` | `op` | Admin commands |
| `ethernova.clans.create` | `true` | Create a clan |
| `ethernova.clans.bypass` | `op` | Bypass restrictions |
| `ethernova.clans.spy` | `op` | Spy mode |
| `ethernova.spy.socialspy` | `op` | Toggle admin social spy |
| `ethernova.spy.infiltrate` | `op` | Infiltrate enemy clan chat |
| `ethernova.spy.intel` | `op` | Generate intel reports |
| `ethernova.clans.nation` | `true` | Access nation features |
| `ethernova.clans.outpost` | `true` | Access outpost features |

---

## 2. EthernovaClans.java — Main Class

**File:** `src/main/java/com/ethernova/clans/EthernovaClans.java` (558 lines)
**Extends:** `org.bukkit.plugin.java.JavaPlugin`

### Purpose
Singleton plugin entry point. Manages the complete lifecycle: initialization order of 30+ managers, ecosystem hooks to sister plugins (`EthernovaCore`, `EthernovaCombat`), command registration, listener registration, scheduled tasks, bStats metrics, and graceful shutdown with data persistence.

### Fields — Core Ecosystem Hooks

| Field | Type | Description |
|-------|------|-------------|
| `instance` | `static EthernovaClans` | Singleton instance |
| `coreHook` | `CoreHook` | EthernovaCore integration (optional) |
| `combatHook` | `CombatHook` | EthernovaCombat integration (optional) |

### Fields — Managers (30+)

| Field | Type |
|-------|------|
| `configManager` | `ConfigManager` |
| `messageManager` | `MessageManager` |
| `storageManager` | `StorageManager` |
| `clanManager` | `ClanManager` |
| `powerManager` | `PowerManager` |
| `territoryManager` | `TerritoryManager` |
| `warManager` | `WarManager` |
| `allianceManager` | `AllianceManager` |
| `economyManager` | `EconomyManager` |
| `invitationManager` | `InvitationManager` |
| `chatManager` | `ClanChatManager` |
| `guiManager` | `GUIManager` |
| `shieldManager` | `ShieldManager` |
| `hologramManager` | `HologramManager` |
| `upgradeManager` | `UpgradeManager` |
| `discordWebhook` | `DiscordWebhook` |
| `bankManager` | `ClanBankManager` |
| `levelManager` | `ClanLevelManager` |
| `auditLogger` | `AuditLogger` |
| `configurableGUI` | `ConfigurableGUI` |
| `territoryFlagManager` | `TerritoryFlagManager` |
| `teleportManager` | `TeleportManager` |
| `confirmationManager` | `ConfirmationManager` |
| `missionManager` | `MissionManager` |
| `achievementManager` | `AchievementManager` |
| `eventScheduler` | `EventScheduler` |
| `flyManager` | `FlyManager` |
| `nametagManager` | `NametagManager` |
| `auditManager` | `AuditManager` |
| `skillManager` | `ClanSkillManager` |
| `shopManager` | `ClanShopManager` |
| `siegeManager` | `SiegeManager` |
| `diplomacyManager` | `DiplomacyManager` |
| `salaryManager` | `SalaryManager` |
| `dynmapHook` | `DynmapHook` |
| `worldGuardHook` | `WorldGuardHook` |
| `nationManager` | `NationManager` |
| `outpostManager` | `OutpostManager` |
| `spyManager` | `SpyManager` |
| `territoryHUD` | `TerritoryHUD` |
| `webMapServer` | `WebMapServer` |
| `metrics` | `Metrics` |
| `blueprintManager` | `BlueprintManager` |
| `blueprintEffectListener` | `BlueprintEffectListener` |
| `chatFormatListener` | `ChatFormatListener` |
| `taxManager` | `TaxManager` |
| `chunkVisualizer` | `ChunkVisualizer` |
| `seasonManager` | `SeasonManager` |
| `bannerManager` | `BannerManager` |
| `enableTime` | `long` |

### Lifecycle — onEnable() (17 phases)

| Phase | Action |
|-------|--------|
| 0 | `setupEcosystemHooks()` — CoreHook, CombatHook |
| 1 | `ConfigManager.loadAllConfigs()` |
| 2 | `MessageManager` initialization |
| 3 | `StorageManager.initialize()` + `SchemaManager.migrate()` |
| 4 | `EconomyManager` (Vault hook) |
| 5 | Instantiate all 30+ managers |
| 6 | `ClanManager.loadAllClans()` from DB |
| 6.5 | Load god-tier data (skills, shop, diplomacy, salaries, nations, outposts, shields) |
| 6.75 | Load ultimate features (blueprints, banners) |
| 7 | `HologramManager` |
| 8 | `DiscordWebhook` |
| 9 | `registerCommands()` — `/clan`, `/clanadmin` |
| 10 | `registerListeners()` — 12 event listeners |
| 11 | `ClanPlaceholderExpansion` (PlaceholderAPI) |
| 12 | `registerTasks()` — auto-save, power regen, war tick, shield tick, outpost resources, territory tax, mission assignment |
| 13 | Register contexts with Core |
| 14 | `ClanAPI.init()` — public API |
| 15 | bStats Metrics |
| 16 | Update Checker |
| 17 | `WebMapServer.start()` |

### Lifecycle — onDisable()

1. Cancel all Bukkit tasks
2. Cancel all pending teleports
3. Disable fly for all airborne players
4. Shutdown all managers (nametag, event scheduler, siege, diplomacy, salary, dynmap, nation, outpost, spy, territory HUD, web map, blueprints, tax, chunk visualizer, seasons, banners)
5. Persist all data synchronously: clans, territories, bank balances, XP, alliances, shields
6. Close database connection pool
7. Remove all holograms
8. Unregister Core hook

### Scheduled Tasks

| Task | Interval | Description |
|------|----------|-------------|
| Auto-save | `auto-save-interval` min (default 5) | Snapshots main-thread data, async DB write |
| Power regen | `power.regen-interval` sec (default 60) | `PowerManager.regenAllOnlinePower()` |
| War tick | 1 second | `WarManager.tick()` — expiry check |
| Shield tick | 1 minute | `ShieldManager.tick()` |
| Outpost resources | 1 minute | `OutpostManager.tickResources()` |
| Territory tax | `bank.tax-interval-minutes` (default 60) | `ClanBankManager.applyTerritoryTax()` |
| Mission assignment | 30s delay, then every 6h | Assigns daily missions to all clans |

### Public Methods — Getters

All fields have a corresponding `public Type getXxx()` getter method. Notable:
- `static EthernovaClans getInstance()`
- `Plugin getPlaceholderHook()` — returns PlaceholderAPI plugin instance
- `EconomyManager getVaultHook()` — alias for `getEconomyManager()`
- `long getEnableTime()` — startup timestamp

### Registered Listeners

| Listener | Purpose |
|----------|---------|
| `PlayerDamageListener` | Territory PvP flags, war tagging, teleport cancel |
| `CombatListener` | Friendly fire, ally PvP, kill/death processing |
| `PlayerListener` | Member tracking, boosts, nametags, invite check, cleanup |
| `ChatListener` | Clan/ally chat routing, anvil input, @mentions |
| `AchievementListener` | Achievement event checks |
| `TerritoryListener` | Territory entry/exit, auto-claim |
| `GUIListener` | GUI click handling |
| `TerritoryFlyListener` | Fly enable/disable in territory |
| `ChatFormatListener` | Chat format with clan tags |
| `SkillEffectListener` | Skill passive effects |
| `OutpostListener` | Outpost block protection + watchtower |
| `BlueprintEffectListener` | Blueprint passive effects |

---

## 3. command/ — Command Package

### 3.1 ClanCommandExecutor

**File:** `src/main/java/com/ethernova/clans/command/ClanCommandExecutor.java` (1890 lines)
**Implements:** `CommandExecutor`, `TabCompleter`
**Handles:** `/clan` (aliases: `/c`, `/clans`)

#### Fields
| Field | Type | Description |
|-------|------|-------------|
| `plugin` | `EthernovaClans` | Plugin reference |
| `createCooldown` | `Map<UUID, Long>` | Per-player clan creation cooldown |
| `CREATE_COOLDOWN_MS` | `static long` | 60,000 ms (1 minute) |

#### Public Methods
| Method | Signature |
|--------|-----------|
| `onCommand` | `boolean onCommand(CommandSender, Command, String, String[])` |
| `onTabComplete` | `List<String> onTabComplete(CommandSender, Command, String, String[])` |

#### Subcommands — Complete List

| Subcommand | Aliases | Min Role | Permission | Args | Description |
|------------|---------|----------|------------|------|-------------|
| `create` | `crear` | — | `ethernova.clans.create` | `<name> [tag]` | Create clan; costs configurable amount; 1min cooldown |
| `disband` | `disolver` | LEADER | — | — | Disband with confirmation; blocked during war/combat |
| `invite` | `invitar` | OFFICER | — | `[player]` | Send invite or open invite GUI |
| `join` | `unir`, `accept`, `aceptar` | — | — | — | Accept pending invitation |
| `deny` | `rechazar` | — | — | — | Deny pending invitation |
| `leave` | `salir` | — | — | — | Leave clan with confirmation; leader blocked |
| `kick` | `expulsar` | OFFICER | — | `<player>` | Kick member (can't kick ≥ own rank) |
| `promote` | `ascender` | LEADER | — | `<player>` | Promote member (cap at CO_LEADER) |
| `demote` | `degradar` | LEADER | — | `<player>` | Demote member |
| `info` | — | — | — | `[clan]` | Show clan info panel |
| `list` | `lista` | — | — | `[page]` | Paginated clan list |
| `chat` | `c` | — | — | — | Toggle clan chat |
| `allychat` | `ac` | — | — | — | Toggle ally chat |
| `officerchat` | `oc` | OFFICER | — | — | Toggle officer chat |
| `ally` | `aliado` | CO_LEADER | — | `<request\|accept\|deny\|break> <clan>` | Alliance management |
| `enemy` | `enemigo` | CO_LEADER | — | `<clan>` | Set rival |
| `claim` | `reclamar` | OFFICER | — | — | Claim current chunk |
| `unclaim` | `abandonar` | OFFICER | — | — | Unclaim current chunk |
| `autoclaim` | — | OFFICER | — | — | Toggle auto-claim mode |
| `map` | `mapa` | — | — | — | ASCII chunk map (9×9 radius) |
| `home` | `base` | — | — | — | Teleport to clan home (warmup + cooldown) |
| `sethome` | `setbase` | OFFICER | — | — | Set clan home |
| `warp` | — | — | — | `<name>` | Teleport to warp |
| `setwarp` | — | OFFICER | — | `<name>` | Set warp |
| `delwarp` | — | OFFICER | — | `<name>` | Delete warp |
| `warps` | — | — | — | — | List warps |
| `war` | `guerra` | CO_LEADER | — | `<declare\|accept\|surrender> [clan]` | War management or open GUI |
| `upgrade` | `mejorar` | CO_LEADER | — | — | Open upgrades GUI |
| `top` | `ranking` | — | — | `[type] [page]` | Leaderboard (power/members/kills/territory/level/bank) |
| `transfer` | `transferir` | LEADER | — | `<player>` | Transfer leadership |
| `desc` | `descripcion` | OFFICER | — | `<text...>` | Set clan description |
| `ban` | `banear` | LEADER | — | `<player>` | Ban player from clan |
| `unban` | `desbanear` | LEADER | — | `<player>` | Unban player |
| `menu` | `gui` | — | — | — | Open main GUI |
| `help` | `ayuda` | — | — | — | Show help |
| `bank` | `banco` | — | — | `<deposit\|withdraw\|balance> [amount]` | Bank operations |
| `level` | `nivel` | — | — | — | Show clan level info |
| `confirm` | `confirmar` | — | — | — | Confirm pending action |
| `log` | `registro` | OFFICER | — | — | Show audit log (async DB query) |
| `flags` | `permisos` | LEADER | — | `[flag]` | View/toggle territory flags |
| `nation` | `nacion` | varies | — | `<sub> ...` | Nation management (see below) |
| `outpost` | `puesto` | varies | — | `<sub> ...` | Outpost management (see below) |
| `spy` | `espiar` | — | specific perms | `<sub> ...` | Spy operations (see below) |

#### Nation Subcommands (`/clan nation ...`)

| Sub | Min Role | Args | Description |
|-----|----------|------|-------------|
| `create` | LEADER | `<name> [tag]` | Create nation (economy cost) |
| `disband` | LEADER (nation leader) | — | Disband nation |
| `invite` | LEADER (nation officer+) | `<clan>` | Invite clan to nation |
| `accept`/`join` | LEADER | — | Accept nation invite |
| `deny` | LEADER | — | Deny nation invite |
| `kick` | — (checked by NationManager) | `<clan>` | Kick clan from nation |
| `leave` | LEADER | — | Leave nation |
| `promote` | — | `<clan>` | Promote clan in nation |
| `demote` | — | `<clan>` | Demote clan in nation |
| `info` | — | `[nation]` | Show nation info |
| `list` | — | — | List all nations |
| `chat` | — | — | Toggle nation chat |
| `desc` | LEADER (nation leader) | `<text>` | Set nation description |

#### Outpost Subcommands (`/clan outpost ...`)

| Sub | Min Role | Args | Description |
|-----|----------|------|-------------|
| `place` | OFFICER | `<type>` | Place outpost at location |
| `remove` | OFFICER | — | Remove outpost at location |
| `upgrade` | OFFICER | — | Upgrade outpost at location |
| `list` | — | — | List clan outposts |
| `info` | — | — | Show outpost info at location |

#### Spy Subcommands (`/clan spy ...`)

| Sub | Permission | Args | Description |
|-----|------------|------|-------------|
| `socialspy` | `ethernova.spy.socialspy` | — | Toggle social spy (see all clan chats) |
| `infiltrate` | `ethernova.spy.infiltrate` | `<clan>` | Infiltrate enemy clan chat |
| `stop` | — | — | Stop infiltration |
| `intel` | `ethernova.spy.intel` | `<clan>` | Generate intel report |

#### Private Utility Methods
- `requireClan(Player) → Clan` — returns clan or sends error
- `requireRole(Player, Clan, ClanRole) → boolean` — checks minimum role
- `getClanKills(Clan) → int` — delegates to `clan.getTotalKills()`
- `showHelp(Player)` — sends full help listing
- `helpLine(MessageManager, Player, String, String)` — formats a clickable help entry

### 3.2 ClanAdminCommand

**File:** `src/main/java/com/ethernova/clans/command/ClanAdminCommand.java`
**Implements:** `CommandExecutor`, `TabCompleter`
**Handles:** `/clanadmin` (aliases: `/cadmin`, `/ca`)
**Permission:** `ethernova.clans.admin`

#### Admin Subcommands

| Subcommand | Args | Description |
|------------|------|-------------|
| `gui`/`menu` | — | Open admin GUI (player only) |
| `reload` | — | Reload all configs |
| `disband` | `<clan>` | Force-disband clan |
| `setpower` | `<player> <amount>` | Set player power |
| `forcejoin` | `<player> <clan>` | Force player into clan |
| `forceleader` | `<clan> <player>` | Force transfer leadership |
| `spy` | — | Toggle spy mode |
| `blueprint`/`blueprints` | — | Open blueprints admin GUI |
| `season` | `reset` | Force end current season |
| `tax` | `collect` | Force tax collection |
| `setbank` | `<clan> <amount>` | Set clan bank balance |
| `setlevel` | `<clan> <xp>` | Set clan XP |
| `info` | — | Show system info (clan count, active wars, hooks) |
| `audit` | `<clan> [limit]` | View clan audit log |
| `unclaimall` | `<clan>` | Unclaim all territory |
| `resetlevel` | `<clan>` | Reset clan XP to 0 |
| `resetbank` | `<clan>` | Reset bank to 0 |
| `tpchunk` | `<world:x:z>` | Teleport to chunk center |

### 3.3 SubCommand Interface

**File:** `src/main/java/com/ethernova/clans/command/sub/SubCommand.java`

```java
public interface SubCommand {
    String getName();
    default List<String> getAliases();
    default String getPermission();
    String getDescription();
    String getUsage();
    default boolean requiresClan();
    void execute(EthernovaClans plugin, Player player, String[] args);
    default List<String> tabComplete(EthernovaClans plugin, Player player, String[] args);
}
```

### 3.4 SubCommandRegistry

**File:** `src/main/java/com/ethernova/clans/command/sub/SubCommandRegistry.java`

| Method | Signature | Description |
|--------|-----------|-------------|
| `register` | `void register(SubCommand)` | Register a subcommand handler |
| `find` | `SubCommand find(String name)` | Find by name or alias |
| `getAllNames` | `List<String> getAllNames()` | All names + aliases |
| `getCompletions` | `List<String> getCompletions(String partial)` | Filtered tab completions |
| `getAllCommands` | `Collection<SubCommand> getAllCommands()` | All registered commands |
| `execute` | `boolean execute(EthernovaClans, Player, String, String[])` | Execute by name |
| `tabComplete` | `List<String> tabComplete(EthernovaClans, Player, String, String[])` | Tab complete for specific subcommand |

---

## 4. clan/ — Clan Model Package

### 4.1 ClanRole (Enum)

**File:** `src/main/java/com/ethernova/clans/clan/ClanRole.java` (101 lines)

| Constant | ID | Priority | Icon | Display Name |
|----------|----|----------|------|-------------|
| `RECRUIT` | `recluta` | 0 | 👤 | Recluta |
| `MEMBER` | `miembro` | 1 | 👤 | Miembro |
| `OFFICER` | `oficial` | 2 | 🛡️ | Oficial |
| `CO_LEADER` | `co-líder` | 3 | 👑 | Co-Líder |
| `LEADER` | `líder` | 4 | 👑 | Líder |

| Method | Signature | Description |
|--------|-----------|-------------|
| `isAtLeast` | `boolean isAtLeast(ClanRole other)` | `this.priority >= other.priority` |
| `isHigherThan` | `boolean isHigherThan(ClanRole other)` | `this.priority > other.priority` |
| `fromId` | `static ClanRole fromId(String id)` | Lookup by ID string |
| `promote` | `ClanRole promote()` | Next role up (or self at max) |
| `demote` | `ClanRole demote()` | Next role down (or self at min) |
| `next` | `ClanRole next()` | Next ordinal or null |
| `previous` | `ClanRole previous()` | Previous ordinal or null |
| `getDisplayName` | `String getDisplayName()` | Localized display name |

### 4.2 ClanRank

**File:** `src/main/java/com/ethernova/clans/clan/ClanRank.java` (133 lines)

Custom per-clan rank with configurable permissions. Higher priority = more authority.

#### Fields
| Field | Type | Description |
|-------|------|-------------|
| `id` | `String` | Unique rank ID |
| `displayName` | `String` | Display name |
| `prefix` | `String` | Chat prefix (MiniMessage format) |
| `priority` | `int` | Authority level (leader = 1000) |
| `permissions` | `Set<String>` | Permission strings (e.g. "claim", "bank.withdraw") |
| `isDefault` | `boolean` | Whether assigned to new members |

#### Methods
| Method | Signature | Description |
|--------|-----------|-------------|
| `hasPermission` | `boolean hasPermission(String)` | Check if rank has permission |
| `addPermission` | `void addPermission(String)` | Add permission |
| `removePermission` | `void removePermission(String)` | Remove permission |
| `isAtLeast` | `boolean isAtLeast(ClanRank other)` | Priority comparison |
| `isHigherThan` | `boolean isHigherThan(ClanRank other)` | Strict priority comparison |
| `fromLegacyRole` | `static String fromLegacyRole(ClanRole)` | Convert legacy role → rank id |
| `createDefaults` | `static List<ClanRank> createDefaults()` | Generate 5 default ranks |

#### Default Ranks Created

| Rank ID | Display | Priority | Default? | Permissions |
|---------|---------|----------|----------|-------------|
| `recruit` | Recluta | 0 | ✔ | (none) |
| `member` | Miembro | 100 | — | `home`, `warp` |
| `officer` | Oficial | 200 | — | `home`, `warp`, `setwarp`, `claim`, `invite`, `kick`, `bank.deposit`, `bank.withdraw`, `chat.officer` |
| `co-leader` | Co-Líder | 500 | — | all officer + `delwarp`, `unclaim`, `promote`, `demote`, `bank.pay`, `sethome`, `ally.request`, `upgrade` |
| `leader` | Líder | 1000 | — | `*` (wildcard — all permissions) |

### 4.3 ClanMember

**File:** `src/main/java/com/ethernova/clans/clan/ClanMember.java` (162 lines)

Thread-safe member model with volatile fields and AtomicIntegers.

#### Fields
| Field | Type | Description |
|-------|------|-------------|
| `uuid` | `UUID` | Player UUID |
| `name` | `volatile String` | Player name |
| `role` | `volatile ClanRole` | Legacy role |
| `rankId` | `volatile String` | Custom rank ID (nullable) |
| `kills` | `AtomicInteger` | Personal kill count |
| `deaths` | `AtomicInteger` | Personal death count |
| `powerContributed` | `volatile int` | Power contributed |
| `joinDate` | `volatile Instant` | Join timestamp |
| `lastSeen` | `volatile Instant` | Last seen timestamp |
| `online` | `volatile boolean` | Online status |

#### Methods
| Method | Signature | Description |
|--------|-----------|-------------|
| `getKD` | `double getKD()` | Kill/death ratio (2 decimal) |
| `setRole` | `void setRole(ClanRole)` | Sets role AND updates rankId |
| `getRankId` | `String getRankId()` | Returns rankId or legacy equivalent |
| `addKill` | `void addKill()` | Atomic increment |
| `addDeath` | `void addDeath()` | Atomic increment |
| `addPowerContributed` | `void addPowerContributed(int)` | Synchronized add |
| `hasPermission(String)` | `boolean hasPermission(String)` | Legacy role-based check (≥OFFICER) |
| `hasPermission(Clan, String)` | `boolean hasPermission(Clan, String)` | Custom rank-based check |
| `promote` | `boolean promote()` | Promote role; returns false if already max |
| `demote` | `boolean demote()` | Demote role; returns false if already min |

### 4.4 ClanBank (inner model)

**File:** `src/main/java/com/ethernova/clans/clan/ClanBank.java` (231 lines)

Per-clan bank model with synchronized operations and transaction logging.

#### Inner Types
- `TransactionPersister` — `@FunctionalInterface` for DB persistence callback
- `TransactionType` — enum: `DEPOSIT`, `WITHDRAW`, `PAY_MEMBER`, `PAY_ALL`, `TAX`, `INTEREST`, `WAR_COST`, `WAR_REWARD`, `ALLIANCE_COST`, `ADMIN`
- `BankTransaction` — record: `(TransactionType type, double amount, UUID actor, UUID target, Instant timestamp)`

#### Fields
| Field | Type | Description |
|-------|------|-------------|
| `clanId` | `UUID` | Clan UUID |
| `balance` | `double` | Current balance |
| `taxRate` | `double` | Tax rate (0-50%) |
| `lastInterestTime` | `Instant` | Last interest application |
| `transactionLog` | `List<BankTransaction>` | In-memory log (max 1000 entries) |
| `persister` | `TransactionPersister` | DB callback |

#### Methods (all synchronized)
| Method | Signature | Description |
|--------|-----------|-------------|
| `deposit` | `double deposit(double amount, double maxBalance, UUID depositor)` | Deposit with cap; returns actual deposited |
| `withdraw` | `double withdraw(double amount, UUID withdrawer)` | Withdraw; returns actual amount |
| `pay` | `boolean pay(double amount, UUID payer, UUID recipient)` | Pay member from bank |
| `applyInterest` | `double applyInterest(double rate, double cap, double maxBalance)` | Apply interest; returns interest earned |
| `applyTax` | `double applyTax(double earnings, double maxBalance, UUID source)` | Tax on earnings; returns tax amount |
| `getTransactionLog` | `List<BankTransaction> getTransactionLog()` | Full log (immutable copy) |
| `getRecentTransactions` | `List<BankTransaction> getRecentTransactions(int count)` | Last N transactions |
| `clearLog` | `void clearLog()` | Clear transaction log |
| `addLoadedTransaction` | `void addLoadedTransaction(BankTransaction)` | Load from DB |

### 4.5 Clan

**File:** `src/main/java/com/ethernova/clans/clan/Clan.java` (600 lines)

Main clan model. Thread-safe with `ConcurrentHashMap`, `AtomicInteger`, and `volatile` fields.

#### Core Fields
| Field | Type | Description |
|-------|------|-------------|
| `id` | `String` | 8-char UUID-based ID |
| `name` | `String` | Clan name |
| `displayName` | `String` | Display name |
| `tag` | `String` | 2-5 char tag |
| `description` | `String` | Clan description |
| `leaderUuid` | `UUID` | Leader UUID |
| `leaderName` | `String` | Leader name |
| `home` | `volatile Location` | Home location |
| `createdAt` | `long` | Creation timestamp |
| `members` | `ConcurrentHashMap<UUID, ClanMember>` | Members map |
| `upgrades` | `ConcurrentHashMap<String, Integer>` | Upgrade levels |
| `banned` | `ConcurrentSet<UUID>` | Banned player UUIDs |
| `warps` | `ConcurrentHashMap<String, Location>` | Named warp points |
| `ranks` | `ConcurrentHashMap<String, ClanRank>` | Custom ranks |

#### Stats Fields
| Field | Type | Description |
|-------|------|-------------|
| `totalKills` | `AtomicInteger` | Total clan kills |
| `totalDeaths` | `AtomicInteger` | Total clan deaths |
| `warsWon` | `AtomicInteger` | Wars won |
| `warsLost` | `AtomicInteger` | Wars lost |
| `claimCount` | `volatile int` | Cached claim count |
| `level` | `volatile int` | Cached level |
| `power` | `volatile double` | Cached total power |
| `allies` | `ConcurrentSet<String>` | Allied clan IDs |
| `bank` | `ClanBank` | Bank model instance |

#### Cooldowns
| Field | Type | Description |
|-------|------|-------------|
| `cooldowns` | `ConcurrentHashMap<String, Long>` | Key → expiry timestamp |

#### Methods — Members
| Method | Signature |
|--------|-----------|
| `addMember` | `void addMember(ClanMember)` |
| `removeMember` | `void removeMember(UUID)` |
| `getMember` | `ClanMember getMember(UUID)` |
| `getMemberByName` | `ClanMember getMemberByName(String)` |
| `isMember` | `boolean isMember(UUID)` |
| `getMembers` | `Collection<ClanMember> getMembers()` |
| `getOnlineMembers` | `Collection<ClanMember> getOnlineMembers()` |
| `getMemberCount` | `int getMemberCount()` |
| `getOnlineMemberCount` | `int getOnlineMemberCount()` |
| `getMembersMap` | `Map<UUID, ClanMember> getMembersMap()` |

#### Methods — Upgrades
| Method | Signature |
|--------|-----------|
| `getUpgradeLevel` | `int getUpgradeLevel(String)` |
| `setUpgradeLevel` | `void setUpgradeLevel(String, int)` |
| `getUpgrades` | `Map<String, Integer> getUpgrades()` |

#### Methods — Warps
| Method | Signature |
|--------|-----------|
| `setWarp` | `void setWarp(String name, Location)` |
| `getWarp` | `Location getWarp(String name)` |
| `removeWarp` | `boolean removeWarp(String name)` |
| `getWarps` | `Map<String, Location> getWarps()` |

#### Methods — Ranks
| Method | Signature |
|--------|-----------|
| `getRank` | `ClanRank getRank(String rankId)` |
| `getRanks` | `Map<String, ClanRank> getRanks()` |
| `addRank` | `void addRank(ClanRank)` |
| `removeRank` | `boolean removeRank(String rankId)` |
| `getDefaultRank` | `ClanRank getDefaultRank()` |
| `getMemberRank` | `ClanRank getMemberRank(ClanMember)` |

#### Methods — Home
| Method | Signature |
|--------|-----------|
| `getHome`/`setHome` | `Location getHome()` / `void setHome(Location)` |
| `getHomeLocation` | `String getHomeLocation()` — serialize to `world:x:y:z:yaw:pitch` |
| `setHomeLocation` | `void setHomeLocation(String)` — deserialize from string |

#### Methods — Cooldowns
| Method | Signature |
|--------|-----------|
| `isOnCooldown` | `boolean isOnCooldown(String key)` |
| `getCooldownRemaining` | `long getCooldownRemaining(String key)` |
| `setCooldown` | `void setCooldown(String key, long durationMs)` |
| `purgeExpiredCooldowns` | `void purgeExpiredCooldowns()` |

#### Methods — Stats/KD
`getTotalKills()`, `setTotalKills(int)`, `addKill()`, `getTotalDeaths()`, `setTotalDeaths(int)`, `addDeath()`, `getWarsWon()`, `setWarsWon(int)`, `addWarWon()`, `getWarsLost()`, `setWarsLost(int)`, `addWarLost()`, `getKills()`, `getDeaths()`, `getKD()`

#### Methods — Allies/Rivals
`getAllies()`, `addAlly(String)`, `removeAlly(String)`, `isAlly(String)`, `getRivals()`, `addRival(String)`, `removeRival(String)`, `isRival(String)`

#### Methods — Settings
`isFriendlyFire()`/`setFriendlyFire(boolean)`, `getInviteMode()`/`setInviteMode(String)`, `isWarParticipation()`/`setWarParticipation(boolean)`, `isInviteOpen()`, `isClanChatEnabled()`/`setClanChatEnabled(boolean)`

#### Methods — Tag Color System
`getFormattedTag()` — returns MiniMessage formatted tag with color/gradient
`getTagColor()`/`setTagColor(String)`, `getGradientStart()`/`setGradientStart(String)`, `getGradientEnd()`/`setGradientEnd(String)`, `isUseGradient()`/`setUseGradient(boolean)`, `setTagColorStart(String)`, `setTagColorEnd(String)`, `setTagUseGradient(boolean)`, `isTagUseGradient()`

#### Methods — Other
`getCreatedDate()` — formatted as `dd/MM/yyyy HH:mm`
`getClaimedChunks()` — delegates to TerritoryManager
`getHeadquartersChunk()`/`setHeadquartersChunk(String)`
`getBanned()`/`addBanned(UUID)`/`removeBanned(UUID)`/`isBanned(UUID)`
`getIcon()`/`setIcon(String)`
`hasInvite(UUID)`/`getPendingInvites()`/`addInvite(UUID, Instant)`/`removeInvite(UUID)`
`getLeader()` → `Optional<ClanMember>`
`getIdString()` — alias for `getId()`

### 4.6 ClanManager

**File:** `src/main/java/com/ethernova/clans/clan/ClanManager.java` (390 lines)

Central clan CRUD, lookup indexes, territory delegation, member management.

#### Fields
| Field | Type | Description |
|-------|------|-------------|
| `clansById` | `ConcurrentHashMap<String, Clan>` | ID-indexed |
| `clansByName` | `ConcurrentHashMap<String, Clan>` | Name-indexed (lowercase) |
| `clansByTag` | `ConcurrentHashMap<String, Clan>` | Tag-indexed (lowercase) |
| `playerClanMap` | `ConcurrentHashMap<UUID, String>` | Player → clan ID |

#### Methods — CRUD
| Method | Signature | Description |
|--------|-----------|-------------|
| `createClan` | `Clan createClan(String name, String tag, Player leader)` | Create, register, save |
| `createClan` | `Clan createClan(Player leader, String name, String tag)` | Overload |
| `deleteClan` | `void deleteClan(Clan)` | Full cleanup across all managers + DB |
| `disbandClan` | `void disbandClan(Clan, Player initiator)` | Delete + notify members |
| `adminDisband` | `void adminDisband(Clan)` | Direct delete |

#### Methods — Save/Load
| Method | Signature |
|--------|-----------|
| `saveClan` | `void saveClan(Clan)` |
| `loadAllClans` | `void loadAllClans()` |

#### Methods — Lookup
| Method | Signature |
|--------|-----------|
| `getClan` / `getClanById` | `Clan getClan(String id)` |
| `getClanByName` | `Clan getClanByName(String)` |
| `getClanByTag` | `Clan getClanByTag(String)` |
| `getClanByPlayer` | `Clan getClanByPlayer(UUID)` / `Clan getClanByPlayer(Player)` |
| `getAllClans` | `Collection<Clan> getAllClans()` |
| `getOnlineMembers` | `List<Player> getOnlineMembers(Clan)` |
| `isInClan` | `boolean isInClan(UUID)` |
| `clanNameExists` | `boolean clanNameExists(String)` |

#### Methods — Territory (delegates to TerritoryManager)
| Method | Signature |
|--------|-----------|
| `buildChunkKey` | `static String buildChunkKey(String world, int x, int z)` |
| `getClaimOwner` | `Clan getClaimOwner(String chunkKey)` |
| `claimChunk` | `void claimChunk(String chunkKey, String clanId)` |
| `claimChunk` | `void claimChunk(Clan, Player, String chunkKey)` — with validation + WorldGuard check |
| `unclaimChunk` | `void unclaimChunk(String chunkKey)` |
| `unclaimChunk` | `void unclaimChunk(Clan, Player, String chunkKey)` — with validation |
| `unclaimAllChunks` | `void unclaimAllChunks(String clanId)` / `int unclaimAllChunks(Clan)` |
| `getClaimCount` | `int getClaimCount(String)` |
| `getClanClaims` | `Set<String> getClanClaims(String)` |

#### Methods — Member Management
| Method | Signature |
|--------|-----------|
| `updatePlayerClanMapping` | `void updatePlayerClanMapping(UUID, String clanId)` |
| `invitePlayer` | `void invitePlayer(Player inviter, Clan, Player target)` |
| `promoteMember` | `void promoteMember(Clan, ClanMember)` / `void promoteMember(Clan, UUID, Player)` |
| `demoteMember` | `void demoteMember(Clan, ClanMember)` / `void demoteMember(Clan, UUID, Player)` |
| `removeMember` | `void removeMember(Clan, ClanMember)` / `void removeMember(Clan, UUID, boolean)` |
| `addMember` | `void addMember(Clan, Player)` |
| `joinClan` | `void joinClan(Player, Clan)` |

#### Methods — Utility
| Method | Signature |
|--------|-----------|
| `changeTag` | `void changeTag(Clan, String)` / `void changeTag(Clan, String, Player)` |
| `changeName` | `void changeName(Clan, String, Player)` |
| `setHeadquarters` | `void setHeadquarters(Clan, Location)` / `void setHeadquarters(Clan, Player, String)` |
| `transferLeadership` | `void transferLeadership(Clan, UUID old, UUID new)` |
| `getTopClans` | `List<Clan> getTopClans(String metric, int limit)` — sorts by kills/power/level/members |
| `hasPermission` | `boolean hasPermission(Player, Clan, String)` / `boolean hasPermission(Clan, UUID, String)` |
| `updateNameIndex` | `void updateNameIndex(String old, String new, String clanId)` |
| `updateTagIndex` | `void updateTagIndex(String old, String new, String clanId)` |

---

## 5. config/ — Configuration

### ConfigManager

**File:** `src/main/java/com/ethernova/clans/config/ConfigManager.java`

#### Methods
| Method | Signature | Description |
|--------|-----------|-------------|
| `loadAllConfigs` | `void loadAllConfigs()` | Save defaults + reload config.yml |
| `getConfig` | `FileConfiguration getConfig()` | Get Bukkit FileConfiguration |
| `set` | `void set(String path, Object value)` | Set config value |
| `getDouble` | `double getDouble(String, double)` | Config value with default |
| `getInt` | `int getInt(String, int)` | Config value with default |
| `getString` | `String getString(String, String)` | Config value with default |
| `getBoolean` | `boolean getBoolean(String, boolean)` | Config value with default |
| `getMessage` | `Component getMessage(String, String...)` | Get formatted Component (delegates to MessageManager) |
| `getRawMessage` | `String getRawMessage(String, String...)` | Get raw MiniMessage string |
| `getGuiConfig` | `ConfigurationSection getGuiConfig(String)` | Get GUI config section |
| `parseTimeToMillis` | `long parseTimeToMillis(String)` | Parse "5m", "1h30m", "2d" → ms |

---

## 6. alliance/ — Alliance Management

### AllianceManager

**File:** `src/main/java/com/ethernova/clans/alliance/AllianceManager.java`

#### Fields
| Field | Type | Description |
|-------|------|-------------|
| `alliances` | `ConcurrentHashMap<String, Set<String>>` | Clan ID → Set of ally clan IDs |
| `pendingRequests` | `ConcurrentHashMap<String, String>` | Requesting clan ID → target clan ID |

#### Methods — Alliance Operations
| Method | Signature | Description |
|--------|-----------|-------------|
| `areAllied` | `boolean areAllied(Clan a, Clan b)` | Check alliance exists |
| `createAlliance` | `void createAlliance(Clan a, Clan b)` | Create bidirectional alliance; syncs Clan.allies |
| `removeAlliance` | `void removeAlliance(Clan a, Clan b)` | Remove bidirectional alliance |
| `getAllies` | `List<Clan> getAllies(Clan)` | Get all allied clans as Clan objects |
| `getAllyCount` | `int getAllyCount(Clan)` | Count of allies |

#### Methods — Requests
| Method | Signature |
|--------|-----------|
| `sendAllianceRequest` | `void sendAllianceRequest(String from, String to)` |
| `hasPendingRequest` | `boolean hasPendingRequest(String from, String to)` |
| `removePendingRequest` | `void removePendingRequest(String from)` |
| `sendAllyRequest` | `void sendAllyRequest(Clan from, Clan to)` — validates self-ally, existing alliance, max allies |
| `acceptAllyRequest` | `void acceptAllyRequest(Clan from, Clan to)` — creates alliance + Discord notification |
| `denyAllyRequest` | `void denyAllyRequest(Clan from, Clan to)` |
| `breakAlliance` | `void breakAlliance(Clan a, Clan b)` — removes + Discord notification |
| `setRival` | `void setRival(Clan, Clan target)` — one-directional rival |

#### Methods — Persistence
| Method | Signature |
|--------|-----------|
| `loadAlliance` | `void loadAlliance(String clanIdA, String clanIdB)` |
| `getAlliedIds` | `Set<String> getAlliedIds(String clanId)` |
| `removeAllAlliances` | `void removeAllAlliances(String clanId)` |

---

## 7. invitation/ — Invitation Management

### InvitationManager

**File:** `src/main/java/com/ethernova/clans/invitation/InvitationManager.java`

#### Fields
| Field | Type | Description |
|-------|------|-------------|
| `pending` | `ConcurrentHashMap<UUID, InviteEntry>` | Player UUID → InviteEntry |

#### Inner Types
- `InviteEntry` — record: `(String clanId, long expiry)`

#### Methods
| Method | Signature | Description |
|--------|-----------|-------------|
| `invite` | `void invite(UUID playerUuid, String clanId)` | Create invitation with configurable expiry |
| `getInvitedClanId` | `String getInvitedClanId(UUID)` | Get pending invite clan ID (null if expired/none) |
| `removeInvitation` | `void removeInvitation(UUID)` | Remove invitation |

Expired invitations are cleaned up via a Bukkit timer every 60 seconds.

---

## 8. chat/ — Chat Package

### 8.1 ClanChatManager

**File:** `src/main/java/com/ethernova/clans/chat/ClanChatManager.java`

Primary chat manager used by `EthernovaClans.chatManager`.

#### Fields
| Field | Type | Description |
|-------|------|-------------|
| `clanChat` | `ConcurrentSet<UUID>` | Players in clan chat mode |
| `allyChat` | `ConcurrentSet<UUID>` | Players in ally chat mode |
| `officerChat` | `ConcurrentSet<UUID>` | Players in officer chat mode |
| `nationChat` | `ConcurrentSet<UUID>` | Players in nation chat mode |

#### Methods — Toggles (mutually exclusive)
| Method | Signature |
|--------|-----------|
| `toggleClanChat` | `void toggleClanChat(UUID)` |
| `toggleAllyChat` | `void toggleAllyChat(UUID)` |
| `toggleOfficerChat` | `void toggleOfficerChat(UUID)` |
| `toggleNationChat` | `void toggleNationChat(UUID)` |
| `isInClanChat` | `boolean isInClanChat(UUID)` |
| `isInAllyChat` | `boolean isInAllyChat(UUID)` |
| `isInOfficerChat` | `boolean isInOfficerChat(UUID)` |
| `isInNationChat` | `boolean isInNationChat(UUID)` |
| `exitAllChats` | `void exitAllChats(UUID)` |

#### Methods — Messaging
| Method | Signature | Description |
|--------|-----------|-------------|
| `sendClanMessage` | `void sendClanMessage(Player, Clan, String)` | Broadcast to clan; escapes MiniMessage tags; forwards to SpyManager + infiltrators |
| `sendAllyMessage` | `void sendAllyMessage(Player, Clan, String)` | Broadcast to clan + all allies; forwards to SpyManager |
| `sendOfficerMessage` | `void sendOfficerMessage(Player, Clan, String)` | Broadcast to officers+ only; forwards to SpyManager |

### 8.2 ChatManager (legacy)

**File:** `src/main/java/com/ethernova/clans/chat/ChatManager.java` (204 lines)

Alternate chat manager with configurable formats, role colors, and alliance chat.

#### Methods
| Method | Signature |
|--------|-----------|
| `toggleClanChat` | `void toggleClanChat(Player)` |
| `toggleAllianceChat` | `void toggleAllianceChat(Player)` |
| `isInClanChat` | `boolean isInClanChat(Player)` |
| `isInAllianceChat` | `boolean isInAllianceChat(Player)` |
| `removeFromClanChat` | `void removeFromClanChat(Player)` |
| `sendClanMessage` | `void sendClanMessage(Player, Clan, String)` — uses configurable format string, role colors, spy forwarding |
| `sendAllianceMessage` | `void sendAllianceMessage(Player, Clan, String)` — sends to all allied clans |

---

## 9. war/ — War System

### 9.1 War

**File:** `src/main/java/com/ethernova/clans/war/War.java`

#### Fields
| Field | Type | Description |
|-------|------|-------------|
| `id` | `String` | War ID (`attackerId_vs_defenderId`) |
| `attackerId` | `String` | Attacker clan ID |
| `defenderId` | `String` | Defender clan ID |
| `startTime` | `long` | Start timestamp |
| `durationMinutes` | `int` | Duration in minutes |
| `kills` | `ConcurrentHashMap<String, Integer>` | Clan ID → kill count |

#### Methods
| Method | Signature | Description |
|--------|-----------|-------------|
| `tick` | `void tick()` | Time-based tick (stub) |
| `isExpired` | `boolean isExpired()` | Check if duration exceeded |
| `involves` | `boolean involves(String clanId)` | Check if clan is in this war |
| `addKill` | `void addKill(String clanId)` | Increment kill counter |
| `getKills` | `int getKills(String clanId)` | Get kills for clan |
| `getLeadingClanId` | `String getLeadingClanId()` | Clan with more kills (null if tied) |
| `getRemainingSeconds` | `int getRemainingSeconds()` | Time remaining |
| `getAttackerKills` | `int getAttackerKills()` | Attacker's kill count |
| `getDefenderKills` | `int getDefenderKills()` | Defender's kill count |
| `getType` | `WarType getType()` | Always `DEATHMATCH` |

### 9.2 WarManager

**File:** `src/main/java/com/ethernova/clans/war/WarManager.java`

#### Inner Types
- `WarType` — enum: `DEATHMATCH`, `CONQUEST`, `RAID`

#### Fields
| Field | Type | Description |
|-------|------|-------------|
| `activeWars` | `ConcurrentHashMap<String, War>` | War ID → War |

#### Methods
| Method | Signature | Description |
|--------|-----------|-------------|
| `declareWar` | `boolean declareWar(Clan attacker, Clan defender)` | Validates (not self, not allied, not shielded, min members), creates war, adds "war" context to Core, broadcasts, Discord |
| `endWar` | `void endWar(String warId, String winnerId)` | Removes war, applies results, broadcasts |
| `handleKill` | `void handleKill(UUID killer, UUID victim, String context)` | Records war kill, applies power loss, checks kill target for auto-end |
| `tick` | `void tick()` | Called every second; expires wars |
| `isAtWar` | `boolean isAtWar(Clan a, Clan b)` / `boolean isAtWar(Clan)` | Check war status |
| `getWar` | `War getWar(Clan)` | Get active war for clan |
| `getActiveWarCount` | `int getActiveWarCount()` | Count of active wars |
| `getActiveWars` | `Collection<War> getActiveWars()` / `List<War> getActiveWars(Clan)` | All or filtered wars |
| `requestWar` | `void requestWar(Clan, Clan, WarType)` | Delegates to `declareWar` |
| `acceptWar` | `void acceptWar(Clan)` | Stub for future pending-war flow |
| `surrender` | `void surrender(Clan)` | End war, enemy wins |
| `forceEndAllWars` | `void forceEndAllWars(Clan)` | Admin force-end |

#### War Results (`applyWarResults`)
- Winner: `+war.winner-power-gain` power per member (default 100)
- Loser: `-war.loser-power-loss` power per member (default 200)
- Winner: `addWarWon()`, Loser: `addWarLost()`
- Loser gets protection shield for `war.loser-shield-hours` (default 24h)
- Winner gets XP via `levelManager.onWarWin()`
- War loot: transfer `war.loot-percent`% of loser's bank to winner (default 10%)
- Both clans get war context removed from Core

---

## 10. power/ — Power System

### PowerManager

**File:** `src/main/java/com/ethernova/clans/power/PowerManager.java`

#### Config Values (loaded from `power.*`)
| Config Key | Default | Field |
|------------|---------|-------|
| `power.max-power` | 100.0 | `maxPower` |
| `power.min-power` | -50.0 | `minPower` |
| `power.start-power` | 50.0 | `startPower` |
| `power.regen-amount` | 1.0 | `regenAmount` |
| `power.kill-gain` | 5.0 | `killGain` |
| `power.death-loss` | 10.0 | `deathLoss` |

#### Fields
| Field | Type | Description |
|-------|------|-------------|
| `playerPower` | `ConcurrentHashMap<UUID, Double>` | Player UUID → power |

#### Methods
| Method | Signature | Description |
|--------|-----------|-------------|
| `getPower` | `double getPower(UUID)` | Get player power (defaults to `startPower`) |
| `setPower` | `void setPower(UUID, double)` | Clamped to [minPower, maxPower] |
| `addPower` | `void addPower(UUID, double)` | Atomic add, clamped |
| `removePower` | `void removePower(UUID, double)` | Atomic subtract, clamped |
| `onKill` | `void onKill(UUID)` | +killGain power, sync clan |
| `onDeath` | `void onDeath(UUID)` | -deathLoss power, sync clan |
| `getClanPower` | `double getClanPower(Clan)` | Sum of all member power |
| `getMaxClanPower` | `double getMaxClanPower(Clan)` | members × maxPower × nation multiplier |
| `getMaxClaims` | `int getMaxClaims(Clan)` | `power / powerPerClaim + levelBonus + skillBonus + nationBonus` |
| `regenAllOnlinePower` | `void regenAllOnlinePower()` | Regen power for all online players |
| `getMaxPower` | `double getMaxPower()` | Return maxPower config value |
| `removePlayer` | `void removePlayer(UUID)` | Remove from map (memory cleanup) |
| `addPower(Clan, double, String)` | `void addPower(Clan, double, String)` | Distribute evenly across members |
| `removePower(Clan, double, String)` | `void removePower(Clan, double, String)` | Distribute evenly across members |
| `setPower(Clan, int)` | `void setPower(Clan, int)` | Set total, distribute evenly |
| `syncClanPower` | `void syncClanPower(Clan)` | Update `Clan.power` cached field |
| `syncAllClanPower` | `void syncAllClanPower()` | Sync all clans |

---

## 11. territory/ — Territory System

### 11.1 TerritoryManager

**File:** `src/main/java/com/ethernova/clans/territory/TerritoryManager.java`

#### Fields
| Field | Type | Description |
|-------|------|-------------|
| `claims` | `ConcurrentHashMap<String, String>` | chunk ID (`world:x:z`) → clan ID |
| `claimCountCache` | `ConcurrentHashMap<String, Integer>` | clan ID → claim count |
| `autoClaimers` | `ConcurrentSet<UUID>` | Players with auto-claim on |

#### Methods
| Method | Signature | Description |
|--------|-----------|-------------|
| `claim` | `void claim(String chunkId, String clanId)` | Claim chunk, update cache |
| `unclaim` | `void unclaim(String chunkId)` | Unclaim chunk, update cache |
| `unclaimAll` | `void unclaimAll(String clanId)` | Remove all claims for clan |
| `unclaimRandom` | `void unclaimRandom(String clanId, int count)` | Unclaim N random chunks (for tax delinquency) |
| `getOwner` | `String getOwner(String chunkId)` | Get clan ID or null |
| `isTerritory` | `boolean isTerritory(String chunkId, String clanId)` | Check ownership |
| `getClaimCount` | `int getClaimCount(String clanId)` | Cached claim count |
| `getAllClaims` | `Map<String, String> getAllClaims()` | Immutable copy |
| `getClanClaims` | `Set<String> getClanClaims(String clanId)` | All chunk keys for clan |
| `loadClaim` | `void loadClaim(String chunkId, String clanId)` | Load from DB |
| `toggleAutoClaim` | `boolean toggleAutoClaim(UUID)` | Toggle; returns new state |
| `isAutoClaiming` | `boolean isAutoClaiming(UUID)` | Check auto-claim status |
| `stopAutoClaim` | `void stopAutoClaim(UUID)` | Disable auto-claim |

### 11.2 TerritoryFlag (Enum)

**File:** `src/main/java/com/ethernova/clans/territory/TerritoryFlag.java`

| Flag | Config Key | Display | Default | Description |
|------|------------|---------|---------|-------------|
| `PVP` | `pvp` | PvP | `true` | Allow PvP in territory |
| `MOB_SPAWN` | `mob-spawn` | Mobs | `true` | Allow mob spawning |
| `EXPLOSIONS` | `explosions` | Explosiones | `false` | Allow explosions |
| `FIRE_SPREAD` | `fire-spread` | Fuego | `false` | Allow fire spread |
| `INTERACT` | `interact` | Interacción | `false` | Allow non-member interaction |
| `CHEST_ACCESS` | `chest-access` | Cofres | `false` | Allow non-member chest access |
| `FLY` | `fly` | Vuelo | `false` | Allow flight |
| `ENDERPEARL` | `enderpearl` | Ender Pearl | `true` | Allow ender pearls |
| `CHORUS` | `chorus` | Chorus | `true` | Allow chorus fruit |
| `ANIMAL_DAMAGE` | `animal-damage` | Daño Animales | `false` | Allow animal damage by non-members |
| `ITEM_DROP` | `item-drop` | Drop Items | `true` | Allow item drops |
| `VEHICLE_USE` | `vehicle-use` | Vehículos | `true` | Allow vehicle use |

### 11.3 TerritoryFlagManager

**File:** `src/main/java/com/ethernova/clans/territory/TerritoryFlagManager.java`

#### Fields
| Field | Type | Description |
|-------|------|-------------|
| `clanFlags` | `ConcurrentHashMap<String, Map<TerritoryFlag, Boolean>>` | Clan ID → flags |

#### Methods
| Method | Signature | Description |
|--------|-----------|-------------|
| `getFlag` | `boolean getFlag(String clanId, TerritoryFlag)` | Get flag value (default if unset) |
| `setFlag` | `void setFlag(String clanId, TerritoryFlag, boolean)` | Set flag value |
| `toggleFlag` | `void toggleFlag(String clanId, TerritoryFlag)` | Toggle flag |
| `getAllFlags` | `Map<TerritoryFlag, Boolean> getAllFlags(String clanId)` | All flags for clan |
| `serialize` | `String serialize(String clanId)` | Serialize to `FLAG=value,...` |
| `deserialize` | `void deserialize(String clanId, String data)` | Load from serialized string |
| `removeFlags` | `void removeFlags(String clanId)` | Remove all flags for clan |

---

## 12. siege/ — Siege Mechanics

### SiegeManager

**File:** `src/main/java/com/ethernova/clans/siege/SiegeManager.java`

Banner-based territory siege system. Attackers place a banner and must defend it for configurable duration (default 300s). Success transfers the chunk.

#### Inner Types
- `Siege` — record: `(String chunkKey, String attackerClanId, String defenderClanId, long startTime, int durationSeconds, Location bannerLocation)`
  - `getRemainingSeconds()`, `isExpired()`, `getProgress()`

#### Fields
| Field | Type | Description |
|-------|------|-------------|
| `activeSieges` | `ConcurrentHashMap<String, Siege>` | chunk key → Siege |
| `siegeDurationSeconds` | `int` | Config: `siege.duration-seconds` (default 300) |

#### Methods
| Method | Signature | Description |
|--------|-----------|-------------|
| `startSiege` | `String startSiege(Clan attacker, Clan defender, String chunkKey, Location bannerLoc)` | Start siege; returns error message or null on success. Requires war, checks cooldown |
| `cancelSiege` | `void cancelSiege(String chunkKey)` | Defender wins; attacker gets 10min cooldown |
| `getSiege` | `Siege getSiege(String chunkKey)` | Get siege at chunk |
| `getActiveSieges` | `Collection<Siege> getActiveSieges()` | All active sieges |
| `getSiegesByClan` | `List<Siege> getSiegesByClan(String clanId)` | Sieges involving clan |
| `getActiveSiegeCount` | `int getActiveSiegeCount()` | Count active sieges |
| `shutdown` | `void shutdown()` | Clear all sieges (transient) |

#### Siege Completion (private)
On siege expiry: unclaim chunk from defender → claim for attacker → 5min cooldown for attacker → async DB save → Discord notification → audit log.

#### Tick
Runs every second via Bukkit timer. Checks for expired sieges and completes them.

---

## 13. diplomacy/ — Diplomacy & Treaties

### DiplomacyManager

**File:** `src/main/java/com/ethernova/clans/diplomacy/DiplomacyManager.java`

Advanced treaty system with proposals, acceptance, expiration, and breaking penalties.

#### Inner Types
- `TreatyType` — enum:

| Constant | Display Name | Icon | Default Hours | Description |
|----------|-------------|------|---------------|-------------|
| `NON_AGGRESSION` | Pacto de No Agresión | 🕊️ | 72h | Prevents war declaration |
| `TRADE_AGREEMENT` | Acuerdo Comercial | 💰 | 48h | Shares 5% bank income |
| `MUTUAL_DEFENSE` | Defensa Mutua | 🛡️ | 96h | Attack notifications |
| `EMBARGO` | Embargo Comercial | 🚫 | 24h | Blocks trade/interaction |

- `Treaty` — record: `(String clanIdA, String clanIdB, TreatyType type, long startTime, long endTime, String proposedBy)`
  - `isActive()`, `getRemainingMs()`, `getRemainingFormatted()`, `getKey()`

#### Fields
| Field | Type | Description |
|-------|------|-------------|
| `treaties` | `ConcurrentHashMap<String, Treaty>` | canonical key+type → Treaty |
| `pendingProposals` | `ConcurrentHashMap<String, Treaty>` | proposal key → Treaty |
| `expirationTask` | `BukkitTask` | Expiration timer (runs every minute) |

#### Methods
| Method | Signature | Description |
|--------|-----------|-------------|
| `getTreaties` | `List<Treaty> getTreaties(String clanId)` | Active treaties for clan |
| `getTreaty` | `Treaty getTreaty(String a, String b, TreatyType)` | Specific treaty lookup |
| `hasTreaty` | `boolean hasTreaty(String a, String b, TreatyType)` | Check treaty exists |
| `hasAnyTreaty` | `boolean hasAnyTreaty(String a, String b)` | Any treaty between pair |
| `isEmbargoed` | `boolean isEmbargoed(String a, String b)` | Embargo check |
| `proposeTreaty` | `String proposeTreaty(Clan proposer, Clan target, TreatyType)` | Propose; returns error or null |
| `acceptTreaty` | `String acceptTreaty(Clan acceptor, Clan proposer, TreatyType)` | Accept; refreshes timestamps; Discord notify |
| `rejectTreaty` | `String rejectTreaty(Clan rejector, Clan proposer, TreatyType)` | Reject proposal |
| `breakTreaty` | `String breakTreaty(Clan breaker, String otherId, TreatyType)` | Break with 1h cooldown penalty |
| `getPendingProposals` | `List<Treaty> getPendingProposals(String clanId)` | Pending proposals for clan |
| `loadAll` | `void loadAll()` | Load from `clan_treaties` table |
| `shutdown` | `void shutdown()` | Cancel timer, sync save |

#### DB Table: `clan_treaties`
| Column | Type |
|--------|------|
| `clan_id_a` | VARCHAR(8) PK |
| `clan_id_b` | VARCHAR(8) PK |
| `treaty_type` | VARCHAR(32) PK |
| `start_time` | BIGINT |
| `end_time` | BIGINT |
| `proposed_by` | VARCHAR(32) |

---

## 14. level/ — Clan Leveling

### ClanLevelManager

**File:** `src/main/java/com/ethernova/clans/level/ClanLevelManager.java`

XP-based level system with exponential scaling and per-level perks.

#### Inner Types
- `LevelData` — record: `(String name, int powerRequired, int maxMembers, int maxClaims, int maxAllies)`

#### Fields
| Field | Type | Description |
|-------|------|-------------|
| `xpMap` | `ConcurrentHashMap<String, Long>` | Clan ID → total XP |

#### Methods — Level Data
| Method | Signature | Description |
|--------|-----------|-------------|
| `getMaxLevel` | `int getMaxLevel()` | Config: `levels.max-level` (default 10) |
| `getLevelData` | `LevelData getLevelData(int level)` | Full level data record |
| `getLevelName` | `String getLevelName(int level)` | Config: `levels.names.<level>` |
| `getMaxMembers` | `int getMaxMembers(int level)` | Config: `levels.max-members.<level>` |
| `getMaxMembersWithSkill` | `int getMaxMembersWithSkill(String clanId)` | Base + skill bonus |
| `getMaxClaims` | `int getMaxClaims(int level)` | Config: `levels.max-claims.<level>` |
| `getMaxAllies` | `int getMaxAllies(int level)` | Config: `levels.max-allies.<level>` |

#### Methods — XP/Level Computation
| Method | Signature | Description |
|--------|-----------|-------------|
| `getXP` | `long getXP(String clanId)` | Total XP |
| `getLevel` | `int getLevel(String clanId)` | Computed from XP using formula: `baseXP * mult^level` |
| `getXPForNextLevel` | `long getXPForNextLevel(String clanId)` | XP needed for next level |
| `getCurrentLevelXP` | `long getCurrentLevelXP(String clanId)` | XP progress within current level |
| `getLevelProgress` | `double getLevelProgress(String clanId)` | 0.0 to 1.0 progress |
| `addXP` | `void addXP(String clanId, long amount)` | Add XP; triggers level-up if crossed |

#### Methods — XP Rewards
| Method | Config Key | Default |
|--------|-----------|---------|
| `onKill` | `levels.xp-per-kill` | 50 |
| `onClaim` | `levels.xp-per-claim` | 25 |
| `onWarWin` | `levels.xp-per-war-win` | 500 |
| `onAllyFormed` | `levels.xp-per-ally` | 100 |
| `onMemberJoin` | `levels.xp-per-member` | 30 |

#### Methods — Bonuses
| Method | Signature | Description |
|--------|-----------|-------------|
| `getMaxMembersBonus` | `int getMaxMembersBonus(String clanId)` | Cumulative `extra-members` from all level perks |
| `getExtraClaimsBonus` | `int getExtraClaimsBonus(String clanId)` | Cumulative `extra-claims` from all level perks |

#### Methods — Persistence
| Method | Signature |
|--------|-----------|
| `loadXP` | `void loadXP(String clanId, long xp)` |
| `getAllXP` | `Map<String, Long> getAllXP()` |
| `removeXP` | `void removeXP(String clanId)` |
| `setLevel` | `void setLevel(Clan, int level)` — admin; calculates required XP |
| `loadLevels` | `void loadLevels()` — no-op (dynamic from config) |
| `applyBoosts` | `void applyBoosts(Player, Clan)` — stub |
| `removeBoosts` | `void removeBoosts(Player, Clan)` — stub |

---

## 15. bank/ — Clan Bank

### ClanBankManager

**File:** `src/main/java/com/ethernova/clans/bank/ClanBankManager.java`

Central bank balance manager. Single source of truth; syncs with `Clan.bank` object.

#### Fields
| Field | Type | Description |
|-------|------|-------------|
| `balances` | `ConcurrentHashMap<String, Double>` | Clan ID → balance |

#### Methods
| Method | Signature | Description |
|--------|-----------|-------------|
| `getBalance` | `double getBalance(String clanId)` | Get balance (default 0) |
| `setBalance` | `void setBalance(String clanId, double)` | Set balance (clamp ≥0); syncs Clan.bank |
| `deposit` | `boolean deposit(Clan, Player, double)` | Withdraw from player via Vault, add to bank; atomic; returns success |
| `withdraw` | `boolean withdraw(Clan, Player, double)` | Check-and-deduct from bank, deposit to player via Vault; atomic; respects `bank.max-withdraw-per-day` |
| `getTaxRate` | `double getTaxRate()` | Config: `bank.territory-tax-rate` |
| `applyTerritoryTax` | `void applyTerritoryTax()` | For each clan: `claims × rate`; if insufficient, unclaim random chunks |
| `loadBalance` | `void loadBalance(String, double)` | Load from DB |
| `getAllBalances` | `Map<String, Double> getAllBalances()` | Immutable copy |
| `removeBalance` | `void removeBalance(String)` | Remove entry |

---

## 16. economy/ — Vault Economy

### EconomyManager

**File:** `src/main/java/com/ethernova/clans/economy/EconomyManager.java`

Vault Economy wrapper with lazy initialization and OfflinePlayer overloads.

#### Fields
| Field | Type | Description |
|-------|------|-------------|
| `economy` | `volatile Economy` | Vault Economy provider |
| `enabled` | `volatile boolean` | Whether Vault is available |
| `initialized` | `volatile boolean` | Initialization flag |

#### Methods
| Method | Signature |
|--------|-----------|
| `isEnabled` | `boolean isEnabled()` |
| `getBalance` | `double getBalance(Player)` / `double getBalance(OfflinePlayer)` |
| `has` | `boolean has(Player, double)` |
| `withdraw` | `boolean withdraw(Player, double)` / `boolean withdraw(OfflinePlayer, double)` |
| `deposit` | `boolean deposit(Player, double)` / `boolean deposit(OfflinePlayer, double)` |
| `format` | `String format(double)` — Vault format or `$%.2f` fallback |

---

## 17. storage/ — Database & Schema

### 17.1 StorageManager

**File:** `src/main/java/com/ethernova/clans/storage/StorageManager.java` (1186 lines)

HikariCP-backed database layer supporting SQLite and MySQL.

#### Fields
| Field | Type | Description |
|-------|------|-------------|
| `dataSource` | `HikariDataSource` | Connection pool |

#### Database Configuration
- **SQLite:** `database.type=SQLITE`, file at `database.sqlite.file` (default `clans.db`), pool size 1
- **MySQL:** `database.type=MYSQL`, host/port/database/username/password, pool size from `database.mysql.pool-size` (default 10)

#### Database Tables Created

| Table | Primary Key | Description |
|-------|-------------|-------------|
| `clans` | `id VARCHAR(8)` | Clan core data: name, tag, description, leader, home, created_at, upgrades JSON, stats, tag colors |
| `clan_members` | `(uuid, clan_id)` | Member data: name, role, rank_id, join_date |
| `clan_territories` | `chunk_id VARCHAR(64)` | Territory claims: chunk_id → clan_id |
| `clan_bank` | `clan_id VARCHAR(8)` | Bank balances |
| `clan_levels` | `clan_id VARCHAR(8)` | Clan XP |
| `clan_warps` | `(clan_id, name)` | Named warps with location |
| `clan_flags` | `clan_id VARCHAR(8)` | Territory flags (serialized text) |
| `clan_audit_log` | `id AUTO_INCREMENT` | Audit entries: action, player, details, timestamp |
| `clan_missions` | `(clan_id, definition_id)` | Mission progress tracking |
| `clan_achievements` | `(clan_id, achievement_id)` | Unlocked achievements |
| `clan_scheduled_events` | `id VARCHAR(64)` | Scheduled events |
| `clan_alliances` | `(clan_id_a, clan_id_b)` | Alliance pairs with created_at |
| `clan_permissions` | `(clan_id, perm_key)` | Custom permission config per clan |
| `clan_skills` | `(clan_id, skill_id)` | Clan skill levels |
| `clan_shop` | `(clan_id, item_id)` | Clan shop items |
| `clan_treaties` | `(clan_id_a, clan_id_b, treaty_type)` | Diplomacy treaties |
| `clan_salaries` | `(clan_id, role_name)` | Role-based salary amounts |
| `clan_ranks` | `(clan_id, rank_id)` | Custom rank definitions with permissions |
| `clan_shields` | `clan_id VARCHAR(8)` | Active protection shields with expiry |
| `clan_nations` | `nation_id VARCHAR(8)` | Nations (via schema migration v4) |
| `clan_nation_members` | `(nation_id, clan_id)` | Nation membership (via schema migration v4) |
| `clan_outposts` | `outpost_id VARCHAR(8)` | Outposts (via schema migration v4) |
| `clan_blueprints` | `id AUTO_INCREMENT` | Built blueprints (via schema migration v6) |
| `clan_banners` | `clan_id VARCHAR(8)` | Clan banners (via schema migration v6) |
| `clan_season_history` | `id AUTO_INCREMENT` | Season leaderboard history (via schema migration v6) |
| `clan_season_entries` | `id AUTO_INCREMENT` | Season stat snapshots (via schema migration v6) |
| `schema_version` | — | Migration version tracking |

#### Inner Record Types
- `MissionData(String definitionId, String type, int target, int progress, long expiresAt, boolean completed)`
- `AuditRow(String playerUuid, String playerName, String action, String details, long timestamp)`
- `ScheduledEventData(String id, String eventType, long startTime, long endTime, String data)`

#### Methods — Core
| Method | Signature | Description |
|--------|-----------|-------------|
| `initialize` | `void initialize()` | Create HikariCP pool + tables |
| `getConnection` | `Connection getConnection()` | Get pooled connection |
| `isMySQL` | `boolean isMySQL()` | Check backend type |
| `close` | `void close()` | Shutdown pool |

#### Methods — Clan CRUD
| Method | Signature | Description |
|--------|-----------|-------------|
| `saveClan` | `void saveClan(Clan)` | Transactional upsert: clan, members, warps, flags, ranks, tag colors |
| `deleteClan` | `void deleteClan(String clanId)` | Delete from ALL 20+ tables |
| `loadAllClans` | `List<Clan> loadAllClans()` | Load all clans + members + ranks + bank + XP + territories + warps + flags + alliances + tag colors |

#### Methods — Territory
| Method | Signature |
|--------|-----------|
| `saveAllTerritories` | `void saveAllTerritories(Map<String, String>)` |
| `saveTerritory` | `void saveTerritory(String chunkKey, String clanId)` |
| `deleteTerritory` | `void deleteTerritory(String chunkKey)` |

#### Methods — Bank/XP
| Method | Signature |
|--------|-----------|
| `saveBankBalances` | `void saveBankBalances(Map<String, Double>)` |
| `saveClanXP` | `void saveClanXP(Map<String, Long>)` |

#### Methods — Alliances
| Method | Signature |
|--------|-----------|
| `saveAllAlliances` | `void saveAllAlliances()` — canonical pair ordering to avoid duplicates |

#### Methods — Missions
| Method | Signature |
|--------|-----------|
| `saveClanMissions` | `void saveClanMissions(String clanId, List<MissionData>)` |
| `loadAllClanMissions` | `Map<String, List<MissionData>> loadAllClanMissions()` |
| `deleteClanMissions` | `void deleteClanMissions(String clanId)` |

#### Methods — Achievements
| Method | Signature |
|--------|-----------|
| `loadAllClanAchievements` | `Map<String, Set<String>> loadAllClanAchievements()` |
| `saveClanAchievements` | `void saveClanAchievements(String clanId, Set<String>)` |
| `deleteClanAchievements` | `void deleteClanAchievements(String clanId)` |

#### Methods — Audit
| Method | Signature |
|--------|-----------|
| `saveAuditEntry` | `void saveAuditEntry(String clanId, String playerUuid, String playerName, String action, String details, long timestamp)` |
| `getAuditLogCount` | `int getAuditLogCount(String clanId)` |
| `loadAuditLog` | `List<AuditRow> loadAuditLog(String clanId, int page, int pageSize)` |

#### Methods — Scheduled Events
| Method | Signature |
|--------|-----------|
| `saveScheduledEvent` | `void saveScheduledEvent(String id, String eventType, long startTime, long endTime, String data)` |
| `deactivateScheduledEvent` | `void deactivateScheduledEvent(String id)` |
| `loadActiveScheduledEvents` | `List<ScheduledEventData> loadActiveScheduledEvents()` |

#### Methods — Permissions
| Method | Signature |
|--------|-----------|
| `saveClanPermissions` | `void saveClanPermissions(String clanId, Map<String, String>)` |
| `loadAllClanPermissions` | `Map<String, Map<String, String>> loadAllClanPermissions()` |
| `deleteClanPermissions` | `void deleteClanPermissions(String clanId)` |

#### Methods — Shields
| Method | Signature |
|--------|-----------|
| `saveShields` | `void saveShields(Map<String, Long>)` |
| `loadShields` | `Map<String, Long> loadShields()` |

### 17.2 SchemaManager

**File:** `src/main/java/com/ethernova/clans/storage/SchemaManager.java` (207 lines)

Formal versioned migration system. Tracks applied versions in `schema_version` table.

**Current Version:** 6

#### Migrations

| Version | Changes |
|---------|---------|
| 1 | Baseline (no-op — tables exist from StorageManager) |
| 2 | Add `total_kills`, `total_deaths`, `wars_won`, `wars_lost` to `clans` |
| 3 | Add `rank_id` column to `clan_members` |
| 4 | Create `clan_nations`, `clan_nation_members`, `clan_outposts`; add `nation_id`, `icon` to `clans` |
| 5 | Create `clan_shields`; add `tag_color`, `gradient_start`, `gradient_end`, `use_gradient` to `clans` |
| 6 | Create `clan_blueprints`, `clan_banners`, `clan_season_history`, `clan_season_entries` |

#### Methods
| Method | Signature | Description |
|--------|-----------|-------------|
| `migrate` | `void migrate(Connection)` | Run all pending migrations in order |

---

*End of Part 1. Part 2 will cover the remaining packages: api/, gui/, listener/, message/, mission/, achievement/, upgrade/, shield/, hologram/, hook/, placeholder/, nametag/, audit/, fly/, teleport/, discord/, cooldown/, event/, util/, nation/, outpost/, spy/, skill/, shop/, salary/, tax/, season/, banner/, blueprint/, webmap/.*
