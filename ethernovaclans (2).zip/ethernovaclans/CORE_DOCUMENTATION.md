# EthernovaCore — Comprehensive Plugin Documentation

> **Auto-generated**: February 10, 2026  
> **Module path**: `core/src/main/java/com/ethernova/core/`  
> **Total classes**: 18 Java source files  

---

## Table of Contents

1. [Plugin Overview](#1-plugin-overview)
2. [Maven Module & Dependencies](#2-maven-module--dependencies)
3. [Main Class — EthernovaCore](#3-main-class--ethernovacore)
4. [Configuration System](#4-configuration-system)
   - 4.1 [CoreConfigManager](#41-coreconfigmanager)
   - 4.2 [Configuration Reference (config.yml)](#42-configuration-reference-configyml)
5. [Message System](#5-message-system)
   - 5.1 [CoreMessageManager](#51-coremessagemanager)
   - 5.2 [Message Keys](#52-message-keys)
6. [Storage System](#6-storage-system)
   - 6.1 [CoreStorageManager](#61-corestoragemanager)
   - 6.2 [Database Schema](#62-database-schema)
7. [Player Profiles](#7-player-profiles)
   - 7.1 [PlayerProfile](#71-playerprofile)
   - 7.2 [PlayerProfileManager](#72-playerprofilemanager)
8. [Context System](#8-context-system)
   - 8.1 [ContextManager](#81-contextmanager)
9. [Cooldown System](#9-cooldown-system)
   - 9.1 [CooldownManager](#91-cooldownmanager)
10. [Economy Integration](#10-economy-integration)
    - 10.1 [EconomyHook](#101-economyhook)
11. [Visual System](#11-visual-system)
    - 11.1 [VisualManager](#111-visualmanager)
12. [Event Bus System](#12-event-bus-system)
    - 12.1 [EthernovaEventBus](#121-ethernovaeventbus)
    - 12.2 [PowerChangeEvent](#122-powerchangeevent)
    - 12.3 [EthernovaPlayerKillEvent](#123-ethernovaplayerkillevent)
    - 12.4 [ClanWarStartEvent](#124-clanwarstartevent)
    - 12.5 [ClanWarEndEvent](#125-clanwarendevent)
13. [GUI Framework](#13-gui-framework)
    - 13.1 [CoreGui (Abstract Base)](#131-coregui-abstract-base)
14. [Listener](#14-listener)
    - 14.1 [CorePlayerListener](#141-coreplayerlistener)
15. [Commands Reference](#15-commands-reference)
    - 15.1 [CoreCommand](#151-corecommand)
16. [Permissions Reference](#16-permissions-reference)
17. [API for Other Plugins](#17-api-for-other-plugins)

---

## 1. Plugin Overview

| Field | Value |
|-------|-------|
| **Plugin name** | `EthernovaCore` |
| **Version** | `${project.version}` (Maven-filtered) |
| **Main class** | `com.ethernova.core.EthernovaCore` |
| **API version** | `1.21` (Paper API) |
| **Prefix** | `EthernovaCore` |
| **Authors** | `Ethernova` |
| **Soft-dependencies** | `Vault` |

**File**: `core/src/main/resources/plugin.yml` (17 lines)

```yaml
name: EthernovaCore
version: '${project.version}'
main: com.ethernova.core.EthernovaCore
api-version: '1.21'
prefix: EthernovaCore
authors: [Ethernova]
softdepend:
  - Vault

commands:
  ethernova:
    description: Core command
    permission: ethernova.admin

permissions:
  ethernova.admin:
    default: op
```

---

## 2. Maven Module & Dependencies

**File**: `core/pom.xml`

| Property | Value |
|----------|-------|
| **Group ID** | `com.ethernova` |
| **Artifact ID** | `ethernova-core` |
| **Parent** | `ethernova-parent:1.0.0` |

### Compile Dependencies

| Dependency | Artifact | Notes |
|------------|----------|-------|
| Paper API | `io.papermc.paper:paper-api` | Minecraft server API |
| Vault API | `com.github.MilkBowl:VaultAPI` | Economy abstraction |
| PlaceholderAPI | `me.clip:placeholderapi` | Placeholder expansion |
| HikariCP | `com.zaxxer:HikariCP` | JDBC connection pool (shaded & relocated) |

### Shading

HikariCP is shaded into the final JAR and relocated to `com.ethernova.core.lib.hikari` to avoid classpath conflicts.

---

## 3. Main Class — EthernovaCore

**File**: `core/src/main/java/com/ethernova/core/EthernovaCore.java` (87 lines)  
**Extends**: `org.bukkit.plugin.java.JavaPlugin`

### Private Fields

| Field | Type | Description |
|-------|------|-------------|
| `instance` | `static volatile EthernovaCore` | Singleton instance (set after full init) |
| `configManager` | `CoreConfigManager` | Configuration loading/access |
| `messageManager` | `CoreMessageManager` | Localized message system |
| `storageManager` | `CoreStorageManager` | Database connection pool |
| `profileManager` | `PlayerProfileManager` | Player profile CRUD |
| `contextManager` | `ContextManager` | Inter-plugin player contexts |
| `eventBus` | `EthernovaEventBus` | Custom publish/subscribe bus |
| `economyHook` | `EconomyHook` | Vault economy bridge |
| `visualManager` | `VisualManager` | Boss bars, titles, particles |
| `cooldownManager` | `CooldownManager` | Per-player cooldown tracking |
| `registeredPlugins` | `Set<String>` (ConcurrentHashMap-backed) | Names of Ethernova sub-plugins |

### Lifecycle

#### `onEnable()`
1. Creates and loads `CoreConfigManager`
2. Creates `CoreMessageManager`
3. Creates and initializes `CoreStorageManager` (DB pool + table creation)
4. Creates `PlayerProfileManager`, `ContextManager`, `EthernovaEventBus`, `EconomyHook`, `VisualManager`, `CooldownManager`
5. Registers `CorePlayerListener`
6. Registers `/ethernova` command with `CoreCommand` as executor and tab completer
7. Logs enable message
8. Sets the singleton `instance` **after** all managers are ready

#### `onDisable()`
1. Clears all event bus listeners
2. Saves all in-memory player profiles
3. Removes all boss bars from players
4. Closes the database connection pool
5. Sets `instance = null`

### Public Methods (Accessors)

| Method | Return Type |
|--------|-------------|
| `getInstance()` | `static EthernovaCore` |
| `getConfigManager()` | `CoreConfigManager` |
| `getMessageManager()` | `CoreMessageManager` |
| `getStorageManager()` | `CoreStorageManager` |
| `getProfileManager()` | `PlayerProfileManager` |
| `getContextManager()` | `ContextManager` |
| `getEventBus()` | `EthernovaEventBus` |
| `getEconomyHook()` | `EconomyHook` |
| `getVisualManager()` | `VisualManager` |
| `getCooldownManager()` | `CooldownManager` |
| `registerPlugin(String name)` | `void` — registers a sub-plugin name |
| `unregisterPlugin(String name)` | `void` — unregisters a sub-plugin name |
| `getRegisteredPlugins()` | `Set<String>` — unmodifiable view |

---

## 4. Configuration System

### 4.1 CoreConfigManager

**File**: `core/src/main/java/com/ethernova/core/config/CoreConfigManager.java` (58 lines)  
**Package**: `com.ethernova.core.config`

#### Private Fields

| Field | Type | Description |
|-------|------|-------------|
| `TIME_PATTERN` | `static final Pattern` | Regex `(\d+)\s*([smhd])` for time parsing |
| `plugin` | `JavaPlugin` | Plugin reference |
| `config` | `volatile FileConfiguration` | Cached Bukkit config |

#### Public Methods

| Signature | Description |
|-----------|-------------|
| `CoreConfigManager(JavaPlugin plugin)` | Constructor |
| `void loadAll()` | Saves default config, reloads, caches `FileConfiguration` |
| `FileConfiguration getConfig()` | Returns the cached configuration |
| `String getString(String path, String def)` | Get string config value with default |
| `int getInt(String path, int def)` | Get integer config value with default |
| `boolean getBoolean(String path, boolean def)` | Get boolean config value with default |
| `long parseTimeToMillis(String input)` | Parses human time strings (`"30s"`, `"5m"`, `"2h"`, `"1d"`) to milliseconds. Falls back to treating raw number as seconds. |
| `String formatTime(long millis)` | Formats milliseconds to `"Xh Xm Xs"` string |

### 4.2 Configuration Reference (config.yml)

**File**: `core/src/main/resources/config.yml` (25 lines)

```yaml
general:
  language: "es"          # Language code for message files
  debug: false            # Debug logging toggle

database:
  type: "SQLITE"          # SQLITE or MYSQL
  sqlite:
    file: "ethernova.db"  # SQLite file name
  mysql:
    host: "localhost"
    port: 3306
    database: "ethernova"
    username: "root"
    password: ""
    pool-size: 10          # HikariCP pool size

visual:
  default-title-fade-in: 5   # Title fade-in ticks
  default-title-stay: 40      # Title display ticks
  default-title-fade-out: 10  # Title fade-out ticks

profiles:
  auto-save-interval: 300     # Auto-save interval in seconds
```

#### Config Keys Used in Code

| Key | Used By | Type | Default |
|-----|---------|------|---------|
| `general.language` | `CoreMessageManager` | `String` | `"es"` |
| `general.debug` | `CoreConfigManager` | `boolean` | `false` |
| `database.type` | `CoreStorageManager` | `String` | `"SQLITE"` |
| `database.sqlite.file` | — (hardcoded `ethernova.db`) | — | — |
| `database.mysql.host` | `CoreStorageManager` | `String` | `"localhost"` |
| `database.mysql.port` | `CoreStorageManager` | `int` | `3306` |
| `database.mysql.database` | `CoreStorageManager` | `String` | `"ethernova"` |
| `database.mysql.username` | `CoreStorageManager` | `String` | `"root"` |
| `database.mysql.password` | `CoreStorageManager` | `String` | `""` |
| `database.mysql.pool-size` | `CoreStorageManager` | `int` | `10` |
| `visual.default-title-fade-in` | — (defined, not directly read in core) | `int` | `5` |
| `visual.default-title-stay` | — (defined, not directly read in core) | `int` | `40` |
| `visual.default-title-fade-out` | — (defined, not directly read in core) | `int` | `10` |
| `profiles.auto-save-interval` | — (defined, not directly read in core) | `int` | `300` |

---

## 5. Message System

### 5.1 CoreMessageManager

**File**: `core/src/main/java/com/ethernova/core/message/CoreMessageManager.java` (47 lines)  
**Package**: `com.ethernova.core.message`

Uses Adventure API's **MiniMessage** format for text styling.

#### Private Fields

| Field | Type | Description |
|-------|------|-------------|
| `plugin` | `JavaPlugin` | Plugin reference |
| `mini` | `MiniMessage` | MiniMessage singleton instance |
| `messages` | `volatile YamlConfiguration` | Loaded message file |
| `prefix` | `volatile String` | Cached `general.prefix` value |

#### Public Methods

| Signature | Description |
|-----------|-------------|
| `CoreMessageManager(JavaPlugin plugin)` | Constructor — calls `load()` |
| `void load()` | Loads message file for configured language. Falls back to `messages_es.yml` if requested language file doesn't exist. Merges defaults from JAR resource. Caches the prefix. |
| `MiniMessage getMiniMessage()` | Returns the MiniMessage instance |
| `String get(String path, String... replacements)` | Retrieves a raw message string by YAML path, replaces `{prefix}` and custom placeholders (key-value pairs). Returns `<red>[Missing: path]</red>` if not found. |
| `void send(CommandSender sender, String path, String... replacements)` | Retrieves, deserializes, and sends a MiniMessage to a command sender |

### 5.2 Message Keys

**Available languages**: English (`messages_en.yml`), Spanish (`messages_es.yml`)

#### English Messages (`messages_en.yml`)

| Key | Value |
|-----|-------|
| `general.prefix` | `<gradient:#A855F7:#6366F1>Ethernova</gradient> <dark_gray>»</dark_gray>` |
| `general.no-permission` | `{prefix} <red>✘</red> <gray>You don't have permission to do this.</gray>` |
| `general.reloaded` | `{prefix} <green>✔</green> <gray>Configuration reloaded successfully.</gray>` |
| `general.info` | `{prefix} <gradient:#A855F7:#6366F1><bold>EthernovaCore</bold></gradient> <dark_gray>—</dark_gray> <gray>Ethernova ecosystem core.</gray>` |

#### Spanish Messages (`messages_es.yml`)

| Key | Value |
|-----|-------|
| `general.prefix` | `<gradient:#A855F7:#6366F1>Ethernova</gradient> <dark_gray>»</dark_gray>` |
| `general.no-permission` | `{prefix} <red>✘</red> <gray>No tienes permiso para hacer esto.</gray>` |
| `general.reloaded` | `{prefix} <green>✔</green> <gray>Configuración recargada correctamente.</gray>` |
| `general.info` | `{prefix} <gradient:#A855F7:#6366F1><bold>EthernovaCore</bold></gradient> <dark_gray>—</dark_gray> <gray>Núcleo del ecosistema Ethernova.</gray>` |

---

## 6. Storage System

### 6.1 CoreStorageManager

**File**: `core/src/main/java/com/ethernova/core/storage/CoreStorageManager.java` (67 lines)  
**Package**: `com.ethernova.core.storage`

Manages a HikariCP connection pool supporting both **SQLite** and **MySQL** backends.

#### Private Fields

| Field | Type | Description |
|-------|------|-------------|
| `plugin` | `JavaPlugin` | Plugin reference |
| `dataSource` | `HikariDataSource` | HikariCP connection pool |

#### Public Methods

| Signature | Description |
|-----------|-------------|
| `CoreStorageManager(JavaPlugin plugin)` | Constructor |
| `void initialize()` | Reads DB config, configures HikariCP pool (MySQL or SQLite), creates the `HikariDataSource`, and calls `createTables()` |
| `Connection getConnection()` | Returns a JDBC `Connection` from the pool. Throws `SQLException` if the pool is unavailable. |
| `boolean isMySQL()` | Returns `true` if the JDBC URL starts with `jdbc:mysql` |
| `void close()` | Closes the `HikariDataSource` if open |

#### Private Methods

| Signature | Description |
|-----------|-------------|
| `void createTables()` | Executes DDL to create the `ethernova_profiles` table if it doesn't exist |

#### HikariCP Configuration

| Backend | Pool Name | Max Pool Size | Notes |
|---------|-----------|---------------|-------|
| MySQL | `EthernovaCore-Pool` | Configurable (`pool-size`, default 10) | `useSSL=false&autoReconnect=true` |
| SQLite | `EthernovaCore-Pool` | 1 (fixed) | File at `plugins/EthernovaCore/ethernova.db` |

### 6.2 Database Schema

#### Table: `ethernova_profiles`

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `uuid` | `VARCHAR(36)` | `PRIMARY KEY` | Player UUID |
| `name` | `VARCHAR(16)` | — | Player username |
| `kills` | `INT` | `DEFAULT 0` | Total kills |
| `deaths` | `INT` | `DEFAULT 0` | Total deaths |
| `play_time` | `BIGINT` | `DEFAULT 0` | Total play time (milliseconds) |
| `first_join` | `BIGINT` | `DEFAULT 0` | First join timestamp (epoch ms) |
| `last_join` | `BIGINT` | `DEFAULT 0` | Last join timestamp (epoch ms) |

**Upsert Strategy**:
- **MySQL**: `INSERT ... ON DUPLICATE KEY UPDATE`
- **SQLite**: `INSERT ... ON CONFLICT(uuid) DO UPDATE SET`

Updates `name`, `kills`, `deaths`, `play_time`, `last_join` on conflict. `first_join` is never overwritten after initial insert.

---

## 7. Player Profiles

### 7.1 PlayerProfile

**File**: `core/src/main/java/com/ethernova/core/profile/PlayerProfile.java` (39 lines)  
**Package**: `com.ethernova.core.profile`

A thread-safe data holder for per-player statistics. Uses `AtomicInteger` for kills/deaths and `volatile` for other fields.

#### Private Fields

| Field | Type | Thread Safety | Description |
|-------|------|---------------|-------------|
| `uuid` | `final UUID` | Immutable | Player UUID |
| `name` | `volatile String` | `volatile` | Player display name |
| `kills` | `AtomicInteger` | Atomic | Total kill count |
| `deaths` | `AtomicInteger` | Atomic | Total death count |
| `playTime` | `volatile long` | `volatile` | Total play time (ms) |
| `firstJoin` | `volatile long` | `volatile` | First join timestamp (epoch ms) |
| `lastJoin` | `volatile long` | `volatile` | Last join timestamp (epoch ms) |

#### Constructor

```java
public PlayerProfile(UUID uuid, String name)
```

#### Public Methods

| Signature | Description |
|-----------|-------------|
| `UUID getUuid()` | Returns the player UUID |
| `String getName()` | Returns the player name |
| `void setName(String name)` | Sets the player name |
| `int getKills()` | Returns kill count |
| `void setKills(int kills)` | Sets kill count |
| `int getDeaths()` | Returns death count |
| `void setDeaths(int deaths)` | Sets death count |
| `long getPlayTime()` | Returns play time in ms |
| `void setPlayTime(long playTime)` | Sets play time |
| `long getFirstJoin()` | Returns first join timestamp |
| `void setFirstJoin(long firstJoin)` | Sets first join timestamp |
| `long getLastJoin()` | Returns last join timestamp |
| `void setLastJoin(long lastJoin)` | Sets last join timestamp |
| `void addKill()` | Atomically increments kill count by 1 |
| `void addDeath()` | Atomically increments death count by 1 |
| `double getKDR()` | Calculates Kill/Death ratio. Returns `kills` if deaths == 0, otherwise `kills / deaths`. |

### 7.2 PlayerProfileManager

**File**: `core/src/main/java/com/ethernova/core/profile/PlayerProfileManager.java` (112 lines)  
**Package**: `com.ethernova.core.profile`

Manages an in-memory `ConcurrentHashMap<UUID, PlayerProfile>` cache backed by the `ethernova_profiles` database table.

#### Private Fields

| Field | Type | Description |
|-------|------|-------------|
| `core` | `EthernovaCore` | Core plugin reference |
| `profiles` | `Map<UUID, PlayerProfile>` (ConcurrentHashMap) | In-memory profile cache |

#### Public Methods

| Signature | Description |
|-----------|-------------|
| `PlayerProfileManager(EthernovaCore core)` | Constructor |
| `PlayerProfile getProfile(UUID uuid)` | Returns the cached profile or `null` if not loaded |
| `PlayerProfile getOrCreate(UUID uuid, String name)` | Gets from cache, loads from DB, or creates new. Uses `putIfAbsent` for thread safety. Sets `firstJoin` on new profiles. |
| `void registerIfAbsent(UUID uuid, PlayerProfile profile)` | Registers a pre-created profile if none exists. Thread-safe for main thread usage. |
| `void mergeFromDB(UUID uuid, String name)` | Loads profile from DB and merges stats into the existing in-memory profile. Safe for async execution. Merges `kills`, `deaths`, `playTime`, `firstJoin`. Preserves in-memory `lastJoin` if non-zero. |
| `void save(PlayerProfile profile)` | Upserts a single profile to the database. Uses MySQL or SQLite upsert syntax based on `isMySQL()`. |
| `void remove(UUID uuid)` | Removes profile from in-memory cache |
| `void saveAll()` | Batch-saves all cached profiles in a single transaction. Uses `setAutoCommit(false)`, `addBatch()`, `executeBatch()`, with rollback on failure. |

#### Private Methods

| Signature | Description |
|-----------|-------------|
| `PlayerProfile loadFromDB(UUID uuid)` | Loads a profile from the `ethernova_profiles` table by UUID. Returns `null` if not found or on error. |

---

## 8. Context System

### 8.1 ContextManager

**File**: `core/src/main/java/com/ethernova/core/context/ContextManager.java` (33 lines)  
**Package**: `com.ethernova.core.context`

Tracks inter-plugin contexts per player. Used by the Combat plugin to apply different combat tag profiles based on context (e.g., `"war"`, `"arena"`, `"ffa"`).

#### Private Fields

| Field | Type | Description |
|-------|------|-------------|
| `contexts` | `Map<UUID, Set<String>>` (ConcurrentHashMap + ConcurrentHashMap.newKeySet) | Player UUID to active context strings |

#### Public Methods

| Signature | Description |
|-----------|-------------|
| `void addContext(UUID uuid, String context)` | Adds a context string for a player |
| `void removeContext(UUID uuid, String context)` | Removes a context string for a player |
| `boolean hasContext(UUID uuid, String context)` | Checks if a player has a specific context |
| `Set<String> getContexts(UUID uuid)` | Returns an unmodifiable set of all contexts for a player, or an empty set |
| `void clearAll(UUID uuid)` | Removes all contexts for a player (O(1) cleanup) |

---

## 9. Cooldown System

### 9.1 CooldownManager

**File**: `core/src/main/java/com/ethernova/core/cooldown/CooldownManager.java` (49 lines)  
**Package**: `com.ethernova.core.cooldown`

In-memory cooldown tracker keyed by `(UUID, String id)`. Stores expiry timestamps and auto-cleans on check.

#### Private Fields

| Field | Type | Description |
|-------|------|-------------|
| `cooldowns` | `Map<UUID, Map<String, Long>>` (nested ConcurrentHashMaps) | Player UUID → (cooldown ID → expiry epoch ms) |

#### Public Methods

| Signature | Description |
|-----------|-------------|
| `void setCooldown(UUID uuid, String id, long durationMs)` | Sets a cooldown with given duration from now |
| `boolean hasCooldown(UUID uuid, String id)` | Returns `true` if cooldown is active. Auto-removes expired entries. |
| `long getRemainingMs(UUID uuid, String id)` | Returns remaining milliseconds (0 if expired or absent) |
| `String getRemainingFormatted(UUID uuid, String id)` | Returns human-readable remaining time: `"Xs"`, `"Xm Xs"`, or `"Xh Xm"` |
| `void removeCooldown(UUID uuid, String id)` | Removes a specific cooldown |
| `void clearAll(UUID uuid)` | Removes all cooldowns for a player (O(1) per-player cleanup) |

---

## 10. Economy Integration

### 10.1 EconomyHook

**File**: `core/src/main/java/com/ethernova/core/economy/EconomyHook.java` (46 lines)  
**Package**: `com.ethernova.core.economy`

Bridges to Vault's `Economy` service. Lazy-initializes on first use — safe for soft-dependency scenarios where Vault may not be present at startup.

#### Private Fields

| Field | Type | Description |
|-------|------|-------------|
| `economy` | `volatile Economy` | Vault economy provider |
| `enabled` | `volatile boolean` | Whether Vault economy was found |
| `initialized` | `volatile boolean` | Whether init has been attempted |

#### Public Methods

| Signature | Description |
|-----------|-------------|
| `EconomyHook()` | Constructor — attempts `tryInit()` |
| `boolean isEnabled()` | Returns `true` if Vault economy is available |
| `double getBalance(Player p)` | Gets the player's balance (0 if Vault unavailable) |
| `boolean has(Player p, double amount)` | Checks if the player has at least `amount` |
| `boolean withdraw(Player p, double amount)` | Withdraws `amount` from the player's balance. Returns `true` on success. |
| `boolean deposit(Player p, double amount)` | Deposits `amount` to the player's balance. Returns `true` on success. |
| `boolean withdrawOffline(UUID uuid, double amount)` | Withdraws from an offline player by UUID |
| `String format(double amount)` | Formats a monetary amount using Vault's format, or `$X.XX` fallback |

#### Private Methods

| Signature | Description |
|-----------|-------------|
| `void tryInit()` | Looks up `Vault` plugin, then resolves `Economy` from Bukkit's service manager |
| `void ensureInit()` | Calls `tryInit()` if not yet initialized (lazy init) |

---

## 11. Visual System

### 11.1 VisualManager

**File**: `core/src/main/java/com/ethernova/core/visual/VisualManager.java` (56 lines)  
**Package**: `com.ethernova.core.visual`

Manages boss bars, titles, action bar messages, and visual effects. Uses Adventure API's MiniMessage for text formatting.

#### Private Fields

| Field | Type | Description |
|-------|------|-------------|
| `mini` | `MiniMessage` | MiniMessage instance for text parsing |
| `bossBars` | `Map<String, BossBar>` (ConcurrentHashMap) | ID → BossBar registry |

#### Public Methods

| Signature | Description |
|-----------|-------------|
| `BossBar createBossBar(String id, String text, BossBar.Color color, float progress)` | Creates and registers a boss bar. Hides previous bar with same ID from all players. Returns the new `BossBar`. |
| `BossBar getBossBar(String id)` | Returns a boss bar by ID (or `null`) |
| `void showBossBar(Player player, String id)` | Shows a registered boss bar to a player |
| `void hideBossBar(Player player, String id)` | Hides a registered boss bar from a player |
| `void removeBossBar(String id)` | Removes a boss bar from the registry (does not hide from viewers) |
| `void removeAllBossBars()` | Hides all boss bars from all online players and clears the registry |
| `void sendTitle(Player player, String title, String subtitle)` | Sends a title + subtitle to a player (MiniMessage formatted) |
| `void sendActionBar(Player player, String message)` | Sends an action bar message to a player (MiniMessage formatted) |
| `void spawnLightning(Location location)` | Spawns a cosmetic lightning effect at a location |
| `void spawnBloodEffect(Location location)` | Spawns a redstone block particle "blood" effect (30 particles) at location + 1Y |

---

## 12. Event Bus System

### 12.1 EthernovaEventBus

**File**: `core/src/main/java/com/ethernova/core/event/EthernovaEventBus.java` (40 lines)  
**Package**: `com.ethernova.core.event`

A custom publish/subscribe event bus independent of Bukkit's event system. Designed for lightweight inter-plugin communication within the Ethernova ecosystem.

#### Private Fields

| Field | Type | Description |
|-------|------|-------------|
| `listeners` | `Map<Class<?>, List<Consumer>>` (ConcurrentHashMap + CopyOnWriteArrayList) | Event class → listener list |

#### Public Methods

| Signature | Description |
|-----------|-------------|
| `<T> void subscribe(Class<T> type, Consumer<T> listener)` | Subscribes a listener to events of a given type |
| `<T> void unsubscribe(Class<T> type, Consumer<T> listener)` | Removes a specific listener |
| `void clearListeners(Class<?> type)` | Removes all listeners for a specific event type |
| `void clearAll()` | Removes ALL listeners (called on plugin disable to prevent classloader leaks) |
| `void publish(Object event)` | Dispatches an event to all subscribers of its exact class. Catches and logs exceptions per-listener. |

#### Thread Safety

- `ConcurrentHashMap` for the listener map
- `CopyOnWriteArrayList` for each event type's listener list
- Individual listener exceptions are caught and logged without propagating

### 12.2 PowerChangeEvent

**File**: `core/src/main/java/com/ethernova/core/event/PowerChangeEvent.java` (14 lines)  
**Type**: Java `record`

Published when a player's power changes.

| Component | Type | Description |
|-----------|------|-------------|
| `playerUuid` | `UUID` | Player whose power changed |
| `playerName` | `String` | Player name |
| `oldPower` | `double` | Previous power value |
| `newPower` | `double` | New power value |
| `reason` | `String` | Reason for the change |

### 12.3 EthernovaPlayerKillEvent

**File**: `core/src/main/java/com/ethernova/core/event/EthernovaPlayerKillEvent.java` (10 lines)  
**Type**: Java `record`

Published when a player kills another player.

| Component | Type | Description |
|-----------|------|-------------|
| `killerUuid` | `UUID` | Killer's UUID |
| `killerName` | `String` | Killer's name |
| `victimUuid` | `UUID` | Victim's UUID |
| `victimName` | `String` | Victim's name |
| `context` | `String` | Context of the kill (e.g., `"war"`, `"arena"`) |

### 12.4 ClanWarStartEvent

**File**: `core/src/main/java/com/ethernova/core/event/ClanWarStartEvent.java` (14 lines)  
**Type**: Java `record`

Published when a clan war begins.

| Component | Type | Description |
|-----------|------|-------------|
| `attackerClanId` | `UUID` | Attacking clan's UUID |
| `attackerClanName` | `String` | Attacking clan's display name |
| `defenderClanId` | `UUID` | Defending clan's UUID |
| `defenderClanName` | `String` | Defending clan's display name |

### 12.5 ClanWarEndEvent

**File**: `core/src/main/java/com/ethernova/core/event/ClanWarEndEvent.java` (12 lines)  
**Type**: Java `record`

Published when a clan war ends.

| Component | Type | Description |
|-----------|------|-------------|
| `winnerClanId` | `UUID` | Winning clan's UUID |
| `loserClanId` | `UUID` | Losing clan's UUID |
| `reason` | `String` | Reason for the war ending |

---

## 13. GUI Framework

### 13.1 CoreGui (Abstract Base)

**File**: `core/src/main/java/com/ethernova/core/gui/CoreGui.java` (112 lines)  
**Package**: `com.ethernova.core.gui`  
**Modifier**: `abstract`

Base GUI framework for all Ethernova plugin GUIs. Provides inventory creation, border filling, item building, sound playback, and click handling.

#### Protected Fields

| Field | Type | Description |
|-------|------|-------------|
| `core` | `EthernovaCore` | Core plugin reference |
| `player` | `Player` | The player viewing the GUI |
| `mini` | `MiniMessage` | MiniMessage instance |
| `slotActions` | `Map<Integer, String>` (HashMap) | Slot index → action string mapping |
| `inventory` | `Inventory` | The Bukkit inventory instance |

#### Constructor

```java
protected CoreGui(EthernovaCore core, Player player)
```

#### Abstract Methods (must be implemented by subclasses)

| Signature | Description |
|-----------|-------------|
| `void populateItems()` | Defines the GUI items and slot-action mappings |
| `boolean processAction(String action, int slot, InventoryClickEvent event)` | Handles a named action triggered by a click |

#### Public Methods

| Signature | Description |
|-----------|-------------|
| `void handleClick(InventoryClickEvent event)` | Cancels the event, resolves the action for the clicked slot, handles `"CLOSE"` action, delegates to `processAction()` |
| `Player getPlayer()` | Returns the player viewing the GUI |

#### Protected Methods

| Signature | Description |
|-----------|-------------|
| `void openInventory(String title, int size)` | Creates a Bukkit inventory with MiniMessage title, fills borders, calls `populateItems()`, opens for player |
| `void setItem(int slot, ItemStack item)` | Sets an item in the inventory with bounds checking |
| `ItemStack createItem(Material material, String name)` | Creates an ItemStack with a MiniMessage display name |
| `ItemStack createItem(Material material, String name, List<String> lore)` | Creates an ItemStack with MiniMessage display name and lore |
| `void fillBorders()` | Fills the top row, bottom row, and side columns with gray stained glass panes |
| `void playSound(String soundName)` | Plays a sound to the player. Supports shortcuts: `"click"` → `UI_BUTTON_CLICK`, `"success"` → `ENTITY_PLAYER_LEVELUP`, `"error"` → `ENTITY_VILLAGER_NO`, or any Bukkit `Sound` enum name. |
| `String replacePlaceholders(String text)` | Replaces `{player}` with the viewer's name |
| `void onBack()` | Called on `"BACK"` action; default implementation closes inventory. Override for custom back navigation. |

---

## 14. Listener

### 14.1 CorePlayerListener

**File**: `core/src/main/java/com/ethernova/core/listener/CorePlayerListener.java` (47 lines)  
**Package**: `com.ethernova.core.listener`  
**Implements**: `org.bukkit.event.Listener`

Handles player join/quit lifecycle for the core profile system.

#### Private Fields

| Field | Type | Description |
|-------|------|-------------|
| `core` | `EthernovaCore` | Core plugin reference |

#### Event Handlers

| Event | Priority | Description |
|-------|----------|-------------|
| `PlayerJoinEvent` | `LOWEST` | Creates an empty `PlayerProfile` immediately (never null on join tick), sets `lastJoin`, registers via `registerIfAbsent()`. Then schedules an **async** task to `mergeFromDB()` — loading persisted stats into the live profile. |
| `PlayerQuitEvent` | `MONITOR` | Gets the profile, removes it from the in-memory cache **synchronously** (prevents rapid-reconnect race conditions), clears all contexts and cooldowns for the player. Schedules an **async** task to save the profile snapshot to the database. |

---

## 15. Commands Reference

### 15.1 CoreCommand

**File**: `core/src/main/java/com/ethernova/core/command/CoreCommand.java` (39 lines)  
**Package**: `com.ethernova.core.command`  
**Implements**: `CommandExecutor`, `TabCompleter`

#### Command: `/ethernova`

| Subcommand | Permission | Description |
|------------|------------|-------------|
| `/ethernova` | `ethernova.admin` | Shows plugin info message (`general.info`) |
| `/ethernova reload` | `ethernova.admin` | Reloads config (`CoreConfigManager.loadAll()`), reloads messages (`CoreMessageManager.load()`), sends confirmation (`general.reloaded`) |

#### Tab Completion

- First argument: suggests `reload` (only if sender has `ethernova.admin`)
- All other positions: empty list

---

## 16. Permissions Reference

| Permission | Default | Description |
|------------|---------|-------------|
| `ethernova.admin` | `op` | Access to `/ethernova` command and all admin operations |

---

## 17. API for Other Plugins

EthernovaCore is designed as a shared foundation for the Ethernova plugin ecosystem. Other plugins access it via the singleton pattern:

```java
EthernovaCore core = EthernovaCore.getInstance();
```

### Plugin Registration

Sub-plugins should register/unregister themselves:

```java
// In your onEnable()
EthernovaCore.getInstance().registerPlugin("MyPlugin");

// In your onDisable()
EthernovaCore.getInstance().unregisterPlugin("MyPlugin");
```

### Available API Services

| Service | Accessor | Key Methods |
|---------|----------|-------------|
| **Configuration** | `core.getConfigManager()` | `getString()`, `getInt()`, `getBoolean()`, `parseTimeToMillis()`, `formatTime()` |
| **Messages** | `core.getMessageManager()` | `get(path, replacements...)`, `send(sender, path, replacements...)`, `getMiniMessage()` |
| **Database** | `core.getStorageManager()` | `getConnection()`, `isMySQL()` |
| **Profiles** | `core.getProfileManager()` | `getProfile(uuid)`, `getOrCreate(uuid, name)`, `save(profile)` |
| **Contexts** | `core.getContextManager()` | `addContext(uuid, ctx)`, `removeContext(uuid, ctx)`, `hasContext(uuid, ctx)`, `getContexts(uuid)` |
| **Cooldowns** | `core.getCooldownManager()` | `setCooldown(uuid, id, durationMs)`, `hasCooldown(uuid, id)`, `getRemainingFormatted(uuid, id)` |
| **Economy** | `core.getEconomyHook()` | `isEnabled()`, `getBalance(p)`, `has(p, amount)`, `withdraw(p, amount)`, `deposit(p, amount)`, `format(amount)` |
| **Visuals** | `core.getVisualManager()` | `createBossBar(id, text, color, progress)`, `sendTitle(player, title, subtitle)`, `sendActionBar(player, msg)`, `spawnLightning(loc)`, `spawnBloodEffect(loc)` |
| **Event Bus** | `core.getEventBus()` | `subscribe(type, consumer)`, `unsubscribe(type, consumer)`, `publish(event)` |

### Event Bus Usage

Subscribe to cross-plugin events:

```java
EthernovaCore.getInstance().getEventBus().subscribe(PowerChangeEvent.class, event -> {
    // React to power changes
    System.out.println(event.playerName() + ": " + event.oldPower() + " -> " + event.newPower());
});

EthernovaCore.getInstance().getEventBus().subscribe(EthernovaPlayerKillEvent.class, event -> {
    // React to kills
});

EthernovaCore.getInstance().getEventBus().subscribe(ClanWarStartEvent.class, event -> {
    // React to war start
});

EthernovaCore.getInstance().getEventBus().subscribe(ClanWarEndEvent.class, event -> {
    // React to war end
});
```

Publish custom events:

```java
EthernovaCore.getInstance().getEventBus().publish(
    new PowerChangeEvent(uuid, name, oldPower, newPower, "kill_reward")
);
```

### GUI Extension

Extend `CoreGui` to create custom plugin GUIs:

```java
public class MyCustomGui extends CoreGui {
    public MyCustomGui(EthernovaCore core, Player player) {
        super(core, player);
    }

    @Override
    protected void populateItems() {
        ItemStack item = createItem(Material.DIAMOND, "<green>My Item", List.of("<gray>Click me"));
        setItem(13, item);
        slotActions.put(13, "MY_ACTION");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if ("MY_ACTION".equals(action)) {
            playSound("click");
            // Handle action
            return true;
        }
        return false;
    }
}
```

### Context System Usage

The context system enables cross-plugin state sharing (e.g., Combat plugin checks contexts to apply different tag profiles):

```java
ContextManager ctx = EthernovaCore.getInstance().getContextManager();

// Set a player in war context
ctx.addContext(player.getUniqueId(), "war");

// Check context in another plugin
if (ctx.hasContext(player.getUniqueId(), "war")) {
    // Apply war-specific behavior
}

// Clean up
ctx.removeContext(player.getUniqueId(), "war");
```

---

## File Summary

| # | File | Package | Type | Lines |
|---|------|---------|------|-------|
| 1 | `EthernovaCore.java` | `com.ethernova.core` | Class (JavaPlugin) | 87 |
| 2 | `CoreConfigManager.java` | `com.ethernova.core.config` | Class | 58 |
| 3 | `CoreMessageManager.java` | `com.ethernova.core.message` | Class | 47 |
| 4 | `CoreStorageManager.java` | `com.ethernova.core.storage` | Class | 67 |
| 5 | `PlayerProfile.java` | `com.ethernova.core.profile` | Class | 39 |
| 6 | `PlayerProfileManager.java` | `com.ethernova.core.profile` | Class | 112 |
| 7 | `ContextManager.java` | `com.ethernova.core.context` | Class | 33 |
| 8 | `CooldownManager.java` | `com.ethernova.core.cooldown` | Class | 49 |
| 9 | `EconomyHook.java` | `com.ethernova.core.economy` | Class | 46 |
| 10 | `VisualManager.java` | `com.ethernova.core.visual` | Class | 56 |
| 11 | `EthernovaEventBus.java` | `com.ethernova.core.event` | Class | 40 |
| 12 | `PowerChangeEvent.java` | `com.ethernova.core.event` | Record | 14 |
| 13 | `EthernovaPlayerKillEvent.java` | `com.ethernova.core.event` | Record | 10 |
| 14 | `ClanWarStartEvent.java` | `com.ethernova.core.event` | Record | 14 |
| 15 | `ClanWarEndEvent.java` | `com.ethernova.core.event` | Record | 12 |
| 16 | `CoreGui.java` | `com.ethernova.core.gui` | Abstract Class | 112 |
| 17 | `CorePlayerListener.java` | `com.ethernova.core.listener` | Class (Listener) | 47 |
| 18 | `CoreCommand.java` | `com.ethernova.core.command` | Class (CommandExecutor) | 39 |

**Total**: 18 files, ~882 lines of Java code

---

*End of EthernovaCore documentation.*
