# EthernovaCosmetics

> Sistema de cosméticos visuales para el ecosistema Ethernova.

## Características

- **Trails** — Partículas que siguen al jugador
- **Kill Effects** — Efectos visuales al eliminar un enemigo
- **Death Effects** — Efectos al morir
- **Win Effects** — Celebraciones al ganar
- **Projectile Trails** — Partículas en proyectiles (flechas, enderpearls)
- **Kill Messages** — Mensajes personalizados de eliminación
- **Mystery Boxes** — Cajas con cosméticos aleatorios por rareza
- **Rarities** — Common, Rare, Epic, Legendary, Mythic
- **Previews** — Previsualización de cosméticos antes de comprar

## API

```java
CosmeticsAPI api = ServiceRegistry.get(CosmeticsAPI.class);
api.isUnlocked(uuid, "trail_flame");
api.equip(uuid, "trail_flame");
api.getEquipped(uuid, CosmeticType.TRAIL);
api.triggerKillEffect(killerUuid, victimLocation);
api.hasActiveTrail(uuid);
api.getAllCosmetics();
```

## Comandos

| Comando | Permiso | Descripción |
|---------|---------|-------------|
| `/cosmetics` | `cosmetics.use` | Abrir menú de cosméticos |
| `/cosmetics preview <id>` | `cosmetics.preview` | Previsualizar |

## Configuración

Los cosméticos se definen en `cosmetics.yml` con tipo, rareza, precio e ícono.
