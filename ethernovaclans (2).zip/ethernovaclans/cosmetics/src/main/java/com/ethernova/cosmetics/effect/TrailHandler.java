package com.ethernova.cosmetics.effect;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.cosmetics.model.CosmeticType;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Handles particle trails behind players who have a trail cosmetic equipped.
 * Runs on a repeating scheduler task, spawning particles at player locations.
 */
public class TrailHandler {

    private final EthernovaCosmetics plugin;
    private final Map<UUID, String> activeTrails = new ConcurrentHashMap<>();
    private BukkitTask trailTask;
    private int rainbowTick = 0;

    public TrailHandler(EthernovaCosmetics plugin) {
        this.plugin = plugin;
    }

    /**
     * Start the trail particle scheduler.
     */
    public void start() {
        int interval = plugin.getConfigManager().getInt("trail.update-interval", 4);
        trailTask = Bukkit.getScheduler().runTaskTimer(plugin, this::tickTrails, 10L, interval);
    }

    /**
     * Stop the trail scheduler and clear active trails.
     */
    public void stop() {
        if (trailTask != null) {
            trailTask.cancel();
            trailTask = null;
        }
        activeTrails.clear();
    }

    /**
     * Register a player's trail when they join or equip one.
     */
    public void registerTrail(UUID uuid) {
        if (uuid == null) return;
        String trailId = plugin.getPlayerCosmeticManager().getEquipped(uuid, CosmeticType.TRAIL);
        if (trailId != null) {
            activeTrails.put(uuid, trailId);
        }
    }

    /**
     * Remove a player's trail when they leave or unequip.
     */
    public void removeTrail(UUID uuid) {
        if (uuid == null) return;
        activeTrails.remove(uuid);
    }

    /**
     * Refresh a player's trail (called when equipped cosmetic changes).
     */
    public void refreshTrail(UUID uuid) {
        if (uuid == null) return;
        String trailId = plugin.getPlayerCosmeticManager().getEquipped(uuid, CosmeticType.TRAIL);
        if (trailId != null) {
            activeTrails.put(uuid, trailId);
        } else {
            activeTrails.remove(uuid);
        }
    }

    /**
     * Tick all active trails — spawns particles for each online player with a trail.
     */
    private void tickTrails() {
        rainbowTick++;
        double maxDist = plugin.getConfigManager().getDouble("trail.max-distance", 50.0);

        for (Map.Entry<UUID, String> entry : activeTrails.entrySet()) {
            Player player = Bukkit.getPlayer(entry.getKey());
            if (player == null || !player.isOnline()) {
                activeTrails.remove(entry.getKey());
                continue;
            }

            // Don't spawn trails for sneaking, gliding (elytra), or stationary players
            if (player.isSneaking() || player.isGliding()) continue;
            if (player.getVelocity().lengthSquared() < 0.001) continue;

            Location loc = player.getLocation().add(0, 0.1, 0);
            if (loc.getWorld() == null) continue;

            // Only show to nearby players
            spawnTrailParticles(entry.getValue(), loc);
        }
    }

    /**
     * Spawn trail particles at the given location based on the trail ID.
     */
    private void spawnTrailParticles(String trailId, Location loc) {
        if (loc.getWorld() == null) return;

        switch (trailId.toLowerCase()) {
            case "trail_flame" -> {
                loc.getWorld().spawnParticle(Particle.FLAME, loc, 3, 0.1, 0.05, 0.1, 0.01);
            }
            case "trail_heart" -> {
                loc.getWorld().spawnParticle(Particle.HEART, loc.clone().add(0, 0.5, 0), 1, 0.2, 0.2, 0.2, 0);
            }
            case "trail_note" -> {
                loc.getWorld().spawnParticle(Particle.NOTE, loc.clone().add(0, 0.5, 0), 2, 0.3, 0.2, 0.3, 1);
            }
            case "trail_enchant" -> {
                loc.getWorld().spawnParticle(Particle.ENCHANT, loc.clone().add(0, 0.3, 0), 8, 0.3, 0.3, 0.3, 0.5);
            }
            case "trail_smoke" -> {
                loc.getWorld().spawnParticle(Particle.CAMPFIRE_COSY_SMOKE, loc, 2, 0.1, 0.05, 0.1, 0.01);
            }
            case "trail_drip" -> {
                loc.getWorld().spawnParticle(Particle.DRIPPING_HONEY, loc.clone().add(0, 1.5, 0), 3, 0.2, 0.1, 0.2, 0);
                loc.getWorld().spawnParticle(Particle.FALLING_HONEY, loc.clone().add(0, 1.0, 0), 2, 0.1, 0.1, 0.1, 0);
            }
            case "trail_rainbow" -> {
                playRainbow(loc);
            }
            case "trail_redstone" -> {
                Particle.DustOptions dust = new Particle.DustOptions(Color.RED, 1.0f);
                loc.getWorld().spawnParticle(Particle.DUST, loc, 5, 0.15, 0.1, 0.15, 0, dust);
            }
            case "trail_nether" -> {
                loc.getWorld().spawnParticle(Particle.LANDING_LAVA, loc, 3, 0.15, 0.05, 0.15, 0);
                loc.getWorld().spawnParticle(Particle.SMALL_FLAME, loc.clone().add(0, 0.3, 0), 2, 0.1, 0.1, 0.1, 0.01);
                Particle.DustOptions ashDust = new Particle.DustOptions(Color.fromRGB(80, 20, 10), 0.7f);
                loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 0.5, 0), 2, 0.2, 0.2, 0.2, 0, ashDust);
            }
            case "trail_cherry" -> {
                loc.getWorld().spawnParticle(Particle.CHERRY_LEAVES, loc.clone().add(0, 0.5, 0), 4, 0.3, 0.3, 0.3, 0.01);
                Particle.DustOptions pinkDust = new Particle.DustOptions(Color.fromRGB(255, 183, 197), 0.8f);
                loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 0.8, 0), 2, 0.15, 0.1, 0.15, 0, pinkDust);
            }
            case "trail_void" -> {
                loc.getWorld().spawnParticle(Particle.REVERSE_PORTAL, loc.clone().add(0, 0.3, 0), 6, 0.15, 0.1, 0.15, 0.05);
                Particle.DustOptions voidDust = new Particle.DustOptions(Color.fromRGB(20, 0, 30), 1.0f);
                loc.getWorld().spawnParticle(Particle.DUST, loc, 3, 0.1, 0.05, 0.1, 0, voidDust);
                loc.getWorld().spawnParticle(Particle.PORTAL, loc.clone().add(0, 0.5, 0), 2, 0.1, 0.1, 0.1, 0.1);
            }
            // ────── Trails from original ProjectileTrail enum ──────
            case "trail_water" -> {
                loc.getWorld().spawnParticle(Particle.DRIPPING_WATER, loc.clone().add(0, 0.8, 0), 4, 0.2, 0.1, 0.2, 0);
                loc.getWorld().spawnParticle(Particle.SPLASH, loc, 3, 0.15, 0.05, 0.15, 0.01);
            }
            case "trail_slime" -> {
                loc.getWorld().spawnParticle(Particle.ITEM_SLIME, loc.clone().add(0, 0.2, 0), 5, 0.15, 0.05, 0.15, 0);
            }
            case "trail_lava" -> {
                loc.getWorld().spawnParticle(Particle.LAVA, loc, 2, 0.1, 0.05, 0.1, 0);
                loc.getWorld().spawnParticle(Particle.LANDING_LAVA, loc, 3, 0.15, 0.05, 0.15, 0);
            }
            case "trail_snow" -> {
                loc.getWorld().spawnParticle(Particle.SNOWFLAKE, loc.clone().add(0, 0.3, 0), 4, 0.2, 0.2, 0.2, 0.01);
            }
            case "trail_ash" -> {
                loc.getWorld().spawnParticle(Particle.WHITE_ASH, loc.clone().add(0, 0.5, 0), 6, 0.3, 0.3, 0.3, 0);
                Particle.DustOptions ashDust = new Particle.DustOptions(Color.fromRGB(80, 80, 80), 0.7f);
                loc.getWorld().spawnParticle(Particle.DUST, loc, 2, 0.15, 0.1, 0.15, 0, ashDust);
            }
            case "trail_spark" -> {
                loc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc.clone().add(0, 0.3, 0), 4, 0.15, 0.1, 0.15, 0.05);
            }
            case "trail_cloud" -> {
                loc.getWorld().spawnParticle(Particle.CLOUD, loc.clone().add(0, 0.3, 0), 3, 0.2, 0.1, 0.2, 0.01);
            }
            case "trail_crit" -> {
                loc.getWorld().spawnParticle(Particle.CRIT, loc.clone().add(0, 0.5, 0), 5, 0.2, 0.2, 0.2, 0.1);
            }
            case "trail_glow" -> {
                loc.getWorld().spawnParticle(Particle.GLOW, loc.clone().add(0, 0.5, 0), 3, 0.2, 0.2, 0.2, 0);
                Particle.DustOptions glowDust = new Particle.DustOptions(Color.fromRGB(0, 255, 200), 0.8f);
                loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 0.3, 0), 2, 0.1, 0.1, 0.1, 0, glowDust);
            }
            case "trail_ink" -> {
                loc.getWorld().spawnParticle(Particle.SQUID_INK, loc.clone().add(0, 0.2, 0), 3, 0.1, 0.05, 0.1, 0.01);
            }
            case "trail_love" -> {
                loc.getWorld().spawnParticle(Particle.HEART, loc.clone().add(0, 0.5, 0), 2, 0.3, 0.2, 0.3, 0);
            }
            case "trail_magic" -> {
                loc.getWorld().spawnParticle(Particle.ENCHANT, loc.clone().add(0, 0.5, 0), 8, 0.3, 0.3, 0.3, 0.5);
                loc.getWorld().spawnParticle(Particle.WITCH, loc.clone().add(0, 0.3, 0), 3, 0.1, 0.1, 0.1, 0);
            }
            case "trail_totem" -> {
                loc.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, loc.clone().add(0, 0.5, 0), 5, 0.2, 0.2, 0.2, 0.1);
            }
            case "trail_witch" -> {
                loc.getWorld().spawnParticle(Particle.WITCH, loc.clone().add(0, 0.5, 0), 5, 0.2, 0.2, 0.2, 0);
            }
            case "trail_soul" -> {
                loc.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, loc.clone().add(0, 0.2, 0), 4, 0.15, 0.1, 0.15, 0.01);
                loc.getWorld().spawnParticle(Particle.SOUL, loc.clone().add(0, 0.5, 0), 2, 0.1, 0.1, 0.1, 0.01);
            }
            case "trail_heartbreak" -> {
                Particle.DustOptions hbDust = new Particle.DustOptions(Color.fromRGB(50, 0, 0), 1.2f);
                loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 0.5, 0), 4, 0.2, 0.2, 0.2, 0, hbDust);
                loc.getWorld().spawnParticle(Particle.DAMAGE_INDICATOR, loc.clone().add(0, 0.3, 0), 2, 0.1, 0.1, 0.1, 0.01);
            }
            case "trail_end" -> {
                loc.getWorld().spawnParticle(Particle.END_ROD, loc.clone().add(0, 0.5, 0), 4, 0.2, 0.2, 0.2, 0.02);
            }
            case "trail_arctic" -> {
                loc.getWorld().spawnParticle(Particle.SNOWFLAKE, loc.clone().add(0, 0.3, 0), 3, 0.2, 0.2, 0.2, 0.01);
                Particle.DustOptions iceDust = new Particle.DustOptions(Color.fromRGB(180, 220, 255), 1.0f);
                loc.getWorld().spawnParticle(Particle.DUST, loc, 3, 0.15, 0.1, 0.15, 0, iceDust);
            }
            case "trail_gold" -> {
                Particle.DustOptions goldDust = new Particle.DustOptions(Color.fromRGB(255, 215, 0), 1.0f);
                loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 0.3, 0), 5, 0.15, 0.1, 0.15, 0, goldDust);
            }
            case "trail_emerald" -> {
                Particle.DustOptions emeraldDust = new Particle.DustOptions(Color.fromRGB(0, 200, 80), 1.0f);
                loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 0.3, 0), 5, 0.15, 0.1, 0.15, 0, emeraldDust);
            }
            default -> {
                // Unknown trail — no particles
            }
        }
    }

    /**
     * Rainbow trail: cycles through colors using the rainbow tick counter.
     */
    private void playRainbow(Location loc) {
        if (loc.getWorld() == null) return;

        // Cycle through hue values (manual HSB→RGB, avoids java.awt on headless servers)
        float hue = (rainbowTick % 360) / 360.0f;
        int rgb = hsbToRgb(hue, 1.0f, 1.0f);
        Color color = Color.fromRGB((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF);

        Particle.DustOptions dust = new Particle.DustOptions(color, 1.2f);
        loc.getWorld().spawnParticle(Particle.DUST, loc, 5, 0.15, 0.1, 0.15, 0, dust);

        // Secondary slightly offset color for richness
        float hue2 = ((rainbowTick + 30) % 360) / 360.0f;
        int rgb2 = hsbToRgb(hue2, 1.0f, 1.0f);
        Color color2 = Color.fromRGB((rgb2 >> 16) & 0xFF, (rgb2 >> 8) & 0xFF, rgb2 & 0xFF);
        Particle.DustOptions dust2 = new Particle.DustOptions(color2, 0.8f);
        loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 0.3, 0), 3, 0.1, 0.1, 0.1, 0, dust2);
    }

    /** Manual HSB→RGB conversion — avoids java.awt dependency on headless servers. */
    private static int hsbToRgb(float hue, float saturation, float brightness) {
        int r = 0, g = 0, b = 0;
        if (saturation == 0) {
            r = g = b = (int) (brightness * 255.0f + 0.5f);
        } else {
            float h = (hue - (float) Math.floor(hue)) * 6.0f;
            float f = h - (float) Math.floor(h);
            float p = brightness * (1.0f - saturation);
            float q = brightness * (1.0f - saturation * f);
            float t = brightness * (1.0f - (saturation * (1.0f - f)));
            switch ((int) h) {
                case 0 -> { r = (int)(brightness*255+0.5f); g = (int)(t*255+0.5f); b = (int)(p*255+0.5f); }
                case 1 -> { r = (int)(q*255+0.5f); g = (int)(brightness*255+0.5f); b = (int)(p*255+0.5f); }
                case 2 -> { r = (int)(p*255+0.5f); g = (int)(brightness*255+0.5f); b = (int)(t*255+0.5f); }
                case 3 -> { r = (int)(p*255+0.5f); g = (int)(q*255+0.5f); b = (int)(brightness*255+0.5f); }
                case 4 -> { r = (int)(t*255+0.5f); g = (int)(p*255+0.5f); b = (int)(brightness*255+0.5f); }
                case 5 -> { r = (int)(brightness*255+0.5f); g = (int)(p*255+0.5f); b = (int)(q*255+0.5f); }
            }
        }
        return (r << 16) | (g << 8) | b;
    }

    /**
     * Preview a trail for a player at their current location.
     */
    public void preview(Player player, String trailId) {
        if (player == null || trailId == null) return;
        Location loc = player.getLocation().add(0, 0.1, 0);

        // Show multiple ticks of trail in a burst
        for (int i = 0; i < 5; i++) {
            final int tick = i;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (player.isOnline()) {
                    Location previewLoc = player.getLocation().add(0, 0.1 + (tick * 0.2), 0);
                    spawnTrailParticles(trailId, previewLoc);
                }
            }, i * 4L);
        }
    }

    /**
     * Check if a player currently has an active trail.
     */
    public boolean hasActiveTrail(UUID uuid) {
        return activeTrails.containsKey(uuid);
    }
}
