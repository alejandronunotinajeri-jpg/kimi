package com.ethernova.cosmetics.effect;

import com.ethernova.cosmetics.EthernovaCosmetics;
import org.bukkit.*;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * FinisherHandler — 8 finisher kill animations matching original UltimateFFA.
 * Types: execution, lightning, implosion, explosion, ascension, disintegrate, freeze, inferno
 */
public class FinisherHandler {

    private final EthernovaCosmetics plugin;
    private final Map<UUID, Long> cooldowns = new ConcurrentHashMap<>();
    private static final int COOLDOWN_MS = 5000;

    public FinisherHandler(EthernovaCosmetics plugin) {
        this.plugin = plugin;
    }

    /**
     * Trigger the finisher animation on kill
     */
    public void triggerFinisher(Player killer, Player victim, String finisherId) {
        if (finisherId == null || finisherId.isEmpty()) return;

        UUID uid = killer.getUniqueId();
        long now = System.currentTimeMillis();
        Long last = cooldowns.get(uid);
        if (last != null && (now - last) < COOLDOWN_MS) return;
        cooldowns.put(uid, now);

        Location loc = victim.getLocation().clone();
        playFinisherAnimation(loc, finisherId, victim);

        // Broadcast local
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (online.getWorld().equals(loc.getWorld()) &&
                    online.getLocation().distance(loc) <= 30) {
                online.sendMessage("§6§l⚡ §e" + killer.getName() + " §7ejecutó finisher: §c" + finisherId.toUpperCase());
            }
        }
    }

    /**
     * Preview a finisher — spawns a zombie test dummy 2 blocks in front,
     * plays the finisher animation on it after 1 second, removes dummy after animation ends.
     */
    public void previewFinisher(Player player, String finisherId) {
        Location playerLoc = player.getLocation();
        Location spawnLoc = playerLoc.clone().add(playerLoc.getDirection().multiply(2));
        spawnLoc.setY(playerLoc.getY());

        Zombie dummy = (Zombie) player.getWorld().spawnEntity(spawnLoc, EntityType.ZOMBIE);
        dummy.setAI(false);
        dummy.setSilent(true);
        dummy.setInvulnerable(true);
        dummy.customName(net.kyori.adventure.text.Component.text("§c§lTest Dummy"));
        dummy.setCustomNameVisible(true);
        dummy.getEquipment().setHelmet(new ItemStack(Material.DIAMOND_HELMET));

        int animDuration = getAnimationDuration(finisherId);

        // After 1 second, play the finisher animation
        new BukkitRunnable() {
            @Override
            public void run() {
                if (dummy.isValid()) {
                    playFinisherAnimation(dummy.getLocation().clone(), finisherId, null);
                }
            }
        }.runTaskLater(plugin, 20L);

        // Remove dummy after animation finishes (1s delay + animation duration + small buffer)
        new BukkitRunnable() {
            @Override
            public void run() {
                if (dummy.isValid()) {
                    dummy.remove();
                }
            }
        }.runTaskLater(plugin, 20L + animDuration + 5L);
    }

    /** Returns the tick duration of the finisher animation. */
    private int getAnimationDuration(String finisherId) {
        String effectName = finisherId.toLowerCase().startsWith("finisher_")
                ? finisherId.substring(9).toLowerCase()
                : finisherId.toLowerCase();

        return switch (effectName) {
            case "execution"               -> 40;
            case "lightning", "lightning_slam" -> 20;
            case "implosion"               -> 60;
            case "explosion"               -> 5;
            case "ascension", "ascend"     -> 60;
            case "disintegrate"            -> 50;
            case "freeze"                  -> 60;
            case "inferno"                 -> 60;
            case "tornado"                 -> 60;
            case "void_consume"            -> 60;
            default                        -> 60;
        };
    }

    private void playFinisherAnimation(Location loc, String finisherId, Player target) {
        // Strip "finisher_" prefix — cosmetics.yml uses IDs like finisher_execution
        String effectName = finisherId.toLowerCase().startsWith("finisher_")
                ? finisherId.substring(9).toLowerCase()
                : finisherId.toLowerCase();

        switch (effectName) {
            case "execution" -> animateExecution(loc);
            case "lightning", "lightning_slam" -> animateLightning(loc);
            case "implosion" -> animateImplosion(loc);
            case "explosion" -> animateExplosion(loc);
            case "ascension", "ascend" -> animateAscension(loc);
            case "disintegrate" -> animateDisintegrate(loc);
            case "freeze" -> animateFreeze(loc);
            case "inferno" -> animateInferno(loc);
            case "tornado" -> animateTornado(loc);
            case "void_consume" -> animateVoidConsume(loc);
            default -> plugin.getLogger().warning("Unknown finisher: " + finisherId + " (parsed: " + effectName + ")");
        }
    }

    // ═══════════════════════════════════════════════════════════
    //   EXECUTION — Espada gigante descendente + impacto
    // ═══════════════════════════════════════════════════════════
    private void animateExecution(Location loc) {
        new BukkitRunnable() {
            int tick = 0;
            @Override
            public void run() {
                if (tick >= 40) { cancel(); return; }

                double height = 5 - (tick * 0.125);
                Location swordLoc = loc.clone().add(0, height, 0);

                loc.getWorld().spawnParticle(Particle.CRIT, swordLoc, 3, 0.1, 0.1, 0.1, 0);
                loc.getWorld().spawnParticle(Particle.SWEEP_ATTACK, swordLoc, 1, 0, 0, 0, 0);

                if (tick == 35) {
                    loc.getWorld().spawnParticle(Particle.EXPLOSION, loc, 1, 0, 0, 0, 0);
                    loc.getWorld().spawnParticle(Particle.CRIT, loc, 30, 0.5, 0.5, 0.5, 0.3);
                    loc.getWorld().playSound(loc, Sound.ENTITY_IRON_GOLEM_DEATH, 1.0f, 0.5f);
                }
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ═══════════════════════════════════════════════════════════
    //   LIGHTNING — Rayo visual + explosión
    // ═══════════════════════════════════════════════════════════
    private void animateLightning(Location loc) {
        loc.getWorld().spawnParticle(Particle.END_ROD, loc.clone().add(0, 20, 0), 100, 0, -10, 0, 0.5);
        loc.getWorld().spawnParticle(Particle.FIREWORK, loc, 50, 1, 1, 1, 0.3);
        loc.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.5f, 1.0f);
        loc.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 2.0f);

        new BukkitRunnable() {
            int tick = 0;
            @Override
            public void run() {
                if (tick >= 20) { cancel(); return; }
                for (double y = 0; y < 20; y += 0.5) {
                    Location rayLoc = loc.clone().add(0, y, 0);
                    loc.getWorld().spawnParticle(Particle.END_ROD, rayLoc, 1, 0.1, 0, 0.1, 0);
                }
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ═══════════════════════════════════════════════════════════
    //   IMPLOSION — Espiral → contracción → explosión
    // ═══════════════════════════════════════════════════════════
    private void animateImplosion(Location loc) {
        new BukkitRunnable() {
            int tick = 0;
            @Override
            public void run() {
                if (tick >= 60) { cancel(); return; }

                if (tick < 20) {
                    double radius = tick * 0.15;
                    for (int i = 0; i < 20; i++) {
                        double angle = 2 * Math.PI * i / 20;
                        double x = Math.cos(angle) * radius;
                        double z = Math.sin(angle) * radius;
                        loc.getWorld().spawnParticle(Particle.PORTAL, loc.clone().add(x, 1, z), 1, 0, 0, 0, 0);
                    }
                } else if (tick < 40) {
                    double radius = 3 - ((tick - 20) * 0.15);
                    for (int i = 0; i < 30; i++) {
                        double angle = 2 * Math.PI * i / 30;
                        double x = Math.cos(angle) * radius;
                        double z = Math.sin(angle) * radius;
                        loc.getWorld().spawnParticle(Particle.PORTAL, loc.clone().add(x, 1, z), 2, -x * 0.1, 0, -z * 0.1, 0.3);
                    }
                } else if (tick == 40) {
                    loc.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, loc, 3, 0, 0, 0, 0);
                    loc.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 2.0f, 0.5f);
                }
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ═══════════════════════════════════════════════════════════
    //   EXPLOSION — Explosión masiva instantánea
    // ═══════════════════════════════════════════════════════════
    private void animateExplosion(Location loc) {
        loc.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, loc, 5, 0, 0, 0, 0);
        loc.getWorld().spawnParticle(Particle.FLAME, loc, 100, 2, 2, 2, 0.3);
        loc.getWorld().spawnParticle(Particle.LAVA, loc, 50, 1.5, 1.5, 1.5, 0.1);
        loc.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 2.0f, 0.8f);
        loc.getWorld().playSound(loc, Sound.ENTITY_DRAGON_FIREBALL_EXPLODE, 1.5f, 1.0f);
    }

    // ═══════════════════════════════════════════════════════════
    //   ASCENSION — Alma ascendiendo con alas angelicales
    // ═══════════════════════════════════════════════════════════
    private void animateAscension(Location loc) {
        new BukkitRunnable() {
            int tick = 0;
            @Override
            public void run() {
                if (tick >= 60) { cancel(); return; }

                double height = tick * 0.05;
                Location ascendLoc = loc.clone().add(0, height, 0);

                loc.getWorld().spawnParticle(Particle.FIREWORK, ascendLoc, 5, 0.3, 0.3, 0.3, 0.05);
                loc.getWorld().spawnParticle(Particle.END_ROD, ascendLoc, 2, 0.2, 0.2, 0.2, 0.02);

                if (tick % 5 == 0) {
                    double wingSpan = 1.5;
                    loc.getWorld().spawnParticle(Particle.CLOUD, ascendLoc.clone().add(wingSpan, 0, 0), 3, 0.1, 0.2, 0.1, 0);
                    loc.getWorld().spawnParticle(Particle.CLOUD, ascendLoc.clone().add(-wingSpan, 0, 0), 3, 0.1, 0.2, 0.1, 0);
                }

                if (tick % 20 == 0) {
                    loc.getWorld().playSound(ascendLoc, Sound.BLOCK_BELL_USE, 0.5f, 2.0f);
                }
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ═══════════════════════════════════════════════════════════
    //   DISINTEGRATE — Desintegración progresiva en polvo
    // ═══════════════════════════════════════════════════════════
    private void animateDisintegrate(Location loc) {
        new BukkitRunnable() {
            int tick = 0;
            @Override
            public void run() {
                if (tick >= 50) { cancel(); return; }

                double intensity = tick / 10.0;
                loc.getWorld().spawnParticle(Particle.DRAGON_BREATH, loc.clone().add(0, 1, 0),
                        (int) (5 * intensity), 0.5, 0.5, 0.5, 0.05);
                loc.getWorld().spawnParticle(Particle.WITCH, loc.clone().add(0, 1, 0),
                        (int) (3 * intensity), 0.4, 0.4, 0.4, 0.1);

                if (tick % 10 == 0) {
                    loc.getWorld().playSound(loc, Sound.ENTITY_PHANTOM_DEATH, 0.7f, 1.5f);
                }

                if (tick == 45) {
                    loc.getWorld().spawnParticle(Particle.CLOUD, loc, 50, 1, 1, 1, 0.2);
                    loc.getWorld().playSound(loc, Sound.BLOCK_GLASS_BREAK, 1.0f, 0.5f);
                }
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ═══════════════════════════════════════════════════════════
    //   FREEZE — Congelamiento progresivo y ruptura de hielo
    // ═══════════════════════════════════════════════════════════
    private void animateFreeze(Location loc) {
        new BukkitRunnable() {
            int tick = 0;
            @Override
            public void run() {
                if (tick >= 60) { cancel(); return; }

                if (tick < 20) {
                    double height = tick * 0.1;
                    for (double y = 0; y <= height; y += 0.3) {
                        loc.getWorld().spawnParticle(Particle.SNOWFLAKE, loc.clone().add(0, y, 0), 5, 0.3, 0.1, 0.3, 0);
                    }
                } else if (tick < 50) {
                    loc.getWorld().spawnParticle(Particle.SNOWFLAKE, loc.clone().add(0, 1, 0), 10, 0.4, 0.8, 0.4, 0);
                    if (tick % 10 == 0) {
                        loc.getWorld().playSound(loc, Sound.BLOCK_GLASS_PLACE, 1.0f, 1.5f);
                    }
                } else {
                    loc.getWorld().spawnParticle(Particle.ITEM_SNOWBALL, loc.clone().add(0, 1, 0), 50, 0.5, 0.5, 0.5, 0.1);
                    if (tick == 50) {
                        loc.getWorld().playSound(loc, Sound.BLOCK_GLASS_BREAK, 1.5f, 1.0f);
                    }
                }
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ═══════════════════════════════════════════════════════════
    //   INFERNO — Columna de fuego con espiral
    // ═══════════════════════════════════════════════════════════
    private void animateInferno(Location loc) {
        new BukkitRunnable() {
            int tick = 0;
            @Override
            public void run() {
                if (tick >= 60) { cancel(); return; }

                double height = Math.min(tick * 0.15, 5);
                for (double y = 0; y <= height; y += 0.2) {
                    Location fireLoc = loc.clone().add(0, y, 0);
                    loc.getWorld().spawnParticle(Particle.FLAME, fireLoc, 3, 0.2, 0.1, 0.2, 0.02);
                    loc.getWorld().spawnParticle(Particle.LAVA, fireLoc, 1, 0.1, 0.1, 0.1, 0);
                }

                double angle = tick * 0.3;
                double radius = 1.5;
                double x = Math.cos(angle) * radius;
                double z = Math.sin(angle) * radius;
                loc.getWorld().spawnParticle(Particle.FLAME, loc.clone().add(x, height * 0.5, z), 2, 0, 0, 0, 0.05);

                if (tick % 15 == 0) {
                    loc.getWorld().playSound(loc, Sound.ENTITY_BLAZE_SHOOT, 1.0f, 0.8f);
                }
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ═══════════════════════════════════════════════════════════
    //   TORNADO — Espiral de viento ascendente
    // ═══════════════════════════════════════════════════════════
    private void animateTornado(Location loc) {
        new BukkitRunnable() {
            int tick = 0;
            @Override
            public void run() {
                if (tick >= 60) { cancel(); return; }

                double radius = 0.5 + (tick % 20) * 0.15;
                double height = tick * 0.12;
                for (int i = 0; i < 16; i++) {
                    double angle = (Math.PI * 2 * i) / 16 + (tick * 0.4);
                    double x = Math.cos(angle) * radius;
                    double z = Math.sin(angle) * radius;
                    loc.getWorld().spawnParticle(Particle.CLOUD, loc.clone().add(x, height % 6, z), 1, 0.05, 0.05, 0.05, 0);
                }

                if (tick < 40) {
                    loc.getWorld().spawnParticle(Particle.SWEEP_ATTACK, loc.clone().add(0, height % 4, 0), 1, 0.5, 0.3, 0.5, 0);
                }

                if (tick % 10 == 0) {
                    loc.getWorld().playSound(loc, Sound.ENTITY_PHANTOM_FLAP, 1.0f, 0.5f);
                }
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ═══════════════════════════════════════════════════════════
    //   VOID CONSUME — Portal oscuro que consume a la víctima
    // ═══════════════════════════════════════════════════════════
    private void animateVoidConsume(Location loc) {
        new BukkitRunnable() {
            int tick = 0;
            @Override
            public void run() {
                if (tick >= 60) { cancel(); return; }

                if (tick < 20) {
                    // Phase 1: Opening void portal
                    double radius = tick * 0.15;
                    for (int i = 0; i < 20; i++) {
                        double angle = (Math.PI * 2 * i) / 20;
                        double x = Math.cos(angle) * radius;
                        double z = Math.sin(angle) * radius;
                        loc.getWorld().spawnParticle(Particle.PORTAL, loc.clone().add(x, 0.1, z), 2, 0, 0, 0, 0.1);
                    }
                    Particle.DustOptions voidDust = new Particle.DustOptions(Color.fromRGB(20, 0, 30), 2.0f);
                    loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 0.5, 0), 10, 0.5, 0.3, 0.5, 0, voidDust);
                } else if (tick < 45) {
                    // Phase 2: Pulling inward
                    double radius = 3.0 - ((tick - 20) * 0.12);
                    for (int i = 0; i < 24; i++) {
                        double angle = (Math.PI * 2 * i) / 24 + (tick * 0.2);
                        double x = Math.cos(angle) * radius;
                        double z = Math.sin(angle) * radius;
                        double height = 2.0 - ((tick - 20) * 0.06);
                        loc.getWorld().spawnParticle(Particle.REVERSE_PORTAL, loc.clone().add(x, height, z), 2, -x * 0.05, -0.1, -z * 0.05, 0.3);
                    }
                    Particle.DustOptions darkDust = new Particle.DustOptions(Color.fromRGB(10 + tick, 0, 20 + tick), 1.5f);
                    loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 1, 0), 8, 0.3, 0.5, 0.3, 0, darkDust);
                } else if (tick == 45) {
                    // Phase 3: Collapse
                    loc.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, loc.clone().add(0, 0.5, 0), 2, 0, 0, 0, 0);
                    loc.getWorld().spawnParticle(Particle.REVERSE_PORTAL, loc.clone().add(0, 1, 0), 80, 0.3, 0.3, 0.3, 0.5);
                    loc.getWorld().playSound(loc, Sound.ENTITY_WARDEN_SONIC_BOOM, 0.8f, 0.3f);
                    loc.getWorld().playSound(loc, Sound.ENTITY_ENDERMAN_TELEPORT, 1.5f, 0.3f);
                }

                if (tick % 8 == 0 && tick < 45) {
                    loc.getWorld().playSound(loc, Sound.BLOCK_PORTAL_AMBIENT, 0.5f, 0.5f);
                }
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    /**
     * Remove cooldown entry for a player on quit.
     */
    public void cleanupPlayer(UUID uuid) {
        cooldowns.remove(uuid);
    }
}
