package com.ethernova.cosmetics.listener;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.cosmetics.model.Cosmetic;
import com.ethernova.cosmetics.model.CosmeticType;
import com.ethernova.core.event.EthernovaPlayerKillEvent;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;
import java.util.function.Consumer;

/**
 * Central event listener for cosmetics. Handles:
 * - Loading/saving player cosmetics on join/quit
 * - Registering/removing trails
 * - Triggering kill effects via EventBus subscription
 * - Triggering death effects
 * - Broadcasting custom kill messages
 */
public class CosmeticListener implements Listener {

    private final EthernovaCosmetics plugin;
    private final MiniMessage mini = MiniMessage.miniMessage();
    private final Consumer<EthernovaPlayerKillEvent> killEventConsumer;

    public CosmeticListener(EthernovaCosmetics plugin) {
        this.plugin = plugin;

        // Subscribe to the EventBus for kill events
        this.killEventConsumer = this::onKillEvent;
        plugin.getCore().getEventBus().subscribe(EthernovaPlayerKillEvent.class, killEventConsumer);
    }

    /**
     * Unsubscribe from the EventBus (call on plugin disable).
     */
    public void unsubscribe() {
        plugin.getCore().getEventBus().unsubscribe(EthernovaPlayerKillEvent.class, killEventConsumer);
    }

    /**
     * Load player cosmetics and register trails on join.
     */
    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();

        // Load cosmetics asynchronously, then register trail on main thread
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            plugin.getPlayerCosmeticManager().loadPlayer(uuid);

            // Register trail + join message on main thread after loading
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (player.isOnline()) {
                    plugin.getTrailHandler().registerTrail(uuid);

                    // Load aura data
                    plugin.getAdvancedAurasManager().loadPlayerData(uuid);

                    // Custom join message
                    String joinMsgId = plugin.getPlayerCosmeticManager().getEquipped(uuid, CosmeticType.JOIN_MESSAGE);
                    if (joinMsgId != null) {
                        String joinMsg = formatJoinMessage(joinMsgId, player.getName());
                        if (joinMsg != null) {
                            Bukkit.broadcast(mini.deserialize(joinMsg));
                        }
                    }
                }
            });
        });
    }

    /**
     * Save player cosmetics and remove trails on quit.
     */
    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerQuit(PlayerQuitEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();

        // Remove trail immediately
        plugin.getTrailHandler().removeTrail(uuid);

        // Remove pet entity from world
        plugin.getPetManager().removePet(uuid);

        // Cleanup aura data
        plugin.getAdvancedAurasManager().cleanupPlayer(uuid);

        // Cleanup title data
        plugin.getTitleManager().cleanupPlayer(uuid);

        // Cleanup armor trim cache
        plugin.getArmorTrimManager().unloadPlayer(uuid);

        // Cleanup finisher cooldown
        plugin.getFinisherHandler().cleanupPlayer(uuid);

        // Cleanup cosmetic cache
        if (plugin.getCosmeticCache() != null) {
            plugin.getCosmeticCache().invalidateAll(uuid);
        }

        // Save and unload asynchronously
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () ->
                plugin.getPlayerCosmeticManager().saveAndUnloadPlayer(uuid));
    }

    /**
     * Handle death events for death effect cosmetics.
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        UUID victimUuid = victim.getUniqueId();
        Location deathLoc = victim.getLocation();

        // Check for death effect on the victim
        String deathEffectId = plugin.getPlayerCosmeticManager().getEquipped(victimUuid, CosmeticType.DEATH_EFFECT);
        if (deathEffectId != null) {
            Cosmetic cosmetic = plugin.getCosmeticRegistry().getById(deathEffectId);
            if (cosmetic != null) {
                Bukkit.getScheduler().runTask(plugin, () -> playDeathEffect(deathEffectId, deathLoc));
            }
        }
    }

    /**
     * Handle hit effects — trigger on-hit particle when attacker has one equipped.
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (!(event.getEntity() instanceof Player victim)) return;
        if (plugin.getHitEffectsManager() == null) return;
        plugin.getHitEffectsManager().triggerHitEffect(attacker.getUniqueId(), victim);

        // Aura reactive bursts
        plugin.getAdvancedAurasManager().triggerAttackBurst(attacker);
        plugin.getAdvancedAurasManager().triggerDamageBurst(victim);
    }

    /**
     * Handle kill events from the EventBus.
     * Triggers kill effects and custom kill messages.
     */
    private void onKillEvent(EthernovaPlayerKillEvent event) {
        // EventBus may fire on any thread — ensure Bukkit API access on main thread
        Bukkit.getScheduler().runTask(plugin, () -> {
            UUID killerUuid = event.killerUuid();
            UUID victimUuid = event.victimUuid();

            // Use the location captured at death time (from the event), not fetched from live player
            Location victimLoc = event.victimLocation();

            // Trigger kill effect
            if (victimLoc != null) {
                plugin.getKillEffectHandler().triggerKillEffect(killerUuid, victimLoc);
            }

            // Fetch player objects for finisher/aura/sound (may be null if offline)
            Player killer = Bukkit.getPlayer(killerUuid);
            Player victim = Bukkit.getPlayer(victimUuid);

            // Aura reactive: register kill streak + kill effect
            if (killer != null && victim != null) {
                plugin.getAdvancedAurasManager().registerKill(killer);
                plugin.getAdvancedAurasManager().triggerKillEffect(killer, victim);
            }
            if (victim != null) {
                plugin.getAdvancedAurasManager().resetStreak(victim);
            }

            if (killer != null && victim != null) {
                String finisherId = plugin.getPlayerCosmeticManager().getEquipped(killerUuid, CosmeticType.FINISHER);
                if (finisherId != null) {
                    plugin.getFinisherHandler().triggerFinisher(killer, victim, finisherId);
                }
            }

            // Trigger death sound
            if (victim != null) {
                plugin.getDeathSoundHandler().triggerDeathSound(killerUuid, victim);
            }

            // Handle death message (victim's equipped)
            String deathMsgId = plugin.getPlayerCosmeticManager().getEquipped(killerUuid, CosmeticType.DEATH_MESSAGE);
            if (deathMsgId != null) {
                String deathMsg = formatDeathMessage(deathMsgId, event.killerName(), event.victimName());
                if (deathMsg != null) {
                    Bukkit.broadcast(mini.deserialize(deathMsg));
                }
            }

            // Handle custom kill message
            String killMsgId = plugin.getPlayerCosmeticManager().getEquipped(killerUuid, CosmeticType.KILL_MESSAGE);
            if (killMsgId != null) {
                Cosmetic cosmetic = plugin.getCosmeticRegistry().getById(killMsgId);
                if (cosmetic != null) {
                    String message = formatKillMessage(killMsgId, event.killerName(), event.victimName());
                    Bukkit.broadcast(mini.deserialize(message));
                }
            }
        });
    }

    /**
     * Play a death effect at the given location.
     */
    public void playDeathEffect(String effectId, Location loc) {
        if (loc == null || loc.getWorld() == null) return;

        switch (effectId.toLowerCase()) {
            case "ghost_ascend" -> {
                // Ascending soul particles
                for (int i = 0; i < 8; i++) {
                    final int tick = i;
                    Bukkit.getScheduler().runTaskLater(plugin, () -> {
                        if (loc.getWorld() == null) return;
                        loc.getWorld().spawnParticle(org.bukkit.Particle.SOUL,
                                loc.clone().add(0, 0.5 + (tick * 0.5), 0),
                                8, 0.2, 0.1, 0.2, 0.01);
                        loc.getWorld().spawnParticle(org.bukkit.Particle.SOUL_FIRE_FLAME,
                                loc.clone().add(0, 0.3 + (tick * 0.5), 0),
                                5, 0.15, 0.1, 0.15, 0.005);
                    }, tick * 3L);
                }
            }
            case "explosion_death" -> {
                loc.getWorld().spawnParticle(org.bukkit.Particle.EXPLOSION, loc.clone().add(0, 1, 0), 3, 0.5, 0.5, 0.5, 0);
                loc.getWorld().spawnParticle(org.bukkit.Particle.SMOKE, loc.clone().add(0, 0.5, 0), 30, 0.8, 0.5, 0.8, 0.05);
                loc.getWorld().spawnParticle(org.bukkit.Particle.FLAME, loc.clone().add(0, 0.5, 0), 20, 0.5, 0.5, 0.5, 0.05);
            }
            case "flower_death" -> {
                // Spawn flower particles in a ring
                for (int i = 0; i < 12; i++) {
                    double angle = (Math.PI * 2 * i) / 12;
                    double x = Math.cos(angle) * 1.5;
                    double z = Math.sin(angle) * 1.5;
                    loc.getWorld().spawnParticle(org.bukkit.Particle.CHERRY_LEAVES,
                            loc.clone().add(x, 0.5, z), 5, 0.1, 0.3, 0.1, 0.01);
                }
                loc.getWorld().spawnParticle(org.bukkit.Particle.CHERRY_LEAVES,
                        loc.clone().add(0, 1, 0), 25, 0.8, 0.5, 0.8, 0.02);
            }
            case "void_collapse" -> {
                // Collapsing void effect: particles spiral inward then vanish
                for (int i = 0; i < 6; i++) {
                    final int tick = i;
                    Bukkit.getScheduler().runTaskLater(plugin, () -> {
                        if (loc.getWorld() == null) return;
                        double radius = 2.5 - (tick * 0.4);
                        for (int j = 0; j < 10; j++) {
                            double angle = (Math.PI * 2 * j) / 10 + (tick * 0.5);
                            double x = Math.cos(angle) * radius;
                            double z = Math.sin(angle) * radius;
                            loc.getWorld().spawnParticle(org.bukkit.Particle.REVERSE_PORTAL,
                                    loc.clone().add(x, 0.5, z), 5, 0.05, 0.1, 0.05, 0.02);
                        }
                        loc.getWorld().spawnParticle(org.bukkit.Particle.PORTAL,
                                loc.clone().add(0, 1, 0), 15, 0.3, 0.5, 0.3, 0.3);
                    }, tick * 4L);
                }
                // Final implosion
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (loc.getWorld() == null) return;
                    loc.getWorld().spawnParticle(org.bukkit.Particle.EXPLOSION, loc.clone().add(0, 1, 0), 1, 0, 0, 0, 0);
                    loc.getWorld().spawnParticle(org.bukkit.Particle.REVERSE_PORTAL, loc.clone().add(0, 1, 0), 60, 0.1, 0.1, 0.1, 0.5);
                }, 28L);
            }
            default -> {
                // Unknown death effect
            }
        }
    }

    /**
     * Format a death message based on the death message cosmetic ID.
     * Matches original UltimateFFA DeathMessage enum texts.
     */
    private String formatDeathMessage(String msgId, String killerName, String victimName) {
        return switch (msgId.toLowerCase()) {
            case "death_default" -> "<gray>" + victimName + " murió a manos de " + killerName + ".";
            case "death_knight" -> "<gray>" + victimName + " cayó con honor ante " + killerName + ".";
            case "death_pirate" -> "<gray>" + victimName + " caminó por la plancha de " + killerName + ".";
            case "death_toxic" -> "<gray>" + victimName + " fue humillado (EZ) por " + killerName + ".";
            case "death_windows" -> "<gray>" + victimName + ".exe dejó de funcionar por culpa de " + killerName + ".";
            case "death_math" -> "<gray>" + victimName + " fue restado de la ecuación por " + killerName + ".";
            case "death_error404" -> "<red>Error 404: <gray>Skill de " + victimName + " no encontrada vs " + killerName + ".";
            case "death_meme" -> "<gray>" + victimName + " olvidó activar el killaura contra " + killerName + ".";
            case "death_anime" -> "<red>Omae wa mou shindeiru. <gray>" + victimName + " fue aniquilado por " + killerName + ".";
            case "death_discord" -> "<gray>" + victimName + " fue baneado del servidor de la vida por " + killerName + ".";
            default -> null;
        };
    }

    /**
     * Format a custom kill message based on the kill message cosmetic ID.
     */
    private String formatKillMessage(String msgId, String killerName, String victimName) {
        return switch (msgId.toLowerCase()) {
            case "msg_brutal" ->
                    "<red><bold>" + killerName + "</bold></red> <dark_red>☠ DESTRUYÓ ☠</dark_red> <red>" + victimName;
            case "msg_elegant" ->
                    "<gradient:#ffd700:#ff69b4>" + killerName + "</gradient> <white>eliminó elegantemente a</white> <gradient:#ff69b4:#ffd700>" + victimName + "</gradient>";
            case "msg_mythic" ->
                    "<gradient:#ff0000:#ff7700:#ffff00:#00ff00:#0000ff:#8b00ff>" + killerName + "</gradient> <light_purple>⚡ ANIQUILÓ ⚡</light_purple> <gradient:#8b00ff:#0000ff:#00ff00:#ffff00:#ff7700:#ff0000>" + victimName + "</gradient>";
            case "msg_samurai" ->
                    "<gradient:#ff4444:#ff8800>" + killerName + "</gradient> <red>⚔ cortó en dos ⚔</red> <gradient:#ff8800:#ff4444>" + victimName + "</gradient>";
            case "msg_glitch" ->
                    "<obfuscated>xx</obfuscated><red>" + killerName + "</red><obfuscated>xx</obfuscated> <dark_red>█▓░ ELIMINÓ ░▓█</dark_red> <obfuscated>xx</obfuscated><red>" + victimName + "</red><obfuscated>xx</obfuscated>";
            default ->
                    "<gray>" + killerName + " eliminó a " + victimName;
        };
    }

    /**
     * Format join message based on cosmetic ID.
     * Matches original UltimateFFA JoinMessage enum (16 messages).
     */
    private String formatJoinMessage(String msgId, String playerName) {
        return switch (msgId.toLowerCase()) {
            case "join_default" -> "<gray>[<green>+</green>] <white>" + playerName + " ha entrado.";
            case "join_pizza" -> "<green>Ding dong... <white>¡Llegó " + playerName + " con la pizza!";
            case "join_mom" -> "<light_purple>❤ <white>¡La mamá de " + playerName + " lo dejó en la guardería!";
            case "join_fbi" -> "<red><bold>FBI!</bold> <white>" + playerName + " ha tirado la puerta abajo.";
            case "join_dad" -> "<dark_gray>" + playerName + " ha vuelto (al fin).";
            case "join_party" -> "<light_purple>\uD83C\uDF89 <white>¡Llegó " + playerName + ", que empiece la fiesta! <light_purple>\uD83C\uDF89";
            case "join_streamer" -> "<light_purple>\uD83C\uDFA5 <white>" + playerName + " está en directo. ¡Saluden!";
            case "join_wild" -> "<green>¡Un " + playerName + " salvaje apareció!";
            case "join_handsome" -> "<aqua>✨ Aparten la mirada, llegó <bold>" + playerName + "</bold> <aqua>✨";
            case "join_ghost" -> "<gray>Una sombra llamada " + playerName + " apareció...";
            case "join_herobrine" -> "<white><bold>" + playerName + "</bold> <gray>se ha unido a la partida...";
            case "join_hacker" -> "<red>[ALERT] <white>" + playerName + " ha inyectado el servidor.";
            case "join_admin" -> "<dark_red><bold>ADMIN</bold> <dark_gray>» <red>" + playerName + " ha entrado en modo oculto.";
            case "join_mvp" -> "<aqua><bold>MVP</bold> <dark_aqua>» <white>¡" + playerName + " ha aterrizado en la arena!";
            case "join_king" -> "<yellow>\uD83D\uDC51 ¡Su majestad " + playerName + " honra el servidor! \uD83D\uDC51";
            case "join_god" -> "<gold>⚡ <yellow>¡EL DIOS " + playerName + " HA LLEGADO! <gold>⚡";
            default -> null;
        };
    }

    // ═══════════════════════════════════════════════════════════════
    //              AURA / ARMOR TRIM / TITLE GUI CLICK ROUTING
    // ═══════════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        String title = event.getView().getTitle();
        if (title == null || title.isEmpty()) return;
        String stripped = ChatColor.stripColor(title);

        ItemStack item = event.getCurrentItem();
        int slot = event.getRawSlot();
        boolean rightClick = event.isRightClick();

        // ─── ARMOR TRIM GUI Routing ───
        if (stripped.contains("Armor Trims")) {
            event.setCancelled(true);
            handleArmorTrimMainClick(player, item, slot);
            return;
        }
        if (stripped.startsWith("Editar ")) {
            event.setCancelled(true);
            handleArmorTrimPieceClick(player, item, slot, stripped);
            return;
        }
        if (stripped.startsWith("Seleccionar Patr") && stripped.contains(" - ")) {
            event.setCancelled(true);
            handleArmorTrimPatternClick(player, item, slot, stripped);
            return;
        }
        if (stripped.startsWith("Seleccionar Color") && stripped.contains(" - ")) {
            event.setCancelled(true);
            handleArmorTrimColorClick(player, item, slot, stripped);
            return;
        }

        // ─── TITLE GUI Routing ───
        if (stripped.contains("Títulos") || stripped.contains("Titulos")) {
            event.setCancelled(true);
            plugin.getTitleManager().handleGUIClick(player, slot, item, title);
            return;
        }

        // ─── AURA GUI Routing ───
        var aurasManager = plugin.getAdvancedAurasManager();
        if (aurasManager == null) return;
        var guiManager = aurasManager.getGUIManager();
        if (guiManager == null) return;

        if (stripped.contains("SELECCIONAR TIER")) {
            event.setCancelled(true);
            guiManager.handleTiersClick(player, item, slot);
        } else if (stripped.contains("BASIC AURAS")) {
            event.setCancelled(true);
            guiManager.handleTierAurasClick(player, item, slot, "BASIC", rightClick);
        } else if (stripped.contains("PREMIUM AURAS")) {
            event.setCancelled(true);
            guiManager.handleTierAurasClick(player, item, slot, "PREMIUM", rightClick);
        } else if (stripped.contains("LEGENDARY AURAS")) {
            event.setCancelled(true);
            guiManager.handleTierAurasClick(player, item, slot, "LEGENDARY", rightClick);
        } else if (stripped.contains("SPECIAL AURAS")) {
            event.setCancelled(true);
            guiManager.handleTierAurasClick(player, item, slot, "SPECIAL", rightClick);
        } else if (stripped.contains("PATRONES:")) {
            event.setCancelled(true);
            guiManager.handlePatternsClick(player, item, slot, title, rightClick);
        } else if (stripped.contains("FUSIÓN DE AURAS") || stripped.contains("FUSION DE AURAS")) {
            event.setCancelled(true);
            guiManager.handleFusionsClick(player, item, slot);
        } else if (stripped.contains("GESTIÓN DE SLOTS") || stripped.contains("GESTION DE SLOTS")) {
            event.setCancelled(true);
            guiManager.handleSlotsClick(player, item, slot);
        } else if (stripped.contains("Seleccionar Aura")) {
            event.setCancelled(true);
            guiManager.handleSlotAuraSelection(player, item, slot);
        } else if (stripped.contains("PATRÓN PARA") || stripped.contains("PATRON PARA")) {
            event.setCancelled(true);
            guiManager.handleSlotPatternSelection(player, item, slot);
        } else if (stripped.contains("CONFIG") && (stripped.contains("⚙") || stripped.contains("CONFIGURACIÓN") || stripped.contains("CONFIGURACION"))) {
            event.setCancelled(true);
            if (stripped.contains("CONFIG:")) {
                guiManager.handleAuraSettingsClick(player, item, slot);
            } else {
                guiManager.handleAdvancedConfigClick(player, item, slot);
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //              ARMOR TRIM CLICK HANDLERS
    // ═══════════════════════════════════════════════════════════════

    private void handleArmorTrimMainClick(Player player, ItemStack item, int slot) {
        if (item == null || item.getType().isAir()) return;
        var trimManager = plugin.getArmorTrimManager();

        // Diamond piece slots: 12=helmet, 13=chest, 14=legs, 15=boots
        // Netherite piece slots: 21=helmet, 22=chest, 23=legs, 24=boots
        com.ethernova.cosmetics.armortrim.ArmorTrimManager.ArmorPiece piece = switch (slot) {
            case 12, 21 -> com.ethernova.cosmetics.armortrim.ArmorTrimManager.ArmorPiece.HELMET;
            case 13, 22 -> com.ethernova.cosmetics.armortrim.ArmorTrimManager.ArmorPiece.CHESTPLATE;
            case 14, 23 -> com.ethernova.cosmetics.armortrim.ArmorTrimManager.ArmorPiece.LEGGINGS;
            case 15, 24 -> com.ethernova.cosmetics.armortrim.ArmorTrimManager.ArmorPiece.BOOTS;
            default -> null;
        };

        if (piece != null) {
            trimManager.openPieceEditMenu(player, piece);
            return;
        }

        switch (slot) {
            case 29 -> trimManager.startPreview(player);
            case 31 -> {
                trimManager.saveTrimConfig(player.getUniqueId());
                player.sendMessage(MiniMessage.miniMessage().deserialize("<green>✦ Configuración de trims guardada."));
                player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);
            }
            case 33 -> {
                trimManager.clearTrims(player.getUniqueId());
                player.sendMessage(MiniMessage.miniMessage().deserialize("<red>✘ Todos los trims eliminados."));
                player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_FIRE_EXTINGUISH, 1f, 1f);
                trimManager.openArmorSelector(player);
            }
            case 49 -> new com.ethernova.cosmetics.gui.CosmeticsMainGui(plugin.getCore(), player, plugin).open();
        }
    }

    private void handleArmorTrimPieceClick(Player player, ItemStack item, int slot, String stripped) {
        if (item == null || item.getType().isAir()) return;
        var trimManager = plugin.getArmorTrimManager();
        var piece = parsePieceFromTitle(stripped);
        if (piece == null) return;

        switch (slot) {
            case 19 -> trimManager.openPatternSelector(player, piece);      // Pattern
            case 21 -> trimManager.openMaterialSelector(player, piece);     // Color
            case 23 -> trimManager.startPiecePreview(player, piece);        // Preview piece
            case 25 -> trimManager.startPreview(player);                    // Preview full
            case 30 -> {
                // Clear trim pattern
                trimManager.setDesign(player.getUniqueId(), piece, null);
                player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_FIRE_EXTINGUISH, 1f, 1f);
                player.sendMessage(MiniMessage.miniMessage().deserialize(
                        "<red>✘ Patrón eliminado de " + piece.getDisplayName()));
                trimManager.openPieceEditMenu(player, piece);
            }
            case 32 -> {
                // Clear color
                trimManager.setColor(player.getUniqueId(), piece, null);
                player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_FIRE_EXTINGUISH, 1f, 1f);
                player.sendMessage(MiniMessage.miniMessage().deserialize(
                        "<red>✘ Color eliminado de " + piece.getDisplayName()));
                trimManager.openPieceEditMenu(player, piece);
            }
            case 40 -> trimManager.openArmorSelector(player);               // Back
        }
    }

    private void handleArmorTrimPatternClick(Player player, ItemStack item, int slot, String stripped) {
        if (item == null || item.getType().isAir()) return;
        var trimManager = plugin.getArmorTrimManager();
        var piece = parsePieceFromTitle(stripped);
        if (piece == null) return;

        if (slot == 34) {
            // Remove pattern
            trimManager.setDesign(player.getUniqueId(), piece, null);
            player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_FIRE_EXTINGUISH, 1f, 1f);
            trimManager.openPieceEditMenu(player, piece);
            return;
        }
        if (slot == 40) {
            // Back
            trimManager.openPieceEditMenu(player, piece);
            return;
        }
        // Select pattern via slot→index mapping (content slots: 10-16, 19-25, 28-31)
        int patternIndex = trimManager.getPatternIndexFromSlot(slot);
        if (patternIndex >= 0) {
            var designs = com.ethernova.cosmetics.armortrim.ArmorTrimManager.TrimDesign.values();
            if (patternIndex < designs.length) {
                trimManager.setDesign(player.getUniqueId(), piece, designs[patternIndex]);
                player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.5f);
                player.sendMessage(MiniMessage.miniMessage().deserialize(
                        "<green>✦ Patrón " + designs[patternIndex].getDisplayName() + " seleccionado para " + piece.getDisplayName()));
                trimManager.openPieceEditMenu(player, piece);
            }
        }
    }

    private void handleArmorTrimColorClick(Player player, ItemStack item, int slot, String stripped) {
        if (item == null || item.getType().isAir()) return;
        var trimManager = plugin.getArmorTrimManager();
        var piece = parsePieceFromTitle(stripped);
        if (piece == null) return;

        if (slot == 25) {
            // Remove color
            trimManager.setColor(player.getUniqueId(), piece, null);
            player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_FIRE_EXTINGUISH, 1f, 1f);
            trimManager.openPieceEditMenu(player, piece);
            return;
        }
        if (slot == 31) {
            // Back
            trimManager.openPieceEditMenu(player, piece);
            return;
        }
        // Select color via slot→index mapping (content slots: 10-16, 19-21)
        int colorIndex = trimManager.getColorIndexFromSlot(slot);
        if (colorIndex >= 0) {
            var colors = com.ethernova.cosmetics.armortrim.ArmorTrimManager.TrimColor.values();
            if (colorIndex < colors.length) {
                trimManager.setColor(player.getUniqueId(), piece, colors[colorIndex]);
                player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.5f);
                player.sendMessage(MiniMessage.miniMessage().deserialize(
                        "<green>✦ Color " + colors[colorIndex].getDisplayName() + " seleccionado para " + piece.getDisplayName()));
                trimManager.openPieceEditMenu(player, piece);
            }
        }
    }

    private com.ethernova.cosmetics.armortrim.ArmorTrimManager.ArmorPiece parsePieceFromTitle(String stripped) {
        if (stripped.contains("Casco")) return com.ethernova.cosmetics.armortrim.ArmorTrimManager.ArmorPiece.HELMET;
        if (stripped.contains("Pechera")) return com.ethernova.cosmetics.armortrim.ArmorTrimManager.ArmorPiece.CHESTPLATE;
        if (stripped.contains("Pantalones")) return com.ethernova.cosmetics.armortrim.ArmorTrimManager.ArmorPiece.LEGGINGS;
        if (stripped.contains("Botas")) return com.ethernova.cosmetics.armortrim.ArmorTrimManager.ArmorPiece.BOOTS;
        return null;
    }

    @EventHandler
    public void onInventoryClose(org.bukkit.event.inventory.InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        var aurasManager = plugin.getAdvancedAurasManager();
        if (aurasManager == null) return;
        var guiManager = aurasManager.getGUIManager();
        if (guiManager == null) return;
        guiManager.stopBorderAnimation(player);
    }
}
