package com.ethernova.cosmetics.effect;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.cosmetics.model.CosmeticType;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.UUID;

/**
 * HitEffectsManager — 15 on-hit particle/sound effects.
 * Triggered when a player with an equipped hit effect attacks another player.
 * Ported faithfully from original UltimateFFA HitEffectsManager.
 *
 * Effects: blood, lightning, explosion, freeze, fire, poison, ender, hearts,
 *          critical, slime, witch, dragon, star, smoke, magic
 */
public class HitEffectsManager {

    private final EthernovaCosmetics plugin;

    public HitEffectsManager(EthernovaCosmetics plugin) {
        this.plugin = plugin;
    }

    /**
     * Trigger the hit effect when attacker hits victim.
     * Called from CosmeticListener on EntityDamageByEntityEvent.
     */
    public void triggerHitEffect(UUID attackerUuid, Player victim) {
        if (attackerUuid == null || victim == null) return;

        String effectId = plugin.getPlayerCosmeticManager().getEquipped(attackerUuid, CosmeticType.HIT_EFFECT);
        if (effectId == null) return;

        playEffect(effectId, victim);
    }

    /**
     * Play the particle + sound effect on the victim.
     */
    public void playEffect(String effectId, Player victim) {
        if (victim == null) return;
        Location loc = victim.getLocation().add(0, 1, 0);
        if (loc.getWorld() == null) return;

        switch (effectId.toLowerCase()) {
            case "hit_blood", "blood" -> {
                loc.getWorld().spawnParticle(Particle.DUST, loc, 30, 0.3, 0.3, 0.3, 0,
                        new Particle.DustOptions(Color.fromRGB(139, 0, 0), 1.5f));
                loc.getWorld().playSound(loc, Sound.ENTITY_PLAYER_HURT, 1f, 0.8f);
            }
            case "hit_lightning", "lightning" -> {
                loc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc, 40, 0.2, 0.5, 0.2, 0.05);
                loc.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.5f, 2f);
            }
            case "hit_explosion", "explosion" -> {
                loc.getWorld().spawnParticle(Particle.EXPLOSION, loc, 2, 0.2, 0.2, 0.2, 0);
                loc.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 1.2f);
            }
            case "hit_freeze", "freeze" -> {
                loc.getWorld().spawnParticle(Particle.SNOWFLAKE, loc, 40, 0.3, 0.3, 0.3, 0.02);
                loc.getWorld().playSound(loc, Sound.BLOCK_GLASS_BREAK, 1f, 1.5f);
            }
            case "hit_fire", "fire" -> {
                loc.getWorld().spawnParticle(Particle.FLAME, loc, 30, 0.3, 0.3, 0.3, 0.05);
                loc.getWorld().playSound(loc, Sound.ITEM_FIRECHARGE_USE, 1f, 1f);
            }
            case "hit_poison", "poison" -> {
                loc.getWorld().spawnParticle(Particle.ITEM_SLIME, loc, 25, 0.3, 0.3, 0.3, 0);
                loc.getWorld().playSound(loc, Sound.ENTITY_SPIDER_AMBIENT, 1f, 0.8f);
            }
            case "hit_ender", "ender" -> {
                loc.getWorld().spawnParticle(Particle.PORTAL, loc, 50, 0.3, 0.3, 0.3, 0.5);
                loc.getWorld().playSound(loc, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
            }
            case "hit_hearts", "hearts" -> {
                loc.getWorld().spawnParticle(Particle.HEART, loc, 10, 0.5, 0.5, 0.5, 0);
                loc.getWorld().playSound(loc, Sound.ENTITY_PLAYER_LEVELUP, 1f, 2f);
            }
            case "hit_critical", "critical" -> {
                loc.getWorld().spawnParticle(Particle.CRIT, loc, 40, 0.3, 0.3, 0.3, 0.1);
                loc.getWorld().playSound(loc, Sound.ENTITY_PLAYER_ATTACK_CRIT, 1f, 1f);
            }
            case "hit_slime", "slime" -> {
                loc.getWorld().spawnParticle(Particle.ITEM_SLIME, loc, 20, 0.3, 0.3, 0.3, 0);
                loc.getWorld().playSound(loc, Sound.BLOCK_SLIME_BLOCK_PLACE, 1f, 1f);
            }
            case "hit_witch", "witch" -> {
                loc.getWorld().spawnParticle(Particle.WITCH, loc, 30, 0.3, 0.3, 0.3, 0);
                loc.getWorld().playSound(loc, Sound.ENTITY_WITCH_AMBIENT, 1f, 1f);
            }
            case "hit_dragon", "dragon" -> {
                loc.getWorld().spawnParticle(Particle.DRAGON_BREATH, loc, 35, 0.3, 0.3, 0.3, 0.02);
                loc.getWorld().playSound(loc, Sound.ENTITY_ENDER_DRAGON_GROWL, 0.5f, 2f);
            }
            case "hit_star", "star" -> {
                loc.getWorld().spawnParticle(Particle.END_ROD, loc, 25, 0.5, 0.5, 0.5, 0.1);
                loc.getWorld().playSound(loc, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 2f);
            }
            case "hit_smoke", "smoke" -> {
                loc.getWorld().spawnParticle(Particle.LARGE_SMOKE, loc, 30, 0.3, 0.3, 0.3, 0.05);
                loc.getWorld().playSound(loc, Sound.BLOCK_FIRE_EXTINGUISH, 1f, 1f);
            }
            case "hit_magic", "magic" -> {
                loc.getWorld().spawnParticle(Particle.ENCHANT, loc, 35, 0.3, 0.3, 0.3, 0.5);
                loc.getWorld().playSound(loc, Sound.ENTITY_ILLUSIONER_CAST_SPELL, 1f, 1.5f);
            }
            default -> { }
        }
    }

    /**
     * Preview a hit effect for a player.
     * Plays the effect 3 times with delays so the player can see it clearly.
     */
    public void preview(Player player, String effectId) {
        if (player == null || effectId == null) return;

        new BukkitRunnable() {
            int count = 0;

            @Override
            public void run() {
                if (!player.isOnline() || count >= 3) {
                    cancel();
                    return;
                }
                playEffect(effectId, player);
                count++;
            }
        }.runTaskTimer(plugin, 0L, 15L); // Play immediately, then every 15 ticks (0.75s)
    }
}
