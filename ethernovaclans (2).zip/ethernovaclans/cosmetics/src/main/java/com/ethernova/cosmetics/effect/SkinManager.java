package com.ethernova.cosmetics.effect;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.cosmetics.model.CosmeticType;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.entity.Player;

import java.util.UUID;

/**
 * Manages weapon and armor skins — cosmetic model data overrides that change
 * the appearance of a player's gear without changing stats.
 * <p>
 * Skins work by setting CustomModelData on the player's equipment when they
 * join an arena/duel. The actual stat items remain unchanged.
 * <p>
 * Replicates the original UltimateFFA skins.yml system with weapon, armor, and bow skins.
 */
public class SkinManager {

    private final EthernovaCosmetics plugin;

    public SkinManager(EthernovaCosmetics plugin) {
        this.plugin = plugin;
    }

    /**
     * Apply the player's equipped weapon skin to the given item, if applicable.
     * Returns the modified item (or the original if no skin is equipped).
     */
    public ItemStack applyWeaponSkin(UUID uuid, ItemStack item) {
        if (item == null || item.getType().isAir()) return item;
        if (!isSword(item.getType()) && !isBow(item.getType())) return item;

        String skinId = plugin.getPlayerCosmeticManager().getEquipped(uuid, CosmeticType.WEAPON_SKIN);
        if (skinId == null) return item;

        int modelData = getModelData(skinId);
        if (modelData <= 0) return item;

        ItemStack skinned = item.clone();
        ItemMeta meta = skinned.getItemMeta();
        if (meta != null) {
            meta.setCustomModelData(modelData);
            skinned.setItemMeta(meta);
        }
        return skinned;
    }

    /**
     * Apply the player's equipped armor skin to their full armor set.
     * Returns an array [helmet, chest, legs, boots] with model data applied,
     * or the originals if no skin is equipped.
     */
    public ItemStack[] applyArmorSkin(UUID uuid, ItemStack[] armor) {
        if (armor == null || armor.length < 4) return armor;

        String skinId = plugin.getPlayerCosmeticManager().getEquipped(uuid, CosmeticType.ARMOR_SKIN);
        if (skinId == null) return armor;

        int modelData = getModelData(skinId);
        if (modelData <= 0) return armor;

        ItemStack[] result = new ItemStack[4];
        for (int i = 0; i < 4; i++) {
            if (armor[i] != null && !armor[i].getType().isAir()) {
                result[i] = armor[i].clone();
                ItemMeta meta = result[i].getItemMeta();
                if (meta != null) {
                    meta.setCustomModelData(modelData);
                    result[i].setItemMeta(meta);
                }
            } else {
                result[i] = armor[i];
            }
        }
        return result;
    }

    /**
     * Preview a skin — show info message.
     */
    public void preview(Player player, String skinId) {
        if (player == null || skinId == null) return;
        var cosmetic = plugin.getCosmeticRegistry().getById(skinId);
        if (cosmetic != null) {
            player.sendMessage(MiniMessage.miniMessage().deserialize(
                    "<gray>Skin: " + cosmetic.name() + " <dark_gray>(requiere resource pack para visualizar)"));
        }
    }

    /**
     * Get model data for a given skin ID. Returns 0 if unknown.
     * Model data is defined in the cosmetics.yml config under each skin cosmetic.
     */
    private int getModelData(String skinId) {
        // Model data is stored in the cosmetic's config section as a custom property
        var cosmetic = plugin.getCosmeticRegistry().getById(skinId);
        if (cosmetic == null) return 0;
        // Convention: price is repurposed partially, but model data comes from config
        // We use the cosmetics.yml "model-data" field loaded by CosmeticRegistry
        var sec = plugin.getCosmeticRegistry().getCosmeticSection(skinId);
        if (sec != null) {
            return sec.getInt("model-data", 0);
        }
        return 0;
    }

    private boolean isSword(Material mat) {
        return mat.name().endsWith("_SWORD");
    }

    private boolean isBow(Material mat) {
        return mat == Material.BOW || mat == Material.CROSSBOW;
    }
}
