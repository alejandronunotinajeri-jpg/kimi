package com.ethernova.cosmetics.armortrim;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.core.EthernovaCore;
import com.ethernova.core.profile.PlayerProfile;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ArmorMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.trim.ArmorTrim;
import org.bukkit.inventory.meta.trim.TrimMaterial;
import org.bukkit.inventory.meta.trim.TrimPattern;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Armor Trim Manager — allows players to customize armor trims as cosmetics.
 * Provides per-piece editing with pattern and material selectors, live preview,
 * and persistence via player profile data.
 */
public class ArmorTrimManager {

    private final EthernovaCosmetics plugin;
    private final EthernovaCore core;
    private final MiniMessage mini = MiniMessage.miniMessage();

    /** Cached trim configurations per player. */
    private final Map<UUID, TrimConfig> trimCache = new ConcurrentHashMap<>();

    /** Players currently in preview mode with their backup armor. */
    private final Map<UUID, ItemStack[]> previewBackup = new ConcurrentHashMap<>();

    /**
     * Available trim patterns with display info (18 patterns including 1.21 BOLT/FLOW).
     */
    public enum TrimDesign {
        BOLT("Bolt", Material.BOLT_ARMOR_TRIM_SMITHING_TEMPLATE, TrimPattern.BOLT),
        COAST("Coast", Material.COAST_ARMOR_TRIM_SMITHING_TEMPLATE, TrimPattern.COAST),
        DUNE("Dune", Material.DUNE_ARMOR_TRIM_SMITHING_TEMPLATE, TrimPattern.DUNE),
        EYE("Eye", Material.EYE_ARMOR_TRIM_SMITHING_TEMPLATE, TrimPattern.EYE),
        FLOW("Flow", Material.FLOW_ARMOR_TRIM_SMITHING_TEMPLATE, TrimPattern.FLOW),
        HOST("Host", Material.HOST_ARMOR_TRIM_SMITHING_TEMPLATE, TrimPattern.HOST),
        RAISER("Raiser", Material.RAISER_ARMOR_TRIM_SMITHING_TEMPLATE, TrimPattern.RAISER),
        RIB("Rib", Material.RIB_ARMOR_TRIM_SMITHING_TEMPLATE, TrimPattern.RIB),
        SENTRY("Sentry", Material.SENTRY_ARMOR_TRIM_SMITHING_TEMPLATE, TrimPattern.SENTRY),
        SHAPER("Shaper", Material.SHAPER_ARMOR_TRIM_SMITHING_TEMPLATE, TrimPattern.SHAPER),
        SILENCE("Silence", Material.SILENCE_ARMOR_TRIM_SMITHING_TEMPLATE, TrimPattern.SILENCE),
        SNOUT("Snout", Material.SNOUT_ARMOR_TRIM_SMITHING_TEMPLATE, TrimPattern.SNOUT),
        SPIRE("Spire", Material.SPIRE_ARMOR_TRIM_SMITHING_TEMPLATE, TrimPattern.SPIRE),
        TIDE("Tide", Material.TIDE_ARMOR_TRIM_SMITHING_TEMPLATE, TrimPattern.TIDE),
        VEX("Vex", Material.VEX_ARMOR_TRIM_SMITHING_TEMPLATE, TrimPattern.VEX),
        WARD("Ward", Material.WARD_ARMOR_TRIM_SMITHING_TEMPLATE, TrimPattern.WARD),
        WAYFINDER("Wayfinder", Material.WAYFINDER_ARMOR_TRIM_SMITHING_TEMPLATE, TrimPattern.WAYFINDER),
        WILD("Wild", Material.WILD_ARMOR_TRIM_SMITHING_TEMPLATE, TrimPattern.WILD);

        private final String displayName;
        private final Material icon;
        private final TrimPattern pattern;

        TrimDesign(String displayName, Material icon, TrimPattern pattern) {
            this.displayName = displayName;
            this.icon = icon;
            this.pattern = pattern;
        }

        public String getDisplayName() { return displayName; }
        public Material getIcon() { return icon; }
        public TrimPattern getPattern() { return pattern; }
    }

    /**
     * Available trim materials (colors).
     */
    public enum TrimColor {
        AMETHYST("Amatista", Material.AMETHYST_SHARD, TrimMaterial.AMETHYST, "<light_purple>"),
        COPPER("Cobre", Material.COPPER_INGOT, TrimMaterial.COPPER, "<gold>"),
        DIAMOND("Diamante", Material.DIAMOND, TrimMaterial.DIAMOND, "<aqua>"),
        EMERALD("Esmeralda", Material.EMERALD, TrimMaterial.EMERALD, "<green>"),
        GOLD("Oro", Material.GOLD_INGOT, TrimMaterial.GOLD, "<yellow>"),
        IRON("Hierro", Material.IRON_INGOT, TrimMaterial.IRON, "<white>"),
        LAPIS("Lapislázuli", Material.LAPIS_LAZULI, TrimMaterial.LAPIS, "<blue>"),
        NETHERITE("Netherite", Material.NETHERITE_INGOT, TrimMaterial.NETHERITE, "<dark_gray>"),
        QUARTZ("Cuarzo", Material.QUARTZ, TrimMaterial.QUARTZ, "<white>"),
        REDSTONE("Redstone", Material.REDSTONE, TrimMaterial.REDSTONE, "<red>");

        private final String displayName;
        private final Material icon;
        private final TrimMaterial material;
        private final String color;

        TrimColor(String displayName, Material icon, TrimMaterial material, String color) {
            this.displayName = displayName;
            this.icon = icon;
            this.material = material;
            this.color = color;
        }

        public String getDisplayName() { return displayName; }
        public Material getIcon() { return icon; }
        public TrimMaterial getMaterial() { return material; }
        public String getColor() { return color; }
    }

    /**
     * Represents a player's trim configuration for all armor pieces.
     */
    public static class TrimConfig {
        private TrimDesign helmetDesign, chestDesign, legsDesign, bootsDesign;
        private TrimColor helmetColor, chestColor, legsColor, bootsColor;

        public TrimDesign getDesign(ArmorPiece piece) {
            return switch (piece) {
                case HELMET -> helmetDesign;
                case CHESTPLATE -> chestDesign;
                case LEGGINGS -> legsDesign;
                case BOOTS -> bootsDesign;
            };
        }

        public TrimColor getColor(ArmorPiece piece) {
            return switch (piece) {
                case HELMET -> helmetColor;
                case CHESTPLATE -> chestColor;
                case LEGGINGS -> legsColor;
                case BOOTS -> bootsColor;
            };
        }

        public void setDesign(ArmorPiece piece, TrimDesign design) {
            switch (piece) {
                case HELMET -> helmetDesign = design;
                case CHESTPLATE -> chestDesign = design;
                case LEGGINGS -> legsDesign = design;
                case BOOTS -> bootsDesign = design;
            }
        }

        public void setColor(ArmorPiece piece, TrimColor color) {
            switch (piece) {
                case HELMET -> helmetColor = color;
                case CHESTPLATE -> chestColor = color;
                case LEGGINGS -> legsColor = color;
                case BOOTS -> bootsColor = color;
            }
        }

        /**
         * Serialize to a storage string.
         * Format: helmet_design:helmet_color|chest_design:chest_color|legs_design:legs_color|boots_design:boots_color
         */
        public String serialize() {
            return serializePiece(helmetDesign, helmetColor) + "|" +
                    serializePiece(chestDesign, chestColor) + "|" +
                    serializePiece(legsDesign, legsColor) + "|" +
                    serializePiece(bootsDesign, bootsColor);
        }

        private String serializePiece(TrimDesign design, TrimColor color) {
            String d = design != null ? design.name() : "NONE";
            String c = color != null ? color.name() : "NONE";
            return d + ":" + c;
        }

        /**
         * Deserialize from a storage string.
         */
        public static TrimConfig deserialize(String data) {
            TrimConfig config = new TrimConfig();
            if (data == null || data.isEmpty()) return config;
            try {
                String[] parts = data.split("\\|");
                if (parts.length >= 4) {
                    parsePiece(parts[0], config, ArmorPiece.HELMET);
                    parsePiece(parts[1], config, ArmorPiece.CHESTPLATE);
                    parsePiece(parts[2], config, ArmorPiece.LEGGINGS);
                    parsePiece(parts[3], config, ArmorPiece.BOOTS);
                }
            } catch (Exception ignored) {}
            return config;
        }

        private static void parsePiece(String piece, TrimConfig config, ArmorPiece armorPiece) {
            String[] parts = piece.split(":");
            if (parts.length >= 2) {
                try {
                    if (!"NONE".equals(parts[0])) config.setDesign(armorPiece, TrimDesign.valueOf(parts[0]));
                    if (!"NONE".equals(parts[1])) config.setColor(armorPiece, TrimColor.valueOf(parts[1]));
                } catch (IllegalArgumentException ignored) {}
            }
        }
    }

    public enum ArmorPiece {
        HELMET("Casco", 39),
        CHESTPLATE("Pechera", 38),
        LEGGINGS("Pantalones", 37),
        BOOTS("Botas", 36);

        private final String displayName;
        private final int armorSlot;

        ArmorPiece(String displayName, int armorSlot) {
            this.displayName = displayName;
            this.armorSlot = armorSlot;
        }

        public String getDisplayName() { return displayName; }
        public int getArmorSlot() { return armorSlot; }
    }

    public ArmorTrimManager(EthernovaCosmetics plugin) {
        this.plugin = plugin;
        this.core = plugin.getCore();
    }

    /**
     * Get the diamond armor material for a given piece.
     */
    public Material getDiamondMaterial(ArmorPiece piece) {
        return switch (piece) {
            case HELMET -> Material.DIAMOND_HELMET;
            case CHESTPLATE -> Material.DIAMOND_CHESTPLATE;
            case LEGGINGS -> Material.DIAMOND_LEGGINGS;
            case BOOTS -> Material.DIAMOND_BOOTS;
        };
    }

    /**
     * Get the netherite armor material for a given piece.
     */
    public Material getNetheriteMaterial(ArmorPiece piece) {
        return switch (piece) {
            case HELMET -> Material.NETHERITE_HELMET;
            case CHESTPLATE -> Material.NETHERITE_CHESTPLATE;
            case LEGGINGS -> Material.NETHERITE_LEGGINGS;
            case BOOTS -> Material.NETHERITE_BOOTS;
        };
    }

    /**
     * Load a player's trim configuration from profile.
     */
    public TrimConfig loadTrimConfig(UUID uuid) {
        TrimConfig cached = trimCache.get(uuid);
        if (cached != null) return cached;

        PlayerProfile profile = core.getProfileManager().getProfile(uuid);
        if (profile == null) return new TrimConfig();

        String data = profile.getCustom("armor_trim");
        TrimConfig config = TrimConfig.deserialize(data);
        trimCache.put(uuid, config);
        return config;
    }

    /**
     * Save a player's trim configuration.
     */
    public void saveTrimConfig(UUID uuid) {
        TrimConfig config = trimCache.get(uuid);
        if (config == null) return;
        core.getProfileManager().setData(uuid, "armor_trim", config.serialize());
    }

    // ═══════════════════════════════════════════════════════════════
    //                    GUI METHODS (POLISHED)
    // ═══════════════════════════════════════════════════════════════

    /**
     * Open the main armor selector GUI (54 slots).
     * Row 0: Header. Row 1: Diamond armor (4 pieces). Row 2: Netherite armor (4 pieces).
     * Row 3: Actions. Row 5: Back.
     * Each armor piece is clickable to edit trims.
     */
    public void openArmorSelector(Player player) {
        UUID uuid = player.getUniqueId();
        TrimConfig config = loadTrimConfig(uuid);

        Inventory inv = Bukkit.createInventory(null, 54,
                mini.deserialize("<gradient:gold:yellow>✦ Armor Trims</gradient>"));

        fillBorders(inv, 54);

        // Gradient header
        inv.setItem(4, createItem(Material.ANVIL, "<gradient:gold:yellow><bold>Armor Trims</bold></gradient>",
                List.of("",
                        "<dark_gray>▎ <gray>Personaliza la decoración",
                        "<dark_gray>▎ <gray>de cada pieza de armadura.",
                        "<dark_gray>▎",
                        "<dark_gray>▎ <yellow>18 patrones <dark_gray>· <yellow>10 materiales",
                        "",
                        "<dark_gray>▎ <green>▶ Click en una pieza para editarla")));

        // ═══ Row 1: Diamond Armor Label + 4 pieces ═══
        inv.setItem(10, createItem(Material.DIAMOND, "<aqua><bold>Diamante",
                List.of("", "<dark_gray>▎ <gray>Armadura de diamante", "")));

        for (ArmorPiece piece : ArmorPiece.values()) {
            int slot = switch (piece) {
                case HELMET -> 12;
                case CHESTPLATE -> 13;
                case LEGGINGS -> 14;
                case BOOTS -> 15;
            };
            buildArmorSlot(inv, slot, piece, config, getDiamondMaterial(piece));
        }

        // ═══ Row 2: Netherite Armor Label + 4 pieces ═══
        inv.setItem(19, createItem(Material.NETHERITE_INGOT, "<dark_gray><bold>Netherite",
                List.of("", "<dark_gray>▎ <gray>Armadura de netherite", "")));

        for (ArmorPiece piece : ArmorPiece.values()) {
            int slot = switch (piece) {
                case HELMET -> 21;
                case CHESTPLATE -> 22;
                case LEGGINGS -> 23;
                case BOOTS -> 24;
            };
            buildArmorSlot(inv, slot, piece, config, getNetheriteMaterial(piece));
        }

        // ═══ Row 3: Action buttons ═══
        inv.setItem(29, createItem(Material.SPYGLASS, "<green>▶ Vista Previa",
                List.of("",
                        "<dark_gray>▎ <gray>Prueba tus trims en",
                        "<dark_gray>▎ <gray>tu armadura durante",
                        "<dark_gray>▎ <gray>4 segundos.",
                        "")));

        inv.setItem(31, createItem(Material.NETHER_STAR, "<gold>⭐ Guardar Todo",
                List.of("",
                        "<dark_gray>▎ <gray>Guarda tu configuración",
                        "<dark_gray>▎ <gray>de trims actual.",
                        "")));

        inv.setItem(33, createItem(Material.BARRIER, "<red>✘ Quitar Todos",
                List.of("",
                        "<dark_gray>▎ <gray>Eliminar todos los",
                        "<dark_gray>▎ <gray>trims de armadura.",
                        "")));

        // Back button
        inv.setItem(49, createItem(Material.ARROW, "<red>← Volver", List.of()));

        player.openInventory(inv);
    }

    /**
     * Helper: builds an armor piece slot with trim info in lore.
     */
    private void buildArmorSlot(Inventory inv, int slot, ArmorPiece piece, TrimConfig config, Material armorMat) {
        TrimDesign design = config.getDesign(piece);
        TrimColor color = config.getColor(piece);
        String designText = design != null ? design.getDisplayName() : "<gray>Ninguno";
        String colorText = color != null ? color.getColor() + color.getDisplayName() : "<gray>Ninguno";

        List<String> lore = new ArrayList<>();
        lore.add("");
        lore.add("<dark_gray>▎ <yellow>Patrón: <white>" + designText);
        lore.add("<dark_gray>▎ <yellow>Color: <white>" + colorText);
        lore.add("");
        lore.add("<dark_gray>▎ <green>▶ Click para editar");

        ItemStack item = createTrimmedItem(armorMat, design, color);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(mini.deserialize("<aqua><bold>" + piece.getDisplayName()));
        List<Component> loreCmps = new ArrayList<>();
        for (String l : lore) loreCmps.add(mini.deserialize(l));
        meta.lore(loreCmps);
        item.setItemMeta(meta);
        inv.setItem(slot, item);
    }

    /**
     * Open the piece edit menu (45 slots).
     * Row 1: diamond preview (11), header (13), netherite preview (15).
     * Row 2: pattern (19), color (21), preview piece (23), preview full (25).
     * Row 3: clear trim (30), clear color (32).
     * Row 4: back (40).
     */
    public void openPieceEditMenu(Player player, ArmorPiece piece) {
        UUID uuid = player.getUniqueId();
        TrimConfig config = loadTrimConfig(uuid);
        TrimDesign currentDesign = config.getDesign(piece);
        TrimColor currentColor = config.getColor(piece);

        Inventory inv = Bukkit.createInventory(null, 45,
                mini.deserialize("<gradient:aqua:dark_aqua>Editar " + piece.getDisplayName() + "</gradient>"));

        fillBorders(inv, 45);

        // ═══ Row 1: Diamond preview + Header + Netherite preview ═══
        String designName = currentDesign != null ? currentDesign.getDisplayName() : "<gray>Ninguno";
        String colorName = currentColor != null ? currentColor.getColor() + currentColor.getDisplayName() : "<gray>Ninguno";

        // Piece header
        inv.setItem(11, createItem(Material.ANVIL, "<gradient:gold:yellow><bold>" + piece.getDisplayName() + "</bold></gradient>",
                List.of("",
                        "<dark_gray>▎ <gray>Edita el patrón y color",
                        "<dark_gray>▎ <gray>del trim para esta pieza.",
                        "")));

        // Armor preview — shows current trim on this piece
        ItemStack previewItem = createTrimmedItem(getDiamondMaterial(piece), currentDesign, currentColor);
        ItemMeta previewMeta = previewItem.getItemMeta();
        previewMeta.displayName(mini.deserialize("<aqua><bold>" + piece.getDisplayName()));
        previewMeta.lore(List.of(
                mini.deserialize(""),
                mini.deserialize("<dark_gray>▎ <yellow>Patrón: <white>" + designName),
                mini.deserialize("<dark_gray>▎ <yellow>Color: <white>" + colorName),
                mini.deserialize("")));
        previewItem.setItemMeta(previewMeta);
        inv.setItem(15, previewItem);

        // ═══ Row 2: Pattern + Color + Preview piece + Preview full ═══
        inv.setItem(19, createItem(Material.SMITHING_TABLE, "<yellow><bold>Patrón",
                List.of("",
                        "<dark_gray>▎ <gray>Actual: <white>" + designName,
                        "",
                        "<dark_gray>▎ <green>▶ Click para cambiar")));

        inv.setItem(21, createItem(currentColor != null ? currentColor.getIcon() : Material.GRAY_DYE,
                "<yellow><bold>Color",
                List.of("",
                        "<dark_gray>▎ <gray>Actual: <white>" + colorName,
                        "",
                        "<dark_gray>▎ <green>▶ Click para cambiar")));

        inv.setItem(23, createItem(Material.SPYGLASS, "<green>▶ Preview Pieza",
                List.of("",
                        "<dark_gray>▎ <gray>Prueba el trim en tu",
                        "<dark_gray>▎ <white>" + piece.getDisplayName(),
                        "<dark_gray>▎ <gray>durante 4 segundos.",
                        "")));

        inv.setItem(25, createItem(Material.ARMOR_STAND, "<green>▶ Preview Completa",
                List.of("",
                        "<dark_gray>▎ <gray>Prueba tus trims en las",
                        "<dark_gray>▎ <gray>4 piezas de armadura",
                        "<dark_gray>▎ <gray>durante 4 segundos.",
                        "")));

        // ═══ Row 3: Clear trim + Clear color ═══
        inv.setItem(30, createItem(Material.BARRIER, "<red>✘ Borrar Patrón",
                List.of("",
                        "<dark_gray>▎ <gray>Eliminar el patrón",
                        "<dark_gray>▎ <gray>de esta pieza.",
                        "")));

        inv.setItem(32, createItem(Material.BARRIER, "<red>✘ Borrar Color",
                List.of("",
                        "<dark_gray>▎ <gray>Eliminar el color",
                        "<dark_gray>▎ <gray>de esta pieza.",
                        "")));

        // ═══ Back ═══
        inv.setItem(40, createItem(Material.ARROW, "<red>← Volver", List.of()));

        player.openInventory(inv);
    }

    /**
     * Open the pattern selector (45 slots).
     * Layout: 18 patterns at content slots (10-16, 19-25, 28-31), remove at 34, back at 40.
     */
    public void openPatternSelector(Player player, ArmorPiece piece) {
        UUID uuid = player.getUniqueId();
        TrimConfig config = loadTrimConfig(uuid);
        TrimDesign currentDesign = config.getDesign(piece);

        Inventory inv = Bukkit.createInventory(null, 45,
                mini.deserialize("<gradient:yellow:gold>Seleccionar Patrón - " + piece.getDisplayName() + "</gradient>"));

        fillBorders(inv, 45);

        // Place 18 patterns across content slots
        TrimDesign[] designs = TrimDesign.values();
        int[] contentSlots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31};

        for (int i = 0; i < designs.length && i < contentSlots.length; i++) {
            TrimDesign design = designs[i];
            boolean selected = design == currentDesign;
            String prefix = selected ? "<green>✔ " : "<yellow>";
            String status = selected ? "<dark_gray>▎ <green>Seleccionado" : "<dark_gray>▎ <yellow>▶ Click para seleccionar";

            // Show smithing template icon (actual trim item, not trimmed armor)
            inv.setItem(contentSlots[i], createItem(design.getIcon(), prefix + design.getDisplayName(),
                    List.of("", status)));
        }

        // Remove pattern button
        inv.setItem(34, createItem(Material.BARRIER, "<red>✘ Quitar Patrón",
                List.of("", "<dark_gray>▎ <gray>Eliminar el patrón actual")));

        // Back button
        inv.setItem(40, createItem(Material.ARROW, "<red>← Volver", List.of()));

        player.openInventory(inv);
    }

    /**
     * Open the material/color selector (36 slots).
     * Layout: 10 colors at content slots (10-16, 19-21), remove at 25, back at 31.
     */
    public void openMaterialSelector(Player player, ArmorPiece piece) {
        UUID uuid = player.getUniqueId();
        TrimConfig config = loadTrimConfig(uuid);
        TrimColor currentColor = config.getColor(piece);

        Inventory inv = Bukkit.createInventory(null, 36,
                mini.deserialize("<gradient:yellow:gold>Seleccionar Color - " + piece.getDisplayName() + "</gradient>"));

        fillBorders(inv, 36);

        // Place 10 colors across content slots
        TrimColor[] colors = TrimColor.values();
        int[] contentSlots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21};

        TrimDesign currentDesign = config.getDesign(piece);
        TrimDesign displayDesign = currentDesign != null ? currentDesign : TrimDesign.COAST;
        Material armorMat = getDiamondMaterial(piece);

        for (int i = 0; i < colors.length && i < contentSlots.length; i++) {
            TrimColor color = colors[i];
            boolean selected = color == currentColor;
            String prefix = selected ? "<green>✔ " : color.getColor();
            String status = selected ? "<dark_gray>▎ <green>Seleccionado" : "<dark_gray>▎ <yellow>▶ Click para seleccionar";

            ItemStack colorItem = createTrimmedItem(armorMat, displayDesign, color);
            ItemMeta meta = colorItem.getItemMeta();
            if (meta != null) {
                meta.displayName(mini.deserialize(prefix + color.getDisplayName()));
                meta.lore(List.of(mini.deserialize(""), mini.deserialize(status)));
                colorItem.setItemMeta(meta);
            }
            inv.setItem(contentSlots[i], colorItem);
        }

        // Remove color button
        inv.setItem(25, createItem(Material.BARRIER, "<red>✘ Quitar Color",
                List.of("", "<dark_gray>▎ <gray>Eliminar el color actual")));

        // Back button
        inv.setItem(31, createItem(Material.ARROW, "<red>← Volver", List.of()));

        player.openInventory(inv);
    }

    // ═══════════════════════════════════════════════════════════════
    //                    SLOT INDEX MAPPING
    // ═══════════════════════════════════════════════════════════════

    /**
     * Map a pattern selector inventory slot to a TrimDesign array index.
     * Content slots: 10-16 (indices 0-6), 19-25 (7-13), 28-31 (14-17).
     * Returns -1 for non-content slots.
     */
    public int getPatternIndexFromSlot(int slot) {
        if (slot >= 10 && slot <= 16) return slot - 10;
        if (slot >= 19 && slot <= 25) return slot - 19 + 7;
        if (slot >= 28 && slot <= 31) return slot - 28 + 14;
        return -1;
    }

    /**
     * Map a color selector inventory slot to a TrimColor array index.
     * Content slots: 10-16 (indices 0-6), 19-21 (7-9).
     * Returns -1 for non-content slots.
     */
    public int getColorIndexFromSlot(int slot) {
        if (slot >= 10 && slot <= 16) return slot - 10;
        if (slot >= 19 && slot <= 21) return slot - 19 + 7;
        return -1;
    }

    // ═══════════════════════════════════════════════════════════════
    //                    DATA OPERATIONS
    // ═══════════════════════════════════════════════════════════════

    /**
     * Set a trim design for a specific piece.
     */
    public void setDesign(UUID uuid, ArmorPiece piece, TrimDesign design) {
        TrimConfig config = loadTrimConfig(uuid);
        config.setDesign(piece, design);
        trimCache.put(uuid, config);
    }

    /**
     * Set a trim color for a specific piece.
     */
    public void setColor(UUID uuid, ArmorPiece piece, TrimColor color) {
        TrimConfig config = loadTrimConfig(uuid);
        config.setColor(piece, color);
        trimCache.put(uuid, config);
    }

    /**
     * Remove all trims for a player.
     */
    public void clearTrims(UUID uuid) {
        trimCache.put(uuid, new TrimConfig());
        saveTrimConfig(uuid);
    }

    /**
     * Apply saved trim to an ItemStack.
     * Used when equipping armor in FFA/Duels.
     */
    public ItemStack applySavedTrimToItem(UUID uuid, ItemStack item, ArmorPiece piece) {
        if (item == null || item.getType().isAir()) return item;

        TrimConfig config = loadTrimConfig(uuid);
        TrimDesign design = config.getDesign(piece);
        TrimColor color = config.getColor(piece);

        if (design == null || color == null) return item; // No trim configured

        return applyTrim(item, design, color);
    }

    // ═══════════════════════════════════════════════════════════════
    //                    PREVIEW
    // ═══════════════════════════════════════════════════════════════

    /**
     * Start a live preview for a player (4 seconds / 80 ticks).
     */
    public void startPreview(Player player) {
        UUID uuid = player.getUniqueId();
        if (previewBackup.containsKey(uuid)) return;

        // Backup current armor
        ItemStack[] backup = new ItemStack[4];
        backup[0] = player.getInventory().getHelmet() != null ? player.getInventory().getHelmet().clone() : null;
        backup[1] = player.getInventory().getChestplate() != null ? player.getInventory().getChestplate().clone() : null;
        backup[2] = player.getInventory().getLeggings() != null ? player.getInventory().getLeggings().clone() : null;
        backup[3] = player.getInventory().getBoots() != null ? player.getInventory().getBoots().clone() : null;
        previewBackup.put(uuid, backup);

        // Apply trimmed preview using diamond armor
        TrimConfig config = loadTrimConfig(uuid);
        player.getInventory().setHelmet(createPreviewPiece(getDiamondMaterial(ArmorPiece.HELMET), config, ArmorPiece.HELMET));
        player.getInventory().setChestplate(createPreviewPiece(getDiamondMaterial(ArmorPiece.CHESTPLATE), config, ArmorPiece.CHESTPLATE));
        player.getInventory().setLeggings(createPreviewPiece(getDiamondMaterial(ArmorPiece.LEGGINGS), config, ArmorPiece.LEGGINGS));
        player.getInventory().setBoots(createPreviewPiece(getDiamondMaterial(ArmorPiece.BOOTS), config, ArmorPiece.BOOTS));

        player.sendMessage(mini.deserialize("<green>✦ Vista previa activa por 4 segundos..."));
        player.playSound(player.getLocation(), Sound.ITEM_ARMOR_EQUIP_DIAMOND, 0.7f, 1.2f);
        player.closeInventory();

        // Restore after 4 seconds (80 ticks)
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline()) {
                ItemStack[] b = previewBackup.remove(uuid);
                if (b != null) {
                    player.getInventory().setHelmet(b[0]);
                    player.getInventory().setChestplate(b[1]);
                    player.getInventory().setLeggings(b[2]);
                    player.getInventory().setBoots(b[3]);
                }
                player.sendMessage(mini.deserialize("<gray>Vista previa terminada."));
                openArmorSelector(player);
            }
        }, 80L);
    }

    /**
     * Start a live preview for a single armor piece (4 seconds / 80 ticks).
     */
    public void startPiecePreview(Player player, ArmorPiece piece) {
        UUID uuid = player.getUniqueId();
        if (previewBackup.containsKey(uuid)) return;

        // Backup current armor
        ItemStack[] backup = new ItemStack[4];
        backup[0] = player.getInventory().getHelmet() != null ? player.getInventory().getHelmet().clone() : null;
        backup[1] = player.getInventory().getChestplate() != null ? player.getInventory().getChestplate().clone() : null;
        backup[2] = player.getInventory().getLeggings() != null ? player.getInventory().getLeggings().clone() : null;
        backup[3] = player.getInventory().getBoots() != null ? player.getInventory().getBoots().clone() : null;
        previewBackup.put(uuid, backup);

        TrimConfig config = loadTrimConfig(uuid);
        Material armorMat = getDiamondMaterial(piece);
        ItemStack previewItem = createPreviewPiece(armorMat, config, piece);

        switch (piece) {
            case HELMET -> player.getInventory().setHelmet(previewItem);
            case CHESTPLATE -> player.getInventory().setChestplate(previewItem);
            case LEGGINGS -> player.getInventory().setLeggings(previewItem);
            case BOOTS -> player.getInventory().setBoots(previewItem);
        }

        player.sendMessage(mini.deserialize("<green>✦ Vista previa de " + piece.getDisplayName() + " activa por 4 segundos..."));
        player.playSound(player.getLocation(), Sound.ITEM_ARMOR_EQUIP_DIAMOND, 0.7f, 1.2f);
        player.closeInventory();

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline()) {
                ItemStack[] b = previewBackup.remove(uuid);
                if (b != null) {
                    player.getInventory().setHelmet(b[0]);
                    player.getInventory().setChestplate(b[1]);
                    player.getInventory().setLeggings(b[2]);
                    player.getInventory().setBoots(b[3]);
                }
                player.sendMessage(mini.deserialize("<gray>Vista previa terminada."));
                openPieceEditMenu(player, piece);
            }
        }, 80L);
    }

    // ═══════════════════════════════════════════════════════════════
    //                    INTERNAL HELPERS
    // ═══════════════════════════════════════════════════════════════

    /**
     * Apply a trim to an ItemStack.
     */
    private ItemStack applyTrim(ItemStack item, TrimDesign design, TrimColor color) {
        if (item == null) return null;
        ItemStack result = item.clone();
        if (result.getItemMeta() instanceof ArmorMeta armorMeta) {
            ArmorTrim trim = new ArmorTrim(color.getMaterial(), design.getPattern());
            armorMeta.setTrim(trim);
            result.setItemMeta(armorMeta);
        }
        return result;
    }

    /**
     * Create a trimmed display item for the GUI.
     */
    private ItemStack createTrimmedItem(Material base, TrimDesign design, TrimColor color) {
        ItemStack item = new ItemStack(base);
        if (design != null && color != null && item.getItemMeta() instanceof ArmorMeta armorMeta) {
            ArmorTrim trim = new ArmorTrim(color.getMaterial(), design.getPattern());
            armorMeta.setTrim(trim);
            item.setItemMeta(armorMeta);
        }
        return item;
    }

    private ItemStack createPreviewPiece(Material baseMat, TrimConfig config, ArmorPiece piece) {
        ItemStack item = new ItemStack(baseMat);
        TrimDesign design = config.getDesign(piece);
        TrimColor color = config.getColor(piece);
        if (design != null && color != null) {
            return applyTrim(item, design, color);
        }
        return item;
    }

    /**
     * Fill GUI borders with black stained glass and gold accent corners.
     */
    private void fillBorders(Inventory inv, int size) {
        ItemStack black = createItem(Material.BLACK_STAINED_GLASS_PANE, " ", null);
        ItemStack accent = createItem(Material.YELLOW_STAINED_GLASS_PANE, " ", null);

        for (int i = 0; i < size; i++) {
            if (i < 9 || i >= size - 9 || i % 9 == 0 || i % 9 == 8) {
                inv.setItem(i, black);
            }
        }
        // Gold accent corners
        inv.setItem(0, accent);
        inv.setItem(8, accent);
        inv.setItem(size - 9, accent);
        inv.setItem(size - 1, accent);
    }

    /**
     * Unload player data.
     */
    public void unloadPlayer(UUID uuid) {
        saveTrimConfig(uuid);
        trimCache.remove(uuid);
        previewBackup.remove(uuid);
    }

    /**
     * Helper to create a GUI item.
     */
    private ItemStack createItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(mini.deserialize(name));
        if (lore != null && !lore.isEmpty()) {
            List<Component> loreCmps = new ArrayList<>();
            for (String l : lore) loreCmps.add(mini.deserialize(l));
            meta.lore(loreCmps);
        }
        item.setItemMeta(meta);
        return item;
    }
}
