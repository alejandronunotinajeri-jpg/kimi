package com.ethernova.cosmetics;

import com.ethernova.cosmetics.api.CosmeticsAPI;
import com.ethernova.cosmetics.api.CosmeticsAPIImpl;
import com.ethernova.cosmetics.command.CosmeticsCommand;
import com.ethernova.cosmetics.aura.AdvancedAurasManager;
import com.ethernova.cosmetics.armortrim.ArmorTrimManager;
import com.ethernova.cosmetics.config.CosmeticsConfigManager;
import com.ethernova.cosmetics.effect.*;
import com.ethernova.cosmetics.listener.CosmeticListener;
import com.ethernova.cosmetics.manager.CosmeticRegistry;
import com.ethernova.cosmetics.manager.MysteryBoxManager;
import com.ethernova.cosmetics.manager.PlayerCosmeticManager;
import com.ethernova.core.EthernovaCore;
import com.ethernova.core.service.ServiceRegistry;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.logging.Level;

/**
 * Main plugin class for EthernovaCosmetics.
 * Provides a cosmetic system (trails, kill effects, projectile trails, win effects,
 * kill messages, death effects) integrated with the Ethernova ecosystem.
 */
public class EthernovaCosmetics extends JavaPlugin {

    private static volatile EthernovaCosmetics instance;

    private EthernovaCore core;
    private CosmeticsConfigManager configManager;
    private CosmeticRegistry cosmeticRegistry;
    private PlayerCosmeticManager playerCosmeticManager;
    private KillEffectHandler killEffectHandler;
    private TrailHandler trailHandler;
    private ProjectileTrailHandler projectileTrailHandler;
    private WinEffectHandler winEffectHandler;
    private MysteryBoxManager mysteryBoxManager;
    private TitleManager titleManager;
    private FinisherHandler finisherHandler;
    private PetManager petManager;
    private ElytraTrailHandler elytraTrailHandler;
    private DeathSoundHandler deathSoundHandler;
    private SkinManager skinManager;
    private AdvancedAurasManager advancedAurasManager;
    private HitEffectsManager hitEffectsManager;
    private ArmorTrimManager armorTrimManager;
    private com.ethernova.cosmetics.cache.CosmeticCache cosmeticCache;
    private CosmeticListener cosmeticListener;

    @Override
    public void onEnable() {
        instance = this;
        long start = System.currentTimeMillis();

        getLogger().info("═══════════════════════════════════════════");
        getLogger().info("  EthernovaCosmetics v" + getDescription().getVersion());
        getLogger().info("═══════════════════════════════════════════");

        try {
            // Phase 1: Core dependency
            core = (EthernovaCore) Bukkit.getPluginManager().getPlugin("EthernovaCore");
            if (core == null) {
                getLogger().severe("EthernovaCore no encontrado! Deshabilitando...");
                Bukkit.getPluginManager().disablePlugin(this);
                return;
            }
            core.registerPlugin("EthernovaCosmetics");

            // Phase 2: Configuration
            configManager = new CosmeticsConfigManager(this);
            configManager.loadAll();

            // Phase 3: Cosmetic Registry (loads from cosmetics.yml)
            cosmeticRegistry = new CosmeticRegistry(this);

            // Phase 4: Player Manager (needs DB via core)
            playerCosmeticManager = new PlayerCosmeticManager(
                    core.getStorageManager(), cosmeticRegistry, getLogger());

            // Phase 5: Effect Handlers
            killEffectHandler = new KillEffectHandler(this);
            trailHandler = new TrailHandler(this);
            projectileTrailHandler = new ProjectileTrailHandler(this);
            winEffectHandler = new WinEffectHandler(this);
            mysteryBoxManager = new MysteryBoxManager(this);
            titleManager = new TitleManager(this);
            finisherHandler = new FinisherHandler(this);
            petManager = new PetManager(this);
            elytraTrailHandler = new ElytraTrailHandler(this);
            deathSoundHandler = new DeathSoundHandler(this);
            skinManager = new SkinManager(this);
            advancedAurasManager = new AdvancedAurasManager(this);
            hitEffectsManager = new HitEffectsManager(this);
            armorTrimManager = new ArmorTrimManager(this);

            // Phase 5.5: Cosmetic Cache
            cosmeticCache = new com.ethernova.cosmetics.cache.CosmeticCache(this);

            // Phase 6: Start schedulers
            trailHandler.start();
            petManager.start();
            elytraTrailHandler.start();
            advancedAurasManager.start();

            // Phase 7: Listeners
            cosmeticListener = new CosmeticListener(this);
            Bukkit.getPluginManager().registerEvents(cosmeticListener, this);
            Bukkit.getPluginManager().registerEvents(projectileTrailHandler, this);

            // Phase 8: Commands
            registerCommands();

            // Phase 9: Public API
            ServiceRegistry.register(CosmeticsAPI.class, new CosmeticsAPIImpl(this));
            getLogger().info("✔ CosmeticsAPI registrada en ServiceRegistry");

            // Phase 9.1: ArmorTrimService for cross-module trim application
            ServiceRegistry.register(com.ethernova.core.service.ArmorTrimService.class,
                    (uuid, armor) -> {
                        if (armor == null || armorTrimManager == null) return armor;
                        // Bukkit armor order: [boots(0), leggings(1), chestplate(2), helmet(3)]
                        var pieces = com.ethernova.cosmetics.armortrim.ArmorTrimManager.ArmorPiece.values();
                        // Map: HELMET=slot39, CHESTPLATE=38, LEGGINGS=37, BOOTS=36
                        // Bukkit array: boots[0], leggings[1], chestplate[2], helmet[3]
                        if (armor.length >= 4) {
                            armor[3] = armorTrimManager.applySavedTrimToItem(uuid, armor[3],
                                    com.ethernova.cosmetics.armortrim.ArmorTrimManager.ArmorPiece.HELMET);
                            armor[2] = armorTrimManager.applySavedTrimToItem(uuid, armor[2],
                                    com.ethernova.cosmetics.armortrim.ArmorTrimManager.ArmorPiece.CHESTPLATE);
                            armor[1] = armorTrimManager.applySavedTrimToItem(uuid, armor[1],
                                    com.ethernova.cosmetics.armortrim.ArmorTrimManager.ArmorPiece.LEGGINGS);
                            armor[0] = armorTrimManager.applySavedTrimToItem(uuid, armor[0],
                                    com.ethernova.cosmetics.armortrim.ArmorTrimManager.ArmorPiece.BOOTS);
                        }
                        return armor;
                    });
            getLogger().info("✔ ArmorTrimService registrada en ServiceRegistry");

            // Phase 10: Load cosmetics for already-online players (for /reload support)
            for (var player : Bukkit.getOnlinePlayers()) {
                Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
                    playerCosmeticManager.loadPlayer(player.getUniqueId());
                    Bukkit.getScheduler().runTask(this, () -> {
                        if (player.isOnline()) {
                            trailHandler.registerTrail(player.getUniqueId());
                            titleManager.updateNametag(player);
                        }
                    });
                });
            }

            long elapsed = System.currentTimeMillis() - start;
            getLogger().info("═══════════════════════════════════════════");
            getLogger().info("  EthernovaCosmetics habilitado en " + elapsed + "ms");
            getLogger().info("═══════════════════════════════════════════");

        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Error habilitando EthernovaCosmetics", e);
            Bukkit.getPluginManager().disablePlugin(this);
        }
    }

    @Override
    public void onDisable() {
        // Cancel all scheduler tasks
        Bukkit.getScheduler().cancelTasks(this);

        // Stop effect handlers
        if (advancedAurasManager != null) advancedAurasManager.stop();
        if (trailHandler != null) trailHandler.stop();
        if (projectileTrailHandler != null) projectileTrailHandler.stopAll();
        if (petManager != null) petManager.stop();
        if (elytraTrailHandler != null) elytraTrailHandler.stop();

        // Unsubscribe from EventBus
        if (cosmeticListener != null) cosmeticListener.unsubscribe();

        // Save all loaded player data
        if (playerCosmeticManager != null) playerCosmeticManager.saveAll();

        // Shutdown cosmetic cache
        if (cosmeticCache != null) cosmeticCache.shutdown();

        // Unregister APIs
        ServiceRegistry.unregister(CosmeticsAPI.class);
        ServiceRegistry.unregister(com.ethernova.core.service.ArmorTrimService.class);

        // Unregister from core
        if (core != null) core.unregisterPlugin("EthernovaCosmetics");

        instance = null;
    }

    /**
     * Register all plugin commands.
     */
    private void registerCommands() {
        CosmeticsCommand cmd = new CosmeticsCommand(this);
        String[] cmds = {"cosmetics", "titles", "shop"};
        for (String name : cmds) {
            var c = getCommand(name);
            if (c != null) {
                c.setExecutor(cmd);
                c.setTabCompleter(cmd);
            }
        }
    }

    // ═══════════════ Getters ═══════════════

    public static EthernovaCosmetics getInstance() { return instance; }
    public EthernovaCore getCore() { return core; }
    public CosmeticsConfigManager getConfigManager() { return configManager; }
    public CosmeticRegistry getCosmeticRegistry() { return cosmeticRegistry; }
    public PlayerCosmeticManager getPlayerCosmeticManager() { return playerCosmeticManager; }
    public KillEffectHandler getKillEffectHandler() { return killEffectHandler; }
    public TrailHandler getTrailHandler() { return trailHandler; }
    public ProjectileTrailHandler getProjectileTrailHandler() { return projectileTrailHandler; }
    public WinEffectHandler getWinEffectHandler() { return winEffectHandler; }
    public MysteryBoxManager getMysteryBoxManager() { return mysteryBoxManager; }
    public TitleManager getTitleManager() { return titleManager; }
    public FinisherHandler getFinisherHandler() { return finisherHandler; }
    public PetManager getPetManager() { return petManager; }
    public ElytraTrailHandler getElytraTrailHandler() { return elytraTrailHandler; }
    public DeathSoundHandler getDeathSoundHandler() { return deathSoundHandler; }
    public SkinManager getSkinManager() { return skinManager; }
    public AdvancedAurasManager getAdvancedAurasManager() { return advancedAurasManager; }
    public HitEffectsManager getHitEffectsManager() { return hitEffectsManager; }
    public ArmorTrimManager getArmorTrimManager() { return armorTrimManager; }
    public CosmeticListener getCosmeticListener() { return cosmeticListener; }
    public com.ethernova.cosmetics.cache.CosmeticCache getCosmeticCache() { return cosmeticCache; }
}
