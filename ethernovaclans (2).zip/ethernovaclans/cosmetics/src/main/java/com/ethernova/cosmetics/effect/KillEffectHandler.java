package com.ethernova.cosmetics.effect;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.cosmetics.model.Cosmetic;
import com.ethernova.cosmetics.model.CosmeticType;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.UUID;

/**
 * Handles kill effects — spawns particles at the victim's death location
 * when the killer has a kill effect cosmetic equipped.
 */
public class KillEffectHandler {

    private final EthernovaCosmetics plugin;

    public KillEffectHandler(EthernovaCosmetics plugin) {
        this.plugin = plugin;
    }

    /**
     * Trigger the kill effect for the killer at the victim's death location.
     * Called from the event listener when a kill occurs.
     *
     * @param killerUuid UUID of the killer
     * @param victimLocation Location where the victim died
     */
    public void triggerKillEffect(UUID killerUuid, Location victimLocation) {
        if (killerUuid == null || victimLocation == null || victimLocation.getWorld() == null) return;

        String cosmeticId = plugin.getPlayerCosmeticManager().getEquipped(killerUuid, CosmeticType.KILL_EFFECT);
        if (cosmeticId == null) return;

        Cosmetic cosmetic = plugin.getCosmeticRegistry().getById(cosmeticId);
        if (cosmetic == null) return;

        // Already called from main thread (via runTask in CosmeticListener) — play directly
        playEffect(cosmeticId, victimLocation);
    }

    /**
     * Play the specific kill effect at the given location.
     */
    private void playEffect(String effectId, Location loc) {
        if (loc.getWorld() == null) return;

        switch (effectId.toLowerCase()) {
            case "lightning_strike", "lightning" -> playLightningStrike(loc);
            case "fire_burst", "fire" -> playFireBurst(loc);
            case "soul_burst", "ghost" -> playSoulBurst(loc);
            case "blood_splash", "blood" -> playBloodSplash(loc);
            case "ender_burst", "ender" -> playEnderBurst(loc);
            case "wither_storm", "wither" -> playWitherStorm(loc);
            case "ice_shatter" -> playIceShatter(loc);
            // ────── Original UltimateFFA kill effects ──────
            case "tnt" -> playTNT(loc);
            case "thief" -> playThief(loc);
            case "squid", "ink" -> playSquid(loc);
            case "firework", "fireworks" -> playFirework(loc);
            case "vortex" -> playVortex(loc);
            case "meteor" -> playMeteor(loc);
            case "zeus" -> playZeus(loc);
            case "holy_ray" -> playHolyRay(loc);
            case "pinata" -> playPinata(loc);
            case "launch" -> playLaunch(loc);
            case "tornado" -> playTornado(loc);
            case "sculk_explosion" -> playSculkExplosion(loc);
            case "warden_soul" -> playWardenSoul(loc);
            case "black_hole" -> playBlackHole(loc);
            case "alien" -> playAlien(loc);
            case "gravity" -> playGravity(loc);
            default -> { }
        }
    }

    /**
     * Lightning Strike: Visual lightning bolt and electric particles.
     */
    private void playLightningStrike(Location loc) {
        // Visual-only lightning (no damage)
        loc.getWorld().strikeLightningEffect(loc);

        // Additional electric particles
        loc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc.clone().add(0, 1, 0), 30, 0.5, 1.0, 0.5, 0.1);
        loc.getWorld().spawnParticle(Particle.FLASH, loc.clone().add(0, 0.5, 0), 2, 0, 0, 0, 0);
    }

    /**
     * Fire Burst: Explosion of fire and lava particles.
     */
    private void playFireBurst(Location loc) {
        loc.getWorld().spawnParticle(Particle.FLAME, loc.clone().add(0, 1, 0), 50, 0.8, 0.8, 0.8, 0.05);
        loc.getWorld().spawnParticle(Particle.LAVA, loc.clone().add(0, 0.5, 0), 20, 0.5, 0.5, 0.5, 0);
        loc.getWorld().spawnParticle(Particle.SMOKE, loc.clone().add(0, 1.5, 0), 15, 0.4, 0.6, 0.4, 0.02);

        // Delayed secondary burst
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (loc.getWorld() != null) {
                loc.getWorld().spawnParticle(Particle.FLAME, loc.clone().add(0, 1.5, 0), 30, 0.3, 0.5, 0.3, 0.08);
            }
        }, 5L);
    }

    /**
     * Soul Burst: Soul fire and sculk soul particles.
     */
    private void playSoulBurst(Location loc) {
        loc.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, loc.clone().add(0, 1, 0), 40, 0.6, 0.8, 0.6, 0.04);
        loc.getWorld().spawnParticle(Particle.SOUL, loc.clone().add(0, 1.5, 0), 15, 0.5, 0.5, 0.5, 0.02);
        loc.getWorld().spawnParticle(Particle.SCULK_SOUL, loc.clone().add(0, 0.5, 0), 10, 0.3, 0.3, 0.3, 0.01);

        // Ascending soul particles over time
        for (int i = 1; i <= 4; i++) {
            final int tick = i;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (loc.getWorld() != null) {
                    loc.getWorld().spawnParticle(Particle.SOUL, loc.clone().add(0, 1.0 + (tick * 0.5), 0),
                            5, 0.2, 0.1, 0.2, 0.01);
                }
            }, i * 4L);
        }
    }

    /**
     * Blood Splash: Red dust particles simulating blood.
     */
    private void playBloodSplash(Location loc) {
        Particle.DustOptions redDust = new Particle.DustOptions(Color.RED, 1.5f);
        Particle.DustOptions darkRedDust = new Particle.DustOptions(Color.fromRGB(139, 0, 0), 1.2f);

        loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 1, 0), 40, 0.8, 0.8, 0.8, 0, redDust);
        loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 0.5, 0), 25, 0.6, 0.3, 0.6, 0, darkRedDust);

        // Splatter effect on the ground
        for (int i = 0; i < 8; i++) {
            double angle = (Math.PI * 2 * i) / 8;
            double x = Math.cos(angle) * 1.5;
            double z = Math.sin(angle) * 1.5;
            loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(x, 0.1, z), 5, 0.1, 0.05, 0.1, 0, redDust);
        }
    }

    /**
     * Ender Burst: Enderman-style teleport particles.
     */
    private void playEnderBurst(Location loc) {
        loc.getWorld().spawnParticle(Particle.PORTAL, loc.clone().add(0, 1, 0), 80, 0.5, 1.0, 0.5, 0.5);
        loc.getWorld().spawnParticle(Particle.REVERSE_PORTAL, loc.clone().add(0, 1.5, 0), 40, 0.3, 0.5, 0.3, 0.1);
        loc.getWorld().spawnParticle(Particle.WITCH, loc.clone().add(0, 0.5, 0), 20, 0.5, 0.5, 0.5, 0);

        // Expanding ring of ender particles
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (loc.getWorld() == null) return;
            for (int i = 0; i < 16; i++) {
                double angle = (Math.PI * 2 * i) / 16;
                double x = Math.cos(angle) * 2.0;
                double z = Math.sin(angle) * 2.0;
                loc.getWorld().spawnParticle(Particle.PORTAL, loc.clone().add(x, 0.5, z), 10, 0.1, 0.3, 0.1, 0.2);
            }
        }, 5L);
    }

    /**
     * Wither Storm: Dark wither skulls and smoke cloud.
     */
    private void playWitherStorm(Location loc) {
        // Dark smoke cloud
        loc.getWorld().spawnParticle(Particle.LARGE_SMOKE, loc.clone().add(0, 1, 0), 35, 0.8, 0.8, 0.8, 0.02);
        loc.getWorld().spawnParticle(Particle.SMOKE, loc.clone().add(0, 0.5, 0), 50, 1.0, 0.5, 1.0, 0.05);

        // Wither effect particles in expanding ring
        for (int i = 0; i < 3; i++) {
            final int tick = i;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (loc.getWorld() == null) return;
                double radius = 1.0 + tick * 0.8;
                for (int j = 0; j < 12; j++) {
                    double angle = (Math.PI * 2 * j) / 12;
                    double x = Math.cos(angle) * radius;
                    double z = Math.sin(angle) * radius;
                    loc.getWorld().spawnParticle(Particle.SMOKE, loc.clone().add(x, 0.5 + tick * 0.3, z), 3, 0.1, 0.1, 0.1, 0.01);
                }
                Particle.DustOptions witherDust = new Particle.DustOptions(Color.fromRGB(30, 30, 30), 1.5f);
                loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 1 + tick * 0.5, 0), 15, 0.5, 0.3, 0.5, 0, witherDust);
            }, i * 5L);
        }
    }

    /**
     * Ice Shatter: Freeze and shatter into ice crystals.
     */
    private void playIceShatter(Location loc) {
        // Initial freeze burst
        Particle.DustOptions iceDust = new Particle.DustOptions(Color.fromRGB(180, 220, 255), 1.5f);
        loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 1, 0), 40, 0.5, 0.8, 0.5, 0, iceDust);
        loc.getWorld().spawnParticle(Particle.SNOWFLAKE, loc.clone().add(0, 1, 0), 30, 0.6, 0.6, 0.6, 0.02);

        // Shatter outward after brief delay
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (loc.getWorld() == null) return;
            loc.getWorld().spawnParticle(Particle.BLOCK, loc.clone().add(0, 1, 0), 50, 0.8, 0.8, 0.8, 0.1,
                    org.bukkit.Material.BLUE_ICE.createBlockData());
            Particle.DustOptions shardDust = new Particle.DustOptions(Color.fromRGB(140, 200, 255), 0.8f);
            for (int i = 0; i < 16; i++) {
                double angle = (Math.PI * 2 * i) / 16;
                double x = Math.cos(angle) * 2.0;
                double z = Math.sin(angle) * 2.0;
                loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(x, 0.5, z), 3, 0.1, 0.2, 0.1, 0, shardDust);
            }
        }, 8L);
    }

    /**
     * Preview a kill effect — spawns a Test Dummy zombie in front of the player,
     * then plays the effect after 1.5 seconds. Zombie removed after 5s.
     */
    public void preview(Player player, String effectId) {
        if (player == null || effectId == null) return;

        // Close GUI so the player can see the effect clearly
        player.closeInventory();

        Location playerLoc = player.getLocation();
        // Spawn zombie 3 blocks in front for better visibility
        Vector forward = playerLoc.getDirection().normalize().multiply(3);
        Location spawnLoc = playerLoc.clone().add(forward);
        spawnLoc.setY(playerLoc.getY());

        org.bukkit.entity.Zombie dummy = player.getWorld().spawn(spawnLoc, org.bukkit.entity.Zombie.class, zombie -> {
            zombie.setAI(false);
            zombie.setSilent(true);
            zombie.setInvulnerable(true);
            zombie.customName(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                    .deserialize("<red><bold>Test Dummy"));
            zombie.setCustomNameVisible(true);
            zombie.setAdult();
            org.bukkit.inventory.ItemStack helmet = new org.bukkit.inventory.ItemStack(Material.DIAMOND_HELMET);
            zombie.getEquipment().setHelmet(helmet);
            zombie.getEquipment().setHelmetDropChance(0f);
        });

        player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .deserialize("<gray>▸ Previsualizando efecto..."));

        // After 1.5 seconds, play the effect at the zombie location
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (dummy.isValid()) {
                playEffect(effectId, dummy.getLocation());
            }
        }, 30L);

        // Remove zombie after 5 seconds (enough time for all effects to finish)
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (dummy.isValid()) {
                dummy.remove();
                player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                        .deserialize("<gray>▸ Preview terminada."));
            }
        }, 100L);
    }

    // ═══════════════════════════════════════════════════════════════
    //    NEW KILL EFFECTS — Ported from original UltimateFFA
    // ═══════════════════════════════════════════════════════════════

    /** TNT: Explosion without damage + flying blocks. */
    private void playTNT(Location loc) {
        loc.getWorld().spawnParticle(Particle.EXPLOSION, loc.clone().add(0, 1, 0), 5, 0.5, 0.5, 0.5, 0);
        loc.getWorld().spawnParticle(Particle.SMOKE, loc, 30, 1.0, 0.5, 1.0, 0.05);
        loc.getWorld().spawnParticle(Particle.FLAME, loc.clone().add(0, 0.5, 0), 20, 0.8, 0.5, 0.8, 0.03);
        loc.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 0.8f);
    }

    /** Thief: Fake item rain (emerald particles). */
    private void playThief(Location loc) {
        Particle.DustOptions gold = new Particle.DustOptions(Color.fromRGB(255, 215, 0), 1.2f);
        Particle.DustOptions green = new Particle.DustOptions(Color.fromRGB(0, 200, 80), 1.2f);
        for (int i = 0; i < 3; i++) {
            final int t = i;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (loc.getWorld() == null) return;
                loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 2 + t, 0), 15, 0.8, 0.3, 0.8, 0, gold);
                loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 1.5 + t, 0), 10, 0.5, 0.3, 0.5, 0, green);
                loc.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, loc.clone().add(0, 1 + t, 0), 5, 0.5, 0.3, 0.5, 0);
            }, t * 5L);
        }
        loc.getWorld().playSound(loc, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.5f, 1.0f);
    }

    /** Squid: Ink explosion. */
    private void playSquid(Location loc) {
        loc.getWorld().spawnParticle(Particle.SQUID_INK, loc.clone().add(0, 1, 0), 40, 0.8, 0.8, 0.8, 0.05);
        Particle.DustOptions inkDust = new Particle.DustOptions(Color.fromRGB(10, 10, 20), 1.5f);
        loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 0.5, 0), 20, 1.0, 0.5, 1.0, 0, inkDust);
        loc.getWorld().playSound(loc, Sound.ENTITY_SQUID_SQUIRT, 1.5f, 0.8f);
    }

    /** Firework: Random firework burst. */
    private void playFirework(Location loc) {
        org.bukkit.entity.Firework fw = loc.getWorld().spawn(loc.clone().add(0, 1, 0), org.bukkit.entity.Firework.class);
        org.bukkit.inventory.meta.FireworkMeta meta = fw.getFireworkMeta();
        meta.addEffect(org.bukkit.FireworkEffect.builder()
                .with(org.bukkit.FireworkEffect.Type.BALL_LARGE)
                .withColor(Color.RED, Color.BLUE, Color.YELLOW, Color.LIME)
                .withFade(Color.WHITE).trail(true).flicker(true).build());
        meta.setPower(0);
        fw.setFireworkMeta(meta);
        Bukkit.getScheduler().runTaskLater(plugin, fw::detonate, 2L);
    }

    /** Vortex: Inward-spiraling particles. */
    private void playVortex(Location loc) {
        for (int i = 0; i < 5; i++) {
            final int t = i;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (loc.getWorld() == null) return;
                double radius = 3.0 - (t * 0.5);
                for (int j = 0; j < 16; j++) {
                    double angle = (Math.PI * 2 * j) / 16 + (t * 0.5);
                    double x = Math.cos(angle) * radius;
                    double z = Math.sin(angle) * radius;
                    loc.getWorld().spawnParticle(Particle.PORTAL, loc.clone().add(x, 0.3 + t * 0.3, z), 3, 0.05, 0.05, 0.05, 0.1);
                }
            }, t * 3L);
        }
        loc.getWorld().playSound(loc, Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 0.5f);
    }

    /** Meteor: Fire charge falls from the sky. */
    private void playMeteor(Location loc) {
        for (int i = 0; i < 5; i++) {
            final int t = i;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (loc.getWorld() == null) return;
                Location high = loc.clone().add(0, 10 - (t * 2), 0);
                loc.getWorld().spawnParticle(Particle.FLAME, high, 15, 0.3, 0.3, 0.3, 0.05);
                loc.getWorld().spawnParticle(Particle.LARGE_SMOKE, high, 8, 0.2, 0.2, 0.2, 0.02);
            }, t * 3L);
        }
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (loc.getWorld() == null) return;
            loc.getWorld().spawnParticle(Particle.EXPLOSION, loc.clone().add(0, 1, 0), 3, 0.3, 0.3, 0.3, 0);
            loc.getWorld().spawnParticle(Particle.LAVA, loc, 15, 1.0, 0.5, 1.0, 0);
            loc.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 0.7f);
        }, 16L);
    }

    /** Zeus: 5 consecutive lightning strikes. */
    private void playZeus(Location loc) {
        for (int i = 0; i < 5; i++) {
            final int t = i;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (loc.getWorld() == null) return;
                double ox = (Math.random() - 0.5) * 3;
                double oz = (Math.random() - 0.5) * 3;
                loc.getWorld().strikeLightningEffect(loc.clone().add(ox, 0, oz));
            }, t * 4L);
        }
    }

    /** Holy Ray: Beacon beam + angelic choir. */
    private void playHolyRay(Location loc) {
        for (int i = 0; i < 8; i++) {
            final int t = i;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (loc.getWorld() == null) return;
                Location up = loc.clone().add(0, t * 1.5, 0);
                Particle.DustOptions gold = new Particle.DustOptions(Color.fromRGB(255, 255, 150), 1.5f);
                loc.getWorld().spawnParticle(Particle.DUST, up, 10, 0.2, 0.1, 0.2, 0, gold);
                loc.getWorld().spawnParticle(Particle.END_ROD, up, 5, 0.15, 0.1, 0.15, 0.02);
            }, t * 2L);
        }
        loc.getWorld().playSound(loc, Sound.BLOCK_BEACON_ACTIVATE, 1.5f, 1.5f);
    }

    /** Pinata: Color explosion burst. */
    private void playPinata(Location loc) {
        Color[] colors = {Color.RED, Color.BLUE, Color.YELLOW, Color.LIME, Color.FUCHSIA, Color.AQUA, Color.ORANGE};
        for (Color c : colors) {
            Particle.DustOptions dust = new Particle.DustOptions(c, 1.5f);
            loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 1.5, 0), 8, 1.2, 0.8, 1.2, 0, dust);
        }
        loc.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, loc.clone().add(0, 1, 0), 50, 0.8, 0.8, 0.8, 0.3);
        loc.getWorld().playSound(loc, Sound.ENTITY_PLAYER_LEVELUP, 1.5f, 1.5f);
    }

    /** Launch: Victim flies upward. */
    private void playLaunch(Location loc) {
        for (int i = 0; i < 6; i++) {
            final int t = i;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (loc.getWorld() == null) return;
                loc.getWorld().spawnParticle(Particle.CLOUD, loc.clone().add(0, t * 1.5, 0), 8, 0.3, 0.2, 0.3, 0.02);
                loc.getWorld().spawnParticle(Particle.FLAME, loc.clone().add(0, t * 1.5, 0), 5, 0.2, 0.1, 0.2, 0.03);
            }, t * 3L);
        }
        loc.getWorld().playSound(loc, Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 1.5f, 0.8f);
    }

    /** Tornado: Massive spiral of wind. */
    private void playTornado(Location loc) {
        for (int i = 0; i < 8; i++) {
            final int t = i;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (loc.getWorld() == null) return;
                double radius = 0.5 + t * 0.3;
                for (int j = 0; j < 12; j++) {
                    double angle = (Math.PI * 2 * j) / 12 + (t * 0.8);
                    double x = Math.cos(angle) * radius;
                    double z = Math.sin(angle) * radius;
                    loc.getWorld().spawnParticle(Particle.CLOUD, loc.clone().add(x, t * 0.5, z), 1, 0.05, 0.05, 0.05, 0);
                }
            }, t * 2L);
        }
        loc.getWorld().playSound(loc, Sound.ENTITY_PHANTOM_FLAP, 1.5f, 0.5f);
    }

    /** Sculk Explosion: Warden darkness burst. */
    private void playSculkExplosion(Location loc) {
        loc.getWorld().spawnParticle(Particle.SCULK_CHARGE_POP, loc.clone().add(0, 1, 0), 40, 0.8, 0.8, 0.8, 0.02);
        loc.getWorld().spawnParticle(Particle.SCULK_SOUL, loc.clone().add(0, 0.5, 0), 20, 0.5, 0.5, 0.5, 0.01);
        Particle.DustOptions dark = new Particle.DustOptions(Color.fromRGB(5, 5, 15), 2.0f);
        loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 1, 0), 25, 1.0, 0.8, 1.0, 0, dark);
        loc.getWorld().playSound(loc, Sound.ENTITY_WARDEN_SONIC_BOOM, 0.8f, 0.5f);
    }

    /** Warden Soul: Sonic boom particles. */
    private void playWardenSoul(Location loc) {
        loc.getWorld().spawnParticle(Particle.SONIC_BOOM, loc.clone().add(0, 1, 0), 1, 0, 0, 0, 0);
        loc.getWorld().spawnParticle(Particle.SCULK_SOUL, loc.clone().add(0, 1.5, 0), 15, 0.5, 0.5, 0.5, 0.02);
        for (int i = 1; i <= 3; i++) {
            final int t = i;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (loc.getWorld() == null) return;
                loc.getWorld().spawnParticle(Particle.SCULK_SOUL, loc.clone().add(0, 1 + t * 0.5, 0), 8, 0.3, 0.2, 0.3, 0.01);
            }, t * 5L);
        }
        loc.getWorld().playSound(loc, Sound.ENTITY_WARDEN_SONIC_BOOM, 1.0f, 1.0f);
    }

    /** Black Hole: Space collapse effect. */
    private void playBlackHole(Location loc) {
        for (int i = 0; i < 6; i++) {
            final int t = i;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (loc.getWorld() == null) return;
                double radius = 4.0 - (t * 0.6);
                for (int j = 0; j < 20; j++) {
                    double angle = (Math.PI * 2 * j) / 20;
                    double x = Math.cos(angle) * radius;
                    double z = Math.sin(angle) * radius;
                    Particle.DustOptions d = new Particle.DustOptions(Color.fromRGB(20 + t * 5, 0, 30 + t * 5), 1.0f);
                    loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(x, 1, z), 2, 0.05, 0.05, 0.05, 0, d);
                }
            }, t * 3L);
        }
        loc.getWorld().spawnParticle(Particle.REVERSE_PORTAL, loc.clone().add(0, 1, 0), 60, 0.3, 0.3, 0.3, 0.5);
        loc.getWorld().playSound(loc, Sound.ENTITY_ENDERMAN_TELEPORT, 1.5f, 0.3f);
    }

    /** Alien: Tractor beam abduction. */
    private void playAlien(Location loc) {
        for (int i = 0; i < 8; i++) {
            final int t = i;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (loc.getWorld() == null) return;
                double radius = 1.5 - (t * 0.15);
                Location up = loc.clone().add(0, t * 1.2, 0);
                Particle.DustOptions beam = new Particle.DustOptions(Color.fromRGB(100, 255, 100), 1.2f);
                for (int j = 0; j < 8; j++) {
                    double angle = (Math.PI * 2 * j) / 8;
                    double x = Math.cos(angle) * radius;
                    double z = Math.sin(angle) * radius;
                    loc.getWorld().spawnParticle(Particle.DUST, up.clone().add(x, 0, z), 2, 0.05, 0.1, 0.05, 0, beam);
                }
            }, t * 2L);
        }
        loc.getWorld().spawnParticle(Particle.END_ROD, loc.clone().add(0, 1, 0), 20, 0.1, 3, 0.1, 0.01);
        loc.getWorld().playSound(loc, Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 2.0f);
    }

    /** Gravity: Zero-gravity floating particles. */
    private void playGravity(Location loc) {
        for (int i = 0; i < 5; i++) {
            final int t = i;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (loc.getWorld() == null) return;
                for (int j = 0; j < 10; j++) {
                    double ox = (Math.random() - 0.5) * 3;
                    double oy = Math.random() * 1.5;
                    double oz = (Math.random() - 0.5) * 3;
                    loc.getWorld().spawnParticle(Particle.END_ROD, loc.clone().add(ox, oy + t * 0.5, oz), 1, 0, 0.1, 0, 0.01);
                    loc.getWorld().spawnParticle(Particle.CLOUD, loc.clone().add(ox, oy + t * 0.3, oz), 1, 0, 0.05, 0, 0.005);
                }
            }, t * 4L);
        }
        loc.getWorld().playSound(loc, Sound.ENTITY_SHULKER_SHOOT, 1.0f, 0.5f);
    }
}
