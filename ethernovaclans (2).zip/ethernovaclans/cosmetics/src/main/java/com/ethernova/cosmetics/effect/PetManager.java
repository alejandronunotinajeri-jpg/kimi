package com.ethernova.cosmetics.effect;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.cosmetics.model.CosmeticType;
import com.ethernova.core.event.CombatTagChangeEvent;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages cosmetic pets — real entity mobs that follow players around.
 * Supports 32 pet categories with variants (colors, age, styles).
 * Ported faithfully from original UltimateFFA PetManager.
 */
public class PetManager {

    private static final String PET_TAG = "ethernova_pet";
    private static final double FOLLOW_DISTANCE = 3.0;
    private static final double TELEPORT_DISTANCE = 20.0;

    private final EthernovaCosmetics plugin;
    private final Map<UUID, Entity> activePets = new ConcurrentHashMap<>();
    private final Map<UUID, Boolean> petOnHead = new ConcurrentHashMap<>();
    private final Set<UUID> combatHiddenPets = ConcurrentHashMap.newKeySet();
    private int taskId = -1;

    public PetManager(EthernovaCosmetics plugin) {
        this.plugin = plugin;

        // Subscribe to combat tag changes — hide pets during combat
        plugin.getCore().getEventBus().subscribe(CombatTagChangeEvent.class, this::onCombatTagChange);
    }

    /**
     * Handle combat tag state changes: remove pet on combat entry, restore on exit.
     */
    private void onCombatTagChange(CombatTagChangeEvent event) {
        UUID uuid = event.playerUuid();
        if (event.tagged()) {
            // Entering combat — hide pet if active
            if (activePets.containsKey(uuid)) {
                combatHiddenPets.add(uuid);
                Bukkit.getScheduler().runTask(plugin, () -> removePet(uuid));
            }
        } else {
            // Leaving combat — restore pet if it was hidden
            if (combatHiddenPets.remove(uuid)) {
                Player player = Bukkit.getPlayer(uuid);
                if (player != null && player.isOnline()) {
                    Bukkit.getScheduler().runTask(plugin, () -> restorePet(player));
                }
            }
        }
    }

    public void start() {
        taskId = Bukkit.getScheduler().scheduleSyncRepeatingTask(plugin, () -> {
            List<UUID> toRemove = new ArrayList<>();
            for (var entry : activePets.entrySet()) {
                Player player = Bukkit.getPlayer(entry.getKey());
                Entity pet = entry.getValue();
                if (player == null || !player.isOnline() || pet == null || pet.isDead()) {
                    toRemove.add(entry.getKey());
                    continue;
                }
                if (petOnHead.getOrDefault(entry.getKey(), false)) continue;

                Location petLoc = pet.getLocation();
                Location playerLoc = player.getLocation();
                double dist = petLoc.distanceSquared(playerLoc);

                if (dist > TELEPORT_DISTANCE * TELEPORT_DISTANCE) {
                    // Ensure pet is not sitting before teleporting
                    if (pet instanceof org.bukkit.entity.Sittable sittable && sittable.isSitting()) {
                        sittable.setSitting(false);
                    }
                    pet.teleport(playerLoc.clone().add(-1.5, 0, -1.5));
                } else if (dist > FOLLOW_DISTANCE * FOLLOW_DISTANCE) {
                    // Ensure pet is not sitting before moving
                    if (pet instanceof org.bukkit.entity.Sittable sittable && sittable.isSitting()) {
                        sittable.setSitting(false);
                    }
                    if (pet instanceof Mob mob) {
                        mob.getPathfinder().moveTo(playerLoc, 1.2);
                    } else {
                        double dx = playerLoc.getX() - petLoc.getX();
                        double dz = playerLoc.getZ() - petLoc.getZ();
                        double len = Math.sqrt(dx * dx + dz * dz);
                        Location newLoc = petLoc.clone().add((dx / len) * 0.3, 0, (dz / len) * 0.3);
                        newLoc.setY(playerLoc.getY());
                        pet.teleport(newLoc);
                    }
                }
            }
            // Remove invalid pets after iteration to avoid ConcurrentModificationException
            toRemove.forEach(this::removePet);
        }, 2L, 4L);
    }

    public void stop() {
        if (taskId != -1) {
            Bukkit.getScheduler().cancelTask(taskId);
            taskId = -1;
        }
        for (Entity pet : activePets.values()) {
            if (pet != null && !pet.isDead()) pet.remove();
        }
        activePets.clear();
        petOnHead.clear();
        combatHiddenPets.clear();
    }

    /**
     * Preview a pet — temporarily spawn for 5 seconds.
     */
    public void preview(Player player, String petId) {
        if (player == null || petId == null) return;
        removePet(player.getUniqueId());
        Entity pet = spawnPetEntity(player, petId);
        if (pet != null) {
            activePets.put(player.getUniqueId(), pet);
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (pet.isValid() && !pet.isDead()) {
                    pet.remove();
                    activePets.remove(player.getUniqueId());
                }
            }, 100L);
        }
    }

    public void spawnPet(Player player) {
        String petId = plugin.getPlayerCosmeticManager().getEquipped(player.getUniqueId(), CosmeticType.PET);
        if (petId == null) return;
        removePet(player.getUniqueId());
        Entity pet = spawnPetEntity(player, petId);
        if (pet != null) activePets.put(player.getUniqueId(), pet);
    }

    private Entity spawnPetEntity(Player player, String petId) {
        Location loc = player.getLocation().add(-1.5, 0, -1.5);
        String id = petId.toLowerCase().replace("pet_", "");
        boolean baby = id.endsWith("_baby");
        if (baby) id = id.substring(0, id.length() - 5);

        String type, variant = "default";
        // Handle multi-word types
        if (id.startsWith("iron_golem")) { type = "iron_golem"; variant = id.length() > 10 ? id.substring(11) : "default"; }
        else if (id.startsWith("polar_bear")) { type = "polar_bear"; variant = id.length() > 10 ? id.substring(11) : "default"; }
        else if (id.startsWith("snow_golem")) { type = "snow_golem"; variant = id.length() > 10 ? id.substring(11) : "default"; }
        else {
            int idx = id.indexOf('_');
            if (idx > 0) { type = id.substring(0, idx); variant = id.substring(idx + 1); }
            else { type = id; }
        }

        Entity entity = switch (type) {
            case "chicken" -> spawnMob(loc, EntityType.CHICKEN);
            case "pig" -> spawnMob(loc, EntityType.PIG);
            case "cow" -> spawnMob(loc, EntityType.COW);
            case "sheep" -> spawnMob(loc, EntityType.SHEEP);
            case "rabbit" -> spawnRabbit(loc, variant);
            case "slime" -> spawnSlime(loc);
            case "frog" -> spawnFrog(loc, variant);
            case "bee" -> spawnMob(loc, EntityType.BEE);
            case "turtle" -> spawnMob(loc, EntityType.TURTLE);
            case "cat" -> spawnCat(loc, variant);
            case "parrot" -> spawnParrot(loc, variant);
            case "wolf" -> spawnMob(loc, EntityType.WOLF);
            case "fox" -> spawnFox(loc, variant);
            case "panda" -> spawnPanda(loc, variant);
            case "polar_bear" -> spawnMob(loc, EntityType.POLAR_BEAR);
            case "llama" -> spawnLlama(loc, variant);
            case "axolotl" -> spawnAxolotl(loc, variant);
            case "allay" -> spawnMob(loc, EntityType.ALLAY);
            case "vex" -> spawnMob(loc, EntityType.VEX);
            case "snow_golem", "snowman" -> spawnMob(loc, EntityType.SNOW_GOLEM);
            case "zombie" -> spawnZombie(loc, variant);
            case "skeleton" -> spawnMob(loc, EntityType.SKELETON);
            case "strider" -> spawnMob(loc, EntityType.STRIDER);
            case "camel" -> spawnMob(loc, EntityType.CAMEL);
            case "sniffer" -> spawnMob(loc, EntityType.SNIFFER);
            case "phantom" -> spawnPhantom(loc);
            case "iron_golem" -> spawnMob(loc, EntityType.IRON_GOLEM);
            case "ravager" -> spawnMob(loc, EntityType.RAVAGER);
            case "warden" -> spawnWarden(loc);
            case "wither" -> spawnWither(loc, variant);
            case "giant" -> spawnGiant(loc);
            default -> spawnMob(loc, EntityType.CHICKEN);
        };

        if (entity == null) return null;
        if (baby && entity instanceof Ageable ageable) ageable.setBaby();
        configureEntity(entity, player);
        return entity;
    }

    private void configureEntity(Entity entity, Player player) {
        entity.setInvulnerable(true);
        entity.setSilent(true);
        entity.setPersistent(false);
        entity.addScoreboardTag(PET_TAG);
        entity.setMetadata("pet_owner", new FixedMetadataValue(plugin, player.getUniqueId().toString()));
        if (entity instanceof LivingEntity living) {
            living.setCollidable(false);
            living.setRemoveWhenFarAway(false);
            living.setCanPickupItems(false);
        }
        if (entity instanceof Mob mob) {
            mob.setAware(true);
            mob.setTarget(null);
        }
        if (entity instanceof Monster monster) monster.setTarget(null);
        // Prevent tamed entities from sitting (cats, wolves, parrots, foxes)
        if (entity instanceof org.bukkit.entity.Sittable sittable) {
            sittable.setSitting(false);
        }
        // For tameable entities, set owner so pathfinder works properly
        if (entity instanceof org.bukkit.entity.Tameable tameable) {
            tameable.setTamed(true);
            tameable.setOwner(player);
        }
    }

    private Entity spawnMob(Location loc, EntityType type) {
        try { return loc.getWorld().spawnEntity(loc, type); }
        catch (Exception e) {
            plugin.getLogger().warning("[Pets] Failed to spawn mob " + type + " at " + loc + ": " + e.getMessage());
            return null;
        }
    }

    private Entity spawnCat(Location loc, String variant) {
        Cat cat = (Cat) loc.getWorld().spawnEntity(loc, EntityType.CAT);
        try {
            Cat.Type ct = switch (variant.toLowerCase()) {
                case "black" -> Cat.Type.BLACK;
                case "british_shorthair", "british" -> Cat.Type.BRITISH_SHORTHAIR;
                case "calico" -> Cat.Type.CALICO;
                case "jellie" -> Cat.Type.JELLIE;
                case "persian" -> Cat.Type.PERSIAN;
                case "ragdoll" -> Cat.Type.RAGDOLL;
                case "red" -> Cat.Type.RED;
                case "siamese" -> Cat.Type.SIAMESE;
                case "white" -> Cat.Type.WHITE;
                case "all_black" -> Cat.Type.ALL_BLACK;
                default -> Cat.Type.TABBY;
            };
            cat.setCatType(ct);
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to set cat variant '" + variant + "': " + e.getMessage());
        }
        return cat;
    }

    private Entity spawnParrot(Location loc, String variant) {
        Parrot parrot = (Parrot) loc.getWorld().spawnEntity(loc, EntityType.PARROT);
        try {
            Parrot.Variant pv = switch (variant.toLowerCase()) {
                case "blue" -> Parrot.Variant.BLUE;
                case "green" -> Parrot.Variant.GREEN;
                case "cyan" -> Parrot.Variant.CYAN;
                case "gray", "grey" -> Parrot.Variant.GRAY;
                default -> Parrot.Variant.RED;
            };
            parrot.setVariant(pv);
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to set parrot variant '" + variant + "': " + e.getMessage());
        }
        return parrot;
    }

    private Entity spawnRabbit(Location loc, String variant) {
        Rabbit rabbit = (Rabbit) loc.getWorld().spawnEntity(loc, EntityType.RABBIT);
        try {
            Rabbit.Type rt = switch (variant.toLowerCase()) {
                case "white" -> Rabbit.Type.WHITE;
                case "black" -> Rabbit.Type.BLACK;
                case "black_and_white" -> Rabbit.Type.BLACK_AND_WHITE;
                case "gold" -> Rabbit.Type.GOLD;
                case "salt_and_pepper" -> Rabbit.Type.SALT_AND_PEPPER;
                case "the_killer_bunny", "killer" -> Rabbit.Type.THE_KILLER_BUNNY;
                default -> Rabbit.Type.BROWN;
            };
            rabbit.setRabbitType(rt);
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to set rabbit variant '" + variant + "': " + e.getMessage());
        }
        return rabbit;
    }

    private Entity spawnFox(Location loc, String variant) {
        Fox fox = (Fox) loc.getWorld().spawnEntity(loc, EntityType.FOX);
        fox.setFoxType("snow".equalsIgnoreCase(variant) ? Fox.Type.SNOW : Fox.Type.RED);
        return fox;
    }

    private Entity spawnPanda(Location loc, String variant) {
        Panda panda = (Panda) loc.getWorld().spawnEntity(loc, EntityType.PANDA);
        try {
            Panda.Gene gene = switch (variant.toLowerCase()) {
                case "lazy" -> Panda.Gene.LAZY; case "worried" -> Panda.Gene.WORRIED;
                case "playful" -> Panda.Gene.PLAYFUL; case "brown" -> Panda.Gene.BROWN;
                case "weak" -> Panda.Gene.WEAK; case "aggressive" -> Panda.Gene.AGGRESSIVE;
                default -> Panda.Gene.NORMAL;
            };
            panda.setMainGene(gene); panda.setHiddenGene(gene);
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to set panda variant '" + variant + "': " + e.getMessage());
        }
        return panda;
    }

    private Entity spawnLlama(Location loc, String variant) {
        Llama llama = (Llama) loc.getWorld().spawnEntity(loc, EntityType.LLAMA);
        try {
            Llama.Color color = switch (variant.toLowerCase()) {
                case "white" -> Llama.Color.WHITE; case "brown" -> Llama.Color.BROWN;
                case "gray", "grey" -> Llama.Color.GRAY; default -> Llama.Color.CREAMY;
            };
            llama.setColor(color);
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to set llama variant '" + variant + "': " + e.getMessage());
        }
        return llama;
    }

    private Entity spawnAxolotl(Location loc, String variant) {
        Axolotl axolotl = (Axolotl) loc.getWorld().spawnEntity(loc, EntityType.AXOLOTL);
        try {
            Axolotl.Variant av = switch (variant.toLowerCase()) {
                case "wild" -> Axolotl.Variant.WILD; case "gold" -> Axolotl.Variant.GOLD;
                case "cyan" -> Axolotl.Variant.CYAN; case "blue" -> Axolotl.Variant.BLUE;
                default -> Axolotl.Variant.LUCY;
            };
            axolotl.setVariant(av);
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to set axolotl variant '" + variant + "': " + e.getMessage());
        }
        return axolotl;
    }

    private Entity spawnFrog(Location loc, String variant) {
        Frog frog = (Frog) loc.getWorld().spawnEntity(loc, EntityType.FROG);
        try {
            Frog.Variant fv = switch (variant.toLowerCase()) {
                case "warm" -> Frog.Variant.WARM; case "cold" -> Frog.Variant.COLD;
                default -> Frog.Variant.TEMPERATE;
            };
            frog.setVariant(fv);
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to set frog variant '" + variant + "': " + e.getMessage());
        }
        return frog;
    }

    private Entity spawnSlime(Location loc) {
        Slime slime = (Slime) loc.getWorld().spawnEntity(loc, EntityType.SLIME);
        slime.setSize(1); return slime;
    }

    private Entity spawnPhantom(Location loc) {
        Phantom phantom = (Phantom) loc.getWorld().spawnEntity(loc, EntityType.PHANTOM);
        phantom.setSize(3); return phantom;
    }

    private Entity spawnZombie(Location loc, String variant) {
        Zombie zombie = (Zombie) loc.getWorld().spawnEntity(loc, EntityType.ZOMBIE);
        zombie.setShouldBurnInDay(false);
        if ("gold".equalsIgnoreCase(variant)) {
            zombie.getEquipment().setHelmet(new ItemStack(Material.GOLDEN_HELMET));
            zombie.getEquipment().setChestplate(new ItemStack(Material.GOLDEN_CHESTPLATE));
        } else if ("diamond".equalsIgnoreCase(variant)) {
            zombie.getEquipment().setHelmet(new ItemStack(Material.DIAMOND_HELMET));
            zombie.getEquipment().setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
        }
        return zombie;
    }

    private Entity spawnWarden(Location loc) {
        Warden warden = (Warden) loc.getWorld().spawnEntity(loc, EntityType.WARDEN);
        warden.setAnger(null, 0); return warden;
    }

    private Entity spawnWither(Location loc, String variant) {
        WitherSkeleton ws = (WitherSkeleton) loc.getWorld().spawnEntity(loc, EntityType.WITHER_SKELETON);
        if ("charged".equalsIgnoreCase(variant))
            ws.getEquipment().setHelmet(new ItemStack(Material.WITHER_SKELETON_SKULL));
        return ws;
    }

    private Entity spawnGiant(Location loc) {
        try { return loc.getWorld().spawnEntity(loc, EntityType.GIANT); }
        catch (Exception e) {
            Zombie z = (Zombie) loc.getWorld().spawnEntity(loc, EntityType.ZOMBIE);
            z.getEquipment().setHelmet(new ItemStack(Material.ZOMBIE_HEAD)); return z;
        }
    }

    public void removePet(UUID uuid) {
        Entity pet = activePets.remove(uuid);
        if (pet != null && !pet.isDead()) {
            // If pet is riding the player, dismount first
            Entity vehicle = pet.getVehicle();
            if (vehicle != null) vehicle.removePassenger(pet);
            pet.remove();
        }
        petOnHead.remove(uuid);
        combatHiddenPets.remove(uuid);
    }

    public boolean hasPet(UUID uuid) { return activePets.containsKey(uuid); }

    public boolean isPetOnHead(UUID uuid) { return petOnHead.getOrDefault(uuid, false); }

    public void restorePet(Player player) {
        String petId = plugin.getPlayerCosmeticManager().getEquipped(player.getUniqueId(), CosmeticType.PET);
        if (petId != null) spawnPet(player);
    }

    public void toggleOnHead(Player player) {
        UUID uuid = player.getUniqueId();
        Entity pet = activePets.get(uuid);
        if (pet == null) return;
        boolean onHead = petOnHead.getOrDefault(uuid, false);
        if (onHead) {
            player.removePassenger(pet); petOnHead.put(uuid, false);
            pet.teleport(player.getLocation());
            player.sendMessage("§a§l✓ §aTu mascota ahora camina a tu lado");
        } else {
            player.addPassenger(pet); petOnHead.put(uuid, true);
            player.sendMessage("§a§l✓ §aTu mascota ahora va en tu cabeza");
        }
    }

    // ────────────────── Variant Helpers ──────────────────

    /**
     * Get the base pet ID for any pet (base or variant).
     * e.g., "pet_cat_black" → "pet_cat", "pet_wolf" → "pet_wolf",
     *        "pet_iron_golem" → "pet_iron_golem"
     */
    public static String getBasePetId(String petId) {
        String id = petId.toLowerCase().replace("pet_", "");
        // Handle multi-word base types first
        if (id.startsWith("iron_golem")) return "pet_iron_golem";
        if (id.startsWith("polar_bear")) return "pet_polar_bear";
        if (id.startsWith("snow_golem")) return "pet_snow_golem";
        // Simple types: first word is the type
        int idx = id.indexOf('_');
        if (idx > 0) return "pet_" + id.substring(0, idx);
        return petId.toLowerCase(); // Already a base pet
    }

    /**
     * Check if a pet ID is a variant (not the base pet itself).
     * e.g., "pet_cat_black" → true, "pet_cat" → false
     */
    public static boolean isVariant(String petId) {
        return !petId.equalsIgnoreCase(getBasePetId(petId));
    }

    /**
     * Get the variant name from a pet ID.
     * e.g., "pet_cat_black" → "black", "pet_cat" → "default"
     */
    public static String getVariantName(String petId) {
        String base = getBasePetId(petId);
        if (petId.equalsIgnoreCase(base)) return "default";
        // Remove base prefix + underscore
        return petId.substring(base.length() + 1);
    }
}
