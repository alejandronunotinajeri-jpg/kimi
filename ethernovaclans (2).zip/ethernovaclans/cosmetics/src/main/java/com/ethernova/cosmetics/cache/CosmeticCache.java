package com.ethernova.cosmetics.cache;

import com.ethernova.cosmetics.EthernovaCosmetics;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * Per-player cosmetic selection cache with TTL-based expiration.
 * <p>
 * Preloads active cosmetic selections for online players to avoid
 * repeated DB lookups. Used by particle handlers, trail handlers,
 * and kill effect handlers for fast O(1) lookups.
 * <p>
 * Features:
 * <ul>
 *   <li>TTL-based cache entries (configurable, default 10 min)</li>
 *   <li>Automatic preload on player join</li>
 *   <li>Manual invalidation on cosmetic change</li>
 *   <li>Hit/miss tracking for diagnostics</li>
 *   <li>Periodic cleanup of expired entries</li>
 * </ul>
 */
public class CosmeticCache {

    private final EthernovaCosmetics plugin;
    private final Logger logger;

    // Cache: UUID -> cosmetic type -> cached entry
    private final Map<UUID, Map<String, CacheEntry>> cache = new ConcurrentHashMap<>();

    // Stats
    private long hits = 0;
    private long misses = 0;

    // Config
    private final long ttlMillis;
    private BukkitTask cleanupTask;

    public CosmeticCache(EthernovaCosmetics plugin) {
        this.plugin = plugin;
        this.logger = plugin.getLogger();
        this.ttlMillis = plugin.getConfig().getLong("cache.ttl-seconds", 600) * 1000L;
        startCleanupTask();
    }

    // ═══════════════════════════════════════
    //  CACHE ENTRY
    // ═══════════════════════════════════════

    public record CacheEntry(String value, long expiresAt) {
        public boolean isExpired() {
            return System.currentTimeMillis() > expiresAt;
        }
    }

    // ═══════════════════════════════════════
    //  GET / PUT / INVALIDATE
    // ═══════════════════════════════════════

    /**
     * Get a cached cosmetic value. Returns null if not in cache or expired.
     */
    public String get(UUID uuid, String cosmeticType) {
        Map<String, CacheEntry> playerCache = cache.get(uuid);
        if (playerCache == null) {
            misses++;
            return null;
        }
        CacheEntry entry = playerCache.get(cosmeticType);
        if (entry == null || entry.isExpired()) {
            if (entry != null) playerCache.remove(cosmeticType);
            misses++;
            return null;
        }
        hits++;
        return entry.value();
    }

    /**
     * Put a value in the cache.
     */
    public void put(UUID uuid, String cosmeticType, String value) {
        cache.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>())
                .put(cosmeticType, new CacheEntry(value, System.currentTimeMillis() + ttlMillis));
    }

    /**
     * Invalidate a specific cosmetic type for a player.
     */
    public void invalidate(UUID uuid, String cosmeticType) {
        Map<String, CacheEntry> playerCache = cache.get(uuid);
        if (playerCache != null) {
            playerCache.remove(cosmeticType);
        }
    }

    /**
     * Invalidate all cached entries for a player.
     */
    public void invalidateAll(UUID uuid) {
        cache.remove(uuid);
    }

    /**
     * Check if a value is cached and not expired.
     */
    public boolean isCached(UUID uuid, String cosmeticType) {
        Map<String, CacheEntry> playerCache = cache.get(uuid);
        if (playerCache == null) return false;
        CacheEntry entry = playerCache.get(cosmeticType);
        return entry != null && !entry.isExpired();
    }

    // ═══════════════════════════════════════
    //  PRELOAD
    // ═══════════════════════════════════════

    /**
     * Preload all cosmetic selections for a player.
     * Called on join by the cosmetics module.
     */
    public void preload(UUID uuid) {
        if (plugin.getPlayerCosmeticManager() == null) return;

        // Load all active cosmetics from PlayerCosmeticManager
        var activeCosmetics = plugin.getPlayerCosmeticManager().getAllEquipped(uuid);
        if (activeCosmetics != null && !activeCosmetics.isEmpty()) {
            Map<String, CacheEntry> entries = new ConcurrentHashMap<>();
            long expires = System.currentTimeMillis() + ttlMillis;
            for (var entry : activeCosmetics.entrySet()) {
                entries.put(entry.getKey().name().toLowerCase(), new CacheEntry(entry.getValue(), expires));
            }
            cache.put(uuid, entries);
        }
    }

    /**
     * Unload all cached data for a player (on quit).
     */
    public void unload(UUID uuid) {
        cache.remove(uuid);
    }

    // ═══════════════════════════════════════
    //  CLEANUP
    // ═══════════════════════════════════════

    private void startCleanupTask() {
        // Run every 5 minutes to clean expired entries
        cleanupTask = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            int cleaned = 0;
            for (Map.Entry<UUID, Map<String, CacheEntry>> playerEntry : cache.entrySet()) {
                Map<String, CacheEntry> playerCache = playerEntry.getValue();
                Iterator<Map.Entry<String, CacheEntry>> it = playerCache.entrySet().iterator();
                while (it.hasNext()) {
                    if (it.next().getValue().isExpired()) {
                        it.remove();
                        cleaned++;
                    }
                }
                if (playerCache.isEmpty()) {
                    cache.remove(playerEntry.getKey());
                }
            }
            if (cleaned > 0) {
                logger.fine("CosmeticCache cleanup: removed " + cleaned + " expired entries");
            }
        }, 6000L, 6000L); // Every 5 minutes
    }

    // ═══════════════════════════════════════
    //  DIAGNOSTICS
    // ═══════════════════════════════════════

    /**
     * Get cache hit count.
     */
    public long getHits() { return hits; }

    /**
     * Get cache miss count.
     */
    public long getMisses() { return misses; }

    /**
     * Get hit rate (0.0 - 1.0).
     */
    public double getHitRate() {
        long total = hits + misses;
        return total > 0 ? (double) hits / total : 0;
    }

    /**
     * Get total cached entries count.
     */
    public int getSize() {
        return cache.values().stream().mapToInt(Map::size).sum();
    }

    /**
     * Get number of cached players.
     */
    public int getPlayerCount() {
        return cache.size();
    }

    /**
     * Get a diagnostic summary string.
     */
    public String getDiagnostics() {
        return String.format(
                "CosmeticCache: %d entries for %d players | Hit rate: %.1f%% (%d/%d) | TTL: %ds",
                getSize(), getPlayerCount(),
                getHitRate() * 100, hits, hits + misses,
                ttlMillis / 1000
        );
    }

    /**
     * Shutdown cleanup.
     */
    public void shutdown() {
        if (cleanupTask != null) cleanupTask.cancel();
        cache.clear();
    }
}
