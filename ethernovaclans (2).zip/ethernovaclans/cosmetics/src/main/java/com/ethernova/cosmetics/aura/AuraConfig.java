package com.ethernova.cosmetics.aura;

/**
 * Per-aura customizable configuration: intensity, speed, radius, blend mode.
 * Mutable to support the settings GUI adjustments in real-time.
 */
public class AuraConfig {

    public double intensity;
    public double speed;
    public double radius;
    public String blendMode;

    /** Default neutral configuration. */
    public AuraConfig() {
        this(1.0, 1.0, 1.0, "NORMAL");
    }

    public AuraConfig(double intensity, double speed, double radius, String blendMode) {
        this.intensity = Math.max(0.1, Math.min(2.0, intensity));
        this.speed = Math.max(0.5, Math.min(2.0, speed));
        this.radius = Math.max(0.5, Math.min(3.0, radius));
        this.blendMode = blendMode != null ? blendMode : "NORMAL";
    }

    // Accessor methods for compatibility with code using record-style access
    public double intensity() { return intensity; }
    public double speed() { return speed; }
    public double radius() { return radius; }
    public String blendMode() { return blendMode; }
}
