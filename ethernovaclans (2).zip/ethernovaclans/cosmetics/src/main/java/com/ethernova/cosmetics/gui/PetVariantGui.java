package com.ethernova.cosmetics.gui;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.cosmetics.effect.PetManager;
import com.ethernova.cosmetics.model.Cosmetic;
import com.ethernova.cosmetics.model.CosmeticType;
import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.PaginatedGui;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * GUI showing all variants for a specific pet type.
 * Opens when a player clicks on an owned base pet in the CosmeticTypeGui.
 * Variants are free to equip once the base pet is owned.
 */
public class PetVariantGui extends PaginatedGui {

    private final EthernovaCosmetics cosmetics;
    private final String basePetId;
    private final Cosmetic basePet;

    public PetVariantGui(EthernovaCore core, Player player, EthernovaCosmetics cosmetics, String basePetId) {
        super(core, player);
        this.cosmetics = cosmetics;
        this.basePetId = basePetId;
        this.basePet = cosmetics.getCosmeticRegistry().getById(basePetId);
    }

    public void open() {
        String petName = basePet != null ? basePet.name() : basePetId;
        openPaginated("<gradient:#a855f7:#ec4899>✦ Variantes: " + petName + "</gradient>", 0);
    }

    @Override
    protected String getTitle() {
        String petName = basePet != null ? basePet.name() : basePetId;
        return "<gradient:#a855f7:#ec4899>✦ Variantes: " + petName + "</gradient>";
    }

    @Override
    protected List<PageItem> getPageItems() {
        List<PageItem> items = new ArrayList<>();
        UUID uuid = player.getUniqueId();
        String equippedId = cosmetics.getPlayerCosmeticManager().getEquipped(uuid, CosmeticType.PET);

        // Add the base (default) variant first
        if (basePet != null) {
            boolean isEquipped = basePetId.equalsIgnoreCase(equippedId);
            List<String> lore = new ArrayList<>();
            lore.add("");
            lore.add("<yellow>Variante por defecto");
            lore.add("");
            if (isEquipped) {
                lore.add("<green>✔ Equipado");
                lore.add("");
                lore.add("<red>▶ Click para desequipar");
            } else {
                lore.add("<green>✔ Disponible");
                lore.add("");
                lore.add("<green>▶ Click para equipar");
            }
            lore.add("<aqua>▶ Click der. para previsualizar");

            ItemStack item = createItem(basePet.icon(), "<green>" + basePet.name() + " <gray>(Default)", lore);
            if (isEquipped) addGlow(item);
            items.add(new PageItem(item, "VARIANT_" + basePetId));
        }

        // Add all variant cosmetics
        List<Cosmetic> allPets = cosmetics.getCosmeticRegistry().getByType(CosmeticType.PET);
        for (Cosmetic cosmetic : allPets) {
            if (!PetManager.isVariant(cosmetic.id())) continue;
            if (!PetManager.getBasePetId(cosmetic.id()).equalsIgnoreCase(basePetId)) continue;

            boolean isEquipped = cosmetic.id().equalsIgnoreCase(equippedId);
            String variantName = PetManager.getVariantName(cosmetic.id());

            List<String> lore = new ArrayList<>();
            lore.add("");
            lore.add("<gray>Variante: <white>" + capitalize(variantName));
            lore.add("");
            if (isEquipped) {
                lore.add("<green>✔ Equipado");
                lore.add("");
                lore.add("<red>▶ Click para desequipar");
            } else {
                lore.add("<green>✔ Disponible");
                lore.add("");
                lore.add("<green>▶ Click para equipar");
            }
            lore.add("<aqua>▶ Click der. para previsualizar");

            ItemStack item = createItem(cosmetic.icon(), cosmetic.coloredName(), lore);
            if (isEquipped) addGlow(item);
            items.add(new PageItem(item, "VARIANT_" + cosmetic.id()));
        }

        // Head/floor toggle if pet is active
        if (cosmetics.getPetManager().hasPet(uuid)) {
            boolean onHead = cosmetics.getPetManager().isPetOnHead(uuid);
            String mode = onHead ? "<green>En cabeza" : "<green>En el suelo";
            String toggleTo = onHead ? "suelo" : "cabeza";
            items.add(0, new PageItem(
                    createItem(Material.SADDLE,
                            "<yellow>✦ Modo Mascota: " + mode,
                            List.of("", "<gray>Modo actual: " + mode,
                                    "", "<yellow>▶ Click para cambiar al " + toggleTo)),
                    "PET_TOGGLE_HEAD"
            ));
        }

        return items;
    }

    @Override
    protected boolean onItemClick(String action, int slot, InventoryClickEvent event) {
        if ("PET_TOGGLE_HEAD".equals(action)) {
            cosmetics.getPetManager().toggleOnHead(player);
            core.getSoundManager().play(player, "click");
            open();
            return true;
        }

        if (!action.startsWith("VARIANT_")) return false;

        String variantId = action.substring(8);
        UUID uuid = player.getUniqueId();

        // Right-click → preview
        if (event.isRightClick()) {
            player.closeInventory();
            cosmetics.getPetManager().preview(player, variantId);
            player.sendMessage(MiniMessage.miniMessage().deserialize(
                    "<gray>Previsualizando mascota por 5 segundos..."));
            // Return to variant menu after preview ends
            final String returnBasePetId = this.basePetId;
            Bukkit.getScheduler().runTaskLater(core, () -> {
                if (player.isOnline()) {
                    new PetVariantGui(core, player, cosmetics, returnBasePetId).open();
                }
            }, 120); // 6 seconds (preview is 5s + 1s buffer)
            return true;
        }

        String equippedId = cosmetics.getPlayerCosmeticManager().getEquipped(uuid, CosmeticType.PET);
        boolean isEquipped = variantId.equalsIgnoreCase(equippedId);

        if (isEquipped) {
            // Unequip
            cosmetics.getPlayerCosmeticManager().unequipById(uuid, variantId);
            cosmetics.getPetManager().removePet(uuid);
            core.getSoundManager().play(player, "click");
            player.sendMessage(MiniMessage.miniMessage().deserialize("<red>✘ Mascota desequipada"));
        } else {
            // Equip this variant — auto-unlock variants if base is owned
            if (!cosmetics.getPlayerCosmeticManager().isUnlocked(uuid, variantId)) {
                cosmetics.getPlayerCosmeticManager().unlock(uuid, variantId);
            }
            cosmetics.getPlayerCosmeticManager().equip(uuid, variantId);
            cosmetics.getPetManager().spawnPet(player);
            core.getSoundManager().play(player, "success");
            Cosmetic cosmetic = cosmetics.getCosmeticRegistry().getById(variantId);
            String name = cosmetic != null ? cosmetic.name() : variantId;
            player.sendMessage(MiniMessage.miniMessage().deserialize("<green>✔ Mascota equipada: <white>" + name));
        }

        open(); // Refresh
        return true;
    }

    @Override
    protected void onBack() {
        new CosmeticTypeGui(core, player, cosmetics, CosmeticType.PET).open();
    }

    private void addGlow(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            item.setItemMeta(meta);
        }
    }

    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return s.substring(0, 1).toUpperCase() + s.substring(1).replace("_", " ");
    }
}
