package com.ethernova.cosmetics.model;

import org.bukkit.Material;

/**
 * Rarity tiers for cosmetics with associated color and display name.
 */
public enum CosmeticRarity {

    COMMON("<gray>", "Común"),
    RARE("<blue>", "Raro"),
    EPIC("<dark_purple>", "Épico"),
    LEGENDARY("<gold>", "Legendario"),
    MYTHIC("<light_purple>", "Mítico");

    private final String color;
    private final String displayName;

    CosmeticRarity(String color, String displayName) {
        this.color = color;
        this.displayName = displayName;
    }

    /**
     * Get the MiniMessage color tag for this rarity.
     */
    public String getColor() {
        return color;
    }

    /**
     * Get the localized display name.
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Get a formatted display string with color applied.
     */
    public String getFormattedName() {
        return color + displayName;
    }

    /**
     * Get the corresponding Material for GUI display border/accent.
     */
    public Material getGlassPaneMaterial() {
        return switch (this) {
            case COMMON -> Material.WHITE_STAINED_GLASS_PANE;
            case RARE -> Material.BLUE_STAINED_GLASS_PANE;
            case EPIC -> Material.PURPLE_STAINED_GLASS_PANE;
            case LEGENDARY -> Material.ORANGE_STAINED_GLASS_PANE;
            case MYTHIC -> Material.MAGENTA_STAINED_GLASS_PANE;
        };
    }
}
