package com.ethernova.cosmetics.manager;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.cosmetics.model.Cosmetic;
import com.ethernova.cosmetics.model.CosmeticRarity;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Manages mystery box opening logic with weighted random cosmetic selection.
 * Supports animated reveal, duplicate protection, and coin refund on all-owned.
 */
public class MysteryBoxManager {

    private final EthernovaCosmetics plugin;
    private final MiniMessage mini = MiniMessage.miniMessage();

    /** Players currently opening a mystery box (prevent double-open) */
    private final Set<UUID> opening = Collections.synchronizedSet(new HashSet<>());

    public MysteryBoxManager(EthernovaCosmetics plugin) {
        this.plugin = plugin;
    }

    /**
     * Attempt to purchase and open a mystery box for a player.
     *
     * @param player The player
     * @param boxId  The mystery box ID
     * @return true if the process started
     */
    public boolean openBox(Player player, String boxId) {
        if (player == null || boxId == null) return false;
        UUID uuid = player.getUniqueId();

        if (opening.contains(uuid)) {
            player.sendMessage(mini.deserialize(
                    plugin.getConfigManager().getMessage("mystery-box-already-opening")));
            return false;
        }

        CosmeticRegistry.MysteryBoxDef box = plugin.getCosmeticRegistry().getMysteryBox(boxId);
        if (box == null) {
            player.sendMessage(mini.deserialize(
                    plugin.getConfigManager().getMessage("cosmetic-not-found")));
            return false;
        }

        // Check coins
        var profile = plugin.getCore().getProfileManager().getProfile(uuid);
        if (profile == null) return false;

        if (profile.getCoins() < box.price()) {
            player.sendMessage(mini.deserialize(
                    plugin.getConfigManager().getMessage("cosmetic-not-enough-coins")
                            .replace("{price}", String.format("%.0f", box.price()))));
            plugin.getCore().getSoundManager().play(player, "error");
            return false;
        }

        // Roll a cosmetic
        Cosmetic result = rollCosmetic(uuid, box);
        if (result == null) {
            player.sendMessage(mini.deserialize(
                    plugin.getConfigManager().getMessage("mystery-box-all-owned")));
            plugin.getCore().getSoundManager().play(player, "error");
            return false;
        }

        // Deduct coins and unlock cosmetic immediately (before animation)
        // This prevents coin loss if player disconnects during the reveal animation
        profile.addCoins(-box.price());
        plugin.getPlayerCosmeticManager().unlock(uuid, result.id());
        opening.add(uuid);

        // Animated reveal: 10 ticks of suspense, then reveal
        playOpenAnimation(player, box, result);
        return true;
    }

    /**
     * Roll a cosmetic from the mystery box using weighted rarity selection.
     * Guarantees the result is not already owned. Returns null if all owned.
     */
    private Cosmetic rollCosmetic(UUID uuid, CosmeticRegistry.MysteryBoxDef box) {
        Map<CosmeticRarity, Integer> weights = box.weights();
        PlayerCosmeticManager pcm = plugin.getPlayerCosmeticManager();
        CosmeticRegistry registry = plugin.getCosmeticRegistry();

        // Build a list of eligible cosmetics per rarity
        Map<CosmeticRarity, List<Cosmetic>> eligible = new EnumMap<>(CosmeticRarity.class);
        int totalWeight = 0;

        for (CosmeticRarity rarity : CosmeticRarity.values()) {
            int weight = weights.getOrDefault(rarity, 0);
            if (weight <= 0) continue;

            List<Cosmetic> candidates = new ArrayList<>();
            for (Cosmetic c : registry.getByRarity(rarity)) {
                if (!pcm.isUnlocked(uuid, c.id())) {
                    candidates.add(c);
                }
            }
            if (!candidates.isEmpty()) {
                eligible.put(rarity, candidates);
                totalWeight += weight;
            }
        }

        if (totalWeight <= 0 || eligible.isEmpty()) return null;

        // Weighted random rarity pick
        int roll = ThreadLocalRandom.current().nextInt(totalWeight);
        int cumulative = 0;
        CosmeticRarity pickedRarity = null;

        for (Map.Entry<CosmeticRarity, List<Cosmetic>> entry : eligible.entrySet()) {
            int w = weights.getOrDefault(entry.getKey(), 0);
            cumulative += w;
            if (roll < cumulative) {
                pickedRarity = entry.getKey();
                break;
            }
        }

        if (pickedRarity == null) {
            // Fallback: pick last eligible
            pickedRarity = eligible.keySet().stream().reduce((a, b) -> b).orElse(null);
        }
        if (pickedRarity == null) return null;

        List<Cosmetic> pool = eligible.get(pickedRarity);
        return pool.get(ThreadLocalRandom.current().nextInt(pool.size()));
    }

    /**
     * Play the mystery box opening animation with suspense sounds, then reveal.
     */
    private void playOpenAnimation(Player player, CosmeticRegistry.MysteryBoxDef box, Cosmetic result) {
        UUID uuid = player.getUniqueId();

        // Suspense ticks: 8 clicks with increasing speed
        int[] delays = {6, 5, 5, 4, 4, 3, 3, 2};
        long cumulativeDelay = 0;

        for (int i = 0; i < delays.length; i++) {
            cumulativeDelay += delays[i];
            final long tick = cumulativeDelay;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!player.isOnline()) return;
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1.0f, 1.0f + (tick * 0.02f));
            }, tick);
        }

        // Reveal after animation
        long revealTick = cumulativeDelay + 8;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) {
                opening.remove(uuid);
                return;
            }

            // Cosmetic was already unlocked before animation started (see openBox)
            opening.remove(uuid);

            // Reveal sound based on rarity
            switch (result.rarity()) {
                case MYTHIC -> {
                    player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
                    player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.5f, 1.2f);
                }
                case LEGENDARY -> {
                    player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.2f);
                    player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 0.8f);
                }
                case EPIC -> {
                    player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
                }
                default -> {
                    player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
                }
            }

            // Send reveal message
            String rarityDisplay = result.rarity().getFormattedName();
            player.sendMessage(mini.deserialize(
                    plugin.getConfigManager().getMessage("mystery-box-reveal")
                            .replace("{cosmetic}", result.name())
                            .replace("{rarity}", result.rarity().getDisplayName())
                            .replace("{box}", box.name())));

            // Broadcast for rarity >= LEGENDARY
            if (result.rarity().ordinal() >= CosmeticRarity.LEGENDARY.ordinal()) {
                String broadcast = plugin.getConfigManager().getRawMessage("mystery-box-broadcast")
                        .replace("{player}", player.getName())
                        .replace("{cosmetic}", result.name())
                        .replace("{rarity}", result.rarity().getDisplayName());
                Bukkit.broadcast(mini.deserialize(
                        plugin.getConfigManager().getRawMessage("prefix") + broadcast));
            }
        }, revealTick);
    }

    /**
     * Check if a player is currently opening a mystery box.
     */
    public boolean isOpening(UUID uuid) {
        return opening.contains(uuid);
    }
}
