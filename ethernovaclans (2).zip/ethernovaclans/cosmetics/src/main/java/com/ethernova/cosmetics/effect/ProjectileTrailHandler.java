package com.ethernova.cosmetics.effect;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.cosmetics.model.CosmeticType;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Handles projectile trails — adds particle trails to arrows and other projectiles
 * shot by players who have a projectile trail cosmetic equipped.
 */
public class ProjectileTrailHandler implements Listener {

    private final EthernovaCosmetics plugin;
    private final Map<UUID, BukkitTask> trackedProjectiles = new ConcurrentHashMap<>();

    public ProjectileTrailHandler(EthernovaCosmetics plugin) {
        this.plugin = plugin;
    }

    /**
     * Listen for projectile launch events and begin tracking the projectile
     * if the shooter has a projectile trail cosmetic equipped.
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onProjectileLaunch(ProjectileLaunchEvent event) {
        Projectile projectile = event.getEntity();
        if (!(projectile.getShooter() instanceof Player shooter)) return;

        UUID shooterUuid = shooter.getUniqueId();
        String cosmeticId = plugin.getPlayerCosmeticManager().getEquipped(shooterUuid, CosmeticType.PROJECTILE_TRAIL);
        if (cosmeticId == null) return;

        int interval = plugin.getConfigManager().getInt("projectile-trail.update-interval", 1);
        UUID projectileUuid = projectile.getUniqueId();

        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            // Stop tracking if projectile is dead, on ground, or invalid
            if (projectile.isDead() || !projectile.isValid() || projectile.isOnGround()) {
                BukkitTask existing = trackedProjectiles.remove(projectileUuid);
                if (existing != null) existing.cancel();
                return;
            }

            Location loc = projectile.getLocation();
            if (loc.getWorld() == null) return;

            spawnProjectileTrail(cosmeticId, loc);
        }, 1L, interval);

        trackedProjectiles.put(projectileUuid, task);

        // Safety cleanup: remove after 10 seconds max
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            BukkitTask existing = trackedProjectiles.remove(projectileUuid);
            if (existing != null) existing.cancel();
        }, 200L);
    }

    /**
     * Spawn projectile trail particles at the given location.
     */
    private void spawnProjectileTrail(String trailId, Location loc) {
        if (loc.getWorld() == null) return;

        switch (trailId.toLowerCase()) {
            case "proj_flame" -> {
                loc.getWorld().spawnParticle(Particle.FLAME, loc, 3, 0.05, 0.05, 0.05, 0.01);
                loc.getWorld().spawnParticle(Particle.SMOKE, loc, 1, 0.02, 0.02, 0.02, 0.005);
            }
            case "proj_magic" -> {
                loc.getWorld().spawnParticle(Particle.WITCH, loc, 5, 0.1, 0.1, 0.1, 0.02);
                loc.getWorld().spawnParticle(Particle.ENCHANT, loc, 3, 0.1, 0.1, 0.1, 0.3);
            }
            case "proj_snow" -> {
                loc.getWorld().spawnParticle(Particle.SNOWFLAKE, loc, 4, 0.1, 0.1, 0.1, 0.01);
                Particle.DustOptions iceDust = new Particle.DustOptions(Color.fromRGB(180, 220, 255), 0.8f);
                loc.getWorld().spawnParticle(Particle.DUST, loc, 2, 0.05, 0.05, 0.05, 0, iceDust);
            }
            case "proj_dragon" -> {
                loc.getWorld().spawnParticle(Particle.DRAGON_BREATH, loc, 4, 0.08, 0.08, 0.08, 0.01);
                loc.getWorld().spawnParticle(Particle.FLAME, loc, 1, 0.02, 0.02, 0.02, 0.005);
            }
            case "proj_void" -> {
                loc.getWorld().spawnParticle(Particle.PORTAL, loc, 6, 0.1, 0.1, 0.1, 0.3);
                loc.getWorld().spawnParticle(Particle.REVERSE_PORTAL, loc, 3, 0.05, 0.05, 0.05, 0.05);
                Particle.DustOptions voidDust = new Particle.DustOptions(Color.fromRGB(20, 0, 30), 0.6f);
                loc.getWorld().spawnParticle(Particle.DUST, loc, 2, 0.05, 0.05, 0.05, 0, voidDust);
            }
            // ── Projectile Trails adicionales (original UltimateFFA) ──
            case "proj_smoke" -> loc.getWorld().spawnParticle(Particle.LARGE_SMOKE, loc, 3, 0.05, 0.05, 0.05, 0.01);
            case "proj_water" -> loc.getWorld().spawnParticle(Particle.DRIPPING_WATER, loc, 3, 0.05, 0.05, 0.05, 0);
            case "proj_slime" -> loc.getWorld().spawnParticle(Particle.ITEM_SLIME, loc, 4, 0.05, 0.05, 0.05, 0.02);
            case "proj_lava" -> loc.getWorld().spawnParticle(Particle.DRIPPING_LAVA, loc, 3, 0.05, 0.05, 0.05, 0);
            case "proj_ash" -> loc.getWorld().spawnParticle(Particle.ASH, loc, 5, 0.1, 0.1, 0.1, 0);
            case "proj_spark" -> loc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc, 3, 0.05, 0.05, 0.05, 0.02);
            case "proj_cloud" -> loc.getWorld().spawnParticle(Particle.CLOUD, loc, 3, 0.05, 0.05, 0.05, 0.01);
            case "proj_note" -> loc.getWorld().spawnParticle(Particle.NOTE, loc, 2, 0.1, 0.1, 0.1, 0);
            case "proj_crit" -> loc.getWorld().spawnParticle(Particle.CRIT, loc, 5, 0.05, 0.05, 0.05, 0.02);
            case "proj_glow" -> loc.getWorld().spawnParticle(Particle.GLOW, loc, 3, 0.05, 0.05, 0.05, 0);
            case "proj_ink" -> loc.getWorld().spawnParticle(Particle.SQUID_INK, loc, 3, 0.05, 0.05, 0.05, 0.01);
            case "proj_love" -> loc.getWorld().spawnParticle(Particle.HEART, loc, 2, 0.1, 0.1, 0.1, 0);
            case "proj_totem" -> loc.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, loc, 4, 0.05, 0.05, 0.05, 0.02);
            case "proj_witch" -> loc.getWorld().spawnParticle(Particle.WITCH, loc, 4, 0.05, 0.05, 0.05, 0.01);
            case "proj_soul" -> loc.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, loc, 3, 0.05, 0.05, 0.05, 0.01);
            case "proj_cherry" -> loc.getWorld().spawnParticle(Particle.CHERRY_LEAVES, loc, 4, 0.1, 0.1, 0.1, 0);
            case "proj_heartbreak" -> {
                Particle.DustOptions pinkDust = new Particle.DustOptions(Color.fromRGB(255, 100, 150), 0.8f);
                loc.getWorld().spawnParticle(Particle.DUST, loc, 3, 0.05, 0.05, 0.05, 0, pinkDust);
            }
            case "proj_end" -> loc.getWorld().spawnParticle(Particle.END_ROD, loc, 3, 0.05, 0.05, 0.05, 0.02);
            case "proj_arctic" -> {
                loc.getWorld().spawnParticle(Particle.SNOWFLAKE, loc, 3, 0.05, 0.05, 0.05, 0.01);
                Particle.DustOptions frostDust = new Particle.DustOptions(Color.fromRGB(200, 240, 255), 0.6f);
                loc.getWorld().spawnParticle(Particle.DUST, loc, 2, 0.05, 0.05, 0.05, 0, frostDust);
            }
            case "proj_gold" -> {
                Particle.DustOptions goldDust = new Particle.DustOptions(Color.fromRGB(255, 215, 0), 0.8f);
                loc.getWorld().spawnParticle(Particle.DUST, loc, 3, 0.05, 0.05, 0.05, 0, goldDust);
            }
            case "proj_emerald" -> {
                Particle.DustOptions emeraldDust = new Particle.DustOptions(Color.fromRGB(0, 200, 83), 0.8f);
                loc.getWorld().spawnParticle(Particle.DUST, loc, 3, 0.05, 0.05, 0.05, 0, emeraldDust);
            }
            case "proj_rainbow" -> {
                float hue = (System.currentTimeMillis() % 3000) / 3000f;
                int rgb = hsbToRgb(hue, 1f, 1f);
                Particle.DustOptions rainbowDust = new Particle.DustOptions(
                        Color.fromRGB((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF), 1.0f);
                loc.getWorld().spawnParticle(Particle.DUST, loc, 4, 0.05, 0.05, 0.05, 0, rainbowDust);
            }
            default -> {
                // Unknown projectile trail — no particle
            }
        }
    }

    /**
     * Stop all tracked projectiles (called on plugin disable).
     */
    public void stopAll() {
        for (BukkitTask task : trackedProjectiles.values()) {
            task.cancel();
        }
        trackedProjectiles.clear();
    }

    /** Manual HSB→RGB conversion — avoids java.awt dependency on headless servers. */
    private static int hsbToRgb(float hue, float saturation, float brightness) {
        int r = 0, g = 0, b = 0;
        if (saturation == 0) {
            r = g = b = (int) (brightness * 255.0f + 0.5f);
        } else {
            float h = (hue - (float) Math.floor(hue)) * 6.0f;
            float f = h - (float) Math.floor(h);
            float p = brightness * (1.0f - saturation);
            float q = brightness * (1.0f - saturation * f);
            float t = brightness * (1.0f - (saturation * (1.0f - f)));
            switch ((int) h) {
                case 0 -> { r = (int)(brightness*255+0.5f); g = (int)(t*255+0.5f); b = (int)(p*255+0.5f); }
                case 1 -> { r = (int)(q*255+0.5f); g = (int)(brightness*255+0.5f); b = (int)(p*255+0.5f); }
                case 2 -> { r = (int)(p*255+0.5f); g = (int)(brightness*255+0.5f); b = (int)(t*255+0.5f); }
                case 3 -> { r = (int)(p*255+0.5f); g = (int)(q*255+0.5f); b = (int)(brightness*255+0.5f); }
                case 4 -> { r = (int)(t*255+0.5f); g = (int)(p*255+0.5f); b = (int)(brightness*255+0.5f); }
                case 5 -> { r = (int)(brightness*255+0.5f); g = (int)(p*255+0.5f); b = (int)(q*255+0.5f); }
            }
        }
        return (r << 16) | (g << 8) | b;
    }

    /**
     * Preview a projectile trail — shoots an actual arrow with the trail effect.
     */
    public void preview(Player player, String trailId) {
        if (player == null || trailId == null) return;

        // Shoot a slow arrow forward with no gravity
        org.bukkit.entity.Arrow arrow = player.launchProjectile(
                org.bukkit.entity.Arrow.class,
                player.getLocation().getDirection().normalize().multiply(0.5));
        arrow.setGravity(false);
        arrow.setPickupStatus(org.bukkit.entity.AbstractArrow.PickupStatus.DISALLOWED);
        arrow.setPersistent(false);

        // Track the arrow with trail particles
        final BukkitTask[] taskRef = new BukkitTask[1];
        final int[] tickCount = {0};

        taskRef[0] = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            tickCount[0]++;
            if (!arrow.isValid() || arrow.isOnGround() || tickCount[0] > 60) {
                arrow.remove();
                if (taskRef[0] != null) taskRef[0].cancel();
                return;
            }
            spawnProjectileTrail(trailId, arrow.getLocation());
        }, 1L, 1L);
    }
}
