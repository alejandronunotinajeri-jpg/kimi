package com.ethernova.cosmetics.model;

import org.bukkit.Material;

/**
 * Represents a single cosmetic item with all its properties.
 */
public record Cosmetic(
        String id,
        CosmeticType type,
        String name,
        String description,
        Material icon,
        String permission,
        double price,
        CosmeticRarity rarity,
        boolean vip
) {

    /**
     * Backward-compatible constructor without VIP field (defaults to false).
     */
    public Cosmetic(String id, CosmeticType type, String name, String description,
                    Material icon, String permission, double price, CosmeticRarity rarity) {
        this(id, type, name, description, icon, permission, price, rarity, false);
    }

    /**
     * Get a formatted display name with rarity color applied.
     */
    public String coloredName() {
        return rarity.getColor() + name;
    }

    /**
     * Check if the cosmetic has a cost (purchasable).
     */
    public boolean isPurchasable() {
        return price > 0;
    }

    /**
     * Get the formatted price string.
     */
    public String formattedPrice() {
        if (price <= 0) return "<green>Gratis";
        return "<gold>" + String.format("%.0f", price) + " monedas";
    }
}
