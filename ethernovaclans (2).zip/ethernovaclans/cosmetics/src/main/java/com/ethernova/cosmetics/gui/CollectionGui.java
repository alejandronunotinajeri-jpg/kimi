package com.ethernova.cosmetics.gui;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.cosmetics.model.Cosmetic;
import com.ethernova.cosmetics.model.CosmeticRarity;
import com.ethernova.cosmetics.model.CosmeticType;
import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.PaginatedGui;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * GUI showing the player's cosmetic collection progress.
 * Displays completion per CosmeticType and per CosmeticRarity with progress bars.
 */
public class CollectionGui extends PaginatedGui {

    private final EthernovaCosmetics cosmetics;

    public CollectionGui(EthernovaCore core, Player player, EthernovaCosmetics cosmetics) {
        super(core, player);
        this.cosmetics = cosmetics;
    }

    public void open() {
        openPaginated("<gradient:#00d4ff:#00ff88>✦ Mi Colección</gradient>", 0);
    }

    @Override
    protected String getTitle() {
        return "<gradient:#00d4ff:#00ff88>✦ Mi Colección</gradient>";
    }

    @Override
    protected List<PageItem> getPageItems() {
        List<PageItem> items = new ArrayList<>();
        UUID uuid = player.getUniqueId();
        Set<String> owned = cosmetics.getPlayerCosmeticManager().getAllUnlocked(uuid);
        int totalOwned = owned.size();
        int totalAll = cosmetics.getCosmeticRegistry().size();

        // Overall progress header item
        double overallPct = totalAll > 0 ? (double) totalOwned / totalAll * 100 : 0;
        items.add(new PageItem(
                createItem(Material.NETHER_STAR, "<aqua>Progreso General", List.of(
                        "",
                        "<gray>Cosméticos: <white>" + totalOwned + "<gray>/<white>" + totalAll,
                        progressBar(totalOwned, totalAll),
                        "<gray>Completado: <white>" + String.format("%.1f", overallPct) + "%",
                        ""
                )),
                "OVERALL"
        ));

        // Per type
        for (CosmeticType type : CosmeticType.values()) {
            List<Cosmetic> typeCosmetics = cosmetics.getCosmeticRegistry().getByType(type);
            if (typeCosmetics.isEmpty()) continue;

            int typeOwned = 0;
            for (Cosmetic c : typeCosmetics) {
                if (owned.contains(c.id())) typeOwned++;
            }

            double pct = (double) typeOwned / typeCosmetics.size() * 100;
            String status = typeOwned == typeCosmetics.size() ? "<green>✔ COMPLETO" : "<yellow>" + String.format("%.0f", pct) + "%";

            items.add(new PageItem(
                    createItem(type.getIcon(), "<light_purple>" + type.getDisplayName(), List.of(
                            "",
                            "<gray>Desbloqueados: <white>" + typeOwned + "<gray>/<white>" + typeCosmetics.size(),
                            progressBar(typeOwned, typeCosmetics.size()),
                            status,
                            "",
                            "<yellow>▶ Click para ver"
                    )),
                    "TYPE_" + type.name()
            ));
        }

        // Separator
        items.add(new PageItem(
                createItem(Material.GRAY_STAINED_GLASS_PANE, "<dark_gray>───"),
                "SEPARATOR"
        ));

        // Per rarity
        for (CosmeticRarity rarity : CosmeticRarity.values()) {
            List<Cosmetic> rarityCosmetics = cosmetics.getCosmeticRegistry().getByRarity(rarity);
            if (rarityCosmetics.isEmpty()) continue;

            int rarityOwned = 0;
            for (Cosmetic c : rarityCosmetics) {
                if (owned.contains(c.id())) rarityOwned++;
            }

            double pct = (double) rarityOwned / rarityCosmetics.size() * 100;
            String status = rarityOwned == rarityCosmetics.size() ? "<green>✔ COMPLETO" : rarity.getColor() + String.format("%.0f", pct) + "%";

            items.add(new PageItem(
                    createItem(rarity.getGlassPaneMaterial(), rarity.getFormattedName(), List.of(
                            "",
                            "<gray>Desbloqueados: <white>" + rarityOwned + "<gray>/<white>" + rarityCosmetics.size(),
                            progressBar(rarityOwned, rarityCosmetics.size()),
                            status,
                            ""
                    )),
                    "RARITY_" + rarity.name()
            ));
        }

        return items;
    }

    @Override
    protected boolean onItemClick(String action, int slot, InventoryClickEvent event) {
        if (action.startsWith("TYPE_")) {
            playSound("click");
            try {
                CosmeticType type = CosmeticType.valueOf(action.substring(5));
                new CosmeticTypeGui(core, player, cosmetics, type).open();
            } catch (IllegalArgumentException ignored) {}
            return true;
        }
        // Rarity/Overall/Separator clicks do nothing
        return true;
    }

    @Override
    protected void onBack() {
        new CosmeticsMainGui(core, player, cosmetics).open();
    }

    /**
     * Generate a MiniMessage progress bar like [████████░░░░]
     */
    private String progressBar(int current, int total) {
        int bars = 20;
        int filled = total > 0 ? (int) Math.round((double) current / total * bars) : 0;
        int empty = bars - filled;

        StringBuilder sb = new StringBuilder("<dark_gray>[");
        sb.append("<green>");
        sb.append("█".repeat(filled));
        sb.append("<dark_gray>");
        sb.append("░".repeat(empty));
        sb.append("<dark_gray>]");
        return sb.toString();
    }
}
