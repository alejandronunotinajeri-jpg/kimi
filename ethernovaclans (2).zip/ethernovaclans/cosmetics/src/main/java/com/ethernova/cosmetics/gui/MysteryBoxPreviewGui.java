package com.ethernova.cosmetics.gui;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.cosmetics.manager.CosmeticRegistry;
import com.ethernova.cosmetics.model.Cosmetic;
import com.ethernova.cosmetics.model.CosmeticRarity;
import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.PaginatedGui;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/**
 * Preview GUI for a specific mystery box.
 * Shows all cosmetics that can drop, organized by rarity,
 * with calculated individual drop probabilities and owned status.
 */
public class MysteryBoxPreviewGui extends PaginatedGui {

    private final EthernovaCosmetics cosmetics;
    private final CosmeticRegistry.MysteryBoxDef box;

    public MysteryBoxPreviewGui(EthernovaCore core, Player player,
                                 EthernovaCosmetics cosmetics, CosmeticRegistry.MysteryBoxDef box) {
        super(core, player);
        this.cosmetics = cosmetics;
        this.box = box;
    }

    public void open() {
        openPaginated("<gradient:#ff6b35:#ffd700>✦ " + box.name() + " - Contenido</gradient>", 0);
    }

    @Override
    protected String getTitle() {
        return "<gradient:#ff6b35:#ffd700>✦ " + box.name() + " - Contenido</gradient>";
    }

    @Override
    protected List<PageItem> getPageItems() {
        List<PageItem> items = new ArrayList<>();
        UUID uuid = player.getUniqueId();
        CosmeticRegistry registry = cosmetics.getCosmeticRegistry();
        Map<CosmeticRarity, Integer> weights = box.weights();

        // Calculate total weight for probability display
        int totalWeight = 0;
        for (int w : weights.values()) {
            if (w > 0) totalWeight += w;
        }

        // Add a rarity header separator, then all cosmetics of that rarity
        for (CosmeticRarity rarity : CosmeticRarity.values()) {
            int weight = weights.getOrDefault(rarity, 0);
            if (weight <= 0) continue;

            List<Cosmetic> cosmeticsInRarity = registry.getByRarity(rarity);
            if (cosmeticsInRarity.isEmpty()) continue;

            int count = cosmeticsInRarity.size();
            double rarityPercent = totalWeight > 0 ? (double) weight / totalWeight * 100 : 0;
            double individualPercent = count > 0 ? rarityPercent / count : 0;

            // Rarity header item (glass pane separator)
            Material headerPane = rarity.getGlassPaneMaterial();
            items.add(new PageItem(
                    createItem(headerPane, rarity.getFormattedName() + " <dark_gray>(" + count + " cosméticos)",
                            List.of("",
                                    "<dark_gray>▎ <gray>Probabilidad del grupo: " + rarity.getColor() + String.format("%.1f%%", rarityPercent),
                                    "<dark_gray>▎ <gray>Prob. individual: " + rarity.getColor() + String.format("%.2f%%", individualPercent),
                                    "")),
                    "HEADER_" + rarity.name()));

            // Individual cosmetics in this rarity
            for (Cosmetic cosmetic : cosmeticsInRarity) {
                boolean owned = cosmetics.getPlayerCosmeticManager().isUnlocked(uuid, cosmetic.id());

                List<String> lore = new ArrayList<>();
                lore.add("");
                String rarityLine = rarity.getFormattedName() + " <dark_gray>| " + cosmetic.type().getDisplayName();
                if (cosmetic.vip()) rarityLine += " <dark_gray>| <gold>⭐ VIP";
                lore.add(rarityLine);
                lore.add("");
                lore.add("<gray>" + cosmetic.description());
                lore.add("");
                lore.add("<dark_gray>▎ <gray>Probabilidad: " + rarity.getColor() + String.format("%.2f%%", individualPercent));
                lore.add("");

                if (owned) {
                    lore.add("<green>✔ Ya lo tienes");
                } else {
                    lore.add("<red>✘ No desbloqueado");
                }

                items.add(new PageItem(
                        createItem(cosmetic.icon(), cosmetic.coloredName(), lore),
                        "PREVIEW_" + cosmetic.id()));
            }
        }

        return items;
    }

    @Override
    protected boolean onItemClick(String action, int slot, InventoryClickEvent event) {
        // Preview items are informational — no action on click
        if (action.startsWith("HEADER_") || action.startsWith("PREVIEW_")) {
            playSound("click");
            return true;
        }
        return false;
    }

    @Override
    protected void onBack() {
        new MysteryBoxGui(core, player, cosmetics).open();
    }

    @Override
    protected void onPostRender() {
        // Add probability distribution bar at slot 50 (allowed border slot)
        Map<CosmeticRarity, Integer> weights = box.weights();
        int totalWeight = 0;
        for (int w : weights.values()) {
            if (w > 0) totalWeight += w;
        }

        List<String> distLore = new ArrayList<>();
        distLore.add("");
        distLore.add("<white><bold>Distribución de rareza:");
        distLore.add("");
        for (CosmeticRarity rarity : CosmeticRarity.values()) {
            int w = weights.getOrDefault(rarity, 0);
            if (w <= 0) continue;
            double pct = totalWeight > 0 ? (double) w / totalWeight * 100 : 0;
            int bars = (int) Math.round(pct / 5); // 20 bars = 100%
            String bar = rarity.getColor() + "█".repeat(Math.max(1, bars))
                       + "<dark_gray>" + "░".repeat(Math.max(0, 20 - bars));
            distLore.add("<dark_gray>▎ " + rarity.getColor() + rarity.getDisplayName()
                    + " <dark_gray>" + String.format("%.0f%%", pct));
            distLore.add("<dark_gray>▎ " + bar);
        }
        distLore.add("");
        distLore.add("<gray>Precio: <gold>" + String.format("%.0f", box.price()) + " monedas");

        setItem(50, createItem(Material.SPYGLASS, "<gold>✦ Probabilidades",  distLore));
        slotActions.put(50, "INFO");
    }
}
