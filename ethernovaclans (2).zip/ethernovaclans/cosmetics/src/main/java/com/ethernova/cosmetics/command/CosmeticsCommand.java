package com.ethernova.cosmetics.command;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.cosmetics.gui.CosmeticShopGui;
import com.ethernova.cosmetics.gui.CollectionGui;
import com.ethernova.cosmetics.gui.CosmeticsAdminGui;
import com.ethernova.cosmetics.gui.CosmeticsMainGui;
import com.ethernova.cosmetics.gui.MysteryBoxGui;
import com.ethernova.cosmetics.model.Cosmetic;
import com.ethernova.cosmetics.model.CosmeticType;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Main command handler for /cosmetics.
 *
 * Usage:
 *   /cosmetics            — Opens the main cosmetics menu
 *   /cosmetics shop       — Opens the cosmetics shop
 *   /cosmetics preview <id> — Previews a specific cosmetic
 */
public class CosmeticsCommand implements CommandExecutor, TabCompleter {

    private final EthernovaCosmetics plugin;
    private final MiniMessage mini = MiniMessage.miniMessage();

    public CosmeticsCommand(EthernovaCosmetics plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(mini.deserialize("<red>Este comando solo puede ser usado por jugadores."));
            return true;
        }

        if (!player.hasPermission("ethernova.cosmetics.use")) {
            player.sendMessage(mini.deserialize(
                    plugin.getConfigManager().getMessage("cosmetic-no-permission")));
            return true;
        }

        // Handle /titles as a standalone command -> open TITLE type GUI
        String cmdName = command.getName().toLowerCase();
        if ("titles".equals(cmdName) || "titulo".equals(cmdName) || "titulos".equals(cmdName)) {
            new com.ethernova.cosmetics.gui.CosmeticTypeGui(
                    plugin.getCore(), player, plugin, CosmeticType.TITLE).open();
            return true;
        }

        // Handle /shop as a standalone command -> redirect to main cosmetics menu
        if ("shop".equals(cmdName) || "tienda".equals(cmdName)) {
            new CosmeticsMainGui(plugin.getCore(), player, plugin).open();
            return true;
        }

        if (args.length == 0) {
            // Open main GUI
            new CosmeticsMainGui(plugin.getCore(), player, plugin).open();
            return true;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "shop", "tienda" -> {
                if (!player.hasPermission("ethernova.cosmetics.shop")) {
                    player.sendMessage(mini.deserialize(
                            plugin.getConfigManager().getMessage("cosmetic-no-permission")));
                    return true;
                }
                new CosmeticShopGui(plugin.getCore(), player, plugin).open();
            }

            case "preview", "previa" -> {
                if (args.length < 2) {
                    player.sendMessage(mini.deserialize(
                            plugin.getConfigManager().getMessage("prefix")
                                    + "<yellow>Uso: /" + label + " preview <id>"));
                    return true;
                }
                String cosmeticId = args[1].toLowerCase();
                Cosmetic cosmetic = plugin.getCosmeticRegistry().getById(cosmeticId);
                if (cosmetic == null) {
                    player.sendMessage(mini.deserialize(
                            plugin.getConfigManager().getMessage("cosmetic-not-found")));
                    return true;
                }

                previewCosmetic(player, cosmetic);
            }

            case "collection", "coleccion" -> {
                new CollectionGui(plugin.getCore(), player, plugin).open();
            }

            case "mysterybox", "caja", "mystery", "box" -> {
                if (!player.hasPermission("ethernova.cosmetics.mysterybox")) {
                    player.sendMessage(mini.deserialize(
                            plugin.getConfigManager().getMessage("cosmetic-no-permission")));
                    return true;
                }
                new MysteryBoxGui(plugin.getCore(), player, plugin).open();
            }

            case "admin" -> {
                if (!player.hasPermission("ethernova.cosmetics.admin")) {
                    player.sendMessage(mini.deserialize(
                            plugin.getConfigManager().getMessage("cosmetic-no-permission")));
                    return true;
                }
                new CosmeticsAdminGui(plugin, player).open();
            }

            case "reload" -> {
                if (!player.hasPermission("ethernova.cosmetics.admin")) {
                    player.sendMessage(mini.deserialize(
                            plugin.getConfigManager().getMessage("cosmetic-no-permission")));
                    return true;
                }
                plugin.getConfigManager().reload();
                plugin.getCosmeticRegistry().loadFromYaml();
                player.sendMessage(mini.deserialize(
                        plugin.getConfigManager().getMessage("prefix")
                                + "<green>Configuración y cosméticos recargados."));
            }

            default -> {
                // Try to open as a type filter
                try {
                    CosmeticType type = CosmeticType.valueOf(sub.toUpperCase());
                    new com.ethernova.cosmetics.gui.CosmeticTypeGui(
                            plugin.getCore(), player, plugin, type).open();
                } catch (IllegalArgumentException e) {
                    player.sendMessage(mini.deserialize(
                            plugin.getConfigManager().getMessage("prefix")
                                    + "<yellow>Subcomandos: shop, preview, collection, mysterybox, reload"));
                }
            }
        }

        return true;
    }

    /**
     * Preview a cosmetic effect for the player.
     */
    private void previewCosmetic(Player player, Cosmetic cosmetic) {
        player.sendMessage(mini.deserialize(
                plugin.getConfigManager().getMessage("preview-start")
                        .replace("{cosmetic}", cosmetic.name())));

        plugin.getCore().getSoundManager().play(player, "click");

        switch (cosmetic.type()) {
            case KILL_EFFECT -> plugin.getKillEffectHandler().preview(player, cosmetic.id());
            case TRAIL -> plugin.getTrailHandler().preview(player, cosmetic.id());
            case PROJECTILE_TRAIL -> plugin.getProjectileTrailHandler().preview(player, cosmetic.id());
            case WIN_EFFECT -> plugin.getWinEffectHandler().preview(player, cosmetic.id());
            case DEATH_EFFECT -> plugin.getCosmeticListener().playDeathEffect(cosmetic.id(), player.getLocation());
            case HIT_EFFECT -> plugin.getHitEffectsManager().preview(player, cosmetic.id());
            case FINISHER -> plugin.getFinisherHandler().previewFinisher(player, cosmetic.id());
            case PET -> plugin.getPetManager().preview(player, cosmetic.id());
            case ELYTRA_TRAIL -> plugin.getElytraTrailHandler().preview(player, cosmetic.id());
            case DEATH_SOUND -> plugin.getDeathSoundHandler().preview(player, cosmetic.id());
            case TITLE -> plugin.getTitleManager().previewTitle(player, cosmetic.id());
            case WEAPON_SKIN, ARMOR_SKIN -> plugin.getSkinManager().preview(player, cosmetic.id());
            case KILL_MESSAGE -> {
                player.sendMessage(mini.deserialize(
                        "<gray>Ejemplo: " + getKillMessageSample(cosmetic.id(), player.getName())));
            }
            case DEATH_MESSAGE -> {
                player.sendMessage(mini.deserialize(
                        "<gray>Ejemplo: <gray>" + player.getName() + " murió en combate."));
            }
            case JOIN_MESSAGE -> {
                player.sendMessage(mini.deserialize(
                        "<gray>Ejemplo: <gray>" + player.getName() + " se ha unido al servidor."));
            }
        }
    }

    /**
     * Get a sample kill message for preview.
     */
    private String getKillMessageSample(String msgId, String playerName) {
        return switch (msgId.toLowerCase()) {
            case "msg_brutal" -> "<red><bold>" + playerName + "</bold></red> <dark_red>☠ DESTRUYÓ ☠</dark_red> <red>a un enemigo";
            case "msg_elegant" -> "<gradient:#ffd700:#ff69b4>" + playerName + "</gradient> <white>eliminó elegantemente a un rival</white>";
            case "msg_mythic" -> "<gradient:#ff0000:#ff7700:#ffff00:#00ff00:#0000ff:#8b00ff>" + playerName + "</gradient> <light_purple>⚡ ANIQUILÓ ⚡</light_purple> <gray>a un oponente";
            case "msg_samurai" -> "<gradient:#ff4444:#ff8800>" + playerName + "</gradient> <red>⚔ cortó en dos ⚔</red> <gray>a un rival";
            case "msg_glitch" -> "<obfuscated>xx</obfuscated><red>" + playerName + "</red><obfuscated>xx</obfuscated> <dark_red>█▓░ ELIMINÓ ░▓█</dark_red> <gray>a un oponente";
            default -> "<gray>" + playerName + " eliminó a un jugador";
        };
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                 @NotNull String alias, @NotNull String[] args) {
        List<String> completions = new ArrayList<>();

        if (args.length == 1) {
            completions.add("shop");
            completions.add("preview");
            completions.add("collection");
            completions.add("mysterybox");
            completions.add("tienda");
            completions.add("previa");
            completions.add("coleccion");
            completions.add("caja");
            if (sender.hasPermission("ethernova.cosmetics.admin")) {
                completions.add("reload");
                completions.add("admin");
            }
            for (CosmeticType type : CosmeticType.values()) {
                completions.add(type.name().toLowerCase());
            }
            return filterCompletions(completions, args[0]);
        }

        if (args.length == 2 && (args[0].equalsIgnoreCase("preview") || args[0].equalsIgnoreCase("previa"))) {
            completions.addAll(plugin.getCosmeticRegistry().getAllIds());
            return filterCompletions(completions, args[1]);
        }

        return completions;
    }

    /**
     * Filter tab completions by current input.
     */
    private List<String> filterCompletions(List<String> options, String input) {
        String lower = input.toLowerCase();
        return options.stream()
                .filter(s -> s.toLowerCase().startsWith(lower))
                .sorted()
                .collect(Collectors.toList());
    }
}
