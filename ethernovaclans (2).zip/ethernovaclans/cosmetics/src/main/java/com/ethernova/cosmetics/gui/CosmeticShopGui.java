package com.ethernova.cosmetics.gui;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.cosmetics.model.Cosmetic;
import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.PaginatedGui;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Shop GUI for purchasing cosmetics with coins.
 * Shows all purchasable cosmetics sorted by price, with buy-on-click functionality.
 */
public class CosmeticShopGui extends PaginatedGui {

    private final EthernovaCosmetics cosmetics;

    public CosmeticShopGui(EthernovaCore core, Player player, EthernovaCosmetics cosmetics) {
        super(core, player);
        this.cosmetics = cosmetics;
    }

    /**
     * Open the shop GUI.
     */
    public void open() {
        openPaginated("<gold>✦ Tienda de Cosméticos</gold>", 0);
    }

    @Override
    protected String getTitle() {
        return "<gold>✦ Tienda de Cosméticos</gold>";
    }

    @Override
    protected List<PageItem> getPageItems() {
        List<PageItem> items = new ArrayList<>();
        UUID uuid = player.getUniqueId();
        List<Cosmetic> purchasable = cosmetics.getCosmeticRegistry().getPurchasable();

        var profile = core.getProfileManager().getProfile(uuid);
        double coins = profile != null ? profile.getCoins() : 0;

        for (Cosmetic cosmetic : purchasable) {
            boolean owned = cosmetics.getPlayerCosmeticManager().isUnlocked(uuid, cosmetic.id());
            boolean canAfford = coins >= cosmetic.price();
            boolean isVip = cosmetic.vip();
            boolean playerIsVip = player.hasPermission("ethernova.vip");

            List<String> lore = new ArrayList<>();
            lore.add("");
            String rarityLine = cosmetic.rarity().getFormattedName() + " <dark_gray>| " + cosmetic.type().getDisplayName();
            if (isVip) rarityLine += " <dark_gray>| <gold>⭐ VIP";
            lore.add(rarityLine);
            lore.add("");
            lore.add("<gray>" + cosmetic.description());
            lore.add("");

            if (owned) {
                lore.add("<green>✔ Ya lo tienes");
            } else if (isVip && !playerIsVip) {
                lore.add("<gold>⭐ Exclusivo VIP");
                lore.add("<gray>Necesitas rango <gold>VIP <gray>para comprar");
            } else {
                lore.add("<gray>Precio: " + cosmetic.formattedPrice());
                lore.add("<gray>Tus monedas: <gold>" + String.format("%.0f", coins));
                lore.add("");
                if (canAfford) {
                    lore.add("<green>▶ Click para comprar");
                } else {
                    lore.add("<red>✘ No tienes suficientes monedas");
                }
            }

            ItemStack item = createItem(cosmetic.icon(), cosmetic.coloredName(), lore);
            items.add(new PageItem(item, "BUY_" + cosmetic.id()));
        }

        return items;
    }

    @Override
    protected boolean onItemClick(String action, int slot, InventoryClickEvent event) {
        if (!action.startsWith("BUY_")) return false;

        String cosmeticId = action.substring(4);
        UUID uuid = player.getUniqueId();
        Cosmetic cosmetic = cosmetics.getCosmeticRegistry().getById(cosmeticId);
        if (cosmetic == null) return true;

        // Already owned?
        if (cosmetics.getPlayerCosmeticManager().isUnlocked(uuid, cosmeticId)) {
            core.getSoundManager().play(player, "error");
            player.sendMessage(MiniMessage.miniMessage().deserialize(
                    cosmetics.getConfigManager().getMessage("cosmetic-already-owned")));
            return true;
        }

        // Check permission
        if (!cosmetic.permission().isEmpty() && !player.hasPermission(cosmetic.permission())) {
            core.getSoundManager().play(player, "error");
            player.sendMessage(MiniMessage.miniMessage().deserialize(
                    cosmetics.getConfigManager().getMessage("cosmetic-no-permission")));
            return true;
        }

        // Check VIP requirement
        if (cosmetic.vip() && !player.hasPermission("ethernova.vip")) {
            core.getSoundManager().play(player, "error");
            player.sendMessage(MiniMessage.miniMessage().deserialize(
                    "<red>✘ Este cosmético es <gold>⭐ Exclusivo VIP<red>. Necesitas rango VIP."));
            return true;
        }

        // Check coins
        var profile = core.getProfileManager().getProfile(uuid);
        if (profile == null) {
            core.getSoundManager().play(player, "error");
            return true;
        }

        if (profile.getCoins() < cosmetic.price()) {
            core.getSoundManager().play(player, "error");
            player.sendMessage(MiniMessage.miniMessage().deserialize(
                    cosmetics.getConfigManager().getMessage("cosmetic-not-enough-coins")
                            .replace("{price}", String.format("%.0f", cosmetic.price()))));
            return true;
        }

        // Purchase
        profile.addCoins(-cosmetic.price());
        cosmetics.getPlayerCosmeticManager().unlock(uuid, cosmetic.id());
        core.getSoundManager().play(player, "reward");
        player.sendMessage(MiniMessage.miniMessage().deserialize(
                cosmetics.getConfigManager().getMessage("cosmetic-bought")
                        .replace("{cosmetic}", cosmetic.name())
                        .replace("{price}", String.format("%.0f", cosmetic.price()))));
        open(); // Refresh
        return true;
    }

    @Override
    protected void onBack() {
        new CosmeticsMainGui(core, player, cosmetics).open();
    }
}
