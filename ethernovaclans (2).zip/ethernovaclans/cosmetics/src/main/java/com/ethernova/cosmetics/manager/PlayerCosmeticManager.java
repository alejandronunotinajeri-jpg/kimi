package com.ethernova.cosmetics.manager;

import com.ethernova.cosmetics.model.Cosmetic;
import com.ethernova.cosmetics.model.CosmeticType;
import com.ethernova.core.storage.CoreStorageManager;
import com.ethernova.core.storage.MigrationManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Manages per-player cosmetic unlocks and equipped cosmetics.
 * Persists data to the ethernova_cosmetics table via Core's StorageManager.
 */
public class PlayerCosmeticManager {

    private final CoreStorageManager storage;
    private final CosmeticRegistry registry;
    private final Logger logger;

    /** Map<playerUUID, Set<cosmeticId>> — unlocked cosmetics per player */
    private final Map<UUID, Set<String>> unlocked = new ConcurrentHashMap<>();

    /** Map<playerUUID, Map<CosmeticType, cosmeticId>> — equipped cosmetic per type per player */
    private final Map<UUID, Map<CosmeticType, String>> equipped = new ConcurrentHashMap<>();

    public PlayerCosmeticManager(CoreStorageManager storage, CosmeticRegistry registry, Logger logger) {
        this.storage = storage;
        this.registry = registry;
        this.logger = logger;
        runMigrations();
    }

    /**
     * Run database migrations for the cosmetics table.
     */
    private void runMigrations() {
        new MigrationManager(storage, logger, "ethernova_cosmetics")
                .addMigration(1,
                        """
                        CREATE TABLE IF NOT EXISTS ethernova_cosmetics (
                            uuid VARCHAR(36) NOT NULL,
                            cosmetic_id VARCHAR(64) NOT NULL,
                            equipped TINYINT DEFAULT 0,
                            unlocked_at BIGINT DEFAULT 0,
                            PRIMARY KEY (uuid, cosmetic_id)
                        )
                        """)
                .migrate();
    }

    /**
     * Load a player's cosmetics from the database into memory.
     */
    public void loadPlayer(UUID uuid) {
        if (uuid == null) return;
        Set<String> playerUnlocked = ConcurrentHashMap.newKeySet();
        Map<CosmeticType, String> playerEquipped = new ConcurrentHashMap<>();

        try (Connection conn = storage.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT cosmetic_id, equipped FROM ethernova_cosmetics WHERE uuid = ?")) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String cosmeticId = rs.getString("cosmetic_id");
                    boolean isEquipped = rs.getInt("equipped") == 1;
                    playerUnlocked.add(cosmeticId.toLowerCase());

                    if (isEquipped) {
                        Cosmetic cosmetic = registry.getById(cosmeticId);
                        if (cosmetic != null) {
                            playerEquipped.put(cosmetic.type(), cosmeticId);
                        }
                    }
                }
            }
        } catch (Exception e) {
            logger.log(Level.WARNING, "Error cargando cosméticos para " + uuid, e);
        }

        unlocked.put(uuid, playerUnlocked);
        equipped.put(uuid, playerEquipped);
    }

    /**
     * Save a player's cosmetics to the database and remove from memory.
     */
    public void saveAndUnloadPlayer(UUID uuid) {
        if (uuid == null) return;
        savePlayer(uuid);
        unlocked.remove(uuid);
        equipped.remove(uuid);
    }

    /**
     * Save a player's cosmetics to the database.
     */
    public void savePlayer(UUID uuid) {
        if (uuid == null) return;
        Set<String> playerUnlocked = unlocked.get(uuid);
        if (playerUnlocked == null || playerUnlocked.isEmpty()) return;
        Map<CosmeticType, String> playerEquipped = equipped.getOrDefault(uuid, Collections.emptyMap());

        String sql = storage.isMySQL()
                ? "INSERT INTO ethernova_cosmetics (uuid, cosmetic_id, equipped, unlocked_at) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE equipped=VALUES(equipped)"
                : "INSERT INTO ethernova_cosmetics (uuid, cosmetic_id, equipped, unlocked_at) VALUES (?,?,?,?) ON CONFLICT(uuid, cosmetic_id) DO UPDATE SET equipped=excluded.equipped";

        try (Connection conn = storage.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            Collection<String> equippedIds = playerEquipped.values();
            for (String cosmeticId : playerUnlocked) {
                ps.setString(1, uuid.toString());
                ps.setString(2, cosmeticId);
                ps.setInt(3, equippedIds.contains(cosmeticId) ? 1 : 0);
                ps.setLong(4, System.currentTimeMillis());
                ps.addBatch();
            }
            ps.executeBatch();
        } catch (Exception e) {
            logger.log(Level.WARNING, "Error guardando cosméticos para " + uuid, e);
        }
    }

    /**
     * Save all loaded players' cosmetics to the database.
     */
    public void saveAll() {
        for (UUID uuid : unlocked.keySet()) {
            savePlayer(uuid);
        }
    }

    /**
     * Unlock a cosmetic for a player.
     * @return true if newly unlocked, false if already owned
     */
    public boolean unlock(UUID uuid, String cosmeticId) {
        if (uuid == null || cosmeticId == null) return false;
        Set<String> playerUnlocked = unlocked.computeIfAbsent(uuid, k -> ConcurrentHashMap.newKeySet());
        boolean added = playerUnlocked.add(cosmeticId.toLowerCase());

        if (added) {
            // Persist immediately
            String sql = storage.isMySQL()
                    ? "INSERT INTO ethernova_cosmetics (uuid, cosmetic_id, equipped, unlocked_at) VALUES (?,?,0,?) ON DUPLICATE KEY UPDATE cosmetic_id=cosmetic_id"
                    : "INSERT INTO ethernova_cosmetics (uuid, cosmetic_id, equipped, unlocked_at) VALUES (?,?,0,?) ON CONFLICT(uuid, cosmetic_id) DO NOTHING";
            try (Connection conn = storage.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, uuid.toString());
                ps.setString(2, cosmeticId.toLowerCase());
                ps.setLong(3, System.currentTimeMillis());
                ps.executeUpdate();
            } catch (Exception e) {
                logger.log(Level.WARNING, "Error desbloqueando cosmético " + cosmeticId + " para " + uuid, e);
            }
        }
        return added;
    }

    /**
     * Check if a player has a cosmetic unlocked.
     */
    public boolean isUnlocked(UUID uuid, String cosmeticId) {
        if (uuid == null || cosmeticId == null) return false;
        Set<String> playerUnlocked = unlocked.get(uuid);
        return playerUnlocked != null && playerUnlocked.contains(cosmeticId.toLowerCase());
    }

    /**
     * Equip a cosmetic for a player. Unequips any previously equipped cosmetic of the same type.
     * @return true if equipped successfully
     */
    public boolean equip(UUID uuid, String cosmeticId) {
        if (uuid == null || cosmeticId == null) return false;
        if (!isUnlocked(uuid, cosmeticId)) return false;

        Cosmetic cosmetic = registry.getById(cosmeticId);
        if (cosmetic == null) return false;

        Map<CosmeticType, String> playerEquipped = equipped.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>());
        playerEquipped.put(cosmetic.type(), cosmeticId.toLowerCase());

        // Persist equip state
        updateEquipState(uuid, cosmeticId, true);
        return true;
    }

    /**
     * Unequip the cosmetic of a given type for a player.
     * @return the ID of the unequipped cosmetic, or null if none was equipped
     */
    public String unequip(UUID uuid, CosmeticType type) {
        if (uuid == null || type == null) return null;
        Map<CosmeticType, String> playerEquipped = equipped.get(uuid);
        if (playerEquipped == null) return null;

        String removed = playerEquipped.remove(type);
        if (removed != null) {
            updateEquipState(uuid, removed, false);
        }
        return removed;
    }

    /**
     * Unequip a specific cosmetic by ID for a player.
     * @return true if unequipped
     */
    public boolean unequipById(UUID uuid, String cosmeticId) {
        if (uuid == null || cosmeticId == null) return false;
        Cosmetic cosmetic = registry.getById(cosmeticId);
        if (cosmetic == null) return false;

        Map<CosmeticType, String> playerEquipped = equipped.get(uuid);
        if (playerEquipped == null) return false;

        String current = playerEquipped.get(cosmetic.type());
        if (cosmeticId.equalsIgnoreCase(current)) {
            playerEquipped.remove(cosmetic.type());
            updateEquipState(uuid, cosmeticId, false);
            return true;
        }
        return false;
    }

    /**
     * Get the equipped cosmetic ID for a player and type.
     * @return cosmetic ID or null if none equipped
     */
    public String getEquipped(UUID uuid, CosmeticType type) {
        if (uuid == null || type == null) return null;
        Map<CosmeticType, String> playerEquipped = equipped.get(uuid);
        if (playerEquipped == null) return null;
        return playerEquipped.get(type);
    }

    /**
     * Get all equipped cosmetic IDs for a player mapped by type.
     */
    public Map<CosmeticType, String> getAllEquipped(UUID uuid) {
        if (uuid == null) return Collections.emptyMap();
        Map<CosmeticType, String> playerEquipped = equipped.get(uuid);
        if (playerEquipped == null) return Collections.emptyMap();
        return Collections.unmodifiableMap(playerEquipped);
    }

    /**
     * Get all unlocked cosmetic IDs for a player.
     */
    public Set<String> getAllUnlocked(UUID uuid) {
        if (uuid == null) return Collections.emptySet();
        Set<String> playerUnlocked = unlocked.get(uuid);
        if (playerUnlocked == null) return Collections.emptySet();
        return Collections.unmodifiableSet(playerUnlocked);
    }

    /**
     * Check if a player has a specific cosmetic type equipped.
     */
    public boolean hasEquipped(UUID uuid, CosmeticType type) {
        return getEquipped(uuid, type) != null;
    }

    /**
     * Update the equipped state in the database.
     */
    private void updateEquipState(UUID uuid, String cosmeticId, boolean isEquipped) {
        try (Connection conn = storage.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "UPDATE ethernova_cosmetics SET equipped = ? WHERE uuid = ? AND cosmetic_id = ?")) {
            ps.setInt(1, isEquipped ? 1 : 0);
            ps.setString(2, uuid.toString());
            ps.setString(3, cosmeticId.toLowerCase());
            ps.executeUpdate();
        } catch (Exception e) {
            logger.log(Level.WARNING, "Error actualizando estado de equip para " + cosmeticId, e);
        }
    }
}
