package com.ethernova.cosmetics.gui;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.cosmetics.model.CosmeticType;
import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.PaginatedGui;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * Main cosmetics menu showing buttons for each CosmeticType category.
 * Players click a category to browse cosmetics of that type.
 */
public class CosmeticsMainGui extends PaginatedGui {

    private final EthernovaCosmetics cosmetics;

    public CosmeticsMainGui(EthernovaCore core, Player player, EthernovaCosmetics cosmetics) {
        super(core, player);
        this.cosmetics = cosmetics;
    }

    /**
     * Opens the main cosmetics menu.
     */
    public void open() {
        openPaginated("<gradient:#a855f7:#ec4899>✦ Cosméticos</gradient>", 0);
    }

    @Override
    protected String getTitle() {
        return "<gradient:#a855f7:#ec4899>✦ Cosméticos</gradient>";
    }

    @Override
    protected List<PageItem> getPageItems() {
        List<PageItem> items = new ArrayList<>();

        // Types to hide from this menu
        java.util.Set<CosmeticType> hiddenTypes = java.util.EnumSet.of(
                CosmeticType.TRAIL, CosmeticType.WEAPON_SKIN,
                CosmeticType.ARMOR_SKIN, CosmeticType.KILL_MESSAGE,
                CosmeticType.TITLE);

        for (CosmeticType type : CosmeticType.values()) {
            if (hiddenTypes.contains(type)) continue;
            String enabledKey = type.name().toLowerCase().replace("_", "-");
            if (!cosmetics.getConfigManager().isTypeEnabled(enabledKey)) continue;

            int count = cosmetics.getCosmeticRegistry().getByType(type).size();
            String equippedId = cosmetics.getPlayerCosmeticManager().getEquipped(player.getUniqueId(), type);
            String equippedText = equippedId != null
                    ? "<green>Equipado: <white>" + getEquippedName(equippedId)
                    : "<gray>Ninguno equipado";

            List<String> lore = List.of(
                    "",
                    "<gray>Cosméticos disponibles: <white>" + count,
                    equippedText,
                    "",
                    "<yellow>▶ Click para ver"
            );

            items.add(new PageItem(
                    createItem(type.getIcon(), "<light_purple>" + type.getDisplayName(), new ArrayList<>(lore)),
                    "TYPE_" + type.name()
            ));
        }

        // Mystery Boxes button
        int boxCount = cosmetics.getCosmeticRegistry().getMysteryBoxes().size();
        if (boxCount > 0) {
            items.add(new PageItem(
                    createItem(Material.ENDER_CHEST, "<gradient:#ff6b35:#ffd700>✦ Mystery Boxes</gradient>", List.of(
                            "",
                            "<gray>Abre cajas con cosméticos al azar",
                            "<gray>Cajas disponibles: <white>" + boxCount,
                            "",
                            "<yellow>▶ Click para abrir"
                    )),
                    "MYSTERY_BOXES"
            ));
        }

        // Collection button
        int totalOwned = cosmetics.getPlayerCosmeticManager().getAllUnlocked(player.getUniqueId()).size();
        int totalAll = cosmetics.getCosmeticRegistry().size();
        double pct = totalAll > 0 ? (double) totalOwned / totalAll * 100 : 0;
        items.add(new PageItem(
                createItem(Material.BOOK, "<gradient:#00d4ff:#00ff88>✦ Mi Colección</gradient>", List.of(
                        "",
                        "<gray>Progreso: <white>" + totalOwned + "<gray>/<white>" + totalAll
                                + " <dark_gray>(" + String.format("%.0f", pct) + "%)",
                        "",
                        "<yellow>▶ Click para ver"
                )),
                "COLLECTION"
        ));

        // Armor Trims button
        items.add(new PageItem(
                createItem(Material.SMITHING_TABLE, "<gradient:#ffd700:#ff8c00>✦ Armor Trims</gradient>", List.of(
                        "",
                        "<gray>Personaliza tu armadura pieza por pieza",
                        "<gray>Patrones y materiales de decoración",
                        "",
                        "<yellow>▶ Click para editar"
                )),
                "ARMOR_TRIMS"
        ));

        // Advanced Auras button
        items.add(new PageItem(
                createItem(Material.BLAZE_POWDER, "<gradient:#ff6b35:#ff1493>✦ Auras Avanzadas</gradient>", List.of(
                        "",
                        "<gray>48 auras con 12 patrones cada una",
                        "<gray>Fusiones, slots múltiples y más",
                        "",
                        "<yellow>▶ Click para abrir"
                )),
                "AURAS"
        ));

        return items;
    }

    @Override
    protected boolean onItemClick(String action, int slot, InventoryClickEvent event) {
        if (action.startsWith("TYPE_")) {
            playSound("click");
            String typeName = action.substring(5);
            try {
                CosmeticType type = CosmeticType.valueOf(typeName);
                // TITLE: open TitleManager's own GUI
                if (type == CosmeticType.TITLE) {
                    cosmetics.getTitleManager().openTitlesGUI(player, 1);
                    return true;
                }
                new CosmeticTypeGui(core, player, cosmetics, type).open();
            } catch (IllegalArgumentException e) {
                // Invalid type — ignore
            }
            return true;
        }

        if ("ARMOR_TRIMS".equals(action)) {
            playSound("click");
            cosmetics.getArmorTrimManager().openArmorSelector(player);
            return true;
        }

        if ("SHOP".equals(action)) {
            playSound("click");
            new CosmeticShopGui(core, player, cosmetics).open();
            return true;
        }

        if ("MYSTERY_BOXES".equals(action)) {
            playSound("click");
            new MysteryBoxGui(core, player, cosmetics).open();
            return true;
        }

        if ("COLLECTION".equals(action)) {
            playSound("click");
            new CollectionGui(core, player, cosmetics).open();
            return true;
        }

        if ("AURAS".equals(action)) {
            playSound("click");
            var aurasManager = cosmetics.getAdvancedAurasManager();
            if (aurasManager != null && aurasManager.getGUIManager() != null) {
                aurasManager.getGUIManager().openTiersGUI(player);
            }
            return true;
        }

        return false;
    }

    @Override
    protected void onBack() {
        player.closeInventory();
    }

    /**
     * Get the display name of an equipped cosmetic by ID.
     */
    private String getEquippedName(String id) {
        var cosmetic = cosmetics.getCosmeticRegistry().getById(id);
        return cosmetic != null ? cosmetic.name() : id;
    }
}
