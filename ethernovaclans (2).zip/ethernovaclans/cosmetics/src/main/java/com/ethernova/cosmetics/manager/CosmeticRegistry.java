package com.ethernova.cosmetics.manager;

import com.ethernova.cosmetics.model.Cosmetic;
import com.ethernova.cosmetics.model.CosmeticRarity;
import com.ethernova.cosmetics.model.CosmeticType;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * Registry of all cosmetics. Loads from cosmetics.yml (YAML-based, admin-configurable).
 * Falls back to bundled defaults on first run.
 */
public class CosmeticRegistry {

    private final Map<String, Cosmetic> byId = new ConcurrentHashMap<>();
    private final Map<CosmeticType, List<Cosmetic>> byType = new ConcurrentHashMap<>();
    private final Map<CosmeticRarity, List<Cosmetic>> byRarity = new ConcurrentHashMap<>();
    private final JavaPlugin plugin;
    private final Logger logger;
    /** Cached cosmetics.yml to avoid re-reading from disk on every getCosmeticSection() call */
    private volatile YamlConfiguration cachedConfig;

    // Mystery box definitions
    private final Map<String, MysteryBoxDef> mysteryBoxes = new LinkedHashMap<>();

    public record MysteryBoxDef(String id, String name, String description, Material icon, double price,
                                 Map<CosmeticRarity, Integer> weights) {}

    public CosmeticRegistry(JavaPlugin plugin) {
        this.plugin = plugin;
        this.logger = plugin.getLogger();
        loadFromYaml();
    }

    /**
     * Load all cosmetics and mystery boxes from cosmetics.yml.
     */
    public void loadFromYaml() {
        byId.clear();
        byType.clear();
        byRarity.clear();
        mysteryBoxes.clear();

        File cosmFile = new File(plugin.getDataFolder(), "cosmetics.yml");
        if (!cosmFile.exists()) {
            plugin.saveResource("cosmetics.yml", false);
        }

        // Merge new defaults into existing file
        YamlConfiguration config = YamlConfiguration.loadConfiguration(cosmFile);
        this.cachedConfig = config; // Cache for getCosmeticSection()
        try (InputStream defStream = plugin.getResource("cosmetics.yml")) {
            if (defStream != null) {
                YamlConfiguration defaults = YamlConfiguration.loadConfiguration(
                        new InputStreamReader(defStream, StandardCharsets.UTF_8));
                int added = 0;
                for (String key : defaults.getKeys(true)) {
                    if (!config.contains(key)) {
                        config.set(key, defaults.get(key));
                        added++;
                    }
                }
                if (added > 0) {
                    config.save(cosmFile);
                    logger.info("cosmetics.yml actualizado: " + added + " clave(s) nueva(s)");
                }
            }
        } catch (Exception e) {
            logger.log(Level.WARNING, "Error merging cosmetics.yml defaults", e);
        }

        // Load cosmetics
        ConfigurationSection cosmeticsSection = config.getConfigurationSection("cosmetics");
        if (cosmeticsSection != null) {
            for (String id : cosmeticsSection.getKeys(false)) {
                ConfigurationSection cs = cosmeticsSection.getConfigurationSection(id);
                if (cs == null) continue;
                try {
                    CosmeticType type = CosmeticType.valueOf(cs.getString("type", "KILL_EFFECT").toUpperCase());
                    String name = cs.getString("name", id);
                    String desc = cs.getString("description", "");
                    Material icon = parseMaterial(cs.getString("icon", "BARRIER"));
                    String permission = cs.getString("permission", "");
                    double price = cs.getDouble("price", 0);
                    CosmeticRarity rarity = parseRarity(cs.getString("rarity", "COMMON"));
                    boolean vip = cs.getBoolean("vip", false);

                    register(new Cosmetic(id.toLowerCase(), type, name, desc, icon, permission, price, rarity, vip));
                } catch (Exception e) {
                    logger.log(java.util.logging.Level.WARNING, "Error cargando cosmético '" + id + "'", e);
                }
            }
        }

        // Load mystery boxes
        ConfigurationSection boxSection = config.getConfigurationSection("mystery-boxes");
        if (boxSection != null) {
            for (String boxId : boxSection.getKeys(false)) {
                ConfigurationSection bs = boxSection.getConfigurationSection(boxId);
                if (bs == null) continue;
                try {
                    String name = bs.getString("name", boxId);
                    String desc = bs.getString("description", "");
                    Material icon = parseMaterial(bs.getString("icon", "CHEST"));
                    double price = bs.getDouble("price", 0);

                    Map<CosmeticRarity, Integer> weights = new EnumMap<>(CosmeticRarity.class);
                    ConfigurationSection ws = bs.getConfigurationSection("weights");
                    if (ws != null) {
                        for (CosmeticRarity r : CosmeticRarity.values()) {
                            weights.put(r, ws.getInt(r.name(), 0));
                        }
                    }

                    mysteryBoxes.put(boxId.toLowerCase(), new MysteryBoxDef(boxId, name, desc, icon, price, weights));
                } catch (Exception e) {
                    logger.log(java.util.logging.Level.WARNING, "Error cargando mystery box '" + boxId + "'", e);
                }
            }
        }

        logger.info("Cargados " + byId.size() + " cosméticos y " + mysteryBoxes.size() + " mystery boxes desde cosmetics.yml");
    }

    /**
     * Register a cosmetic into the registry.
     */
    public void register(Cosmetic cosmetic) {
        if (cosmetic == null) return;
        byId.put(cosmetic.id(), cosmetic);
        byType.computeIfAbsent(cosmetic.type(), k -> Collections.synchronizedList(new ArrayList<>())).add(cosmetic);
        byRarity.computeIfAbsent(cosmetic.rarity(), k -> Collections.synchronizedList(new ArrayList<>())).add(cosmetic);
    }

    // ═══════════════ Query Methods ═══════════════

    public Cosmetic getById(String id) {
        if (id == null) return null;
        return byId.get(id.toLowerCase());
    }

    public List<Cosmetic> getByType(CosmeticType type) {
        if (type == null) return Collections.emptyList();
        List<Cosmetic> list = byType.getOrDefault(type, Collections.emptyList());
        // Sort by rarity ordinal (ascending: COMMON first) then by price (ascending)
        return list.stream()
                .sorted(Comparator.comparingInt((Cosmetic c) -> c.rarity().ordinal())
                        .thenComparingDouble(Cosmetic::price))
                .collect(Collectors.toList());
    }

    public List<Cosmetic> getByRarity(CosmeticRarity rarity) {
        if (rarity == null) return Collections.emptyList();
        return byRarity.getOrDefault(rarity, Collections.emptyList());
    }

    public Collection<Cosmetic> getAll() {
        return Collections.unmodifiableCollection(byId.values());
    }

    public Set<String> getAllIds() {
        return Collections.unmodifiableSet(byId.keySet());
    }

    public int size() { return byId.size(); }

    public List<Cosmetic> getPurchasable() {
        return byId.values().stream()
                .filter(Cosmetic::isPurchasable)
                .sorted(Comparator.comparingDouble(Cosmetic::price))
                .collect(Collectors.toList());
    }

    // ═══════════════ Mystery Boxes ═══════════════

    public Map<String, MysteryBoxDef> getMysteryBoxes() {
        return Collections.unmodifiableMap(mysteryBoxes);
    }

    public MysteryBoxDef getMysteryBox(String id) {
        if (id == null) return null;
        return mysteryBoxes.get(id.toLowerCase());
    }

    // ═══════════════ Collection Stats ═══════════════

    public int countByType(CosmeticType type) {
        return getByType(type).size();
    }

    public int countByRarity(CosmeticRarity rarity) {
        return getByRarity(rarity).size();
    }

    // ═══════════════ Utility ═══════════════

    /**
     * Get the raw YAML ConfigurationSection for a specific cosmetic by ID.
     * Useful for handlers that need extra config beyond the Cosmetic record (e.g. model-data).
     */
    public ConfigurationSection getCosmeticSection(String id) {
        if (id == null) return null;
        YamlConfiguration config = this.cachedConfig;
        if (config == null) return null;
        ConfigurationSection cosmeticsSection = config.getConfigurationSection("cosmetics");
        return cosmeticsSection != null ? cosmeticsSection.getConfigurationSection(id.toLowerCase()) : null;
    }

    private Material parseMaterial(String name) {
        try {
            return Material.valueOf(name.toUpperCase());
        } catch (IllegalArgumentException e) {
            return Material.BARRIER;
        }
    }

    private CosmeticRarity parseRarity(String name) {
        try {
            return CosmeticRarity.valueOf(name.toUpperCase());
        } catch (IllegalArgumentException e) {
            return CosmeticRarity.COMMON;
        }
    }
}
