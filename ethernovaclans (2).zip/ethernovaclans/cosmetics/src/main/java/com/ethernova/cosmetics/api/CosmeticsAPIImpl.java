package com.ethernova.cosmetics.api;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.cosmetics.model.Cosmetic;
import com.ethernova.cosmetics.model.CosmeticType;
import org.bukkit.Location;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Implementation of CosmeticsAPI. Registered with ServiceRegistry on enable.
 */
public class CosmeticsAPIImpl implements CosmeticsAPI {

    private final EthernovaCosmetics plugin;

    public CosmeticsAPIImpl(EthernovaCosmetics plugin) {
        this.plugin = plugin;
    }

    // ═══════════════ Player Cosmetic State ═══════════════

    @Override
    public boolean isUnlocked(UUID uuid, String cosmeticId) {
        return plugin.getPlayerCosmeticManager().isUnlocked(uuid, cosmeticId);
    }

    @Override
    public boolean unlock(UUID uuid, String cosmeticId) {
        return plugin.getPlayerCosmeticManager().unlock(uuid, cosmeticId);
    }

    @Override
    public boolean equip(UUID uuid, String cosmeticId) {
        return plugin.getPlayerCosmeticManager().equip(uuid, cosmeticId);
    }

    @Override
    public String unequip(UUID uuid, CosmeticType type) {
        return plugin.getPlayerCosmeticManager().unequip(uuid, type);
    }

    @Override
    public String getEquipped(UUID uuid, CosmeticType type) {
        return plugin.getPlayerCosmeticManager().getEquipped(uuid, type);
    }

    @Override
    public Map<CosmeticType, String> getAllEquipped(UUID uuid) {
        return plugin.getPlayerCosmeticManager().getAllEquipped(uuid);
    }

    @Override
    public Set<String> getAllUnlocked(UUID uuid) {
        return plugin.getPlayerCosmeticManager().getAllUnlocked(uuid);
    }

    @Override
    public boolean hasEquipped(UUID uuid, CosmeticType type) {
        return plugin.getPlayerCosmeticManager().hasEquipped(uuid, type);
    }

    // ═══════════════ Registry Queries ═══════════════

    @Override
    public Cosmetic getCosmetic(String id) {
        return plugin.getCosmeticRegistry().getById(id);
    }

    @Override
    public List<Cosmetic> getCosmeticsByType(CosmeticType type) {
        return plugin.getCosmeticRegistry().getByType(type);
    }

    @Override
    public Collection<Cosmetic> getAllCosmetics() {
        return plugin.getCosmeticRegistry().getAll();
    }

    @Override
    public int getCosmeticCount() {
        return plugin.getCosmeticRegistry().size();
    }

    // ═══════════════ Effect Triggers ═══════════════

    @Override
    public void triggerKillEffect(UUID killerUuid, Location victimLocation) {
        plugin.getKillEffectHandler().triggerKillEffect(killerUuid, victimLocation);
    }

    @Override
    public void triggerWinEffect(UUID uuid) {
        plugin.getWinEffectHandler().triggerWinEffect(uuid);
    }

    // ═══════════════ Trail Queries ═══════════════

    @Override
    public boolean hasActiveTrail(UUID uuid) {
        return plugin.getTrailHandler().hasActiveTrail(uuid);
    }
}
