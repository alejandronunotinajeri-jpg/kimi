package com.ethernova.cosmetics.aura;

/**
 * Represents an active aura equipped in a slot.
 */
public record ActiveAura(String auraId, String patternId) {
    public ActiveAura(String auraId) {
        this(auraId, "falling");
    }
}
