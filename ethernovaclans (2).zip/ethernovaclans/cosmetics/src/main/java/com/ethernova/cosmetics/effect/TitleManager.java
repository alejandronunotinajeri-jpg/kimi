package com.ethernova.cosmetics.effect;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.cosmetics.gui.CosmeticsMainGui;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * TitlesManager — Sistema de títulos desbloqueables matching original UltimateFFA.
 * 30+ títulos con prefijos/sufijos, chat/nametag integration, paginación GUI.
 */
public class TitleManager {

    private final EthernovaCosmetics plugin;

    // Cache: UUID -> set of unlocked title IDs
    private final Map<UUID, Set<String>> unlockedTitles = new ConcurrentHashMap<>();
    // Cache: UUID -> active title ID
    private final Map<UUID, String> activeTitles = new ConcurrentHashMap<>();
    // Loaded title definitions
    private final Map<String, TitleData> titlesCache = new LinkedHashMap<>();

    public TitleManager(EthernovaCosmetics plugin) {
        this.plugin = plugin;
        loadDefaultTitles();
    }

    private void loadDefaultTitles() {
        // ═══════════════ COMMON ═══════════════
        reg("novato", "§7[Novato]", "§7[Novato] ", "", "COMMON", Material.WOODEN_SWORD, "DEFAULT", 0);
        reg("guerrero", "§a[Guerrero]", "§a[Guerrero] ", "", "COMMON", Material.STONE_SWORD, "KILLS", 50);
        reg("cazador", "§2[Cazador]", "§2[Cazador] ", "", "COMMON", Material.BOW, "KILLS", 100);
        reg("veterano", "§6[Veterano]", "§6[Veterano] ", "", "COMMON", Material.IRON_SWORD, "KILLS", 250);
        reg("gladiador", "§c[Gladiador]", "§c[Gladiador] ", "", "COMMON", Material.GOLDEN_SWORD, "KILLS", 500);

        // ═══════════════ RARE ═══════════════
        reg("destructor", "§9[Destructor]", "§9[Destructor] ", "", "RARE", Material.DIAMOND_SWORD, "KILLS", 1000);
        reg("asesino", "§4[Asesino]", "§4[Asesino] ", "", "RARE", Material.NETHERITE_SWORD, "KILLS", 2000);
        reg("titan", "§b[Titán]", "§b[Titán] ", "", "RARE", Material.TRIDENT, "KILLS", 3000);
        reg("conquistador", "§3[Conquistador]", "§3[Conquistador] ", "", "RARE", Material.SHIELD, "KILLS", 5000);
        reg("berserker", "§c[Berserker]", "§c[Berserker] ", "", "RARE", Material.NETHERITE_AXE, "KILLS", 7500);

        // ═══════════════ EPIC ═══════════════
        reg("leyenda", "§5[Leyenda]", "§5[Leyenda] ", "", "EPIC", Material.NETHER_STAR, "KILLS", 10000);
        reg("inmortal", "§d[Inmortal]", "§d[Inmortal] ", "", "EPIC", Material.TOTEM_OF_UNDYING, "KILLS", 15000);
        reg("demonio", "§4[Demonio]", "§4[Demonio] ", "", "EPIC", Material.BLAZE_POWDER, "KILLS", 20000);
        reg("dios_guerra", "§6[Dios de Guerra]", "§6[Dios de Guerra] ", "", "EPIC", Material.GOLDEN_APPLE, "KILLS", 25000);

        // ═══════════════ LEGENDARY ═══════════════
        reg("supremo", "§6§l[SUPREMO]", "§6§l[SUPREMO] ", "", "LEGENDARY", Material.DRAGON_EGG, "KILLS", 50000);
        reg("omnipotente", "§c§l[OMNIPOTENTE]", "§c§l[OMNIPOTENTE] ", "", "LEGENDARY", Material.END_CRYSTAL, "KILLS", 100000);

        // ═══════════════ PRESTIGE TITLES ═══════════════
        reg("prestige_1", "§e✦ Prestige I", "§e✦ ", "", "RARE", Material.GOLD_INGOT, "PRESTIGE", 1);
        reg("prestige_5", "§6✦✦ Prestige V", "§6✦✦ ", "", "EPIC", Material.GOLD_BLOCK, "PRESTIGE", 5);
        reg("prestige_10", "§c§l✦✦✦ Prestige X", "§c§l✦✦✦ ", "", "LEGENDARY", Material.BEACON, "PRESTIGE", 10);

        // ═══════════════ LEVEL TITLES ═══════════════
        reg("nivel_25", "§a[Nivel 25]", "§a[Lv25] ", "", "COMMON", Material.EXPERIENCE_BOTTLE, "LEVEL", 25);
        reg("nivel_50", "§b[Nivel 50]", "§b[Lv50] ", "", "RARE", Material.EXPERIENCE_BOTTLE, "LEVEL", 50);
        reg("nivel_75", "§5[Nivel 75]", "§5[Lv75] ", "", "EPIC", Material.EXPERIENCE_BOTTLE, "LEVEL", 75);
        reg("nivel_100", "§6§l[Lv MAX]", "§6§l[MAX] ", "", "LEGENDARY", Material.EXPERIENCE_BOTTLE, "LEVEL", 100);

        // ═══════════════ RANKED TITLES ═══════════════
        reg("bronce", "§6[Bronce]", "§6[Bronce] ", "", "COMMON", Material.BRICK, "RANK", 800);
        reg("plata", "§7[Plata]", "§7[Plata] ", "", "RARE", Material.IRON_INGOT, "RANK", 1200);
        reg("oro", "§e[Oro]", "§e[Oro] ", "", "RARE", Material.GOLD_INGOT, "RANK", 1600);
        reg("diamante", "§b[Diamante]", "§b[Diamante] ", "", "EPIC", Material.DIAMOND, "RANK", 2000);
        reg("maestro", "§d§l[Maestro]", "§d§l[Maestro] ", "", "LEGENDARY", Material.AMETHYST_SHARD, "RANK", 2500);

        // ═══════════════ PLAYTIME TITLES ═══════════════
        reg("dedicado", "§a[Dedicado]", "§a[Dedicado] ", "", "COMMON", Material.CLOCK, "PLAYTIME", 10);
        reg("adicto", "§e[Adicto]", "§e[Adicto] ", "", "RARE", Material.CLOCK, "PLAYTIME", 50);
        reg("sin_vida", "§c§l[Sin Vida]", "§c§l[Sin Vida] ", "", "LEGENDARY", Material.CLOCK, "PLAYTIME", 200);

        // ═══════════════ SPECIAL TITLES ═══════════════
        reg("first_blood", "§c[First Blood]", "§c[FB] ", "", "RARE", Material.REDSTONE, "ACHIEVEMENT", 0);
        reg("racha_20", "§4[Racha 20]", "§4[R20] ", "", "EPIC", Material.FIRE_CHARGE, "ACHIEVEMENT", 0);

        plugin.getLogger().info("[TitleManager] " + titlesCache.size() + " títulos cargados");
    }

    private void reg(String id, String name, String prefix, String suffix, String rarity, Material icon, String unlockType, int unlockValue) {
        titlesCache.put(id, new TitleData(id, name, prefix, suffix, rarity, icon, unlockType, unlockValue));
    }

    // ══════════════════════════════════════════════════════════
    //                    TITLE MANAGEMENT
    // ══════════════════════════════════════════════════════════

    public void unlockTitle(UUID uuid, String titleId) {
        unlockedTitles.computeIfAbsent(uuid, k -> ConcurrentHashMap.newKeySet()).add(titleId);
        Player player = Bukkit.getPlayer(uuid);
        if (player != null && player.isOnline()) {
            TitleData title = titlesCache.get(titleId);
            if (title != null) {
                player.sendMessage("§a§l✓ §aTítulo desbloqueado: " + title.name);
                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.5f);
            }
        }
    }

    public boolean equipTitle(Player player, String titleId) {
        if (!titlesCache.containsKey(titleId)) return false;
        if (!isUnlocked(player.getUniqueId(), titleId)) return false;

        activeTitles.put(player.getUniqueId(), titleId);
        TitleData title = titlesCache.get(titleId);
        player.sendMessage("§a§l✓ §aTítulo equipado: " + title.name);
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 1.2f);
        updateNametag(player);
        return true;
    }

    public void unequipTitle(Player player) {
        activeTitles.remove(player.getUniqueId());
        player.sendMessage("§c§l✗ §cTítulo desactivado");
        updateNametag(player);
    }

    public boolean isUnlocked(UUID uuid, String titleId) {
        Set<String> titles = unlockedTitles.get(uuid);
        return titles != null && titles.contains(titleId);
    }

    public String getActiveTitle(UUID uuid) {
        return activeTitles.get(uuid);
    }

    public String getPrefix(UUID uuid) {
        String titleId = activeTitles.get(uuid);
        if (titleId == null) return "";
        TitleData title = titlesCache.get(titleId);
        return title != null ? title.prefix : "";
    }

    public String getSuffix(UUID uuid) {
        String titleId = activeTitles.get(uuid);
        if (titleId == null) return "";
        TitleData title = titlesCache.get(titleId);
        return title != null ? title.suffix : "";
    }

    // ══════════════════════════════════════════════════════════
    //              NAMETAG / CHAT INTEGRATION
    // ══════════════════════════════════════════════════════════

    public void updateNametag(Player player) {
        Scoreboard sb = Bukkit.getScoreboardManager().getMainScoreboard();
        String teamName = "title_" + player.getName();
        if (teamName.length() > 16) teamName = teamName.substring(0, 16);

        Team team = sb.getTeam(teamName);
        if (team == null) {
            team = sb.registerNewTeam(teamName);
        }

        String prefix = getPrefix(player.getUniqueId());
        String suffix = getSuffix(player.getUniqueId());

        team.setPrefix(prefix);
        team.setSuffix(suffix);

        if (!team.hasEntry(player.getName())) {
            team.addEntry(player.getName());
        }
    }

    /**
     * Get display name with title prefix for chat messages
     */
    public String getDisplayName(Player player) {
        String prefix = getPrefix(player.getUniqueId());
        return prefix + player.getName();
    }

    // ══════════════════════════════════════════════════════════
    //              AUTO-UNLOCK CHECK
    // ══════════════════════════════════════════════════════════

    public void checkUnlocks(Player player, int kills, int prestige, int level, int elo, long playtimeHours) {
        UUID uuid = player.getUniqueId();

        for (TitleData title : titlesCache.values()) {
            if (isUnlocked(uuid, title.id)) continue;

            boolean shouldUnlock = switch (title.unlockType.toUpperCase()) {
                case "KILLS" -> kills >= title.unlockValue;
                case "PRESTIGE" -> prestige >= title.unlockValue;
                case "LEVEL" -> level >= title.unlockValue;
                case "RANK" -> elo >= title.unlockValue;
                case "PLAYTIME" -> playtimeHours >= title.unlockValue;
                case "DEFAULT" -> true;
                default -> false;
            };

            if (shouldUnlock) {
                unlockTitle(uuid, title.id);
            }
        }
    }

    // ══════════════════════════════════════════════════════════
    //                    PAGINATED GUI
    // ══════════════════════════════════════════════════════════

    public void openTitlesGUI(Player player, int page) {
        UUID uuid = player.getUniqueId();

        List<TitleData> allTitles = new ArrayList<>(titlesCache.values());
        int totalPages = Math.max(1, (int) Math.ceil(allTitles.size() / 45.0));
        page = Math.max(1, Math.min(page, totalPages));

        int startIndex = (page - 1) * 45;
        int endIndex = Math.min(startIndex + 45, allTitles.size());

        Inventory inv = Bukkit.createInventory(null, 54, "§8» §6§lTítulos §7(Pág " + page + "/" + totalPages + ")");

        for (int i = startIndex; i < endIndex; i++) {
            TitleData title = allTitles.get(i);
            int slot = i - startIndex;

            boolean unlocked = isUnlocked(uuid, title.id);
            boolean equipped = title.id.equals(activeTitles.get(uuid));

            inv.setItem(slot, createTitleItem(title, unlocked, equipped));
        }

        // Navigation
        if (page > 1) {
            inv.setItem(45, createItem(Material.ARROW, "§a◀ Página Anterior"));
        }
        if (page < totalPages) {
            inv.setItem(53, createItem(Material.ARROW, "§aPágina Siguiente ▶"));
        }

        // Stats
        String activeTitleName = "§cNinguno";
        if (activeTitles.containsKey(uuid)) {
            TitleData activeTitle = titlesCache.get(activeTitles.get(uuid));
            if (activeTitle != null) activeTitleName = "§a" + activeTitle.name;
        }
        ItemStack stats = createItem(Material.BOOK, "§e§lEstadísticas");
        ItemMeta sm = stats.getItemMeta();
        sm.setLore(Arrays.asList(
                "§7Desbloqueados: §a" + unlockedTitles.getOrDefault(uuid, Collections.emptySet()).size() + "§7/§e" + titlesCache.size(),
                "§7Activo: " + activeTitleName,
                "", "§7Click en un título para equiparlo"
        ));
        stats.setItemMeta(sm);
        inv.setItem(49, stats);

        // Back button
        inv.setItem(48, createItem(Material.ARROW, "§c← Volver"));

        // Fill glass
        fillGlass(inv);
        player.openInventory(inv);
    }

    public void handleGUIClick(Player player, int slot, ItemStack item, String inventoryTitle) {
        if (item == null || item.getType() == Material.AIR) return;

        int currentPage = 1;
        if (inventoryTitle.contains("Pág")) {
            try {
                String pageStr = inventoryTitle.split("Pág ")[1].split("/")[0].trim();
                currentPage = Integer.parseInt(pageStr);
            } catch (Exception ignored) {}
        }

        if (slot == 45) { openTitlesGUI(player, currentPage - 1); return; }
        if (slot == 53 && item.getType() == Material.ARROW) { openTitlesGUI(player, currentPage + 1); return; }
        if (slot == 48) {
            new CosmeticsMainGui(plugin.getCore(), player, plugin).open();
            return;
        }
        if (slot == 49) return;

        if (slot < 45) {
            List<TitleData> allTitles = new ArrayList<>(titlesCache.values());
            int titleIndex = (currentPage - 1) * 45 + slot;
            if (titleIndex < allTitles.size()) {
                TitleData title = allTitles.get(titleIndex);
                UUID uuid = player.getUniqueId();

                if (!isUnlocked(uuid, title.id)) {
                    player.sendMessage("§c§l✗ §cNo has desbloqueado este título aún.");
                    player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 0.5f);
                    return;
                }

                if (title.id.equals(activeTitles.get(uuid))) {
                    unequipTitle(player);
                } else {
                    equipTitle(player, title.id);
                }
                openTitlesGUI(player, currentPage);
            }
        }
    }

    // ══════════════════════════════════════════════════════════
    //                    UTILITIES
    // ══════════════════════════════════════════════════════════

    private ItemStack createTitleItem(TitleData title, boolean unlocked, boolean equipped) {
        Material icon = unlocked ? title.icon : Material.GRAY_DYE;
        String displayName;

        if (equipped) displayName = "§a§l✓ " + title.name + " §7(Equipado)";
        else if (unlocked) displayName = "§f" + title.name;
        else displayName = "§7§m" + title.name.replaceAll("§.", "") + " §c(Bloqueado)";

        ItemStack item = new ItemStack(icon);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(displayName);

        List<String> lore = new ArrayList<>();
        lore.add("");
        if (unlocked) {
            lore.add("§7Prefix: " + title.prefix + "§7Nombre§r");
            if (!title.suffix.isEmpty()) lore.add("§7Suffix: §7Nombre" + title.suffix);
        } else {
            lore.add("§7Desbloqueo: §e" + title.unlockType);
            lore.add("§7Requisito: §e" + title.unlockValue);
        }
        lore.add("");
        lore.add("§7Rareza: " + getRarityColor(title.rarity) + title.rarity);
        lore.add("");
        if (unlocked) {
            lore.add(equipped ? "§c§lClick para quitar" : "§a§lClick para equipar");
        } else {
            lore.add("§c§lNo disponible aún");
        }

        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private String getRarityColor(String rarity) {
        return switch (rarity.toUpperCase()) {
            case "COMMON" -> "§f";
            case "RARE" -> "§9";
            case "EPIC" -> "§5";
            case "LEGENDARY" -> "§6";
            case "MYTHIC" -> "§c";
            default -> "§7";
        };
    }

    private ItemStack createItem(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) { meta.setDisplayName(name); item.setItemMeta(meta); }
        return item;
    }

    private void fillGlass(Inventory inv) {
        ItemStack glass = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta gm = glass.getItemMeta();
        gm.setDisplayName(" ");
        glass.setItemMeta(gm);
        for (int i = 45; i < 54; i++) {
            if (inv.getItem(i) == null) inv.setItem(i, glass);
        }
    }

    /**
     * Preview a title by showing the player what it looks like as a prefix.
     */
    public void previewTitle(Player player, String titleId) {
        TitleData title = titlesCache.get(titleId);
        if (title == null) {
            player.sendMessage("§cTítulo no encontrado: " + titleId);
            return;
        }
        player.sendMessage("§7Vista previa: " + title.prefix + player.getName() + title.suffix);
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 1.5f);
    }

    public void cleanupPlayer(UUID uuid) {
        unlockedTitles.remove(uuid);
        activeTitles.remove(uuid);
    }

    public Map<String, TitleData> getAllTitles() {
        return Collections.unmodifiableMap(titlesCache);
    }

    // ══════════════════════════════════════════════════════════

    public static class TitleData {
        public final String id;
        public final String name;
        public final String prefix;
        public final String suffix;
        public final String rarity;
        public final Material icon;
        public final String unlockType;
        public final int unlockValue;

        public TitleData(String id, String name, String prefix, String suffix, String rarity,
                         Material icon, String unlockType, int unlockValue) {
            this.id = id; this.name = name; this.prefix = prefix; this.suffix = suffix;
            this.rarity = rarity; this.icon = icon; this.unlockType = unlockType; this.unlockValue = unlockValue;
        }
    }
}
