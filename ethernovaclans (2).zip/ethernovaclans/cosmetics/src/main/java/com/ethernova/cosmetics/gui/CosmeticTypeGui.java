package com.ethernova.cosmetics.gui;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.cosmetics.effect.PetManager;
import com.ethernova.cosmetics.model.Cosmetic;
import com.ethernova.cosmetics.model.CosmeticType;
import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.PaginatedGui;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * GUI showing all cosmetics of a specific type.
 * Players can equip/unequip owned cosmetics or see locked ones.
 */
public class CosmeticTypeGui extends PaginatedGui {

    private final EthernovaCosmetics cosmetics;
    private final CosmeticType cosmeticType;

    public CosmeticTypeGui(EthernovaCore core, Player player, EthernovaCosmetics cosmetics, CosmeticType cosmeticType) {
        super(core, player);
        this.cosmetics = cosmetics;
        this.cosmeticType = cosmeticType;
    }

    /**
     * Open the cosmetic type browsing GUI.
     */
    public void open() {
        openPaginated("<gradient:#a855f7:#ec4899>✦ " + cosmeticType.getDisplayName() + "</gradient>", 0);
    }

    @Override
    protected void onPostRender() {
        addUnequipButton();
    }

    /**
     * Add an unequip button at slot 50 if the player has a cosmetic equipped for this type.
     */
    private void addUnequipButton() {
        UUID uuid = player.getUniqueId();
        String equippedId = cosmetics.getPlayerCosmeticManager().getEquipped(uuid, cosmeticType);
        if (equippedId != null) {
            Cosmetic equipped = cosmetics.getCosmeticRegistry().getById(equippedId);
            String equippedName = equipped != null ? equipped.name() : equippedId;
            setItem(50, createItem(Material.LEATHER_CHESTPLATE,
                    "<red>✘ Desequipar " + cosmeticType.getDisplayName(),
                    List.of("", "<gray>Equipado: <white>" + equippedName,
                            "", "<yellow>▶ Click para desequipar")));
            slotActions.put(50, "UNEQUIP_CURRENT");
        }
    }

    @Override
    protected String getTitle() {
        return "<gradient:#a855f7:#ec4899>✦ " + cosmeticType.getDisplayName() + "</gradient>";
    }

    @Override
    protected List<PageItem> getPageItems() {
        List<PageItem> items = new ArrayList<>();
        UUID uuid = player.getUniqueId();
        List<Cosmetic> typeCosmetics = cosmetics.getCosmeticRegistry().getByType(cosmeticType);
        String equippedId = cosmetics.getPlayerCosmeticManager().getEquipped(uuid, cosmeticType);

        // For PET type, add a head/floor toggle button at the top
        if (cosmeticType == CosmeticType.PET && cosmetics.getPetManager().hasPet(uuid)) {
            boolean onHead = cosmetics.getPetManager().isPetOnHead(uuid);
            String mode = onHead ? "<green>En cabeza" : "<green>En el suelo";
            String toggleTo = onHead ? "suelo" : "cabeza";
            items.add(new PageItem(
                    createItem(org.bukkit.Material.SADDLE,
                            "<yellow>✦ Modo Mascota: " + mode,
                            List.of("", "<gray>Modo actual: " + mode,
                                    "", "<yellow>▶ Click para cambiar al " + toggleTo)),
                    "PET_TOGGLE_HEAD"
            ));
        }

        // Count variants per base pet for display purposes
        java.util.Map<String, Integer> variantCounts = new java.util.HashMap<>();
        if (cosmeticType == CosmeticType.PET) {
            for (Cosmetic c : typeCosmetics) {
                if (PetManager.isVariant(c.id())) {
                    String base = PetManager.getBasePetId(c.id());
                    variantCounts.merge(base, 1, Integer::sum);
                }
            }
        }

        // Determine if this type has visual preview or text-only preview
        boolean hasVisualPreview = switch (cosmeticType) {
            case KILL_MESSAGE, DEATH_MESSAGE, JOIN_MESSAGE -> false;
            default -> true;
        };
        String previewText = hasVisualPreview
                ? "<aqua>▶ Click der. para previsualizar"
                : "<aqua>▶ Click der. para ver ejemplo";

        for (Cosmetic cosmetic : typeCosmetics) {
            // For PET type: skip variants — they are shown in the PetVariantGui submenu
            if (cosmeticType == CosmeticType.PET && PetManager.isVariant(cosmetic.id())) {
                continue;
            }

            boolean owned = cosmetics.getPlayerCosmeticManager().isUnlocked(uuid, cosmetic.id());
            // For pets, also check if any variant of this pet is equipped
            boolean isEquipped;
            if (cosmeticType == CosmeticType.PET && equippedId != null) {
                String equippedBase = PetManager.getBasePetId(equippedId);
                isEquipped = cosmetic.id().equalsIgnoreCase(equippedId)
                        || cosmetic.id().equalsIgnoreCase(equippedBase);
            } else {
                isEquipped = cosmetic.id().equalsIgnoreCase(equippedId);
            }

            List<String> lore = new ArrayList<>();
            lore.add("");
            String rarityLine = cosmetic.rarity().getFormattedName() + " <dark_gray>| " + cosmetic.rarity().getColor() + cosmetic.rarity().getDisplayName();
            if (cosmetic.vip()) rarityLine += " <dark_gray>| <gold>⭐ VIP";
            lore.add(rarityLine);
            lore.add("");
            lore.add("<gray>" + cosmetic.description());
            lore.add("");

            if (isEquipped) {
                // Show which variant is equipped for pets
                if (cosmeticType == CosmeticType.PET && equippedId != null && !equippedId.equalsIgnoreCase(cosmetic.id())) {
                    Cosmetic equippedCosmetic = cosmetics.getCosmeticRegistry().getById(equippedId);
                    String varName = equippedCosmetic != null ? equippedCosmetic.name() : PetManager.getVariantName(equippedId);
                    lore.add("<green>✔ Equipado <gray>(" + varName + ")");
                } else {
                    lore.add("<green>✔ Equipado");
                }
                lore.add("");
                // For pets with variants, show variant submenu hint
                int vc = variantCounts.getOrDefault(cosmetic.id(), 0);
                if (cosmeticType == CosmeticType.PET && vc > 0) {
                    lore.add("<light_purple>▶ Click izq. para ver " + (vc + 1) + " variantes");
                } else {
                    lore.add("<red>▶ Click izq. para desequipar");
                }
                lore.add(previewText);
            } else if (owned) {
                lore.add("<yellow>✔ Desbloqueado");
                lore.add("");
                int vc = variantCounts.getOrDefault(cosmetic.id(), 0);
                if (cosmeticType == CosmeticType.PET && vc > 0) {
                    lore.add("<light_purple>▶ Click izq. para ver " + (vc + 1) + " variantes");
                } else {
                    lore.add("<green>▶ Click izq. para equipar");
                }
                lore.add(previewText);
            } else {
                if (cosmetic.vip() && !player.hasPermission("ethernova.vip")) {
                    lore.add("<gold>⭐ Exclusivo VIP");
                    lore.add("<gray>Necesitas rango <gold>VIP");
                } else {
                    lore.add("<red>✘ Bloqueado");
                    lore.add("<gray>Precio: " + cosmetic.formattedPrice());
                    lore.add("");
                    lore.add("<gold>▶ Click izq. para comprar");
                }
                lore.add(previewText);
            }

            ItemStack item = createItem(cosmetic.icon(), cosmetic.coloredName(), lore);

            // Add enchant glow for equipped cosmetics
            if (isEquipped) {
                ItemMeta meta = item.getItemMeta();
                if (meta != null) {
                    meta.addEnchant(Enchantment.UNBREAKING, 1, true);
                    meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
                    item.setItemMeta(meta);
                }
            }

            items.add(new PageItem(item, "COSMETIC_" + cosmetic.id()));
        }

        return items;
    }

    @Override
    protected boolean onItemClick(String action, int slot, InventoryClickEvent event) {
        // Pet head/floor toggle
        if (action.equals("PET_TOGGLE_HEAD")) {
            cosmetics.getPetManager().toggleOnHead(player);
            core.getSoundManager().play(player, "click");
            open(); // Refresh to update toggle state
            return true;
        }

        // Unequip current cosmetic
        if (action.equals("UNEQUIP_CURRENT")) {
            UUID uuid = player.getUniqueId();
            String equippedId = cosmetics.getPlayerCosmeticManager().getEquipped(uuid, cosmeticType);
            if (equippedId != null) {
                cosmetics.getPlayerCosmeticManager().unequipById(uuid, equippedId);
                cosmetics.getTrailHandler().refreshTrail(uuid);
                // Remove pet if unequipping pet
                if (cosmeticType == CosmeticType.PET) {
                    cosmetics.getPetManager().removePet(uuid);
                }
                core.getSoundManager().play(player, "click");
                Cosmetic cosmetic = cosmetics.getCosmeticRegistry().getById(equippedId);
                String name = cosmetic != null ? cosmetic.name() : equippedId;
                player.sendMessage(MiniMessage.miniMessage().deserialize(
                        cosmetics.getConfigManager().getMessage("cosmetic-unequipped")
                                .replace("{cosmetic}", name)));
                open(); // Refresh
            }
            return true;
        }

        if (!action.startsWith("COSMETIC_")) return false;

        String cosmeticId = action.substring(9);
        UUID uuid = player.getUniqueId();
        Cosmetic cosmetic = cosmetics.getCosmeticRegistry().getById(cosmeticId);
        if (cosmetic == null) return true;

        // Right-click → preview
        if (event.isRightClick()) {
            // Death sound: play sound in-place without closing inventory
            if (cosmeticType == CosmeticType.DEATH_SOUND) {
                cosmetics.getDeathSoundHandler().preview(player, cosmetic.id());
                player.sendMessage(MiniMessage.miniMessage().deserialize(
                        "<gray>Sonido: <white>" + cosmetic.name()));
                return true;
            }
            // Title: show chat preview without closing
            if (cosmeticType == CosmeticType.TITLE) {
                cosmetics.getTitleManager().previewTitle(player, cosmetic.id());
                return true;
            }
            player.closeInventory();
            previewCosmetic(cosmetic);
            return true;
        }

        boolean owned = cosmetics.getPlayerCosmeticManager().isUnlocked(uuid, cosmeticId);
        String equippedId = cosmetics.getPlayerCosmeticManager().getEquipped(uuid, cosmeticType);
        boolean isEquipped = cosmeticId.equalsIgnoreCase(equippedId);

        // For PET type: if owned and has variants, open variant submenu instead
        if (cosmeticType == CosmeticType.PET && owned) {
            // Check if this pet has variants
            boolean hasVariants = cosmetics.getCosmeticRegistry().getByType(CosmeticType.PET).stream()
                    .anyMatch(c -> PetManager.isVariant(c.id()) && PetManager.getBasePetId(c.id()).equalsIgnoreCase(cosmeticId));
            if (hasVariants) {
                core.getSoundManager().play(player, "click");
                new PetVariantGui(core, player, cosmetics, cosmeticId).open();
                return true;
            }
            // No variants — equip/unequip directly
            if (isEquipped || (equippedId != null && PetManager.getBasePetId(equippedId).equalsIgnoreCase(cosmeticId))) {
                cosmetics.getPlayerCosmeticManager().unequipById(uuid, equippedId != null ? equippedId : cosmeticId);
                cosmetics.getPetManager().removePet(uuid);
                core.getSoundManager().play(player, "click");
                player.sendMessage(MiniMessage.miniMessage().deserialize("<red>✘ Mascota desequipada"));
                open();
            } else {
                cosmetics.getPlayerCosmeticManager().equip(uuid, cosmeticId);
                cosmetics.getPetManager().spawnPet(player);
                core.getSoundManager().play(player, "success");
                player.sendMessage(MiniMessage.miniMessage().deserialize(
                        cosmetics.getConfigManager().getMessage("cosmetic-equipped")
                                .replace("{cosmetic}", cosmetic.name())));
                open();
            }
            return true;
        }

        if (isEquipped) {
            // Unequip
            cosmetics.getPlayerCosmeticManager().unequipById(uuid, cosmeticId);
            cosmetics.getTrailHandler().refreshTrail(uuid);
            core.getSoundManager().play(player, "click");
            player.sendMessage(MiniMessage.miniMessage().deserialize(
                    cosmetics.getConfigManager().getMessage("cosmetic-unequipped")
                            .replace("{cosmetic}", cosmetic.name())));
            open(); // Refresh
        } else if (owned) {
            // Equip
            cosmetics.getPlayerCosmeticManager().equip(uuid, cosmeticId);
            cosmetics.getTrailHandler().refreshTrail(uuid);
            core.getSoundManager().play(player, "success");
            player.sendMessage(MiniMessage.miniMessage().deserialize(
                    cosmetics.getConfigManager().getMessage("cosmetic-equipped")
                            .replace("{cosmetic}", cosmetic.name())));
            open(); // Refresh
        } else {
            // Try to buy
            handlePurchase(cosmetic);
        }

        return true;
    }

    /**
     * Handle purchasing a cosmetic — checks coins and permissions.
     */
    private void handlePurchase(Cosmetic cosmetic) {
        UUID uuid = player.getUniqueId();

        // Check permission
        if (!cosmetic.permission().isEmpty() && !player.hasPermission(cosmetic.permission())) {
            core.getSoundManager().play(player, "error");
            player.sendMessage(MiniMessage.miniMessage().deserialize(
                    cosmetics.getConfigManager().getMessage("cosmetic-no-permission")));
            return;
        }

        // Check VIP requirement
        if (cosmetic.vip() && !player.hasPermission("ethernova.vip")) {
            core.getSoundManager().play(player, "error");
            player.sendMessage(MiniMessage.miniMessage().deserialize(
                    "<red>✘ Este cosmético es <gold>⭐ Exclusivo VIP<red>. Necesitas rango VIP."));
            return;
        }

        // Check coins
        var profile = core.getProfileManager().getProfile(uuid);
        if (profile == null) {
            core.getSoundManager().play(player, "error");
            return;
        }

        if (profile.getCoins() < cosmetic.price()) {
            core.getSoundManager().play(player, "error");
            player.sendMessage(MiniMessage.miniMessage().deserialize(
                    cosmetics.getConfigManager().getMessage("cosmetic-not-enough-coins")
                            .replace("{price}", String.format("%.0f", cosmetic.price()))));
            return;
        }

        // Deduct coins and unlock
        profile.addCoins(-cosmetic.price());
        cosmetics.getPlayerCosmeticManager().unlock(uuid, cosmetic.id());
        core.getSoundManager().play(player, "reward");
        player.sendMessage(MiniMessage.miniMessage().deserialize(
                cosmetics.getConfigManager().getMessage("cosmetic-bought")
                        .replace("{cosmetic}", cosmetic.name())
                        .replace("{price}", String.format("%.0f", cosmetic.price()))));
        open(); // Refresh
    }

    @Override
    protected void onBack() {
        new CosmeticsMainGui(core, player, cosmetics).open();
    }

    /**
     * Preview a cosmetic effect for the player.
     */
    private void previewCosmetic(Cosmetic cosmetic) {
        player.sendMessage(MiniMessage.miniMessage().deserialize(
                cosmetics.getConfigManager().getMessage("preview-start")
                        .replace("{cosmetic}", cosmetic.name())));
        core.getSoundManager().play(player, "click");

        // Determine preview duration (ticks) for return-to-menu timing
        int previewTicks = 80; // 4 seconds default

        switch (cosmetic.type()) {
            case KILL_EFFECT -> cosmetics.getKillEffectHandler().preview(player, cosmetic.id());
            case TRAIL -> cosmetics.getTrailHandler().preview(player, cosmetic.id());
            case PROJECTILE_TRAIL -> cosmetics.getProjectileTrailHandler().preview(player, cosmetic.id());
            case WIN_EFFECT -> cosmetics.getWinEffectHandler().preview(player, cosmetic.id());
            case DEATH_EFFECT -> cosmetics.getCosmeticListener().playDeathEffect(cosmetic.id(), player.getLocation());
            case HIT_EFFECT -> cosmetics.getHitEffectsManager().preview(player, cosmetic.id());
            case FINISHER -> cosmetics.getFinisherHandler().previewFinisher(player, cosmetic.id());
            case PET -> cosmetics.getPetManager().preview(player, cosmetic.id());
            case ELYTRA_TRAIL -> cosmetics.getElytraTrailHandler().preview(player, cosmetic.id());
            case DEATH_SOUND -> { cosmetics.getDeathSoundHandler().preview(player, cosmetic.id()); previewTicks = 20; }
            case TITLE -> { cosmetics.getTitleManager().previewTitle(player, cosmetic.id()); previewTicks = 40; }
            case WEAPON_SKIN, ARMOR_SKIN -> { previewTicks = 20; }
            case KILL_MESSAGE -> {
                previewTicks = 80;
                String sample = switch (cosmetic.id().toLowerCase()) {
                    case "msg_brutal" -> "<red><bold>" + player.getName() + "</bold></red> <dark_red>☠ DESTRUYÓ ☠</dark_red> <red>a un enemigo";
                    case "msg_elegant" -> "<gradient:#ffd700:#ff69b4>" + player.getName() + "</gradient> <white>eliminó elegantemente a un rival</white>";
                    case "msg_mythic" -> "<gradient:#ff0000:#ff7700:#ffff00:#00ff00:#0000ff:#8b00ff>" + player.getName() + "</gradient> <light_purple>⚡ ANIQUILÓ ⚡</light_purple> <gray>a un oponente";
                    case "msg_samurai" -> "<gradient:#ff4444:#ff8800>" + player.getName() + "</gradient> <red>⚔ cortó en dos ⚔</red> <gray>a un rival";
                    case "msg_glitch" -> "<obfuscated>xx</obfuscated><red>" + player.getName() + "</red><obfuscated>xx</obfuscated> <dark_red>█▓░ ELIMINÓ ░▓█</dark_red> <gray>a un oponente";
                    default -> "<gray>" + player.getName() + " eliminó a un jugador";
                };
                player.sendMessage(MiniMessage.miniMessage().deserialize("<gray>Ejemplo: " + sample));
            }
            case DEATH_MESSAGE -> {
                previewTicks = 80;
                String sample = switch (cosmetic.id().toLowerCase()) {
                    case "death_default" -> "<gray>" + player.getName() + " murió a manos de un enemigo.";
                    case "death_knight" -> "<gray>" + player.getName() + " cayó con honor ante un enemigo.";
                    case "death_pirate" -> "<gray>" + player.getName() + " caminó por la plancha de un enemigo.";
                    case "death_toxic" -> "<gray>" + player.getName() + " fue humillado (EZ) por un enemigo.";
                    case "death_windows" -> "<gray>" + player.getName() + ".exe dejó de funcionar.";
                    case "death_math" -> "<gray>" + player.getName() + " fue restado de la ecuación.";
                    case "death_error404" -> "<red>Error 404: <gray>Skill de " + player.getName() + " no encontrada.";
                    case "death_meme" -> "<gray>" + player.getName() + " olvidó activar el killaura.";
                    case "death_anime" -> "<red>Omae wa mou shindeiru. <gray>" + player.getName() + " fue aniquilado.";
                    case "death_discord" -> "<gray>" + player.getName() + " fue baneado del servidor de la vida.";
                    default -> "<gray>" + player.getName() + " murió en combate.";
                };
                player.sendMessage(MiniMessage.miniMessage().deserialize("<gray>Ejemplo: " + sample));
            }
            case JOIN_MESSAGE -> {
                previewTicks = 80;
                String sample = switch (cosmetic.id().toLowerCase()) {
                    case "join_default" -> "<gray>[<green>+</green>] <white>" + player.getName() + " ha entrado.";
                    case "join_pizza" -> "<green>Ding dong... <white>¡Llegó " + player.getName() + " con la pizza!";
                    case "join_mom" -> "<light_purple>❤ <white>¡La mamá de " + player.getName() + " lo dejó en la guardería!";
                    case "join_fbi" -> "<red><bold>FBI!</bold> <white>" + player.getName() + " ha tirado la puerta abajo.";
                    case "join_dad" -> "<dark_gray>" + player.getName() + " ha vuelto (al fin).";
                    case "join_party" -> "<light_purple>\uD83C\uDF89 <white>¡Llegó " + player.getName() + ", que empiece la fiesta!";
                    case "join_streamer" -> "<light_purple>\uD83C\uDFA5 <white>" + player.getName() + " está en directo. ¡Saluden!";
                    case "join_wild" -> "<green>¡Un " + player.getName() + " salvaje apareció!";
                    case "join_god" -> "<gold>⚡ <yellow>¡EL DIOS " + player.getName() + " HA LLEGADO! <gold>⚡";
                    default -> "<gray>" + player.getName() + " se ha unido al servidor.";
                };
                player.sendMessage(MiniMessage.miniMessage().deserialize("<gray>Ejemplo: " + sample));
            }
        }

        // Schedule return to the cosmetic menu after preview ends
        final CosmeticType returnType = this.cosmeticType;
        Bukkit.getScheduler().runTaskLater(core, () -> {
            if (player.isOnline()) {
                new CosmeticTypeGui(core, player, cosmetics, returnType).open();
            }
        }, previewTicks + 10); // +0.5 second buffer
    }
}
