package com.ethernova.cosmetics.effect;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.cosmetics.model.Cosmetic;
import com.ethernova.cosmetics.model.CosmeticType;
import org.bukkit.*;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.meta.FireworkMeta;

import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Handles win effects — special effects triggered when a player wins a match.
 * Effects include firework shows, lightning storms, and dragon breath particles.
 */
public class WinEffectHandler {

    private final EthernovaCosmetics plugin;

    public WinEffectHandler(EthernovaCosmetics plugin) {
        this.plugin = plugin;
    }

    /**
     * Trigger the win effect for a player.
     * @param uuid The winning player's UUID
     */
    public void triggerWinEffect(UUID uuid) {
        if (uuid == null) return;
        Player player = Bukkit.getPlayer(uuid);
        if (player == null || !player.isOnline()) return;

        String cosmeticId = plugin.getPlayerCosmeticManager().getEquipped(uuid, CosmeticType.WIN_EFFECT);
        if (cosmeticId == null) return;

        Cosmetic cosmetic = plugin.getCosmeticRegistry().getById(cosmeticId);
        if (cosmetic == null) return;

        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!player.isOnline()) return;
            playEffect(cosmeticId, player);
        });
    }

    /**
     * Play the specific win effect for a player.
     */
    private void playEffect(String effectId, Player player) {
        Location loc = player.getLocation();
        if (loc.getWorld() == null) return;

        switch (effectId.toLowerCase()) {
            case "fireworks_show" -> playFireworksShow(player, loc);
            case "lightning_storm" -> playLightningStorm(player, loc);
            case "dragon_breath" -> playDragonBreath(player, loc);
            case "blood_rain" -> playBloodRain(player, loc);
            default -> {
                // Unknown effect
            }
        }
    }

    /**
     * Fireworks Show: Spawn multiple fireworks around the player over time.
     */
    private void playFireworksShow(Player player, Location center) {
        int count = plugin.getConfigManager().getInt("win-effect.firework-count", 8);
        int durationTicks = plugin.getConfigManager().getInt("win-effect.duration-ticks", 60);
        int interval = Math.max(1, durationTicks / count);

        for (int i = 0; i < count; i++) {
            final int index = i;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!player.isOnline() || center.getWorld() == null) return;

                double angle = (Math.PI * 2 * index) / count;
                double radius = 2.0 + ThreadLocalRandom.current().nextDouble(2.0);
                double x = Math.cos(angle) * radius;
                double z = Math.sin(angle) * radius;
                Location spawnLoc = center.clone().add(x, 0.5, z);

                Firework firework = (Firework) center.getWorld().spawnEntity(spawnLoc, EntityType.FIREWORK_ROCKET);
                FireworkMeta meta = firework.getFireworkMeta();

                Color[] colors = {Color.RED, Color.BLUE, Color.GREEN, Color.YELLOW, Color.PURPLE, Color.AQUA, Color.ORANGE, Color.FUCHSIA};
                Color primary = colors[ThreadLocalRandom.current().nextInt(colors.length)];
                Color fade = colors[ThreadLocalRandom.current().nextInt(colors.length)];

                FireworkEffect.Type[] types = FireworkEffect.Type.values();
                FireworkEffect.Type type = types[ThreadLocalRandom.current().nextInt(types.length)];

                FireworkEffect effect = FireworkEffect.builder()
                        .with(type)
                        .withColor(primary)
                        .withFade(fade)
                        .flicker(ThreadLocalRandom.current().nextBoolean())
                        .trail(ThreadLocalRandom.current().nextBoolean())
                        .build();

                meta.addEffect(effect);
                meta.setPower(1);
                firework.setFireworkMeta(meta);
            }, (long) i * interval);
        }
    }

    /**
     * Lightning Storm: Multiple lightning bolts around the player.
     */
    private void playLightningStorm(Player player, Location center) {
        int count = plugin.getConfigManager().getInt("win-effect.lightning-count", 5);
        int durationTicks = plugin.getConfigManager().getInt("win-effect.duration-ticks", 60);
        int interval = Math.max(1, durationTicks / count);

        for (int i = 0; i < count; i++) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!player.isOnline() || center.getWorld() == null) return;

                double x = (ThreadLocalRandom.current().nextDouble() - 0.5) * 8.0;
                double z = (ThreadLocalRandom.current().nextDouble() - 0.5) * 8.0;
                Location strikeLoc = center.clone().add(x, 0, z);

                // Visual-only lightning (no fire, no damage)
                center.getWorld().strikeLightningEffect(strikeLoc);

                // Additional electric particles
                center.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, strikeLoc.clone().add(0, 1, 0),
                        20, 0.5, 1.0, 0.5, 0.1);
            }, (long) i * interval);
        }

        // Final big flash
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline() || center.getWorld() == null) return;
            center.getWorld().spawnParticle(Particle.FLASH, center.clone().add(0, 2, 0), 3, 0.5, 0.5, 0.5, 0);
            center.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, center.clone().add(0, 1, 0), 50, 2, 2, 2, 0.1);
        }, durationTicks + 5L);
    }

    /**
     * Dragon Breath: Area of dragon breath particles swirling around the player.
     */
    private void playDragonBreath(Player player, Location center) {
        int durationTicks = plugin.getConfigManager().getInt("win-effect.duration-ticks", 60);

        for (int tick = 0; tick < durationTicks; tick += 4) {
            final int t = tick;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!player.isOnline() || center.getWorld() == null) return;

                double progress = (double) t / durationTicks;
                double radius = 1.0 + progress * 3.0;
                int points = 8;

                for (int i = 0; i < points; i++) {
                    double angle = (Math.PI * 2 * i) / points + (t * 0.1);
                    double x = Math.cos(angle) * radius;
                    double z = Math.sin(angle) * radius;
                    Location particleLoc = center.clone().add(x, 0.3 + progress * 2.0, z);

                    center.getWorld().spawnParticle(Particle.DRAGON_BREATH, particleLoc,
                            3, 0.05, 0.1, 0.05, 0.01);
                }

                // Central column of dragon breath
                center.getWorld().spawnParticle(Particle.DRAGON_BREATH, center.clone().add(0, 0.5 + progress * 3, 0),
                        10, 0.3, 0.5, 0.3, 0.02);
            }, tick);
        }
    }

    /**
     * Blood Rain: Crimson drops fall from above around the player.
     */
    private void playBloodRain(Player player, Location center) {
        int durationTicks = plugin.getConfigManager().getInt("win-effect.duration-ticks", 60);

        for (int tick = 0; tick < durationTicks; tick += 3) {
            final int t = tick;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!player.isOnline() || center.getWorld() == null) return;

                Particle.DustOptions bloodDust = new Particle.DustOptions(Color.RED, 1.2f);
                Particle.DustOptions darkBloodDust = new Particle.DustOptions(Color.fromRGB(139, 0, 0), 1.5f);

                // Rain drops from above in a 5-block radius
                for (int i = 0; i < 6; i++) {
                    double x = (ThreadLocalRandom.current().nextDouble() - 0.5) * 10.0;
                    double z = (ThreadLocalRandom.current().nextDouble() - 0.5) * 10.0;
                    double height = 4.0 + ThreadLocalRandom.current().nextDouble(2.0);
                    Location dropLoc = center.clone().add(x, height, z);
                    center.getWorld().spawnParticle(Particle.DUST, dropLoc, 3, 0.05, 0.5, 0.05, 0, bloodDust);
                    center.getWorld().spawnParticle(Particle.DUST, dropLoc.clone().add(0, -1, 0), 2, 0.05, 0.3, 0.05, 0, darkBloodDust);
                }

                // Splashes on the ground
                if (t % 6 == 0) {
                    for (int i = 0; i < 4; i++) {
                        double x = (ThreadLocalRandom.current().nextDouble() - 0.5) * 8.0;
                        double z = (ThreadLocalRandom.current().nextDouble() - 0.5) * 8.0;
                        center.getWorld().spawnParticle(Particle.DUST, center.clone().add(x, 0.1, z), 5, 0.2, 0.05, 0.2, 0, bloodDust);
                    }
                }
            }, tick);
        }
    }

    /**
     * Preview a win effect for a player.
     */
    public void preview(Player player, String effectId) {
        if (player == null || effectId == null) return;
        playEffect(effectId, player);
    }
}
