package com.ethernova.cosmetics.aura;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Player;

/**
 * Motor de renderizado de patrones de partículas para auras.
 * Zero-Drift Engine: count=1, offset=0 para posicionamiento exacto.
 *
 * Patrones: falling, helix, tornado, shield, dna, vortex, circle,
 *           wings, pulse, orbit, radar, layers, rainbow
 */
public class AuraPatternRenderer {

    private Player renderTarget;
    private int lod = 2;
    private Color auraColor = Color.WHITE;
    private float dustSize = 1.0f;

    public void setContext(Player target, int lod, Color color, float dustSize) {
        this.renderTarget = target;
        this.lod = lod;
        this.auraColor = color != null ? color : Color.WHITE;
        this.dustSize = dustSize;
    }

    public void render(String patternId, Location loc, Particle particle, int tick, AuraConfig config) {
        switch (patternId.toLowerCase()) {
            case "falling"  -> renderFalling(loc, particle, config);
            case "helix"    -> renderHelix(loc, particle, tick, config);
            case "tornado"  -> renderTornado(loc, particle, tick, config);
            case "shield"   -> renderShield(loc, particle, tick, config);
            case "dna"      -> renderDNA(loc, particle, tick, config);
            case "vortex"   -> renderVortex(loc, particle, tick, config);
            case "circle"   -> renderCircle(loc, particle, tick, config);
            case "wings"    -> renderWings(loc, particle, tick, config);
            case "pulse"    -> renderPulse(loc, particle, tick, config);
            case "orbit"    -> renderOrbit(loc, particle, tick, config);
            case "radar"    -> renderRadar(loc, particle, tick, config);
            case "rainbow"  -> renderRainbow(loc, tick, config);
            default         -> renderFalling(loc, particle, config);
        }
    }

    public void renderLayersEffect(Location loc, Particle particle, int tick) {
        if (lod == 0) return;
        if (tick % 3 == 0 && lod >= 2) {
            double coreRadius = 0.25;
            double coreAngle = tick * 0.2;
            for (int i = 0; i < 4; i++) {
                double a = coreAngle + (Math.PI / 2) * i;
                double x = Math.cos(a) * coreRadius;
                double z = Math.sin(a) * coreRadius;
                spawnParticle(loc.getWorld(), particle, loc.clone().add(x, -0.2, z), 1, 0, 0, 0, 0);
            }
        }
    }

    // ═══ PATRONES ═══

    private void renderFalling(Location loc, Particle particle, AuraConfig config) {
        int count = Math.max(2, (int) (4 * config.intensity()));
        for (int i = 0; i < count; i++) {
            double angle = (i * 2.399) % (2 * Math.PI);
            double r = (0.3 + (i % 3) * 0.25) * config.radius();
            double x = Math.cos(angle) * r;
            double z = Math.sin(angle) * r;
            double phase = (System.currentTimeMillis() / 50.0 + i * 7.3) % 40.0;
            double y = 1.5 - (phase / 40.0) * 2.5;
            spawnParticle(loc.getWorld(), particle, loc.clone().add(x, y, z), 1, 0, 0, 0, 0);
        }
    }

    private void renderHelix(Location loc, Particle particle, int tick, AuraConfig config) {
        double radius = 0.6 * config.radius();
        int points = Math.max(4, (int) (8 * config.intensity()));
        double rotSpeed = tick * 0.15;
        for (int i = 0; i < points; i++) {
            double t = (double) i / points;
            double height = t * 2.2 - 1.1;
            double a = rotSpeed + t * Math.PI * 3;
            spawnParticle(loc.getWorld(), particle, loc.clone().add(Math.cos(a) * radius, height, Math.sin(a) * radius), 1, 0, 0, 0, 0);
            spawnParticle(loc.getWorld(), particle, loc.clone().add(Math.cos(a + Math.PI) * radius, height, Math.sin(a + Math.PI) * radius), 1, 0, 0, 0, 0);
        }
    }

    private void renderTornado(Location loc, Particle particle, int tick, AuraConfig config) {
        int pointsPerLevel = Math.max(2, (int) (3 * config.intensity()));
        int levels = 5;
        double rotSpeed = tick * 0.12;
        for (int lvl = 0; lvl < levels; lvl++) {
            double t = (double) lvl / (levels - 1);
            double y = t * 2.0 - 0.8;
            double radius = (0.2 + t * 0.8) * config.radius();
            double levelRot = rotSpeed * (1.0 + t * 0.8);
            for (int p = 0; p < pointsPerLevel; p++) {
                double a = levelRot + (2 * Math.PI * p / pointsPerLevel);
                spawnParticle(loc.getWorld(), particle, loc.clone().add(Math.cos(a) * radius, y, Math.sin(a) * radius), 1, 0, 0, 0, 0);
            }
        }
    }

    private void renderShield(Location loc, Particle particle, int tick, AuraConfig config) {
        int points = Math.max(8, (int) (16 * config.intensity()));
        double radius = 0.9 * config.radius();
        double rotAngle = tick * 0.06;
        for (int i = 0; i < points; i++) {
            double phi = Math.acos(1 - 2.0 * (i + 0.5) / points);
            double theta = Math.PI * (1 + Math.sqrt(5)) * i + rotAngle;
            double x = radius * Math.sin(phi) * Math.cos(theta);
            double y = radius * Math.cos(phi) * 0.7;
            double z = radius * Math.sin(phi) * Math.sin(theta);
            spawnParticle(loc.getWorld(), particle, loc.clone().add(x, y, z), 1, 0, 0, 0, 0);
        }
    }

    private void renderDNA(Location loc, Particle particle, int tick, AuraConfig config) {
        double radius = 0.5 * config.radius();
        int points = Math.max(6, (int) (10 * config.intensity()));
        double rotSpeed = tick * 0.1;
        for (int i = 0; i < points; i++) {
            double t = (double) i / points;
            double height = t * 2.6 - 1.3;
            double a = rotSpeed + t * Math.PI * 4;
            double x1 = Math.cos(a) * radius, z1 = Math.sin(a) * radius;
            double x2 = Math.cos(a + Math.PI) * radius, z2 = Math.sin(a + Math.PI) * radius;
            spawnParticle(loc.getWorld(), particle, loc.clone().add(x1, height, z1), 1, 0, 0, 0, 0);
            spawnParticle(loc.getWorld(), particle, loc.clone().add(x2, height, z2), 1, 0, 0, 0, 0);
            if (i % 3 == 0) {
                for (int c = 1; c <= 2; c++) {
                    double blend = c / 3.0;
                    spawnParticle(loc.getWorld(), particle, loc.clone().add(x1 + (x2 - x1) * blend, height, z1 + (z2 - z1) * blend), 1, 0, 0, 0, 0);
                }
            }
        }
    }

    private void renderVortex(Location loc, Particle particle, int tick, AuraConfig config) {
        int arms = 3, pointsPerArm = Math.max(3, (int) (5 * config.intensity()));
        double maxRadius = 1.0 * config.radius(), rotSpeed = tick * 0.15;
        for (int arm = 0; arm < arms; arm++) {
            double armOffset = (2 * Math.PI / arms) * arm;
            for (int i = 0; i < pointsPerArm; i++) {
                double t = (double) i / pointsPerArm;
                double r = maxRadius * (1.0 - t * 0.8);
                double y = t * 1.5 - 0.5;
                double a = rotSpeed + armOffset + t * Math.PI * 2;
                spawnParticle(loc.getWorld(), particle, loc.clone().add(Math.cos(a) * r, y, Math.sin(a) * r), 1, 0, 0, 0, 0);
            }
        }
    }

    private void renderCircle(Location loc, Particle particle, int tick, AuraConfig config) {
        int points = Math.max(8, (int) (16 * config.intensity()));
        double radius = 0.8 * config.radius(), rotAngle = tick * 0.08;
        double yOsc = Math.sin(tick * 0.05) * 0.3;
        for (int i = 0; i < points; i++) {
            double a = (2 * Math.PI * i / points) + rotAngle;
            spawnParticle(loc.getWorld(), particle, loc.clone().add(Math.cos(a) * radius, yOsc, Math.sin(a) * radius), 1, 0, 0, 0, 0);
        }
    }

    private void renderWings(Location loc, Particle particle, int tick, AuraConfig config) {
        double flapAngle = Math.sin(tick * 0.08) * 0.3;
        double yaw = Math.toRadians(loc.getYaw());
        double cosYaw = Math.cos(yaw), sinYaw = Math.sin(yaw);
        int pointsPerWing = Math.max(5, (int) (8 * config.intensity()));
        for (int i = 0; i < pointsPerWing; i++) {
            double t = (double) i / (pointsPerWing - 1);
            double wingX = 0.3 + t * 1.2, wingY = -0.3 + Math.sin(t * Math.PI) * 0.9 + flapAngle * t, wingZ = -0.3 - t * 0.15;
            spawnParticle(loc.getWorld(), particle, loc.clone().add(-wingX * cosYaw - wingZ * sinYaw, wingY, -wingX * sinYaw + wingZ * cosYaw), 1, 0, 0, 0, 0);
            spawnParticle(loc.getWorld(), particle, loc.clone().add(wingX * cosYaw - wingZ * sinYaw, wingY, wingX * sinYaw + wingZ * cosYaw), 1, 0, 0, 0, 0);
        }
    }

    private void renderPulse(Location loc, Particle particle, int tick, AuraConfig config) {
        double maxRadius = 1.5 * config.radius(), progress = (tick % 25) / 25.0;
        double radius = progress * maxRadius;
        int points = Math.max(4, (int) ((1.0 - progress * 0.6) * 12 * config.intensity()));
        for (int i = 0; i < points; i++) {
            double a = (2 * Math.PI * i / points) + tick * 0.03;
            spawnParticle(loc.getWorld(), particle, loc.clone().add(Math.cos(a) * radius, -0.3, Math.sin(a) * radius), 1, 0, 0, 0, 0);
        }
    }

    private void renderOrbit(Location loc, Particle particle, int tick, AuraConfig config) {
        double radius = 0.9 * config.radius(), speed = tick * 0.1;
        spawnParticle(loc.getWorld(), particle, loc.clone().add(Math.cos(speed) * radius, 0, Math.sin(speed) * radius), 1, 0, 0, 0, 0);
        double a2 = speed + Math.PI * 2 / 3;
        spawnParticle(loc.getWorld(), particle, loc.clone().add(Math.cos(a2) * radius, Math.sin(a2) * radius * 0.5, Math.sin(a2) * radius * 0.866), 1, 0, 0, 0, 0);
        double a3 = speed + Math.PI * 4 / 3;
        spawnParticle(loc.getWorld(), particle, loc.clone().add(Math.cos(a3) * radius * 0.866, Math.sin(a3) * radius * 0.5, Math.sin(a3) * radius), 1, 0, 0, 0, 0);
    }

    private void renderRadar(Location loc, Particle particle, int tick, AuraConfig config) {
        double angle = tick * 0.08, radius = 1.0 * config.radius();
        int linePoints = Math.max(4, (int) (6 * config.intensity()));
        for (int i = 1; i <= linePoints; i++) {
            double r = radius * i / linePoints;
            spawnParticle(loc.getWorld(), particle, loc.clone().add(Math.cos(angle) * r, -0.5, Math.sin(angle) * r), 1, 0, 0, 0, 0);
        }
        if (tick % 3 == 0) {
            int ringPoints = Math.max(8, (int) (14 * config.intensity()));
            for (int i = 0; i < ringPoints; i++) {
                double a = 2 * Math.PI * i / ringPoints;
                spawnParticle(loc.getWorld(), particle, loc.clone().add(Math.cos(a) * radius, -0.5, Math.sin(a) * radius), 1, 0, 0, 0, 0);
            }
        }
    }

    private void renderRainbow(Location loc, int tick, AuraConfig config) {
        double radius = 0.65 * config.radius();
        int points = Math.max(4, (int) (8 * config.intensity()));
        if (lod == 0) points = Math.max(2, points / 3);
        else if (lod == 1) points = Math.max(3, points / 2);
        double rotSpeed = tick * 0.12;
        for (int i = 0; i < points; i++) {
            double t = (double) i / points;
            double height = t * 2.2 - 1.1;
            double a = rotSpeed + t * Math.PI * 3;
            float hue = ((tick * 3 + i * (360 / points)) % 360) / 360.0f;
            int rgb = hsbToRgb(hue, 1.0f, 1.0f);
            Particle.DustOptions dust = new Particle.DustOptions(Color.fromRGB((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF), 1.2f);
            float hue2 = ((tick * 3 + i * (360 / points) + 180) % 360) / 360.0f;
            int rgb2 = hsbToRgb(hue2, 1.0f, 1.0f);
            Particle.DustOptions dust2 = new Particle.DustOptions(Color.fromRGB((rgb2 >> 16) & 0xFF, (rgb2 >> 8) & 0xFF, rgb2 & 0xFF), 1.2f);
            double x1 = Math.cos(a) * radius, z1 = Math.sin(a) * radius;
            double x2 = Math.cos(a + Math.PI) * radius, z2 = Math.sin(a + Math.PI) * radius;
            if (renderTarget != null) {
                renderTarget.spawnParticle(Particle.DUST, loc.clone().add(x1, height, z1), 1, 0, 0, 0, 0, dust);
                renderTarget.spawnParticle(Particle.DUST, loc.clone().add(x2, height, z2), 1, 0, 0, 0, 0, dust2);
            } else {
                loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(x1, height, z1), 1, 0, 0, 0, 0, dust);
                loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(x2, height, z2), 1, 0, 0, 0, 0, dust2);
            }
        }
    }

    // ═══ PARTICLE SPAWN (Zero-Drift + LOD + Per-Player) ═══

    public void spawnParticle(World world, Particle particle, Location loc, int count,
                              double offX, double offY, double offZ, double extra) {
        try {
            int adj = count;
            if (lod == 0) adj = Math.max(1, count / 3);
            else if (lod == 1) adj = Math.max(1, count / 2);

            if (renderTarget != null) {
                if (particle == Particle.DUST) {
                    renderTarget.spawnParticle(particle, loc, adj, offX, offY, offZ, extra, new Particle.DustOptions(auraColor, dustSize));
                } else {
                    renderTarget.spawnParticle(particle, loc, adj, offX, offY, offZ, extra);
                }
            } else {
                if (particle == Particle.DUST) {
                    world.spawnParticle(particle, loc, adj, offX, offY, offZ, extra, new Particle.DustOptions(auraColor, dustSize));
                } else {
                    world.spawnParticle(particle, loc, adj, offX, offY, offZ, extra);
                }
            }
        } catch (IllegalArgumentException e) {
            if (renderTarget != null) {
                renderTarget.spawnParticle(Particle.CRIT, loc, count, offX, offY, offZ, extra);
            } else {
                world.spawnParticle(Particle.CRIT, loc, count, offX, offY, offZ, extra);
            }
        }
    }

    /** Manual HSB→RGB to avoid java.awt on headless servers. */
    private static int hsbToRgb(float hue, float saturation, float brightness) {
        float h = (hue - (float) Math.floor(hue)) * 6.0f;
        float f = h - (float) Math.floor(h);
        float p = brightness * (1.0f - saturation);
        float q = brightness * (1.0f - saturation * f);
        float t = brightness * (1.0f - (saturation * (1.0f - f)));
        int r, g, b;
        switch ((int) h) {
            case 0 -> { r = (int)(brightness*255+0.5f); g = (int)(t*255+0.5f); b = (int)(p*255+0.5f); }
            case 1 -> { r = (int)(q*255+0.5f); g = (int)(brightness*255+0.5f); b = (int)(p*255+0.5f); }
            case 2 -> { r = (int)(p*255+0.5f); g = (int)(brightness*255+0.5f); b = (int)(t*255+0.5f); }
            case 3 -> { r = (int)(p*255+0.5f); g = (int)(q*255+0.5f); b = (int)(brightness*255+0.5f); }
            case 4 -> { r = (int)(t*255+0.5f); g = (int)(p*255+0.5f); b = (int)(brightness*255+0.5f); }
            default -> { r = (int)(brightness*255+0.5f); g = (int)(p*255+0.5f); b = (int)(q*255+0.5f); }
        }
        return (r << 16) | (g << 8) | b;
    }
}
