package com.ethernova.cosmetics.model;

import org.bukkit.Material;

/**
 * Types of cosmetics available in the system.
 */
public enum CosmeticType {

    KILL_EFFECT("Efecto de Muerte", Material.DIAMOND_SWORD),
    DEATH_EFFECT("Efecto al Morir", Material.SKELETON_SKULL),
    TRAIL("Estela", Material.BLAZE_POWDER),
    PROJECTILE_TRAIL("Estela de Proyectil", Material.SPECTRAL_ARROW),
    KILL_MESSAGE("Mensaje de Kill", Material.WRITABLE_BOOK),
    WIN_EFFECT("Efecto de Victoria", Material.FIREWORK_ROCKET),
    TITLE("Título", Material.NAME_TAG),
    FINISHER("Finisher", Material.IRON_AXE),
    PET("Mascota", Material.WOLF_SPAWN_EGG),
    WEAPON_SKIN("Skin de Arma", Material.NETHERITE_SWORD),
    ARMOR_SKIN("Skin de Armadura", Material.DIAMOND_CHESTPLATE),
    ELYTRA_TRAIL("Estela de Elytra", Material.ELYTRA),
    DEATH_SOUND("Sonido de Kill", Material.NOTE_BLOCK),
    JOIN_MESSAGE("Mensaje de Entrada", Material.PLAYER_HEAD),
    DEATH_MESSAGE("Mensaje de Muerte", Material.WRITABLE_BOOK),
    HIT_EFFECT("Efecto de Golpe", Material.IRON_SWORD);

    private final String displayName;
    private final Material icon;

    CosmeticType(String displayName, Material icon) {
        this.displayName = displayName;
        this.icon = icon;
    }

    /**
     * Get the localized display name for this cosmetic type.
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Get the Material icon representing this cosmetic type in GUIs.
     */
    public Material getIcon() {
        return icon;
    }
}
