package com.ethernova.cosmetics.gui;

import com.ethernova.core.gui.CoreGui;
import com.ethernova.cosmetics.EthernovaCosmetics;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/**
 * Admin GUI for EthernovaCosmetics — full in-game configuration
 * without needing to touch config files.
 * Permission: ethernova.cosmetics.admin
 */
public class CosmeticsAdminGui extends CoreGui {

    private final EthernovaCosmetics plugin;

    public CosmeticsAdminGui(EthernovaCosmetics plugin, Player player) {
        super(plugin.getCore(), player);
        this.plugin = plugin;
    }

    public void open() {
        openInventory("<gradient:#FF6B6B:#FFD93D>⚙ Cosmetics Admin</gradient>", 54);
    }

    @Override
    protected void populateItems() {
        // ── Back ──
        setItem(45, createItem(Material.ARROW, "<gray>← Volver"));
        slotActions.put(45, "BACK");

        // ═══ Header ═══
        setItem(4, createItem(Material.PAINTING,
                "<gold><bold>⚙ Configuración de Cosméticos",
                List.of("<gray>Gestiona todos los ajustes",
                        "<gray>del plugin de cosméticos",
                        "",
                        "<dark_gray>Los cambios se guardan automáticamente")));

        // ═══ Row 1: Enabled Types ═══
        setItem(10, toggleItem("Kill Effect", "enabled-types.kill-effect"));
        slotActions.put(10, "TOGGLE:enabled-types.kill-effect");

        setItem(11, toggleItem("Death Effect", "enabled-types.death-effect"));
        slotActions.put(11, "TOGGLE:enabled-types.death-effect");

        setItem(12, toggleItem("Trail", "enabled-types.trail"));
        slotActions.put(12, "TOGGLE:enabled-types.trail");

        setItem(13, toggleItem("Projectile Trail", "enabled-types.projectile-trail"));
        slotActions.put(13, "TOGGLE:enabled-types.projectile-trail");

        setItem(14, toggleItem("Kill Message", "enabled-types.kill-message"));
        slotActions.put(14, "TOGGLE:enabled-types.kill-message");

        setItem(15, toggleItem("Win Effect", "enabled-types.win-effect"));
        slotActions.put(15, "TOGGLE:enabled-types.win-effect");

        // Section label
        setItem(16, createItem(Material.ORANGE_STAINED_GLASS_PANE,
                "<gold>Tipos Habilitados",
                List.of("<gray>Activa/desactiva tipos de cosméticos")));

        // ═══ Row 2: Trail & Projectile Settings ═══
        setItem(19, createItem(Material.CYAN_STAINED_GLASS_PANE,
                "<aqua>Ajustes de Trails", List.of("<gray>Configuración de partículas")));

        setItem(20, numberItem(Material.CLOCK, "Trail Interval", "trail.update-interval", "ticks"));
        slotActions.put(20, "INT:trail.update-interval:1:40");

        setItem(21, doubleItem(Material.SPYGLASS, "Trail Distancia", "trail.max-distance", "bloques"));
        slotActions.put(21, "DOUBLE:trail.max-distance:5.0:200.0");

        setItem(22, numberItem(Material.ARROW, "Projectile Interval", "projectile-trail.update-interval", "ticks"));
        slotActions.put(22, "INT:projectile-trail.update-interval:1:20");

        // ═══ Row 2 continued: Win Effect Settings ═══
        setItem(24, createItem(Material.MAGENTA_STAINED_GLASS_PANE,
                "<light_purple>Efectos de Victoria", List.of("<gray>Configuración de win effects")));

        setItem(25, numberItem(Material.FIREWORK_ROCKET, "Fireworks", "win-effect.firework-count", ""));
        slotActions.put(25, "INT:win-effect.firework-count:1:50");

        // ═══ Row 3: Win Effect continued + Sounds ═══
        setItem(28, numberItem(Material.LIGHTNING_ROD, "Lightning", "win-effect.lightning-count", ""));
        slotActions.put(28, "INT:win-effect.lightning-count:0:30");

        setItem(29, numberItem(Material.REPEATER, "Duración Win", "win-effect.duration-ticks", "ticks"));
        slotActions.put(29, "INT:win-effect.duration-ticks:20:200");

        // Separator
        setItem(31, createItem(Material.YELLOW_STAINED_GLASS_PANE,
                "<yellow>Sonidos", List.of("<gray>Configuración de sonidos")));

        setItem(32, soundItem("Equip", "sounds.cosmetic-equip"));
        slotActions.put(32, "CYCLE_SOUND:sounds.cosmetic-equip");

        setItem(33, soundItem("Unequip", "sounds.cosmetic-unequip"));
        slotActions.put(33, "CYCLE_SOUND:sounds.cosmetic-unequip");

        setItem(34, soundItem("Buy", "sounds.cosmetic-buy"));
        slotActions.put(34, "CYCLE_SOUND:sounds.cosmetic-buy");

        // ═══ Row 4: Actions ═══
        setItem(38, createItem(Material.COMMAND_BLOCK,
                "<green>⟳ Recargar Config",
                List.of("<gray>Recarga config.yml y mensajes",
                        "",
                        "<yellow>Click para recargar")));
        slotActions.put(38, "RELOAD");

        setItem(40, createItem(Material.BOOK,
                "<aqua>ℹ Información",
                List.of("<gray>Plugin: <white>EthernovaCosmetics",
                        "<gray>Cosméticos registrados: <white>" + plugin.getCosmeticRegistry().getAll().size(),
                        "<gray>Tipos activos: <white>" + countEnabledTypes())));

        setItem(42, createItem(Material.PAINTING,
                "<aqua>Estado del Plugin",
                List.of("<gray>Mensajes definidos en config.yml",
                        "<gray>bajo la sección <white>messages:")));

        // ═══ Close ═══
        setItem(49, createItem(Material.BARRIER, "<red>Cerrar"));
        slotActions.put(49, "CLOSE");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.startsWith("TOGGLE:")) {
            String path = action.substring(7);
            boolean current = plugin.getConfig().getBoolean(path, true);
            plugin.getConfig().set(path, !current);
            plugin.saveConfig();
            refresh();
            return true;
        }
        if (action.startsWith("INT:")) {
            String[] parts = action.substring(4).split(":");
            adjustInt(parts[0], event, Integer.parseInt(parts[1]), Integer.parseInt(parts[2]));
            return true;
        }
        if (action.startsWith("DOUBLE:")) {
            String[] parts = action.substring(7).split(":");
            adjustDouble(parts[0], event, Double.parseDouble(parts[1]), Double.parseDouble(parts[2]));
            return true;
        }
        if (action.startsWith("CYCLE_SOUND:")) {
            String path = action.substring(12);
            cycleSound(path);
            return true;
        }

        if ("RELOAD".equals(action)) {
            plugin.getConfigManager().reload();
            plugin.getCosmeticRegistry().loadFromYaml();
            playSound("success");
            player.closeInventory();
            player.sendMessage(mini.deserialize("<green>✔ Configuración de Cosméticos recargada."));
            return true;
        }
        if ("BACK".equals(action)) {
            playSound("click");
            player.closeInventory();
            Bukkit.getScheduler().runTaskLater(core, () -> player.performCommand("ethernova admin"), 2L);
            return true;
        }
        return false;
    }

    // ═══════════════ Helpers ═══════════════

    private void adjustInt(String path, InventoryClickEvent event, int min, int max) {
        int current = plugin.getConfig().getInt(path, 0);
        int delta = event.isShiftClick() ? 10 : 1;
        if (event.isRightClick()) delta = -delta;
        plugin.getConfig().set(path, Math.max(min, Math.min(max, current + delta)));
        plugin.saveConfig();
        refresh();
    }

    private void adjustDouble(String path, InventoryClickEvent event, double min, double max) {
        double current = plugin.getConfig().getDouble(path, 0);
        double delta = event.isShiftClick() ? 1.0 : 0.1;
        if (event.isRightClick()) delta = -delta;
        double newVal = Math.round(Math.max(min, Math.min(max, current + delta)) * 100.0) / 100.0;
        plugin.getConfig().set(path, newVal);
        plugin.saveConfig();
        refresh();
    }

    private void cycleSound(String path) {
        String[] sounds = {"ENTITY_PLAYER_LEVELUP", "BLOCK_NOTE_BLOCK_BASS", "ENTITY_VILLAGER_YES",
                "ENTITY_EXPERIENCE_ORB_PICKUP", "UI_BUTTON_CLICK", "BLOCK_NOTE_BLOCK_PLING"};
        String current = plugin.getConfig().getString(path, sounds[0]);
        int idx = 0;
        for (int i = 0; i < sounds.length; i++) {
            if (sounds[i].equalsIgnoreCase(current)) { idx = i; break; }
        }
        plugin.getConfig().set(path, sounds[(idx + 1) % sounds.length]);
        plugin.saveConfig();
        refresh();
    }

    private void refresh() {
        playSound("click");
        player.closeInventory();
        Bukkit.getScheduler().runTaskLater(core, this::open, 1L);
    }

    private ItemStack toggleItem(String name, String path) {
        boolean val = plugin.getConfig().getBoolean(path, true);
        return createItem(val ? Material.LIME_DYE : Material.GRAY_DYE,
                (val ? "<green>✔ " : "<red>✘ ") + name,
                List.of("<gray>Estado: " + (val ? "<green>Activado" : "<red>Desactivado"),
                        "",
                        "<yellow>Click para " + (val ? "desactivar" : "activar")));
    }

    private ItemStack numberItem(Material mat, String name, String path, String unit) {
        int val = plugin.getConfig().getInt(path, 0);
        String suffix = unit.isEmpty() ? "" : " " + unit;
        return createItem(mat,
                "<gold>" + name + ": <white>" + val + suffix,
                List.of("<gray>Click izq: <green>+1",
                        "<gray>Click der: <red>-1",
                        "<gray>Shift+Click: <yellow>±10"));
    }

    private ItemStack doubleItem(Material mat, String name, String path, String unit) {
        double val = plugin.getConfig().getDouble(path, 0);
        String suffix = unit.isEmpty() ? "" : " " + unit;
        return createItem(mat,
                "<gold>" + name + ": <white>" + String.format("%.1f", val) + suffix,
                List.of("<gray>Click izq: <green>+0.1",
                        "<gray>Click der: <red>-0.1",
                        "<gray>Shift+Click: <yellow>±1.0"));
    }

    private ItemStack soundItem(String name, String path) {
        String val = plugin.getConfig().getString(path, "UNKNOWN");
        String display = val.replace("ENTITY_", "").replace("BLOCK_", "").replace("_", " ");
        return createItem(Material.NOTE_BLOCK,
                "<gold>" + name + ": <white>" + display,
                List.of("<gray>Sonido actual: <yellow>" + val,
                        "",
                        "<yellow>Click para cambiar sonido"));
    }

    private int countEnabledTypes() {
        int count = 0;
        for (String type : List.of("kill-effect", "death-effect", "trail", "projectile-trail", "kill-message", "win-effect")) {
            if (plugin.getConfig().getBoolean("enabled-types." + type, true)) count++;
        }
        return count;
    }
}
