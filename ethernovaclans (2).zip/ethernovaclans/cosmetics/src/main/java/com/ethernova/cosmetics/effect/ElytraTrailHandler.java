package com.ethernova.cosmetics.effect;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.cosmetics.model.Cosmetic;
import com.ethernova.cosmetics.model.CosmeticType;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Handles elytra trails — particle effects shown behind players while gliding with elytra.
 * Each trail type has unique particle patterns and animations.
 * <p>
 * Replicates the original UltimateFFA elytra-trails system with 20+ animated effects.
 */
public class ElytraTrailHandler {

    private final EthernovaCosmetics plugin;
    /** Tick counters for animation phases per player. */
    private final Map<UUID, Integer> animTicks = new ConcurrentHashMap<>();
    private int taskId = -1;

    public ElytraTrailHandler(EthernovaCosmetics plugin) {
        this.plugin = plugin;
    }

    /**
     * Start the elytra trail task (runs every 1 tick for smooth trails).
     */
    public void start() {
        taskId = Bukkit.getScheduler().scheduleSyncRepeatingTask(plugin, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (!player.isGliding()) {
                    animTicks.remove(player.getUniqueId());
                    continue;
                }

                String trailId = plugin.getPlayerCosmeticManager().getEquipped(
                        player.getUniqueId(), CosmeticType.ELYTRA_TRAIL);
                if (trailId == null) continue;

                int tick = animTicks.getOrDefault(player.getUniqueId(), 0) + 1;
                animTicks.put(player.getUniqueId(), tick);

                spawnTrail(trailId, player.getLocation(), tick);
            }
        }, 1L, 1L);
    }

    /**
     * Stop the elytra trail task.
     */
    public void stop() {
        if (taskId != -1) {
            Bukkit.getScheduler().cancelTask(taskId);
            taskId = -1;
        }
        animTicks.clear();
    }

    /**
     * Spawn trail particles at the given location based on trail ID.
     */
    private void spawnTrail(String trailId, Location loc, int tick) {
        if (loc.getWorld() == null) return;

        switch (trailId.toLowerCase()) {
            case "elytra_rainbow" -> spawnRainbow(loc, tick);
            case "elytra_fire" -> loc.getWorld().spawnParticle(Particle.FLAME, loc, 5, 0.3, 0.3, 0.3, 0.02);
            case "elytra_ice" -> loc.getWorld().spawnParticle(Particle.SNOWFLAKE, loc, 5, 0.3, 0.3, 0.3, 0.02);
            case "elytra_dragon" -> loc.getWorld().spawnParticle(Particle.DRAGON_BREATH, loc, 5, 0.3, 0.3, 0.3, 0.01);
            case "elytra_starfield" -> loc.getWorld().spawnParticle(Particle.END_ROD, loc, 4, 0.3, 0.3, 0.3, 0.02);
            case "elytra_toxic" -> loc.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, loc, 3, 0.4, 0.4, 0.4, 0);
            case "elytra_portal" -> loc.getWorld().spawnParticle(Particle.PORTAL, loc, 10, 0.5, 0.5, 0.5, 0.3);
            case "elytra_smoke" -> loc.getWorld().spawnParticle(Particle.CAMPFIRE_COSY_SMOKE, loc, 3, 0.2, 0.2, 0.2, 0.01);
            case "elytra_cherry" -> loc.getWorld().spawnParticle(Particle.CHERRY_LEAVES, loc, 8, 0.4, 0.4, 0.4, 0);
            case "elytra_soul" -> loc.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, loc, 5, 0.3, 0.3, 0.3, 0.01);
            case "elytra_electric" -> loc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc, 6, 0.3, 0.3, 0.3, 0.05);
            case "elytra_void" -> loc.getWorld().spawnParticle(Particle.SQUID_INK, loc, 4, 0.3, 0.3, 0.3, 0.01);
            case "elytra_lava" -> loc.getWorld().spawnParticle(Particle.LAVA, loc, 3, 0.3, 0.3, 0.3, 0);
            case "elytra_enchant" -> loc.getWorld().spawnParticle(Particle.ENCHANT, loc, 10, 0.4, 0.4, 0.4, 0.5);
            case "elytra_nether" -> loc.getWorld().spawnParticle(Particle.CRIMSON_SPORE, loc, 8, 0.4, 0.4, 0.4, 0);
            case "elytra_heart" -> {
                if (tick % 3 == 0) loc.getWorld().spawnParticle(Particle.HEART, loc, 2, 0.3, 0.3, 0.3, 0);
            }
            case "elytra_note" -> {
                if (tick % 2 == 0) loc.getWorld().spawnParticle(Particle.NOTE, loc, 3, 0.4, 0.4, 0.4, 0);
            }
            case "elytra_sculk" -> loc.getWorld().spawnParticle(Particle.SCULK_CHARGE_POP, loc, 5, 0.3, 0.3, 0.3, 0.01);
            case "elytra_warden" -> loc.getWorld().spawnParticle(Particle.SONIC_BOOM, loc, 1, 0, 0, 0, 0);
            case "elytra_firework" -> {
                if (tick % 5 == 0) loc.getWorld().spawnParticle(Particle.FIREWORK, loc, 8, 0.3, 0.3, 0.3, 0.05);
            }
            default -> loc.getWorld().spawnParticle(Particle.CLOUD, loc, 3, 0.2, 0.2, 0.2, 0.01);
        }
    }

    /** Rainbow trail: cycling DUST colors (no java.awt dependency). */
    private void spawnRainbow(Location loc, int tick) {
        float hue = (tick % 60) / 60f;
        int rgb = hsbToRgb(hue, 1f, 1f);
        Particle.DustOptions dust = new Particle.DustOptions(
                org.bukkit.Color.fromRGB((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF), 1.2f);
        loc.getWorld().spawnParticle(Particle.DUST, loc, 6, 0.3, 0.3, 0.3, 0, dust);
    }

    /** Manual HSB→RGB conversion — avoids java.awt dependency on headless servers. */
    private static int hsbToRgb(float hue, float saturation, float brightness) {
        int r = 0, g = 0, b = 0;
        if (saturation == 0) {
            r = g = b = (int) (brightness * 255.0f + 0.5f);
        } else {
            float h = (hue - (float) Math.floor(hue)) * 6.0f;
            float f = h - (float) Math.floor(h);
            float p = brightness * (1.0f - saturation);
            float q = brightness * (1.0f - saturation * f);
            float t = brightness * (1.0f - (saturation * (1.0f - f)));
            switch ((int) h) {
                case 0 -> { r = (int)(brightness*255+0.5f); g = (int)(t*255+0.5f); b = (int)(p*255+0.5f); }
                case 1 -> { r = (int)(q*255+0.5f); g = (int)(brightness*255+0.5f); b = (int)(p*255+0.5f); }
                case 2 -> { r = (int)(p*255+0.5f); g = (int)(brightness*255+0.5f); b = (int)(t*255+0.5f); }
                case 3 -> { r = (int)(p*255+0.5f); g = (int)(q*255+0.5f); b = (int)(brightness*255+0.5f); }
                case 4 -> { r = (int)(t*255+0.5f); g = (int)(p*255+0.5f); b = (int)(brightness*255+0.5f); }
                case 5 -> { r = (int)(brightness*255+0.5f); g = (int)(p*255+0.5f); b = (int)(q*255+0.5f); }
            }
        }
        return (r << 16) | (g << 8) | b;
    }

    /**
     * Preview an elytra trail — equips elytra, elevates the player, forces gliding,
     * shows trail particles for 3 seconds, then teleports back and restores armor.
     */
    public void preview(Player player, String trailId) {
        if (player == null || trailId == null) return;

        // Save original state
        final Location originalLoc = player.getLocation().clone();
        final ItemStack originalChestplate = player.getInventory().getChestplate() != null
                ? player.getInventory().getChestplate().clone() : null;
        final boolean wasFlying = player.isFlying();
        final boolean wasAllowFlight = player.getAllowFlight();

        // Equip elytra and teleport up
        player.getInventory().setChestplate(new ItemStack(Material.ELYTRA));
        player.teleport(originalLoc.clone().add(0, 15, 0));

        // Force gliding after 1 tick (need to be in air first)
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) return;
            player.setGliding(true);
            player.setVelocity(player.getLocation().getDirection().multiply(0.8).setY(-0.1));
        }, 2L);

        // Spawn trail particles while gliding
        final int[] tick = {0};
        final int[] taskRef = {-1};
        taskRef[0] = Bukkit.getScheduler().scheduleSyncRepeatingTask(plugin, () -> {
            if (!player.isOnline() || tick[0]++ > 60) {
                if (taskRef[0] != -1) Bukkit.getScheduler().cancelTask(taskRef[0]);
                return;
            }
            // Force keep gliding
            if (!player.isGliding() && tick[0] < 55) {
                player.setGliding(true);
            }
            spawnTrail(trailId, player.getLocation(), tick[0]);
        }, 3L, 1L);

        // After 3 seconds: restore everything and teleport back
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) return;
            player.setGliding(false);
            player.teleport(originalLoc);
            player.getInventory().setChestplate(originalChestplate);
            player.setAllowFlight(wasAllowFlight);
            player.setFlying(wasFlying);
            player.setFallDistance(0f);
        }, 65L);
    }

    /**
     * Clean up for a specific player.
     */
    public void cleanup(UUID uuid) {
        animTicks.remove(uuid);
    }
}
