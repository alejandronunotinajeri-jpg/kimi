package com.ethernova.cosmetics.api;

import com.ethernova.cosmetics.model.Cosmetic;
import com.ethernova.cosmetics.model.CosmeticType;
import org.bukkit.Location;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Public API interface for EthernovaCosmetics.
 *
 * <p>Provides methods for managing player cosmetics including unlocking,
 * equipping, querying, and triggering visual effects.</p>
 *
 * <p>Obtain an instance via {@code ServiceRegistry.get(CosmeticsAPI.class)}.</p>
 *
 * <p>All methods are thread-safe. Effect trigger methods should be called
 * from the main server thread.</p>
 */
public interface CosmeticsAPI {

    // ═══════════════ Player Cosmetic State ═══════════════

    /**
     * Check if a player has unlocked a specific cosmetic.
     *
     * @param uuid       the UUID of the player
     * @param cosmeticId the cosmetic identifier
     * @return {@code true} if the cosmetic is unlocked
     */
    boolean isUnlocked(UUID uuid, String cosmeticId);

    /**
     * Unlock a cosmetic for a player.
     *
     * @param uuid       the UUID of the player
     * @param cosmeticId the cosmetic identifier
     * @return {@code true} if the cosmetic was newly unlocked, {@code false} if already owned
     */
    boolean unlock(UUID uuid, String cosmeticId);

    /**
     * Equip a cosmetic for a player. The cosmetic must be unlocked first.
     *
     * @param uuid       the UUID of the player
     * @param cosmeticId the cosmetic identifier
     * @return {@code true} if the cosmetic was successfully equipped
     */
    boolean equip(UUID uuid, String cosmeticId);

    /**
     * Unequip the equipped cosmetic of a given type.
     *
     * @param uuid the UUID of the player
     * @param type the {@link CosmeticType} to unequip
     * @return the removed cosmetic ID, or {@code null} if nothing was equipped
     */
    String unequip(UUID uuid, CosmeticType type);

    /**
     * Get the equipped cosmetic ID for a specific type.
     *
     * @param uuid the UUID of the player
     * @param type the {@link CosmeticType} to query
     * @return the equipped cosmetic ID, or {@code null} if none is equipped
     */
    String getEquipped(UUID uuid, CosmeticType type);

    /**
     * Get all equipped cosmetics for a player.
     *
     * @param uuid the UUID of the player
     * @return an unmodifiable map of {@link CosmeticType} to cosmetic ID
     */
    Map<CosmeticType, String> getAllEquipped(UUID uuid);

    /**
     * Get all unlocked cosmetic IDs for a player.
     *
     * @param uuid the UUID of the player
     * @return an unmodifiable set of unlocked cosmetic IDs
     */
    Set<String> getAllUnlocked(UUID uuid);

    /**
     * Check if a player has any cosmetic equipped of a given type.
     *
     * @param uuid the UUID of the player
     * @param type the {@link CosmeticType} to check
     * @return {@code true} if a cosmetic of that type is equipped
     */
    boolean hasEquipped(UUID uuid, CosmeticType type);

    // ═══════════════ Registry Queries ═══════════════

    /**
     * Get a cosmetic definition by its ID.
     *
     * @param id the cosmetic identifier
     * @return the {@link Cosmetic}, or {@code null} if not found
     */
    Cosmetic getCosmetic(String id);

    /**
     * Get all cosmetics of a specific type.
     *
     * @param type the {@link CosmeticType} to filter by
     * @return a list of matching {@link Cosmetic} definitions
     */
    List<Cosmetic> getCosmeticsByType(CosmeticType type);

    /**
     * Get all registered cosmetics.
     *
     * @return an unmodifiable collection of all {@link Cosmetic} definitions
     */
    Collection<Cosmetic> getAllCosmetics();

    /**
     * Get the total number of registered cosmetics.
     *
     * @return the cosmetic count
     */
    int getCosmeticCount();

    // ═══════════════ Effect Triggers ═══════════════

    /**
     * Trigger a kill effect at the victim's location if the killer has one equipped.
     *
     * @param killerUuid     the UUID of the killer
     * @param victimLocation the {@link Location} where the victim died
     */
    void triggerKillEffect(UUID killerUuid, Location victimLocation);

    /**
     * Trigger a win effect for a player if one is equipped.
     *
     * @param uuid the UUID of the player
     */
    void triggerWinEffect(UUID uuid);

    // ═══════════════ Trail Queries ═══════════════

    /**
     * Check if a player has an active trail cosmetic.
     *
     * @param uuid the UUID of the player
     * @return {@code true} if the player has an active trail
     */
    boolean hasActiveTrail(UUID uuid);
}
