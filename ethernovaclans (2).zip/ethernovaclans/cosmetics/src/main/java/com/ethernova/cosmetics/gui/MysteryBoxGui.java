package com.ethernova.cosmetics.gui;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.cosmetics.manager.CosmeticRegistry;
import com.ethernova.cosmetics.model.CosmeticRarity;
import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.PaginatedGui;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * GUI for purchasing and opening mystery boxes.
 * Shows each available mystery box with rarity weights, price, and open-on-click.
 */
public class MysteryBoxGui extends PaginatedGui {

    private final EthernovaCosmetics cosmetics;

    public MysteryBoxGui(EthernovaCore core, Player player, EthernovaCosmetics cosmetics) {
        super(core, player);
        this.cosmetics = cosmetics;
    }

    public void open() {
        openPaginated("<gradient:#ff6b35:#ffd700>✦ Mystery Boxes</gradient>", 0);
    }

    @Override
    protected String getTitle() {
        return "<gradient:#ff6b35:#ffd700>✦ Mystery Boxes</gradient>";
    }

    @Override
    protected List<PageItem> getPageItems() {
        List<PageItem> items = new ArrayList<>();
        Map<String, CosmeticRegistry.MysteryBoxDef> boxes = cosmetics.getCosmeticRegistry().getMysteryBoxes();

        var profile = core.getProfileManager().getProfile(player.getUniqueId());
        double coins = profile != null ? profile.getCoins() : 0;

        for (var entry : boxes.entrySet()) {
            CosmeticRegistry.MysteryBoxDef box = entry.getValue();

            List<String> lore = new ArrayList<>();
            lore.add("");
            lore.add("<gray>" + box.description());
            lore.add("");
            lore.add("<white>Probabilidades:");

            for (CosmeticRarity rarity : CosmeticRarity.values()) {
                int w = box.weights().getOrDefault(rarity, 0);
                if (w > 0) {
                    lore.add("  " + rarity.getColor() + rarity.getDisplayName() + " <dark_gray>- <white>" + w + "%");
                }
            }

            lore.add("");
            lore.add("<gray>Precio: <gold>" + String.format("%.0f", box.price()) + " monedas");
            lore.add("<gray>Tus monedas: <gold>" + String.format("%.0f", coins));
            lore.add("");

            if (coins >= box.price()) {
                lore.add("<green>▶ Click izq. para comprar y abrir");
            } else {
                lore.add("<red>✘ No tienes suficientes monedas");
            }
            lore.add("<yellow>▶ Click der. para ver contenido");

            items.add(new PageItem(
                    createItem(box.icon(), "<gold>✦ " + box.name(), lore),
                    "BOX_" + entry.getKey()
            ));
        }

        return items;
    }

    @Override
    protected boolean onItemClick(String action, int slot, InventoryClickEvent event) {
        if (!action.startsWith("BOX_")) return false;

        String boxId = action.substring(4);
        playSound("click");

        // Right-click → preview contents
        if (event.isRightClick()) {
            var boxDef = cosmetics.getCosmeticRegistry().getMysteryBox(boxId);
            if (boxDef != null) {
                new MysteryBoxPreviewGui(core, player, cosmetics, boxDef).open();
            }
            return true;
        }

        // Left-click → buy and open
        player.closeInventory();
        cosmetics.getMysteryBoxManager().openBox(player, boxId);
        return true;
    }

    @Override
    protected void onBack() {
        new CosmeticsMainGui(core, player, cosmetics).open();
    }
}
