package com.ethernova.cosmetics.effect;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.cosmetics.model.Cosmetic;
import com.ethernova.cosmetics.model.CosmeticType;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

import java.util.UUID;

/**
 * Handles death sounds — custom sounds played when a player kills another player.
 * <p>
 * Replicates the original UltimateFFA death-sounds shop category.
 */
public class DeathSoundHandler {

    private final EthernovaCosmetics plugin;

    public DeathSoundHandler(EthernovaCosmetics plugin) {
        this.plugin = plugin;
    }

    /**
     * Preview a death sound for the player.
     */
    public void preview(Player player, String soundId) {
        if (player == null || soundId == null) return;
        playSound(soundId, player, player.getLocation());
    }

    /**
     * Play the killer's equipped death sound at the victim's location.
     */
    public void triggerDeathSound(UUID killerUuid, Player victim) {
        if (killerUuid == null || victim == null) return;

        String soundId = plugin.getPlayerCosmeticManager().getEquipped(killerUuid, CosmeticType.DEATH_SOUND);
        if (soundId == null) return;

        Player killer = org.bukkit.Bukkit.getPlayer(killerUuid);
        if (killer == null) return;

        playSound(soundId, killer, victim.getLocation());
    }

    private void playSound(String soundId, Player killer, org.bukkit.Location loc) {
        switch (soundId.toLowerCase()) {
            case "sound_pling", "dsound_pling" -> loc.getWorld().playSound(loc, Sound.BLOCK_NOTE_BLOCK_PLING, 2.0f, 1.0f);
            case "sound_anvil", "dsound_anvil" -> loc.getWorld().playSound(loc, Sound.BLOCK_ANVIL_LAND, 1.5f, 1.0f);
            case "sound_dragon", "dsound_dragon" -> loc.getWorld().playSound(loc, Sound.ENTITY_ENDER_DRAGON_GROWL, 1.0f, 1.0f);
            case "sound_wither", "dsound_wither" -> loc.getWorld().playSound(loc, Sound.ENTITY_WITHER_SPAWN, 0.5f, 1.5f);
            case "sound_totem", "dsound_totem" -> loc.getWorld().playSound(loc, Sound.ITEM_TOTEM_USE, 1.0f, 1.2f);
            case "sound_bell", "dsound_bell" -> loc.getWorld().playSound(loc, Sound.BLOCK_BELL_USE, 2.0f, 0.8f);
            case "sound_thunder", "dsound_thunder" -> loc.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.5f, 1.0f);
            case "sound_horn", "dsound_horn" -> loc.getWorld().playSound(loc, Sound.EVENT_RAID_HORN, 1.5f, 1.0f);
            case "sound_explosion", "sound_explode", "dsound_explosion" -> loc.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 1.0f);
            case "sound_levelup", "sound_level_up", "dsound_levelup" -> loc.getWorld().playSound(loc, Sound.ENTITY_PLAYER_LEVELUP, 1.5f, 1.0f);
            // ────── Original UltimateFFA DeathSound enum sounds ──────
            case "sound_villager", "dsound_villager" -> loc.getWorld().playSound(loc, Sound.ENTITY_VILLAGER_TRADE, 1.5f, 1.0f);
            case "sound_burp", "dsound_burp" -> loc.getWorld().playSound(loc, Sound.ENTITY_PLAYER_BURP, 1.5f, 1.0f);
            case "sound_cat", "dsound_cat" -> loc.getWorld().playSound(loc, Sound.ENTITY_CAT_AMBIENT, 1.5f, 1.0f);
            case "sound_glass", "dsound_glass" -> loc.getWorld().playSound(loc, Sound.BLOCK_GLASS_BREAK, 2.0f, 1.0f);
            case "sound_enderman", "dsound_enderman" -> loc.getWorld().playSound(loc, Sound.ENTITY_ENDERMAN_SCREAM, 1.5f, 1.0f);
            case "sound_goat", "dsound_goat" -> loc.getWorld().playSound(loc, Sound.ENTITY_GOAT_SCREAMING_AMBIENT, 1.5f, 1.0f);
            default -> { /* unknown sound */ }
        }
    }
}
