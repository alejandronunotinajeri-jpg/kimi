package com.ethernova.cosmetics.aura;

import com.ethernova.cosmetics.EthernovaCosmetics;
import com.ethernova.cosmetics.gui.CosmeticsMainGui;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * AuraGUIManager — Manages all GUI (inventory menus) for the Auras system.
 * Ported from UltimateFFA AuraGUIManager.
 *
 * Handles: tier selection, aura browsing, pattern selection, fusion GUI,
 * multi-slot management, advanced configuration, and all click handlers.
 */
public class AuraGUIManager {

    private final EthernovaCosmetics plugin;
    private final AdvancedAurasManager aurasManager;
    private final Map<UUID, Integer> configGUIPage = new ConcurrentHashMap<>();

    // PVP-obstructive auras (only for lobby use)
    static final Set<String> PVP_OBSTRUCTIVE_AURAS = new HashSet<>(Arrays.asList(
        "shield", "tornado", "void", "black_hole", "nebula", "galaxy", "god", "dragon"
    ));
    static final Set<String> PVP_OBSTRUCTIVE_PATTERNS = new HashSet<>(Arrays.asList(
        "shield", "tornado", "dna", "radar"
    ));

    /** Rainbow glass colors for animated borders. */
    private static final Material[] RAINBOW_PANES = {
        Material.RED_STAINED_GLASS_PANE, Material.ORANGE_STAINED_GLASS_PANE,
        Material.YELLOW_STAINED_GLASS_PANE, Material.LIME_STAINED_GLASS_PANE,
        Material.GREEN_STAINED_GLASS_PANE, Material.CYAN_STAINED_GLASS_PANE,
        Material.LIGHT_BLUE_STAINED_GLASS_PANE, Material.BLUE_STAINED_GLASS_PANE,
        Material.PURPLE_STAINED_GLASS_PANE, Material.MAGENTA_STAINED_GLASS_PANE,
        Material.PINK_STAINED_GLASS_PANE, Material.WHITE_STAINED_GLASS_PANE
    };

    /** Active border animation tasks per player. */
    private final Map<UUID, org.bukkit.scheduler.BukkitTask> borderAnimations = new ConcurrentHashMap<>();

    public AuraGUIManager(EthernovaCosmetics plugin, AdvancedAurasManager aurasManager) {
        this.plugin = plugin;
        this.aurasManager = aurasManager;
    }

    public void cleanupPlayer(UUID uuid) {
        configGUIPage.remove(uuid);
        Player player = Bukkit.getPlayer(uuid);
        if (player != null) {
            stopBorderAnimation(player);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //                      GUI PRINCIPAL - TIERS
    // ═══════════════════════════════════════════════════════════════

    public void openTiersGUI(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, "§6§l✦ SELECCIONAR TIER ✦");
        fillBorder(inv);

        // Row 1: Tier categories (centered)
        inv.setItem(10, makeItem(Material.IRON_INGOT, "§f§lBASIC TIER",
            "", "§75 Auras básicas", "§7Precios: §e3,000 - 5,000 monedas", "", "§aClick para ver auras"));

        inv.setItem(12, makeItem(Material.GOLD_INGOT, "§9§lPREMIUM TIER",
            "", "§715 Auras premium", "§7Precios: §e6,000 - 15,000 monedas", "", "§aClick para ver auras"));

        inv.setItem(14, makeItem(Material.DIAMOND, "§5§lLEGENDARY TIER",
            "", "§710 Auras legendarias", "§7Precios: §e18,000 - 35,000 monedas", "", "§aClick para ver auras"));

        inv.setItem(16, makeItem(Material.NETHER_STAR, "§6§lSPECIAL TIER",
            "", "§710 Auras especiales", "§7Precios: §e40,000 - 100,000 monedas", "§c⚠ ULTRA RARAS", "", "§aClick para ver auras"));

        // Row 2: Management options (centered)
        inv.setItem(20, makeItem(Material.BREWING_STAND, "§5§l⚗ FUSIÓN DE AURAS",
            "", "§7Combina 2 auras para crear", "§7efectos híbridos únicos", "",
            "§e10 Fusiones disponibles", "", "§aClick para explorar fusiones"));

        inv.setItem(22, makeItem(Material.ENDER_CHEST, "§e§l⚡ SLOTS MÚLTIPLES",
            "", "§7Activa múltiples auras", "§7simultáneamente", "",
            "§a✓ PRIMARY §7(Gratis)", "§e○ SECONDARY §7(10K coins)",
            "§6○ SPECIAL §7(50K coins)", "", "§aClick para gestionar"));

        inv.setItem(24, makeItem(Material.COMPARATOR, "§b§l⚙ CONFIGURACIÓN",
            "", "§7Personaliza tus auras:", "§f• §7Intensidad, Velocidad",
            "§f• §7Radio, Modo Blend", "", "§aClick para configurar"));

        // Row 3: Feature info (centered)
        UUID uuid = player.getUniqueId();
        boolean soundOn = aurasManager.soundEnabled.getOrDefault(uuid, true);
        inv.setItem(29, makeItem(soundOn ? Material.NOTE_BLOCK : Material.IRON_TRAPDOOR,
            "§e§l🔊 SONIDOS", "",
            "§7Estado: " + (soundOn ? "§a§lON ✓" : "§c§lOFF ✗"), "",
            "§eClick para " + (soundOn ? "§cdesactivar" : "§aactivar")));

        int streak = aurasManager.playerKillStreaks.getOrDefault(uuid, 0);
        int sTier = aurasManager.streakTier.getOrDefault(uuid, 0);
        String tierName = switch (sTier) { case 1 -> "WARMING"; case 2 -> "BLAZING"; case 3 -> "INFERNO"; case 4 -> "GODLIKE"; default -> "NORMAL"; };
        String tierColor = switch (sTier) { case 1 -> "§e"; case 2 -> "§6"; case 3 -> "§c"; case 4 -> "§d"; default -> "§7"; };
        inv.setItem(31, makeItem(sTier >= 3 ? Material.BLAZE_POWDER : sTier >= 1 ? Material.FIRE_CHARGE : Material.GUNPOWDER,
            "§c§l🔥 STREAK", "",
            "§7Racha: §f" + streak + " kills",
            "§7Tier: " + tierColor + "§l" + tierName));

        World world = player.getWorld();
        long time = world.getTime();
        boolean isNight = time >= 13000 && time <= 23000;
        inv.setItem(33, makeItem(Material.CLOCK, "§b§l🌀 DINÁMICAS", "",
            "§7Tu aura se adapta al entorno",
            "§7Hora: " + (isNight ? "§9🌙 Noche" : "§e☀ Día"),
            "§7Clima: " + (world.isThundering() ? "§e⚡ Tormenta" : world.hasStorm() ? "§b☂ Lluvia" : "§f☀ Despejado")));

        // Row 4: Actions
        inv.setItem(36, makeItem(Material.ARROW, "§c← Volver", "§7Volver a la tienda"));

        boolean hasActive = aurasManager.activeAuras.containsKey(uuid) ||
            (aurasManager.playerSlots.containsKey(uuid) && !aurasManager.playerSlots.get(uuid).isEmpty());
        if (hasActive) {
            List<String> dLore = new ArrayList<>();
            dLore.add("");
            if (aurasManager.playerSlots.containsKey(uuid)) {
                for (var entry : aurasManager.playerSlots.get(uuid).entrySet()) {
                    dLore.add("§7Slot " + entry.getKey() + ": §f" + aurasManager.getAuraName(entry.getValue().auraId()));
                }
            } else if (aurasManager.activeAuras.containsKey(uuid)) {
                dLore.add("§7Activa: §f" + aurasManager.getAuraName(aurasManager.activeAuras.get(uuid).auraId()));
            }
            dLore.add(""); dLore.add("§c§lClick para desactivar todo");
            inv.setItem(40, makeItem(Material.BARRIER, "§c§l✗ DESACTIVAR AURA", dLore.toArray(String[]::new)));
        }

        player.openInventory(inv);
        startBorderAnimation(player, inv);
    }

    // ═══════════════════════════════════════════════════════════════
    //                      TIER AURAS GUI
    // ═══════════════════════════════════════════════════════════════

    public void openTierAurasGUI(Player player, String tier) {
        Inventory inv = Bukkit.createInventory(null, 54, "§6§l✦ " + tier.toUpperCase() + " AURAS ✦");
        fillBorder(inv);

        // Content slots (avoid borders): rows 1-4 inner slots
        int[] contentSlots = {10, 11, 12, 13, 14, 15, 16,
                              19, 20, 21, 22, 23, 24, 25,
                              28, 29, 30, 31, 32, 33, 34,
                              37, 38, 39, 40, 41, 42, 43};

        String[] auraIds = getAurasByTier(tier);
        for (int i = 0; i < auraIds.length && i < contentSlots.length; i++) {
            String auraId = auraIds[i];
            int price = aurasManager.getAuraPrice(auraId);
            boolean unlocked = aurasManager.hasAura(player.getUniqueId(), auraId);
            boolean active = aurasManager.isAuraActive(player.getUniqueId(), auraId);
            inv.setItem(contentSlots[i], createAuraItem(auraId, price, unlocked, active));
        }

        inv.setItem(49, makeItem(Material.ARROW, "§e← Volver a Tiers"));
        player.openInventory(inv);
        startBorderAnimation(player, inv);
    }

    private String[] getAurasByTier(String tier) {
        return switch (tier.toUpperCase()) {
            case "BASIC" -> new String[]{"redstone", "nature", "storm", "flame", "ink"};
            case "PREMIUM" -> new String[]{"lava", "candy", "snow", "toxic", "music",
                "heart", "emerald", "critical", "totem", "frost", "cherry", "portal", "enchanted", "cyber", "witch"};
            case "LEGENDARY" -> new String[]{"rainbow_aura", "energy", "oceanic", "halo", "dna_aura",
                "galaxy", "phoenix", "dragon", "angels", "demons"};
            case "SPECIAL" -> new String[]{"nebula", "quantum", "celestial", "void", "aurora",
                "matrix", "volcanic", "ancient", "black_hole", "god"};
            default -> new String[]{};
        };
    }

    // ═══════════════════════════════════════════════════════════════
    //                      PATTERNS GUI
    // ═══════════════════════════════════════════════════════════════

    public void openPatternsGUI(Player player, String auraId) {
        if (!aurasManager.hasAura(player.getUniqueId(), auraId)) {
            player.sendMessage("§c¡No tienes esta aura desbloqueada!");
            return;
        }

        Inventory inv = Bukkit.createInventory(null, 54, "§6§l✦ PATRONES: " + auraId.toUpperCase() + " ✦");
        fillBorder(inv);

        int[] slots = {10, 11, 12, 13, 14, 19, 20, 21, 22, 23, 28, 29};
        for (int i = 0; i < AdvancedAurasManager.ALL_PATTERNS.length; i++) {
            String patternId = AdvancedAurasManager.ALL_PATTERNS[i];
            int price = aurasManager.getPatternPrice(patternId);
            boolean unlocked = patternId.equals("falling") || aurasManager.hasPattern(player.getUniqueId(), auraId, patternId);
            boolean active = aurasManager.isPatternActive(player.getUniqueId(), auraId, patternId);
            inv.setItem(slots[i], createPatternItem(auraId, patternId, price, unlocked, active));
        }

        inv.setItem(45, makeItem(Material.ARROW, "§e← Volver"));
        inv.setItem(49, makeItem(Material.BARRIER, "§c✗ Desactivar Aura"));
        player.openInventory(inv);
        startBorderAnimation(player, inv);
    }

    // ═══════════════════════════════════════════════════════════════
    //                      FUSION GUI
    // ═══════════════════════════════════════════════════════════════

    public void openFusionsGUI(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, "§5§l⚗ FUSIÓN DE AURAS ⚗");
        fillBorder(inv);

        int[] slots = {10, 11, 12, 13, 14, 19, 20, 21, 22, 23};
        for (int i = 0; i < AdvancedAurasManager.ALL_FUSIONS.length && i < slots.length; i++) {
            inv.setItem(slots[i], createFusionItem(player, AdvancedAurasManager.ALL_FUSIONS[i]));
        }

        inv.setItem(49, makeItem(Material.ARROW, "§e← Volver a Tiers"));
        player.openInventory(inv);
        startBorderAnimation(player, inv);
    }

    private ItemStack createFusionItem(Player player, String fusionId) {
        String[] components = aurasManager.getFusionComponents(fusionId);
        if (components == null) return makeItem(Material.BARRIER, "§c§lERROR: " + fusionId);

        String aura1 = components[0], aura2 = components[1];
        int price = aurasManager.getAuraPrice(fusionId);
        boolean has1 = aurasManager.hasAura(player.getUniqueId(), aura1);
        boolean has2 = aurasManager.hasAura(player.getUniqueId(), aura2);
        boolean unlocked = aurasManager.hasAura(player.getUniqueId(), fusionId);
        boolean active = aurasManager.isAuraActive(player.getUniqueId(), fusionId);

        Material mat = unlocked ? (active ? Material.GLOWSTONE_DUST : Material.NETHER_STAR) :
            (has1 && has2) ? Material.BREWING_STAND : Material.BARRIER;

        List<String> lore = new ArrayList<>();
        lore.add("");
        lore.add("§7╔════ §e§lREQUISITOS §7═══╗");
        lore.add((has1 ? "§a✓" : "§c✗") + " §7Aura 1: §f" + aura1.toUpperCase());
        lore.add((has2 ? "§a✓" : "§c✗") + " §7Aura 2: §f" + aura2.toUpperCase());
        lore.add("§7╚════════════════════"); lore.add("");
        lore.add("§7Precio: §e" + String.format("%,d", price) + " monedas"); lore.add("");

        if (unlocked) {
            lore.add(active ? "§a§l✓ ACTIVA" : "§e§l◆ DESBLOQUEADA");
            lore.add(active ? "§7Clic para §cdesactivar" : "§7Clic para §aactivar");
        } else if (has1 && has2) {
            lore.add("§e§l★ DISPONIBLE"); lore.add("§7Clic para §edesbloquear");
        } else {
            lore.add("§c§l✗ BLOQUEADA"); lore.add("§7Necesitas ambas auras");
        }
        lore.add("§8§oID:" + fusionId);

        return makeItem(mat, aurasManager.getAuraName(fusionId), lore.toArray(String[]::new));
    }

    // ═══════════════════════════════════════════════════════════════
    //                  MULTIPLE SLOTS SYSTEM
    // ═══════════════════════════════════════════════════════════════

    public void openSlotsGUI(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, "§e§l⚡ GESTIÓN DE SLOTS ⚡");
        fillBorder(inv);

        UUID uuid = player.getUniqueId();
        aurasManager.ensurePrimarySlot(uuid);

        inv.setItem(20, createSlotItem(player, "PRIMARY", Material.EMERALD, "§a§lSLOT PRIMARY", "§aSiempre disponible"));
        boolean hasSec = aurasManager.hasSlot(uuid, "SECONDARY");
        inv.setItem(22, createSlotItem(player, "SPECIAL", aurasManager.hasSlot(uuid, "SPECIAL") ? Material.NETHER_STAR : Material.IRON_BLOCK,
            "§6§lSLOT SPECIAL", aurasManager.hasSlot(uuid, "SPECIAL") ? "§aDesbloqueado" : "§650,000 coins para desbloquear"));
        inv.setItem(24, createSlotItem(player, "SECONDARY", hasSec ? Material.DIAMOND : Material.IRON_INGOT,
            "§9§lSLOT SECONDARY", hasSec ? "§aDesbloqueado" : "§e10,000 coins para desbloquear"));

        inv.setItem(49, makeItem(Material.ARROW, "§e← Volver a Tiers"));
        player.openInventory(inv);
        startBorderAnimation(player, inv);
    }

    private ItemStack createSlotItem(Player player, String slotName, Material mat, String displayName, String status) {
        UUID uuid = player.getUniqueId();
        boolean unlocked = aurasManager.hasSlot(uuid, slotName);
        List<String> lore = new ArrayList<>();
        lore.add(""); lore.add("§7Estado: " + status); lore.add("");

        if (aurasManager.playerSlots.containsKey(uuid) && aurasManager.playerSlots.get(uuid).containsKey(slotName)) {
            ActiveAura aura = aurasManager.playerSlots.get(uuid).get(slotName);
            lore.add("§e§lAura Activa:"); lore.add("§f" + aura.auraId().toUpperCase());
            lore.add("§7Patrón: §f" + aura.patternId()); lore.add(""); lore.add("§cClic para desactivar");
        } else if (unlocked) {
            lore.add("§e§lSlot vacío"); lore.add("§7Selecciona una aura para activar"); lore.add(""); lore.add("§aClick para abrir auras");
        } else {
            lore.add("§c§lBLOQUEADO"); lore.add("§7Click para desbloquear");
        }

        return makeItem(mat, displayName, lore.toArray(String[]::new));
    }

    private void openSlotAuraSelector(Player player, String slotName) {
        Inventory inv = Bukkit.createInventory(null, 54, "§e§l⚡ " + slotName + " - Seleccionar Aura ⚡");
        fillBorder(inv);

        UUID uuid = player.getUniqueId();
        Set<String> playerAuras = new HashSet<>();
        if (aurasManager.unlockedAuras.containsKey(uuid)) playerAuras.addAll(aurasManager.unlockedAuras.get(uuid));
        for (String aura : AdvancedAurasManager.ALL_AURAS) {
            if (aurasManager.hasAura(uuid, aura)) playerAuras.add(aura);
        }

        int slot = 10;
        for (String auraId : playerAuras) {
            if (slot >= 44) break;
            Material mat = getAuraMaterial(auraId);
            List<String> lore = new ArrayList<>();
            lore.add(""); lore.add("§aClick para asignar a este slot"); lore.add("§8§oID:" + auraId);
            inv.setItem(slot, makeItem(mat, aurasManager.getAuraName(auraId), lore.toArray(String[]::new)));
            slot++;
            if (slot % 9 == 8) slot += 2;
        }

        inv.setItem(49, makeItem(Material.ARROW, "§e← Volver a Slots"));
        player.setMetadata("selecting_slot", new org.bukkit.metadata.FixedMetadataValue(plugin, slotName));
        player.openInventory(inv);
        startBorderAnimation(player, inv);
    }

    private void openPatternSelectorForSlot(Player player, String auraId, String slotName) {
        Inventory inv = Bukkit.createInventory(null, 54, "§6§l✦ PATRÓN PARA " + slotName + " ✦");
        fillBorder(inv);

        int[] slots = {10, 11, 12, 13, 14, 19, 20, 21, 22, 23, 28, 29};
        for (int i = 0; i < AdvancedAurasManager.ALL_PATTERNS.length; i++) {
            String patternId = AdvancedAurasManager.ALL_PATTERNS[i];
            int price = aurasManager.getPatternPrice(patternId);
            boolean unlocked = patternId.equals("falling") || aurasManager.hasPattern(player.getUniqueId(), auraId, patternId);
            inv.setItem(slots[i], createPatternItem(auraId, patternId, price, unlocked, false));
        }

        inv.setItem(49, makeItem(Material.ARROW, "§e← Volver a Auras"));
        player.openInventory(inv);
        startBorderAnimation(player, inv);
    }

    // ═══════════════════════════════════════════════════════════════
    //              ADVANCED CONFIGURATION SYSTEM
    // ═══════════════════════════════════════════════════════════════

    public void openAdvancedConfigGUI(Player player) { openAdvancedConfigGUI(player, 0); }

    public void openAdvancedConfigGUI(Player player, int page) {
        UUID uuid = player.getUniqueId();
        aurasManager.playerConfigs.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>());

        List<String> playerAuras = new ArrayList<>();
        for (String aura : AdvancedAurasManager.ALL_AURAS) {
            if (aurasManager.hasAura(uuid, aura)) playerAuras.add(aura);
        }

        int aurasPerPage = 21;
        int totalPages = Math.max(1, (int) Math.ceil((double) playerAuras.size() / aurasPerPage));
        page = Math.max(0, Math.min(page, totalPages - 1));
        configGUIPage.put(uuid, page);

        String title = totalPages > 1 ? "§b§l⚙ CONFIG (" + (page + 1) + "/" + totalPages + ") ⚙" : "§b§l⚙ CONFIGURACIÓN AVANZADA ⚙";
        Inventory inv = Bukkit.createInventory(null, 54, title);
        fillBorder(inv);

        int startIndex = page * aurasPerPage, endIndex = Math.min(startIndex + aurasPerPage, playerAuras.size());
        int[] auraSlots = {10,11,12,13,14,15,16, 19,20,21,22,23,24,25, 28,29,30,31,32,33,34};

        for (int i = startIndex; i < endIndex; i++) {
            int slotIdx = i - startIndex;
            if (slotIdx < auraSlots.length) inv.setItem(auraSlots[slotIdx], createConfigAuraItem(player, playerAuras.get(i)));
        }

        if (page > 0) inv.setItem(45, makeItem(Material.SPECTRAL_ARROW, "§e← Página Anterior", "§7Página " + page + "/" + totalPages));
        inv.setItem(48, makeItem(Material.BARRIER, "§c§l↻ Restablecer Todo", "", "§7Restaura valores por defecto", "§7en todas las auras", "", "§cClick para restablecer"));
        inv.setItem(49, makeItem(Material.ARROW, "§e← Volver a Tiers"));
        inv.setItem(50, makeItem(Material.BOOK, "§6§lTus Auras: §f" + playerAuras.size(), "§7Página " + (page + 1) + " de " + totalPages, "", "§eClick en un aura para", "§eajustar intensidad, velocidad y radio"));
        if (page < totalPages - 1) inv.setItem(53, makeItem(Material.SPECTRAL_ARROW, "§e Página Siguiente →", "§7Página " + (page + 2) + "/" + totalPages));

        player.openInventory(inv);
        startBorderAnimation(player, inv);
    }

    private ItemStack createConfigAuraItem(Player player, String auraId) {
        UUID uuid = player.getUniqueId();
        AuraConfig cfg = aurasManager.playerConfigs.get(uuid).getOrDefault(auraId, new AuraConfig());

        List<String> lore = new ArrayList<>();
        lore.add(""); lore.add("§b§lCONFIGURACIÓN ACTUAL:");
        lore.add("§f• Intensidad: §e" + String.format("%.1f", cfg.intensity()));
        lore.add("§f• Velocidad: §e" + String.format("%.1f", cfg.speed()));
        lore.add("§f• Radio: §e" + String.format("%.1f", cfg.radius()));
        lore.add("§f• Blend: §e" + cfg.blendMode());
        if (PVP_OBSTRUCTIVE_AURAS.contains(auraId.toLowerCase())) {
            lore.add(""); lore.add("§c§l⚠ ADVERTENCIA PVP:");
            lore.add("§cEsta aura puede obstruir la");
            lore.add("§cvisión durante el combate.");
        }
        lore.add(""); lore.add("§aClick para ajustar"); lore.add("§8§oID:" + auraId);

        return makeItem(getAuraMaterial(auraId), aurasManager.getAuraName(auraId), lore.toArray(String[]::new));
    }

    public void openAuraSettingsGUI(Player player, String auraId) {
        Inventory inv = Bukkit.createInventory(null, 54, "§b§l⚙ CONFIG: " + auraId.toUpperCase() + " ⚙");
        fillBorder(inv);

        UUID uuid = player.getUniqueId();
        aurasManager.playerConfigs.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>());
        AuraConfig config = aurasManager.playerConfigs.get(uuid).computeIfAbsent(auraId, k -> new AuraConfig());

        // Intensity
        inv.setItem(11, createSettingItem(Material.GLOWSTONE_DUST, "§e§lINTENSIDAD", config.intensity(), 0.1, 2.0));
        inv.setItem(20, makeItem(Material.RED_CONCRETE, "§c§l- 0.1"));
        inv.setItem(29, makeItem(Material.LIME_CONCRETE, "§a§l+ 0.1"));

        // Speed
        inv.setItem(13, createSettingItem(Material.FEATHER, "§b§lVELOCIDAD", config.speed(), 0.5, 2.0));
        inv.setItem(21, makeItem(Material.RED_CONCRETE, "§c§l- 0.1"));
        inv.setItem(30, makeItem(Material.LIME_CONCRETE, "§a§l+ 0.1"));

        // Radius
        inv.setItem(15, createSettingItem(Material.ENDER_PEARL, "§d§lRADIO", config.radius(), 0.5, 3.0));
        inv.setItem(23, makeItem(Material.RED_CONCRETE, "§c§l- 0.1"));
        inv.setItem(32, makeItem(Material.LIME_CONCRETE, "§a§l+ 0.1"));

        // Blend mode
        inv.setItem(22, makeItem(Material.PAINTING, "§6§lMODO BLEND", "",
            "§7Actual: §e" + config.blendMode(), "", "§7Click para cambiar:",
            "§fNORMAL §7→ ADDITIVE §7→ MULTIPLY", "", "§8(Afecta cómo se mezclan partículas)"));

        // PVP Warning
        if (PVP_OBSTRUCTIVE_AURAS.contains(auraId.toLowerCase())) {
            inv.setItem(36, makeItem(Material.TNT, "§c§l⚠ ADVERTENCIA PVP", "",
                "§cEsta aura puede obstruir", "§cla visión en combate PVP.", "",
                "§eSe desactivará automáticamente", "§eal entrar en una arena FFA."));
        }

        inv.setItem(39, makeItem(Material.BARRIER, "§c§l↻ Restablecer", "§7Volver a valores por defecto"));
        inv.setItem(40, makeItem(Material.EMERALD, "§a§l✓ APLICAR CAMBIOS"));
        inv.setItem(49, makeItem(Material.ARROW, "§e← Volver"));

        player.setMetadata("configuring_aura", new org.bukkit.metadata.FixedMetadataValue(plugin, auraId));
        player.openInventory(inv);
        startBorderAnimation(player, inv);
    }

    private ItemStack createSettingItem(Material mat, String name, double value, double min, double max) {
        double pct = ((value - min) / (max - min)) * 100;
        int bars = (int) (pct / 10);
        StringBuilder pb = new StringBuilder("§7[");
        for (int i = 0; i < 10; i++) pb.append(i < bars ? "§a▰" : "§7▱");
        pb.append("§7]");
        return makeItem(mat, name, "", "§7Valor: §e" + String.format("%.1f", value),
            pb.toString(), "", "§7Rango: §f" + String.format("%.1f", min) + " - " + String.format("%.1f", max));
    }

    // ═══════════════════════════════════════════════════════════════
    //                      GUI CLICK HANDLERS
    // ═══════════════════════════════════════════════════════════════

    public void handleTiersClick(Player player, ItemStack item, int slot) {
        if (item == null || !item.hasItemMeta()) return;
        String name = ChatColor.stripColor(item.getItemMeta().getDisplayName());

        if (slot == 20 || name.contains("FUSION")) { openFusionsGUI(player); return; }
        if (slot == 22 || name.contains("SLOTS")) { openSlotsGUI(player); return; }
        if (slot == 24 || name.contains("CONFIGURACION") || name.contains("CONFIG")) { openAdvancedConfigGUI(player); return; }
        if (slot == 29 || name.contains("SONIDOS")) { aurasManager.toggleSound(player); openTiersGUI(player); return; }
        if (slot == 31 || name.contains("STREAK")) {
            player.sendMessage("§c§l🔥 STREAK §8» §7Racha: §f" + aurasManager.getPlayerStreak(player.getUniqueId()) +
                " §7| Tier: §f" + aurasManager.getStreakTierName(aurasManager.getStreakTier(player.getUniqueId()))); return;
        }
        if (slot == 33 || name.contains("DINAMICA")) {
            player.sendMessage("§b§l🌀 DYNAMIC §8» §7Tu aura se adapta automáticamente al entorno"); return;
        }
        if (slot == 40 || name.contains("DESACTIVAR")) { aurasManager.deactivateAura(player); openTiersGUI(player); return; }
        if (slot == 36 && item.getType() == Material.ARROW) {
            new CosmeticsMainGui(plugin.getCore(), player, plugin).open();
            return;
        }

        if (name.contains("BASIC")) openTierAurasGUI(player, "BASIC");
        else if (name.contains("PREMIUM")) openTierAurasGUI(player, "PREMIUM");
        else if (name.contains("LEGENDARY")) openTierAurasGUI(player, "LEGENDARY");
        else if (name.contains("SPECIAL")) openTierAurasGUI(player, "SPECIAL");
    }

    public void handleTierAurasClick(Player player, ItemStack item, int slot, String tier, boolean isRightClick) {
        if (item == null || !item.hasItemMeta()) return;
        if (slot == 49) { openTiersGUI(player); return; }

        String auraId = extractAuraIdFromLore(item);
        if (auraId == null) {
            for (String id : getAurasByTier(tier)) {
                if (ChatColor.stripColor(item.getItemMeta().getDisplayName()).contains(ChatColor.stripColor(aurasManager.getAuraName(id)))) {
                    auraId = id; break;
                }
            }
        }
        if (auraId == null) return;

        UUID uuid = player.getUniqueId();
        if (isRightClick) { startAuraPreview(player, auraId, tier); return; }

        if (!aurasManager.hasAura(uuid, auraId)) {
            int price = aurasManager.getAuraPrice(auraId);
            if (aurasManager.purchaseAura(player, auraId, price)) openTierAurasGUI(player, tier);
        } else {
            openPatternsGUI(player, auraId);
        }
    }

    public void handlePatternsClick(Player player, ItemStack item, int slot, String title, boolean isRightClick) {
        if (item == null || !item.hasItemMeta()) return;
        UUID uuid = player.getUniqueId();
        String auraId = extractAuraFromTitle(title);

        if (slot == 45) { openTiersGUI(player); return; }
        if (slot == 49) {
            aurasManager.deactivateAura(player);
            openTiersGUI(player); return;
        }

        int[] slots = {10,11,12,13,14, 19,20,21,22,23, 28,29};
        String selectedPattern = null;
        for (int i = 0; i < slots.length; i++) {
            if (slot == slots[i] && i < AdvancedAurasManager.ALL_PATTERNS.length) {
                selectedPattern = AdvancedAurasManager.ALL_PATTERNS[i]; break;
            }
        }
        if (selectedPattern == null) return;

        if (isRightClick) { startPatternPreview(player, auraId, selectedPattern); return; }

        boolean unlocked = selectedPattern.equals("falling") || aurasManager.hasPattern(uuid, auraId, selectedPattern);
        if (!unlocked) {
            int price = aurasManager.getPatternPrice(selectedPattern);
            if (aurasManager.purchasePattern(player, auraId, selectedPattern, price)) openPatternsGUI(player, auraId);
        } else {
            aurasManager.activateAura(player, auraId, selectedPattern);
            player.closeInventory();
        }
    }

    public void handleFusionsClick(Player player, ItemStack item, int slot) {
        if (item == null || !item.hasItemMeta()) return;
        if (slot == 49) { openTiersGUI(player); return; }

        int[] slots = {10,11,12,13,14, 19,20,21,22,23};
        String fusionId = null;
        for (int i = 0; i < slots.length; i++) {
            if (slot == slots[i] && i < AdvancedAurasManager.ALL_FUSIONS.length) {
                fusionId = AdvancedAurasManager.ALL_FUSIONS[i]; break;
            }
        }
        if (fusionId == null) return;

        UUID uuid = player.getUniqueId();
        if (!aurasManager.hasAura(uuid, fusionId)) {
            // Try to unlock fusion
            String[] comps = aurasManager.getFusionComponents(fusionId);
            if (comps == null) return;
            if (!aurasManager.hasAura(uuid, comps[0]) || !aurasManager.hasAura(uuid, comps[1])) {
                player.sendMessage("§c§l✗ §cNecesitas desbloquear las dos auras base primero!");
                return;
            }
            int price = aurasManager.getAuraPrice(fusionId);
            if (aurasManager.purchaseAura(player, fusionId, price)) openFusionsGUI(player);
        } else if (aurasManager.isAuraActive(uuid, fusionId)) {
            aurasManager.deactivateAura(player);
            openFusionsGUI(player);
        } else {
            openPatternsGUI(player, fusionId);
        }
    }

    public void handleSlotsClick(Player player, ItemStack item, int slot) {
        if (item == null || !item.hasItemMeta()) return;
        UUID uuid = player.getUniqueId();
        if (slot == 49) { openTiersGUI(player); return; }

        String slotName = null; int price = 0;
        if (slot == 20) { slotName = "PRIMARY"; }
        else if (slot == 24) { slotName = "SECONDARY"; price = 10000; }
        else if (slot == 22) { slotName = "SPECIAL"; price = 50000; }
        if (slotName == null) return;

        if (!aurasManager.hasSlot(uuid, slotName) && !slotName.equals("PRIMARY")) {
            var profile = plugin.getCore().getProfileManager().getProfile(uuid);
            if (profile == null || profile.getCoins() < price) {
                player.sendMessage("§c§l✗ §cNecesitas §e" + price + " monedas"); return;
            }
            profile.addCoins(-price);
            aurasManager.unlockSlot(uuid, slotName);
            player.sendMessage("§a§l✓ §aSlot " + slotName + " desbloqueado!");
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);
            openSlotsGUI(player); return;
        }

        if (aurasManager.playerSlots.containsKey(uuid) && aurasManager.playerSlots.get(uuid).containsKey(slotName)) {
            aurasManager.playerSlots.get(uuid).remove(slotName);
            if (slotName.equals("PRIMARY")) aurasManager.activeAuras.remove(uuid);
            if (aurasManager.playerSlots.get(uuid).isEmpty()) aurasManager.activeAuras.remove(uuid);
            player.playSound(player.getLocation(), Sound.BLOCK_FIRE_EXTINGUISH, 1f, 1f);
            player.sendMessage("§c§l✗ §cAura del slot " + slotName + " desactivada");
            openSlotsGUI(player); return;
        }

        openSlotAuraSelector(player, slotName);
    }

    public void handleSlotAuraSelection(Player player, ItemStack item, int slot) {
        if (item == null || !item.hasItemMeta()) return;
        if (slot == 49) { player.removeMetadata("selecting_slot", plugin); openSlotsGUI(player); return; }

        if (!player.hasMetadata("selecting_slot")) { player.sendMessage("§c§l✗ §cError: No se detectó el slot"); return; }
        String slotName = player.getMetadata("selecting_slot").get(0).asString();
        String auraId = extractAuraIdFromLore(item);
        if (auraId == null) { player.sendMessage("§c§l✗ §cNo se pudo identificar el aura"); return; }

        player.removeMetadata("selecting_slot", plugin);
        player.setMetadata("assigning_slot", new org.bukkit.metadata.FixedMetadataValue(plugin, slotName));
        player.setMetadata("assigning_aura", new org.bukkit.metadata.FixedMetadataValue(plugin, auraId));
        openPatternSelectorForSlot(player, auraId, slotName);
    }

    public void handleSlotPatternSelection(Player player, ItemStack item, int slot) {
        if (item == null || !item.hasItemMeta()) return;
        UUID uuid = player.getUniqueId();
        if (slot == 49) {
            if (player.hasMetadata("assigning_slot"))
                openSlotAuraSelector(player, player.getMetadata("assigning_slot").get(0).asString());
            return;
        }
        if (!player.hasMetadata("assigning_slot") || !player.hasMetadata("assigning_aura")) return;

        String slotName = player.getMetadata("assigning_slot").get(0).asString();
        String auraId = player.getMetadata("assigning_aura").get(0).asString();

        int[] slots = {10,11,12,13,14, 19,20,21,22,23, 28,29};
        String selectedPattern = null;
        for (int i = 0; i < slots.length; i++) {
            if (slot == slots[i] && i < AdvancedAurasManager.ALL_PATTERNS.length) {
                selectedPattern = AdvancedAurasManager.ALL_PATTERNS[i]; break;
            }
        }
        if (selectedPattern == null) return;
        if (!selectedPattern.equals("falling") && !aurasManager.hasPattern(uuid, auraId, selectedPattern)) {
            player.sendMessage("§c§l✗ §cDebes desbloquear este patrón primero"); return;
        }

        aurasManager.playerSlots.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>()).put(slotName, new ActiveAura(auraId, selectedPattern));
        aurasManager.activeAuras.put(uuid, new ActiveAura(auraId, selectedPattern));
        player.sendMessage("§a§l✓ §aAura " + auraId.toUpperCase() + " asignada al slot " + slotName);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);
        player.removeMetadata("assigning_slot", plugin); player.removeMetadata("assigning_aura", plugin);
        openSlotsGUI(player);
    }

    public void handleAdvancedConfigClick(Player player, ItemStack item, int slot) {
        if (item == null || !item.hasItemMeta()) return;
        UUID uuid = player.getUniqueId();
        if (slot == 49) { openTiersGUI(player); return; }
        if (slot == 48) {
            aurasManager.playerConfigs.put(uuid, new ConcurrentHashMap<>());
            player.sendMessage("§a§l✓ §aConfiguración restablecida para todas las auras");
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 2f);
            openAdvancedConfigGUI(player, configGUIPage.getOrDefault(uuid, 0)); return;
        }
        if (slot == 45) { openAdvancedConfigGUI(player, configGUIPage.getOrDefault(uuid, 0) - 1); return; }
        if (slot == 53) { openAdvancedConfigGUI(player, configGUIPage.getOrDefault(uuid, 0) + 1); return; }

        String auraId = extractAuraIdFromLore(item);
        if (auraId != null && aurasManager.hasAura(uuid, auraId)) openAuraSettingsGUI(player, auraId);
    }

    public void handleAuraSettingsClick(Player player, ItemStack item, int slot) {
        if (item == null || !item.hasItemMeta()) return;
        if (!player.hasMetadata("configuring_aura")) return;
        UUID uuid = player.getUniqueId();
        String auraId = player.getMetadata("configuring_aura").get(0).asString();

        aurasManager.playerConfigs.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>());
        AuraConfig config = aurasManager.playerConfigs.get(uuid).computeIfAbsent(auraId, k -> new AuraConfig());

        if (slot == 49) { player.removeMetadata("configuring_aura", plugin); openAdvancedConfigGUI(player, configGUIPage.getOrDefault(uuid, 0)); return; }
        if (slot == 40) {
            player.removeMetadata("configuring_aura", plugin);
            player.sendMessage("§a§l✓ §aConfiguración aplicada a §f" + auraId.toUpperCase());
            if (PVP_OBSTRUCTIVE_AURAS.contains(auraId.toLowerCase()))
                player.sendMessage("§c§l⚠ §cEsta aura puede obstruir la visión en PVP.");
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);
            openAdvancedConfigGUI(player, configGUIPage.getOrDefault(uuid, 0)); return;
        }
        if (slot == 39) { aurasManager.playerConfigs.get(uuid).put(auraId, new AuraConfig()); player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 2f); openAuraSettingsGUI(player, auraId); return; }

        // Intensity controls
        if (slot == 20) { config.intensity = Math.max(0.1, config.intensity - 0.1); openAuraSettingsGUI(player, auraId); return; }
        if (slot == 29) { config.intensity = Math.min(2.0, config.intensity + 0.1); openAuraSettingsGUI(player, auraId); return; }
        // Speed controls
        if (slot == 21) { config.speed = Math.max(0.5, config.speed - 0.1); openAuraSettingsGUI(player, auraId); return; }
        if (slot == 30) { config.speed = Math.min(2.0, config.speed + 0.1); openAuraSettingsGUI(player, auraId); return; }
        // Radius controls
        if (slot == 23) { config.radius = Math.max(0.5, config.radius - 0.1); openAuraSettingsGUI(player, auraId); return; }
        if (slot == 32) { config.radius = Math.min(3.0, config.radius + 0.1); openAuraSettingsGUI(player, auraId); return; }
        // Blend mode
        if (slot == 22) {
            config.blendMode = switch (config.blendMode) { case "NORMAL" -> "ADDITIVE"; case "ADDITIVE" -> "MULTIPLY"; default -> "NORMAL"; };
            openAuraSettingsGUI(player, auraId);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //                      PREVIEW SYSTEM
    // ═══════════════════════════════════════════════════════════════

    public void startAuraPreview(Player player, String auraId, String tier) {
        Particle particle = aurasManager.getAuraParticle(auraId);
        Color previewColor = aurasManager.getAuraColor(auraId);
        player.closeInventory();
        player.sendMessage("§b§l✦ PREVIEW §8» §fProbando aura " + aurasManager.getAuraName(auraId) + " §7(4s)");
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.5f);

        new BukkitRunnable() {
            int tick = 0;
            @Override public void run() {
                if (tick >= 80 || !player.isOnline()) {
                    cancel();
                    if (player.isOnline()) {
                        player.sendMessage("§7Vista previa terminada.");
                        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1f, 1f);
                        // Reopen the tier auras GUI after a brief delay
                        Bukkit.getScheduler().runTaskLater(plugin, () -> {
                            if (player.isOnline()) openTierAurasGUI(player, tier);
                        }, 10L);
                    }
                    return;
                }
                Location loc = player.getLocation().add(0, 1, 0);
                double angle = tick * 0.15;
                for (int i = 0; i < 3; i++) {
                    double a = angle + (i * Math.PI * 2 / 3);
                    Location pl = loc.clone().add(Math.cos(a), (tick % 20) * 0.05, Math.sin(a));
                    try {
                        if (particle == Particle.DUST) {
                            player.getWorld().spawnParticle(Particle.DUST, pl, 1, 0, 0, 0, 0, new Particle.DustOptions(previewColor, 1.2f));
                        } else {
                            player.getWorld().spawnParticle(particle, pl, 1, 0, 0, 0, 0);
                        }
                    } catch (Exception e) {
                        player.getWorld().spawnParticle(Particle.DUST, pl, 1, 0, 0, 0, 0, new Particle.DustOptions(previewColor, 1.2f));
                    }
                }
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void startPatternPreview(Player player, String auraId, String patternId) {
        UUID uuid = player.getUniqueId();
        player.closeInventory();
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.5f);
        player.sendMessage("§e§l★ §eVisualizando patrón: §f" + aurasManager.getPatternName(patternId) + " §7(4s)");

        ActiveAura prev = aurasManager.activeAuras.get(uuid);
        Map<String, ActiveAura> prevSlots = aurasManager.playerSlots.containsKey(uuid) ? new HashMap<>(aurasManager.playerSlots.get(uuid)) : null;

        ActiveAura previewAura = new ActiveAura(auraId, patternId);
        aurasManager.activeAuras.put(uuid, previewAura);
        Map<String, ActiveAura> previewSlots = new ConcurrentHashMap<>();
        previewSlots.put("PRIMARY", previewAura);
        aurasManager.playerSlots.put(uuid, previewSlots);

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (prev != null) aurasManager.activeAuras.put(uuid, prev); else aurasManager.activeAuras.remove(uuid);
            if (prevSlots != null) aurasManager.playerSlots.put(uuid, new ConcurrentHashMap<>(prevSlots)); else aurasManager.playerSlots.remove(uuid);
            if (player.isOnline()) {
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1f, 1f);
                player.sendMessage("§7Preview finalizado");
                Bukkit.getScheduler().runTaskLater(plugin, () -> { if (player.isOnline()) openPatternsGUI(player, auraId); }, 10L);
            }
        }, 80L);
    }

    // ═══════════════════════════════════════════════════════════════
    //                      ITEM CREATION
    // ═══════════════════════════════════════════════════════════════

    private ItemStack createAuraItem(String auraId, int price, boolean unlocked, boolean active) {
        Material mat = getAuraMaterial(auraId);
        String display = (active ? "§a§l✓ " : unlocked ? "§f" : "§7") + aurasManager.getAuraName(auraId);

        List<String> lore = new ArrayList<>(); lore.add("");
        if (unlocked) {
            lore.add("§aESTADO: DESBLOQUEADA");
            lore.add(active ? "§f▶ §eACTIVA AHORA" : "§f▶ §7Click para activar");
            lore.add(""); lore.add("§bClick para ver patrones");
        } else {
            lore.add("§cESTADO: BLOQUEADA");
            lore.add("§f▶ §eComprar por §6" + String.format("%,d", price) + " coins");
            lore.add(""); lore.add("§7Al comprar desbloqueas:");
            lore.add("§f• Efecto base (cayendo)"); lore.add("§f• 10 patrones personalizables");
            lore.add(""); lore.add("§a▸ Click izquierdo: §fComprar"); lore.add("§e▸ Click derecho: §bVista previa §7(3s)");
        }
        lore.add("§8§oID:" + auraId);
        return makeItem(mat, display, lore.toArray(String[]::new));
    }

    private ItemStack createPatternItem(String auraId, String patternId, int price, boolean unlocked, boolean active) {
        Material mat = getPatternMaterial(patternId);
        String display = (active ? "§a§l✓ " : unlocked ? "§f" : "§7") + aurasManager.getPatternName(patternId);

        List<String> lore = new ArrayList<>(); lore.add("");
        lore.add(getPatternDescription(patternId)); lore.add("");
        if (unlocked) {
            lore.add("§aESTADO: DESBLOQUEADO"); lore.add(active ? "§f▶ §eACTIVO AHORA" : "§f▶ §7Click izquierdo para activar");
        } else {
            lore.add("§cESTADO: BLOQUEADO");
            lore.add(price > 0 ? "§f▶ §7Click izquierdo: §eComprar (§6" + price + " coins§e)" : "§f▶ §a¡GRATIS con esta aura!");
        }
        lore.add(""); lore.add("§e▸ Click derecho para §bpreview §7(3s)");
        return makeItem(mat, display, lore.toArray(String[]::new));
    }

    // ═══════════════════════════════════════════════════════════════
    //                      MATERIAL MAPPINGS
    // ═══════════════════════════════════════════════════════════════

    public Material getAuraMaterial(String auraId) {
        return switch (auraId.toLowerCase()) {
            case "fire" -> Material.BLAZE_POWDER; case "water" -> Material.PRISMARINE_SHARD;
            case "nature" -> Material.OAK_SAPLING; case "ice" -> Material.ICE;
            case "lightning" -> Material.GOLDEN_SWORD; case "shadow" -> Material.COAL;
            case "holy" -> Material.NETHER_STAR; case "toxic" -> Material.SLIME_BALL;
            case "cosmic" -> Material.END_CRYSTAL; case "blood" -> Material.RED_DYE;
            case "redstone" -> Material.REDSTONE; case "storm" -> Material.GHAST_TEAR;
            case "flame" -> Material.FIRE_CHARGE; case "ink" -> Material.INK_SAC;
            case "lava" -> Material.MAGMA_CREAM; case "candy" -> Material.SWEET_BERRIES;
            case "snow" -> Material.SNOWBALL; case "music" -> Material.NOTE_BLOCK;
            case "heart" -> Material.PINK_DYE; case "emerald" -> Material.EMERALD;
            case "critical" -> Material.IRON_SWORD; case "totem" -> Material.TOTEM_OF_UNDYING;
            case "frost" -> Material.BLUE_ICE; case "cherry" -> Material.CHERRY_SAPLING;
            case "portal" -> Material.OBSIDIAN; case "enchanted" -> Material.ENCHANTED_BOOK;
            case "cyber" -> Material.REPEATER; case "witch" -> Material.BREWING_STAND;
            case "rainbow_aura" -> Material.PRISMARINE_CRYSTALS; case "energy" -> Material.GLOWSTONE_DUST;
            case "oceanic" -> Material.TRIDENT; case "halo" -> Material.BEACON;
            case "dna_aura" -> Material.GHAST_TEAR; case "galaxy" -> Material.AMETHYST_SHARD;
            case "phoenix" -> Material.FEATHER; case "dragon" -> Material.DRAGON_HEAD;
            case "angels" -> Material.FEATHER; case "demons" -> Material.WITHER_SKELETON_SKULL;
            case "nebula" -> Material.PURPLE_DYE; case "quantum" -> Material.END_PORTAL_FRAME;
            case "celestial" -> Material.FIREWORK_STAR; case "void" -> Material.ENDER_PEARL;
            case "aurora" -> Material.LIGHT_BLUE_DYE; case "matrix" -> Material.LIME_DYE;
            case "volcanic" -> Material.NETHERITE_SCRAP; case "ancient" -> Material.ECHO_SHARD;
            case "black_hole" -> Material.BLACK_CONCRETE; case "god" -> Material.ENCHANTED_GOLDEN_APPLE;
            default -> Material.PAPER;
        };
    }

    private Material getPatternMaterial(String patternId) {
        return switch (patternId.toLowerCase()) {
            case "helix" -> Material.STRING; case "tornado" -> Material.FEATHER;
            case "shield" -> Material.SHIELD; case "dna" -> Material.BONE;
            case "vortex" -> Material.ENDER_EYE; case "circle" -> Material.ENDER_PEARL;
            case "wings" -> Material.ELYTRA; case "pulse" -> Material.HEART_OF_THE_SEA;
            case "orbit" -> Material.ECHO_SHARD; case "radar" -> Material.COMPASS;
            case "rainbow" -> Material.PRISMARINE_SHARD;
            default -> Material.PAPER;
        };
    }

    private String getPatternDescription(String patternId) {
        return switch (patternId.toLowerCase()) {
            case "falling" -> "§7Partículas cayendo suavemente §a(GRATIS)";
            case "helix" -> "§7Espiral ascendente elegante";
            case "tornado" -> "§7Torbellino expansivo feroz";
            case "shield" -> "§7Esfera protectora completa";
            case "dna" -> "§7Doble hélice científica";
            case "vortex" -> "§7Remolino horizontal giratorio";
            case "circle" -> "§7Anillo horizontal perfecto";
            case "wings" -> "§7Alas angelicales batientes";
            case "pulse" -> "§7Ondas expansivas rítmicas";
            case "orbit" -> "§7Órbitas planetarias triple";
            case "radar" -> "§7Barrido de radar rotatorio";
            default -> "§7Patrón especial";
        };
    }

    // ═══════════════════════════════════════════════════════════════
    //                      UTILITY METHODS
    // ═══════════════════════════════════════════════════════════════

    private String extractAuraIdFromLore(ItemStack item) {
        if (item == null || !item.hasItemMeta() || !item.getItemMeta().hasLore()) return null;
        for (String line : item.getItemMeta().getLore()) {
            String stripped = ChatColor.stripColor(line);
            if (stripped.startsWith("ID:")) return stripped.substring(3);
        }
        return null;
    }

    public String extractAuraFromTitle(String title) {
        String clean = ChatColor.stripColor(title).toUpperCase();
        if (clean.contains("CELESTIAL_PHOENIX") || clean.contains("CELESTIAL PHOENIX")) return "celestial_phoenix";
        if (clean.contains("OMEGA_BLACK_HOLE") || clean.contains("OMEGA BLACK HOLE")) return "omega_black_hole";
        if (clean.contains("DIVINE_MATRIX") || clean.contains("DIVINE MATRIX")) return "divine_matrix";
        if (clean.contains("COSMIC_VOID") || clean.contains("COSMIC VOID")) return "cosmic_void";
        if (clean.contains("DARK_DRAGON") || clean.contains("DARK DRAGON")) return "dark_dragon";
        if (clean.contains("VOID_STORM") || clean.contains("VOID STORM")) return "void_storm";
        if (clean.contains("HOLY_FIRE") || clean.contains("HOLY FIRE")) return "holy_fire";
        if (clean.contains("TOXIC_FIRE") || clean.contains("TOXIC FIRE")) return "toxic_fire";
        if (clean.contains("FROSTBITE")) return "frostbite"; if (clean.contains("PLASMA")) return "plasma";
        if (clean.contains("RAINBOW_AURA") || clean.contains("RAINBOW AURA")) return "rainbow_aura";
        if (clean.contains("DNA_AURA") || clean.contains("DNA AURA")) return "dna_aura";
        if (clean.contains("BLACK_HOLE")) return "black_hole";
        for (String aura : AdvancedAurasManager.ALL_AURAS) {
            if (clean.contains(aura.toUpperCase().replace("_", " ")) || clean.contains(aura.toUpperCase())) return aura;
        }
        return "redstone";
    }

    public boolean isObstructiveInPVP(String auraId, String patternId) {
        return PVP_OBSTRUCTIVE_AURAS.contains(auraId.toLowerCase()) || PVP_OBSTRUCTIVE_PATTERNS.contains(patternId.toLowerCase());
    }

    // ═══════════════════════════════════════════════════════════════
    //                      HELPER METHODS
    // ═══════════════════════════════════════════════════════════════

    private void fillBorder(Inventory inv) {
        List<Integer> borderSlots = new ArrayList<>();
        for (int i = 0; i < inv.getSize(); i++) {
            if (i < 9 || i >= inv.getSize() - 9 || i % 9 == 0 || i % 9 == 8) {
                borderSlots.add(i);
                Material mat = RAINBOW_PANES[i % RAINBOW_PANES.length];
                ItemStack glass = new ItemStack(mat);
                ItemMeta m = glass.getItemMeta();
                m.setDisplayName(" ");
                glass.setItemMeta(m);
                inv.setItem(i, glass);
            }
        }
    }

    /**
     * Start animated rainbow border for a player's open inventory.
     * Protects non-glass items from being overwritten.
     */
    private void startBorderAnimation(Player player, Inventory inv) {
        stopBorderAnimation(player);
        List<Integer> borderSlots = new ArrayList<>();
        Set<Integer> protectedSlots = new HashSet<>();
        for (int i = 0; i < inv.getSize(); i++) {
            if (i < 9 || i >= inv.getSize() - 9 || i % 9 == 0 || i % 9 == 8) {
                // Check if this border slot has a non-glass item placed after fillBorder
                ItemStack existing = inv.getItem(i);
                if (existing != null && !existing.getType().isAir()
                        && !existing.getType().name().endsWith("_STAINED_GLASS_PANE")) {
                    protectedSlots.add(i);
                } else {
                    borderSlots.add(i);
                }
            }
        }
        final int[] offset = {0};
        org.bukkit.scheduler.BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (inv.getViewers().isEmpty()) {
                stopBorderAnimation(player);
                return;
            }
            offset[0]++;
            for (int slot : borderSlots) {
                Material mat = RAINBOW_PANES[(slot + offset[0]) % RAINBOW_PANES.length];
                ItemStack glass = new ItemStack(mat);
                ItemMeta m = glass.getItemMeta();
                m.setDisplayName(" ");
                glass.setItemMeta(m);
                inv.setItem(slot, glass);
            }
        }, 4, 4);
        borderAnimations.put(player.getUniqueId(), task);
    }

    /**
     * Stop the border animation for a player.
     */
    public void stopBorderAnimation(Player player) {
        org.bukkit.scheduler.BukkitTask task = borderAnimations.remove(player.getUniqueId());
        if (task != null) task.cancel();
    }

    private ItemStack makeItem(Material mat, String name, String... lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        if (lore.length > 0) meta.setLore(Arrays.asList(lore));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack makeItem(Material mat, String name, List<String> lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }
}
