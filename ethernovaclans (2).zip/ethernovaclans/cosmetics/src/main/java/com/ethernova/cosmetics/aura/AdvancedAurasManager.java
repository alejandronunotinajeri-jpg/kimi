package com.ethernova.cosmetics.aura;

import com.ethernova.cosmetics.EthernovaCosmetics;
import org.bukkit.*;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Advanced Aura System — ported from UltimateFFA AdvancedAurasManager.
 *
 * Features:
 * - 48 base auras (4 tiers: Basic/Premium/Legendary/Special)
 * - 12 patterns per aura (falling, helix, tornado, shield, dna, vortex, circle, wings, pulse, orbit, radar, rainbow)
 * - 10 fusion combinations
 * - Multi-slot system (PRIMARY/SECONDARY/SPECIAL)
 * - Streak reactive (kill streak intensification)
 * - Dynamic auras (day/night, weather, health)
 * - Ambient sounds per aura
 * - Per-player rendering with LOD
 * - TPS-adaptive quality
 * - Kill effects with absorption animation
 * - Attack/damage/jump burst triggers
 */
public class AdvancedAurasManager {

    private final EthernovaCosmetics plugin;
    private final AuraPatternRenderer patternRenderer = new AuraPatternRenderer();
    private AuraGUIManager guiManager;

    // ═══ Player Data (all ConcurrentHashMap for safety) ═══
    // Package-private access for AuraGUIManager
    final Map<UUID, Map<String, ActiveAura>> playerSlots = new ConcurrentHashMap<>();
    final Map<UUID, Set<String>> unlockedSlots = new ConcurrentHashMap<>();
    final Map<UUID, Map<String, AuraConfig>> playerConfigs = new ConcurrentHashMap<>();
    final Map<UUID, ActiveAura> activeAuras = new ConcurrentHashMap<>();
    final Map<UUID, Set<String>> unlockedAuras = new ConcurrentHashMap<>();
    final Map<UUID, Map<String, Set<String>>> unlockedPatterns = new ConcurrentHashMap<>();
    final Map<UUID, Integer> playerKillStreaks = new ConcurrentHashMap<>();
    final Map<UUID, Integer> streakTier = new ConcurrentHashMap<>();
    final Map<UUID, Boolean> soundEnabled = new ConcurrentHashMap<>();
    final Map<UUID, Location> lastLocation = new ConcurrentHashMap<>();
    final Map<UUID, Long> lastAttackBurst = new ConcurrentHashMap<>();
    final Map<UUID, Long> lastJumpBurst = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastKillEffect = new ConcurrentHashMap<>();

    // ═══ Aura Sounds ═══
    private final Map<String, Sound> auraSounds = new HashMap<>();
    private final Map<String, Float> auraSoundPitch = new HashMap<>();

    // ═══ Performance Config ═══
    private double AURA_RENDER_DISTANCE_SQ = 32.0 * 32.0;
    private double LOD_MEDIUM_DISTANCE_SQ = 16.0 * 16.0;
    private double LOD_FAR_DISTANCE_SQ = 25.0 * 25.0;
    private int renderInterval = 2;
    private double globalIntensity = 0.5;
    private double globalRadius = 0.8;
    private float dustSize = 0.7f;
    private double maxIntensityMult = 2.0;
    private double maxRadiusMult = 1.5;

    // Streak multipliers
    private boolean streakEnabled = true;
    private double[] streakIntensityArr = {1.0, 1.15, 1.3, 1.5, 1.8};
    private double[] streakRadiusArr = {1.0, 1.05, 1.1, 1.2, 1.3};

    // Dynamic multipliers
    private boolean dynamicEnabled = true;
    private double dynNightIntensity = 1.2, dynNightRadius = 1.1;
    private double dynStormSpeed = 1.15;
    private double dynLowHealthSpeed = 1.2, dynLowHealthIntensity = 1.3;

    // TPS + quality
    private long lastTickTime = System.currentTimeMillis();
    private double estimatedTPS = 20.0;
    private int qualityLevel = 2;
    private Player currentRenderTarget = null;
    private int currentLOD = 2;
    private Color currentAuraColor = Color.RED;

    // Persistence
    private File playerDataFile;
    private FileConfiguration playerDataConfig;
    private BukkitTask auraTask;
    private BukkitTask autoSaveTask;

    // ═══════════════════════════════════════════
    //              INITIALIZATION
    // ═══════════════════════════════════════════

    public AdvancedAurasManager(EthernovaCosmetics plugin) {
        this.plugin = plugin;
        loadSettings();
        initializeAuraSounds();
        this.guiManager = new AuraGUIManager(plugin, this);
    }

    public void start() {
        startAuraTask();
        startAutoSaveTask();
    }

    public void stop() {
        if (auraTask != null) auraTask.cancel();
        if (autoSaveTask != null) autoSaveTask.cancel();
        saveAllData();
    }

    // ═══════════════════════════════════════════
    //              CONFIGURATION
    // ═══════════════════════════════════════════

    private void loadSettings() {
        FileConfiguration cfg = plugin.getConfig();
        renderInterval = Math.max(1, cfg.getInt("auras.render-interval", 2));
        globalIntensity = cfg.getDouble("auras.global-intensity", 0.5);
        globalRadius = cfg.getDouble("auras.global-radius", 0.8);
        dustSize = (float) cfg.getDouble("auras.dust-size", 0.7);
        double rd = cfg.getDouble("auras.render-distance", 32);
        AURA_RENDER_DISTANCE_SQ = rd * rd;
        double lodMed = cfg.getDouble("auras.lod-medium-distance", 16);
        LOD_MEDIUM_DISTANCE_SQ = lodMed * lodMed;
        double lodFar = cfg.getDouble("auras.lod-far-distance", 25);
        LOD_FAR_DISTANCE_SQ = lodFar * lodFar;
        maxIntensityMult = cfg.getDouble("auras.max-intensity-multiplier", 2.0);
        maxRadiusMult = cfg.getDouble("auras.max-radius-multiplier", 1.5);
        streakEnabled = cfg.getBoolean("auras.streak.enabled", true);
        dynamicEnabled = cfg.getBoolean("auras.dynamic.enabled", true);
        dynNightIntensity = cfg.getDouble("auras.dynamic.night-intensity", 1.2);
        dynNightRadius = cfg.getDouble("auras.dynamic.night-radius", 1.1);
        dynStormSpeed = cfg.getDouble("auras.dynamic.storm-speed", 1.15);
        dynLowHealthSpeed = cfg.getDouble("auras.dynamic.low-health-speed", 1.2);
        dynLowHealthIntensity = cfg.getDouble("auras.dynamic.low-health-intensity", 1.3);
        plugin.getLogger().info("[Auras] Config: interval=" + renderInterval + ", intensity=" + globalIntensity + ", radius=" + globalRadius);
    }

    private void initializeAuraSounds() {
        auraSounds.put("fire", Sound.BLOCK_FIRE_AMBIENT);
        auraSounds.put("flame", Sound.BLOCK_FIRE_AMBIENT);
        auraSounds.put("lava", Sound.BLOCK_LAVA_AMBIENT);
        auraSounds.put("water", Sound.BLOCK_WATER_AMBIENT);
        auraSounds.put("oceanic", Sound.BLOCK_WATER_AMBIENT);
        auraSounds.put("ice", Sound.BLOCK_GLASS_BREAK);
        auraSounds.put("frost", Sound.ENTITY_SNOW_GOLEM_AMBIENT);
        auraSounds.put("snow", Sound.ENTITY_SNOW_GOLEM_AMBIENT);
        auraSounds.put("lightning", Sound.ENTITY_LIGHTNING_BOLT_THUNDER);
        auraSounds.put("storm", Sound.WEATHER_RAIN);
        auraSounds.put("nature", Sound.BLOCK_AZALEA_LEAVES_PLACE);
        auraSounds.put("cherry", Sound.BLOCK_CHERRY_LEAVES_PLACE);
        auraSounds.put("shadow", Sound.ENTITY_PHANTOM_AMBIENT);
        auraSounds.put("void", Sound.BLOCK_PORTAL_AMBIENT);
        auraSounds.put("holy", Sound.BLOCK_BEACON_AMBIENT);
        auraSounds.put("halo", Sound.BLOCK_BEACON_AMBIENT);
        auraSounds.put("angels", Sound.BLOCK_BEACON_AMBIENT);
        auraSounds.put("toxic", Sound.ENTITY_SLIME_SQUISH);
        auraSounds.put("blood", Sound.ENTITY_SLIME_SQUISH_SMALL);
        auraSounds.put("cosmic", Sound.BLOCK_END_PORTAL_FRAME_FILL);
        auraSounds.put("portal", Sound.BLOCK_PORTAL_AMBIENT);
        auraSounds.put("enchanted", Sound.BLOCK_ENCHANTMENT_TABLE_USE);
        auraSounds.put("music", Sound.BLOCK_NOTE_BLOCK_CHIME);
        auraSounds.put("dragon", Sound.ENTITY_ENDER_DRAGON_AMBIENT);
        auraSounds.put("phoenix", Sound.ENTITY_BLAZE_AMBIENT);
        auraSounds.put("demons", Sound.ENTITY_GHAST_AMBIENT);
        auraSounds.put("witch", Sound.ENTITY_WITCH_AMBIENT);
        auraSounds.put("galaxy", Sound.BLOCK_AMETHYST_BLOCK_CHIME);
        auraSounds.put("nebula", Sound.BLOCK_AMETHYST_BLOCK_CHIME);
        auraSounds.put("quantum", Sound.BLOCK_AMETHYST_CLUSTER_BREAK);
        auraSounds.put("matrix", Sound.BLOCK_SCULK_SENSOR_CLICKING);
        auraSounds.put("cyber", Sound.BLOCK_SCULK_SENSOR_CLICKING);
        auraSounds.put("volcanic", Sound.BLOCK_LAVA_POP);
        auraSounds.put("ancient", Sound.BLOCK_SCULK_SHRIEKER_SHRIEK);
        auraSounds.put("black_hole", Sound.BLOCK_PORTAL_AMBIENT);
        auraSounds.put("god", Sound.UI_TOAST_CHALLENGE_COMPLETE);
        auraSounds.put("aurora", Sound.BLOCK_AMETHYST_BLOCK_RESONATE);
        auraSounds.put("redstone", Sound.BLOCK_REDSTONE_TORCH_BURNOUT);
        auraSounds.put("energy", Sound.ENTITY_EXPERIENCE_ORB_PICKUP);
        auraSounds.put("totem", Sound.ITEM_TOTEM_USE);
        auraSounds.put("emerald", Sound.ENTITY_EXPERIENCE_ORB_PICKUP);
        auraSoundPitch.put("lightning", 2.0f);
        auraSoundPitch.put("dragon", 0.5f);
        auraSoundPitch.put("demons", 0.7f);
        auraSoundPitch.put("ancient", 0.5f);
        auraSoundPitch.put("god", 2.0f);
        auraSoundPitch.put("totem", 2.0f);
    }

    // ═══════════════════════════════════════════
    //          AURA PRICE + NAME DATA
    // ═══════════════════════════════════════════

    /** All 48 base aura IDs in order. */
    public static final String[] ALL_AURAS = {
        "fire","water","nature","ice","lightning","shadow","holy","toxic","cosmic","blood",
        "redstone","storm","flame","ink","lava","candy","snow","music","heart","emerald",
        "critical","totem","frost","cherry","portal","enchanted","cyber","witch",
        "rainbow_aura","energy","oceanic","halo","dna_aura","galaxy","phoenix","dragon","angels","demons",
        "nebula","quantum","celestial","void","aurora","matrix","volcanic","ancient","black_hole","god"
    };

    /** All 12 pattern IDs. */
    public static final String[] ALL_PATTERNS = {
        "falling","helix","tornado","shield","dna","vortex","circle","wings","pulse","orbit","radar","rainbow"
    };

    /** All 10 fusion IDs. */
    public static final String[] ALL_FUSIONS = {
        "plasma","frostbite","toxic_fire","holy_fire","dark_dragon",
        "void_storm","celestial_phoenix","cosmic_void","divine_matrix","omega_black_hole"
    };

    public String getAuraName(String auraId) {
        return switch (auraId.toLowerCase()) {
            case "fire" -> "§c§lFIRE AURA"; case "water" -> "§b§lWATER AURA";
            case "nature" -> "§a§lNATURE AURA"; case "ice" -> "§f§lICE AURA";
            case "lightning" -> "§e§lLIGHTNING AURA"; case "shadow" -> "§8§lSHADOW AURA";
            case "holy" -> "§f§lHOLY AURA"; case "toxic" -> "§2§lTOXIC AURA";
            case "cosmic" -> "§5§lCOSMIC AURA"; case "blood" -> "§4§lBLOOD AURA";
            case "redstone" -> "§c§lREDSTONE"; case "storm" -> "§9§lSTORM";
            case "flame" -> "§c§lFLAME"; case "ink" -> "§0§lINK";
            case "lava" -> "§6§lLAVA"; case "candy" -> "§d§lCANDY";
            case "snow" -> "§f§lSNOW"; case "music" -> "§b§lMUSIC";
            case "heart" -> "§d§lHEART"; case "emerald" -> "§a§lEMERALD";
            case "critical" -> "§c§lCRITICAL"; case "totem" -> "§e§lTOTEM";
            case "frost" -> "§b§lFROST"; case "cherry" -> "§d§lCHERRY";
            case "portal" -> "§5§lPORTAL"; case "enchanted" -> "§b§lENCHANTED";
            case "cyber" -> "§a§lCYBER"; case "witch" -> "§5§lWITCH";
            case "rainbow_aura" -> "§6§lRAINBOW"; case "energy" -> "§e§lENERGY";
            case "oceanic" -> "§3§lOCEANIC"; case "halo" -> "§f§lHALO";
            case "dna_aura" -> "§a§lDNA AURA"; case "galaxy" -> "§5§lGALAXY";
            case "phoenix" -> "§6§lPHOENIX"; case "dragon" -> "§4§lDRAGON";
            case "angels" -> "§f§lANGELS"; case "demons" -> "§4§lDEMONS";
            case "nebula" -> "§5§lNEBULA"; case "quantum" -> "§b§lQUANTUM";
            case "celestial" -> "§e§lCELESTIAL"; case "void" -> "§8§lVOID";
            case "aurora" -> "§b§lAURORA"; case "matrix" -> "§a§lMATRIX";
            case "volcanic" -> "§6§lVOLCANIC"; case "ancient" -> "§8§lANCIENT";
            case "black_hole" -> "§0§lBLACK HOLE"; case "god" -> "§6§l✦ GOD ✦";
            // Fusions
            case "plasma" -> "§b§lPLASMA"; case "frostbite" -> "§f§lFROSTBITE";
            case "toxic_fire" -> "§a§lTOXIC FIRE"; case "holy_fire" -> "§e§lHOLY FIRE";
            case "dark_dragon" -> "§5§lDARK DRAGON"; case "void_storm" -> "§8§lVOID STORM";
            case "celestial_phoenix" -> "§6§lCELESTIAL PHOENIX"; case "cosmic_void" -> "§5§lCOSMIC VOID";
            case "divine_matrix" -> "§d§lDIVINE MATRIX"; case "omega_black_hole" -> "§0§lOMEGA BLACK HOLE";
            default -> "§7§l" + auraId.toUpperCase();
        };
    }

    public int getAuraPrice(String auraId) {
        return switch (auraId.toLowerCase()) {
            case "redstone" -> 3000; case "nature" -> 3500; case "storm" -> 4000; case "flame" -> 4500; case "ink" -> 5000;
            case "lava" -> 6000; case "candy" -> 6500; case "snow" -> 7000; case "toxic" -> 7500; case "music" -> 8000;
            case "heart" -> 8500; case "emerald" -> 9000; case "critical" -> 10000;
            case "totem" -> 11000; case "frost" -> 12000; case "cherry" -> 12500;
            case "portal" -> 13000; case "enchanted" -> 13500; case "cyber" -> 14000; case "witch" -> 15000;
            case "rainbow_aura" -> 18000; case "energy" -> 20000; case "oceanic" -> 22000;
            case "halo" -> 24000; case "dna_aura" -> 25000; case "galaxy" -> 27000;
            case "phoenix" -> 28000; case "dragon" -> 30000; case "angels" -> 32000; case "demons" -> 35000;
            case "nebula" -> 40000; case "quantum" -> 45000; case "celestial" -> 50000;
            case "void" -> 55000; case "aurora" -> 60000; case "matrix" -> 65000;
            case "volcanic" -> 70000; case "ancient" -> 80000; case "black_hole" -> 90000; case "god" -> 100000;
            case "fire" -> 5000; case "water" -> 6000; case "ice" -> 8000;
            case "lightning" -> 10000; case "shadow" -> 12000; case "holy" -> 15000;
            case "cosmic" -> 25000; case "blood" -> 30000;
            // Fusions
            case "plasma" -> 20000; case "frostbite" -> 18000; case "toxic_fire" -> 22000;
            case "holy_fire" -> 25000; case "dark_dragon" -> 30000; case "void_storm" -> 50000;
            case "celestial_phoenix" -> 80000; case "cosmic_void" -> 100000;
            case "divine_matrix" -> 120000; case "omega_black_hole" -> 150000;
            default -> 5000;
        };
    }

    public int getPatternPrice(String patternId) {
        return switch (patternId.toLowerCase()) {
            case "falling" -> 0; case "circle" -> 1500; case "helix" -> 2000; case "shield" -> 2500;
            case "radar" -> 3000; case "tornado" -> 3000; case "pulse" -> 3500;
            case "vortex" -> 4000; case "orbit" -> 4500; case "rainbow" -> 4500;
            case "dna" -> 5000; case "wings" -> 6000;
            default -> 2000;
        };
    }

    public String getPatternName(String patternId) {
        return switch (patternId.toLowerCase()) {
            case "falling" -> "§a§lCAYENDO"; case "helix" -> "§b§lHELIX"; case "tornado" -> "§c§lTORNADO";
            case "shield" -> "§e§lESCUDO"; case "dna" -> "§a§lADN"; case "vortex" -> "§d§lVÓRTICE";
            case "circle" -> "§f§lCÍRCULO"; case "wings" -> "§6§lALAS"; case "pulse" -> "§c§lPULSO";
            case "orbit" -> "§b§lÓRBITA"; case "radar" -> "§a§lRADAR"; case "rainbow" -> "§6§lRAINBOW";
            default -> "§7§l" + patternId.toUpperCase();
        };
    }

    public String getAuraTier(String auraId) {
        int price = getAuraPrice(auraId);
        if (price <= 5000) return "BASIC";
        if (price <= 15000) return "PREMIUM";
        if (price <= 35000) return "LEGENDARY";
        return "SPECIAL";
    }

    // ═══════════════════════════════════════════
    //              PERSISTENCE (YML)
    // ═══════════════════════════════════════════

    private void initPlayerDataFile() {
        if (playerDataFile == null) {
            playerDataFile = new File(plugin.getDataFolder(), "auras_players.yml");
            if (!playerDataFile.exists()) {
                try { playerDataFile.createNewFile(); } catch (Exception e) { plugin.getLogger().log(Level.SEVERE, "Could not create auras_players.yml", e); }
            }
            playerDataConfig = YamlConfiguration.loadConfiguration(playerDataFile);
        }
    }

    public void loadPlayerData(UUID uuid) {
        initPlayerDataFile();
        String path = "players." + uuid;
        if (!playerDataConfig.contains(path)) return;

        // Unlocked auras
        List<String> auras = playerDataConfig.getStringList(path + ".unlocked-auras");
        if (!auras.isEmpty()) unlockedAuras.put(uuid, ConcurrentHashMap.newKeySet());
        unlockedAuras.getOrDefault(uuid, ConcurrentHashMap.newKeySet()).addAll(auras);

        // Unlocked patterns
        if (playerDataConfig.contains(path + ".unlocked-patterns")) {
            var patterns = new ConcurrentHashMap<String, Set<String>>();
            for (String auraId : playerDataConfig.getConfigurationSection(path + ".unlocked-patterns").getKeys(false)) {
                Set<String> set = ConcurrentHashMap.newKeySet();
                set.addAll(playerDataConfig.getStringList(path + ".unlocked-patterns." + auraId));
                patterns.put(auraId, set);
            }
            unlockedPatterns.put(uuid, patterns);
        }

        // Unlocked slots
        List<String> slots = playerDataConfig.getStringList(path + ".unlocked-slots");
        if (!slots.isEmpty()) {
            Set<String> set = ConcurrentHashMap.newKeySet();
            set.addAll(slots);
            unlockedSlots.put(uuid, set);
        }
        ensurePrimarySlot(uuid);

        // Active slots
        if (playerDataConfig.contains(path + ".active-slots")) {
            var slotMap = new ConcurrentHashMap<String, ActiveAura>();
            for (String slotName : playerDataConfig.getConfigurationSection(path + ".active-slots").getKeys(false)) {
                String auraId = playerDataConfig.getString(path + ".active-slots." + slotName + ".aura");
                String patternId = playerDataConfig.getString(path + ".active-slots." + slotName + ".pattern", "falling");
                if (auraId != null) slotMap.put(slotName, new ActiveAura(auraId, patternId));
            }
            playerSlots.put(uuid, slotMap);
        }

        // Legacy active aura
        String legacyAura = playerDataConfig.getString(path + ".active-aura");
        String legacyPattern = playerDataConfig.getString(path + ".active-pattern", "falling");
        if (legacyAura != null) activeAuras.put(uuid, new ActiveAura(legacyAura, legacyPattern));

        // Aura configs
        if (playerDataConfig.contains(path + ".aura-configs")) {
            var configs = new ConcurrentHashMap<String, AuraConfig>();
            for (String auraId : playerDataConfig.getConfigurationSection(path + ".aura-configs").getKeys(false)) {
                double i = playerDataConfig.getDouble(path + ".aura-configs." + auraId + ".intensity", 1.0);
                double s = playerDataConfig.getDouble(path + ".aura-configs." + auraId + ".speed", 1.0);
                double r = playerDataConfig.getDouble(path + ".aura-configs." + auraId + ".radius", 1.0);
                String b = playerDataConfig.getString(path + ".aura-configs." + auraId + ".blendMode", "NORMAL");
                configs.put(auraId, new AuraConfig(i, s, r, b));
            }
            playerConfigs.put(uuid, configs);
        }

        if (playerDataConfig.contains(path + ".sound-enabled"))
            soundEnabled.put(uuid, playerDataConfig.getBoolean(path + ".sound-enabled", true));
    }

    public void savePlayerData(UUID uuid) {
        initPlayerDataFile();
        String path = "players." + uuid;

        Set<String> auras = unlockedAuras.get(uuid);
        if (auras != null && !auras.isEmpty()) playerDataConfig.set(path + ".unlocked-auras", new ArrayList<>(auras));

        Map<String, Set<String>> patterns = unlockedPatterns.get(uuid);
        if (patterns != null) patterns.forEach((aid, pats) -> playerDataConfig.set(path + ".unlocked-patterns." + aid, new ArrayList<>(pats)));

        Set<String> slots = unlockedSlots.get(uuid);
        if (slots != null && !slots.isEmpty()) playerDataConfig.set(path + ".unlocked-slots", new ArrayList<>(slots));

        Map<String, ActiveAura> slotMap = playerSlots.get(uuid);
        if (slotMap != null) slotMap.forEach((sn, aa) -> {
            playerDataConfig.set(path + ".active-slots." + sn + ".aura", aa.auraId());
            playerDataConfig.set(path + ".active-slots." + sn + ".pattern", aa.patternId());
        });

        ActiveAura legacy = activeAuras.get(uuid);
        if (legacy != null) {
            playerDataConfig.set(path + ".active-aura", legacy.auraId());
            playerDataConfig.set(path + ".active-pattern", legacy.patternId());
        }

        Map<String, AuraConfig> configs = playerConfigs.get(uuid);
        if (configs != null) configs.forEach((aid, cfg) -> {
            String cp = path + ".aura-configs." + aid;
            playerDataConfig.set(cp + ".intensity", cfg.intensity());
            playerDataConfig.set(cp + ".speed", cfg.speed());
            playerDataConfig.set(cp + ".radius", cfg.radius());
            playerDataConfig.set(cp + ".blendMode", cfg.blendMode());
        });

        if (soundEnabled.containsKey(uuid)) playerDataConfig.set(path + ".sound-enabled", soundEnabled.get(uuid));

        try { playerDataConfig.save(playerDataFile); } catch (Exception e) {
            plugin.getLogger().warning("Error saving aura data: " + e.getMessage());
        }
    }

    public void saveAllData() {
        Set<UUID> all = new HashSet<>(unlockedAuras.keySet());
        all.addAll(playerSlots.keySet());
        all.addAll(activeAuras.keySet());
        for (UUID uuid : all) savePlayerData(uuid);
    }

    public void cleanupPlayer(UUID uuid) {
        savePlayerData(uuid);
        playerKillStreaks.remove(uuid); streakTier.remove(uuid); soundEnabled.remove(uuid);
        lastKillEffect.remove(uuid); lastLocation.remove(uuid); lastAttackBurst.remove(uuid);
        lastJumpBurst.remove(uuid); unlockedAuras.remove(uuid); unlockedPatterns.remove(uuid);
        unlockedSlots.remove(uuid); playerSlots.remove(uuid); playerConfigs.remove(uuid);
        activeAuras.remove(uuid);
        guiManager.cleanupPlayer(uuid);
    }

    // ═══════════════════════════════════════════
    //              SLOTS
    // ═══════════════════════════════════════════

    public void ensurePrimarySlot(UUID uuid) {
        unlockedSlots.computeIfAbsent(uuid, k -> ConcurrentHashMap.newKeySet()).add("PRIMARY");
    }

    public boolean hasSlot(UUID uuid, String slot) {
        ensurePrimarySlot(uuid);
        return unlockedSlots.getOrDefault(uuid, Set.of()).contains(slot);
    }

    public void unlockSlot(UUID uuid, String slot) {
        unlockedSlots.computeIfAbsent(uuid, k -> ConcurrentHashMap.newKeySet()).add(slot);
    }

    // ═══════════════════════════════════════════
    //          PURCHASE + ACTIVATE
    // ═══════════════════════════════════════════

    public boolean hasAura(UUID uuid, String auraId) {
        Set<String> s = unlockedAuras.get(uuid);
        return s != null && s.contains(auraId);
    }

    public boolean hasPattern(UUID uuid, String auraId, String patternId) {
        var m = unlockedPatterns.get(uuid);
        if (m == null) return false;
        var s = m.get(auraId);
        return s != null && s.contains(patternId);
    }

    public boolean isAuraActive(UUID uuid, String auraId) {
        ActiveAura a = activeAuras.get(uuid);
        return a != null && a.auraId().equals(auraId);
    }

    public boolean isPatternActive(UUID uuid, String auraId, String patternId) {
        ActiveAura a = activeAuras.get(uuid);
        return a != null && a.auraId().equals(auraId) && a.patternId().equals(patternId);
    }

    public void unlockAura(UUID uuid, String auraId) {
        unlockedAuras.computeIfAbsent(uuid, k -> ConcurrentHashMap.newKeySet()).add(auraId);
        unlockedPatterns.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>())
            .computeIfAbsent(auraId, k -> ConcurrentHashMap.newKeySet()).add("falling");
    }

    public void unlockPattern(UUID uuid, String auraId, String patternId) {
        unlockedPatterns.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>())
            .computeIfAbsent(auraId, k -> ConcurrentHashMap.newKeySet()).add(patternId);
    }

    public boolean purchaseAura(Player player, String auraId, int price) {
        UUID uuid = player.getUniqueId();
        if (hasAura(uuid, auraId)) { player.sendMessage("§c¡Ya tienes esta aura!"); return false; }
        var profile = plugin.getCore().getProfileManager().getProfile(uuid);
        if (profile == null || profile.getCoins() < price) {
            player.sendMessage("§c¡No tienes suficientes monedas! Necesitas §e" + price + " §cmonedas.");
            return false;
        }
        profile.addCoins(-price);
        unlockAura(uuid, auraId);
        player.sendMessage("§a✓ ¡Aura comprada! §f" + getAuraName(auraId) + " §7(-" + price + " monedas)");
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 2f);
        return true;
    }

    public boolean purchasePattern(Player player, String auraId, String patternId, int price) {
        UUID uuid = player.getUniqueId();
        if (!hasAura(uuid, auraId)) { player.sendMessage("§c¡Debes comprar la aura primero!"); return false; }
        if (hasPattern(uuid, auraId, patternId)) { player.sendMessage("§c¡Ya tienes este patrón!"); return false; }
        var profile = plugin.getCore().getProfileManager().getProfile(uuid);
        if (profile == null || profile.getCoins() < price) {
            player.sendMessage("§c¡No tienes suficientes monedas! Necesitas §e" + price + " §cmonedas.");
            return false;
        }
        profile.addCoins(-price);
        unlockPattern(uuid, auraId, patternId);
        player.sendMessage("§a✓ ¡Patrón comprado! §f" + getPatternName(patternId) + " §7(-" + price + " monedas)");
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 2f);
        return true;
    }

    public void activateAura(Player player, String auraId, String patternId) {
        UUID uuid = player.getUniqueId();
        if (!hasAura(uuid, auraId)) return;
        if (patternId != null && !patternId.equals("falling") && !hasPattern(uuid, auraId, patternId)) return;
        String pat = patternId != null ? patternId : "falling";
        ensurePrimarySlot(uuid);
        playerSlots.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>()).put("PRIMARY", new ActiveAura(auraId, pat));
        activeAuras.put(uuid, new ActiveAura(auraId, pat));
        player.sendMessage("§a✓ Aura activada: §f" + getAuraName(auraId) + " §7(" + pat + ")");
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 2f);
    }

    public void deactivateAura(Player player) {
        activeAuras.remove(player.getUniqueId());
        playerSlots.remove(player.getUniqueId());
        player.sendMessage("§c✗ Aura desactivada");
    }

    // ═══════════════════════════════════════════
    //          RENDERING ENGINE
    // ═══════════════════════════════════════════

    private void startAuraTask() {
        auraTask = new BukkitRunnable() {
            private int tick = 0;
            @Override
            public void run() {
                tick++;
                // TPS tracking every 20 ticks
                if (tick % 20 == 0) {
                    long now = System.currentTimeMillis();
                    double elapsed = (now - lastTickTime) / 1000.0;
                    lastTickTime = now;
                    estimatedTPS = Math.min(20.0, (20.0 * renderInterval) / elapsed);
                    qualityLevel = estimatedTPS < 14 ? 0 : estimatedTPS < 17 ? 1 : 2;
                }
                if (qualityLevel == 0 && tick % 2 != 0) return;
                List<Player> online = new ArrayList<>(Bukkit.getOnlinePlayers());
                for (Player player : online) {
                    UUID uuid = player.getUniqueId();
                    if (tick % 60 == 0) playAmbientSounds(player);
                    var slots = playerSlots.get(uuid);
                    if (slots != null && !slots.isEmpty()) {
                        int idx = 0;
                        for (var entry : slots.entrySet()) {
                            if (entry.getValue() != null) renderForNearby(player, entry.getValue(), tick, idx++, online);
                        }
                    } else {
                        ActiveAura a = activeAuras.get(uuid);
                        if (a != null) renderForNearby(player, a, tick, 0, online);
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, renderInterval);
    }

    private void startAutoSaveTask() {
        autoSaveTask = new BukkitRunnable() {
            @Override public void run() { saveAllData(); }
        }.runTaskTimer(plugin, 6000L, 6000L);
    }

    private void renderForNearby(Player owner, ActiveAura aura, int tick, int slotIdx, List<Player> online) {
        Location ownerLoc = owner.getLocation();
        List<Player> viewers = new ArrayList<>();
        viewers.add(owner);
        for (Player v : online) {
            if (v.equals(owner) || !v.getWorld().equals(owner.getWorld())) continue;
            if (v.getLocation().distanceSquared(ownerLoc) <= AURA_RENDER_DISTANCE_SQ) viewers.add(v);
        }
        for (Player viewer : viewers) {
            int viewerLOD = viewer.equals(owner) ? 2 :
                viewer.getLocation().distanceSquared(ownerLoc) > LOD_FAR_DISTANCE_SQ ? 0 :
                viewer.getLocation().distanceSquared(ownerLoc) > LOD_MEDIUM_DISTANCE_SQ ? 1 : 2;
            viewerLOD = Math.min(viewerLOD, qualityLevel);
            if (viewerLOD == 0 && tick % 4 != 0) continue;
            if (viewerLOD == 1 && tick % 2 != 0) continue;
            currentRenderTarget = viewer;
            currentLOD = viewerLOD;
            renderAuraWithOffset(owner, aura, tick, slotIdx);
        }
        currentRenderTarget = null;
        patternRenderer.setContext(null, 2, Color.WHITE, dustSize);
    }

    private void renderAuraWithOffset(Player player, ActiveAura aura, int tick, int slotIndex) {
        Location loc = player.getLocation().add(0, 1 + slotIndex * 0.5, 0);
        UUID uuid = player.getUniqueId();

        String[] fusion = getFusionComponents(aura.auraId());
        if (fusion != null) {
            int st = streakTier.getOrDefault(uuid, 0);
            double si = getStreakIntensityMult(st), sr = getStreakRadiusMult(st);
            DynamicMods dm = calcDynamic(player);
            currentAuraColor = getAuraColor(fusion[0]);
            patternRenderer.setContext(currentRenderTarget, currentLOD, currentAuraColor, dustSize);
            renderWithMods(loc, getAuraParticle(fusion[0]), fusion[0], aura.patternId(), uuid, tick, si, sr, dm);
            currentAuraColor = getAuraColor(fusion[1]);
            patternRenderer.setContext(currentRenderTarget, currentLOD, currentAuraColor, dustSize);
            renderWithMods(loc, getAuraParticle(fusion[1]), fusion[1], aura.patternId(), uuid, tick + 10, si * 0.7, sr, dm);
            if (st >= 3 && tick % 4 == 0) renderStreakAura(loc, st, tick);
            return;
        }

        currentAuraColor = getAuraColor(aura.auraId());
        int st = streakTier.getOrDefault(uuid, 0);
        double si = getStreakIntensityMult(st), sr = getStreakRadiusMult(st);
        DynamicMods dm = calcDynamic(player);
        if (st >= 3 && tick % 4 == 0) renderStreakAura(loc, st, tick);
        patternRenderer.setContext(currentRenderTarget, currentLOD, currentAuraColor, dustSize);
        renderWithMods(loc, getAuraParticle(aura.auraId()), aura.auraId(), aura.patternId(), uuid, tick, si, sr, dm);
    }

    private void renderWithMods(Location loc, Particle particle, String auraId, String patternId,
                                UUID uuid, int tick, double siMult, double srMult, DynamicMods dm) {
        AuraConfig cfg = new AuraConfig();
        if (uuid != null && playerConfigs.containsKey(uuid))
            cfg = playerConfigs.get(uuid).getOrDefault(auraId, new AuraConfig());
        double fi = Math.min(cfg.intensity() * globalIntensity * siMult * dm.intensity, maxIntensityMult);
        double fr = Math.min(cfg.radius() * globalRadius * srMult * dm.radius, maxRadiusMult);
        AuraConfig finalCfg = new AuraConfig(fi, cfg.speed() * dm.speed, fr, cfg.blendMode());
        if (dm.overrideParticle != null) particle = dm.overrideParticle;
        patternRenderer.render(patternId, loc, particle, (int)(tick * finalCfg.speed()), finalCfg);
    }

    // ═══════════════════════════════════════════
    //          PARTICLE + COLOR MAPPING
    // ═══════════════════════════════════════════

    public Particle getAuraParticle(String auraId) {
        return switch (auraId.toLowerCase()) {
            case "redstone","candy","emerald","frost","rainbow","dna","void","shield","radar","corona","creeper",
                 "galactic","ice","shadow","blood","plasma","frostbite","holy_fire","toxic_fire","dark_dragon",
                 "void_storm","celestial_phoenix","cosmic_void","divine_matrix","omega_black_hole",
                 "rainbow_aura","dna_aura","dragon","nebula","aurora","matrix" -> Particle.DUST;
            case "nature" -> Particle.HAPPY_VILLAGER;
            case "storm","water" -> Particle.DRIPPING_WATER;
            case "flame","fire","phoenix" -> Particle.FLAME;
            case "ink" -> Particle.SQUID_INK;
            case "lava","volcanic" -> Particle.DRIPPING_LAVA;
            case "snow" -> Particle.SNOWFLAKE;
            case "toxic" -> Particle.ITEM_SLIME;
            case "music" -> Particle.NOTE;
            case "heart" -> Particle.HEART;
            case "critical" -> Particle.CRIT;
            case "totem" -> Particle.TOTEM_OF_UNDYING;
            case "cherry" -> Particle.CHERRY_LEAVES;
            case "portal","cosmic","galaxy" -> Particle.PORTAL;
            case "enchanted","ancient" -> Particle.ENCHANT;
            case "cyber","lightning","quantum" -> Particle.ELECTRIC_SPARK;
            case "witch" -> Particle.WITCH;
            case "energy","halo","angels","celestial","holy","god" -> Particle.END_ROD;
            case "oceanic" -> Particle.BUBBLE_POP;
            case "black_hole" -> Particle.SMOKE;
            case "demons" -> Particle.LAVA;
            default -> Particle.DUST;
        };
    }

    public Color getAuraColor(String auraId) {
        return switch (auraId.toLowerCase()) {
            case "redstone" -> Color.fromRGB(255, 50, 50); case "nature" -> Color.fromRGB(0, 200, 0);
            case "storm" -> Color.fromRGB(100, 150, 255); case "flame" -> Color.fromRGB(255, 120, 0);
            case "ink" -> Color.fromRGB(20, 20, 20); case "lava" -> Color.fromRGB(255, 80, 0);
            case "candy" -> Color.fromRGB(255, 105, 180); case "snow" -> Color.fromRGB(220, 240, 255);
            case "toxic" -> Color.fromRGB(80, 255, 20); case "music" -> Color.fromRGB(0, 255, 127);
            case "heart" -> Color.fromRGB(255, 50, 100); case "emerald" -> Color.fromRGB(0, 180, 80);
            case "critical" -> Color.fromRGB(255, 200, 0); case "totem" -> Color.fromRGB(255, 215, 0);
            case "frost" -> Color.fromRGB(100, 200, 255); case "cherry" -> Color.fromRGB(255, 150, 180);
            case "portal" -> Color.fromRGB(128, 0, 255); case "enchanted" -> Color.fromRGB(130, 100, 255);
            case "cyber" -> Color.fromRGB(0, 255, 255); case "witch" -> Color.fromRGB(150, 0, 200);
            case "rainbow","rainbow_aura" -> Color.fromRGB(255, 100, 50); case "energy" -> Color.fromRGB(255, 255, 150);
            case "oceanic" -> Color.fromRGB(0, 100, 200); case "halo" -> Color.fromRGB(255, 255, 200);
            case "fire" -> Color.fromRGB(255, 100, 0); case "water" -> Color.fromRGB(50, 100, 255);
            case "ice" -> Color.fromRGB(150, 220, 255); case "lightning" -> Color.fromRGB(255, 255, 80);
            case "shadow" -> Color.fromRGB(40, 40, 50); case "holy" -> Color.fromRGB(255, 255, 200);
            case "cosmic" -> Color.fromRGB(180, 0, 255); case "blood" -> Color.fromRGB(130, 0, 0);
            case "dna","dna_aura" -> Color.fromRGB(0, 255, 100);
            case "void" -> Color.fromRGB(30, 0, 60); case "black_hole" -> Color.fromRGB(10, 0, 20);
            case "galaxy" -> Color.fromRGB(100, 0, 200); case "phoenix" -> Color.fromRGB(255, 120, 0);
            case "dragon" -> Color.fromRGB(150, 0, 200); case "angels" -> Color.fromRGB(255, 255, 230);
            case "demons" -> Color.fromRGB(150, 0, 0); case "nebula" -> Color.fromRGB(200, 50, 255);
            case "quantum" -> Color.fromRGB(0, 200, 255); case "celestial" -> Color.fromRGB(255, 230, 100);
            case "aurora" -> Color.fromRGB(50, 255, 200); case "matrix" -> Color.fromRGB(0, 255, 65);
            case "volcanic" -> Color.fromRGB(255, 100, 0); case "ancient" -> Color.fromRGB(180, 150, 100);
            case "god" -> Color.fromRGB(255, 215, 0);
            case "plasma" -> Color.fromRGB(0, 200, 255); case "frostbite" -> Color.fromRGB(150, 200, 255);
            case "holy_fire" -> Color.fromRGB(255, 200, 50); case "toxic_fire" -> Color.fromRGB(200, 255, 0);
            case "dark_dragon" -> Color.fromRGB(80, 0, 100); case "void_storm" -> Color.fromRGB(50, 0, 150);
            case "celestial_phoenix" -> Color.fromRGB(255, 150, 50); case "cosmic_void" -> Color.fromRGB(100, 0, 180);
            case "divine_matrix" -> Color.fromRGB(200, 200, 255); case "omega_black_hole" -> Color.fromRGB(20, 0, 40);
            default -> Color.fromRGB(255, 50, 50);
        };
    }

    public String[] getFusionComponents(String auraId) {
        return switch (auraId) {
            case "plasma" -> new String[]{"lightning", "water"};
            case "frostbite" -> new String[]{"ice", "shadow"};
            case "toxic_fire" -> new String[]{"toxic", "fire"};
            case "holy_fire" -> new String[]{"holy", "fire"};
            case "dark_dragon" -> new String[]{"shadow", "dragon"};
            case "void_storm" -> new String[]{"void", "lightning"};
            case "celestial_phoenix" -> new String[]{"celestial", "phoenix"};
            case "cosmic_void" -> new String[]{"cosmic", "void"};
            case "divine_matrix" -> new String[]{"holy", "matrix"};
            case "omega_black_hole" -> new String[]{"black_hole", "god"};
            default -> null;
        };
    }

    // ═══════════════════════════════════════════
    //          STREAK REACTIVE SYSTEM
    // ═══════════════════════════════════════════

    public void registerKill(Player killer) {
        UUID uuid = killer.getUniqueId();
        int streak = playerKillStreaks.merge(uuid, 1, Integer::sum);
        int oldTier = streakTier.getOrDefault(uuid, 0);
        int newTier = streak >= 20 ? 4 : streak >= 10 ? 3 : streak >= 5 ? 2 : streak >= 3 ? 1 : 0;
        streakTier.put(uuid, newTier);
        if (newTier > oldTier) notifyStreakTierUp(killer, newTier, streak);
    }

    public void resetStreak(Player victim) {
        UUID uuid = victim.getUniqueId();
        int lost = playerKillStreaks.getOrDefault(uuid, 0);
        playerKillStreaks.put(uuid, 0);
        streakTier.put(uuid, 0);
        if (lost >= 3) victim.sendMessage("§c§l✗ §cRacha de aura perdida §7(" + lost + " kills)");
    }

    private void notifyStreakTierUp(Player player, int tier, int kills) {
        String name = switch (tier) { case 1 -> "§e§l⚡ WARMING ⚡"; case 2 -> "§6§l🔥 BLAZING 🔥"; case 3 -> "§c§l☠ INFERNO ☠"; case 4 -> "§d§l✧ GODLIKE ✧"; default -> ""; };
        Sound s = switch (tier) { case 1 -> Sound.ENTITY_BLAZE_SHOOT; case 2 -> Sound.ENTITY_BLAZE_AMBIENT; case 3 -> Sound.ENTITY_ENDER_DRAGON_GROWL; default -> Sound.UI_TOAST_CHALLENGE_COMPLETE; };
        player.sendTitle(name, "§7Tu aura se intensifica §f(" + kills + " kills)", 5, tier >= 4 ? 60 : 30, 10);
        player.playSound(player.getLocation(), s, 1.0f, 1.0f);
        if (tier >= 3) Bukkit.broadcastMessage("§6§l⚔ AURA §8» " + name + " §f" + player.getName() + " §7(" + kills + " kills)");
    }

    private double getStreakIntensityMult(int tier) {
        return streakEnabled && tier >= 0 && tier < streakIntensityArr.length ? streakIntensityArr[tier] : 1.0;
    }
    private double getStreakRadiusMult(int tier) {
        return streakEnabled && tier >= 0 && tier < streakRadiusArr.length ? streakRadiusArr[tier] : 1.0;
    }

    private void renderStreakAura(Location loc, int tier, int tick) {
        World world = loc.getWorld();
        if (tier >= 3) {
            double angle = tick * 0.3;
            for (int i = 0; i < 4; i++) {
                double a = angle + (i * Math.PI / 2);
                patternRenderer.spawnParticle(world, Particle.FLAME, loc.clone().add(Math.cos(a) * 1.2, -0.5, Math.sin(a) * 1.2), 1, 0, 0.05, 0, 0);
                patternRenderer.spawnParticle(world, Particle.SMOKE, loc.clone().add(Math.cos(a) * 1.2, -0.5, Math.sin(a) * 1.2), 1, 0, 0.02, 0, 0);
            }
        }
        if (tier >= 4) {
            for (double y = -1; y < 2; y += 0.5) {
                double wobble = Math.sin(tick * 0.1 + y) * 0.15;
                patternRenderer.spawnParticle(world, Particle.END_ROD, loc.clone().add(wobble, y, wobble), 1, 0, 0.05, 0, 0);
            }
            double haloAngle = tick * 0.5;
            for (int i = 0; i < 6; i++) {
                double a = haloAngle + (i * Math.PI / 3);
                Particle.DustOptions gold = new Particle.DustOptions(Color.fromRGB(255, 215, 0), 0.8f);
                loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(Math.cos(a) * 0.4, 1.5, Math.sin(a) * 0.4), 1, 0, 0, 0, 0, gold);
            }
        }
    }

    // ═══════════════════════════════════════════
    //          DYNAMIC AURAS
    // ═══════════════════════════════════════════

    private DynamicMods calcDynamic(Player player) {
        DynamicMods m = new DynamicMods();
        if (!dynamicEnabled) return m;
        World world = player.getWorld();
        long time = world.getTime();
        boolean isNight = time >= 13000 && time <= 23000;
        if (isNight) { m.intensity *= dynNightIntensity; m.radius *= dynNightRadius; }
        if (world.hasStorm()) { m.speed *= dynStormSpeed; }
        double hp = player.getHealth() / player.getMaxHealth();
        if (hp <= 0.25) { m.speed *= dynLowHealthSpeed; m.intensity *= dynLowHealthIntensity; }
        return m;
    }

    private static class DynamicMods {
        double intensity = 1.0, speed = 1.0, radius = 1.0;
        Particle overrideParticle = null;
    }

    // ═══════════════════════════════════════════
    //          AMBIENT SOUNDS
    // ═══════════════════════════════════════════

    private void playAmbientSounds(Player player) {
        UUID uuid = player.getUniqueId();
        if (!soundEnabled.getOrDefault(uuid, true)) return;
        ActiveAura aura = getActiveAuraForPlayer(player);
        if (aura == null) return;
        Sound sound = auraSounds.get(aura.auraId().toLowerCase());
        if (sound == null) return;
        float pitch = auraSoundPitch.getOrDefault(aura.auraId().toLowerCase(), 1.0f);
        float volume = 0.15f;
        int tier = streakTier.getOrDefault(uuid, 0);
        if (tier >= 2) volume = 0.25f;
        if (tier >= 4) volume = 0.35f;
        player.playSound(player.getLocation(), sound, volume, pitch);
    }

    public void toggleSound(Player player) {
        UUID uuid = player.getUniqueId();
        boolean current = soundEnabled.getOrDefault(uuid, true);
        soundEnabled.put(uuid, !current);
        player.sendMessage(!current ? "§a§l✓ §aSonidos de aura activados" : "§c§l✗ §cSonidos de aura desactivados");
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0f, 1.0f);
    }

    private ActiveAura getActiveAuraForPlayer(Player player) {
        UUID uuid = player.getUniqueId();
        var slots = playerSlots.get(uuid);
        if (slots != null && !slots.isEmpty()) {
            ActiveAura primary = slots.get("PRIMARY");
            if (primary != null) return primary;
            return slots.values().iterator().next();
        }
        return activeAuras.get(uuid);
    }

    // ═══════════════════════════════════════════
    //          REACTIVE TRIGGERS
    // ═══════════════════════════════════════════

    public void triggerAttackBurst(Player attacker) {
        UUID uuid = attacker.getUniqueId();
        ActiveAura aura = activeAuras.get(uuid);
        if (aura == null) return;
        long now = System.currentTimeMillis();
        if (lastAttackBurst.getOrDefault(uuid, 0L) + 500 > now) return;
        lastAttackBurst.put(uuid, now);
        Particle p = getAuraParticle(aura.auraId());
        Location loc = attacker.getLocation().add(0, 1, 0);
        int tier = streakTier.getOrDefault(uuid, 0);
        int count = 12 + (tier * 4);
        double radius = 0.5 + (tier * 0.1);
        currentAuraColor = getAuraColor(aura.auraId());
        patternRenderer.setContext(null, 2, currentAuraColor, dustSize);
        for (int i = 0; i < count; i++) {
            double angle = 2 * Math.PI * i / count;
            patternRenderer.spawnParticle(loc.getWorld(), p, loc, 1, Math.cos(angle) * radius, 0, Math.sin(angle) * radius, 0.15);
        }
        attacker.playSound(loc, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 0.5f, 1.5f);
        if (tier >= 2) attacker.playSound(loc, Sound.ENTITY_BLAZE_SHOOT, 0.3f, 1.5f + tier * 0.2f);
    }

    public void triggerDamageBurst(Player victim) {
        UUID uuid = victim.getUniqueId();
        ActiveAura aura = activeAuras.get(uuid);
        if (aura == null) return;
        currentAuraColor = getAuraColor(aura.auraId());
        patternRenderer.setContext(null, 2, currentAuraColor, dustSize);
        Location loc = victim.getLocation().add(0, 1, 0);
        patternRenderer.spawnParticle(loc.getWorld(), getAuraParticle(aura.auraId()), loc, 20, 0.3, 0.5, 0.3, 0.1);
    }

    public void triggerKillEffect(Player killer, Player victim) {
        UUID uuid = killer.getUniqueId();
        ActiveAura aura = getActiveAuraForPlayer(killer);
        if (aura == null) return;
        long now = System.currentTimeMillis();
        if (lastKillEffect.getOrDefault(uuid, 0L) + 1000 > now) return;
        lastKillEffect.put(uuid, now);
        Particle p = getAuraParticle(aura.auraId());
        currentAuraColor = getAuraColor(aura.auraId());
        Location vLoc = victim.getLocation().add(0, 1, 0);
        Location kLoc = killer.getLocation().add(0, 1, 0);
        World world = vLoc.getWorld();
        // Explosion
        for (int i = 0; i < 30; i++) {
            patternRenderer.spawnParticle(world, p, vLoc, 1, (Math.random()-0.5)*2, Math.random()*2, (Math.random()-0.5)*2, 0.2);
        }
        // Absorption line
        new BukkitRunnable() {
            int step = 0;
            @Override public void run() {
                if (step >= 10) {
                    for (int i = 0; i < 15; i++) {
                        double a = 2 * Math.PI * i / 15;
                        patternRenderer.spawnParticle(world, p, kLoc, 1, Math.cos(a)*0.8, 0.5, Math.sin(a)*0.8, 0.1);
                    }
                    cancel(); return;
                }
                double t = step / 10.0;
                Location path = new Location(world,
                    vLoc.getX()+(kLoc.getX()-vLoc.getX())*t,
                    vLoc.getY()+(kLoc.getY()-vLoc.getY())*t+Math.sin(t*Math.PI)*1.5,
                    vLoc.getZ()+(kLoc.getZ()-vLoc.getZ())*t);
                patternRenderer.spawnParticle(world, p, path, 3, 0.1, 0.1, 0.1, 0.02);
                step++;
            }
        }.runTaskTimer(plugin, 0L, 2L);
        killer.playSound(kLoc, Sound.ENTITY_ENDER_DRAGON_FLAP, 0.7f, 1.5f);
        int tier = streakTier.getOrDefault(uuid, 0);
        if (tier >= 3) killer.playSound(kLoc, Sound.ENTITY_WITHER_SPAWN, 0.3f, 2.0f);
    }

    // ═══════════════════════════════════════════
    //          GUI DELEGATION
    // ═══════════════════════════════════════════

    public void openAurasGUI(Player player) { guiManager.openTiersGUI(player); }
    public void openPatternsGUI(Player player, String auraId) { guiManager.openPatternsGUI(player, auraId); }
    public void openFusionsGUI(Player player) { guiManager.openFusionsGUI(player); }
    public void openSlotsGUI(Player player) { guiManager.openSlotsGUI(player); }
    public AuraGUIManager getGUIManager() { return guiManager; }

    // ═══════════════════════════════════════════
    //          QUERIES
    // ═══════════════════════════════════════════

    public Set<String> getUnlockedAuras(UUID uuid) { return unlockedAuras.getOrDefault(uuid, Set.of()); }
    public Map<String, Set<String>> getUnlockedPatterns(UUID uuid) { return unlockedPatterns.getOrDefault(uuid, Map.of()); }
    public int getPlayerStreak(UUID uuid) { return playerKillStreaks.getOrDefault(uuid, 0); }
    public int getStreakTier(UUID uuid) { return streakTier.getOrDefault(uuid, 0); }
    public String getStreakTierName(int tier) {
        return switch (tier) { case 1 -> "§eWARMING"; case 2 -> "§6BLAZING"; case 3 -> "§cINFERNO"; case 4 -> "§dGODLIKE"; default -> "§7NORMAL"; };
    }
    public EthernovaCosmetics getPlugin() { return plugin; }
}
