package com.ethernova.cosmetics.model;

import org.bukkit.Material;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import static org.junit.jupiter.api.Assertions.*;

class CosmeticRarityTest {

    @ParameterizedTest
    @EnumSource(CosmeticRarity.class)
    @DisplayName("Every rarity has a non-null color")
    void colorNotNull(CosmeticRarity rarity) {
        assertNotNull(rarity.getColor());
        assertFalse(rarity.getColor().isEmpty());
    }

    @ParameterizedTest
    @EnumSource(CosmeticRarity.class)
    @DisplayName("Every rarity has a display name")
    void displayNameNotNull(CosmeticRarity rarity) {
        assertNotNull(rarity.getDisplayName());
        assertFalse(rarity.getDisplayName().isEmpty());
    }

    @ParameterizedTest
    @EnumSource(CosmeticRarity.class)
    @DisplayName("getFormattedName() starts with color")
    void formattedNameStartsWithColor(CosmeticRarity rarity) {
        assertTrue(rarity.getFormattedName().startsWith(rarity.getColor()));
    }

    @ParameterizedTest
    @EnumSource(CosmeticRarity.class)
    @DisplayName("Every rarity maps to a glass pane material")
    void glassPaneNotNull(CosmeticRarity rarity) {
        Material m = rarity.getGlassPaneMaterial();
        assertNotNull(m);
        assertTrue(m.name().contains("STAINED_GLASS_PANE"));
    }

    @Test
    @DisplayName("Specific glass pane mappings")
    void specificMappings() {
        assertEquals(Material.WHITE_STAINED_GLASS_PANE, CosmeticRarity.COMMON.getGlassPaneMaterial());
        assertEquals(Material.BLUE_STAINED_GLASS_PANE, CosmeticRarity.RARE.getGlassPaneMaterial());
        assertEquals(Material.PURPLE_STAINED_GLASS_PANE, CosmeticRarity.EPIC.getGlassPaneMaterial());
        assertEquals(Material.ORANGE_STAINED_GLASS_PANE, CosmeticRarity.LEGENDARY.getGlassPaneMaterial());
        assertEquals(Material.MAGENTA_STAINED_GLASS_PANE, CosmeticRarity.MYTHIC.getGlassPaneMaterial());
    }

    @Test
    @DisplayName("Five rarity tiers exist")
    void fiveRarities() {
        assertEquals(5, CosmeticRarity.values().length);
    }
}
