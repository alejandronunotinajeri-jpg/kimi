package com.ethernova.cosmetics.model;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.bukkit.Material;

import static org.junit.jupiter.api.Assertions.*;

class CosmeticTest {

    private Cosmetic free = new Cosmetic("trail_fire", CosmeticType.TRAIL, "Fire Trail",
            "A trail of fire", Material.BLAZE_POWDER, "cosmetic.trail.fire", 0, CosmeticRarity.COMMON);

    private Cosmetic paid = new Cosmetic("msg_skull", CosmeticType.KILL_MESSAGE, "Skull Message",
            "Death message", Material.WRITABLE_BOOK, "cosmetic.msg.skull", 5000, CosmeticRarity.LEGENDARY);

    @Nested
    @DisplayName("Record fields")
    class FieldTests {
        @Test void id() { assertEquals("trail_fire", free.id()); }
        @Test void type() { assertEquals(CosmeticType.TRAIL, free.type()); }
        @Test void name() { assertEquals("Fire Trail", free.name()); }
        @Test void description() { assertEquals("A trail of fire", free.description()); }
        @Test void icon() { assertEquals(Material.BLAZE_POWDER, free.icon()); }
        @Test void permission() { assertEquals("cosmetic.trail.fire", free.permission()); }
        @Test void price() { assertEquals(0, free.price()); }
        @Test void rarity() { assertEquals(CosmeticRarity.COMMON, free.rarity()); }
    }

    @Nested
    @DisplayName("coloredName()")
    class ColoredNameTests {
        @Test
        void includesRarityColor() {
            String result = free.coloredName();
            assertTrue(result.startsWith(CosmeticRarity.COMMON.getColor()));
            assertTrue(result.endsWith("Fire Trail"));
        }

        @Test
        void legendaryColor() {
            String result = paid.coloredName();
            assertTrue(result.startsWith(CosmeticRarity.LEGENDARY.getColor()));
        }
    }

    @Nested
    @DisplayName("isPurchasable()")
    class PurchasableTests {
        @Test void freeIsNotPurchasable() { assertFalse(free.isPurchasable()); }
        @Test void paidIsPurchasable() { assertTrue(paid.isPurchasable()); }
    }

    @Nested
    @DisplayName("formattedPrice()")
    class FormattedPriceTests {
        @Test
        void freeShowsGratis() {
            assertEquals("<green>Gratis", free.formattedPrice());
        }

        @Test
        void paidShowsAmount() {
            assertEquals("<gold>5000 monedas", paid.formattedPrice());
        }
    }
}
