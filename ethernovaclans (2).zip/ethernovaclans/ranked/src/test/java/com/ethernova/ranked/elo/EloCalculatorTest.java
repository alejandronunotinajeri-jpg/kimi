package com.ethernova.ranked.elo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for EloCalculator.
 */
class EloCalculatorTest {

    private EloCalculator calc;

    @BeforeEach
    void setUp() {
        calc = new EloCalculator(); // defaults: kLow=40, kMid=20, kHigh=10
    }

    // ═══════════════ K-Factor ═══════════════

    @Nested
    @DisplayName("K-Factor selection")
    class KFactorTests {
        @Test
        @DisplayName("New player (<30 games) gets high K-factor")
        void newPlayerHighK() {
            assertEquals(40, calc.getKFactor(0));
            assertEquals(40, calc.getKFactor(15));
            assertEquals(40, calc.getKFactor(29));
        }

        @Test
        @DisplayName("Mid player (30-99 games) gets medium K-factor")
        void midPlayerMedK() {
            assertEquals(20, calc.getKFactor(30));
            assertEquals(20, calc.getKFactor(50));
            assertEquals(20, calc.getKFactor(99));
        }

        @Test
        @DisplayName("Veteran player (100+ games) gets low K-factor")
        void veteranPlayerLowK() {
            assertEquals(10, calc.getKFactor(100));
            assertEquals(10, calc.getKFactor(500));
        }
    }

    // ═══════════════ ELO Calculation ═══════════════

    @Nested
    @DisplayName("ELO calculation")
    class EloCalcTests {
        @Test
        @DisplayName("Equal ELO match produces symmetric changes")
        void equalEloMatch() {
            int[] result = calc.calculateNewElo(1000, 1000, 50, 50);
            assertTrue(result[0] > 1000, "Winner ELO should increase");
            assertTrue(result[1] < 1000, "Loser ELO should decrease");
        }

        @Test
        @DisplayName("Winner always gains at least 1 ELO")
        void minimumGain() {
            // Huge favorite wins: very high expected, so small gain
            int[] result = calc.calculateNewElo(2000, 500, 200, 200);
            assertTrue(result[0] >= 2001, "Winner must gain at least 1");
        }

        @Test
        @DisplayName("Loser always loses at least 1 ELO")
        void minimumLoss() {
            // Huge underdog loses: very low expected, so small loss
            int[] result = calc.calculateNewElo(2000, 500, 200, 200);
            assertTrue(result[1] <= 499, "Loser must lose at least 1");
        }

        @Test
        @DisplayName("ELO never goes below floor (0)")
        void eloFloor() {
            int[] result = calc.calculateNewElo(100, 5, 50, 50);
            assertTrue(result[1] >= 0, "ELO should never go below 0");
        }

        @Test
        @DisplayName("Upset gives more ELO to winner")
        void upsetBonus() {
            // Low ELO player beats high ELO player
            int[] upset = calc.calculateNewElo(500, 1500, 50, 50);
            int[] normal = calc.calculateNewElo(1500, 500, 50, 50);

            int upsetWinnerGain = upset[0] - 500;
            int normalWinnerGain = normal[0] - 1500;

            assertTrue(upsetWinnerGain > normalWinnerGain,
                    "Upset winner should gain more than favorite winner");
        }

        @Test
        @DisplayName("Simplified calculateNewElo uses defaults")
        void simplifiedMethod() {
            int[] result = calc.calculateNewElo(1000, 1000);
            assertNotNull(result);
            assertEquals(2, result.length);
            assertTrue(result[0] > 1000);
            assertTrue(result[1] < 1000);
        }
    }

    // ═══════════════ Preview ═══════════════

    @Nested
    @DisplayName("Preview change")
    class PreviewTests {
        @Test
        @DisplayName("Preview win returns positive change")
        void previewWin() {
            int change = calc.previewChange(1000, 1000, true, 50);
            assertTrue(change > 0, "Win should give positive ELO change");
        }

        @Test
        @DisplayName("Preview loss returns negative change")
        void previewLoss() {
            int change = calc.previewChange(1000, 1000, false, 50);
            assertTrue(change < 0, "Loss should give negative ELO change");
        }

        @Test
        @DisplayName("Preview minimum win gain is 1")
        void previewMinWin() {
            int change = calc.previewChange(2000, 500, true, 200);
            assertTrue(change >= 1, "Win preview must be at least 1");
        }

        @Test
        @DisplayName("Preview minimum loss is -1")
        void previewMinLoss() {
            int change = calc.previewChange(500, 2000, false, 200);
            assertTrue(change <= -1, "Loss preview must be at most -1");
        }
    }

    // ═══════════════ Custom Constructor ═══════════════

    @Test
    @DisplayName("Custom constructor applies configured values")
    void customConstructor() {
        EloCalculator custom = new EloCalculator(50, 10, 30, 50, 15, 100);
        assertEquals(50, custom.getKFactor(5));   // <10 games
        assertEquals(30, custom.getKFactor(25));   // 10-49 games
        assertEquals(15, custom.getKFactor(100));  // 50+ games

        // Test floor = 100
        int[] result = custom.calculateNewElo(110, 105, 200, 200);
        assertTrue(result[1] >= 100, "ELO should not go below custom floor (100)");
    }
}
