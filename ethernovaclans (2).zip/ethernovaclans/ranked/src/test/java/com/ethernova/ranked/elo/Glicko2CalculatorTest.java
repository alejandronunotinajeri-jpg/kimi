package com.ethernova.ranked.elo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Glicko-2 calculator.
 * Tests the core algorithm, streak modifiers, placement multiplier,
 * RD decay, rating decay, preview, and confidence intervals.
 */
class Glicko2CalculatorTest {

    private Glicko2Calculator calc;

    @BeforeEach
    void setUp() {
        calc = new Glicko2Calculator(); // defaults
    }

    // ═══════════════ Constructor / Getters ═══════════════

    @Test
    @DisplayName("Default constructor sets expected values")
    void defaultConstructor() {
        assertEquals(0.5, calc.getTau());
        assertEquals(1500.0, calc.getDefaultRating());
        assertEquals(350.0, calc.getDefaultRd());
        assertEquals(0.06, calc.getDefaultVolatility());
        assertEquals(0.0, calc.getRatingFloor());
        assertEquals(350.0, calc.getMaxRd());
        assertEquals(50.0, calc.getMinRd());
        assertEquals(0.03, calc.getStreakBonusPerWin());
        assertEquals(0.15, calc.getStreakBonusMax());
        assertEquals(0.02, calc.getStreakProtectionPerLoss());
        assertEquals(0.10, calc.getStreakProtectionMax());
        assertEquals(1.5, calc.getPlacementMultiplier());
    }

    @Test
    @DisplayName("Custom constructor stores values correctly")
    void customConstructor() {
        var custom = new Glicko2Calculator(0.3, 1200, 300, 0.05, 100, 400, 30,
                0.05, 0.20, 0.03, 0.12, 2.0);
        assertEquals(0.3, custom.getTau());
        assertEquals(1200.0, custom.getDefaultRating());
        assertEquals(300.0, custom.getDefaultRd());
        assertEquals(0.05, custom.getDefaultVolatility());
        assertEquals(100.0, custom.getRatingFloor());
        assertEquals(400.0, custom.getMaxRd());
        assertEquals(30.0, custom.getMinRd());
        assertEquals(2.0, custom.getPlacementMultiplier());
    }

    // ═══════════════ Core Match Processing ═══════════════

    @Nested
    @DisplayName("processMatch — core Glicko-2 algorithm")
    class ProcessMatchTests {

        @Test
        @DisplayName("Equal rating match: winner gains, loser loses")
        void equalRatingMatch() {
            var results = calc.processMatch(
                    1500, 200, 0.06, 0, false,
                    1500, 200, 0.06, 0, false);

            assertTrue(results[0].rating() > 1500, "Winner should gain rating");
            assertTrue(results[1].rating() < 1500, "Loser should lose rating");
            assertTrue(results[0].ratingChange() > 0, "Winner change should be positive");
            assertTrue(results[1].ratingChange() < 0, "Loser change should be negative");
        }

        @Test
        @DisplayName("Upset gives larger gain to underdog winner")
        void upsetGivesMoreReward() {
            // Underdog (1200) beats favourite (1800)
            var upset = calc.processMatch(
                    1200, 100, 0.06, 0, false,
                    1800, 100, 0.06, 0, false);

            // Favourite (1800) beats underdog (1200)
            var expected = calc.processMatch(
                    1800, 100, 0.06, 0, false,
                    1200, 100, 0.06, 0, false);

            assertTrue(upset[0].ratingChange() > expected[0].ratingChange(),
                    "Underdog winner should gain more than favourite winner");
        }

        @Test
        @DisplayName("Winner always gains at least 1 rating point")
        void winnerMinGain() {
            // Huge favourite (3000) beats newbie (500)
            var results = calc.processMatch(
                    3000, 50, 0.06, 0, false,
                    500, 50, 0.06, 0, false);

            assertTrue(results[0].ratingChange() >= 1, "Winner must gain at least 1");
        }

        @Test
        @DisplayName("Loser always loses at least 1 rating point")
        void loserMinLoss() {
            // Newbie (500) loses to huge favourite (3000)
            var results = calc.processMatch(
                    3000, 50, 0.06, 0, false,
                    500, 50, 0.06, 0, false);

            assertTrue(results[1].ratingChange() <= -1, "Loser must lose at least 1");
        }

        @Test
        @DisplayName("Rating floor is enforced")
        void ratingFloor() {
            var custom = new Glicko2Calculator(0.5, 1500, 350, 0.06, 100, 350, 50,
                    0.03, 0.15, 0.02, 0.10, 1.5);

            var results = custom.processMatch(
                    2000, 50, 0.06, 0, false,
                    110, 50, 0.06, 0, false);

            assertTrue(results[1].rating() >= 100, "Rating should not go below floor (100)");
        }

        @Test
        @DisplayName("Result array contains exactly 2 elements (winner, loser)")
        void resultArraySize() {
            var results = calc.processMatch(
                    1500, 200, 0.06, 0, false,
                    1500, 200, 0.06, 0, false);

            assertEquals(2, results.length);
        }

        @Test
        @DisplayName("High RD opponent causes larger rating change")
        void highRdOpponentLargerChange() {
            // Opponent with very low RD (=certain) vs high RD (=uncertain)
            var vsLowRd = calc.processMatch(
                    1500, 200, 0.06, 0, false,
                    1500, 50, 0.06, 0, false);

            var vsHighRd = calc.processMatch(
                    1500, 200, 0.06, 0, false,
                    1500, 350, 0.06, 0, false);

            // When opponent has LOW RD (more certain), the outcome is more meaningful
            // When opponent has HIGH RD (uncertain), the result is weighted less
            assertTrue(vsLowRd[0].ratingChange() > vsHighRd[0].ratingChange(),
                    "Beating a certain-rated (low RD) opponent should give more points");
        }

        @Test
        @DisplayName("RD decreases after playing a match")
        void rdDecreasesAfterMatch() {
            var results = calc.processMatch(
                    1500, 300, 0.06, 0, false,
                    1500, 300, 0.06, 0, false);

            assertTrue(results[0].rd() < 300, "Winner RD should decrease (more certain)");
            assertTrue(results[1].rd() < 300, "Loser RD should decrease (more certain)");
        }
    }

    // ═══════════════ Streak Modifiers ═══════════════

    @Nested
    @DisplayName("Streak modifiers")
    class StreakTests {

        @Test
        @DisplayName("Win streak gives bonus to winner")
        void winStreakBonus() {
            var noStreak = calc.processMatch(
                    1500, 200, 0.06, 0, false,
                    1500, 200, 0.06, 0, false);

            var withStreak = calc.processMatch(
                    1500, 200, 0.06, 5, false,
                    1500, 200, 0.06, 0, false);

            assertTrue(withStreak[0].ratingChange() > noStreak[0].ratingChange(),
                    "Win streak should give bonus gain to winner");
        }

        @Test
        @DisplayName("Loss streak gives protection (reduces loss)")
        void lossStreakProtection() {
            var noStreak = calc.processMatch(
                    1500, 200, 0.06, 0, false,
                    1500, 200, 0.06, 0, false);

            var withStreak = calc.processMatch(
                    1500, 200, 0.06, 0, false,
                    1500, 200, 0.06, 5, false);

            // Loser with high loss streak should lose less
            assertTrue(withStreak[1].ratingChange() > noStreak[1].ratingChange(),
                    "Loss streak should add protection (smaller loss)");
        }

        @Test
        @DisplayName("Streak bonus is capped")
        void streakBonusCapped() {
            var streak50 = calc.processMatch(
                    1500, 200, 0.06, 50, false,
                    1500, 200, 0.06, 0, false);

            var streak100 = calc.processMatch(
                    1500, 200, 0.06, 100, false,
                    1500, 200, 0.06, 0, false);

            // Both should be capped at streakBonusMax, so change should be equal
            assertEquals(streak50[0].ratingChange(), streak100[0].ratingChange(),
                    "Streak bonus should be capped (50-win and 100-win match)");
        }
    }

    // ═══════════════ Placement Multiplier ═══════════════

    @Nested
    @DisplayName("Placement multiplier")
    class PlacementTests {

        @Test
        @DisplayName("Placement win gives higher gain")
        void placementBoostedGain() {
            var normal = calc.processMatch(
                    1500, 250, 0.06, 0, false,
                    1500, 250, 0.06, 0, false);

            var placement = calc.processMatch(
                    1500, 250, 0.06, 0, true,
                    1500, 250, 0.06, 0, false);

            assertTrue(placement[0].ratingChange() > normal[0].ratingChange(),
                    "Placement winner should gain more than normal winner");
        }

        @Test
        @DisplayName("Placement loss gives larger loss")
        void placementBoostedLoss() {
            var normal = calc.processMatch(
                    1500, 250, 0.06, 0, false,
                    1500, 250, 0.06, 0, false);

            var placement = calc.processMatch(
                    1500, 250, 0.06, 0, false,
                    1500, 250, 0.06, 0, true);

            // The loser in placement (results[1] for placement) loses more
            assertTrue(Math.abs(placement[1].ratingChange()) > Math.abs(normal[1].ratingChange()),
                    "Placement loser should lose more than normal loser");
        }
    }

    // ═══════════════ RD Decay ═══════════════

    @Nested
    @DisplayName("RD decay (inactivity)")
    class RdDecayTests {

        @Test
        @DisplayName("RD increases with inactivity periods")
        void rdIncreasesWithInactivity() {
            double newRd = calc.decayRd(100, 0.06, 5);
            assertTrue(newRd > 100, "RD should increase after inactive periods");
        }

        @Test
        @DisplayName("RD capped at maxRd")
        void rdCappedAtMax() {
            double newRd = calc.decayRd(100, 0.06, 1000);
            assertTrue(newRd <= 350, "RD should not exceed maxRd (350)");
        }

        @Test
        @DisplayName("Zero inactive periods means no RD change")
        void noDecayForZeroPeriods() {
            double newRd = calc.decayRd(200, 0.06, 0);
            assertEquals(200, newRd, 0.001, "RD should not change with 0 inactive periods");
        }
    }

    // ═══════════════ Rating Decay ═══════════════

    @Nested
    @DisplayName("Rating decay")
    class RatingDecayTests {

        @Test
        @DisplayName("No decay before threshold")
        void noDecayBeforeThreshold() {
            double newRating = calc.decayRating(2000, 3, 5, 25);
            assertEquals(2000, newRating, "Rating should not decay before threshold");
        }

        @Test
        @DisplayName("Rating decays after threshold")
        void decaysAfterThreshold() {
            double newRating = calc.decayRating(2000, 7, 5, 25);
            assertEquals(1950, newRating, "2 excess periods * 25 = 50 decay → 1950");
        }

        @Test
        @DisplayName("Rating floor enforced during decay")
        void decayRespectsFloor() {
            double newRating = calc.decayRating(100, 100, 5, 25);
            assertEquals(0.0, newRating, "Rating should not go below floor (0)");
        }

        @Test
        @DisplayName("Exact threshold means no decay")
        void exactThresholdNoDecay() {
            double newRating = calc.decayRating(2000, 5, 5, 25);
            assertEquals(2000, newRating, "Rating should not decay at exact threshold");
        }
    }

    // ═══════════════ Preview ═══════════════

    @Nested
    @DisplayName("Preview change")
    class PreviewTests {

        @Test
        @DisplayName("Preview win returns positive change")
        void previewWin() {
            int change = calc.previewChange(1500, 200, 1500, 200, true);
            assertTrue(change > 0, "Win preview should be positive");
        }

        @Test
        @DisplayName("Preview loss returns negative change")
        void previewLoss() {
            int change = calc.previewChange(1500, 200, 1500, 200, false);
            assertTrue(change < 0, "Loss preview should be negative");
        }

        @Test
        @DisplayName("Preview minimum win is +1")
        void previewMinWin() {
            int change = calc.previewChange(3000, 50, 500, 50, true);
            assertTrue(change >= 1, "Win preview must be at least +1");
        }

        @Test
        @DisplayName("Preview minimum loss is -1")
        void previewMinLoss() {
            int change = calc.previewChange(500, 50, 3000, 50, false);
            assertTrue(change <= -1, "Loss preview must be at most -1");
        }

        @Test
        @DisplayName("Upset win gives larger preview gain")
        void previewUpsetBonus() {
            int upsetGain = calc.previewChange(1000, 200, 2000, 200, true);
            int normalGain = calc.previewChange(2000, 200, 1000, 200, true);
            assertTrue(upsetGain > normalGain,
                    "Upset win should preview larger gain than expected win");
        }
    }

    // ═══════════════ Confidence Interval ═══════════════

    @Nested
    @DisplayName("Confidence interval")
    class ConfidenceTests {

        @Test
        @DisplayName("95% CI is symmetric around rating")
        void symmetricCI() {
            int[] ci = calc.confidenceInterval(1500, 100);
            // 1500 ± 1.96*100 = [1304, 1696]
            assertEquals(1304, ci[0], "Lower bound = 1500 - 196");
            assertEquals(1696, ci[1], "Upper bound = 1500 + 196");
        }

        @Test
        @DisplayName("Narrow RD gives tighter interval")
        void narrowRdTighterCI() {
            int[] wide = calc.confidenceInterval(1500, 200);
            int[] narrow = calc.confidenceInterval(1500, 50);

            assertTrue((wide[1] - wide[0]) > (narrow[1] - narrow[0]),
                    "Higher RD should produce wider confidence interval");
        }

        @Test
        @DisplayName("Lower bound respects floor")
        void ciRespectsFloor() {
            int[] ci = calc.confidenceInterval(100, 200);
            assertTrue(ci[0] >= 0, "Lower CI bound should not go below floor (0)");
        }
    }

    // ═══════════════ Glicko2Result record ═══════════════

    @Nested
    @DisplayName("Glicko2Result display helpers")
    class ResultDisplayTests {

        @Test
        @DisplayName("displayRating rounds correctly")
        void displayRating() {
            var result = new Glicko2Calculator.Glicko2Result(1523.7, 95.3, 0.058, 24);
            assertEquals(1524, result.displayRating());
        }

        @Test
        @DisplayName("displayRd rounds correctly")
        void displayRd() {
            var result = new Glicko2Calculator.Glicko2Result(1523.7, 95.3, 0.058, 24);
            assertEquals(95, result.displayRd());
        }
    }
}
