package com.ethernova.ranked.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.CoreGui;
import com.ethernova.ranked.EthernovaRanked;
import com.ethernova.ranked.message.MessageManager;
import com.ethernova.ranked.model.Rank;
import com.ethernova.ranked.model.RankedProfile;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * GUI de tarjeta ranked del jugador.
 * Muestra ícono de rango, ELO, ratio V/D, barra de progreso y racha actual.
 */
public class RankedGui extends CoreGui {

    private final EthernovaRanked plugin;

    public RankedGui(EthernovaRanked plugin, EthernovaCore core, Player player) {
        super(core, player);
        this.plugin = plugin;
    }

    private MessageManager mm() { return plugin.getMessageManager(); }

    public void open() {
        openInventory(mm().get("gui.ranked.title"), 45);
    }

    @Override
    protected void populateItems() {
        RankedProfile profile = plugin.getRankedManager().getProfile(player.getUniqueId());
        if (profile == null) {
            setItem(22, createItem(Material.BARRIER, mm().get("gui.ranked.profile-not-found")));
            return;
        }

        Rank rank = profile.getCurrentRank();
        int placementMatches = plugin.getConfig().getInt("placement.matches", 10);
        boolean inPlacements = profile.isInPlacements(placementMatches);

        // Cabeza del jugador (slot 4)
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta skullMeta = (SkullMeta) skull.getItemMeta();
        if (skullMeta != null) {
            skullMeta.setOwningPlayer(player);
            skullMeta.displayName(mini.deserialize(mm().get("gui.ranked.skull-title", "{player}", player.getName())));
            List<String> lore = new ArrayList<>();
            lore.add(mm().get("gui.ranked.skull-separator"));
            lore.add(mm().get("gui.ranked.skull-rank", "{rank}", rank.getColoredName()));
            lore.add(mm().get("gui.ranked.skull-elo", "{elo}", String.valueOf(profile.getElo())));
            if (inPlacements) {
                lore.add(mm().get("gui.ranked.skull-placement",
                        "{played}", String.valueOf(profile.getPlacementMatchesPlayed()),
                        "{total}", String.valueOf(placementMatches)));
            }
            lore.add(mm().get("gui.ranked.skull-separator"));
            skullMeta.lore(lore.stream().map(mini::deserialize).toList());
            skull.setItemMeta(skullMeta);
        }
        setItem(4, skull);

        // Ícono del rango actual (slot 20)
        List<String> rankLore = new ArrayList<>();
        rankLore.add(mm().get("gui.ranked.skull-separator"));
        rankLore.add(mm().get("gui.ranked.rank-min", "{min}", String.valueOf(rank.getMinElo())));
        if (rank.getMaxElo() != Integer.MAX_VALUE) {
            rankLore.add(mm().get("gui.ranked.rank-max", "{max}", String.valueOf(rank.getMaxElo())));
        } else {
            rankLore.add(mm().get("gui.ranked.rank-max", "{max}", "∞"));
        }
        rankLore.add(mm().get("gui.ranked.skull-separator"));
        Rank next = rank.next();
        if (next != null) {
            rankLore.add(mm().get("gui.ranked.rank-next",
                    "{rank}", next.getColoredName(),
                    "{elo}", String.valueOf(next.getMinElo())));
        } else {
            rankLore.add(mm().get("gui.ranked.rank-max-reached"));
        }
        setItem(20, createItem(rank.getIcon(), rank.getColoredName(), rankLore));
        slotActions.put(20, "RANK_INFO");

        // ELO display (slot 22)
        List<String> eloLore = new ArrayList<>();
        eloLore.add(mm().get("gui.ranked.skull-separator"));
        eloLore.add(buildProgressBarLore(rank, profile.getElo()));
        eloLore.add(mm().get("gui.ranked.skull-separator"));
        eloLore.add(mm().get("gui.ranked.elo-rd", "{rd}", profile.getRdFormatted()));
        eloLore.add(mm().get("gui.ranked.elo-confidence", "{interval}", profile.getConfidenceInterval()));
        eloLore.add(mm().get("gui.ranked.elo-peak", "{peak}", String.valueOf(profile.getPeakRating())));
        if (rank.next() != null) {
            int needed = rank.next().getMinElo() - profile.getElo();
            eloLore.add(mm().get("gui.ranked.elo-needed",
                    "{needed}", String.valueOf(needed),
                    "{rank}", rank.next().getColoredName()));
        }
        setItem(22, createItem(Material.EXPERIENCE_BOTTLE,
                mm().get("gui.ranked.elo-display", "{elo}", String.valueOf(profile.getElo())), eloLore));

        // Estadísticas V/D (slot 24)
        List<String> statsLore = new ArrayList<>();
        statsLore.add(mm().get("gui.ranked.skull-separator"));
        statsLore.add(mm().get("gui.ranked.stats-wins", "{wins}", String.valueOf(profile.getWins())));
        statsLore.add(mm().get("gui.ranked.stats-losses", "{losses}", String.valueOf(profile.getLosses())));
        statsLore.add(mm().get("gui.ranked.stats-total", "{total}", String.valueOf(profile.getTotalGames())));
        statsLore.add(mm().get("gui.ranked.skull-separator"));
        statsLore.add(mm().get("gui.ranked.stats-ratio", "{winrate}", profile.getWinRateFormatted()));
        setItem(24, createItem(Material.BOOK, mm().get("gui.ranked.stats-title"), statsLore));

        // Barra de progreso visual (slots 28-32 — rendered first to avoid conflicts)
        buildProgressBarItems(rank, profile.getElo());

        // Racha (slot 11 — row 2)
        List<String> streakLore = new ArrayList<>();
        streakLore.add(mm().get("gui.ranked.skull-separator"));
        streakLore.add(mm().get("gui.ranked.streak-current", "{current}", String.valueOf(profile.getWinStreak())));
        streakLore.add(mm().get("gui.ranked.streak-best", "{best}", String.valueOf(profile.getBestWinStreak())));
        streakLore.add(mm().get("gui.ranked.skull-separator"));
        if (profile.getWinStreak() >= 5) {
            streakLore.add(mm().get("gui.ranked.streak-fire"));
        } else if (profile.getWinStreak() >= 3) {
            streakLore.add(mm().get("gui.ranked.streak-good"));
        }
        Material streakIcon = profile.getWinStreak() >= 5 ? Material.BLAZE_POWDER :
                profile.getWinStreak() >= 3 ? Material.FIRE_CHARGE : Material.COAL;
        setItem(11, createItem(streakIcon, mm().get("gui.ranked.streak-title"), streakLore));

        // Temporada (slot 13 — row 2)
        List<String> seasonLore = new ArrayList<>();
        seasonLore.add(mm().get("gui.ranked.skull-separator"));
        seasonLore.add(mm().get("gui.ranked.season-id", "{id}", plugin.getSeasonManager().getCurrentSeason()));
        seasonLore.add(plugin.getSeasonManager().isSeasonActive()
                ? mm().get("gui.ranked.season-active")
                : mm().get("gui.ranked.season-inactive"));
        setItem(13, createItem(Material.CLOCK,
                mm().get("gui.ranked.season-title", "{season}", plugin.getSeasonManager().getSeasonDisplayName()), seasonLore));

        // Botón leaderboard (slot 15 — row 2)
        setItem(15, createItem(Material.GOLDEN_HELMET, mm().get("gui.ranked.leaderboard-btn"),
                List.of(mm().get("gui.ranked.leaderboard-desc1"), mm().get("gui.ranked.leaderboard-desc2"))));
        slotActions.put(15, "LEADERBOARD");

        // Cerrar
        setItem(40, createItem(Material.BARRIER, mm().get("gui.ranked.close")));
        slotActions.put(40, "CLOSE");
    }

    /**
     * Construye la barra de progreso visual con items de cristal coloreado.
     */
    private void buildProgressBarItems(Rank rank, int elo) {
        if (rank.isHighest()) {
            for (int i = 28; i <= 32; i++) {
                setItem(i, createItem(Material.GOLD_BLOCK, mm().get("gui.ranked.progress-max")));
            }
            return;
        }

        double progress = rank.getProgress(elo);
        int totalSlots = 5;
        int filled = (int) Math.round(progress * totalSlots);

        int[] slots = {28, 29, 30, 31, 32};
        for (int i = 0; i < slots.length; i++) {
            if (i < filled) {
                setItem(slots[i], createItem(Material.LIME_STAINED_GLASS_PANE,
                        mm().get("gui.ranked.progress-filled", "{percent}", String.valueOf((int)(progress * 100)))));
            } else {
                setItem(slots[i], createItem(Material.RED_STAINED_GLASS_PANE,
                        mm().get("gui.ranked.progress-empty", "{percent}", String.valueOf((int)(progress * 100)))));
            }
        }
    }

    private String buildProgressBarLore(Rank rank, int elo) {
        if (rank.isHighest()) {
            return "<gradient:#FFD700:#FF4500>████████████████████ MAX</gradient>";
        }

        double progress = rank.getProgress(elo);
        int filled = (int) (progress * 20);
        int empty = 20 - filled;

        return rank.getColor() + "█".repeat(filled) + "<dark_gray>" + "░".repeat(empty) +
                "</dark_gray> <white>" + (int) (progress * 100) + "%</white>";
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        return switch (action) {
            case "LEADERBOARD" -> {
                playSound("click");
                player.closeInventory();
                new LeaderboardGui(plugin, core, player).open();
                yield true;
            }
            case "RANK_INFO" -> {
                playSound("click");
                yield true;
            }
            default -> false;
        };
    }
}
