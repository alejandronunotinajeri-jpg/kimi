package com.ethernova.ranked.placeholder;

import com.ethernova.ranked.EthernovaRanked;
import com.ethernova.ranked.message.MessageManager;
import com.ethernova.ranked.model.Rank;
import com.ethernova.ranked.model.RankedProfile;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * PlaceholderAPI expansion for EthernovaRanked (Glicko-2).
 * Placeholders:
 *   %ranked_elo%                 - Rating numérico
 *   %ranked_rd%                  - Rating Deviation (incertidumbre)
 *   %ranked_confidence%          - Intervalo de confianza 95%
 *   %ranked_rank%                - Nombre del rango
 *   %ranked_rank_color%          - Color del rango
 *   %ranked_wins%
 *   %ranked_losses%
 *   %ranked_winrate%
 *   %ranked_total_games%
 *   %ranked_win_streak%
 *   %ranked_loss_streak%
 *   %ranked_best_streak%
 *   %ranked_season%
 *   %ranked_in_placements%
 *   %ranked_placement_progress%
 */
public class RankedPlaceholders extends PlaceholderExpansion {

    private final EthernovaRanked plugin;

    public RankedPlaceholders(EthernovaRanked plugin) {
        this.plugin = plugin;
    }

    private MessageManager mm() { return plugin.getMessageManager(); }

    @Override
    public @NotNull String getIdentifier() {
        return "ranked";
    }

    @Override
    public @NotNull String getAuthor() {
        return "Ethernova";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public @Nullable String onRequest(OfflinePlayer offlinePlayer, @NotNull String params) {
        if (offlinePlayer == null) return "";
        UUID uuid = offlinePlayer.getUniqueId();

        RankedProfile profile = plugin.getRankedManager().getProfile(uuid);
        if (profile == null) return "";

        Rank rank = profile.getCurrentRank();
        int placementMatches = plugin.getConfig().getInt("placement.matches", 10);

        return switch (params.toLowerCase()) {
            case "elo" -> String.valueOf(profile.getElo());

            case "rd" -> profile.getRdFormatted();

            case "confidence" -> profile.getConfidenceInterval();

            case "rank" -> mm().get("rank." + rank.name().toLowerCase());

            case "rank_color" -> rank.getColor();

            case "wins" -> String.valueOf(profile.getWins());

            case "losses" -> String.valueOf(profile.getLosses());

            case "winrate" -> profile.getWinRateFormatted();

            case "total_games" -> String.valueOf(profile.getTotalGames());

            case "win_streak" -> String.valueOf(profile.getWinStreak());

            case "loss_streak" -> String.valueOf(profile.getLossStreak());

            case "best_streak" -> String.valueOf(profile.getBestWinStreak());

            case "peak_rating" -> String.valueOf(profile.getPeakRating());

            case "peak_rank" -> {
                Rank peakRank = Rank.fromElo(profile.getPeakRating());
                yield mm().get("rank." + peakRank.name().toLowerCase());
            }

            case "season" -> plugin.getSeasonManager().getSeasonDisplayName();

            case "in_placements" -> profile.isInPlacements(placementMatches)
                    ? mm().get("placeholder.yes") : mm().get("placeholder.no");

            case "placement_progress" -> profile.isInPlacements(placementMatches)
                    ? profile.getPlacementMatchesPlayed() + "/" + placementMatches
                    : mm().get("placeholder.no");

            default -> null;
        };
    }
}
