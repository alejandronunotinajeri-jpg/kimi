package com.ethernova.ranked.listener;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.event.DuelEndEvent;
import com.ethernova.core.event.EthernovaPlayerKillEvent;
import com.ethernova.ranked.EthernovaRanked;
import com.ethernova.ranked.manager.RankedManager;
import com.ethernova.ranked.model.RankedProfile;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.function.Consumer;

/**
 * Listener del sistema de clasificación Glicko-2.
 * <p>
 * Se suscribe a DOS eventos vía EventBus:
 * <ul>
 *     <li>{@link EthernovaPlayerKillEvent} — Kills en FFA, ranked open world, etc.</li>
 *     <li>{@link DuelEndEvent} — Resultados de duelos 1v1</li>
 * </ul>
 * Solo procesa eventos con contextos permitidos (configurable en config.yml).
 */
public class RankedListener implements Listener {

    private final EthernovaRanked plugin;
    private final EthernovaCore core;
    private final Consumer<EthernovaPlayerKillEvent> killHandler;
    private final Consumer<DuelEndEvent> duelHandler;

    public RankedListener(EthernovaRanked plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;

        // Registrar handler de kills (FFA, open world PvP con contexto válido)
        this.killHandler = this::onPlayerKill;
        core.getEventBus().subscribe(EthernovaPlayerKillEvent.class, killHandler);

        // Registrar handler de duelos
        this.duelHandler = this::onDuelEnd;
        core.getEventBus().subscribe(DuelEndEvent.class, duelHandler);
    }

    /**
     * Procesa un evento de kill del EventBus.
     * Solo da ELO si el contexto está en la lista de contextos permitidos.
     */
    private void onPlayerKill(EthernovaPlayerKillEvent event) {
        RankedManager manager = plugin.getRankedManager();

        // Filtrar por contexto — solo contextos configurados dan ELO
        if (!manager.isAllowedContext(event.context())) return;

        RankedProfile winnerProfile = manager.getProfile(event.killerUuid());
        RankedProfile loserProfile = manager.getProfile(event.victimUuid());
        if (winnerProfile == null || loserProfile == null) return;
        if (!plugin.getSeasonManager().isSeasonActive()) return;

        manager.processResult(event.killerUuid(), event.victimUuid());
    }

    /**
     * Procesa el resultado de un duelo.
     * Los duelos SIEMPRE dan ELO (son el modo competitivo principal).
     */
    private void onDuelEnd(DuelEndEvent event) {
        RankedManager manager = plugin.getRankedManager();

        RankedProfile winnerProfile = manager.getProfile(event.winnerUuid());
        RankedProfile loserProfile = manager.getProfile(event.loserUuid());
        if (winnerProfile == null || loserProfile == null) return;
        if (!plugin.getSeasonManager().isSeasonActive()) return;

        manager.processResult(event.winnerUuid(), event.loserUuid());
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerJoin(PlayerJoinEvent event) {
        plugin.getRankedManager().loadProfile(event.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerQuit(PlayerQuitEvent event) {
        plugin.getRankedManager().unloadProfile(event.getPlayer().getUniqueId());
    }

    /**
     * Desregistra los handlers del EventBus. Llamar al deshabilitar el plugin.
     */
    public void unregister() {
        core.getEventBus().unsubscribe(EthernovaPlayerKillEvent.class, killHandler);
        core.getEventBus().unsubscribe(DuelEndEvent.class, duelHandler);
    }
}
