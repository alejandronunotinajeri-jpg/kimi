package com.ethernova.ranked.elo;

/**
 * @deprecated Replaced by {@link com.ethernova.ranked.glicko2.Glicko2Calculator}.
 * This legacy ELO calculator is kept only for reference. All rating calculations
 * now use the Glicko-2 algorithm which provides superior accuracy with
 * Rating Deviation (uncertainty) and Volatility (consistency) tracking.
 */
@Deprecated(since = "2.0", forRemoval = true)
public final class EloCalculator {

    private final int kLow;
    private final int kMid;
    private final int kHigh;
    private final int lowThreshold;
    private final int midThreshold;
    private final int eloFloor;

    public EloCalculator(int kLow, int lowThreshold, int kMid, int midThreshold, int kHigh, int eloFloor) {
        this.kLow = kLow;
        this.kMid = kMid;
        this.kHigh = kHigh;
        this.lowThreshold = lowThreshold;
        this.midThreshold = midThreshold;
        this.eloFloor = eloFloor;
    }

    /**
     * Constructor con valores por defecto estándar.
     */
    public EloCalculator() {
        this(40, 30, 20, 100, 10, 0);
    }

    /**
     * Calcula el nuevo ELO para ambos jugadores después de un resultado.
     *
     * @param winnerElo ELO actual del ganador
     * @param loserElo ELO actual del perdedor
     * @param winnerGames cantidad de partidas totales del ganador
     * @param loserGames cantidad de partidas totales del perdedor
     * @return int[2] donde [0] = nuevo ELO del ganador, [1] = nuevo ELO del perdedor
     */
    public int[] calculateNewElo(int winnerElo, int loserElo, int winnerGames, int loserGames) {
        int kWinner = getKFactor(winnerGames);
        int kLoser = getKFactor(loserGames);

        // Expectativa de victoria basada en diferencia de ELO (fórmula ELO estándar)
        double expectedWinner = expectedScore(winnerElo, loserElo);
        double expectedLoser = 1.0 - expectedWinner;

        // Calcular cambio de ELO
        // El ganador obtiene resultado = 1.0, el perdedor = 0.0
        int winnerChange = (int) Math.round(kWinner * (1.0 - expectedWinner));
        int loserChange = (int) Math.round(kLoser * (0.0 - expectedLoser));

        // Garantizar ganancia mínima de 1 para el ganador
        if (winnerChange < 1) {
            winnerChange = 1;
        }

        // Garantizar pérdida máxima de -1 para el perdedor (no puede ganar por perder)
        if (loserChange > -1) {
            loserChange = -1;
        }

        int newWinnerElo = Math.max(eloFloor, winnerElo + winnerChange);
        int newLoserElo = Math.max(eloFloor, loserElo + loserChange);

        return new int[]{newWinnerElo, newLoserElo};
    }

    /**
     * Calcula el nuevo ELO simplificado (usa K basado en promedio).
     */
    public int[] calculateNewElo(int winnerElo, int loserElo) {
        return calculateNewElo(winnerElo, loserElo, 50, 50);
    }

    /**
     * Calcula la expectativa de victoria usando la fórmula ELO estándar.
     * Retorna un valor entre 0.0 y 1.0.
     */
    private double expectedScore(int playerElo, int opponentElo) {
        return 1.0 / (1.0 + Math.pow(10.0, (opponentElo - playerElo) / 400.0));
    }

    /**
     * Obtiene el factor K basado en la cantidad de partidas jugadas.
     * Jugadores nuevos tienen factores más altos (cambios más rápidos).
     */
    public int getKFactor(int gamesPlayed) {
        if (gamesPlayed < lowThreshold) return kLow;
        if (gamesPlayed < midThreshold) return kMid;
        return kHigh;
    }

    /**
     * Calcula cuántos puntos de ELO cambiarían en un hipotético resultado.
     * Útil para previsualización.
     */
    public int previewChange(int playerElo, int opponentElo, boolean win, int gamesPlayed) {
        int k = getKFactor(gamesPlayed);
        double expected = expectedScore(playerElo, opponentElo);
        double actual = win ? 1.0 : 0.0;
        int change = (int) Math.round(k * (actual - expected));
        if (win && change < 1) change = 1;
        if (!win && change > -1) change = -1;
        return change;
    }
}
