package com.ethernova.ranked.gui;

import com.ethernova.core.gui.CoreGui;
import com.ethernova.ranked.EthernovaRanked;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/**
 * Admin GUI for EthernovaRanked — full in-game configuration.
 * Permission: ethernova.ranked.admin
 */
public class RankedAdminGui extends CoreGui {

    private final EthernovaRanked plugin;

    public RankedAdminGui(EthernovaRanked plugin, Player player) {
        super(plugin.getCore(), player);
        this.plugin = plugin;
    }

    public void open() {
        openInventory("<gradient:#F7971E:#FFD200>⚙ Ranked Admin</gradient>", 54);
    }

    @Override
    protected void populateItems() {
        // ── Back ──
        setItem(45, createItem(Material.ARROW, "<gray>← Volver"));
        slotActions.put(45, "BACK");

        // ═══ Header ═══
        setItem(4, createItem(Material.DIAMOND_SWORD,
                "<gold><bold>⚙ Configuración Ranked",
                List.of("<gray>Gestiona el sistema Glicko-2",
                        "<gray>y clasificación competitiva")));

        // ═══ Row 1: Season ═══
        setItem(10, createItem(Material.YELLOW_STAINED_GLASS_PANE, "<yellow><bold>Temporada"));

        setItem(11, createItem(Material.NAME_TAG,
                "<gold>Season: <white>" + plugin.getConfig().getString("season.name", "Temporada 1"),
                List.of("<gray>ID: <white>" + plugin.getConfig().getString("season.id", "s1"),
                        "",
                        "<yellow>Click para editar nombre")));
        slotActions.put(11, "EDIT_SEASON_NAME");

        setItem(12, toggleItem("Season Activa", "season.active"));
        slotActions.put(12, "TOGGLE:season.active");

        setItem(13, toggleItem("Soft Reset", "season.soft-reset.enabled"));
        slotActions.put(13, "TOGGLE:season.soft-reset.enabled");

        // ═══ Row 1 continued: Glicko-2 Base ═══
        setItem(14, createItem(Material.CYAN_STAINED_GLASS_PANE, "<aqua><bold>Glicko-2"));

        setItem(15, numberItem(Material.GOLD_INGOT, "Rating Inicial", "glicko2.default-rating", ""));
        slotActions.put(15, "INT:glicko2.default-rating:0:5000");

        setItem(16, numberItem(Material.BEDROCK, "Rating Floor", "glicko2.rating-floor", ""));
        slotActions.put(16, "INT:glicko2.rating-floor:0:2000");

        // ═══ Row 2: Glicko-2 & Placement ═══
        setItem(19, numberItem(Material.IRON_SWORD, "Placements", "placement.matches", "partidas"));
        slotActions.put(19, "INT:placement.matches:0:50");

        setItem(20, numberItem(Material.HEART_OF_THE_SEA, "RD Inicial", "glicko2.default-rd", ""));
        slotActions.put(20, "INT:glicko2.default-rd:50:500");

        setItem(21, numberItem(Material.ENDER_EYE, "Max RD", "glicko2.max-rd", ""));
        slotActions.put(21, "INT:glicko2.max-rd:100:500");

        setItem(22, numberItem(Material.ENDER_PEARL, "Min RD", "glicko2.min-rd", ""));
        slotActions.put(22, "INT:glicko2.min-rd:10:200");

        setItem(23, createItem(Material.ORANGE_STAINED_GLASS_PANE, "<gold><bold>Rachas"));

        setItem(24, decimalItem(Material.BLAZE_POWDER, "Bonus/Win", "streaks.bonus-per-win"));
        slotActions.put(24, "DEC:streaks.bonus-per-win:0.0:0.5");

        setItem(25, decimalItem(Material.REDSTONE, "Bonus Max", "streaks.bonus-max"));
        slotActions.put(25, "DEC:streaks.bonus-max:0.0:1.0");

        // ═══ Row 3: Decay & Leaderboard ═══
        setItem(28, createItem(Material.LIME_STAINED_GLASS_PANE, "<green><bold>Decay"));

        setItem(29, toggleItem("Decay Activo", "decay.enabled"));
        slotActions.put(29, "TOGGLE:decay.enabled");

        setItem(30, numberItem(Material.CLOCK, "Periodo", "decay.period-days", "días"));
        slotActions.put(30, "INT:decay.period-days:1:90");

        setItem(31, numberItem(Material.IRON_BARS, "Umbral (periodos)", "decay.threshold-periods", ""));
        slotActions.put(31, "INT:decay.threshold-periods:1:20");

        setItem(32, numberItem(Material.SPIDER_EYE, "Rating/Periodo", "decay.rating-per-period", ""));
        slotActions.put(32, "INT:decay.rating-per-period:1:100");

        setItem(33, createItem(Material.PURPLE_STAINED_GLASS_PANE, "<light_purple><bold>Leaderboard"));

        setItem(34, numberItem(Material.PAINTING, "Max Entries", "leaderboard.max-entries", ""));
        slotActions.put(34, "INT:leaderboard.max-entries:10:500");

        // ═══ Row 4: Actions ═══
        setItem(37, createItem(Material.WRITABLE_BOOK,
                "<yellow>Idioma: <white>" + plugin.getConfig().getString("general.language", "es"),
                List.of("<yellow>Click para cambiar")));
        slotActions.put(37, "CYCLE_LANG");

        setItem(39, createItem(Material.COMMAND_BLOCK,
                "<green>⟳ Recargar Config", List.of("<gray>Recarga config.yml y mensajes")));
        slotActions.put(39, "RELOAD");

        setItem(40, createItem(Material.BOOK, "<aqua>ℹ Información",
                List.of("<gray>Plugin: <white>EthernovaRanked",
                        "<gray>Algoritmo: <white>Glicko-2",
                        "<gray>Temporada: <white>" + plugin.getSeasonManager().getSeasonDisplayName(),
                        "<gray>Jugadores con datos: <white>" + plugin.getRankedManager().getProfiles().size())));

        setItem(49, createItem(Material.BARRIER, "<red>Cerrar"));
        slotActions.put(49, "CLOSE");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.startsWith("TOGGLE:")) {
            String path = action.substring(7);
            plugin.getConfig().set(path, !plugin.getConfig().getBoolean(path, false));
            plugin.saveConfig();
            refresh();
            return true;
        }
        if (action.startsWith("INT:")) {
            String[] parts = action.substring(4).split(":");
            adjustInt(parts[0], event, Integer.parseInt(parts[1]), Integer.parseInt(parts[2]));
            return true;
        }
        if (action.startsWith("DEC:")) {
            String[] parts = action.substring(4).split(":");
            adjustDecimal(parts[0], event, Double.parseDouble(parts[1]), Double.parseDouble(parts[2]));
            return true;
        }
        return switch (action) {
            case "CYCLE_LANG" -> {
                String current = plugin.getConfig().getString("general.language", "es");
                plugin.getConfig().set("general.language", "es".equals(current) ? "en" : "es");
                plugin.saveConfig();
                refresh();
                yield true;
            }
            case "EDIT_SEASON_NAME" -> {
                player.closeInventory();
                core.getGuiManager().requestChatInput(player,
                        "<yellow>Escribe el nuevo nombre de temporada:",
                        600, input -> {
                            if (input != null) {
                                plugin.getConfig().set("season.name", input);
                                plugin.saveConfig();
                                player.sendMessage(mini.deserialize("<green>✔ Nombre de temporada cambiado a: <white>" + input));
                            }
                            Bukkit.getScheduler().runTask(core, () -> new RankedAdminGui(plugin, player).open());
                        });
                yield true;
            }
            case "RELOAD" -> {
                plugin.reloadConfig();
                plugin.getMessageManager().load();
                playSound("success");
                player.closeInventory();
                player.sendMessage(mini.deserialize("<green>✔ Configuración de Ranked recargada."));
                yield true;
            }
            case "BACK" -> {
                playSound("click");
                player.closeInventory();
                Bukkit.getScheduler().runTaskLater(core, () -> player.performCommand("ethernova admin"), 2L);
                yield true;
            }
            default -> false;
        };
    }

    // ═══════════════ Helpers ═══════════════

    private void adjustInt(String path, InventoryClickEvent event, int min, int max) {
        int current = plugin.getConfig().getInt(path, 0);
        int delta = event.isShiftClick() ? 10 : 1;
        if (event.isRightClick()) delta = -delta;
        plugin.getConfig().set(path, Math.max(min, Math.min(max, current + delta)));
        plugin.saveConfig();
        refresh();
    }

    private void refresh() {
        playSound("click");
        player.closeInventory();
        Bukkit.getScheduler().runTaskLater(core, this::open, 1L);
    }

    private ItemStack toggleItem(String name, String path) {
        boolean val = plugin.getConfig().getBoolean(path, false);
        return createItem(val ? Material.LIME_DYE : Material.GRAY_DYE,
                (val ? "<green>✔ " : "<red>✘ ") + name,
                List.of("<gray>Estado: " + (val ? "<green>Activado" : "<red>Desactivado"),
                        "", "<yellow>Click para " + (val ? "desactivar" : "activar")));
    }

    private ItemStack numberItem(Material mat, String name, String path, String unit) {
        int val = plugin.getConfig().getInt(path, 0);
        String suffix = unit.isEmpty() ? "" : " " + unit;
        return createItem(mat, "<gold>" + name + ": <white>" + val + suffix,
                List.of("<gray>Click izq: <green>+1", "<gray>Click der: <red>-1",
                        "<gray>Shift+Click: <yellow>±10"));
    }

    private ItemStack decimalItem(Material mat, String name, String path) {
        double val = plugin.getConfig().getDouble(path, 0.0);
        return createItem(mat, "<gold>" + name + ": <white>" + String.format("%.2f", val),
                List.of("<gray>Click izq: <green>+0.01", "<gray>Click der: <red>-0.01",
                        "<gray>Shift+Click: <yellow>±0.05"));
    }

    private void adjustDecimal(String path, InventoryClickEvent event, double min, double max) {
        double current = plugin.getConfig().getDouble(path, 0.0);
        double delta = event.isShiftClick() ? 0.05 : 0.01;
        if (event.isRightClick()) delta = -delta;
        double newVal = Math.max(min, Math.min(max, current + delta));
        plugin.getConfig().set(path, Math.round(newVal * 100.0) / 100.0);
        plugin.saveConfig();
        refresh();
    }
}
