package com.ethernova.ranked.manager;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.storage.CoreStorageManager;
import com.ethernova.ranked.EthernovaRanked;
import com.ethernova.ranked.model.Rank;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;

/**
 * Gestiona las temporadas del sistema de clasificación.
 * Permite archivar rankings y resetear para una nueva temporada.
 */
public class SeasonManager {

    private final EthernovaRanked plugin;
    private final CoreStorageManager storage;
    private volatile String currentSeason;
    private volatile boolean seasonActive;

    public SeasonManager(EthernovaRanked plugin, CoreStorageManager storage) {
        this.plugin = plugin;
        this.storage = storage;
        this.currentSeason = plugin.getConfig().getString("season.id", "s1");
        this.seasonActive = plugin.getConfig().getBoolean("season.active", true);
    }

    public String getCurrentSeason() { return currentSeason; }

    public String getSeasonDisplayName() {
        return plugin.getConfig().getString("season.name", "Temporada 1");
    }

    public boolean isSeasonActive() { return seasonActive; }

    /**
     * Resetea la temporada actual: archiva los rankings y reinicia el ELO.
     *
     * @param newSeasonId ID de la nueva temporada
     * @param newSeasonName nombre visible de la nueva temporada
     * @return future que se completa cuando el reset termina
     */
    public CompletableFuture<Integer> resetSeason(String newSeasonId, String newSeasonName) {
        return CompletableFuture.supplyAsync(() -> {
            int archived = 0;
            String oldSeason = currentSeason;
            boolean softReset = plugin.getConfig().getBoolean("season.soft-reset.enabled", true);

            try (Connection conn = storage.getConnection()) {
                conn.setAutoCommit(false);

                try {
                    // Paso 1: Archivar todos los rankings actuales en la tabla de historial
                    archived = archiveCurrentSeason(conn, oldSeason);

                    if (softReset) {
                        // Soft Reset: Actualizar perfiles en memoria, luego sincronizar a DB
                        // Paso 2a: Resetear perfiles en memoria (soft — bajan rangos)
                        plugin.getRankedManager().resetAllProfiles(newSeasonId);

                        // Paso 2b: Actualizar DB — cambiar season y aplicar nuevos valores
                        softResetDatabase(conn, oldSeason, newSeasonId);
                    } else {
                        // Hard Reset: Eliminar todo de DB
                        try (PreparedStatement ps = conn.prepareStatement(
                                "DELETE FROM ethernova_ranked WHERE season = ?")) {
                            ps.setString(1, oldSeason);
                            ps.executeUpdate();
                        }
                        // Resetear perfiles en memoria (hard — vuelta a default)
                        plugin.getRankedManager().resetAllProfiles(newSeasonId);
                    }

                    conn.commit();

                    // Paso 3: Actualizar config en memoria
                    this.currentSeason = newSeasonId;
                    this.seasonActive = true;
                    plugin.getConfig().set("season.id", newSeasonId);
                    plugin.getConfig().set("season.name", newSeasonName);
                    plugin.getConfig().set("season.active", true);
                    plugin.saveConfig();

                    // Paso 4: Guardar perfiles actualizados a DB (soft reset ya los modificó)
                    if (softReset) {
                        plugin.getRankedManager().saveAllProfilesSync();
                    }

                    plugin.getRankedManager().invalidateLeaderboard();

                    String mode = softReset ? "SOFT" : "HARD";
                    plugin.getLogger().info("Temporada reseteada (" + mode + "): " + oldSeason + " → " + newSeasonId +
                            " (" + archived + " perfiles archivados)");

                } catch (SQLException e) {
                    conn.rollback();
                    throw e;
                } finally {
                    conn.setAutoCommit(true);
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Error reseteando temporada", e);
            }

            return archived;
        }, EthernovaCore.getInstance().getDbExecutor()).exceptionally(ex -> {
            plugin.getLogger().log(Level.SEVERE, "Unhandled error resetting season", ex);
            return 0;
        });
    }

    /**
     * Soft reset a nivel de DB: aplica reset completo a TODOS los registros (online + offline).
     * Para jugadores ONLINE, los valores en memoria ya fueron reseteados por resetAllProfiles(),
     * y se sincronizarán después con saveAllProfilesSync().
     * Para jugadores OFFLINE, este método calcula y aplica el soft reset directamente en DB
     * para que no se queden con sus ratings de la temporada anterior.
     */
    private void softResetDatabase(Connection conn, String oldSeason, String newSeason) throws SQLException {
        int dropRanks = plugin.getConfig().getInt("season.soft-reset.drop-ranks", 2);
        double resetRd = plugin.getConfig().getDouble("season.soft-reset.rd-after-reset", 200.0);
        double resetVol = plugin.getRankedManager().getCalculator().getDefaultVolatility();
        double defaultRating = plugin.getRankedManager().getCalculator().getDefaultRating();

        // First: update season column for ALL players
        try (PreparedStatement ps = conn.prepareStatement(
                "UPDATE ethernova_ranked SET season = ? WHERE season = ?")) {
            ps.setString(1, newSeason);
            ps.setString(2, oldSeason);
            ps.executeUpdate();
        }

        // Now compute soft reset for OFFLINE players (online ones will be overwritten by saveAllProfilesSync)
        java.util.Set<java.util.UUID> onlineUuids = plugin.getRankedManager().getProfiles().keySet();

        try (PreparedStatement selectPs = conn.prepareStatement(
                "SELECT uuid, elo FROM ethernova_ranked WHERE season = ?")) {
            selectPs.setString(1, newSeason);

            try (ResultSet rs = selectPs.executeQuery();
                 PreparedStatement updatePs = conn.prepareStatement(
                         "UPDATE ethernova_ranked SET elo = ?, rd = ?, volatility = ?, " +
                         "wins = 0, losses = 0, win_streak = 0, loss_streak = 0, " +
                         "placement_matches = 0, peak_rating = ? WHERE uuid = ? AND season = ?")) {

                while (rs.next()) {
                    java.util.UUID uuid = java.util.UUID.fromString(rs.getString("uuid"));

                    // Skip online players — they were already reset in memory
                    if (onlineUuids.contains(uuid)) continue;

                    // Compute soft reset for this offline player
                    int currentElo = rs.getInt("elo");
                    Rank currentRank = Rank.fromElo(currentElo);
                    Rank targetRank = currentRank;
                    for (int i = 0; i < dropRanks; i++) {
                        Rank prev = targetRank.previous();
                        if (prev != null) targetRank = prev;
                    }
                    int rankMin = targetRank.getMinElo();
                    int rankMax = targetRank.getMaxElo() == Integer.MAX_VALUE
                            ? targetRank.getMinElo() + 500 : targetRank.getMaxElo();
                    double regressionTarget = (currentElo + defaultRating) / 2.0;
                    int newElo = (int) Math.round(Math.max(rankMin, Math.min(rankMax, regressionTarget)));

                    updatePs.setInt(1, newElo);
                    updatePs.setDouble(2, resetRd);
                    updatePs.setDouble(3, resetVol);
                    updatePs.setInt(4, newElo); // peak_rating = new elo for fresh season
                    updatePs.setString(5, uuid.toString());
                    updatePs.setString(6, newSeason);
                    updatePs.addBatch();
                }
                updatePs.executeBatch();
            }
        }
    }

    /**
     * Archiva los rankings de la temporada actual en ethernova_ranked_history.
     */
    private int archiveCurrentSeason(Connection conn, String season) throws SQLException {
        String insertSql = """
            INSERT INTO ethernova_ranked_history (uuid, season, final_elo, final_rank, wins, losses, best_win_streak, archived_at)
            SELECT uuid, season, elo, ?, wins, losses, best_win_streak, ?
            FROM ethernova_ranked WHERE season = ?
        """;

        // Necesitamos calcular el rango para cada jugador, pero como es un INSERT SELECT
        // usamos un enfoque por lotes
        int count = 0;
        try (PreparedStatement selectPs = conn.prepareStatement(
                "SELECT uuid, elo, wins, losses, best_win_streak FROM ethernova_ranked WHERE season = ?")) {
            selectPs.setString(1, season);

            try (ResultSet rs = selectPs.executeQuery();
                 PreparedStatement insertPs = conn.prepareStatement(
                         "INSERT INTO ethernova_ranked_history (uuid, season, final_elo, final_rank, wins, losses, best_win_streak, archived_at) " +
                         "VALUES (?, ?, ?, ?, ?, ?, ?, ?)")) {

                long now = System.currentTimeMillis();
                while (rs.next()) {
                    int elo = rs.getInt("elo");
                    Rank rank = Rank.fromElo(elo);

                    insertPs.setString(1, rs.getString("uuid"));
                    insertPs.setString(2, season);
                    insertPs.setInt(3, elo);
                    insertPs.setString(4, rank.name());
                    insertPs.setInt(5, rs.getInt("wins"));
                    insertPs.setInt(6, rs.getInt("losses"));
                    insertPs.setInt(7, rs.getInt("best_win_streak"));
                    insertPs.setLong(8, now);
                    insertPs.addBatch();
                    count++;
                }
                if (count > 0) insertPs.executeBatch();
            }
        }
        return count;
    }

    /**
     * Obtiene estadísticas de la temporada actual.
     */
    public CompletableFuture<SeasonStats> getSeasonStats() {
        return CompletableFuture.supplyAsync(() -> {
            try (Connection conn = storage.getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "SELECT COUNT(*) as players, AVG(elo) as avg_elo, MAX(elo) as max_elo, " +
                         "SUM(wins + losses) as total_games FROM ethernova_ranked WHERE season = ?")) {
                ps.setString(1, currentSeason);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return new SeasonStats(
                                rs.getInt("players"),
                                (int) rs.getDouble("avg_elo"),
                                rs.getInt("max_elo"),
                                rs.getInt("total_games")
                        );
                    }
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Error obteniendo stats de temporada", e);
            }
            return new SeasonStats(0, 0, 0, 0);
        }, EthernovaCore.getInstance().getDbExecutor()).exceptionally(ex -> {
            plugin.getLogger().log(Level.SEVERE, "Unhandled error loading season stats", ex);
            return new SeasonStats(0, 0, 0, 0);
        });
    }

    /**
     * Estadísticas de la temporada.
     */
    public record SeasonStats(int totalPlayers, int averageElo, int highestElo, int totalGames) {}
}
