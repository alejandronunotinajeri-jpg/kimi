package com.ethernova.ranked.manager;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.storage.CoreStorageManager;
import com.ethernova.core.storage.MigrationManager;
import com.ethernova.ranked.EthernovaRanked;
import com.ethernova.ranked.elo.Glicko2Calculator;
import com.ethernova.ranked.elo.Glicko2Calculator.Glicko2Result;
import com.ethernova.ranked.message.MessageManager;
import com.ethernova.ranked.model.Rank;
import com.ethernova.ranked.model.RankedProfile;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Manager central del sistema Glicko-2 competitivo.
 * <p>
 * Gestiona perfiles, cálculos de rating, decay por inactividad,
 * modificadores de racha, protección ante demotion, anti-abuse,
 * match history, y persistencia en base de datos.
 * <p>
 * Thread-safety: processResult is synchronized per-player to prevent
 * concurrent rating updates from FFA/rapid kills.
 */
public class RankedManager {

    private final EthernovaRanked plugin;
    private final EthernovaCore core;
    private final CoreStorageManager storage;
    private final Glicko2Calculator calculator;
    private final MiniMessage mini = MiniMessage.miniMessage();
    private final ConcurrentHashMap<UUID, RankedProfile> profiles = new ConcurrentHashMap<>();

    /** Per-player locks for synchronized rating updates */
    private final ConcurrentHashMap<UUID, Object> playerLocks = new ConcurrentHashMap<>();

    /** Anti-abuse: tracks last opponent fought, key=attacker, value=(opponent, timestamp) */
    private final ConcurrentHashMap<UUID, OpponentRecord> lastOpponent = new ConcurrentHashMap<>();

    private record OpponentRecord(UUID opponent, long timestamp) {}

    private MessageManager mm() { return plugin.getMessageManager(); }

    // Cache del leaderboard
    private volatile List<LeaderboardEntry> leaderboardCache = new ArrayList<>();
    private volatile long leaderboardCacheTime = 0;
    private final long leaderboardCacheDuration;

    // Configuración de contextos permitidos
    private final Set<String> allowedContexts;

    // Configuración de decay
    private final boolean decayEnabled;
    private final long decayPeriodMs;
    private final int decayThresholdPeriods;
    private final double decayPerPeriod;

    // Configuración de demotion protection
    private final boolean demotionProtectionEnabled;
    private final int demotionShieldGames;

    // Anti-abuse config
    private final long sameOpponentCooldownMs;
    private final int leaderboardMinGames;

    public RankedManager(EthernovaRanked plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
        this.storage = core.getStorageManager();
        this.leaderboardCacheDuration = plugin.getConfig().getLong("leaderboard.cache-seconds", 30) * 1000L;

        // Cargar rangos desde config
        Rank.loadFromConfig(plugin.getConfig().getConfigurationSection("ranks"));

        // Configurar Glicko-2 desde config
        double tau = plugin.getConfig().getDouble("glicko2.tau", 0.5);
        double defaultRating = plugin.getConfig().getDouble("glicko2.default-rating", 1500.0);
        double defaultRd = plugin.getConfig().getDouble("glicko2.default-rd", 350.0);
        double defaultVol = plugin.getConfig().getDouble("glicko2.default-volatility", 0.06);
        double ratingFloor = plugin.getConfig().getDouble("glicko2.rating-floor", 0.0);
        double maxRd = plugin.getConfig().getDouble("glicko2.max-rd", 350.0);
        double minRd = plugin.getConfig().getDouble("glicko2.min-rd", 50.0);

        double streakBonusPerWin = plugin.getConfig().getDouble("streaks.bonus-per-win", 0.03);
        double streakBonusMax = plugin.getConfig().getDouble("streaks.bonus-max", 0.15);
        double streakProtectionPerLoss = plugin.getConfig().getDouble("streaks.protection-per-loss", 0.02);
        double streakProtectionMax = plugin.getConfig().getDouble("streaks.protection-max", 0.10);

        double placementMultiplier = plugin.getConfig().getDouble("placement.rating-multiplier", 1.5);

        this.calculator = new Glicko2Calculator(
                tau, defaultRating, defaultRd, defaultVol,
                ratingFloor, maxRd, minRd,
                streakBonusPerWin, streakBonusMax,
                streakProtectionPerLoss, streakProtectionMax,
                placementMultiplier);

        // Contextos permitidos para ranked
        List<String> contexts = plugin.getConfig().getStringList("ranked-contexts");
        if (contexts.isEmpty()) {
            contexts = List.of("duel", "ffa", "ranked");
        }
        this.allowedContexts = new HashSet<>(contexts);

        // Decay config
        this.decayEnabled = plugin.getConfig().getBoolean("decay.enabled", true);
        this.decayPeriodMs = plugin.getConfig().getLong("decay.period-days", 7) * 24 * 60 * 60 * 1000L;
        this.decayThresholdPeriods = plugin.getConfig().getInt("decay.threshold-periods", 2);
        this.decayPerPeriod = plugin.getConfig().getDouble("decay.rating-per-period", 15.0);

        // Demotion protection config
        this.demotionProtectionEnabled = plugin.getConfig().getBoolean("demotion-protection.enabled", true);
        this.demotionShieldGames = plugin.getConfig().getInt("demotion-protection.shield-games", 3);

        // Anti-abuse config
        this.sameOpponentCooldownMs = plugin.getConfig().getLong("anti-abuse.same-opponent-cooldown-seconds", 120) * 1000L;
        this.leaderboardMinGames = plugin.getConfig().getInt("leaderboard.min-games", 5);

        runMigrations();

        // Periodic cleanup of expired opponent cooldown entries (every 10 minutes)
        Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            long now = System.currentTimeMillis();
            lastOpponent.entrySet().removeIf(e -> now - e.getValue().timestamp() > sameOpponentCooldownMs);
        }, 12000L, 12000L); // 12000 ticks = 10 minutes
    }

    private void runMigrations() {
        boolean isMySQL = storage.isMySQL();

        new MigrationManager(storage, plugin.getLogger(), "ethernova_ranked")
                .addMigration(1,
                        """
                        CREATE TABLE IF NOT EXISTS ethernova_ranked (
                            uuid VARCHAR(36) NOT NULL,
                            season VARCHAR(32) NOT NULL,
                            elo INT NOT NULL DEFAULT 1000,
                            wins INT NOT NULL DEFAULT 0,
                            losses INT NOT NULL DEFAULT 0,
                            win_streak INT NOT NULL DEFAULT 0,
                            best_win_streak INT NOT NULL DEFAULT 0,
                            placement_matches INT NOT NULL DEFAULT 0,
                            updated_at BIGINT NOT NULL DEFAULT 0,
                            PRIMARY KEY (uuid, season)
                        )
                        """,
                        "CREATE INDEX IF NOT EXISTS idx_ranked_elo ON ethernova_ranked (season, elo DESC)",
                        "CREATE INDEX IF NOT EXISTS idx_ranked_uuid ON ethernova_ranked (uuid)"
                )
                .addMigration(2,
                        """
                        CREATE TABLE IF NOT EXISTS ethernova_ranked_history (
                            id INTEGER PRIMARY KEY %s,
                            uuid VARCHAR(36) NOT NULL,
                            season VARCHAR(32) NOT NULL,
                            final_elo INT NOT NULL,
                            final_rank VARCHAR(32) NOT NULL,
                            wins INT NOT NULL DEFAULT 0,
                            losses INT NOT NULL DEFAULT 0,
                            best_win_streak INT NOT NULL DEFAULT 0,
                            archived_at BIGINT NOT NULL DEFAULT 0
                        )
                        """.formatted(isMySQL ? "AUTO_INCREMENT" : "AUTOINCREMENT"),
                        "CREATE INDEX IF NOT EXISTS idx_ranked_history_uuid ON ethernova_ranked_history (uuid)"
                )
                // Migration 3: Glicko-2 columns
                .addMigration(3,
                        "ALTER TABLE ethernova_ranked ADD COLUMN rd DOUBLE NOT NULL DEFAULT 350.0",
                        "ALTER TABLE ethernova_ranked ADD COLUMN volatility DOUBLE NOT NULL DEFAULT 0.06",
                        "ALTER TABLE ethernova_ranked ADD COLUMN loss_streak INT NOT NULL DEFAULT 0",
                        "ALTER TABLE ethernova_ranked ADD COLUMN last_played BIGINT NOT NULL DEFAULT 0"
                )
                // Migration 4: Peak rating + match log
                .addMigration(4,
                        "ALTER TABLE ethernova_ranked ADD COLUMN peak_rating INT NOT NULL DEFAULT 1500",
                        """
                        CREATE TABLE IF NOT EXISTS ethernova_ranked_matches (
                            id INTEGER PRIMARY KEY %s,
                            winner_uuid VARCHAR(36) NOT NULL,
                            loser_uuid VARCHAR(36) NOT NULL,
                            season VARCHAR(32) NOT NULL,
                            winner_rating_before INT NOT NULL,
                            winner_rating_after INT NOT NULL,
                            loser_rating_before INT NOT NULL,
                            loser_rating_after INT NOT NULL,
                            winner_rd INT NOT NULL,
                            loser_rd INT NOT NULL,
                            match_time BIGINT NOT NULL
                        )
                        """.formatted(isMySQL ? "AUTO_INCREMENT" : "AUTOINCREMENT"),
                        "CREATE INDEX IF NOT EXISTS idx_matches_winner ON ethernova_ranked_matches (winner_uuid, season)",
                        "CREATE INDEX IF NOT EXISTS idx_matches_loser ON ethernova_ranked_matches (loser_uuid, season)",
                        "CREATE INDEX IF NOT EXISTS idx_matches_time ON ethernova_ranked_matches (match_time DESC)"
                )
                .migrate();
    }

    /**
     * Obtiene el perfil de un jugador desde la caché.
     */
    public RankedProfile getProfile(UUID uuid) {
        return profiles.get(uuid);
    }

    /**
     * Verifica si un contexto de kill está permitido para dar ELO.
     */
    public boolean isAllowedContext(String context) {
        if (context == null) return false;
        return allowedContexts.contains(context.toLowerCase(Locale.ROOT));
    }

    /**
     * Carga el perfil de un jugador desde la base de datos de forma asíncrona.
     */
    public CompletableFuture<RankedProfile> loadProfile(UUID uuid) {
        return CompletableFuture.supplyAsync(() -> {
            String season = plugin.getSeasonManager().getCurrentSeason();
            double startRating = calculator.getDefaultRating();
            double startRd = calculator.getDefaultRd();
            double startVol = calculator.getDefaultVolatility();

            try (Connection conn = storage.getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "SELECT elo, rd, volatility, wins, losses, win_streak, loss_streak, " +
                         "best_win_streak, peak_rating, placement_matches, last_played " +
                         "FROM ethernova_ranked WHERE uuid = ? AND season = ?")) {
                ps.setString(1, uuid.toString());
                ps.setString(2, season);

                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        double rd = rs.getDouble("rd");
                        double vol = rs.getDouble("volatility");
                        long lastPlayed = rs.getLong("last_played");
                        int peakRating = rs.getInt("peak_rating");

                        // Aplicar RD decay por inactividad al cargar
                        if (decayEnabled && lastPlayed > 0) {
                            long inactiveMs = System.currentTimeMillis() - lastPlayed;
                            if (inactiveMs > 0 && decayPeriodMs > 0) {
                                int periods = (int) (inactiveMs / decayPeriodMs);
                                if (periods > 0) {
                                    rd = calculator.decayRd(rd, vol, periods);
                                }
                            }
                        }

                        RankedProfile profile = new RankedProfile(
                                uuid,
                                rs.getInt("elo"),
                                rd,
                                vol,
                                rs.getInt("wins"),
                                rs.getInt("losses"),
                                rs.getInt("win_streak"),
                                rs.getInt("loss_streak"),
                                rs.getInt("best_win_streak"),
                                peakRating,
                                season,
                                rs.getInt("placement_matches"),
                                lastPlayed
                        );

                        // Aplicar rating decay si está habilitado
                        if (decayEnabled && lastPlayed > 0) {
                            long inactiveMs = System.currentTimeMillis() - lastPlayed;
                            if (inactiveMs > 0 && decayPeriodMs > 0) {
                                int periods = (int) (inactiveMs / decayPeriodMs);
                                if (periods > decayThresholdPeriods) {
                                    double decayed = calculator.decayRating(
                                            profile.getRating(), periods,
                                            decayThresholdPeriods, decayPerPeriod);
                                    if (decayed < profile.getRating()) {
                                        profile.setRating(decayed);
                                        profile.setRd(rd);
                                        plugin.getLogger().info("Decay aplicado a " + uuid +
                                                ": " + rs.getInt("elo") + " → " + profile.getElo() +
                                                " (RD: " + (int) rd + ")");
                                    }
                                }
                            }
                        }

                        // Grant demotion shield if at rank boundary
                        if (demotionProtectionEnabled) {
                            Rank rank = profile.getCurrentRank();
                            int eloAboveMin = profile.getElo() - rank.getMinElo();
                            if (eloAboveMin < 50 && rank.previous() != null) {
                                profile.setDemotionShield(demotionShieldGames);
                            }
                        }

                        profiles.put(uuid, profile);
                        return profile;
                    }
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Error cargando perfil ranked de " + uuid, e);
            }

            // Crear nuevo perfil si no existe
            RankedProfile newProfile = RankedProfile.createNew(uuid, startRating, startRd, startVol, season);
            profiles.put(uuid, newProfile);
            saveProfileSync(newProfile);
            return newProfile;
        }, core.getDbExecutor()).exceptionally(ex -> {
            plugin.getLogger().log(Level.SEVERE, "Unhandled error loading ranked profile " + uuid, ex);
            RankedProfile fallback = RankedProfile.createNew(uuid, (int) calculator.getDefaultRating(),
                    plugin.getSeasonManager().getCurrentSeason());
            profiles.put(uuid, fallback);
            return fallback;
        });
    }

    /**
     * Guarda el perfil de forma asíncrona.
     */
    public CompletableFuture<Void> saveProfile(RankedProfile profile) {
        if (!profile.isDirty()) return CompletableFuture.completedFuture(null);
        return CompletableFuture.runAsync(() -> saveProfileSync(profile), core.getDbExecutor()).exceptionally(ex -> {
            plugin.getLogger().log(Level.SEVERE, "Unhandled error saving ranked profile", ex);
            return null;
        });
    }

    /**
     * Guarda el perfil de forma síncrona (usar dentro de hilos async).
     */
    private void saveProfileSync(RankedProfile profile) {
        String sql;
        if (storage.isMySQL()) {
            sql = """
                INSERT INTO ethernova_ranked (uuid, season, elo, rd, volatility, wins, losses,
                    win_streak, loss_streak, best_win_streak, peak_rating, placement_matches, updated_at, last_played)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE elo = VALUES(elo), rd = VALUES(rd), volatility = VALUES(volatility),
                    wins = VALUES(wins), losses = VALUES(losses),
                    win_streak = VALUES(win_streak), loss_streak = VALUES(loss_streak),
                    best_win_streak = VALUES(best_win_streak), peak_rating = VALUES(peak_rating),
                    placement_matches = VALUES(placement_matches), updated_at = VALUES(updated_at),
                    last_played = VALUES(last_played)
            """;
        } else {
            sql = """
                INSERT INTO ethernova_ranked (uuid, season, elo, rd, volatility, wins, losses,
                    win_streak, loss_streak, best_win_streak, peak_rating, placement_matches, updated_at, last_played)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(uuid, season) DO UPDATE SET elo = excluded.elo, rd = excluded.rd,
                    volatility = excluded.volatility,
                    wins = excluded.wins, losses = excluded.losses,
                    win_streak = excluded.win_streak, loss_streak = excluded.loss_streak,
                    best_win_streak = excluded.best_win_streak, peak_rating = excluded.peak_rating,
                    placement_matches = excluded.placement_matches, updated_at = excluded.updated_at,
                    last_played = excluded.last_played
            """;
        }

        try (Connection conn = storage.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, profile.getUuid().toString());
            ps.setString(2, profile.getSeason());
            ps.setInt(3, profile.getElo());
            ps.setDouble(4, profile.getRd());
            ps.setDouble(5, profile.getVolatility());
            ps.setInt(6, profile.getWins());
            ps.setInt(7, profile.getLosses());
            ps.setInt(8, profile.getWinStreak());
            ps.setInt(9, profile.getLossStreak());
            ps.setInt(10, profile.getBestWinStreak());
            ps.setInt(11, profile.getPeakRating());
            ps.setInt(12, profile.getPlacementMatchesPlayed());
            ps.setLong(13, System.currentTimeMillis());
            ps.setLong(14, profile.getLastPlayed());
            ps.executeUpdate();
            profile.setDirty(false);
        } catch (SQLException e) {
            plugin.getLogger().log(Level.SEVERE, "Error guardando perfil ranked de " + profile.getUuid(), e);
        }
    }

    /**
     * Procesa el resultado de un combate entre dos jugadores usando Glicko-2.
     * Synchronized per-player to prevent concurrent rating corruption in FFA.
     * Includes demotion protection, anti-abuse, and match history logging.
     */
    public void processResult(UUID winnerId, UUID loserId) {
        // Guard: self-kill should never count
        if (winnerId.equals(loserId)) return;

        // Anti-abuse: same opponent cooldown
        if (sameOpponentCooldownMs > 0) {
            long now = System.currentTimeMillis();
            OpponentRecord lastW = lastOpponent.get(winnerId);
            OpponentRecord lastL = lastOpponent.get(loserId);
            if ((lastW != null && lastW.opponent.equals(loserId) && now - lastW.timestamp < sameOpponentCooldownMs) ||
                (lastL != null && lastL.opponent.equals(winnerId) && now - lastL.timestamp < sameOpponentCooldownMs)) {
                // Cooldown active — skip rating change but still count as a match
                plugin.getLogger().fine("Anti-abuse: cooldown active between " + winnerId + " and " + loserId);
                return;
            }
            lastOpponent.put(winnerId, new OpponentRecord(loserId, now));
            lastOpponent.put(loserId, new OpponentRecord(winnerId, now));
        }

        // Acquire locks in consistent order to prevent deadlocks
        Object lockA, lockB;
        UUID first, second;
        if (winnerId.compareTo(loserId) < 0) {
            first = winnerId; second = loserId;
        } else {
            first = loserId; second = winnerId;
        }
        lockA = playerLocks.computeIfAbsent(first, k -> new Object());
        lockB = playerLocks.computeIfAbsent(second, k -> new Object());

        synchronized (lockA) {
            synchronized (lockB) {
                processResultLocked(winnerId, loserId);
            }
        }
    }

    private void processResultLocked(UUID winnerId, UUID loserId) {
        RankedProfile winner = profiles.get(winnerId);
        RankedProfile loser = profiles.get(loserId);
        if (winner == null || loser == null) {
            plugin.getLogger().warning("processResult: perfil null para " +
                    (winner == null ? winnerId : loserId) + " — resultado descartado");
            return;
        }

        double oldWinnerRating = winner.getRating();
        double oldLoserRating = loser.getRating();
        Rank oldWinnerRank = winner.getCurrentRank();
        Rank oldLoserRank = loser.getCurrentRank();

        // Determinar si es partida de colocación
        int placementMatches = plugin.getConfig().getInt("placement.matches", 10);
        boolean winnerInPlacements = winner.isInPlacements(placementMatches);
        boolean loserInPlacements = loser.isInPlacements(placementMatches);

        // Calcular nuevos ratings con Glicko-2
        Glicko2Result[] results = calculator.processMatch(
                winner.getRating(), winner.getRd(), winner.getVolatility(),
                winner.getWinStreak(), winnerInPlacements,
                loser.getRating(), loser.getRd(), loser.getVolatility(),
                loser.getLossStreak(), loserInPlacements
        );

        Glicko2Result winnerResult = results[0];
        Glicko2Result loserResult = results[1];

        // Actualizar ganador
        winner.setRating(winnerResult.rating());
        winner.setRd(winnerResult.rd());
        winner.setVolatility(winnerResult.volatility());
        winner.addWin();
        if (winnerInPlacements) winner.incrementPlacementMatches();

        // Demotion protection for loser
        boolean demotionBlocked = false;
        double proposedLoserRating = loserInPlacements
                ? oldLoserRating + (loserResult.rating() - oldLoserRating) / 2.0
                : loserResult.rating();

        if (demotionProtectionEnabled && !loserInPlacements) {
            Rank proposedRank = Rank.fromElo((int) Math.round(proposedLoserRating));
            if (!proposedRank.equals(oldLoserRank) && oldLoserRank.previous() != null) {
                // Would demote — check shield
                if (loser.consumeDemotionShield()) {
                    // Shield consumed — clamp to rank minimum
                    proposedLoserRating = oldLoserRank.getMinElo();
                    demotionBlocked = true;
                }
            }
        }

        // Actualizar perdedor
        if (loserInPlacements) {
            double halfLoss = (loserResult.rating() - oldLoserRating) / 2.0;
            loser.setRating(oldLoserRating + halfLoss);
            loser.setRd(loserResult.rd());
            loser.setVolatility(loserResult.volatility());
            loser.incrementPlacementMatches();
        } else {
            loser.setRating(proposedLoserRating);
            loser.setRd(loserResult.rd());
            loser.setVolatility(loserResult.volatility());
        }
        loser.addLoss();

        // Grant demotion shield on promotion
        if (demotionProtectionEnabled && !winner.getCurrentRank().equals(oldWinnerRank)) {
            winner.setDemotionShield(demotionShieldGames);
        }

        // Log match to history
        logMatchHistory(winnerId, loserId, (int) Math.round(oldWinnerRating), winner.getElo(),
                (int) Math.round(oldLoserRating), loser.getElo(),
                (int) Math.round(winner.getRd()), (int) Math.round(loser.getRd()));

        // Guardar async
        saveProfile(winner);
        saveProfile(loser);

        // Calcular cambios finales
        int winnerChange = winner.getElo() - (int) Math.round(oldWinnerRating);
        int loserChange = loser.getElo() - (int) Math.round(oldLoserRating);
        final boolean finalDemotionBlocked = demotionBlocked;

        // Notificar vía action bar
        Bukkit.getScheduler().runTask(plugin, () -> {
            Player winnerPlayer = Bukkit.getPlayer(winnerId);
            Player loserPlayer = Bukkit.getPlayer(loserId);

            if (winnerPlayer != null) {
                String msg = mm().get("result.elo-gain",
                        "{change}", String.valueOf(winnerChange),
                        "{elo}", String.valueOf(winner.getElo()));

                if (!winner.getCurrentRank().equals(oldWinnerRank)) {
                    msg += " " + mm().get("result.rank-up",
                            "{rank}", winner.getCurrentRank().getColoredName());
                    core.getSoundManager().play(winnerPlayer, "level_up");
                } else {
                    core.getSoundManager().play(winnerPlayer, "kill");
                }

                winnerPlayer.sendActionBar(mini.deserialize(msg));

                if (winner.getWinStreak() >= 3) {
                    mm().sendMessage(winnerPlayer, "result.win-streak",
                            "{streak}", String.valueOf(winner.getWinStreak()));
                    if (winner.getWinStreak() % 5 == 0) {
                        core.getSoundManager().play(winnerPlayer, "streak");
                    }
                }
            }

            if (loserPlayer != null) {
                String msg;
                if (loserInPlacements) {
                    msg = mm().get("result.placement-match",
                            "{played}", String.valueOf(loser.getPlacementMatchesPlayed()),
                            "{total}", String.valueOf(placementMatches));
                } else if (finalDemotionBlocked) {
                    msg = mm().get("result.elo-loss",
                            "{change}", String.valueOf(loserChange),
                            "{elo}", String.valueOf(loser.getElo()));
                    msg += " " + mm().get("result.demotion-shield");
                } else {
                    msg = mm().get("result.elo-loss",
                            "{change}", String.valueOf(loserChange),
                            "{elo}", String.valueOf(loser.getElo()));
                }

                if (!loser.getCurrentRank().equals(oldLoserRank) && !loserInPlacements) {
                    msg += " " + mm().get("result.rank-down",
                            "{rank}", loser.getCurrentRank().getColoredName());
                    core.getSoundManager().play(loserPlayer, "death");
                } else {
                    core.getSoundManager().play(loserPlayer, "error");
                }

                loserPlayer.sendActionBar(mini.deserialize(msg));
            }
        });

        // Invalidar caché del leaderboard
        leaderboardCacheTime = 0;
    }

    /**
     * Logs a match result to the match history table.
     */
    private void logMatchHistory(UUID winnerId, UUID loserId,
                                  int winnerBefore, int winnerAfter,
                                  int loserBefore, int loserAfter,
                                  int winnerRd, int loserRd) {
        CompletableFuture.runAsync(() -> {
            try (Connection conn = storage.getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "INSERT INTO ethernova_ranked_matches " +
                         "(winner_uuid, loser_uuid, season, winner_rating_before, winner_rating_after, " +
                         "loser_rating_before, loser_rating_after, winner_rd, loser_rd, match_time) " +
                         "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
                ps.setString(1, winnerId.toString());
                ps.setString(2, loserId.toString());
                ps.setString(3, plugin.getSeasonManager().getCurrentSeason());
                ps.setInt(4, winnerBefore);
                ps.setInt(5, winnerAfter);
                ps.setInt(6, loserBefore);
                ps.setInt(7, loserAfter);
                ps.setInt(8, winnerRd);
                ps.setInt(9, loserRd);
                ps.setLong(10, System.currentTimeMillis());
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Error logging match history", e);
            }
        }, core.getDbExecutor()).exceptionally(ex -> {
            plugin.getLogger().log(Level.WARNING, "Unhandled error logging match history", ex);
            return null;
        });
    }

    /**
     * Checks if a match between two players is on anti-abuse cooldown.
     */
    public boolean isOnCooldown(UUID player1, UUID player2) {
        if (sameOpponentCooldownMs <= 0) return false;
        long now = System.currentTimeMillis();
        OpponentRecord rec = lastOpponent.get(player1);
        return rec != null && rec.opponent.equals(player2) && now - rec.timestamp < sameOpponentCooldownMs;
    }

    /**
     * Obtiene el leaderboard con cacheo.
     */
    public CompletableFuture<List<LeaderboardEntry>> getLeaderboard(int limit) {
        if (System.currentTimeMillis() - leaderboardCacheTime < leaderboardCacheDuration
                && !leaderboardCache.isEmpty()) {
            return CompletableFuture.completedFuture(leaderboardCache);
        }

        return CompletableFuture.supplyAsync(() -> {
            List<LeaderboardEntry> entries = new ArrayList<>();
            String season = plugin.getSeasonManager().getCurrentSeason();

            try (Connection conn = storage.getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "SELECT r.uuid, p.name, r.elo, r.rd, r.wins, r.losses, r.best_win_streak " +
                         "FROM ethernova_ranked r " +
                         "LEFT JOIN ethernova_profiles p ON r.uuid = p.uuid " +
                         "WHERE r.season = ? AND (r.wins + r.losses) >= ? ORDER BY r.elo DESC LIMIT ?")) {
                ps.setString(1, season);
                ps.setInt(2, leaderboardMinGames);
                ps.setInt(3, limit);

                try (ResultSet rs = ps.executeQuery()) {
                    int position = 1;
                    while (rs.next()) {
                        entries.add(new LeaderboardEntry(
                                position++,
                                UUID.fromString(rs.getString("uuid")),
                                rs.getString("name") != null ? rs.getString("name") : mm().get("gui.leaderboard.unknown-name"),
                                rs.getInt("elo"),
                                (int) Math.round(rs.getDouble("rd")),
                                rs.getInt("wins"),
                                rs.getInt("losses"),
                                rs.getInt("best_win_streak"),
                                Rank.fromElo(rs.getInt("elo"))
                        ));
                    }
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Error cargando leaderboard", e);
            }

            leaderboardCache = entries;
            leaderboardCacheTime = System.currentTimeMillis();
            return entries;
        }, core.getDbExecutor()).exceptionally(ex -> {
            plugin.getLogger().log(Level.SEVERE, "Unhandled error loading ranked leaderboard", ex);
            return new ArrayList<>();
        });
    }

    /**
     * Guarda todos los perfiles sucios usando JDBC batch para eficiencia.
     */
    public void saveAll() {
        List<RankedProfile> dirty = profiles.values().stream()
                .filter(RankedProfile::isDirty)
                .collect(java.util.stream.Collectors.toList());
        if (dirty.isEmpty()) return;

        String sql;
        if (storage.isMySQL()) {
            sql = """
                INSERT INTO ethernova_ranked (uuid, season, elo, rd, volatility, wins, losses,
                    win_streak, loss_streak, best_win_streak, peak_rating, placement_matches, updated_at, last_played)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE elo = VALUES(elo), rd = VALUES(rd), volatility = VALUES(volatility),
                    wins = VALUES(wins), losses = VALUES(losses),
                    win_streak = VALUES(win_streak), loss_streak = VALUES(loss_streak),
                    best_win_streak = VALUES(best_win_streak), peak_rating = VALUES(peak_rating),
                    placement_matches = VALUES(placement_matches), updated_at = VALUES(updated_at),
                    last_played = VALUES(last_played)
            """;
        } else {
            sql = """
                INSERT INTO ethernova_ranked (uuid, season, elo, rd, volatility, wins, losses,
                    win_streak, loss_streak, best_win_streak, peak_rating, placement_matches, updated_at, last_played)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(uuid, season) DO UPDATE SET elo = excluded.elo, rd = excluded.rd,
                    volatility = excluded.volatility,
                    wins = excluded.wins, losses = excluded.losses,
                    win_streak = excluded.win_streak, loss_streak = excluded.loss_streak,
                    best_win_streak = excluded.best_win_streak, peak_rating = excluded.peak_rating,
                    placement_matches = excluded.placement_matches, updated_at = excluded.updated_at,
                    last_played = excluded.last_played
            """;
        }

        try (Connection conn = storage.getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                long now = System.currentTimeMillis();
                for (RankedProfile p : dirty) {
                    ps.setString(1, p.getUuid().toString());
                    ps.setString(2, p.getSeason());
                    ps.setInt(3, p.getElo());
                    ps.setDouble(4, p.getRd());
                    ps.setDouble(5, p.getVolatility());
                    ps.setInt(6, p.getWins());
                    ps.setInt(7, p.getLosses());
                    ps.setInt(8, p.getWinStreak());
                    ps.setInt(9, p.getLossStreak());
                    ps.setInt(10, p.getBestWinStreak());
                    ps.setInt(11, p.getPeakRating());
                    ps.setInt(12, p.getPlacementMatchesPlayed());
                    ps.setLong(13, now);
                    ps.setLong(14, p.getLastPlayed());
                    ps.addBatch();
                }
                ps.executeBatch();
                conn.commit();
                dirty.forEach(p -> p.setDirty(false));
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            plugin.getLogger().log(Level.SEVERE, "Error in batch save of ranked profiles", e);
            // Mark dirty again so next save retries
            dirty.forEach(p -> p.setDirty(true));
        }
    }

    /**
     * Descarga el perfil de un jugador (al salir del servidor).
     */
    public void unloadProfile(UUID uuid) {
        RankedProfile profile = profiles.remove(uuid);
        playerLocks.remove(uuid);
        // Keep lastOpponent data — cooldown must persist across logout/login to prevent abuse
        if (profile != null && profile.isDirty()) {
            CompletableFuture.runAsync(() -> saveProfileSync(profile), core.getDbExecutor()).exceptionally(ex -> {
                plugin.getLogger().log(Level.SEVERE, "Unhandled error saving ranked profile on unload", ex);
                return null;
            });
        }
    }

    /**
     * Obtiene el rango de un jugador.
     */
    public Rank getRank(UUID uuid) {
        RankedProfile profile = profiles.get(uuid);
        return profile != null ? profile.getCurrentRank() : Rank.lowest();
    }

    public Glicko2Calculator getCalculator() { return calculator; }

    public ConcurrentHashMap<UUID, RankedProfile> getProfiles() { return profiles; }

    /**
     * Guarda TODOS los perfiles dirty de forma síncrona. Usado por soft reset de temporada.
     * Uses batch save for efficiency.
     */
    public void saveAllProfilesSync() {
        saveAll();
    }

    /**
     * Resetea todos los perfiles en memoria.
     * Usa soft reset si está habilitado en config, si no hard reset.
     */
    public void resetAllProfiles(String newSeason) {
        boolean softReset = plugin.getConfig().getBoolean("season.soft-reset.enabled", true);
        if (softReset) {
            int dropRanks = plugin.getConfig().getInt("season.soft-reset.drop-ranks", 2);
            double resetRd = plugin.getConfig().getDouble("season.soft-reset.rd-after-reset", 200.0);
            double resetVol = calculator.getDefaultVolatility();
            double defaultRating = calculator.getDefaultRating();
            profiles.values().forEach(p -> p.softResetForNewSeason(dropRanks, resetRd, resetVol, newSeason, defaultRating));
        } else {
            double startRating = calculator.getDefaultRating();
            double startRd = calculator.getDefaultRd();
            double startVol = calculator.getDefaultVolatility();
            profiles.values().forEach(p -> p.resetForNewSeason(startRating, startRd, startVol, newSeason));
        }
    }

    /**
     * Invalida la caché del leaderboard.
     */
    public void invalidateLeaderboard() {
        leaderboardCacheTime = 0;
    }

    /**
     * Entrada del leaderboard.
     */
    public record LeaderboardEntry(
            int position,
            UUID uuid,
            String name,
            int elo,
            int rd,
            int wins,
            int losses,
            int bestWinStreak,
            Rank rank
    ) {
        public int totalGames() { return wins + losses; }
        public double winRate() { return totalGames() == 0 ? 0.0 : (double) wins / totalGames(); }
        public String winRateFormatted() { return String.format("%.1f%%", winRate() * 100); }
        public String confidenceInterval() {
            int lower = Math.max(0, (int) Math.round(elo - 1.96 * rd));
            int upper = (int) Math.round(elo + 1.96 * rd);
            return lower + " - " + upper;
        }
    }
}
