package com.ethernova.ranked.elo;

/**
 * Implementación completa del algoritmo Glicko-2 (Mark Glickman, 2012).
 * <p>
 * A diferencia de ELO estándar, Glicko-2 maneja tres valores para cada jugador:
 * <ul>
 *     <li><b>Rating (μ)</b> — Habilidad estimada (equivalente a ELO, pero en escala interna)</li>
 *     <li><b>Rating Deviation (RD/φ)</b> — Incertidumbre. Alto = poco confiable, Bajo = confiable</li>
 *     <li><b>Volatility (σ)</b> — Consistencia. Mide cuánto fluctúa el rendimiento del jugador</li>
 * </ul>
 * <p>
 * El RD crece con el tiempo de inactividad (decay natural), haciendo que jugadores
 * inactivos tengan ratings menos confiables y cambios más grandes al volver.
 * <p>
 * Escala interna: μ = (Rating - 1500) / 173.7178, φ = RD / 173.7178
 * Esto convierte la escala Glicko (centrada en 1500) a la escala Glicko-2 interna.
 *
 * @see <a href="http://www.glicko.net/glicko/glicko2.pdf">Glicko-2 Paper</a>
 */
public final class Glicko2Calculator {

    // ═══════════════ Constantes Glicko-2 ═══════════════

    /** Factor de escala para convertir entre Glicko y Glicko-2. */
    private static final double SCALE = 173.7178;

    /** Tolerancia para convergencia del algoritmo iterativo. */
    private static final double CONVERGENCE_TOLERANCE = 0.000001;

    /** Máximo de iteraciones para el paso de volatilidad (seguridad). */
    private static final int MAX_ITERATIONS = 100;

    // ═══════════════ Parámetros configurables ═══════════════

    /** Constrains volatility change (τ). Recomendado entre 0.3 y 1.2. */
    private final double tau;

    /** Rating por defecto para nuevos jugadores. */
    private final double defaultRating;

    /** RD por defecto para nuevos jugadores (máxima incertidumbre). */
    private final double defaultRd;

    /** Volatilidad por defecto para nuevos jugadores. */
    private final double defaultVolatility;

    /** Rating mínimo (floor). */
    private final double ratingFloor;

    /** RD máximo (para players totalmente inactivos). */
    private final double maxRd;

    /** RD mínimo (para players con muchos juegos). */
    private final double minRd;

    // ═══════════════ Streak modifiers ═══════════════

    /** Bonus multiplicador por racha de victorias. */
    private final double streakBonusPerWin;

    /** Máximo bonus por racha (cap). */
    private final double streakBonusMax;

    /** Protección multiplicadora por racha de derrotas. */
    private final double streakProtectionPerLoss;

    /** Máxima protección por racha de derrotas (cap). */
    private final double streakProtectionMax;

    // ═══════════════ Placement modifiers ═══════════════

    /** Multiplicador de cambio de rating durante placements. */
    private final double placementMultiplier;

    public Glicko2Calculator(double tau, double defaultRating, double defaultRd, double defaultVolatility,
                             double ratingFloor, double maxRd, double minRd,
                             double streakBonusPerWin, double streakBonusMax,
                             double streakProtectionPerLoss, double streakProtectionMax,
                             double placementMultiplier) {
        this.tau = tau;
        this.defaultRating = defaultRating;
        this.defaultRd = defaultRd;
        this.defaultVolatility = defaultVolatility;
        this.ratingFloor = ratingFloor;
        this.maxRd = maxRd;
        this.minRd = minRd;
        this.streakBonusPerWin = streakBonusPerWin;
        this.streakBonusMax = streakBonusMax;
        this.streakProtectionPerLoss = streakProtectionPerLoss;
        this.streakProtectionMax = streakProtectionMax;
        this.placementMultiplier = placementMultiplier;
    }

    /**
     * Constructor con valores por defecto competitivos.
     */
    public Glicko2Calculator() {
        this(0.5,        // tau (moderado)
             1500.0,     // defaultRating
             350.0,      // defaultRd (alta incertidumbre para nuevos)
             0.06,       // defaultVolatility
             0.0,        // ratingFloor
             350.0,      // maxRd
             50.0,       // minRd
             0.03,       // streakBonusPerWin (+3% por win consecutiva)
             0.15,       // streakBonusMax (máximo +15%)
             0.02,       // streakProtectionPerLoss (-2% pérdida por loss consecutiva)
             0.10,       // streakProtectionMax (máximo -10%)
             1.5);       // placementMultiplier (x1.5 durante placements)
    }

    // ═══════════════ Cálculo principal ═══════════════

    /**
     * Resultado de un cálculo Glicko-2.
     *
     * @param rating      Nuevo rating (escala Glicko/display)
     * @param rd          Nuevo Rating Deviation
     * @param volatility  Nueva volatilidad
     * @param ratingChange  Cambio de rating respecto al anterior
     */
    public record Glicko2Result(double rating, double rd, double volatility, int ratingChange) {
        /** Rating redondeado como entero para display. */
        public int displayRating() {
            return (int) Math.round(rating);
        }

        /** RD redondeado como entero para display. */
        public int displayRd() {
            return (int) Math.round(rd);
        }
    }

    /**
     * Calcula nuevos ratings para ganador y perdedor tras un resultado 1v1.
     *
     * @param winnerRating      Rating actual del ganador
     * @param winnerRd          RD actual del ganador
     * @param winnerVolatility  Volatilidad actual del ganador
     * @param winnerStreak      Racha de victorias actual del ganador (pre-match)
     * @param winnerInPlacement ¿Está en placements?
     * @param loserRating       Rating actual del perdedor
     * @param loserRd           RD actual del perdedor
     * @param loserVolatility   Volatilidad actual del perdedor
     * @param loserStreak       Racha de derrotas actual del perdedor (pre-match, usar 0 si tiene winstreak)
     * @param loserInPlacement  ¿Está en placements?
     * @return Glicko2Result[2] donde [0] = ganador, [1] = perdedor
     */
    public Glicko2Result[] processMatch(double winnerRating, double winnerRd, double winnerVolatility,
                                        int winnerStreak, boolean winnerInPlacement,
                                        double loserRating, double loserRd, double loserVolatility,
                                        int loserStreak, boolean loserInPlacement) {
        // Step 1: Convertir a escala Glicko-2
        double muW = toGlicko2(winnerRating);
        double phiW = winnerRd / SCALE;
        double muL = toGlicko2(loserRating);
        double phiL = loserRd / SCALE;

        // Step 2: Calcular nuevos valores para el ganador (score = 1.0)
        Glicko2Result winnerResult = calculateNewRating(
                muW, phiW, winnerVolatility, muL, phiL, 1.0,
                winnerStreak, true, winnerInPlacement, winnerRating);

        // Step 3: Calcular nuevos valores para el perdedor (score = 0.0)
        Glicko2Result loserResult = calculateNewRating(
                muL, phiL, loserVolatility, muW, phiW, 0.0,
                loserStreak, false, loserInPlacement, loserRating);

        return new Glicko2Result[]{winnerResult, loserResult};
    }

    /**
     * Calcula el nuevo rating para un jugador después de un resultado.
     * Implementación del algoritmo Glicko-2 completo (pasos 3-8 del paper).
     *
     * @param mu               Rating del jugador (escala Glicko-2)
     * @param phi              RD del jugador (escala Glicko-2)
     * @param sigma            Volatilidad del jugador
     * @param muOpponent       Rating del oponente (escala Glicko-2)
     * @param phiOpponent      RD del oponente (escala Glicko-2)
     * @param score            1.0 para victoria, 0.0 para derrota
     * @param streak           Racha actual
     * @param isWin            Si es victoria
     * @param inPlacement      Si está en placements
     * @param originalRating   Rating original antes del cálculo (escala display)
     */
    private Glicko2Result calculateNewRating(double mu, double phi, double sigma,
                                              double muOpponent, double phiOpponent, double score,
                                              int streak, boolean isWin, boolean inPlacement,
                                              double originalRating) {
        // Step 3: g(φ) y E(μ, μj, φj)
        double g = g(phiOpponent);
        double e = E(mu, muOpponent, g);

        // Step 4: Estimated variance (v)
        double v = 1.0 / (g * g * e * (1.0 - e));

        // Step 5: Estimated improvement (Δ)
        double delta = v * g * (score - e);

        // Step 6: Compute new volatility (σ')
        double newSigma = computeNewVolatility(phi, sigma, delta, v);

        // Step 7: Update RD with new volatility — pre-rating period φ*
        double phiStar = Math.sqrt(phi * phi + newSigma * newSigma);

        // Step 8: Update rating and RD
        double newPhi = 1.0 / Math.sqrt(1.0 / (phiStar * phiStar) + 1.0 / v);
        double newMu = mu + newPhi * newPhi * g * (score - e);

        // Convertir de vuelta a escala display
        double newRating = fromGlicko2(newMu);
        double newRd = newPhi * SCALE;

        // Clamp RD dentro de límites
        newRd = Math.max(minRd, Math.min(maxRd, newRd));

        // Aplicar modificadores de racha
        double ratingChange = newRating - originalRating;
        if (isWin && streak > 0) {
            double bonus = Math.min(streakBonusMax, streakBonusPerWin * streak);
            ratingChange *= (1.0 + bonus);
        } else if (!isWin && streak > 0) {
            double protection = Math.min(streakProtectionMax, streakProtectionPerLoss * streak);
            ratingChange *= (1.0 - protection);
        }

        // Aplicar multiplicador de placement
        if (inPlacement) {
            ratingChange *= placementMultiplier;
        }

        // Calcular rating final
        newRating = originalRating + ratingChange;

        // Garantizar mínimo ±1
        if (isWin && newRating <= originalRating) {
            newRating = originalRating + 1;
        } else if (!isWin && newRating >= originalRating) {
            newRating = originalRating - 1;
        }

        // Aplicar floor
        newRating = Math.max(ratingFloor, newRating);

        // Calcular cambio entero y garantizar mínimo ±1 tras redondeo
        int change = (int) Math.round(newRating - originalRating);
        if (isWin && change < 1) {
            change = 1;
            newRating = originalRating + 1;
        } else if (!isWin && change > -1) {
            change = -1;
            newRating = originalRating - 1;
        }
        newRating = Math.max(ratingFloor, newRating);

        return new Glicko2Result(newRating, newRd, newSigma, change);
    }

    // ═══════════════ Funciones auxiliares Glicko-2 ═══════════════

    /**
     * Función g(φ) — reduce el impacto del oponente según su incertidumbre.
     * Un oponente con alto RD tiene menos impacto.
     */
    private double g(double phi) {
        return 1.0 / Math.sqrt(1.0 + 3.0 * phi * phi / (Math.PI * Math.PI));
    }

    /**
     * Función E — expectativa de victoria (equivalente a expected score en ELO).
     */
    private double E(double mu, double muJ, double gPhiJ) {
        return 1.0 / (1.0 + Math.exp(-gPhiJ * (mu - muJ)));
    }

    /**
     * Step 5.1 del paper — Calcula nueva volatilidad usando el algoritmo de Illinois.
     * Encuentra σ' que satisface la ecuación f(σ') = 0.
     */
    private double computeNewVolatility(double phi, double sigma, double delta, double v) {
        double a = Math.log(sigma * sigma);
        double deltaSq = delta * delta;
        double phiSq = phi * phi;
        double tauSq = tau * tau;

        // f(x) function
        // f(x) = (e^x(Δ² - φ² - v - e^x)) / (2(φ² + v + e^x)²) - (x - a) / τ²

        // Initial bounds
        double A = a;
        double B;

        if (deltaSq > phiSq + v) {
            B = Math.log(deltaSq - phiSq - v);
        } else {
            // Find B such that f(B) < 0
            int k = 1;
            B = a - k * tau;
            while (f(B, deltaSq, phiSq, v, a, tauSq) < 0 && k < MAX_ITERATIONS) {
                k++;
                B = a - k * tau;
            }
        }

        double fA = f(A, deltaSq, phiSq, v, a, tauSq);
        double fB = f(B, deltaSq, phiSq, v, a, tauSq);

        // Illinois algorithm (bisection variant)
        int iterations = 0;
        while (Math.abs(B - A) > CONVERGENCE_TOLERANCE && iterations < MAX_ITERATIONS) {
            double C = A + (A - B) * fA / (fB - fA);
            double fC = f(C, deltaSq, phiSq, v, a, tauSq);

            if (fC * fB <= 0) {
                A = B;
                fA = fB;
            } else {
                fA /= 2.0;
            }

            B = C;
            fB = fC;
            iterations++;
        }

        return Math.exp(A / 2.0);
    }

    /**
     * Función f(x) usada en el cálculo de volatilidad (Step 5.4 del paper).
     */
    private double f(double x, double deltaSq, double phiSq, double v, double a, double tauSq) {
        double ex = Math.exp(x);
        double d = phiSq + v + ex;
        return (ex * (deltaSq - phiSq - v - ex)) / (2.0 * d * d) - (x - a) / tauSq;
    }

    // ═══════════════ Conversiones de escala ═══════════════

    /** Convierte rating display a escala Glicko-2 interna. */
    private double toGlicko2(double rating) {
        return (rating - 1500.0) / SCALE;
    }

    /** Convierte escala Glicko-2 interna a rating display. */
    private double fromGlicko2(double mu) {
        return mu * SCALE + 1500.0;
    }

    // ═══════════════ RD Decay por inactividad ═══════════════

    /**
     * Calcula el nuevo RD tras un período de inactividad.
     * El RD crece con el tiempo, representando mayor incertidumbre.
     * Esta es la implementación de "rating period" de Glicko-2.
     *
     * @param currentRd       RD actual
     * @param volatility      Volatilidad del jugador
     * @param periodsInactive Número de períodos rating inactivos
     * @return Nuevo RD (clamped a maxRd)
     */
    public double decayRd(double currentRd, double volatility, int periodsInactive) {
        double phi = currentRd / SCALE;
        double sigma = volatility;

        for (int i = 0; i < periodsInactive; i++) {
            phi = Math.sqrt(phi * phi + sigma * sigma);
        }

        double newRd = phi * SCALE;
        return Math.min(maxRd, newRd);
    }

    /**
     * Calcula el decay de rating por inactividad prolongada.
     * Después de cierto umbral, el rating también decae (no solo el RD).
     *
     * @param currentRating     Rating actual
     * @param periodsInactive   Períodos inactivos
     * @param decayThreshold    Períodos antes de que el rating empiece a decaer
     * @param decayPerPeriod    Puntos de rating perdidos por período después del threshold
     * @return Nuevo rating (floored)
     */
    public double decayRating(double currentRating, int periodsInactive,
                              int decayThreshold, double decayPerPeriod) {
        if (periodsInactive <= decayThreshold) return currentRating;
        int excessPeriods = periodsInactive - decayThreshold;
        double decay = excessPeriods * decayPerPeriod;
        return Math.max(ratingFloor, currentRating - decay);
    }

    // ═══════════════ Preview / Utilidades ═══════════════

    /**
     * Preview del cambio de rating sin aplicar modificadores de racha/placement.
     * Útil para mostrar en GUIs.
     */
    public int previewChange(double playerRating, double playerRd,
                             double opponentRating, double opponentRd,
                             boolean win) {
        double mu = toGlicko2(playerRating);
        double phi = playerRd / SCALE;
        double muOpp = toGlicko2(opponentRating);
        double phiOpp = opponentRd / SCALE;

        double g = g(phiOpp);
        double e = E(mu, muOpp, g);

        double v = 1.0 / (g * g * e * (1.0 - e));
        double score = win ? 1.0 : 0.0;
        double newPhi = 1.0 / Math.sqrt(1.0 / (phi * phi) + 1.0 / v);
        double newMu = mu + newPhi * newPhi * g * (score - e);

        double newRating = fromGlicko2(newMu);
        int change = (int) Math.round(newRating - playerRating);

        // Garantizar mínimo ±1
        if (win && change < 1) change = 1;
        if (!win && change > -1) change = -1;

        return change;
    }

    /**
     * Calcula el intervalo de confianza al 95% del rating.
     * Un rating de 1500 con RD 50 significa "95% probable entre 1402 y 1598".
     *
     * @param rating Rating actual
     * @param rd     Rating Deviation actual
     * @return int[2] donde [0] = lower bound, [1] = upper bound
     */
    public int[] confidenceInterval(double rating, double rd) {
        int lower = (int) Math.round(rating - 1.96 * rd);
        int upper = (int) Math.round(rating + 1.96 * rd);
        return new int[]{Math.max((int) ratingFloor, lower), upper};
    }

    // ═══════════════ Getters ═══════════════

    public double getDefaultRating() { return defaultRating; }
    public double getDefaultRd() { return defaultRd; }
    public double getDefaultVolatility() { return defaultVolatility; }
    public double getRatingFloor() { return ratingFloor; }
    public double getMaxRd() { return maxRd; }
    public double getMinRd() { return minRd; }
    public double getTau() { return tau; }
    public double getStreakBonusPerWin() { return streakBonusPerWin; }
    public double getStreakBonusMax() { return streakBonusMax; }
    public double getStreakProtectionPerLoss() { return streakProtectionPerLoss; }
    public double getStreakProtectionMax() { return streakProtectionMax; }
    public double getPlacementMultiplier() { return placementMultiplier; }
}
