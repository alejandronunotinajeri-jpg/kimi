package com.ethernova.ranked;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.service.ServiceRegistry;
import com.ethernova.ranked.api.RankedAPI;
import com.ethernova.ranked.api.RankedAPIImpl;
import com.ethernova.ranked.command.RankedCommand;
import com.ethernova.ranked.listener.RankedListener;
import com.ethernova.ranked.manager.RankedManager;
import com.ethernova.ranked.manager.SeasonManager;
import com.ethernova.ranked.message.MessageManager;
import com.ethernova.ranked.placeholder.RankedPlaceholders;
import com.ethernova.ranked.tournament.TournamentManager;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.logging.Level;

/**
 * EthernovaRanked - Sistema de ELO y clasificación competitiva.
 * Plugin del ecosistema Ethernova que proporciona ranking basado en ELO
 * con temporadas, leaderboards y perfiles de clasificación.
 */
public class EthernovaRanked extends JavaPlugin {

    private static volatile EthernovaRanked instance;
    private EthernovaCore core;
    private MessageManager messageManager;
    private RankedManager rankedManager;
    private SeasonManager seasonManager;
    private TournamentManager tournamentManager;
    private RankedListener rankedListener;

    @Override
    public void onEnable() {
        instance = this;
        long start = System.currentTimeMillis();

        getLogger().info("═══════════════════════════════════════════");
        getLogger().info("  EthernovaRanked v" + getDescription().getVersion());
        getLogger().info("═══════════════════════════════════════════");

        try {
            // Fase 1: Dependencia de Core
            core = (EthernovaCore) Bukkit.getPluginManager().getPlugin("EthernovaCore");
            if (core == null) {
                getLogger().severe("EthernovaCore no encontrado! Deshabilitando...");
                Bukkit.getPluginManager().disablePlugin(this);
                return;
            }
            core.registerPlugin("EthernovaRanked");

            // Fase 2: Configuración
            saveDefaultConfig();
            reloadConfig();

            // Fase 2.5: MessageManager
            messageManager = new MessageManager(this);

            // Fase 3: Managers (SeasonManager primero porque RankedManager lo necesita)
            seasonManager = new SeasonManager(this, core.getStorageManager());
            rankedManager = new RankedManager(this, core);
            tournamentManager = new TournamentManager(this, core);

            // Fase 4: Listeners
            rankedListener = new RankedListener(this, core);
            getServer().getPluginManager().registerEvents(rankedListener, this);

            // Fase 5: Comandos
            var cmd = getCommand("ranked");
            if (cmd != null) {
                var executor = new RankedCommand(this);
                cmd.setExecutor(executor);
                cmd.setTabCompleter(executor);
            }

            // Fase 5.1: Tournament command
            var tourneyCmd = new com.ethernova.ranked.command.TournamentCommand(this);
            var tCmd = getCommand("tournament");
            if (tCmd != null) {
                tCmd.setExecutor(tourneyCmd);
                tCmd.setTabCompleter(tourneyCmd);
            }

            // Fase 6: Auto-guardado periódico
            int saveInterval = getConfig().getInt("auto-save-interval", 300) * 20;
            Bukkit.getScheduler().runTaskTimerAsynchronously(this,
                    () -> rankedManager.saveAll(), saveInterval, saveInterval);

            // Fase 6.5: PlaceholderAPI
            if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
                new RankedPlaceholders(this).register();
                getLogger().info("PlaceholderAPI detectado: placeholders registrados.");
            }

            // Fase 7: Cargar perfiles de jugadores online (reload-safe)
            Bukkit.getOnlinePlayers().forEach(p ->
                    rankedManager.loadProfile(p.getUniqueId()));

            // Fase 8: Public API
            ServiceRegistry.register(RankedAPI.class, new RankedAPIImpl(this));
            getLogger().info("✔ RankedAPI registrada en ServiceRegistry");

            long elapsed = System.currentTimeMillis() - start;
            getLogger().info("EthernovaRanked habilitado en " + elapsed + "ms " +
                    "(Temporada: " + seasonManager.getSeasonDisplayName() + ")");

        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Error habilitando EthernovaRanked", e);
            Bukkit.getPluginManager().disablePlugin(this);
        }
    }

    @Override
    public void onDisable() {
        // Desregistrar listener del EventBus
        if (rankedListener != null) {
            rankedListener.unregister();
        }

        // Guardar todos los perfiles
        if (rankedManager != null) {
            rankedManager.saveAll();
        }

        // Cleanup tournaments
        if (tournamentManager != null) {
            tournamentManager.cleanup();
        }

        // Desregistrar API
        ServiceRegistry.unregister(RankedAPI.class);

        // Desregistrar del Core
        if (core != null) {
            core.unregisterPlugin("EthernovaRanked");
        }

        instance = null;
        getLogger().info("EthernovaRanked deshabilitado.");
    }

    // --- Getters ---

    public static EthernovaRanked getInstance() { return instance; }

    public EthernovaCore getCore() { return core; }

    public RankedManager getRankedManager() { return rankedManager; }

    public SeasonManager getSeasonManager() { return seasonManager; }

    public TournamentManager getTournamentManager() { return tournamentManager; }

    public MessageManager getMessageManager() { return messageManager; }
}
