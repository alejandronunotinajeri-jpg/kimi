package com.ethernova.ranked.message;

import com.ethernova.ranked.EthernovaRanked;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * Multi-language message manager for EthernovaRanked.
 * Loads messages from messages_XX.yml based on config language setting.
 */
public class MessageManager {

    private final EthernovaRanked plugin;
    private final MiniMessage mini = MiniMessage.miniMessage();
    private YamlConfiguration messages;
    private final Map<String, String> cache = new java.util.concurrent.ConcurrentHashMap<>();

    public MessageManager(EthernovaRanked plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        cache.clear();
        String lang = plugin.getConfig().getString("general.language", "es");
        String fileName = "messages_" + lang + ".yml";

        // Save default language files
        for (String l : new String[]{"es", "en"}) {
            String resource = "messages_" + l + ".yml";
            if (!new File(plugin.getDataFolder(), resource).exists()) {
                plugin.saveResource(resource, false);
            }
        }

        File file = new File(plugin.getDataFolder(), fileName);
        if (!file.exists()) {
            plugin.getLogger().warning("Language file " + fileName + " not found, falling back to messages_es.yml");
            file = new File(plugin.getDataFolder(), "messages_es.yml");
        }

        messages = YamlConfiguration.loadConfiguration(file);

        // Merge defaults from jar
        InputStream defaultStream = plugin.getResource(fileName);
        if (defaultStream != null) {
            YamlConfiguration defaults = YamlConfiguration.loadConfiguration(
                    new InputStreamReader(defaultStream, StandardCharsets.UTF_8));
            messages.setDefaults(defaults);
        }
    }

    /**
     * Get a message string with placeholder replacements.
     * Replacements are pairs: "{key}", "value", "{key2}", "value2"
     */
    public String get(String path, String... replacements) {
        String msg = cache.get(path);
        if (msg == null) {
            msg = messages.getString(path);
            if (msg == null) {
                plugin.getLogger().warning("Missing message key: " + path);
                return "<red>[Missing: " + path + "]</red>";
            }
            msg = msg.replace("{prefix}", messages.getString("general.prefix", ""));
            cache.put(path, msg);
        }

        String result = msg;
        for (int i = 0; i < replacements.length - 1; i += 2) {
            result = result.replace(replacements[i], replacements[i + 1]);
        }
        return result;
    }

    /**
     * Send a parsed MiniMessage to a CommandSender.
     */
    public void sendMessage(CommandSender sender, String path, String... replacements) {
        sender.sendMessage(parse(get(path, replacements)));
    }

    /**
     * Send a raw MiniMessage string (not from file).
     */
    public void sendRaw(CommandSender sender, String miniMsg) {
        sender.sendMessage(parse(miniMsg));
    }

    /**
     * Parse a MiniMessage string into a Component.
     */
    public Component parse(String miniMsg) {
        return mini.deserialize(miniMsg);
    }
}
