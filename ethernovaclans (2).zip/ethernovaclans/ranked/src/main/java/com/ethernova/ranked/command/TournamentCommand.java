package com.ethernova.ranked.command;

import com.ethernova.ranked.EthernovaRanked;
import com.ethernova.ranked.tournament.TournamentManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Handles tournament commands:
 * /tournament create <format> [min] [max] [fee] - Create tournament (admin)
 * /tournament join - Join active tournament
 * /tournament leave - Leave tournament
 * /tournament info - Current tournament info
 * /tournament list - List active tournaments
 * /tournament start - Force start (admin)
 * /tournament cancel - Cancel tournament (admin)
 */
public class TournamentCommand implements CommandExecutor, TabCompleter {

    private final EthernovaRanked plugin;
    private final MiniMessage mini = MiniMessage.miniMessage();

    private static final List<String> SUBCOMMANDS = List.of(
            "create", "join", "leave", "info", "list", "start", "cancel", "result");

    public TournamentCommand(EthernovaRanked plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(mini.deserialize("<red>Este comando solo puede ser usado por jugadores."));
            return true;
        }

        TournamentManager tm = plugin.getTournamentManager();
        if (tm == null) {
            player.sendMessage(mini.deserialize("<red>El sistema de torneos no está disponible."));
            return true;
        }

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "create", "crear" -> {
                if (!player.hasPermission("ethernova.tournament.admin")) {
                    player.sendMessage(mini.deserialize("<red>No tienes permiso para crear torneos."));
                    return true;
                }
                if (args.length < 2) {
                    player.sendMessage(mini.deserialize(
                            "<red>Uso: /" + label + " create <SINGLE_ELIMINATION|ROUND_ROBIN> [min] [max] [fee]"));
                    return true;
                }
                try {
                    TournamentManager.TournamentFormat format =
                            TournamentManager.TournamentFormat.valueOf(args[1].toUpperCase());
                    int min = args.length > 2 ? Integer.parseInt(args[2]) : 4;
                    int max = args.length > 3 ? Integer.parseInt(args[3]) : 16;
                    double fee = args.length > 4 ? Double.parseDouble(args[4]) : 0;
                    tm.createTournament(format.name(), format, min, max, fee);
                    player.sendMessage(mini.deserialize(
                            "<green>✦ Torneo creado: <white>" + format.name()
                                    + " <gray>(" + min + "-" + max + " jugadores"
                                    + (fee > 0 ? ", entrada: " + (int) fee + " coins" : "") + ")"));
                } catch (IllegalArgumentException e) {
                    player.sendMessage(mini.deserialize(
                            "<red>Formato inválido. Usa: SINGLE_ELIMINATION o ROUND_ROBIN"));
                }
            }

            case "join", "unirse" -> {
                boolean joined = tm.joinTournament(player);
                if (!joined) {
                    player.sendMessage(mini.deserialize(
                            "<red>No pudiste unirte al torneo. Verifica que hay un torneo en registro."));
                }
            }

            case "leave", "salir" -> {
                boolean left = tm.leaveTournament(player);
                if (!left) {
                    player.sendMessage(mini.deserialize(
                            "<red>No estás participando en ningún torneo."));
                }
            }

            case "info" -> {
                var tournament = tm.getActiveTournament();
                if (tournament == null) {
                    player.sendMessage(mini.deserialize(
                            "<red>No hay ningún torneo activo."));
                } else {
                    player.sendMessage(mini.deserialize(
                            "<gradient:gold:yellow>═══ Torneo Activo ═══</gradient>"));
                    player.sendMessage(mini.deserialize(
                            "<yellow>Formato: <white>" + tournament.getFormat().name()));
                    player.sendMessage(mini.deserialize(
                            "<yellow>Fase: <white>" + tournament.getPhase().name()));
                    player.sendMessage(mini.deserialize(
                            "<yellow>Participantes: <white>" + tournament.getParticipants().size()));
                    player.sendMessage(mini.deserialize(
                            "<yellow>Ronda: <white>" + tournament.getRoundNumber()));
                    if (tournament.getEntryFee() > 0) {
                        player.sendMessage(mini.deserialize(
                                "<yellow>Entrada: <white>" + (int) tournament.getEntryFee() + " coins"));
                        player.sendMessage(mini.deserialize(
                                "<yellow>Pool: <white>" + (int) tournament.getPrizePool() + " coins"));
                    }
                }
            }

            case "list", "lista" -> {
                var tournament = tm.getActiveTournament();
                if (tournament == null) {
                    player.sendMessage(mini.deserialize(
                            "<gray>No hay torneos activos actualmente."));
                } else {
                    player.sendMessage(mini.deserialize(
                            "<gradient:gold:yellow>═══ Torneos ═══</gradient>"));
                    player.sendMessage(mini.deserialize(
                            "<yellow>▸ <white>" + tournament.getFormat().name()
                                    + " <gray>[" + tournament.getPhase().name() + "] "
                                    + "<white>" + tournament.getParticipants().size() + " jugadores"));
                }
            }

            case "start", "forzar" -> {
                if (!player.hasPermission("ethernova.tournament.admin")) {
                    player.sendMessage(mini.deserialize("<red>No tienes permiso."));
                    return true;
                }
                // Force start by manually triggering — just create if not exists
                if (tm.getActiveTournament() == null) {
                    player.sendMessage(mini.deserialize("<red>No hay torneo activo para forzar."));
                } else {
                    player.sendMessage(mini.deserialize("<yellow>El torneo iniciará cuando se cumpla el timer de registro."));
                }
            }

            case "cancel", "cancelar" -> {
                if (!player.hasPermission("ethernova.tournament.admin")) {
                    player.sendMessage(mini.deserialize("<red>No tienes permiso."));
                    return true;
                }
                tm.cancelTournament();
                player.sendMessage(mini.deserialize("<red>✦ Torneo cancelado."));
            }

            case "result", "resultado" -> {
                if (!player.hasPermission("ethernova.tournament.admin")) {
                    player.sendMessage(mini.deserialize("<red>No tienes permiso."));
                    return true;
                }
                if (args.length < 3) {
                    player.sendMessage(mini.deserialize(
                            "<red>Uso: /" + label + " result <ganador> <perdedor>"));
                    return true;
                }
                var winner = plugin.getServer().getPlayer(args[1]);
                var loser = plugin.getServer().getPlayer(args[2]);
                if (winner == null || loser == null) {
                    player.sendMessage(mini.deserialize("<red>Jugador(es) no encontrado(s)."));
                    return true;
                }
                tm.reportResult(winner.getUniqueId(), loser.getUniqueId());
                player.sendMessage(mini.deserialize(
                        "<green>Resultado registrado: <white>" + winner.getName()
                                + " <green>venció a <white>" + loser.getName()));
            }

            default -> sendHelp(player);
        }

        return true;
    }

    private void sendHelp(Player player) {
        player.sendMessage(mini.deserialize(
                "<gradient:gold:yellow>═══ Torneos ═══</gradient>"));
        player.sendMessage(mini.deserialize(
                "<yellow>/tournament join <gray>- Unirse al torneo"));
        player.sendMessage(mini.deserialize(
                "<yellow>/tournament leave <gray>- Salir del torneo"));
        player.sendMessage(mini.deserialize(
                "<yellow>/tournament info <gray>- Información del torneo"));
        player.sendMessage(mini.deserialize(
                "<yellow>/tournament list <gray>- Ver torneos activos"));
        if (player.hasPermission("ethernova.tournament.admin")) {
            player.sendMessage(mini.deserialize(
                    "<yellow>/tournament create <formato> <gray>- Crear torneo"));
            player.sendMessage(mini.deserialize(
                    "<yellow>/tournament start <gray>- Forzar inicio"));
            player.sendMessage(mini.deserialize(
                    "<yellow>/tournament cancel <gray>- Cancelar torneo"));
            player.sendMessage(mini.deserialize(
                    "<yellow>/tournament result <g> <p> <gray>- Registrar resultado"));
        }
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                 @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) {
            List<String> completions = new ArrayList<>(
                    List.of("join", "leave", "info", "list"));
            if (sender.hasPermission("ethernova.tournament.admin")) {
                completions.addAll(List.of("create", "start", "cancel", "result"));
            }
            return completions.stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .sorted()
                    .collect(Collectors.toList());
        }

        if (args.length == 2) {
            if ("create".equalsIgnoreCase(args[0])) {
                return List.of("SINGLE_ELIMINATION", "ROUND_ROBIN").stream()
                        .filter(s -> s.toLowerCase().startsWith(args[1].toLowerCase()))
                        .collect(Collectors.toList());
            }
            if ("result".equalsIgnoreCase(args[0])) {
                return plugin.getServer().getOnlinePlayers().stream()
                        .map(Player::getName)
                        .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase()))
                        .collect(Collectors.toList());
            }
        }

        if (args.length == 3 && "result".equalsIgnoreCase(args[0])) {
            return plugin.getServer().getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[2].toLowerCase()))
                    .collect(Collectors.toList());
        }

        return Collections.emptyList();
    }
}
