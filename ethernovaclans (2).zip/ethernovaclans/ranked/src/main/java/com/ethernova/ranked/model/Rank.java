package com.ethernova.ranked.model;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;

import java.util.*;

/**
 * Rangos competitivos del sistema de clasificación.
 * Los rangos se cargan dinámicamente desde config.yml, permitiendo personalización completa.
 * Si la config no tiene rangos definidos, usa los valores por defecto.
 */
public final class Rank {

    // ═══════════════ Instancias por defecto ═══════════════
    // Se usan si la config no define rangos. También como fallback.

    private static final Rank DEFAULT_BRONZE = new Rank("bronze", 0, 999, "Bronce", "<#CD7F32>", Material.BRICK, 0);
    private static final Rank DEFAULT_SILVER = new Rank("silver", 1000, 1499, "Plata", "<#C0C0C0>", Material.IRON_INGOT, 1);
    private static final Rank DEFAULT_GOLD = new Rank("gold", 1500, 1999, "Oro", "<gold>", Material.GOLD_INGOT, 2);
    private static final Rank DEFAULT_PLATINUM = new Rank("platinum", 2000, 2499, "Platino", "<aqua>", Material.DIAMOND, 3);
    private static final Rank DEFAULT_DIAMOND = new Rank("diamond", 2500, 2999, "Diamante", "<blue>", Material.DIAMOND_BLOCK, 4);
    private static final Rank DEFAULT_MASTER = new Rank("master", 3000, 3499, "Maestro", "<light_purple>", Material.AMETHYST_SHARD, 5);
    private static final Rank DEFAULT_GRANDMASTER = new Rank("grandmaster", 3500, 3999, "Gran Maestro", "<red>", Material.NETHERITE_INGOT, 6);
    private static final Rank DEFAULT_CHALLENGER = new Rank("challenger", 4000, Integer.MAX_VALUE, "Retador", "<gradient:#FFD700:#FF4500>", Material.NETHER_STAR, 7);

    private static final List<Rank> DEFAULT_RANKS = List.of(
            DEFAULT_BRONZE, DEFAULT_SILVER, DEFAULT_GOLD, DEFAULT_PLATINUM,
            DEFAULT_DIAMOND, DEFAULT_MASTER, DEFAULT_GRANDMASTER, DEFAULT_CHALLENGER
    );

    /** Lista activa de rangos, ordenada por minElo ascendente. */
    private static volatile List<Rank> activeRanks = DEFAULT_RANKS;

    // ═══════════════ Campos de instancia ═══════════════

    private final String id;
    private final int minElo;
    private final int maxElo;
    private final String displayName;
    private final String color;
    private final Material icon;
    private final int ordinal;

    public Rank(String id, int minElo, int maxElo, String displayName, String color, Material icon, int ordinal) {
        this.id = id;
        this.minElo = minElo;
        this.maxElo = maxElo;
        this.displayName = displayName;
        this.color = color;
        this.icon = icon;
        this.ordinal = ordinal;
    }

    // ═══════════════ Getters ═══════════════

    public String getId() { return id; }
    public int getMinElo() { return minElo; }
    public int getMaxElo() { return maxElo; }
    public String getDisplayName() { return displayName; }
    public String getColor() { return color; }
    public Material getIcon() { return icon; }
    public int getOrdinal() { return ordinal; }

    /** Nombre coloreado con MiniMessage. */
    public String getColoredName() {
        return color + displayName;
    }

    /** Nombre identificador en mayúsculas (backward-compatible con enum .name()). */
    public String name() {
        return id.toUpperCase(Locale.ROOT);
    }

    // ═══════════════ Carga desde config ═══════════════

    /**
     * Carga los rangos desde la sección "ranks" de config.yml.
     * Si la sección no existe o está vacía, usa los rangos por defecto.
     *
     * <pre>
     * ranks:
     *   bronze:
     *     min: 0
     *     max: 999
     *     display: "Bronce"
     *     color: "&lt;#CD7F32&gt;"
     *     icon: BRICK
     *   silver:
     *     min: 1000
     *     ...
     * </pre>
     */
    public static void loadFromConfig(ConfigurationSection ranksSection) {
        if (ranksSection == null || ranksSection.getKeys(false).isEmpty()) {
            activeRanks = DEFAULT_RANKS;
            return;
        }

        List<Rank> loaded = new ArrayList<>();
        int ord = 0;

        for (String key : ranksSection.getKeys(false)) {
            ConfigurationSection rs = ranksSection.getConfigurationSection(key);
            if (rs == null) continue;

            int min = rs.getInt("min", 0);
            int max = rs.getInt("max", Integer.MAX_VALUE);
            String display = rs.getString("display", key);
            String color = rs.getString("color", "<white>");
            Material icon;
            try {
                icon = Material.valueOf(rs.getString("icon", "STONE").toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException e) {
                icon = Material.STONE;
            }

            loaded.add(new Rank(key.toLowerCase(Locale.ROOT), min, max, display, color, icon, ord++));
        }

        if (loaded.isEmpty()) {
            activeRanks = DEFAULT_RANKS;
        } else {
            // Ordenar por minElo ascendente
            loaded.sort(Comparator.comparingInt(Rank::getMinElo));
            // Reasignar ordinales
            for (int i = 0; i < loaded.size(); i++) {
                Rank r = loaded.get(i);
                loaded.set(i, new Rank(r.id, r.minElo, r.maxElo, r.displayName, r.color, r.icon, i));
            }
            activeRanks = List.copyOf(loaded);
        }
    }

    /** Retorna la lista activa de rangos (inmutable, ordenada por minElo). */
    public static List<Rank> values() {
        return activeRanks;
    }

    // ═══════════════ Métodos estáticos ═══════════════

    /**
     * Determina el rango correspondiente a un valor de ELO.
     */
    public static Rank fromElo(int elo) {
        List<Rank> ranks = activeRanks;
        for (int i = ranks.size() - 1; i >= 0; i--) {
            Rank rank = ranks.get(i);
            if (elo >= rank.minElo && elo <= rank.maxElo) {
                return rank;
            }
        }
        return ranks.isEmpty() ? DEFAULT_BRONZE : ranks.get(0);
    }

    /** Obtiene el rango más bajo. */
    public static Rank lowest() {
        return activeRanks.isEmpty() ? DEFAULT_BRONZE : activeRanks.get(0);
    }

    /** Obtiene el rango más alto. */
    public static Rank highest() {
        return activeRanks.isEmpty() ? DEFAULT_CHALLENGER : activeRanks.get(activeRanks.size() - 1);
    }

    // ═══════════════ Métodos de instancia ═══════════════

    /**
     * Obtiene el progreso dentro del rango actual (0.0 a 1.0).
     */
    public double getProgress(int elo) {
        if (maxElo == Integer.MAX_VALUE) return 1.0;
        int range = maxElo - minElo + 1;
        return Math.min(1.0, Math.max(0.0, (double) (elo - minElo) / range));
    }

    /**
     * Obtiene el siguiente rango. Retorna null si es el último.
     */
    public Rank next() {
        List<Rank> ranks = activeRanks;
        int idx = ordinal + 1;
        return idx < ranks.size() ? ranks.get(idx) : null;
    }

    /**
     * Obtiene el rango anterior. Retorna null si es el primero.
     */
    public Rank previous() {
        List<Rank> ranks = activeRanks;
        int idx = ordinal - 1;
        return idx >= 0 ? ranks.get(idx) : null;
    }

    /**
     * ¿Es el rango más alto posible?
     */
    public boolean isHighest() {
        return next() == null;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Rank other)) return false;
        return id.equals(other.id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }

    @Override
    public String toString() {
        return "Rank{" + id + ", " + minElo + "-" + maxElo + "}";
    }
}
