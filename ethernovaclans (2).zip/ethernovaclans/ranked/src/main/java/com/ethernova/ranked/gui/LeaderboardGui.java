package com.ethernova.ranked.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.PaginatedGui;
import com.ethernova.ranked.EthernovaRanked;
import com.ethernova.ranked.manager.RankedManager;
import com.ethernova.ranked.message.MessageManager;
import com.ethernova.ranked.model.Rank;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * GUI paginada del leaderboard.
 * Muestra los top 28 jugadores por página con cabezas, ícono de rango y ELO.
 */
public class LeaderboardGui extends PaginatedGui {

    private final EthernovaRanked plugin;
    private volatile List<PageItem> cachedItems;

    public LeaderboardGui(EthernovaRanked plugin, EthernovaCore core, Player player) {
        super(core, player);
        this.plugin = plugin;
    }

    private MessageManager mm() { return plugin.getMessageManager(); }

    public void open() {
        int maxEntries = plugin.getConfig().getInt("leaderboard.max-entries", 100);
        plugin.getRankedManager().getLeaderboard(maxEntries).thenAccept(entries -> {
            cachedItems = buildPageItems(entries);
            Bukkit.getScheduler().runTask(plugin, () ->
                    openPaginated(getTitle(), 0));
        });
    }

    private List<PageItem> buildPageItems(List<RankedManager.LeaderboardEntry> entries) {
        List<PageItem> items = new ArrayList<>();

        for (RankedManager.LeaderboardEntry entry : entries) {
            Rank rank = entry.rank();
            String positionColor = switch (entry.position()) {
                case 1 -> "<gold>";
                case 2 -> "<#C0C0C0>";
                case 3 -> "<#CD7F32>";
                default -> "<gray>";
            };

            String positionPrefix = switch (entry.position()) {
                case 1 -> "🥇";
                case 2 -> "🥈";
                case 3 -> "🥉";
                default -> "#" + entry.position();
            };

            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            if (meta != null) {
                var offlinePlayer = Bukkit.getOfflinePlayer(entry.uuid());
                meta.setOwningPlayer(offlinePlayer);

                meta.displayName(mini.deserialize(positionColor + positionPrefix + " " + entry.name() + "</gray>"));

                List<String> lore = new ArrayList<>();
                lore.add(mm().get("gui.ranked.skull-separator"));
                lore.add(mm().get("gui.leaderboard.rank-line", "{rank}", rank.getColoredName()));
                lore.add(mm().get("gui.leaderboard.elo-line", "{elo}", String.valueOf(entry.elo())));
                lore.add(mm().get("gui.ranked.skull-separator"));
                lore.add(mm().get("gui.leaderboard.wins-losses",
                        "{wins}", String.valueOf(entry.wins()),
                        "{losses}", String.valueOf(entry.losses())));
                lore.add(mm().get("gui.leaderboard.winrate", "{winrate}", entry.winRateFormatted()));
                lore.add(mm().get("gui.leaderboard.best-streak", "{best}", String.valueOf(entry.bestWinStreak())));
                lore.add(mm().get("gui.ranked.skull-separator"));

                meta.lore(lore.stream().map(mini::deserialize).toList());
                head.setItemMeta(meta);
            }

            items.add(new PageItem(head, "PLAYER_" + entry.uuid()));
        }

        return items;
    }

    @Override
    protected String getTitle() {
        return mm().get("gui.leaderboard.title");
    }

    @Override
    protected List<PageItem> getPageItems() {
        return cachedItems != null ? cachedItems : new ArrayList<>();
    }

    @Override
    protected boolean onItemClick(String action, int slot, InventoryClickEvent event) {
        if (action.startsWith("PLAYER_")) {
            playSound("click");
            return true;
        }
        return false;
    }

    @Override
    protected void onBack() {
        player.closeInventory();
        new RankedGui(plugin, core, player).open();
    }
}
