package com.ethernova.ranked.api;

import com.ethernova.ranked.model.Rank;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * Public API interface for EthernovaRanked (Glicko-2 rating system).
 *
 * <p>Provides methods for querying player ratings, match processing,
 * rank information, and season data.</p>
 *
 * <p>Obtain an instance via {@code ServiceRegistry.get(RankedAPI.class)}.</p>
 *
 * <p>All methods are thread-safe. Rating queries read from an in-memory cache.
 * The {@link #processResult(UUID, UUID)} method performs async persistence.</p>
 */
public interface RankedAPI {

    // ═══════════════ Profile ═══════════════

    /**
     * Get a player's current rating as an integer.
     *
     * @param uuid the UUID of the player
     * @return the rating rounded to the nearest integer, or {@code 0} if not loaded
     */
    int getElo(UUID uuid);

    /**
     * Get a player's current rating as a precise double.
     *
     * @param uuid the UUID of the player
     * @return the precise Glicko-2 rating value
     */
    double getRating(UUID uuid);

    /**
     * Get a player's Rating Deviation (uncertainty).
     *
     * @param uuid the UUID of the player
     * @return the RD value; lower values indicate more certain ratings
     */
    double getRd(UUID uuid);

    /**
     * Get a player's volatility (consistency measure).
     *
     * @param uuid the UUID of the player
     * @return the Glicko-2 volatility value
     */
    double getVolatility(UUID uuid);

    /**
     * Get a player's current rank tier.
     *
     * @param uuid the UUID of the player
     * @return the player's {@link Rank}
     */
    Rank getRank(UUID uuid);

    /**
     * Get total ranked wins for a player.
     *
     * @param uuid the UUID of the player
     * @return total wins
     */
    int getWins(UUID uuid);

    /**
     * Get total ranked losses for a player.
     *
     * @param uuid the UUID of the player
     * @return total losses
     */
    int getLosses(UUID uuid);

    /**
     * Get total ranked games played by a player.
     *
     * @param uuid the UUID of the player
     * @return total games played
     */
    int getTotalGames(UUID uuid);

    /**
     * Get the current win streak for a player.
     *
     * @param uuid the UUID of the player
     * @return current consecutive wins, or {@code 0} if the last match was a loss
     */
    int getWinStreak(UUID uuid);

    /**
     * Get the current loss streak for a player.
     *
     * @param uuid the UUID of the player
     * @return current consecutive losses, or {@code 0} if the last match was a win
     */
    int getLossStreak(UUID uuid);

    /**
     * Get the best win streak ever achieved by a player.
     *
     * @param uuid the UUID of the player
     * @return the highest consecutive win count recorded
     */
    int getBestWinStreak(UUID uuid);

    /**
     * Get the 95% confidence interval for a player's rating.
     *
     * @param uuid the UUID of the player
     * @return a formatted string in the form "lower - upper"
     */
    String getConfidenceInterval(UUID uuid);

    /**
     * Get a player's peak (highest ever) rating.
     *
     * @param uuid the UUID of the player
     * @return the highest rating the player has achieved
     */
    int getPeakRating(UUID uuid);

    /**
     * Check if a match between two players is on anti-abuse cooldown.
     *
     * @param player1 the UUID of the first player
     * @param player2 the UUID of the second player
     * @return {@code true} if the players are on cooldown and cannot queue together
     */
    boolean isOnCooldown(UUID player1, UUID player2);

    // ═══════════════ ELO ═══════════════

    /**
     * Preview a rating change without applying it.
     *
     * @param playerRating   the player's current rating
     * @param playerRd       the player's current Rating Deviation
     * @param opponentRating the opponent's current rating
     * @param opponentRd     the opponent's current Rating Deviation
     * @param win            {@code true} to simulate a win, {@code false} for a loss
     * @return the estimated rating change (positive for gain, negative for loss)
     */
    int previewRatingChange(double playerRating, double playerRd,
                            double opponentRating, double opponentRd, boolean win);

    /**
     * Process a match result, updating ratings, stats, and sending notifications.
     *
     * @param winnerId the UUID of the winning player
     * @param loserId  the UUID of the losing player
     */
    void processResult(UUID winnerId, UUID loserId);

    // ═══════════════ Season ═══════════════

    /**
     * Get the current season identifier.
     *
     * @return the season ID string (e.g., "S1", "S2")
     */
    String getCurrentSeason();

    /**
     * Get the current season's display name.
     *
     * @return the human-readable season name
     */
    String getSeasonDisplayName();

    /**
     * Check if the ranked season is currently active.
     *
     * @return {@code true} if the season is active and accepting matches
     */
    boolean isSeasonActive();
}
