package com.ethernova.ranked.api;

import com.ethernova.ranked.EthernovaRanked;
import com.ethernova.ranked.model.Rank;
import com.ethernova.ranked.model.RankedProfile;

import java.util.UUID;

/**
 * Implementation of RankedAPI (Glicko-2). Registered with ServiceRegistry on enable.
 */
public class RankedAPIImpl implements RankedAPI {

    private final EthernovaRanked plugin;

    public RankedAPIImpl(EthernovaRanked plugin) {
        this.plugin = plugin;
    }

    // ═══════════════ Profile ═══════════════

    @Override
    public int getElo(UUID uuid) {
        RankedProfile profile = plugin.getRankedManager().getProfile(uuid);
        return profile != null ? profile.getElo() : 0;
    }

    @Override
    public double getRating(UUID uuid) {
        RankedProfile profile = plugin.getRankedManager().getProfile(uuid);
        return profile != null ? profile.getRating() : 0.0;
    }

    @Override
    public double getRd(UUID uuid) {
        RankedProfile profile = plugin.getRankedManager().getProfile(uuid);
        return profile != null ? profile.getRd() : 350.0;
    }

    @Override
    public double getVolatility(UUID uuid) {
        RankedProfile profile = plugin.getRankedManager().getProfile(uuid);
        return profile != null ? profile.getVolatility() : 0.06;
    }

    @Override
    public Rank getRank(UUID uuid) {
        return plugin.getRankedManager().getRank(uuid);
    }

    @Override
    public int getWins(UUID uuid) {
        RankedProfile profile = plugin.getRankedManager().getProfile(uuid);
        return profile != null ? profile.getWins() : 0;
    }

    @Override
    public int getLosses(UUID uuid) {
        RankedProfile profile = plugin.getRankedManager().getProfile(uuid);
        return profile != null ? profile.getLosses() : 0;
    }

    @Override
    public int getTotalGames(UUID uuid) {
        RankedProfile profile = plugin.getRankedManager().getProfile(uuid);
        return profile != null ? profile.getTotalGames() : 0;
    }

    @Override
    public int getWinStreak(UUID uuid) {
        RankedProfile profile = plugin.getRankedManager().getProfile(uuid);
        return profile != null ? profile.getWinStreak() : 0;
    }

    @Override
    public int getLossStreak(UUID uuid) {
        RankedProfile profile = plugin.getRankedManager().getProfile(uuid);
        return profile != null ? profile.getLossStreak() : 0;
    }

    @Override
    public int getBestWinStreak(UUID uuid) {
        RankedProfile profile = plugin.getRankedManager().getProfile(uuid);
        return profile != null ? profile.getBestWinStreak() : 0;
    }

    @Override
    public String getConfidenceInterval(UUID uuid) {
        RankedProfile profile = plugin.getRankedManager().getProfile(uuid);
        return profile != null ? profile.getConfidenceInterval() : "0 - 0";
    }

    @Override
    public int getPeakRating(UUID uuid) {
        RankedProfile profile = plugin.getRankedManager().getProfile(uuid);
        return profile != null ? profile.getPeakRating() : 0;
    }

    @Override
    public boolean isOnCooldown(UUID player1, UUID player2) {
        return plugin.getRankedManager().isOnCooldown(player1, player2);
    }

    // ═══════════════ Rating ═══════════════

    @Override
    public int previewRatingChange(double playerRating, double playerRd,
                                    double opponentRating, double opponentRd, boolean win) {
        return plugin.getRankedManager().getCalculator()
                .previewChange(playerRating, playerRd, opponentRating, opponentRd, win);
    }

    @Override
    public void processResult(UUID winnerId, UUID loserId) {
        plugin.getRankedManager().processResult(winnerId, loserId);
    }

    // ═══════════════ Season ═══════════════

    @Override
    public String getCurrentSeason() {
        return plugin.getSeasonManager().getCurrentSeason();
    }

    @Override
    public String getSeasonDisplayName() {
        return plugin.getSeasonManager().getSeasonDisplayName();
    }

    @Override
    public boolean isSeasonActive() {
        return plugin.getSeasonManager().isSeasonActive();
    }
}
