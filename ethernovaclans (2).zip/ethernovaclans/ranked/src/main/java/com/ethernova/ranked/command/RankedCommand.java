package com.ethernova.ranked.command;

import com.ethernova.ranked.EthernovaRanked;
import com.ethernova.ranked.gui.LeaderboardGui;
import com.ethernova.ranked.gui.RankedAdminGui;
import com.ethernova.ranked.gui.RankedGui;
import com.ethernova.ranked.manager.RankedManager;
import com.ethernova.ranked.manager.SeasonManager;
import com.ethernova.ranked.message.MessageManager;
import com.ethernova.ranked.model.Rank;
import com.ethernova.ranked.model.RankedProfile;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Main /ranked command (/elo, /rango).
 * Subcommands: top, stats, season, card, help, admin (reset, setelo, info, reload)
 */
public class RankedCommand implements CommandExecutor, TabCompleter {

    private final EthernovaRanked plugin;
    private final MiniMessage mini = MiniMessage.miniMessage();

    public RankedCommand(EthernovaRanked plugin) {
        this.plugin = plugin;
    }

    private MessageManager mm() { return plugin.getMessageManager(); }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            mm().sendMessage(sender, "general.only-players");
            return true;
        }

        if (args.length == 0) {
            showOwnRank(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "top", "leaderboard", "tabla" -> showLeaderboard(player);
            case "stats", "estadisticas", "ver" -> handleStats(player, args);
            case "season", "temporada" -> showSeasonInfo(player);
            case "admin" -> handleAdmin(player, args);
            case "card", "tarjeta" -> openRankedCard(player);
            case "help", "ayuda" -> showHelp(player);
            default -> showHelp(player);
        }

        return true;
    }

    private void showOwnRank(Player player) {
        RankedProfile profile = plugin.getRankedManager().getProfile(player.getUniqueId());
        if (profile == null) {
            mm().sendMessage(player, "general.loading-profile");
            plugin.getRankedManager().loadProfile(player.getUniqueId()).thenAccept(p ->
                    Bukkit.getScheduler().runTask(plugin, () -> displayRank(player, p, player.getName())));
            return;
        }
        displayRank(player, profile, player.getName());
    }

    private void displayRank(Player player, RankedProfile profile, String name) {
        Rank rank = profile.getCurrentRank();
        int placementMatches = plugin.getConfig().getInt("placement.matches", 10);
        boolean inPlacements = profile.isInPlacements(placementMatches);

        mm().sendRaw(player, "");
        mm().sendMessage(player, "profile.header", "{player}", name);
        mm().sendMessage(player, "profile.separator");

        if (inPlacements) {
            mm().sendMessage(player, "profile.placement",
                    "{played}", String.valueOf(profile.getPlacementMatchesPlayed()),
                    "{total}", String.valueOf(placementMatches));
        }

        mm().sendMessage(player, "profile.rank-line", "{rank}", rank.getColoredName());
        mm().sendMessage(player, "profile.elo-line", "{elo}", String.valueOf(profile.getElo()));
        mm().sendMessage(player, "profile.wins-losses",
                "{wins}", String.valueOf(profile.getWins()),
                "{losses}", String.valueOf(profile.getLosses()));
        mm().sendMessage(player, "profile.winrate", "{winrate}", profile.getWinRateFormatted());
        mm().sendMessage(player, "profile.streak",
                "{current}", String.valueOf(profile.getWinStreak()),
                "{best}", String.valueOf(profile.getBestWinStreak()));
        mm().sendMessage(player, "profile.progress-line", "{bar}", buildProgressBar(rank, profile.getElo()));
        mm().sendMessage(player, "profile.separator");
        mm().sendMessage(player, "profile.season-line", "{season}", plugin.getSeasonManager().getSeasonDisplayName());
        mm().sendRaw(player, "");
    }

    private String buildProgressBar(Rank rank, int elo) {
        if (rank.isHighest()) {
            return "<gradient:#FFD700:#FF4500>████████████████████ MAX</gradient>";
        }

        double progress = rank.getProgress(elo);
        int filled = (int) (progress * 20);
        int empty = 20 - filled;

        StringBuilder bar = new StringBuilder();
        bar.append(rank.getColor());
        bar.append("█".repeat(filled));
        bar.append("<dark_gray>");
        bar.append("░".repeat(empty));
        bar.append("</dark_gray> ");

        Rank next = rank.next();
        if (next != null) {
            bar.append("<gray>→ ").append(next.getColoredName()).append("</gray>");
        }

        return bar.toString();
    }

    private void showLeaderboard(Player player) {
        new LeaderboardGui(plugin, plugin.getCore(), player).open();
    }

    private void handleStats(Player player, String[] args) {
        if (args.length < 2) {
            openRankedCard(player);
            return;
        }

        String targetName = args[1];
        Player target = Bukkit.getPlayerExact(targetName);

        if (target != null) {
            RankedProfile profile = plugin.getRankedManager().getProfile(target.getUniqueId());
            if (profile != null) {
                displayRank(player, profile, target.getName());
                return;
            }
        }

        mm().sendMessage(player, "general.searching-player");
        plugin.getRankedManager().getLeaderboard(100).thenAccept(entries -> {
            var match = entries.stream()
                    .filter(e -> e.name().equalsIgnoreCase(targetName))
                    .findFirst();

            Bukkit.getScheduler().runTask(plugin, () -> {
                if (match.isPresent()) {
                    var entry = match.get();
                    mm().sendRaw(player, "");
                    mm().sendMessage(player, "lookup.header", "{player}", entry.name());
                    mm().sendMessage(player, "profile.separator");
                    mm().sendMessage(player, "lookup.position", "{position}", String.valueOf(entry.position()));
                    mm().sendMessage(player, "lookup.rank-line", "{rank}", entry.rank().getColoredName());
                    mm().sendMessage(player, "lookup.elo-line", "{elo}", String.valueOf(entry.elo()));
                    mm().sendMessage(player, "lookup.wins-losses",
                            "{wins}", String.valueOf(entry.wins()),
                            "{losses}", String.valueOf(entry.losses()));
                    mm().sendMessage(player, "lookup.winrate", "{winrate}", entry.winRateFormatted());
                    mm().sendMessage(player, "lookup.best-streak", "{best}", String.valueOf(entry.bestWinStreak()));
                    mm().sendMessage(player, "profile.separator");
                } else {
                    mm().sendMessage(player, "general.player-not-found");
                }
            });
        });
    }

    private void showSeasonInfo(Player player) {
        SeasonManager sm = plugin.getSeasonManager();
        mm().sendRaw(player, "");
        mm().sendMessage(player, "season.header");
        mm().sendMessage(player, "profile.separator");
        mm().sendMessage(player, "season.name", "{name}", sm.getSeasonDisplayName());
        mm().sendMessage(player, "season.id", "{id}", sm.getCurrentSeason());

        if (sm.isSeasonActive()) {
            mm().sendMessage(player, "season.active");
        } else {
            mm().sendMessage(player, "season.inactive");
        }

        sm.getSeasonStats().thenAccept(stats ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    mm().sendMessage(player, "season.players", "{count}", String.valueOf(stats.totalPlayers()));
                    mm().sendMessage(player, "season.average-elo", "{elo}", String.valueOf(stats.averageElo()));
                    mm().sendMessage(player, "season.highest-elo", "{elo}", String.valueOf(stats.highestElo()));
                    mm().sendMessage(player, "season.total-games", "{count}", String.valueOf(stats.totalGames()));
                    mm().sendMessage(player, "profile.separator");
                    mm().sendRaw(player, "");
                }));
    }

    private void handleAdmin(Player player, String[] args) {
        if (!player.hasPermission("ethernova.ranked.admin")) {
            mm().sendMessage(player, "general.no-permission");
            return;
        }

        if (args.length < 2) {
            mm().sendMessage(player, "admin.admin-subcommands");
            return;
        }

        switch (args[1].toLowerCase()) {
            case "reset" -> handleAdminReset(player, args);
            case "setelo" -> handleAdminSetElo(player, args);
            case "info" -> handleAdminInfo(player, args);
            case "reload" -> handleAdminReload(player);
            case "gui" -> new RankedAdminGui(plugin, player).open();
            default -> mm().sendMessage(player, "admin.admin-subcommands");
        }
    }

    private void handleAdminReset(Player player, String[] args) {
        if (args.length < 4) {
            mm().sendMessage(player, "admin.reset-usage");
            return;
        }

        String newId = args[2];
        String newName = String.join(" ", java.util.Arrays.copyOfRange(args, 3, args.length));

        mm().sendMessage(player, "admin.reset-starting");

        plugin.getSeasonManager().resetSeason(newId, newName).thenAccept(archived ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    mm().sendMessage(player, "admin.reset-success");
                    mm().sendMessage(player, "admin.reset-archived", "{count}", String.valueOf(archived));
                    mm().sendMessage(player, "admin.reset-new", "{name}", newName, "{id}", newId);
                }));
    }

    private void handleAdminSetElo(Player player, String[] args) {
        if (args.length < 4) {
            mm().sendMessage(player, "admin.setelo-usage");
            return;
        }

        Player target = Bukkit.getPlayerExact(args[2]);
        if (target == null) {
            mm().sendMessage(player, "general.player-not-found");
            return;
        }

        int elo;
        try {
            elo = Integer.parseInt(args[3]);
        } catch (NumberFormatException e) {
            mm().sendMessage(player, "general.invalid-number");
            return;
        }

        RankedProfile profile = plugin.getRankedManager().getProfile(target.getUniqueId());
        if (profile == null) {
            mm().sendMessage(player, "general.player-not-found");
            return;
        }

        profile.setElo(elo);
        plugin.getRankedManager().saveProfile(profile);
        mm().sendMessage(player, "admin.setelo-success",
                "{player}", target.getName(),
                "{elo}", String.valueOf(elo));
    }

    private void handleAdminInfo(Player player, String[] args) {
        if (args.length < 3) {
            mm().sendMessage(player, "admin.info-usage");
            return;
        }

        Player target = Bukkit.getPlayerExact(args[2]);
        if (target == null) {
            mm().sendMessage(player, "general.player-not-found");
            return;
        }

        RankedProfile profile = plugin.getRankedManager().getProfile(target.getUniqueId());
        if (profile != null) {
            displayRank(player, profile, target.getName());
        } else {
            mm().sendMessage(player, "general.player-not-found");
        }
    }

    private void handleAdminReload(Player player) {
        plugin.reloadConfig();
        plugin.getMessageManager().load();
        mm().sendMessage(player, "general.reload-success");
    }

    private void openRankedCard(Player player) {
        new RankedGui(plugin, plugin.getCore(), player).open();
    }

    private void showHelp(Player player) {
        mm().sendRaw(player, "");
        mm().sendMessage(player, "help.header");
        mm().sendMessage(player, "help.ranked");
        mm().sendMessage(player, "help.top");
        mm().sendMessage(player, "help.stats");
        mm().sendMessage(player, "help.season");
        mm().sendMessage(player, "help.card");

        if (player.hasPermission("ethernova.ranked.admin")) {
            mm().sendMessage(player, "help.admin-header");
            mm().sendMessage(player, "help.admin-reset");
            mm().sendMessage(player, "help.admin-setelo");
            mm().sendMessage(player, "help.admin-info");
            mm().sendMessage(player, "help.admin-reload");
        }
        mm().sendRaw(player, "");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        List<String> completions = new ArrayList<>();

        if (args.length == 1) {
            completions.addAll(List.of("top", "stats", "season", "card", "help"));
            if (sender.hasPermission("ethernova.ranked.admin")) {
                completions.add("admin");
            }
        } else if (args.length == 2) {
            switch (args[0].toLowerCase()) {
                case "stats", "ver" -> {
                    return Bukkit.getOnlinePlayers().stream()
                            .map(Player::getName)
                            .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase()))
                            .collect(Collectors.toList());
                }
                case "admin" -> {
                    if (sender.hasPermission("ethernova.ranked.admin")) {
                        completions.addAll(List.of("reset", "setelo", "info", "reload", "gui"));
                    }
                }
            }
        } else if (args.length == 3 && "admin".equalsIgnoreCase(args[0])) {
            switch (args[1].toLowerCase()) {
                case "setelo", "info" -> {
                    return Bukkit.getOnlinePlayers().stream()
                            .map(Player::getName)
                            .filter(n -> n.toLowerCase().startsWith(args[2].toLowerCase()))
                            .collect(Collectors.toList());
                }
                case "reset" -> {
                    try {
                        String digits = plugin.getSeasonManager().getCurrentSeason().replaceAll("\\D", "");
                        int nextNum = digits.isEmpty() ? 1 : Integer.parseInt(digits) + 1;
                        completions.add("s" + nextNum);
                    } catch (NumberFormatException ignored) {
                        completions.add("s1");
                    }
                }
            }
        } else if (args.length == 4 && "admin".equalsIgnoreCase(args[0])) {
            switch (args[1].toLowerCase()) {
                case "setelo" -> completions.addAll(List.of("1000", "1500", "2000", "2500", "3000"));
                case "reset" -> completions.add("Temporada");
            }
        }

        String lastArg = args[args.length - 1].toLowerCase();
        return completions.stream()
                .filter(c -> c.toLowerCase().startsWith(lastArg))
                .collect(Collectors.toList());
    }
}
