package com.ethernova.ranked.model;

import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Perfil de clasificación Glicko-2 de un jugador.
 * Almacena Rating, RD (Rating Deviation), Volatilidad, estadísticas y rachas.
 * <p>
 * El sistema Glicko-2 rastrea tres valores por jugador:
 * <ul>
 *     <li><b>Rating (μ)</b> — Equivalente a ELO. Representa la habilidad estimada.</li>
 *     <li><b>RD (Rating Deviation / φ)</b> — Incertidumbre del rating. Alto = poco fiable.</li>
 *     <li><b>Volatility (σ)</b> — Consistencia del jugador. Bajo = rendimiento estable.</li>
 * </ul>
 * <p>
 * Thread-safety: Compound stats operations (addWin/addLoss) are synchronized.
 * Rating/RD/Volatility are updated atomically via synchronized setters when called from processResult.
 */
public class RankedProfile {

    private final UUID uuid;
    private volatile double rating;
    private volatile double rd;
    private volatile double volatility;
    private final AtomicInteger wins = new AtomicInteger();
    private final AtomicInteger losses = new AtomicInteger();
    private volatile int winStreak;
    private volatile int lossStreak;
    private volatile int bestWinStreak;
    private volatile int peakRating;
    private volatile Rank currentRank;
    private volatile String season;
    private volatile int placementMatchesPlayed;
    private volatile long lastPlayed;
    private volatile boolean dirty;
    /** Demotion protection: shields remaining at current rank boundary */
    private volatile int demotionShield;

    public RankedProfile(UUID uuid, double rating, double rd, double volatility,
                         int wins, int losses, int winStreak, int lossStreak,
                         int bestWinStreak, int peakRating, String season,
                         int placementMatchesPlayed, long lastPlayed) {
        this.uuid = uuid;
        this.rating = rating;
        this.rd = rd;
        this.volatility = volatility;
        this.wins.set(wins);
        this.losses.set(losses);
        this.winStreak = winStreak;
        this.lossStreak = lossStreak;
        this.bestWinStreak = bestWinStreak;
        this.peakRating = Math.max(peakRating, (int) Math.round(rating));
        this.season = season;
        this.placementMatchesPlayed = placementMatchesPlayed;
        this.lastPlayed = lastPlayed;
        this.currentRank = Rank.fromElo(getElo());
        this.demotionShield = 0;
        this.dirty = false;
    }

    /** Backward-compatible constructor (no peakRating). */
    public RankedProfile(UUID uuid, double rating, double rd, double volatility,
                         int wins, int losses, int winStreak, int lossStreak,
                         int bestWinStreak, String season, int placementMatchesPlayed, long lastPlayed) {
        this(uuid, rating, rd, volatility, wins, losses, winStreak, lossStreak,
                bestWinStreak, (int) Math.round(rating), season, placementMatchesPlayed, lastPlayed);
    }

    /**
     * Crea un nuevo perfil con valores Glicko-2 por defecto.
     */
    public static RankedProfile createNew(UUID uuid, double startRating, double startRd,
                                           double startVol, String season) {
        return new RankedProfile(uuid, startRating, startRd, startVol,
                0, 0, 0, 0, 0, (int) Math.round(startRating), season, 0, System.currentTimeMillis());
    }

    /**
     * Backward-compatible factory. Uses Glicko-2 defaults.
     */
    public static RankedProfile createNew(UUID uuid, int startingElo, String season) {
        return createNew(uuid, startingElo, 350.0, 0.06, season);
    }

    public UUID getUuid() { return uuid; }

    // ═══════════════ Rating (display como int "ELO") ═══════════════

    public int getElo() { return (int) Math.round(rating); }

    public double getRating() { return rating; }

    /** Establece el rating. Aplica floor, actualiza rango y peak. Thread-safe. */
    public synchronized void setRating(double rating) {
        this.rating = Math.max(0, rating);
        int elo = getElo();
        this.currentRank = Rank.fromElo(elo);
        if (elo > this.peakRating) {
            this.peakRating = elo;
        }
        this.dirty = true;
    }

    public void setElo(int elo) { setRating(elo); }

    // ═══════════════ Glicko-2 Parameters ═══════════════

    public double getRd() { return rd; }

    public void setRd(double rd) {
        this.rd = rd;
        this.dirty = true;
    }

    public double getVolatility() { return volatility; }

    public void setVolatility(double volatility) {
        this.volatility = volatility;
        this.dirty = true;
    }

    // ═══════════════ Estadísticas (Thread-safe) ═══════════════

    public int getWins() { return wins.get(); }

    /** Registra una victoria. Thread-safe via synchronized. */
    public synchronized void addWin() {
        this.wins.incrementAndGet();
        this.winStreak++;
        this.lossStreak = 0;
        if (this.winStreak > this.bestWinStreak) {
            this.bestWinStreak = this.winStreak;
        }
        this.lastPlayed = System.currentTimeMillis();
        this.dirty = true;
    }

    public int getLosses() { return losses.get(); }

    /** Registra una derrota. Thread-safe via synchronized. */
    public synchronized void addLoss() {
        this.losses.incrementAndGet();
        this.lossStreak++;
        this.winStreak = 0;
        this.lastPlayed = System.currentTimeMillis();
        this.dirty = true;
    }

    public int getWinStreak() { return winStreak; }

    public int getLossStreak() { return lossStreak; }

    public int getBestWinStreak() { return bestWinStreak; }

    /** Peak rating alcanzado en esta temporada. */
    public int getPeakRating() { return peakRating; }

    /** Establece el peak rating (usado al cargar de DB). */
    public void setPeakRating(int peakRating) {
        this.peakRating = peakRating;
    }

    public Rank getCurrentRank() { return currentRank; }

    public String getSeason() { return season; }

    public void setSeason(String season) {
        this.season = season;
        this.dirty = true;
    }

    public int getPlacementMatchesPlayed() { return placementMatchesPlayed; }

    public void incrementPlacementMatches() {
        this.placementMatchesPlayed++;
        this.dirty = true;
    }

    public long getLastPlayed() { return lastPlayed; }

    public void setLastPlayed(long lastPlayed) {
        this.lastPlayed = lastPlayed;
        this.dirty = true;
    }

    public int getTotalGames() { return wins.get() + losses.get(); }

    public double getWinRate() {
        int total = getTotalGames();
        return total == 0 ? 0.0 : (double) wins.get() / total;
    }

    public String getWinRateFormatted() {
        return String.format("%.1f%%", getWinRate() * 100);
    }

    public boolean isDirty() { return dirty; }

    public void setDirty(boolean dirty) { this.dirty = dirty; }

    public boolean isInPlacements(int requiredMatches) {
        return placementMatchesPlayed < requiredMatches;
    }

    public String getRdFormatted() {
        return String.valueOf((int) Math.round(rd));
    }

    public String getConfidenceInterval() {
        int lower = Math.max(0, (int) Math.round(rating - 1.96 * rd));
        int upper = (int) Math.round(rating + 1.96 * rd);
        return lower + " - " + upper;
    }

    // ═══════════════ Demotion Protection ═══════════════

    /** Shields restantes de protección de bajada de rango. */
    public int getDemotionShield() { return demotionShield; }

    /** Activa protección de bajada con N escudos. */
    public void setDemotionShield(int shields) {
        this.demotionShield = shields;
        this.dirty = true;
    }

    /** Consume un escudo de protección. @return true si quedaba escudo. */
    public boolean consumeDemotionShield() {
        if (demotionShield > 0) {
            demotionShield--;
            this.dirty = true;
            return true;
        }
        return false;
    }

    // ═══════════════ Season Resets ═══════════════

    /**
     * Hard reset — todo a valores por defecto.
     */
    public synchronized void resetForNewSeason(double startRating, double startRd, double startVol, String newSeason) {
        this.rating = startRating;
        this.rd = startRd;
        this.volatility = startVol;
        this.wins.set(0);
        this.losses.set(0);
        this.winStreak = 0;
        this.lossStreak = 0;
        this.bestWinStreak = 0;
        this.peakRating = (int) Math.round(startRating);
        this.placementMatchesPlayed = 0;
        this.season = newSeason;
        this.demotionShield = 0;
        this.currentRank = Rank.fromElo(getElo());
        this.dirty = true;
    }

    /**
     * Soft reset para nueva temporada (estilo CoD Mobile + regresión a la media).
     * El jugador baja X rangos con regresión parcial a la media dentro del rango destino.
     * Stats y rachas se reinician, RD sube.
     *
     * @param dropRanks     Cuántos rangos bajar (ej: 2 = Diamante→Oro)
     * @param resetRd       RD después del reset (más incertidumbre)
     * @param resetVol      Volatilidad después del reset
     * @param newSeason     ID de la nueva temporada
     * @param defaultRating Rating por defecto del sistema (para regresión a la media)
     */
    public synchronized void softResetForNewSeason(int dropRanks, double resetRd, double resetVol,
                                       String newSeason, double defaultRating) {
        Rank currentRk = Rank.fromElo(getElo());
        Rank targetRank = currentRk;
        for (int i = 0; i < dropRanks; i++) {
            Rank prev = targetRank.previous();
            if (prev == null) break;
            targetRank = prev;
        }

        // Regresión parcial a la media: midpoint entre rating actual y rating por defecto,
        // pero clampado al rango destino. Preserva el orden dentro del rango.
        double regressionTarget = (this.rating + defaultRating) / 2.0;
        double rankMin = targetRank.getMinElo();
        double rankMax = targetRank.getMaxElo() == Integer.MAX_VALUE
                ? targetRank.getMinElo() + 500 : targetRank.getMaxElo();
        // El nuevo rating es el regresión clampado al rango destino
        double newRating = Math.max(rankMin, Math.min(rankMax, regressionTarget));

        this.rating = newRating;
        this.rd = resetRd;
        this.volatility = resetVol;
        this.wins.set(0);
        this.losses.set(0);
        this.winStreak = 0;
        this.lossStreak = 0;
        this.bestWinStreak = 0;
        this.peakRating = (int) Math.round(newRating);
        this.placementMatchesPlayed = 0;
        this.season = newSeason;
        this.demotionShield = 0;
        this.currentRank = targetRank;
        this.dirty = true;
    }

    /** Backward-compatible soft reset (no defaultRating parameter). */
    public void softResetForNewSeason(int dropRanks, double resetRd, double resetVol, String newSeason) {
        softResetForNewSeason(dropRanks, resetRd, resetVol, newSeason, 1500.0);
    }
}
