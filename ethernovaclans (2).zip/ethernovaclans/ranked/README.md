# EthernovaRanked

> Sistema de ELO y clasificación competitiva.

## Características

- **Sistema ELO** — Basado en fórmula ELO estándar con K-factor dinámico
- **Rangos** — Bronze → Silver → Gold → Platinum → Diamond → Master → Grandmaster → Challenger
- **Temporadas** — Reset periódico con archivo histórico
- **Leaderboards** — Rankings globales con caché
- **Perfiles** — Estadísticas detalladas por jugador
- **Colocación** — Partidas de clasificación con K-factor alto
- **Admin** — Panel de administración GUI

## API

```java
RankedAPI api = ServiceRegistry.get(RankedAPI.class);
api.getElo(uuid);
api.getRank(uuid);
api.getWins(uuid);
api.getLosses(uuid);
api.getWinStreak(uuid);
api.processResult(winnerId, loserId);
api.previewEloChange(1000, 1200, true, 50);
api.getCurrentSeason();
```

## Comandos

| Comando | Descripción |
|---------|-------------|
| `/ranked` | Ver perfil ranked |
| `/ranked top` | Ver leaderboard |
| `/ranked stats <jugador>` | Ver stats de otro |
| `/ranked admin` | Panel de administración |

## Placeholders

| Placeholder | Descripción |
|-------------|-------------|
| `%ranked_elo%` | ELO actual |
| `%ranked_rank%` | Rango actual |
| `%ranked_wins%` | Victorias |
| `%ranked_losses%` | Derrotas |
| `%ranked_win_streak%` | Racha actual |
