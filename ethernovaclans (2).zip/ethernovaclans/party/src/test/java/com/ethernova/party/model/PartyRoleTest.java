package com.ethernova.party.model;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import static org.junit.jupiter.api.Assertions.*;

class PartyRoleTest {

    @Nested
    @DisplayName("Permission checks")
    class PermissionTests {
        @Test void leaderCanInvite() { assertTrue(PartyRole.LEADER.canInvite()); }
        @Test void moderatorCanInvite() { assertTrue(PartyRole.MODERATOR.canInvite()); }
        @Test void memberCannotInvite() { assertFalse(PartyRole.MEMBER.canInvite()); }

        @Test void leaderCanKick() { assertTrue(PartyRole.LEADER.canKick()); }
        @Test void moderatorCanKick() { assertTrue(PartyRole.MODERATOR.canKick()); }
        @Test void memberCannotKick() { assertFalse(PartyRole.MEMBER.canKick()); }

        @Test void leaderCanManageSettings() { assertTrue(PartyRole.LEADER.canManageSettings()); }
        @Test void moderatorCannotManageSettings() { assertFalse(PartyRole.MODERATOR.canManageSettings()); }
        @Test void memberCannotManageSettings() { assertFalse(PartyRole.MEMBER.canManageSettings()); }

        @Test void leaderCanTeleport() { assertTrue(PartyRole.LEADER.canTeleport()); }
        @Test void moderatorCanTeleport() { assertTrue(PartyRole.MODERATOR.canTeleport()); }
        @Test void memberCannotTeleport() { assertFalse(PartyRole.MEMBER.canTeleport()); }
    }

    @Nested
    @DisplayName("isHigherThan()")
    class HierarchyTests {
        @Test void leaderHigherThanModerator() { assertTrue(PartyRole.LEADER.isHigherThan(PartyRole.MODERATOR)); }
        @Test void leaderHigherThanMember() { assertTrue(PartyRole.LEADER.isHigherThan(PartyRole.MEMBER)); }
        @Test void moderatorHigherThanMember() { assertTrue(PartyRole.MODERATOR.isHigherThan(PartyRole.MEMBER)); }
        @Test void memberNotHigherThanModerator() { assertFalse(PartyRole.MEMBER.isHigherThan(PartyRole.MODERATOR)); }
        @Test void sameRoleNotHigher() { assertFalse(PartyRole.LEADER.isHigherThan(PartyRole.LEADER)); }
    }

    @ParameterizedTest
    @EnumSource(PartyRole.class)
    @DisplayName("Every role has display name and icon")
    void displayMetadata(PartyRole role) {
        assertNotNull(role.getDisplayName());
        assertNotNull(role.getIcon());
        assertFalse(role.getDisplayName().isEmpty());
    }

    @Test
    @DisplayName("Three roles exist")
    void threeRoles() {
        assertEquals(3, PartyRole.values().length);
    }
}
