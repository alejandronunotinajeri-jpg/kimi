package com.ethernova.party.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.Set;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class PartyTest {

    private UUID leader;
    private UUID member1;
    private UUID member2;
    private Party party;

    @BeforeEach
    void setUp() {
        leader = UUID.randomUUID();
        member1 = UUID.randomUUID();
        member2 = UUID.randomUUID();
        party = new Party(leader, 5);
    }

    @Nested
    @DisplayName("Construction")
    class ConstructionTests {
        @Test void leaderIsSet() { assertEquals(leader, party.getLeaderUuid()); }
        @Test void leaderIsMember() { assertTrue(party.isMember(leader)); }
        @Test void leaderHasLeaderRole() { assertEquals(PartyRole.LEADER, party.getRole(leader)); }
        @Test void sizeIsOne() { assertEquals(1, party.getSize()); }
        @Test void isNotFull() { assertFalse(party.isFull()); }
        @Test void isDirty() { assertTrue(party.isDirty()); }
        @Test void partyIdNotNull() { assertNotNull(party.getPartyId()); }
    }

    @Nested
    @DisplayName("invite() & accept()")
    class InviteAcceptTests {
        @Test
        void inviteSucceeds() {
            assertTrue(party.invite(member1));
            assertTrue(party.isInvited(member1));
        }

        @Test
        void inviteExistingMemberFails() {
            assertFalse(party.invite(leader));
        }

        @Test
        void inviteAlreadyInvitedFails() {
            party.invite(member1);
            assertFalse(party.invite(member1));
        }

        @Test
        void inviteWhenFullFails() {
            party.setMaxSize(1);
            assertFalse(party.invite(member1));
        }

        @Test
        void acceptWithInvite() {
            party.invite(member1);
            assertTrue(party.accept(member1));
            assertTrue(party.isMember(member1));
            assertEquals(PartyRole.MEMBER, party.getRole(member1));
        }

        @Test
        void acceptWithoutInviteInPrivateFails() {
            assertFalse(party.accept(member1));
        }

        @Test
        void acceptWithoutInviteInPublicSucceeds() {
            party.setPublic(true);
            assertTrue(party.accept(member1));
        }

        @Test
        void acceptWhenFullFails() {
            party.setMaxSize(1);
            party.invite(member1);
            assertFalse(party.accept(member1));
        }

        @Test
        void acceptRemovesInvite() {
            party.invite(member1);
            party.accept(member1);
            assertFalse(party.isInvited(member1));
        }
    }

    @Nested
    @DisplayName("kick()")
    class KickTests {
        @Test
        void kickMemberSucceeds() {
            party.invite(member1);
            party.accept(member1);
            assertTrue(party.kick(member1));
            assertFalse(party.isMember(member1));
        }

        @Test
        void kickLeaderFails() {
            assertFalse(party.kick(leader));
        }

        @Test
        void kickNonMemberFails() {
            assertFalse(party.kick(member1));
        }
    }

    @Nested
    @DisplayName("promote() — transfer leadership")
    class PromoteTests {
        @Test
        void promoteMemberToLeader() {
            party.invite(member1);
            party.accept(member1);
            assertTrue(party.promote(member1));
            assertEquals(member1, party.getLeaderUuid());
            assertEquals(PartyRole.LEADER, party.getRole(member1));
            assertEquals(PartyRole.MODERATOR, party.getRole(leader));
        }

        @Test
        void promoteLeaderFails() {
            assertFalse(party.promote(leader));
        }

        @Test
        void promoteNonMemberFails() {
            assertFalse(party.promote(member1));
        }
    }

    @Nested
    @DisplayName("promoteToModerator()")
    class PromoteModTests {
        @Test
        void promoteRegularMember() {
            party.invite(member1);
            party.accept(member1);
            assertTrue(party.promoteToModerator(member1));
            assertEquals(PartyRole.MODERATOR, party.getRole(member1));
        }

        @Test
        void promoteAlreadyModeratorFails() {
            party.invite(member1);
            party.accept(member1);
            party.promoteToModerator(member1);
            assertFalse(party.promoteToModerator(member1));
        }

        @Test
        void promoteLeaderFails() {
            assertFalse(party.promoteToModerator(leader));
        }
    }

    @Nested
    @DisplayName("demoteToMember()")
    class DemoteTests {
        @Test
        void demoteModerator() {
            party.invite(member1);
            party.accept(member1);
            party.promoteToModerator(member1);
            assertTrue(party.demoteToMember(member1));
            assertEquals(PartyRole.MEMBER, party.getRole(member1));
        }

        @Test
        void demoteRegularMemberFails() {
            party.invite(member1);
            party.accept(member1);
            assertFalse(party.demoteToMember(member1));
        }

        @Test
        void demoteLeaderFails() {
            assertFalse(party.demoteToMember(leader));
        }
    }

    @Nested
    @DisplayName("disband()")
    class DisbandTests {
        @Test
        void returnsPreviousMembers() {
            party.invite(member1);
            party.accept(member1);
            Set<UUID> prev = party.disband();
            assertEquals(2, prev.size());
            assertTrue(prev.contains(leader));
            assertTrue(prev.contains(member1));
        }

        @Test
        void partyEmptyAfterDisband() {
            party.disband();
            assertTrue(party.isEmpty());
        }
    }

    @Nested
    @DisplayName("isFull()")
    class FullTests {
        @Test
        void fullAtMaxSize() {
            party.setMaxSize(2);
            party.invite(member1);
            party.accept(member1);
            assertTrue(party.isFull());
        }

        @Test
        void notFullUnderMax() {
            party.setMaxSize(10);
            assertFalse(party.isFull());
        }
    }

    @Nested
    @DisplayName("Dirty tracking")
    class DirtyTests {
        @Test
        void clearDirty() {
            party.clearDirty();
            assertFalse(party.isDirty());
        }

        @Test
        void inviteLeavesClean() {
            party.clearDirty();
            party.invite(member1);
            assertFalse(party.isDirty()); // invite doesn't mark dirty
        }

        @Test
        void acceptMarksDirty() {
            party.clearDirty();
            party.invite(member1);
            party.accept(member1);
            assertTrue(party.isDirty());
        }

        @Test
        void kickMarksDirty() {
            party.invite(member1);
            party.accept(member1);
            party.clearDirty();
            party.kick(member1);
            assertTrue(party.isDirty());
        }

        @Test
        void setNameMarksDirty() {
            party.clearDirty();
            party.setName("TestParty");
            assertTrue(party.isDirty());
        }
    }

    @Nested
    @DisplayName("removeInvite()")
    class RemoveInviteTests {
        @Test
        void removesInvite() {
            party.invite(member1);
            party.removeInvite(member1);
            assertFalse(party.isInvited(member1));
        }
    }

    @Nested
    @DisplayName("DB constructor")
    class DbConstructorTests {
        @Test
        void restoresClean() {
            Party restored = new Party(UUID.randomUUID(), leader, "TestParty",
                    new PartySettings(), System.currentTimeMillis());
            assertFalse(restored.isDirty());
            assertEquals("TestParty", restored.getName());
        }

        @Test
        void nullSettingsDefaultsToNew() {
            Party restored = new Party(UUID.randomUUID(), leader, null, null, 0);
            assertNotNull(restored.getSettings());
        }
    }
}
