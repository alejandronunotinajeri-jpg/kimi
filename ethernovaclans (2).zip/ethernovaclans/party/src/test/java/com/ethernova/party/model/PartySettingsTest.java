package com.ethernova.party.model;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PartySettingsTest {

    @Nested
    @DisplayName("Defaults")
    class DefaultTests {
        private final PartySettings settings = new PartySettings();

        @Test void friendlyFire() { assertFalse(settings.isFriendlyFire()); }
        @Test void autoAcceptFriends() { assertFalse(settings.isAutoAcceptFriends()); }
        @Test void isPublic() { assertFalse(settings.isPublic()); }
        @Test void maxSize() { assertEquals(5, settings.getMaxSize()); }
        @Test void allowModeratorInvite() { assertTrue(settings.isAllowModeratorInvite()); }
        @Test void partyChat() { assertTrue(settings.isPartyChat()); }
    }

    @Nested
    @DisplayName("JSON serialization round-trip")
    class JsonTests {
        @Test
        void roundTrip() {
            PartySettings original = new PartySettings();
            original.setFriendlyFire(true);
            original.setMaxSize(10);
            original.setPublic(true);

            String json = original.toJson();
            PartySettings restored = PartySettings.fromJson(json);

            assertTrue(restored.isFriendlyFire());
            assertEquals(10, restored.getMaxSize());
            assertTrue(restored.isPublic());
        }

        @Test
        void nullJsonReturnsDefault() {
            PartySettings settings = PartySettings.fromJson(null);
            assertNotNull(settings);
            assertEquals(5, settings.getMaxSize());
        }

        @Test
        void emptyJsonReturnsDefault() {
            PartySettings settings = PartySettings.fromJson("");
            assertNotNull(settings);
        }

        @Test
        void invalidJsonReturnsDefault() {
            PartySettings settings = PartySettings.fromJson("{invalid json!!!");
            assertNotNull(settings);
            assertEquals(5, settings.getMaxSize());
        }

        @Test
        void allFieldsSerialized() {
            PartySettings settings = new PartySettings();
            settings.setFriendlyFire(true);
            settings.setAutoAcceptFriends(true);
            settings.setPublic(true);
            settings.setMaxSize(20);
            settings.setAllowModeratorInvite(false);
            settings.setPartyChat(false);

            PartySettings restored = PartySettings.fromJson(settings.toJson());
            assertTrue(restored.isFriendlyFire());
            assertTrue(restored.isAutoAcceptFriends());
            assertTrue(restored.isPublic());
            assertEquals(20, restored.getMaxSize());
            assertFalse(restored.isAllowModeratorInvite());
            assertFalse(restored.isPartyChat());
        }
    }
}
