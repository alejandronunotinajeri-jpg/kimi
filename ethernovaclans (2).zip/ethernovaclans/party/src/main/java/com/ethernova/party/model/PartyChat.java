package com.ethernova.party.model;

import com.ethernova.party.EthernovaParty;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages party chat mode toggling and message broadcasting.
 * Players with chat mode enabled will have their messages sent to party members only.
 */
public class PartyChat {

    private static final MiniMessage MINI = MiniMessage.miniMessage();

    private final EthernovaParty plugin;
    private final Set<UUID> chatToggledPlayers = ConcurrentHashMap.newKeySet();

    public PartyChat(EthernovaParty plugin) {
        this.plugin = plugin;
    }

    /**
     * Toggle party chat mode for a player.
     * @return true if chat mode is now enabled, false if disabled
     */
    public boolean toggle(UUID uuid) {
        if (chatToggledPlayers.contains(uuid)) {
            chatToggledPlayers.remove(uuid);
            return false;
        } else {
            chatToggledPlayers.add(uuid);
            return true;
        }
    }

    /**
     * Check if a player has party chat mode enabled.
     */
    public boolean isChatEnabled(UUID uuid) {
        return chatToggledPlayers.contains(uuid);
    }

    /**
     * Disable party chat mode for a player (e.g., when leaving party).
     */
    public void disable(UUID uuid) {
        chatToggledPlayers.remove(uuid);
    }

    /**
     * Format a party chat message using the configured format.
     */
    public Component formatMessage(Player sender, String message) {
        String format = plugin.getConfig().getString("chat.format",
                "<gradient:#00d4ff:#00ff88>⚔ Party</gradient> <dark_gray>|</dark_gray> <white>{player}</white> <dark_gray>»</dark_gray> <gray>{message}");
        String formatted = format
                .replace("{player}", sender.getName())
                .replace("{message}", message);
        return MINI.deserialize(formatted);
    }

    /**
     * Broadcast a message to all online party members.
     */
    public void broadcast(Party party, Player sender, String message) {
        Component formatted = formatMessage(sender, message);
        for (UUID memberUuid : party.getMembers()) {
            Player member = Bukkit.getPlayer(memberUuid);
            if (member != null && member.isOnline()) {
                member.sendMessage(formatted);
            }
        }
    }

    /**
     * Broadcast a system component to all online party members.
     */
    public void broadcastComponent(Party party, Component component) {
        for (UUID memberUuid : party.getMembers()) {
            Player member = Bukkit.getPlayer(memberUuid);
            if (member != null && member.isOnline()) {
                member.sendMessage(component);
            }
        }
    }

    /**
     * Clear all toggled states (e.g., on plugin disable).
     */
    public void clearAll() {
        chatToggledPlayers.clear();
    }
}
