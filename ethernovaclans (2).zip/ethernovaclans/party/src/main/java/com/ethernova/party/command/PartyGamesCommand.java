package com.ethernova.party.command;

import com.ethernova.party.EthernovaParty;
import com.ethernova.party.games.PartyGamesManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Handles party game commands:
 * /partygame start <type> - Start a party game
 * /partygame stop - Stop the current party game
 * /partygame list - List available game types
 * /partygame info - Show current game info
 */
public class PartyGamesCommand implements CommandExecutor, TabCompleter {

    private final EthernovaParty plugin;
    private final MiniMessage mini = MiniMessage.miniMessage();

    private static final List<String> SUBCOMMANDS = List.of("start", "stop", "list", "info");

    public PartyGamesCommand(EthernovaParty plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(mini.deserialize("<red>Este comando solo puede ser usado por jugadores."));
            return true;
        }

        if (!player.hasPermission("ethernova.party.use")) {
            player.sendMessage(mini.deserialize("<red>No tienes permiso para usar este comando."));
            return true;
        }

        PartyGamesManager gamesManager = plugin.getPartyGamesManager();
        if (gamesManager == null) {
            player.sendMessage(mini.deserialize("<red>El sistema de juegos de grupo no está disponible."));
            return true;
        }

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "start", "iniciar" -> {
                if (args.length < 2) {
                    player.sendMessage(mini.deserialize(
                            "<red>Uso: /" + label + " start <tipo>"));
                    player.sendMessage(mini.deserialize(
                            "<gray>Tipos: " + getGameTypesString()));
                    return true;
                }
                try {
                    PartyGamesManager.GameType type =
                            PartyGamesManager.GameType.valueOf(args[1].toUpperCase());
                    gamesManager.startGame(player, type);
                } catch (IllegalArgumentException e) {
                    player.sendMessage(mini.deserialize(
                            "<red>Tipo de juego no válido. Tipos disponibles:"));
                    player.sendMessage(mini.deserialize(
                            "<gray>" + getGameTypesString()));
                }
            }

            case "stop", "parar" -> {
                gamesManager.stopGame(player);
            }

            case "list", "lista" -> {
                player.sendMessage(mini.deserialize(
                        "<gradient:gold:yellow>═══ Juegos de Grupo Disponibles ═══</gradient>"));
                for (PartyGamesManager.GameType type : PartyGamesManager.GameType.values()) {
                    player.sendMessage(mini.deserialize(
                            "<yellow>▸ <white>" + type.name()
                                    + " <gray>(" + type.getMinPlayers() + "-" + type.getMaxPlayers() + " jugadores)"));
                }
            }

            case "info" -> {
                var session = gamesManager.getPlayerSession(player.getUniqueId());
                if (session == null) {
                    player.sendMessage(mini.deserialize(
                            "<red>No estás en ningún juego de grupo activo."));
                } else {
                    player.sendMessage(mini.deserialize(
                            "<gradient:gold:yellow>═══ Juego Activo ═══</gradient>"));
                    player.sendMessage(mini.deserialize(
                            "<yellow>Tipo: <white>" + session.getType().name()));
                    player.sendMessage(mini.deserialize(
                            "<yellow>Jugadores vivos: <white>" + session.getAlive().size()
                                    + "/" + session.getParticipants().size()));
                    player.sendMessage(mini.deserialize(
                            "<yellow>Fase: <white>" + session.getPhase()));
                }
            }

            default -> sendHelp(player);
        }

        return true;
    }

    private void sendHelp(Player player) {
        player.sendMessage(mini.deserialize(
                "<gradient:gold:yellow>═══ Juegos de Grupo ═══</gradient>"));
        player.sendMessage(mini.deserialize(
                "<yellow>/partygame start <tipo> <gray>- Iniciar un juego"));
        player.sendMessage(mini.deserialize(
                "<yellow>/partygame stop <gray>- Detener el juego actual"));
        player.sendMessage(mini.deserialize(
                "<yellow>/partygame list <gray>- Ver juegos disponibles"));
        player.sendMessage(mini.deserialize(
                "<yellow>/partygame info <gray>- Info del juego actual"));
    }

    private String getGameTypesString() {
        StringBuilder sb = new StringBuilder();
        PartyGamesManager.GameType[] types = PartyGamesManager.GameType.values();
        for (int i = 0; i < types.length; i++) {
            if (i > 0) sb.append(", ");
            sb.append(types[i].name().toLowerCase());
        }
        return sb.toString();
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                 @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) {
            return SUBCOMMANDS.stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .sorted()
                    .collect(Collectors.toList());
        }

        if (args.length == 2 && "start".equalsIgnoreCase(args[0])) {
            List<String> types = new ArrayList<>();
            for (PartyGamesManager.GameType type : PartyGamesManager.GameType.values()) {
                types.add(type.name().toLowerCase());
            }
            return types.stream()
                    .filter(s -> s.startsWith(args[1].toLowerCase()))
                    .sorted()
                    .collect(Collectors.toList());
        }

        return Collections.emptyList();
    }
}
