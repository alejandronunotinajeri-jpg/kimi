package com.ethernova.party.storage;

import com.ethernova.core.EthernovaCore;
import com.ethernova.party.EthernovaParty;
import com.ethernova.party.model.Party;
import com.ethernova.party.model.PartyRole;
import com.ethernova.party.model.PartySettings;
import org.bukkit.Bukkit;

import java.sql.*;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;

/**
 * Handles party persistence to the Core database.
 * Uses async operations for all DB calls to avoid blocking the main thread.
 *
 * Tables:
 *   ethernova_parties: id, leader_uuid, name, settings_json, created_at, updated_at
 *   ethernova_party_members: party_id, uuid, role, joined_at
 */
public class PartyStorageManager {

    private final EthernovaParty plugin;
    private final EthernovaCore core;

    public PartyStorageManager(EthernovaParty plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
    }

    /**
     * Create the party tables if they don't exist.
     */
    public void createTables() {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (Connection conn = core.getStorageManager().getConnection();
                 Statement stmt = conn.createStatement()) {

                boolean isMySQL = core.getStorageManager().isMySQL();

                stmt.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS ethernova_parties (
                        id VARCHAR(36) PRIMARY KEY,
                        leader_uuid VARCHAR(36) NOT NULL,
                        name VARCHAR(64),
                        settings_json TEXT DEFAULT '{}',
                        created_at BIGINT NOT NULL,
                        updated_at BIGINT NOT NULL
                    )
                """);

                stmt.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS ethernova_party_members (
                        party_id VARCHAR(36) NOT NULL,
                        uuid VARCHAR(36) NOT NULL,
                        role VARCHAR(16) NOT NULL DEFAULT 'MEMBER',
                        joined_at BIGINT NOT NULL,
                        PRIMARY KEY (party_id, uuid)
                    )
                """);

                // Index for quick player → party lookup
                try {
                    stmt.executeUpdate(
                        "CREATE INDEX IF NOT EXISTS idx_party_members_uuid ON ethernova_party_members(uuid)");
                    stmt.executeUpdate(
                        "CREATE INDEX IF NOT EXISTS idx_parties_leader ON ethernova_parties(leader_uuid)");
                } catch (SQLException ignored) {
                    // Index might already exist in some DB engines
                }

                plugin.getLogger().info("Party tables initialized.");
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to create party tables", e);
            }
        });
    }

    /**
     * Save a party and its members to the database asynchronously.
     */
    public CompletableFuture<Void> saveParty(Party party) {
        return CompletableFuture.runAsync(() -> {
            try (Connection conn = core.getStorageManager().getConnection()) {
                conn.setAutoCommit(false);
                try {
                    // Upsert party
                    boolean isMySQL = core.getStorageManager().isMySQL();
                    String partySql;
                    if (isMySQL) {
                        partySql = """
                            INSERT INTO ethernova_parties (id, leader_uuid, name, settings_json, created_at, updated_at)
                            VALUES (?, ?, ?, ?, ?, ?)
                            ON DUPLICATE KEY UPDATE leader_uuid = VALUES(leader_uuid), name = VALUES(name),
                            settings_json = VALUES(settings_json), updated_at = VALUES(updated_at)
                        """;
                    } else {
                        partySql = """
                            INSERT OR REPLACE INTO ethernova_parties (id, leader_uuid, name, settings_json, created_at, updated_at)
                            VALUES (?, ?, ?, ?, ?, ?)
                        """;
                    }

                    try (PreparedStatement ps = conn.prepareStatement(partySql)) {
                        ps.setString(1, party.getPartyId().toString());
                        ps.setString(2, party.getLeaderUuid().toString());
                        ps.setString(3, party.getName());
                        ps.setString(4, party.getSettings().toJson());
                        ps.setLong(5, party.getCreated());
                        ps.setLong(6, System.currentTimeMillis());
                        ps.executeUpdate();
                    }

                    // Delete old members and re-insert
                    try (PreparedStatement ps = conn.prepareStatement(
                            "DELETE FROM ethernova_party_members WHERE party_id = ?")) {
                        ps.setString(1, party.getPartyId().toString());
                        ps.executeUpdate();
                    }

                    // Insert current members
                    try (PreparedStatement ps = conn.prepareStatement(
                            "INSERT INTO ethernova_party_members (party_id, uuid, role, joined_at) VALUES (?, ?, ?, ?)")) {
                        for (UUID memberUuid : party.getMembers()) {
                            ps.setString(1, party.getPartyId().toString());
                            ps.setString(2, memberUuid.toString());
                            var role = party.getRole(memberUuid);
                            ps.setString(3, role != null ? role.name() : "MEMBER");
                            ps.setLong(4, System.currentTimeMillis());
                            ps.addBatch();
                        }
                        ps.executeBatch();
                    }

                    conn.commit();
                } catch (SQLException e) {
                    conn.rollback();
                    throw e;
                } finally {
                    conn.setAutoCommit(true);
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Failed to save party " + party.getPartyId(), e);
            }
        }, core.getDbExecutor()).exceptionally(ex -> {
            plugin.getLogger().log(Level.SEVERE, "Unhandled error saving party", ex);
            return null;
        });
    }

    /**
     * Delete a party and its members from the database asynchronously.
     */
    public CompletableFuture<Void> deleteParty(UUID partyId) {
        return CompletableFuture.runAsync(() -> {
            try (Connection conn = core.getStorageManager().getConnection()) {
                conn.setAutoCommit(false);
                try {
                    try (PreparedStatement ps = conn.prepareStatement(
                            "DELETE FROM ethernova_party_members WHERE party_id = ?")) {
                        ps.setString(1, partyId.toString());
                        ps.executeUpdate();
                    }
                    try (PreparedStatement ps = conn.prepareStatement(
                            "DELETE FROM ethernova_parties WHERE id = ?")) {
                        ps.setString(1, partyId.toString());
                        ps.executeUpdate();
                    }
                    conn.commit();
                } catch (SQLException e) {
                    conn.rollback();
                    throw e;
                } finally {
                    conn.setAutoCommit(true);
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Failed to delete party " + partyId, e);
            }
        }, core.getDbExecutor()).exceptionally(ex -> {
            plugin.getLogger().log(Level.SEVERE, "Unhandled error deleting party", ex);
            return null;
        });
    }

    /**
     * Load all active parties from the database.
     * Called on plugin enable to restore state after restart.
     * @return Map of partyId → Party
     */
    public CompletableFuture<Map<UUID, Party>> loadAllParties(int defaultMaxSize) {
        return CompletableFuture.supplyAsync(() -> {
            Map<UUID, Party> result = new HashMap<>();
            try (Connection conn = core.getStorageManager().getConnection()) {
                // Load parties
                try (PreparedStatement ps = conn.prepareStatement(
                        "SELECT id, leader_uuid, name, settings_json, created_at FROM ethernova_parties")) {
                    ResultSet rs = ps.executeQuery();
                    while (rs.next()) {
                        UUID partyId = UUID.fromString(rs.getString("id"));
                        UUID leaderUuid = UUID.fromString(rs.getString("leader_uuid"));
                        String name = rs.getString("name");
                        String settingsJson = rs.getString("settings_json");
                        long createdAt = rs.getLong("created_at");

                        PartySettings settings = PartySettings.fromJson(settingsJson);
                        if (settings.getMaxSize() <= 0) settings.setMaxSize(defaultMaxSize);

                        Party party = new Party(partyId, leaderUuid, name, settings, createdAt);
                        result.put(partyId, party);
                    }
                }

                // Load members
                try (PreparedStatement ps = conn.prepareStatement(
                        "SELECT party_id, uuid, role FROM ethernova_party_members")) {
                    ResultSet rs = ps.executeQuery();
                    while (rs.next()) {
                        UUID partyId = UUID.fromString(rs.getString("party_id"));
                        UUID memberUuid = UUID.fromString(rs.getString("uuid"));
                        String roleName = rs.getString("role");

                        Party party = result.get(partyId);
                        if (party != null) {
                            PartyRole role;
                            try {
                                role = PartyRole.valueOf(roleName);
                            } catch (IllegalArgumentException e) {
                                role = PartyRole.MEMBER;
                            }
                            party.addMemberDirect(memberUuid, role);
                        }
                    }
                }

                plugin.getLogger().info("Loaded " + result.size() + " parties from database.");
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to load parties", e);
            }
            return result;
        }, core.getDbExecutor()).exceptionally(ex -> {
            plugin.getLogger().log(Level.SEVERE, "Unhandled error loading parties", ex);
            return new HashMap<>();
        });
    }

    /**
     * Save all active parties in batch.
     */
    public CompletableFuture<Void> saveAll(Collection<Party> parties) {
        return CompletableFuture.runAsync(() -> {
            try (Connection conn = core.getStorageManager().getConnection()) {
                conn.setAutoCommit(false);
                try {
                    boolean isMySQL = core.getStorageManager().isMySQL();
                    String partySql = isMySQL
                        ? """
                            INSERT INTO ethernova_parties (id, leader_uuid, name, settings_json, created_at, updated_at)
                            VALUES (?, ?, ?, ?, ?, ?)
                            ON DUPLICATE KEY UPDATE leader_uuid = VALUES(leader_uuid), name = VALUES(name),
                            settings_json = VALUES(settings_json), updated_at = VALUES(updated_at)
                          """
                        : "INSERT OR REPLACE INTO ethernova_parties (id, leader_uuid, name, settings_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)";

                    try (PreparedStatement ps = conn.prepareStatement(partySql)) {
                        for (Party party : parties) {
                            ps.setString(1, party.getPartyId().toString());
                            ps.setString(2, party.getLeaderUuid().toString());
                            ps.setString(3, party.getName());
                            ps.setString(4, party.getSettings().toJson());
                            ps.setLong(5, party.getCreated());
                            ps.setLong(6, System.currentTimeMillis());
                            ps.addBatch();
                        }
                        ps.executeBatch();
                    }

                    // Rebuild members for all parties
                    Set<String> partyIds = new HashSet<>();
                    for (Party party : parties) {
                        partyIds.add(party.getPartyId().toString());
                    }

                    // Delete old members for these parties
                    if (!partyIds.isEmpty()) {
                        StringBuilder deleteSql = new StringBuilder("DELETE FROM ethernova_party_members WHERE party_id IN (");
                        for (int i = 0; i < partyIds.size(); i++) {
                            if (i > 0) deleteSql.append(",");
                            deleteSql.append("?");
                        }
                        deleteSql.append(")");

                        try (PreparedStatement ps = conn.prepareStatement(deleteSql.toString())) {
                            int idx = 1;
                            for (String id : partyIds) {
                                ps.setString(idx++, id);
                            }
                            ps.executeUpdate();
                        }
                    }

                    // Insert all members
                    try (PreparedStatement ps = conn.prepareStatement(
                            "INSERT INTO ethernova_party_members (party_id, uuid, role, joined_at) VALUES (?, ?, ?, ?)")) {
                        long now = System.currentTimeMillis();
                        for (Party party : parties) {
                            for (UUID memberUuid : party.getMembers()) {
                                ps.setString(1, party.getPartyId().toString());
                                ps.setString(2, memberUuid.toString());
                                var role = party.getRole(memberUuid);
                                ps.setString(3, role != null ? role.name() : "MEMBER");
                                ps.setLong(4, now);
                                ps.addBatch();
                            }
                        }
                        ps.executeBatch();
                    }

                    conn.commit();
                } catch (SQLException e) {
                    conn.rollback();
                    throw e;
                } finally {
                    conn.setAutoCommit(true);
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Failed to batch save parties", e);
            }
        }, core.getDbExecutor()).exceptionally(ex -> {
            plugin.getLogger().log(Level.SEVERE, "Unhandled error batch saving parties", ex);
            return null;
        });
    }

    /**
     * Purge empty/stale parties older than a certain age (in hours).
     */
    public CompletableFuture<Integer> purgeStaleParties(int maxAgeHours) {
        return CompletableFuture.supplyAsync(() -> {
            long cutoff = System.currentTimeMillis() - (maxAgeHours * 3600_000L);
            int deleted = 0;
            try (Connection conn = core.getStorageManager().getConnection()) {
                // Find parties with no online members and older than cutoff
                try (PreparedStatement ps = conn.prepareStatement(
                        "SELECT id FROM ethernova_parties WHERE updated_at < ? AND id NOT IN " +
                        "(SELECT DISTINCT party_id FROM ethernova_party_members)")) {
                    ps.setLong(1, cutoff);
                    ResultSet rs = ps.executeQuery();
                    List<String> ids = new ArrayList<>();
                    while (rs.next()) {
                        ids.add(rs.getString("id"));
                    }
                    for (String id : ids) {
                        try (PreparedStatement delPs = conn.prepareStatement(
                                "DELETE FROM ethernova_parties WHERE id = ?")) {
                            delPs.setString(1, id);
                            delPs.executeUpdate();
                            deleted++;
                        }
                    }
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Failed to purge stale parties", e);
            }
            return deleted;
        }, core.getDbExecutor()).exceptionally(ex -> {
            plugin.getLogger().log(Level.SEVERE, "Unhandled error purging stale parties", ex);
            return 0;
        });
    }
}
