package com.ethernova.party.event;

import java.util.Set;
import java.util.UUID;

/**
 * Published to EventBus when a party ready check completes.
 */
public record PartyReadyCheckEvent(UUID partyId, boolean allReady, Set<UUID> readyPlayers, Set<UUID> notReadyPlayers) {}
