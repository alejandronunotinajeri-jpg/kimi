package com.ethernova.party;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.service.ServiceRegistry;
import com.ethernova.party.api.PartyAPI;
import com.ethernova.party.api.PartyAPIImpl;
import com.ethernova.party.command.PartyCommand;
import com.ethernova.party.games.PartyGamesManager;
import com.ethernova.party.listener.PartyListener;
import com.ethernova.party.manager.PartyBuffManager;
import com.ethernova.party.manager.PartyManager;
import com.ethernova.party.manager.PartyReadyCheckManager;
import com.ethernova.party.model.PartyChat;
import com.ethernova.party.storage.PartyStorageManager;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.logging.Level;

/**
 * Main plugin class for EthernovaParty.
 * Provides a comprehensive party/group system integrated with the Ethernova ecosystem.
 *
 * Features:
 * - Party creation, invite/accept/decline, kick, promote, disband
 * - Role system: Leader, Moderator, Member
 * - Configurable party settings (friendly fire, public/private, max size)
 * - Party chat with toggle and quick prefix
 * - Party teleport (leader/mod tp all members)
 * - Public party browsing and joining
 * - GUI management interface with settings panel
 * - Database persistence (survives server restarts)
 * - Party buffs (XP bonus, speed, regen based on party size)
 * - Ready check system
 * - Cross-plugin events via EventBus
 * - Auto-save with dirty tracking
 */
public class EthernovaParty extends JavaPlugin {

    private static volatile EthernovaParty instance;

    private EthernovaCore core;
    private PartyManager partyManager;
    private PartyChat partyChat;
    private PartyStorageManager storageManager;
    private PartyBuffManager buffManager;
    private PartyReadyCheckManager readyCheckManager;
    private PartyGamesManager partyGamesManager;

    @Override
    public void onEnable() {
        instance = this;
        long start = System.currentTimeMillis();

        getLogger().info("═══════════════════════════════════════════");
        getLogger().info("  EthernovaParty v" + getDescription().getVersion());
        getLogger().info("═══════════════════════════════════════════");

        try {
            // Phase 1: Core dependency
            core = (EthernovaCore) Bukkit.getPluginManager().getPlugin("EthernovaCore");
            if (core == null) {
                getLogger().severe("EthernovaCore no encontrado! Deshabilitando...");
                Bukkit.getPluginManager().disablePlugin(this);
                return;
            }
            core.registerPlugin("EthernovaParty");

            // Phase 2: Configuration
            saveDefaultConfig();
            reloadConfig();

            // Phase 3: Database storage
            storageManager = new PartyStorageManager(this, core);
            storageManager.createTables();

            // Phase 4: Party Chat system
            partyChat = new PartyChat(this);

            // Phase 5: Party Manager (central business logic) — loads from DB
            partyManager = new PartyManager(this, core);
            partyManager.loadFromDatabase();

            // Phase 6: Buff Manager
            buffManager = new PartyBuffManager(this, core);
            buffManager.start();

            // Phase 7: Ready Check Manager
            readyCheckManager = new PartyReadyCheckManager(this, core);

            // Phase 7.5: Party Games Manager
            partyGamesManager = new PartyGamesManager(this, core);

            // Phase 8: Listeners
            Bukkit.getPluginManager().registerEvents(new PartyListener(this), this);

            // Phase 9: Commands
            registerCommands();

            // Phase 10: Register sounds with core
            registerSounds();

            // Phase 11: Auto-save task
            startAutoSave();

            // Phase 12: Public API
            ServiceRegistry.register(PartyAPI.class, new PartyAPIImpl(this));
            getLogger().info("✔ PartyAPI registrada en ServiceRegistry");

            long elapsed = System.currentTimeMillis() - start;
            getLogger().info("═══════════════════════════════════════════");
            getLogger().info("  EthernovaParty habilitado en " + elapsed + "ms");
            getLogger().info("═══════════════════════════════════════════");

        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Error habilitando EthernovaParty", e);
            Bukkit.getPluginManager().disablePlugin(this);
        }
    }

    @Override
    public void onDisable() {
        // Cancel all scheduler tasks
        Bukkit.getScheduler().cancelTasks(this);

        // Stop buff manager
        if (buffManager != null) buffManager.stop();

        // Cleanup ready checks
        if (readyCheckManager != null) readyCheckManager.cleanup();

        // Cleanup party games
        if (partyGamesManager != null) partyGamesManager.cleanup();

        // Save all parties to DB before shutdown
        if (partyManager != null && storageManager != null) {
            try {
                getLogger().info("Saving parties to database...");
                storageManager.saveAll(partyManager.getAllParties()).join(); // Block until saved
                getLogger().info("Parties saved successfully.");
            } catch (Exception e) {
                getLogger().log(Level.WARNING, "Error saving parties on disable", e);
            }
        }

        // Cleanup party manager (cancel invite timers, remove contexts)
        if (partyManager != null) partyManager.cleanup();

        // Clear party chat toggles
        if (partyChat != null) partyChat.clearAll();

        // Unregister API
        ServiceRegistry.unregister(PartyAPI.class);

        // Unregister from core
        if (core != null) core.unregisterPlugin("EthernovaParty");

        instance = null;
    }

    /**
     * Register all plugin commands.
     */
    private void registerCommands() {
        PartyCommand cmd = new PartyCommand(this);
        var partyCmd = getCommand("party");
        if (partyCmd != null) {
            partyCmd.setExecutor(cmd);
            partyCmd.setTabCompleter(cmd);
        } else {
            getLogger().warning("Comando 'party' no encontrado en plugin.yml!");
        }

        // Party games command
        var pgCmd = new com.ethernova.party.command.PartyGamesCommand(this);
        var pgCommand = getCommand("partygame");
        if (pgCommand != null) {
            pgCommand.setExecutor(pgCmd);
            pgCommand.setTabCompleter(pgCmd);
        }
    }

    /**
     * Register party-specific sounds with the core SoundManager.
     */
    private void registerSounds() {
        var soundManager = core.getSoundManager();
        var soundSection = getConfig().getConfigurationSection("sounds");

        // Register defaults
        soundManager.register("party-create", org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.5f);
        soundManager.register("party-join", org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1.2f);
        soundManager.register("party-leave", org.bukkit.Sound.ENTITY_VILLAGER_NO, 0.5f, 1f);
        soundManager.register("party-disband", org.bukkit.Sound.ENTITY_WITHER_HURT, 0.5f, 0.8f);
        soundManager.register("party-invite", org.bukkit.Sound.BLOCK_NOTE_BLOCK_BELL, 0.5f, 1.5f);
        soundManager.register("party-kick", org.bukkit.Sound.ENTITY_IRON_GOLEM_HURT, 0.4f, 1f);
        soundManager.register("party-promote", org.bukkit.Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.7f, 1f);
        soundManager.register("party-teleport", org.bukkit.Sound.ENTITY_ENDERMAN_TELEPORT, 0.6f, 1f);
        soundManager.register("party-chat-toggle", org.bukkit.Sound.BLOCK_NOTE_BLOCK_PLING, 0.5f, 1.2f);
        soundManager.register("party-ready", org.bukkit.Sound.BLOCK_NOTE_BLOCK_CHIME, 0.7f, 1.5f);
        soundManager.register("party-buff-activate", org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 0.4f, 1.8f);

        // Apply config overrides if present
        if (soundSection != null) {
            soundManager.loadFromConfig(soundSection);
        }
    }

    /**
     * Start periodic auto-save task that saves dirty parties to DB.
     */
    private void startAutoSave() {
        int intervalSeconds = getConfig().getInt("storage.auto-save-interval", 300); // 5 minutes default
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            var dirtyParties = partyManager.getAllParties().stream()
                    .filter(p -> p.isDirty())
                    .toList();
            if (!dirtyParties.isEmpty()) {
                storageManager.saveAll(dirtyParties).thenRun(() -> {
                    dirtyParties.forEach(p -> p.clearDirty());
                    getLogger().fine("Auto-saved " + dirtyParties.size() + " parties.");
                });
            }
        }, intervalSeconds * 20L, intervalSeconds * 20L);
    }

    // ═══════════════ Getters ═══════════════

    public static EthernovaParty getInstance() { return instance; }
    public EthernovaCore getCore() { return core; }
    public PartyManager getPartyManager() { return partyManager; }
    public PartyChat getPartyChat() { return partyChat; }
    public PartyStorageManager getStorageManager() { return storageManager; }
    public PartyBuffManager getBuffManager() { return buffManager; }
    public PartyReadyCheckManager getReadyCheckManager() { return readyCheckManager; }
    public PartyGamesManager getPartyGamesManager() { return partyGamesManager; }
}
