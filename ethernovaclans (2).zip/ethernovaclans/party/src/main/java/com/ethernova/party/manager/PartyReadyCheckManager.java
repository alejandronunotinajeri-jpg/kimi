package com.ethernova.party.manager;

import com.ethernova.core.EthernovaCore;
import com.ethernova.party.EthernovaParty;
import com.ethernova.party.event.PartyReadyCheckEvent;
import com.ethernova.party.model.Party;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages party-wide ready checks.
 *
 * Flow:
 *   1. Leader initiates ready check → all members get a clickable message
 *   2. Members click "Ready" or it times out
 *   3. When all respond or timeout, result is published to EventBus
 *
 * Used before: party duels, party FFA, party teleport to dangerous zones.
 */
public class PartyReadyCheckManager {

    private static final MiniMessage MINI = MiniMessage.miniMessage();

    private final EthernovaParty plugin;
    private final EthernovaCore core;

    /** Active ready checks by partyId */
    private final Map<UUID, ReadyCheck> activeChecks = new ConcurrentHashMap<>();

    public record ReadyCheck(
        UUID partyId,
        UUID initiatorUuid,
        Set<UUID> pendingPlayers,
        Set<UUID> readyPlayers,
        Set<UUID> declinedPlayers,
        BukkitTask timeoutTask,
        long startTime,
        String reason
    ) {}

    public PartyReadyCheckManager(EthernovaParty plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
    }

    /**
     * Initiate a ready check for a party.
     * @param initiator The player who started the check (must be leader/mod)
     * @param reason Display reason (e.g., "Duelo de grupo", "FFA de grupo")
     * @return true if check was started
     */
    public boolean startReadyCheck(Player initiator, String reason) {
        Party party = plugin.getPartyManager().getParty(initiator.getUniqueId());
        if (party == null) return false;

        UUID partyId = party.getPartyId();

        // Can't have two active checks
        if (activeChecks.containsKey(partyId)) {
            sendPrefixed(initiator, "<red>Ya hay un ready check activo. Espera a que termine.");
            return false;
        }

        // Need at least 2 members
        if (party.getSize() < 2) {
            sendPrefixed(initiator, "<red>Necesitas al menos 2 miembros para un ready check.");
            return false;
        }

        Set<UUID> pending = ConcurrentHashMap.newKeySet();
        Set<UUID> ready = ConcurrentHashMap.newKeySet();
        Set<UUID> declined = ConcurrentHashMap.newKeySet();

        // The initiator is automatically ready
        ready.add(initiator.getUniqueId());

        // Everyone else needs to confirm
        for (UUID memberUuid : party.getMembers()) {
            if (!memberUuid.equals(initiator.getUniqueId())) {
                Player member = Bukkit.getPlayer(memberUuid);
                if (member != null && member.isOnline()) {
                    pending.add(memberUuid);
                } else {
                    // Offline members are automatically declined
                    declined.add(memberUuid);
                }
            }
        }

        if (pending.isEmpty()) {
            sendPrefixed(initiator, "<red>No hay miembros en línea para confirmar.");
            return false;
        }

        // Schedule timeout
        int timeoutSeconds = plugin.getConfig().getInt("ready-check.timeout", 30);
        BukkitTask timeoutTask = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            completeReadyCheck(partyId, false);
        }, timeoutSeconds * 20L);

        ReadyCheck check = new ReadyCheck(partyId, initiator.getUniqueId(), pending, ready, declined, timeoutTask, System.currentTimeMillis(), reason);
        activeChecks.put(partyId, check);

        // Notify pending members
        String prefix = getPrefix();
        String reasonDisplay = reason != null ? reason : "Ready Check";

        for (UUID pendingUuid : pending) {
            Player member = Bukkit.getPlayer(pendingUuid);
            if (member != null) {
                member.sendMessage(MINI.deserialize(prefix + "<yellow>⚡ " + initiator.getName() + " ha iniciado un ready check: <white>" + reasonDisplay));
                Component readyButton = MINI.deserialize(prefix + "<green><bold>[✔ LISTO]</bold></green> ")
                        .clickEvent(ClickEvent.runCommand("/party ready accept"));
                Component declineButton = MINI.deserialize("<red><bold>[✘ NO]</bold></red>")
                        .clickEvent(ClickEvent.runCommand("/party ready decline"));
                member.sendMessage(readyButton.append(Component.text(" ")).append(declineButton));
                core.getSoundManager().play(member, "party-invite");
            }
        }

        // Notify initiator
        sendPrefixed(initiator, "<green>Ready check iniciado. Esperando respuestas... (" + timeoutSeconds + "s)");
        return true;
    }

    /**
     * Player responds "ready" to an active check.
     */
    public boolean acceptReady(Player player) {
        UUID uuid = player.getUniqueId();
        Party party = plugin.getPartyManager().getParty(uuid);
        if (party == null) return false;

        ReadyCheck check = activeChecks.get(party.getPartyId());
        if (check == null) {
            sendPrefixed(player, "<red>No hay un ready check activo.");
            return false;
        }

        if (!check.pendingPlayers().remove(uuid)) {
            sendPrefixed(player, "<red>Ya respondiste o no estás en este ready check.");
            return false;
        }

        check.readyPlayers().add(uuid);
        broadcastToParty(party, "<green>✔ " + player.getName() + " está listo! (" + check.readyPlayers().size() + "/" + (check.readyPlayers().size() + check.pendingPlayers().size() + check.declinedPlayers().size()) + ")");
        core.getSoundManager().play(player, "success");

        // Check if all responded
        if (check.pendingPlayers().isEmpty()) {
            completeReadyCheck(party.getPartyId(), true);
        }

        return true;
    }

    /**
     * Player responds "not ready" to an active check.
     */
    public boolean declineReady(Player player) {
        UUID uuid = player.getUniqueId();
        Party party = plugin.getPartyManager().getParty(uuid);
        if (party == null) return false;

        ReadyCheck check = activeChecks.get(party.getPartyId());
        if (check == null) {
            sendPrefixed(player, "<red>No hay un ready check activo.");
            return false;
        }

        if (!check.pendingPlayers().remove(uuid)) {
            sendPrefixed(player, "<red>Ya respondiste o no estás en este ready check.");
            return false;
        }

        check.declinedPlayers().add(uuid);
        broadcastToParty(party, "<red>✘ " + player.getName() + " no está listo.");
        core.getSoundManager().play(player, "error");

        // Check if all responded
        if (check.pendingPlayers().isEmpty()) {
            completeReadyCheck(party.getPartyId(), true);
        }

        return true;
    }

    /**
     * Complete a ready check (all responded or timeout).
     */
    private void completeReadyCheck(UUID partyId, boolean natural) {
        ReadyCheck check = activeChecks.remove(partyId);
        if (check == null) return;

        check.timeoutTask().cancel();

        // Move remaining pending to declined
        check.declinedPlayers().addAll(check.pendingPlayers());
        check.pendingPlayers().clear();

        boolean allReady = check.declinedPlayers().isEmpty();
        Party party = plugin.getPartyManager().getPartyById(partyId);

        if (party != null) {
            if (allReady) {
                broadcastToParty(party, "<green>⚡ ¡Todos listos! Ready check completado.");
            } else {
                int readyCount = check.readyPlayers().size();
                int totalCount = readyCount + check.declinedPlayers().size();
                broadcastToParty(party, "<red>⚡ Ready check " + (natural ? "completado" : "expirado") +
                        ". Listos: " + readyCount + "/" + totalCount);
            }
        }

        // Publish event
        core.getEventBus().publish(new PartyReadyCheckEvent(
                partyId, allReady,
                Set.copyOf(check.readyPlayers()),
                Set.copyOf(check.declinedPlayers())
        ));
    }

    /**
     * Check if a party has an active ready check.
     */
    public boolean hasActiveCheck(UUID partyId) {
        return activeChecks.containsKey(partyId);
    }

    /**
     * Cancel a ready check (e.g., when party disbands).
     */
    public void cancelCheck(UUID partyId) {
        ReadyCheck check = activeChecks.remove(partyId);
        if (check != null) {
            check.timeoutTask().cancel();
        }
    }

    /**
     * Clean up all active checks.
     */
    public void cleanup() {
        for (ReadyCheck check : activeChecks.values()) {
            check.timeoutTask().cancel();
        }
        activeChecks.clear();
    }

    // ═══════════════ Utility ═══════════════

    private void broadcastToParty(Party party, String message) {
        Component component = MINI.deserialize(getPrefix() + message);
        for (UUID memberUuid : party.getMembers()) {
            Player member = Bukkit.getPlayer(memberUuid);
            if (member != null && member.isOnline()) {
                member.sendMessage(component);
            }
        }
    }

    private void sendPrefixed(Player player, String message) {
        player.sendMessage(MINI.deserialize(getPrefix() + message));
    }

    private String getPrefix() {
        return plugin.getConfig().getString("messages.prefix",
                "<gradient:#00d4ff:#00ff88>⚔ Party</gradient> <dark_gray>»</dark_gray> ");
    }
}
