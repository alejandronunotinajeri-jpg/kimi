package com.ethernova.party.event;

import java.util.UUID;

/**
 * Published to EventBus when a player joins a party.
 */
public record PartyJoinEvent(UUID partyId, UUID playerUuid) {}
