package com.ethernova.party.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.PaginatedGui;
import com.ethernova.party.EthernovaParty;
import com.ethernova.party.model.Party;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Shows all public (non-full) parties in a paginated GUI.
 * Players can click a party to join it directly.
 * Extends PaginatedGui from core.
 */
public class PartyListGui extends PaginatedGui {

    private final EthernovaParty partyPlugin;

    public PartyListGui(EthernovaCore core, Player player, EthernovaParty partyPlugin) {
        super(core, player);
        this.partyPlugin = partyPlugin;
    }

    /**
     * Open the public party list.
     */
    public void open() {
        openPaginated(getTitle(), 0);
    }

    @Override
    protected String getTitle() {
        return "<gradient:#00d4ff:#00ff88>⚔ Grupos Públicos</gradient>";
    }

    @Override
    protected List<PageItem> getPageItems() {
        List<PageItem> items = new ArrayList<>();
        List<Party> publicParties = partyPlugin.getPartyManager().getPublicParties();

        if (publicParties.isEmpty()) {
            items.add(new PageItem(
                    createItem(Material.BARRIER,
                            "<gray>No hay grupos públicos disponibles.",
                            List.of("", "<yellow>Crea uno con <white>/party create</white>", "")),
                    "NONE"
            ));
            return items;
        }

        for (Party party : publicParties) {
            String leaderName = getPlayerName(party.getLeaderUuid());
            int onlineCount = countOnlineMembers(party);

            // Create leader head as item
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            if (meta != null) {
                meta.setOwningPlayer(Bukkit.getOfflinePlayer(party.getLeaderUuid()));
                meta.displayName(mini.deserialize("<green>⚔ Grupo de " + leaderName));

                List<String> loreLines = new ArrayList<>();
                loreLines.add("");
                loreLines.add("<gray>Líder: <white>" + leaderName + "</white>");
                loreLines.add("<gray>Miembros: <white>" + party.getSize() + "/" + party.getMaxSize() + "</white>");
                loreLines.add("<gray>En línea: <green>" + onlineCount + "</green>");
                loreLines.add("");

                // Show member names
                loreLines.add("<gray>Integrantes:");
                for (UUID memberUuid : party.getMembers()) {
                    String memberName = getPlayerName(memberUuid);
                    Player memberPlayer = Bukkit.getPlayer(memberUuid);
                    boolean online = memberPlayer != null && memberPlayer.isOnline();
                    String leaderTag = party.isLeader(memberUuid) ? " <gold>★" : "";
                    String status = online ? "<green>●" : "<red>●";
                    loreLines.add("  <dark_gray>▪</dark_gray> " + status + " <white>" + memberName + "</white>" + leaderTag);
                }

                loreLines.add("");
                if (party.isFull()) {
                    loreLines.add("<red>✘ Grupo lleno");
                } else if (partyPlugin.getPartyManager().isInParty(player.getUniqueId())) {
                    loreLines.add("<red>Ya estás en un grupo");
                } else {
                    loreLines.add("<yellow>▶ Click para unirte");
                }

                meta.lore(loreLines.stream()
                        .map(l -> mini.deserialize(l))
                        .toList());
                head.setItemMeta(meta);
            }

            items.add(new PageItem(head, "JOIN_" + party.getPartyId()));
        }

        return items;
    }

    @Override
    protected boolean onItemClick(String action, int slot, InventoryClickEvent event) {
        if ("NONE".equals(action)) return true;

        if (action.startsWith("JOIN_")) {
            String partyIdStr = action.substring(5);
            try {
                UUID partyId = UUID.fromString(partyIdStr);
                player.closeInventory();
                boolean joined = partyPlugin.getPartyManager().joinPublicParty(player, partyId);
                if (joined) {
                    core.getSoundManager().play(player, "party-join");
                }
            } catch (IllegalArgumentException ignored) {}
            return true;
        }

        return false;
    }

    @Override
    protected void onBack() {
        // If in a party, go to party GUI; otherwise, go to party menu selector
        Party myParty = partyPlugin.getPartyManager().getParty(player.getUniqueId());
        if (myParty != null) {
            new PartyGui(core, player, myParty, partyPlugin).open();
        } else {
            new PartyMenuGui(core, player, partyPlugin).open();
        }
    }

    // ═══════════════ Utility ═══════════════

    private int countOnlineMembers(Party party) {
        int count = 0;
        for (UUID memberUuid : party.getMembers()) {
            Player member = Bukkit.getPlayer(memberUuid);
            if (member != null && member.isOnline()) count++;
        }
        return count;
    }

    private String getPlayerName(UUID uuid) {
        Player p = Bukkit.getPlayer(uuid);
        if (p != null) return p.getName();
        var offlinePlayer = Bukkit.getOfflinePlayer(uuid);
        String name = offlinePlayer.getName();
        return name != null ? name : uuid.toString().substring(0, 8);
    }
}
