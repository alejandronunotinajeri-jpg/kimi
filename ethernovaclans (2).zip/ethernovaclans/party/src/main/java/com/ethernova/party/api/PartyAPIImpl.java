package com.ethernova.party.api;

import com.ethernova.party.EthernovaParty;
import com.ethernova.party.model.Party;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Implementation of PartyAPI. Registered with ServiceRegistry on enable.
 */
public class PartyAPIImpl implements PartyAPI {

    private final EthernovaParty plugin;

    public PartyAPIImpl(EthernovaParty plugin) {
        this.plugin = plugin;
    }

    // ═══════════════ Queries ═══════════════

    @Override
    public Party getParty(UUID playerUuid) {
        return plugin.getPartyManager().getParty(playerUuid);
    }

    @Override
    public Party getPartyById(UUID partyId) {
        return plugin.getPartyManager().getPartyById(partyId);
    }

    @Override
    public boolean isInParty(UUID playerUuid) {
        return plugin.getPartyManager().isInParty(playerUuid);
    }

    @Override
    public boolean areInSameParty(UUID player1, UUID player2) {
        return plugin.getPartyManager().areInSameParty(player1, player2);
    }

    @Override
    public Collection<Party> getAllParties() {
        return plugin.getPartyManager().getAllParties();
    }

    @Override
    public List<Party> getPublicParties() {
        return plugin.getPartyManager().getPublicParties();
    }

    @Override
    public boolean hasPendingInvite(UUID playerUuid) {
        return plugin.getPartyManager().hasPendingInvite(playerUuid);
    }

    // ═══════════════ Party Info ═══════════════

    @Override
    public int getPartySize(UUID playerUuid) {
        Party party = plugin.getPartyManager().getParty(playerUuid);
        return party != null ? party.getSize() : 0;
    }

    @Override
    public UUID getPartyLeader(UUID playerUuid) {
        Party party = plugin.getPartyManager().getParty(playerUuid);
        return party != null ? party.getLeaderUuid() : null;
    }

    @Override
    public Set<UUID> getPartyMembers(UUID playerUuid) {
        Party party = plugin.getPartyManager().getParty(playerUuid);
        return party != null ? party.getMembers() : Collections.emptySet();
    }

    // ═══════════════ Combat Integration ═══════════════

    @Override
    public boolean shouldCancelDamage(UUID attacker, UUID victim) {
        return plugin.getPartyManager().shouldCancelDamage(attacker, victim);
    }

    // ═══════════════ Buffs ═══════════════

    @Override
    public double getXPMultiplier(UUID uuid) {
        var bm = plugin.getBuffManager();
        return bm != null ? bm.getXPMultiplier(uuid) : 1.0;
    }

    @Override
    public boolean hasActiveBuff(UUID uuid) {
        var bm = plugin.getBuffManager();
        return bm != null && bm.hasActiveBuff(uuid);
    }

    // ═══════════════ Ready Checks ═══════════════

    @Override
    public boolean hasActiveReadyCheck(UUID partyId) {
        return plugin.getReadyCheckManager().hasActiveCheck(partyId);
    }
}
