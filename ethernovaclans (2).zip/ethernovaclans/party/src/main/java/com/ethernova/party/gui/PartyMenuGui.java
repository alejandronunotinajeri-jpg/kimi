package com.ethernova.party.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.CoreGui;
import com.ethernova.party.EthernovaParty;
import com.ethernova.party.model.Party;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.List;

/**
 * Pre-party selector GUI. Shown when a player without a party clicks the Party item.
 * Two options: Create Party or Browse Public Parties.
 */
public class PartyMenuGui extends CoreGui {

    private final EthernovaParty partyPlugin;

    public PartyMenuGui(EthernovaCore core, Player player, EthernovaParty partyPlugin) {
        super(core, player);
        this.partyPlugin = partyPlugin;
    }

    public void open() {
        openInventory("<gradient:#00d4ff:#00ff88>⚔ Party</gradient>", 27);
    }

    @Override
    protected void populateItems() {
        // Create Party button — slot 11
        setItem(11, createItem(Material.EMERALD_BLOCK,
                "<green><bold>Crear Party",
                List.of(
                        "",
                        "<gray>Crea tu propia party e invita",
                        "<gray>amigos para jugar juntos.",
                        "",
                        "<yellow>▶ Click para crear"
                )));
        slotActions.put(11, "CREATE_PARTY");

        // Browse Public Parties button — slot 15
        int publicCount = partyPlugin.getPartyManager().getPublicParties().size();
        setItem(15, createItem(Material.COMPASS,
                "<aqua><bold>Unirse a Party Pública",
                List.of(
                        "",
                        "<gray>Explora las parties públicas",
                        "<gray>disponibles y únete a una.",
                        "",
                        "<gray>Parties disponibles: <white>" + publicCount,
                        "",
                        "<yellow>▶ Click para explorar"
                )));
        slotActions.put(15, "BROWSE_PARTIES");

        // Close button — slot 22
        setItem(22, createItem(Material.BARRIER,
                "<red>Cerrar",
                List.of("<gray>Click para cerrar")));
        slotActions.put(22, "CLOSE");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        switch (action) {
            case "CREATE_PARTY" -> {
                player.closeInventory();
                Party created = partyPlugin.getPartyManager().createParty(player);
                if (created != null) {
                    // Open the full party management GUI
                    new PartyGui(core, player, created, partyPlugin).open();
                }
                return true;
            }
            case "BROWSE_PARTIES" -> {
                core.getSoundManager().play(player, "click");
                new PartyListGui(core, player, partyPlugin).open();
                return true;
            }
        }
        return false;
    }
}
