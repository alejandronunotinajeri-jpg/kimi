package com.ethernova.party.gui;

import com.ethernova.core.gui.CoreGui;
import com.ethernova.party.EthernovaParty;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/**
 * Admin GUI for EthernovaParty — full in-game configuration.
 * Permission: ethernova.party.admin
 */
public class PartyAdminGui extends CoreGui {

    private final EthernovaParty plugin;
    private int page = 0;
    private static final int MAX_PAGES = 2;

    public PartyAdminGui(EthernovaParty plugin, Player player) {
        super(plugin.getCore(), player);
        this.plugin = plugin;
    }

    public void open() {
        openInventory("<gradient:#7F7FD5:#86A8E7>⚙ Party Admin</gradient> <gray>(Pág. " + (page + 1) + "/" + MAX_PAGES + ")", 54);
    }

    @Override
    protected void populateItems() {
        // ── Back ──
        setItem(48, createItem(Material.ARROW, "<gray>← Volver"));
        slotActions.put(48, "BACK");

        if (page == 0) populatePage1();
        else populatePage2();

        // ═══ Navigation ═══
        if (page > 0) {
            setItem(45, createItem(Material.ARROW, "<yellow>← Página Anterior"));
            slotActions.put(45, "PREV_PAGE");
        }
        if (page < MAX_PAGES - 1) {
            setItem(53, createItem(Material.ARROW, "<yellow>Página Siguiente →"));
            slotActions.put(53, "NEXT_PAGE");
        }

        // Reload
        setItem(49, createItem(Material.COMMAND_BLOCK,
                "<green>⟳ Recargar Config",
                List.of("<gray>Recarga config.yml completo")));
        slotActions.put(49, "RELOAD");
    }

    private void populatePage1() {
        // ═══ Header ═══
        setItem(4, createItem(Material.CAKE,
                "<gold><bold>⚙ Configuración de Party",
                List.of("<gray>Página 1: Ajustes de grupo y buffs")));

        // ═══ Row 1: Party Settings ═══
        setItem(10, createItem(Material.PURPLE_STAINED_GLASS_PANE,
                "<light_purple>Ajustes de Grupo"));

        setItem(11, numberItem(Material.PLAYER_HEAD, "Max Miembros", "party.max-size", ""));
        slotActions.put(11, "INT:party.max-size:2:50");

        setItem(12, numberItem(Material.GOLDEN_HELMET, "Límite Máximo", "party.max-size-limit", ""));
        slotActions.put(12, "INT:party.max-size-limit:2:100");

        setItem(13, numberItem(Material.CLOCK, "Invite Timeout", "party.invite-timeout", "seg"));
        slotActions.put(13, "INT:party.invite-timeout:10:600");

        setItem(14, numberItem(Material.ENDER_PEARL, "TP Cooldown", "party.teleport-cooldown", "seg"));
        slotActions.put(14, "INT:party.teleport-cooldown:0:600");

        setItem(15, toggleItem("Allow Public", "party.allow-public"));
        slotActions.put(15, "TOGGLE:party.allow-public");

        setItem(16, numberItem(Material.HOPPER, "Offline Timeout", "party.offline-timeout", "seg"));
        slotActions.put(16, "INT:party.offline-timeout:0:9999");

        // ═══ Row 2: Buff Settings ═══
        setItem(19, createItem(Material.BREWING_STAND,
                "<aqua><bold>Buffs de Party"));

        setItem(20, toggleItem("Buffs Activos", "buffs.enabled"));
        slotActions.put(20, "TOGGLE:buffs.enabled");

        setItem(21, numberItem(Material.CLOCK, "Buff Update", "buffs.update-interval", "seg"));
        slotActions.put(21, "INT:buffs.update-interval:5:300");

        setItem(22, doubleItem(Material.EXPERIENCE_BOTTLE, "XP Bonus/Miembro", "buffs.xp-bonus-per-member", ""));
        slotActions.put(22, "DOUBLE:buffs.xp-bonus-per-member:0.01:1.0");

        setItem(23, doubleItem(Material.GOLDEN_APPLE, "XP Max Bonus", "buffs.xp-max-bonus", ""));
        slotActions.put(23, "DOUBLE:buffs.xp-max-bonus:0.05:5.0");

        setItem(24, numberItem(Material.SUGAR, "Speed Threshold", "buffs.speed-threshold", "miembros"));
        slotActions.put(24, "INT:buffs.speed-threshold:1:20");

        setItem(25, numberItem(Material.GOLDEN_CARROT, "Regen Threshold", "buffs.regen-threshold", "miembros"));
        slotActions.put(25, "INT:buffs.regen-threshold:1:20");

        // ═══ Row 3: Buff amplifiers ═══
        setItem(28, numberItem(Material.FEATHER, "Speed Amplifier", "buffs.speed-amplifier", ""));
        slotActions.put(28, "INT:buffs.speed-amplifier:0:5");

        setItem(29, numberItem(Material.GLISTERING_MELON_SLICE, "Regen Amplifier", "buffs.regen-amplifier", ""));
        slotActions.put(29, "INT:buffs.regen-amplifier:0:5");
    }

    private void populatePage2() {
        // ═══ Header ═══
        setItem(4, createItem(Material.CAKE,
                "<gold><bold>⚙ Configuración de Party",
                List.of("<gray>Página 2: Ready Check, Storage y Chat")));

        // ═══ Row 1: Ready Check ═══
        setItem(10, createItem(Material.GREEN_STAINED_GLASS_PANE,
                "<green><bold>Ready Check"));

        setItem(11, numberItem(Material.CLOCK, "Ready Timeout", "ready-check.timeout", "seg"));
        slotActions.put(11, "INT:ready-check.timeout:5:300");

        // ═══ Row 1 continued: Storage ═══
        setItem(13, createItem(Material.CHEST,
                "<yellow><bold>Almacenamiento"));

        setItem(14, numberItem(Material.HOPPER, "Auto-Save", "storage.auto-save-interval", "seg"));
        slotActions.put(14, "INT:storage.auto-save-interval:30:3600");

        setItem(15, numberItem(Material.TNT, "Purge Stale", "storage.purge-stale-days", "días"));
        slotActions.put(15, "INT:storage.purge-stale-days:0:365");

        // ═══ Row 2: Chat ═══
        setItem(19, createItem(Material.WRITABLE_BOOK,
                "<aqua><bold>Chat de Party"));

        setItem(20, createItem(Material.PAPER,
                "<gold>Quick Prefix: <white>" + plugin.getConfig().getString("chat.quick-prefix", "!"),
                List.of("<gray>Prefijo rápido para chat de party",
                        "<gray>Actual: <yellow>" + plugin.getConfig().getString("chat.quick-prefix", "!"),
                        "",
                        "<yellow>Click para cambiar (! / # / @)")));
        slotActions.put(20, "CYCLE_PREFIX");

        // ═══ Row 3: Info ═══
        setItem(28, createItem(Material.PAINTING,
                "<yellow><bold>General"));

        setItem(29, createItem(Material.BOOK,
                "<aqua>Estado del Plugin",
                List.of("<gray>Mensajes definidos en config.yml",
                        "<gray>bajo la sección <white>messages:")));
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.startsWith("TOGGLE:")) {
            String path = action.substring(7);
            plugin.getConfig().set(path, !plugin.getConfig().getBoolean(path, false));
            plugin.saveConfig();
            refresh();
            return true;
        }
        if (action.startsWith("INT:")) {
            String[] parts = action.substring(4).split(":");
            adjustInt(parts[0], event, Integer.parseInt(parts[1]), Integer.parseInt(parts[2]));
            return true;
        }
        if (action.startsWith("DOUBLE:")) {
            String[] parts = action.substring(7).split(":");
            adjustDouble(parts[0], event, Double.parseDouble(parts[1]), Double.parseDouble(parts[2]));
            return true;
        }
        return switch (action) {
            case "PREV_PAGE" -> { page = Math.max(0, page - 1); refresh(); yield true; }
            case "NEXT_PAGE" -> { page = Math.min(MAX_PAGES - 1, page + 1); refresh(); yield true; }
            case "CYCLE_PREFIX" -> {
                String[] prefixes = {"!", "#", "@", "~", "+"};
                String current = plugin.getConfig().getString("chat.quick-prefix", "!");
                int idx = 0;
                for (int i = 0; i < prefixes.length; i++) {
                    if (prefixes[i].equals(current)) { idx = i; break; }
                }
                plugin.getConfig().set("chat.quick-prefix", prefixes[(idx + 1) % prefixes.length]);
                plugin.saveConfig();
                refresh();
                yield true;
            }

            case "RELOAD" -> {
                plugin.reloadConfig();
                playSound("success");
                player.closeInventory();
                player.sendMessage(mini.deserialize("<green>✔ Configuración de Party recargada."));
                yield true;
            }
            case "BACK" -> {
                playSound("click");
                player.closeInventory();
                Bukkit.getScheduler().runTaskLater(core, () -> player.performCommand("ethernova admin"), 2L);
                yield true;
            }
            default -> false;
        };
    }

    // ═══════════════ Helpers ═══════════════

    private void adjustInt(String path, InventoryClickEvent event, int min, int max) {
        int current = plugin.getConfig().getInt(path, 0);
        int delta = event.isShiftClick() ? 10 : 1;
        if (event.isRightClick()) delta = -delta;
        plugin.getConfig().set(path, Math.max(min, Math.min(max, current + delta)));
        plugin.saveConfig();
        refresh();
    }

    private void adjustDouble(String path, InventoryClickEvent event, double min, double max) {
        double current = plugin.getConfig().getDouble(path, 0);
        double delta = event.isShiftClick() ? 1.0 : 0.1;
        if (event.isRightClick()) delta = -delta;
        double newVal = Math.round(Math.max(min, Math.min(max, current + delta)) * 100.0) / 100.0;
        plugin.getConfig().set(path, newVal);
        plugin.saveConfig();
        refresh();
    }

    private void refresh() {
        playSound("click");
        player.closeInventory();
        Bukkit.getScheduler().runTaskLater(core, this::open, 1L);
    }

    private ItemStack toggleItem(String name, String path) {
        boolean val = plugin.getConfig().getBoolean(path, false);
        return createItem(val ? Material.LIME_DYE : Material.GRAY_DYE,
                (val ? "<green>✔ " : "<red>✘ ") + name,
                List.of("<gray>Estado: " + (val ? "<green>Activado" : "<red>Desactivado"),
                        "",
                        "<yellow>Click para " + (val ? "desactivar" : "activar")));
    }

    private ItemStack numberItem(Material mat, String name, String path, String unit) {
        int val = plugin.getConfig().getInt(path, 0);
        String suffix = unit.isEmpty() ? "" : " " + unit;
        return createItem(mat, "<gold>" + name + ": <white>" + val + suffix,
                List.of("<gray>Click izq: <green>+1", "<gray>Click der: <red>-1",
                        "<gray>Shift+Click: <yellow>±10"));
    }

    private ItemStack doubleItem(Material mat, String name, String path, String unit) {
        double val = plugin.getConfig().getDouble(path, 0);
        String suffix = unit.isEmpty() ? "" : " " + unit;
        return createItem(mat, "<gold>" + name + ": <white>" + String.format("%.2f", val) + suffix,
                List.of("<gray>Click izq: <green>+0.1", "<gray>Click der: <red>-0.1",
                        "<gray>Shift+Click: <yellow>±1.0"));
    }
}
