package com.ethernova.party.model;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Represents a party (grupo) in Ethernova.
 * Thread-safe via ConcurrentHashMap-backed data structures.
 *
 * Enhanced features:
 *   - Role system (LEADER, MODERATOR, MEMBER)
 *   - Configurable settings via PartySettings
 *   - Dirty flag for DB persistence
 *   - Named parties
 *   - DB-ready constructor for loading from storage
 */
public class Party {

    private final UUID partyId;
    private volatile UUID leaderUuid;
    private volatile String name;
    private final Map<UUID, PartyRole> memberRoles;
    private final Set<UUID> invited;
    private final PartySettings settings;
    private final long created;
    private volatile boolean dirty = false;

    /**
     * Create a new party (fresh creation).
     */
    public Party(UUID leaderUuid, int maxSize) {
        this.partyId = UUID.randomUUID();
        this.leaderUuid = leaderUuid;
        this.memberRoles = new ConcurrentHashMap<>();
        this.memberRoles.put(leaderUuid, PartyRole.LEADER);
        this.invited = ConcurrentHashMap.newKeySet();
        this.settings = new PartySettings();
        this.settings.setMaxSize(maxSize);
        this.name = null;
        this.created = System.currentTimeMillis();
        this.dirty = true;
    }

    /**
     * DB-restoration constructor.
     */
    public Party(UUID partyId, UUID leaderUuid, String name, PartySettings settings, long created) {
        this.partyId = partyId;
        this.leaderUuid = leaderUuid;
        this.name = name;
        this.memberRoles = new ConcurrentHashMap<>();
        this.invited = ConcurrentHashMap.newKeySet();
        this.settings = settings != null ? settings : new PartySettings();
        this.created = created;
        this.dirty = false;
    }

    // ═══════════════ Query Methods ═══════════════

    public UUID getPartyId() { return partyId; }
    public UUID getLeaderUuid() { return leaderUuid; }
    public long getCreated() { return created; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; markDirty(); }
    public PartySettings getSettings() { return settings; }
    public boolean isDirty() { return dirty; }
    public void markDirty() { this.dirty = true; }
    public void clearDirty() { this.dirty = false; }

    public int getMaxSize() { return settings.getMaxSize(); }
    public void setMaxSize(int maxSize) { settings.setMaxSize(maxSize); markDirty(); }
    public boolean isPublic() { return settings.isPublic(); }
    public void setPublic(boolean isPublic) { settings.setPublic(isPublic); markDirty(); }

    public int getSize() { return memberRoles.size(); }
    public boolean isFull() { return memberRoles.size() >= settings.getMaxSize(); }
    public boolean isMember(UUID uuid) { return memberRoles.containsKey(uuid); }
    public boolean isLeader(UUID uuid) { return leaderUuid.equals(uuid); }
    public boolean isInvited(UUID uuid) { return invited.contains(uuid); }

    public Set<UUID> getMembers() { return Collections.unmodifiableSet(memberRoles.keySet()); }
    public Set<UUID> getInvited() { return Collections.unmodifiableSet(invited); }

    /**
     * Get the role of a member. Returns null if the UUID is not a member.
     */
    public PartyRole getRole(UUID uuid) {
        return memberRoles.get(uuid);
    }

    /**
     * Set the role of a member. Returns false if not a member.
     */
    public boolean setRole(UUID uuid, PartyRole role) {
        if (!isMember(uuid)) return false;
        memberRoles.put(uuid, role);
        markDirty();
        return true;
    }

    // ═══════════════ Mutation Methods ═══════════════

    /**
     * Invite a player to the party. Returns false if full or already invited/member.
     */
    public boolean invite(UUID uuid) {
        if (isFull() || isMember(uuid) || isInvited(uuid)) return false;
        invited.add(uuid);
        return true;
    }

    /**
     * Remove a pending invite.
     */
    public void removeInvite(UUID uuid) {
        invited.remove(uuid);
    }

    /**
     * Accept an invite — add the player as a member. Returns false if party is full
     * or the player was not invited (and party is not public).
     */
    public synchronized boolean accept(UUID uuid) {
        if (isFull()) return false;
        if (!isPublic() && !isInvited(uuid)) return false;
        invited.remove(uuid);
        memberRoles.put(uuid, PartyRole.MEMBER);
        markDirty();
        return true;
    }

    /**
     * Kick a member (not the leader). Returns false if not a member or is the leader.
     */
    public boolean kick(UUID uuid) {
        if (!isMember(uuid) || isLeader(uuid)) return false;
        memberRoles.remove(uuid);
        markDirty();
        return true;
    }

    /**
     * Promote a member to leader. Returns false if not a member.
     * The previous leader becomes a MODERATOR.
     */
    public boolean promote(UUID uuid) {
        if (!isMember(uuid) || isLeader(uuid)) return false;
        memberRoles.put(this.leaderUuid, PartyRole.MODERATOR);
        this.leaderUuid = uuid;
        memberRoles.put(uuid, PartyRole.LEADER);
        markDirty();
        return true;
    }

    /**
     * Promote a member to moderator.
     */
    public boolean promoteToModerator(UUID uuid) {
        if (!isMember(uuid) || isLeader(uuid)) return false;
        if (getRole(uuid) == PartyRole.MODERATOR) return false;
        memberRoles.put(uuid, PartyRole.MODERATOR);
        markDirty();
        return true;
    }

    /**
     * Demote a moderator back to member.
     */
    public boolean demoteToMember(UUID uuid) {
        if (!isMember(uuid) || isLeader(uuid)) return false;
        if (getRole(uuid) != PartyRole.MODERATOR) return false;
        memberRoles.put(uuid, PartyRole.MEMBER);
        markDirty();
        return true;
    }

    /**
     * Remove a member from the party. Returns true if removed.
     */
    public boolean removeMember(UUID uuid) {
        boolean removed = memberRoles.remove(uuid) != null;
        if (removed) markDirty();
        return removed;
    }

    /**
     * Add a member directly with a specific role (used for DB restoration).
     */
    public void addMemberDirect(UUID uuid, PartyRole role) {
        memberRoles.put(uuid, role);
    }

    /**
     * Disband the party. Clears all members and invites.
     * Returns the set of members that were in the party before disbanding.
     */
    public Set<UUID> disband() {
        Set<UUID> previousMembers = Set.copyOf(memberRoles.keySet());
        memberRoles.clear();
        invited.clear();
        markDirty();
        return previousMembers;
    }

    /**
     * Check if the party is empty (no members).
     */
    public boolean isEmpty() {
        return memberRoles.isEmpty();
    }

    /**
     * Check if friendly fire is enabled.
     */
    public boolean isFriendlyFireEnabled() {
        return settings.isFriendlyFire();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Party other)) return false;
        return partyId.equals(other.partyId);
    }

    @Override
    public int hashCode() {
        return partyId.hashCode();
    }
}
