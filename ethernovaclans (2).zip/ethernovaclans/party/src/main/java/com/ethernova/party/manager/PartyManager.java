package com.ethernova.party.manager;

import com.ethernova.core.api.CombatAPI;
import com.ethernova.core.EthernovaCore;
import com.ethernova.core.service.ServiceRegistry;
import com.ethernova.party.EthernovaParty;
import com.ethernova.party.event.*;
import com.ethernova.party.model.Party;
import com.ethernova.party.model.PartyRole;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * Central party management. Handles all business logic for party operations
 * with thread-safe ConcurrentHashMap storage and database persistence.
 *
 * Enhanced features:
 * - Role-aware permission checks (Leader, Moderator, Member)
 * - EventBus integration for cross-plugin events
 * - DB persistence via PartyStorageManager
 * - Dirty tracking for efficient saves
 */
public class PartyManager {

    private static final MiniMessage MINI = MiniMessage.miniMessage();

    private final EthernovaParty plugin;
    private final EthernovaCore core;
    private final Logger logger;

    /** partyId -> Party */
    private final Map<UUID, Party> partiesById = new ConcurrentHashMap<>();
    /** playerUuid -> partyId (quick lookup) */
    private final Map<UUID, UUID> playerPartyMap = new ConcurrentHashMap<>();
    /** invitedPlayerUuid -> PartyInvite */
    private final Map<UUID, PartyInvite> pendingInvites = new ConcurrentHashMap<>();
    /** playerUuid -> last teleport timestamp */
    private final Map<UUID, Long> teleportCooldowns = new ConcurrentHashMap<>();

    /** Immutable invite record */
    public record PartyInvite(UUID partyId, UUID inviterUuid, UUID invitedUuid, long timestamp, BukkitTask expiryTask) {}

    public PartyManager(EthernovaParty plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
        this.logger = plugin.getLogger();
    }

    /**
     * Load saved parties from database on startup.
     */
    public void loadFromDatabase() {
        if (plugin.getStorageManager() == null) return;

        int defaultMaxSize = plugin.getConfig().getInt("party.max-size", 5);
        plugin.getStorageManager().loadAllParties(defaultMaxSize).thenAccept(loaded -> {
            // Merge loaded parties into memory on the main thread
            Bukkit.getScheduler().runTask(plugin, () -> {
                for (Map.Entry<UUID, Party> entry : loaded.entrySet()) {
                    Party party = entry.getValue();
                    if (party.isEmpty()) continue; // Skip empty parties

                    partiesById.put(entry.getKey(), party);
                    for (UUID memberUuid : party.getMembers()) {
                        playerPartyMap.put(memberUuid, entry.getKey());
                    }
                }
                logger.info("Restored " + loaded.size() + " parties from database.");
            });
        });
    }

    // ═══════════════════════════════════════════════════════
    //  Party Lifecycle
    // ═══════════════════════════════════════════════════════

    /**
     * Create a new party with the given player as leader.
     * @return the created Party, or null if the player is already in a party
     */
    public Party createParty(Player leader) {
        UUID uuid = leader.getUniqueId();
        if (playerPartyMap.containsKey(uuid)) return null;

        int maxSize = plugin.getConfig().getInt("party.max-size", 5);
        Party party = new Party(uuid, maxSize);
        partiesById.put(party.getPartyId(), party);
        playerPartyMap.put(uuid, party.getPartyId());

        // Add party context
        core.getContextManager().addContext(uuid, "party");

        sendPrefixed(leader, getMessage("party-created"));
        core.getSoundManager().play(leader, "party-create");

        // Publish event
        core.getEventBus().publish(new PartyCreateEvent(party.getPartyId(), uuid));

        // Refresh hotbar to show party item
        refreshLobbyItems(leader);

        // Save async
        savePartyAsync(party);

        return party;
    }

    /**
     * Disband a party. Only the leader can do this.
     * @return true if disbanded successfully
     */
    public boolean disbandParty(Player leader) {
        Party party = getParty(leader.getUniqueId());
        if (party == null) return false;
        if (!party.isLeader(leader.getUniqueId())) return false;

        UUID partyId = party.getPartyId();
        Set<UUID> members = party.disband();
        partiesById.remove(partyId);

        // Cancel ready checks
        if (plugin.getReadyCheckManager() != null) {
            plugin.getReadyCheckManager().cancelCheck(partyId);
        }

        // Clean up all members
        for (UUID memberUuid : members) {
            playerPartyMap.remove(memberUuid);
            core.getContextManager().removeContext(memberUuid, "party");
            plugin.getPartyChat().disable(memberUuid);

            // Remove buffs
            if (plugin.getBuffManager() != null) {
                plugin.getBuffManager().removeBuffEffects(memberUuid);
            }

            Player member = Bukkit.getPlayer(memberUuid);
            if (member != null && member.isOnline()) {
                // Refresh hotbar to remove party item
                refreshLobbyItems(member);
                if (!memberUuid.equals(leader.getUniqueId())) {
                    sendPrefixed(member, getMessage("party-disbanded"));
                    core.getSoundManager().play(member, "party-disband");
                }
            }
        }

        // Clear pending invites for this party
        clearPartyInvites(partyId);

        sendPrefixed(leader, getMessage("party-disbanded-leader"));
        core.getSoundManager().play(leader, "party-disband");

        // Publish event & delete from DB
        core.getEventBus().publish(new PartyDisbandEvent(partyId, leader.getUniqueId(), members));
        deletePartyAsync(partyId);

        return true;
    }

    // ═══════════════════════════════════════════════════════
    //  Invite System
    // ═══════════════════════════════════════════════════════

    /**
     * Invite a player to the party.
     * Requires LEADER or MODERATOR role (if moderator invites allowed).
     * @return true if invitation was sent
     */
    public boolean invitePlayer(Player inviter, Player target) {
        UUID inviterUuid = inviter.getUniqueId();
        UUID targetUuid = target.getUniqueId();

        // Validate
        if (inviterUuid.equals(targetUuid)) {
            sendPrefixed(inviter, getMessage("cannot-invite-self"));
            core.getSoundManager().play(inviter, "error");
            return false;
        }

        Party party = getParty(inviterUuid);
        if (party == null) {
            sendPrefixed(inviter, getMessage("not-in-party"));
            return false;
        }

        // Role check: Leader always can invite, Moderator only if allowed
        PartyRole inviterRole = party.getRole(inviterUuid);
        if (!inviterRole.canInvite()) {
            sendPrefixed(inviter, getMessage("not-leader"));
            core.getSoundManager().play(inviter, "error");
            return false;
        }
        if (inviterRole == PartyRole.MODERATOR && !party.getSettings().isAllowModeratorInvite()) {
            sendPrefixed(inviter, getMessage("not-leader"));
            core.getSoundManager().play(inviter, "error");
            return false;
        }

        if (party.isFull()) {
            sendPrefixed(inviter, getMessage("party-full")
                    .replace("{max}", String.valueOf(party.getMaxSize())));
            core.getSoundManager().play(inviter, "error");
            return false;
        }
        if (playerPartyMap.containsKey(targetUuid)) {
            sendPrefixed(inviter, getMessage("player-already-in-party"));
            core.getSoundManager().play(inviter, "error");
            return false;
        }
        if (pendingInvites.containsKey(targetUuid)) {
            sendPrefixed(inviter, getMessage("already-invited"));
            core.getSoundManager().play(inviter, "error");
            return false;
        }

        if (!party.invite(targetUuid)) {
            sendPrefixed(inviter, getMessage("already-invited"));
            return false;
        }

        // Schedule expiry
        int timeout = plugin.getConfig().getInt("party.invite-timeout", 60);
        BukkitTask expiryTask = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            expireInvite(targetUuid);
        }, timeout * 20L);

        PartyInvite invite = new PartyInvite(party.getPartyId(), inviterUuid, targetUuid, System.currentTimeMillis(), expiryTask);
        pendingInvites.put(targetUuid, invite);

        // Notify inviter
        sendPrefixed(inviter, getMessage("invite-sent").replace("{player}", target.getName()));
        core.getSoundManager().play(inviter, "success");

        // Notify target with clickable accept
        sendPrefixed(target, getMessage("invite-received").replace("{player}", inviter.getName()));
        Component acceptHint = MINI.deserialize(getPrefix() + getMessage("invite-accept-hint"))
                .clickEvent(ClickEvent.runCommand("/party accept"));
        target.sendMessage(acceptHint);
        core.getSoundManager().play(target, "party-invite");

        return true;
    }

    /**
     * Accept a pending invite.
     * @return true if successfully joined
     */
    public boolean acceptInvite(Player player) {
        UUID uuid = player.getUniqueId();

        if (playerPartyMap.containsKey(uuid)) {
            sendPrefixed(player, getMessage("already-in-party"));
            return false;
        }

        PartyInvite invite = pendingInvites.remove(uuid);
        if (invite == null) {
            sendPrefixed(player, getMessage("no-pending-invite"));
            core.getSoundManager().play(player, "error");
            return false;
        }

        // Cancel expiry task
        invite.expiryTask().cancel();

        Party party = partiesById.get(invite.partyId());
        if (party == null) {
            sendPrefixed(player, getMessage("invite-expired"));
            return false;
        }

        if (!party.accept(uuid)) {
            sendPrefixed(player, getMessage("party-full")
                    .replace("{max}", String.valueOf(party.getMaxSize())));
            return false;
        }

        playerPartyMap.put(uuid, party.getPartyId());
        core.getContextManager().addContext(uuid, "party");

        // Refresh hotbar to show party item
        refreshLobbyItems(player);

        // Notify all members
        broadcastToParty(party, getMessage("player-joined").replace("{player}", player.getName()));
        core.getSoundManager().play(player, "party-join");

        // Publish event & save
        core.getEventBus().publish(new PartyJoinEvent(party.getPartyId(), uuid));
        savePartyAsync(party);

        return true;
    }

    /**
     * Decline a pending invite.
     * @return true if there was an invite to decline
     */
    public boolean declineInvite(Player player) {
        UUID uuid = player.getUniqueId();
        PartyInvite invite = pendingInvites.remove(uuid);
        if (invite == null) {
            sendPrefixed(player, getMessage("no-pending-invite"));
            return false;
        }

        invite.expiryTask().cancel();

        Party party = partiesById.get(invite.partyId());
        if (party != null) {
            party.removeInvite(uuid);
        }

        sendPrefixed(player, getMessage("invite-declined")
                .replace("{player}", getPlayerName(invite.inviterUuid())));

        // Notify inviter
        Player inviter = Bukkit.getPlayer(invite.inviterUuid());
        if (inviter != null && inviter.isOnline()) {
            sendPrefixed(inviter, getMessage("invite-declined-notify")
                    .replace("{player}", player.getName()));
            core.getSoundManager().play(inviter, "error");
        }

        return true;
    }

    /**
     * Expire an invite after timeout.
     */
    private void expireInvite(UUID invitedUuid) {
        PartyInvite invite = pendingInvites.remove(invitedUuid);
        if (invite == null) return;

        Party party = partiesById.get(invite.partyId());
        if (party != null) {
            party.removeInvite(invitedUuid);
        }

        Player target = Bukkit.getPlayer(invitedUuid);
        if (target != null && target.isOnline()) {
            sendPrefixed(target, getMessage("invite-expired"));
        }

        Player inviter = Bukkit.getPlayer(invite.inviterUuid());
        if (inviter != null && inviter.isOnline()) {
            sendPrefixed(inviter, getMessage("invite-expired"));
        }
    }

    /**
     * Clear all pending invites for a specific party.
     */
    private void clearPartyInvites(UUID partyId) {
        pendingInvites.entrySet().removeIf(entry -> {
            if (entry.getValue().partyId().equals(partyId)) {
                entry.getValue().expiryTask().cancel();
                return true;
            }
            return false;
        });
    }

    // ═══════════════════════════════════════════════════════
    //  Member Management
    // ═══════════════════════════════════════════════════════

    /**
     * Kick a player from the party.
     * Requires LEADER or MODERATOR role (mod can't kick other mods).
     * @return true if kicked successfully
     */
    public boolean kickPlayer(Player kicker, UUID targetUuid) {
        Party party = getParty(kicker.getUniqueId());
        if (party == null) {
            sendPrefixed(kicker, getMessage("not-in-party"));
            return false;
        }

        PartyRole kickerRole = party.getRole(kicker.getUniqueId());
        if (!kickerRole.canKick()) {
            sendPrefixed(kicker, getMessage("not-leader"));
            core.getSoundManager().play(kicker, "error");
            return false;
        }

        if (kicker.getUniqueId().equals(targetUuid)) {
            sendPrefixed(kicker, getMessage("cannot-kick-self"));
            core.getSoundManager().play(kicker, "error");
            return false;
        }
        if (!party.isMember(targetUuid)) {
            sendPrefixed(kicker, getMessage("player-not-in-party"));
            core.getSoundManager().play(kicker, "error");
            return false;
        }

        // Moderators can't kick other moderators or the leader
        PartyRole targetRole = party.getRole(targetUuid);
        if (kickerRole == PartyRole.MODERATOR && !kickerRole.isHigherThan(targetRole)) {
            sendPrefixed(kicker, getMessage("not-leader"));
            core.getSoundManager().play(kicker, "error");
            return false;
        }

        party.kick(targetUuid);
        playerPartyMap.remove(targetUuid);
        core.getContextManager().removeContext(targetUuid, "party");
        plugin.getPartyChat().disable(targetUuid);

        // Remove buffs
        if (plugin.getBuffManager() != null) {
            plugin.getBuffManager().removeBuffEffects(targetUuid);
        }

        String targetName = getPlayerName(targetUuid);
        broadcastToParty(party, getMessage("player-kicked").replace("{player}", targetName));
        core.getSoundManager().play(kicker, "party-kick");

        Player target = Bukkit.getPlayer(targetUuid);
        if (target != null && target.isOnline()) {
            sendPrefixed(target, getMessage("player-kicked-notify"));
            core.getSoundManager().play(target, "party-kick");
            // Refresh hotbar to remove party item
            refreshLobbyItems(target);
        }

        // Publish event & save
        core.getEventBus().publish(new PartyLeaveEvent(party.getPartyId(), targetUuid, PartyLeaveEvent.LeaveReason.KICKED));
        savePartyAsync(party);

        return true;
    }

    /**
     * Promote a player to party leader.
     * @return true if promoted successfully
     */
    public boolean promoteLeader(Player leader, UUID targetUuid) {
        Party party = getParty(leader.getUniqueId());
        if (party == null) {
            sendPrefixed(leader, getMessage("not-in-party"));
            return false;
        }
        if (!party.isLeader(leader.getUniqueId())) {
            sendPrefixed(leader, getMessage("not-leader"));
            core.getSoundManager().play(leader, "error");
            return false;
        }
        if (!party.isMember(targetUuid)) {
            sendPrefixed(leader, getMessage("player-not-in-party"));
            core.getSoundManager().play(leader, "error");
            return false;
        }

        party.promote(targetUuid);
        String targetName = getPlayerName(targetUuid);
        broadcastToParty(party, getMessage("player-promoted").replace("{player}", targetName));

        Player target = Bukkit.getPlayer(targetUuid);
        if (target != null && target.isOnline()) {
            sendPrefixed(target, getMessage("player-promoted-notify"));
            core.getSoundManager().play(target, "party-promote");
        }
        core.getSoundManager().play(leader, "party-promote");

        savePartyAsync(party);
        return true;
    }

    /**
     * Set a member as moderator.
     */
    public boolean setModerator(Player leader, UUID targetUuid) {
        Party party = getParty(leader.getUniqueId());
        if (party == null || !party.isLeader(leader.getUniqueId())) return false;
        if (!party.isMember(targetUuid)) return false;

        boolean result = party.promoteToModerator(targetUuid);
        if (result) {
            String targetName = getPlayerName(targetUuid);
            broadcastToParty(party, "<yellow>" + targetName + " ahora es <white>Moderador</white> del grupo.");
            core.getSoundManager().play(leader, "party-promote");
            savePartyAsync(party);
        }
        return result;
    }

    /**
     * Demote a moderator back to member.
     */
    public boolean demoteMember(Player leader, UUID targetUuid) {
        Party party = getParty(leader.getUniqueId());
        if (party == null || !party.isLeader(leader.getUniqueId())) return false;
        if (!party.isMember(targetUuid)) return false;

        boolean result = party.demoteToMember(targetUuid);
        if (result) {
            String targetName = getPlayerName(targetUuid);
            broadcastToParty(party, "<yellow>" + targetName + " ha sido degradado a <white>Miembro</white>.");
            core.getSoundManager().play(leader, "party-kick");
            savePartyAsync(party);
        }
        return result;
    }

    /**
     * Player leaves their party voluntarily.
     * If the leader leaves, transfers leadership to another member.
     * If no members remain, disbands the party.
     * @return true if left successfully
     */
    public boolean leaveParty(Player player) {
        UUID uuid = player.getUniqueId();
        Party party = getParty(uuid);
        if (party == null) {
            sendPrefixed(player, getMessage("not-in-party"));
            return false;
        }

        boolean wasLeader = party.isLeader(uuid);
        party.removeMember(uuid);
        playerPartyMap.remove(uuid);
        core.getContextManager().removeContext(uuid, "party");
        plugin.getPartyChat().disable(uuid);

        // Remove buffs
        if (plugin.getBuffManager() != null) {
            plugin.getBuffManager().removeBuffEffects(uuid);
        }

        if (party.isEmpty()) {
            // No members left — disband
            partiesById.remove(party.getPartyId());
            clearPartyInvites(party.getPartyId());
            if (plugin.getReadyCheckManager() != null) {
                plugin.getReadyCheckManager().cancelCheck(party.getPartyId());
            }
            sendPrefixed(player, getMessage("player-left").replace("{player}", player.getName()));

            // Refresh hotbar to remove party item
            refreshLobbyItems(player);

            core.getEventBus().publish(new PartyLeaveEvent(party.getPartyId(), uuid, PartyLeaveEvent.LeaveReason.LEFT));
            core.getEventBus().publish(new PartyDisbandEvent(party.getPartyId(), uuid, Set.of(uuid)));
            deletePartyAsync(party.getPartyId());
            return true;
        }

        if (wasLeader) {
            // Transfer leadership to a random online member, or any member
            UUID newLeader = findBestLeaderCandidate(party);
            party.promote(newLeader);
            String newLeaderName = getPlayerName(newLeader);
            broadcastToParty(party, getMessage("leader-left-transferred").replace("{player}", newLeaderName));

            Player newLeaderPlayer = Bukkit.getPlayer(newLeader);
            if (newLeaderPlayer != null && newLeaderPlayer.isOnline()) {
                core.getSoundManager().play(newLeaderPlayer, "party-promote");
            }
        } else {
            broadcastToParty(party, getMessage("player-left").replace("{player}", player.getName()));
        }

        sendPrefixed(player, getMessage("player-left").replace("{player}", player.getName()));
        core.getSoundManager().play(player, "party-leave");

        // Refresh hotbar to remove party item
        refreshLobbyItems(player);

        core.getEventBus().publish(new PartyLeaveEvent(party.getPartyId(), uuid, PartyLeaveEvent.LeaveReason.LEFT));
        savePartyAsync(party);
        return true;
    }

    /**
     * Transfer leadership explicitly.
     * @return true if transferred successfully
     */
    public boolean transferLeader(Player leader, UUID targetUuid) {
        return promoteLeader(leader, targetUuid);
    }

    /**
     * Handle player disconnect. Auto-leave is NOT performed — player stays in party
     * for reconnect. But if the leader goes offline and there are online members,
     * we transfer leadership.
     */
    public void handlePlayerQuit(UUID uuid) {
        teleportCooldowns.remove(uuid);
        Party party = getParty(uuid);
        if (party == null) return;

        plugin.getPartyChat().disable(uuid);

        // Remove buffs while offline
        if (plugin.getBuffManager() != null) {
            plugin.getBuffManager().removeBuffEffects(uuid);
        }

        if (party.isLeader(uuid)) {
            // Check if there are online members to transfer to
            UUID onlineCandidate = null;
            for (UUID memberUuid : party.getMembers()) {
                if (!memberUuid.equals(uuid)) {
                    Player member = Bukkit.getPlayer(memberUuid);
                    if (member != null && member.isOnline()) {
                        onlineCandidate = memberUuid;
                        break;
                    }
                }
            }

            if (onlineCandidate != null) {
                party.promote(onlineCandidate);
                String newLeaderName = getPlayerName(onlineCandidate);
                broadcastToParty(party, getMessage("leader-left-transferred").replace("{player}", newLeaderName));

                Player newLeaderPlayer = Bukkit.getPlayer(onlineCandidate);
                if (newLeaderPlayer != null) {
                    core.getSoundManager().play(newLeaderPlayer, "party-promote");
                }
            }
        }

        // Schedule offline removal if configured
        int offlineTimeout = plugin.getConfig().getInt("party.offline-timeout", 0);
        if (offlineTimeout > 0) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                Player p = Bukkit.getPlayer(uuid);
                if (p == null || !p.isOnline()) {
                    Party currentParty = getParty(uuid);
                    if (currentParty != null) {
                        currentParty.removeMember(uuid);
                        playerPartyMap.remove(uuid);
                        if (currentParty.isEmpty()) {
                            partiesById.remove(currentParty.getPartyId());
                            deletePartyAsync(currentParty.getPartyId());
                        } else {
                            broadcastToParty(currentParty, getMessage("player-left-offline").replace("{player}", getPlayerName(uuid)));
                            savePartyAsync(currentParty);
                        }
                    }
                }
            }, offlineTimeout * 20L);
        }
    }

    /**
     * Handle player reconnect. Notify the player their party is still active.
     */
    public void handlePlayerJoin(Player player) {
        UUID uuid = player.getUniqueId();
        Party party = getParty(uuid);
        if (party == null) return;

        int onlineCount = 0;
        for (UUID memberUuid : party.getMembers()) {
            Player member = Bukkit.getPlayer(memberUuid);
            if (member != null && member.isOnline()) onlineCount++;
        }

        sendPrefixed(player, getMessage("rejoin-notification")
                .replace("{count}", String.valueOf(onlineCount)));
        core.getContextManager().addContext(uuid, "party");

        // Refresh hotbar to show party item on rejoin
        refreshLobbyItems(player);
    }

    // ═══════════════════════════════════════════════════════
    //  Party Teleport
    // ═══════════════════════════════════════════════════════

    /**
     * Teleport all party members to the initiator.
     * Requires LEADER or MODERATOR role.
     * @return true if teleport was initiated
     */
    public boolean teleportAll(Player initiator) {
        Party party = getParty(initiator.getUniqueId());
        if (party == null) {
            sendPrefixed(initiator, getMessage("not-in-party"));
            return false;
        }

        PartyRole role = party.getRole(initiator.getUniqueId());
        if (!role.canTeleport()) {
            sendPrefixed(initiator, getMessage("not-leader"));
            core.getSoundManager().play(initiator, "error");
            return false;
        }

        // Cooldown check
        int cooldown = plugin.getConfig().getInt("party.teleport-cooldown", 120);
        Long lastTp = teleportCooldowns.get(initiator.getUniqueId());
        if (lastTp != null) {
            long elapsed = (System.currentTimeMillis() - lastTp) / 1000;
            if (elapsed < cooldown) {
                sendPrefixed(initiator, getMessage("teleport-cooldown")
                        .replace("{time}", String.valueOf(cooldown - elapsed)));
                core.getSoundManager().play(initiator, "error");
                return false;
            }
        }

        teleportCooldowns.put(initiator.getUniqueId(), System.currentTimeMillis());

        // Combat tag check on initiator
        CombatAPI combatAPI = ServiceRegistry.get(CombatAPI.class);
        if (combatAPI != null && combatAPI.isInCombat(initiator)) {
            sendPrefixed(initiator, "<red>No puedes teletransportar mientras estás en combate.");
            core.getSoundManager().play(initiator, "error");
            return false;
        }

        sendPrefixed(initiator, getMessage("teleport-all"));

        for (UUID memberUuid : party.getMembers()) {
            if (memberUuid.equals(initiator.getUniqueId())) continue;
            Player member = Bukkit.getPlayer(memberUuid);
            if (member != null && member.isOnline()) {
                // Skip members in combat
                if (combatAPI != null && combatAPI.isInCombat(member)) {
                    sendPrefixed(member, "<red>No fuiste teletransportado porque estás en combate.");
                    sendPrefixed(initiator, "<yellow>" + member.getName() + " está en combate, no fue teletransportado.");
                    continue;
                }
                member.teleport(initiator.getLocation());
                sendPrefixed(member, getMessage("teleport-notify"));
                core.getSoundManager().play(member, "party-teleport");
            }
        }
        core.getSoundManager().play(initiator, "party-teleport");
        return true;
    }

    // ═══════════════════════════════════════════════════════
    //  Public Party
    // ═══════════════════════════════════════════════════════

    /**
     * Join a public party directly.
     * @return true if joined
     */
    public boolean joinPublicParty(Player player, UUID partyId) {
        UUID uuid = player.getUniqueId();
        if (playerPartyMap.containsKey(uuid)) {
            sendPrefixed(player, getMessage("already-in-party"));
            return false;
        }

        Party party = partiesById.get(partyId);
        if (party == null || !party.isPublic()) return false;
        if (party.isFull()) {
            sendPrefixed(player, getMessage("party-full")
                    .replace("{max}", String.valueOf(party.getMaxSize())));
            return false;
        }

        party.accept(uuid); // public parties allow accept without invite
        playerPartyMap.put(uuid, party.getPartyId());
        core.getContextManager().addContext(uuid, "party");

        // Refresh hotbar to show party item
        refreshLobbyItems(player);

        String leaderName = getPlayerName(party.getLeaderUuid());
        broadcastToParty(party, getMessage("player-joined").replace("{player}", player.getName()));
        sendPrefixed(player, getMessage("joined-public").replace("{player}", leaderName));
        core.getSoundManager().play(player, "party-join");

        core.getEventBus().publish(new PartyJoinEvent(party.getPartyId(), uuid));
        savePartyAsync(party);
        return true;
    }

    // ═══════════════════════════════════════════════════════
    //  Friendly Fire Check (for integration with Combat)
    // ═══════════════════════════════════════════════════════

    /**
     * Check if two players are in the same party and friendly fire is disabled.
     * Used by Combat plugin to prevent party members from damaging each other.
     * @return true if damage should be CANCELLED (friendly fire is OFF)
     */
    public boolean shouldCancelDamage(UUID attacker, UUID victim) {
        UUID attackerPartyId = playerPartyMap.get(attacker);
        UUID victimPartyId = playerPartyMap.get(victim);
        if (attackerPartyId == null || victimPartyId == null) return false;
        if (!attackerPartyId.equals(victimPartyId)) return false;

        Party party = partiesById.get(attackerPartyId);
        return party != null && !party.isFriendlyFireEnabled();
    }

    // ═══════════════════════════════════════════════════════
    //  Lookups
    // ═══════════════════════════════════════════════════════

    public Party getParty(UUID playerUuid) {
        UUID partyId = playerPartyMap.get(playerUuid);
        if (partyId == null) return null;
        return partiesById.get(partyId);
    }

    public Party getPartyById(UUID partyId) {
        return partiesById.get(partyId);
    }

    public Collection<Party> getAllParties() {
        return Collections.unmodifiableCollection(partiesById.values());
    }

    public List<Party> getPublicParties() {
        return partiesById.values().stream()
                .filter(Party::isPublic)
                .filter(p -> !p.isFull())
                .toList();
    }

    public boolean isInParty(UUID playerUuid) {
        return playerPartyMap.containsKey(playerUuid);
    }

    public boolean hasPendingInvite(UUID playerUuid) {
        return pendingInvites.containsKey(playerUuid);
    }

    /**
     * Check if two players are in the same party.
     */
    public boolean areInSameParty(UUID player1, UUID player2) {
        UUID party1 = playerPartyMap.get(player1);
        UUID party2 = playerPartyMap.get(player2);
        return party1 != null && party1.equals(party2);
    }

    // ═══════════════════════════════════════════════════════
    //  Cleanup
    // ═══════════════════════════════════════════════════════

    public void cleanup() {
        for (PartyInvite invite : pendingInvites.values()) {
            invite.expiryTask().cancel();
        }
        pendingInvites.clear();

        for (UUID playerUuid : playerPartyMap.keySet()) {
            core.getContextManager().removeContext(playerUuid, "party");
        }

        partiesById.clear();
        playerPartyMap.clear();
        teleportCooldowns.clear();
    }

    // ═══════════════════════════════════════════════════════
    //  Persistence Helpers
    // ═══════════════════════════════════════════════════════

    private void savePartyAsync(Party party) {
        if (plugin.getStorageManager() != null) {
            plugin.getStorageManager().saveParty(party).thenRun(() -> party.clearDirty());
        }
    }

    private void deletePartyAsync(UUID partyId) {
        if (plugin.getStorageManager() != null) {
            plugin.getStorageManager().deleteParty(partyId);
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Utility
    // ═══════════════════════════════════════════════════════

    private UUID findBestLeaderCandidate(Party party) {
        // Prefer online moderators, then online members
        for (UUID memberUuid : party.getMembers()) {
            if (party.getRole(memberUuid) == PartyRole.MODERATOR) {
                Player member = Bukkit.getPlayer(memberUuid);
                if (member != null && member.isOnline()) return memberUuid;
            }
        }
        for (UUID memberUuid : party.getMembers()) {
            Player member = Bukkit.getPlayer(memberUuid);
            if (member != null && member.isOnline()) return memberUuid;
        }
        // Safe fallback: get any member (check iterator has next)
        var it = party.getMembers().iterator();
        return it.hasNext() ? it.next() : null;
    }

    private void broadcastToParty(Party party, String message) {
        Component component = MINI.deserialize(getPrefix() + message);
        for (UUID memberUuid : party.getMembers()) {
            Player member = Bukkit.getPlayer(memberUuid);
            if (member != null && member.isOnline()) {
                member.sendMessage(component);
            }
        }
    }

    private void sendPrefixed(Player player, String message) {
        player.sendMessage(MINI.deserialize(getPrefix() + message));
    }

    private String getPrefix() {
        return plugin.getConfig().getString("messages.prefix",
                "<gradient:#00d4ff:#00ff88>⚔ Party</gradient> <dark_gray>»</dark_gray> ");
    }

    private String getMessage(String key) {
        return plugin.getConfig().getString("messages." + key, "<red>Mensaje no encontrado: " + key);
    }

    private String getPlayerName(UUID uuid) {
        Player player = Bukkit.getPlayer(uuid);
        if (player != null) return player.getName();
        var offlinePlayer = Bukkit.getOfflinePlayer(uuid);
        String name = offlinePlayer.getName();
        return name != null ? name : uuid.toString().substring(0, 8);
    }

    /**
     * Refresh the lobby hotbar items for a player after party state changes.
     * This ensures the party CAKE item is added/removed correctly.
     */
    private void refreshLobbyItems(Player player) {
        if (player == null || !player.isOnline()) return;
        String state = core.getStateManager().getState(player.getUniqueId());
        if ("lobby".equals(state) && core.getLobbyManager() != null) {
            core.getLobbyManager().giveLobbyItems(player);
        }
    }
}
