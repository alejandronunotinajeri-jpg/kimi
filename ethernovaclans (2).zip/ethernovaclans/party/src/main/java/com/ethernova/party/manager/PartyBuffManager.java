package com.ethernova.party.manager;

import com.ethernova.core.EthernovaCore;
import com.ethernova.party.EthernovaParty;
import com.ethernova.party.model.Party;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages party buffs — bonuses applied to party members based on party size.
 *
 * Buffs:
 *   - XP Multiplier: +5% per additional member (max +25% at 6 members)
 *   - Speed Boost: Speed I when party has 3+ online members
 *   - Regeneration: Regen I when party has 5+ online members
 *
 * Buffs are applied periodically via a scheduled task and removed when
 * the player leaves the party or goes offline.
 */
public class PartyBuffManager {

    private static final MiniMessage MINI = MiniMessage.miniMessage();

    private final EthernovaParty plugin;
    private final EthernovaCore core;
    private final Map<UUID, ActiveBuff> activeBuffs = new ConcurrentHashMap<>();
    private int taskId = -1;

    /** Tracks what buffs a player currently has */
    public record ActiveBuff(double xpMultiplier, boolean hasSpeed, boolean hasRegen) {}

    public PartyBuffManager(EthernovaParty plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
    }

    /**
     * Start the periodic buff update task.
     */
    public void start() {
        if (!plugin.getConfig().getBoolean("buffs.enabled", true)) return;

        int intervalSeconds = plugin.getConfig().getInt("buffs.update-interval", 30);
        long intervalTicks = intervalSeconds * 20L;
        taskId = Bukkit.getScheduler().runTaskTimer(plugin, this::updateAllBuffs, 60L, intervalTicks).getTaskId();
    }

    /**
     * Stop the buff task and remove all active buffs.
     */
    public void stop() {
        if (taskId != -1) {
            Bukkit.getScheduler().cancelTask(taskId);
            taskId = -1;
        }
        // Remove all active buff effects
        for (UUID uuid : activeBuffs.keySet()) {
            removeBuffEffects(uuid);
        }
        activeBuffs.clear();
    }

    /**
     * Update buffs for all players in parties.
     */
    private void updateAllBuffs() {
        PartyManager pm = plugin.getPartyManager();
        if (pm == null) return;

        for (Party party : pm.getAllParties()) {
            int onlineCount = countOnline(party);
            if (onlineCount < 2) {
                // Remove buffs for all members if only 1 or 0 online
                for (UUID memberUuid : party.getMembers()) {
                    if (activeBuffs.containsKey(memberUuid)) {
                        removeBuffEffects(memberUuid);
                        activeBuffs.remove(memberUuid);
                    }
                }
                continue;
            }

            double xpMulti = calculateXPMultiplier(onlineCount);
            boolean speedBuff = onlineCount >= plugin.getConfig().getInt("buffs.speed-threshold", 3);
            boolean regenBuff = onlineCount >= plugin.getConfig().getInt("buffs.regen-threshold", 5);

            for (UUID memberUuid : party.getMembers()) {
                Player member = Bukkit.getPlayer(memberUuid);
                if (member == null || !member.isOnline()) {
                    if (activeBuffs.containsKey(memberUuid)) {
                        activeBuffs.remove(memberUuid);
                    }
                    continue;
                }

                ActiveBuff current = activeBuffs.get(memberUuid);
                ActiveBuff newBuff = new ActiveBuff(xpMulti, speedBuff, regenBuff);

                if (current == null || !current.equals(newBuff)) {
                    applyBuffEffects(member, newBuff);
                    activeBuffs.put(memberUuid, newBuff);
                }
            }
        }
    }

    /**
     * Calculate XP multiplier based on online party members.
     * Base: 1.0, +5% per additional member (beyond the player themselves).
     */
    private double calculateXPMultiplier(int onlineMembers) {
        double bonusPerMember = plugin.getConfig().getDouble("buffs.xp-bonus-per-member", 0.05);
        double maxBonus = plugin.getConfig().getDouble("buffs.xp-max-bonus", 0.25);
        double bonus = Math.min((onlineMembers - 1) * bonusPerMember, maxBonus);
        return 1.0 + bonus;
    }

    /**
     * Apply potion effects to a player based on their active buff.
     */
    private void applyBuffEffects(Player player, ActiveBuff buff) {
        int duration = 200; // 10 seconds (re-applied every 5s, so always active)

        if (buff.hasSpeed()) {
            int amplifier = plugin.getConfig().getInt("buffs.speed-amplifier", 0);
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, duration, amplifier, true, false, true));
        }

        if (buff.hasRegen()) {
            int amplifier = plugin.getConfig().getInt("buffs.regen-amplifier", 0);
            player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, duration, amplifier, true, false, true));
        }
    }

    /**
     * Remove buff effects from a player.
     */
    public void removeBuffEffects(UUID uuid) {
        Player player = Bukkit.getPlayer(uuid);
        if (player != null && player.isOnline()) {
            player.removePotionEffect(PotionEffectType.SPEED);
            player.removePotionEffect(PotionEffectType.REGENERATION);
        }
        activeBuffs.remove(uuid);
    }

    /**
     * Get the current XP multiplier for a player in a party.
     * Returns 1.0 if the player has no active party buff.
     */
    public double getXPMultiplier(UUID uuid) {
        ActiveBuff buff = activeBuffs.get(uuid);
        return buff != null ? buff.xpMultiplier() : 1.0;
    }

    /**
     * Check if a player has an active party buff.
     */
    public boolean hasActiveBuff(UUID uuid) {
        return activeBuffs.containsKey(uuid);
    }

    private int countOnline(Party party) {
        int count = 0;
        for (UUID uuid : party.getMembers()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline()) count++;
        }
        return count;
    }
}
