package com.ethernova.party.command;

import com.ethernova.party.EthernovaParty;
import com.ethernova.party.gui.PartyAdminGui;
import com.ethernova.party.gui.PartyGui;
import com.ethernova.party.gui.PartyListGui;
import com.ethernova.party.gui.PartyMenuGui;
import com.ethernova.party.gui.PartySettingsGui;
import com.ethernova.party.manager.PartyManager;
import com.ethernova.party.model.Party;
import com.ethernova.party.model.PartyRole;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Main command handler for /party (aliases: /p, /grupo).
 *
 * Subcommands:
 *   create, invite <player>, accept, decline, kick <player>, promote <player>,
 *   leave, disband, chat, list, info, teleport, gui, public, settings,
 *   ready [accept|decline], mod <player>, demote <player>, name <name>
 */
public class PartyCommand implements CommandExecutor, TabCompleter {

    private final EthernovaParty plugin;
    private final MiniMessage mini = MiniMessage.miniMessage();

    private static final List<String> SUBCOMMANDS = List.of(
            "create", "invite", "accept", "decline", "kick", "promote",
            "leave", "disband", "chat", "list", "info", "teleport", "gui", "public",
            "settings", "ready", "mod", "demote", "name", "admin"
    );

    public PartyCommand(EthernovaParty plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(mini.deserialize("<red>Este comando solo puede ser usado por jugadores."));
            return true;
        }

        if (!player.hasPermission("ethernova.party.use")) {
            sendPrefixed(player, "<red>No tienes permiso para usar este comando.");
            return true;
        }

        if (args.length == 0) {
            Party party = plugin.getPartyManager().getParty(player.getUniqueId());
            if (party != null) {
                showPartyInfo(player, party);
            } else {
                showHelp(player, label);
            }
            return true;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "create", "crear" -> handleCreate(player);
            case "invite", "invitar", "inv" -> handleInvite(player, args, label);
            case "accept", "aceptar" -> handleAccept(player);
            case "decline", "rechazar", "deny" -> handleDecline(player);
            case "kick", "expulsar" -> handleKick(player, args, label);
            case "promote", "promover" -> handlePromote(player, args, label);
            case "leave", "salir" -> handleLeave(player);
            case "disband", "disolver" -> handleDisband(player);
            case "chat" -> handleChat(player);
            case "list", "lista" -> handleList(player);
            case "info" -> handleInfo(player, args);
            case "teleport", "tp" -> handleTeleport(player);
            case "gui", "menu" -> handleGui(player);
            case "public", "publico" -> handlePublic(player);
            case "settings", "config", "configuracion" -> handleSettings(player);
            case "ready", "listo" -> handleReady(player, args);
            case "mod", "moderador" -> handleMod(player, args, label);
            case "demote", "degradar" -> handleDemote(player, args, label);
            case "name", "nombre" -> handleName(player, args, label);
            case "admin" -> {
                if (!player.hasPermission("ethernova.party.admin")) {
                    sendPrefixed(player, "<red>No tienes permiso para usar este comando.");
                    return true;
                }
                new PartyAdminGui(plugin, player).open();
            }
            default -> showHelp(player, label);
        }

        return true;
    }

    // ═══════════════ Subcommand Handlers ═══════════════

    private void handleCreate(Player player) {
        if (!player.hasPermission("ethernova.party.create")) {
            sendPrefixed(player, "<red>No tienes permiso para crear un grupo.");
            return;
        }
        Party existing = plugin.getPartyManager().getParty(player.getUniqueId());
        if (existing != null) {
            sendPrefixed(player, getMessage("already-in-party"));
            plugin.getCore().getSoundManager().play(player, "error");
            return;
        }
        plugin.getPartyManager().createParty(player);
    }

    private void handleInvite(Player player, String[] args, String label) {
        if (args.length < 2) {
            sendPrefixed(player, "<yellow>Uso: /" + label + " invite <jugador>");
            return;
        }

        // Auto-create party if not in one
        Party party = plugin.getPartyManager().getParty(player.getUniqueId());
        if (party == null) {
            party = plugin.getPartyManager().createParty(player);
            if (party == null) return;
        }

        Player target = Bukkit.getPlayer(args[1]);
        if (target == null || !target.isOnline()) {
            sendPrefixed(player, getMessage("player-not-found"));
            plugin.getCore().getSoundManager().play(player, "error");
            return;
        }

        plugin.getPartyManager().invitePlayer(player, target);
    }

    private void handleAccept(Player player) {
        plugin.getPartyManager().acceptInvite(player);
    }

    private void handleDecline(Player player) {
        plugin.getPartyManager().declineInvite(player);
    }

    private void handleKick(Player player, String[] args, String label) {
        if (args.length < 2) {
            sendPrefixed(player, "<yellow>Uso: /" + label + " kick <jugador>");
            return;
        }

        Party party = plugin.getPartyManager().getParty(player.getUniqueId());
        if (party == null) {
            sendPrefixed(player, getMessage("not-in-party"));
            return;
        }

        UUID targetUuid = resolvePartyMember(party, args[1]);
        if (targetUuid == null) {
            sendPrefixed(player, getMessage("player-not-in-party"));
            plugin.getCore().getSoundManager().play(player, "error");
            return;
        }

        plugin.getPartyManager().kickPlayer(player, targetUuid);
    }

    private void handlePromote(Player player, String[] args, String label) {
        if (args.length < 2) {
            sendPrefixed(player, "<yellow>Uso: /" + label + " promote <jugador>");
            return;
        }

        Party party = plugin.getPartyManager().getParty(player.getUniqueId());
        if (party == null) {
            sendPrefixed(player, getMessage("not-in-party"));
            return;
        }

        UUID targetUuid = resolvePartyMember(party, args[1]);
        if (targetUuid == null) {
            sendPrefixed(player, getMessage("player-not-in-party"));
            plugin.getCore().getSoundManager().play(player, "error");
            return;
        }

        plugin.getPartyManager().promoteLeader(player, targetUuid);
    }

    private void handleLeave(Player player) {
        plugin.getPartyManager().leaveParty(player);
    }

    private void handleDisband(Player player) {
        Party party = plugin.getPartyManager().getParty(player.getUniqueId());
        if (party == null) {
            sendPrefixed(player, getMessage("not-in-party"));
            return;
        }
        if (!party.isLeader(player.getUniqueId())) {
            sendPrefixed(player, getMessage("not-leader"));
            plugin.getCore().getSoundManager().play(player, "error");
            return;
        }
        plugin.getPartyManager().disbandParty(player);
    }

    private void handleChat(Player player) {
        if (!player.hasPermission("ethernova.party.chat")) {
            sendPrefixed(player, "<red>No tienes permiso para usar el chat de grupo.");
            return;
        }

        Party party = plugin.getPartyManager().getParty(player.getUniqueId());
        if (party == null) {
            sendPrefixed(player, getMessage("not-in-party"));
            return;
        }

        boolean enabled = plugin.getPartyChat().toggle(player.getUniqueId());
        if (enabled) {
            sendPrefixed(player, getMessage("chat-enabled"));
        } else {
            sendPrefixed(player, getMessage("chat-disabled"));
        }
        plugin.getCore().getSoundManager().play(player, "party-chat-toggle");
    }

    private void handleList(Player player) {
        new PartyListGui(plugin.getCore(), player, plugin).open();
    }

    private void handleInfo(Player player, String[] args) {
        Party party;
        if (args.length >= 2) {
            Player target = Bukkit.getPlayer(args[1]);
            if (target == null) {
                sendPrefixed(player, getMessage("player-not-found"));
                return;
            }
            party = plugin.getPartyManager().getParty(target.getUniqueId());
        } else {
            party = plugin.getPartyManager().getParty(player.getUniqueId());
        }

        if (party == null) {
            sendPrefixed(player, getMessage("not-in-party"));
            return;
        }

        showPartyInfo(player, party);
    }

    private void handleTeleport(Player player) {
        if (!player.hasPermission("ethernova.party.teleport")) {
            sendPrefixed(player, "<red>No tienes permiso para teleportar al grupo.");
            return;
        }
        plugin.getPartyManager().teleportAll(player);
    }

    private void handleGui(Player player) {
        Party party = plugin.getPartyManager().getParty(player.getUniqueId());
        if (party == null) {
            // Not in a party — open the party selector GUI (create/browse)
            new PartyMenuGui(plugin.getCore(), player, plugin).open();
            return;
        }
        new PartyGui(plugin.getCore(), player, party, plugin).open();
    }

    private void handlePublic(Player player) {
        boolean allowPublic = plugin.getConfig().getBoolean("party.allow-public", true);
        if (!allowPublic) {
            sendPrefixed(player, getMessage("public-not-allowed"));
            plugin.getCore().getSoundManager().play(player, "error");
            return;
        }

        Party party = plugin.getPartyManager().getParty(player.getUniqueId());
        if (party == null) {
            sendPrefixed(player, getMessage("not-in-party"));
            return;
        }
        if (!party.isLeader(player.getUniqueId())) {
            sendPrefixed(player, getMessage("not-leader"));
            plugin.getCore().getSoundManager().play(player, "error");
            return;
        }

        boolean newState = !party.isPublic();
        party.setPublic(newState);
        if (newState) {
            sendPrefixed(player, getMessage("public-enabled"));
        } else {
            sendPrefixed(player, getMessage("public-disabled"));
        }
        plugin.getCore().getSoundManager().play(player, "click");
    }

    private void handleSettings(Player player) {
        Party party = plugin.getPartyManager().getParty(player.getUniqueId());
        if (party == null) {
            sendPrefixed(player, getMessage("not-in-party"));
            return;
        }
        if (!party.isLeader(player.getUniqueId())) {
            sendPrefixed(player, getMessage("not-leader"));
            plugin.getCore().getSoundManager().play(player, "error");
            return;
        }
        new PartySettingsGui(plugin.getCore(), player, party, plugin).open();
    }

    private void handleReady(Player player, String[] args) {
        if (args.length >= 2) {
            String subAction = args[1].toLowerCase();
            switch (subAction) {
                case "accept", "aceptar", "si", "yes" -> plugin.getReadyCheckManager().acceptReady(player);
                case "decline", "rechazar", "no" -> plugin.getReadyCheckManager().declineReady(player);
                default -> plugin.getReadyCheckManager().startReadyCheck(player, null);
            }
        } else {
            // Start a ready check
            plugin.getReadyCheckManager().startReadyCheck(player, null);
        }
    }

    private void handleMod(Player player, String[] args, String label) {
        if (args.length < 2) {
            sendPrefixed(player, "<yellow>Uso: /" + label + " mod <jugador>");
            return;
        }

        Party party = plugin.getPartyManager().getParty(player.getUniqueId());
        if (party == null) {
            sendPrefixed(player, getMessage("not-in-party"));
            return;
        }

        UUID targetUuid = resolvePartyMember(party, args[1]);
        if (targetUuid == null) {
            sendPrefixed(player, getMessage("player-not-in-party"));
            plugin.getCore().getSoundManager().play(player, "error");
            return;
        }

        if (!plugin.getPartyManager().setModerator(player, targetUuid)) {
            sendPrefixed(player, getMessage("not-leader"));
            plugin.getCore().getSoundManager().play(player, "error");
        }
    }

    private void handleDemote(Player player, String[] args, String label) {
        if (args.length < 2) {
            sendPrefixed(player, "<yellow>Uso: /" + label + " demote <jugador>");
            return;
        }

        Party party = plugin.getPartyManager().getParty(player.getUniqueId());
        if (party == null) {
            sendPrefixed(player, getMessage("not-in-party"));
            return;
        }

        UUID targetUuid = resolvePartyMember(party, args[1]);
        if (targetUuid == null) {
            sendPrefixed(player, getMessage("player-not-in-party"));
            plugin.getCore().getSoundManager().play(player, "error");
            return;
        }

        if (!plugin.getPartyManager().demoteMember(player, targetUuid)) {
            sendPrefixed(player, getMessage("not-leader"));
            plugin.getCore().getSoundManager().play(player, "error");
        }
    }

    private void handleName(Player player, String[] args, String label) {
        if (args.length < 2) {
            sendPrefixed(player, "<yellow>Uso: /" + label + " name <nombre>");
            return;
        }

        Party party = plugin.getPartyManager().getParty(player.getUniqueId());
        if (party == null) {
            sendPrefixed(player, getMessage("not-in-party"));
            return;
        }
        if (!party.isLeader(player.getUniqueId())) {
            sendPrefixed(player, getMessage("not-leader"));
            plugin.getCore().getSoundManager().play(player, "error");
            return;
        }

        String name = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
        // Sanitize MiniMessage tags to prevent injection
        name = net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .stripTags(name);
        if (name.length() > 32) {
            sendPrefixed(player, "<red>El nombre no puede tener más de 32 caracteres.");
            return;
        }
        party.setName(name);
        sendPrefixed(player, "<green>Nombre del grupo actualizado a: <white>" + name);
        plugin.getCore().getSoundManager().play(player, "click");
    }

    // ═══════════════ Info Display ═══════════════

    private void showPartyInfo(Player player, Party party) {
        String leaderName = getPlayerName(party.getLeaderUuid());
        String partyName = party.getName() != null ? party.getName() : "Grupo de " + leaderName;

        player.sendMessage(mini.deserialize(getMessage("party-info-header")));
        player.sendMessage(mini.deserialize(getPrefix() + "<gray>Nombre: <white>" + partyName));
        player.sendMessage(mini.deserialize(getPrefix() + getMessage("party-info-leader")
                .replace("{player}", leaderName)));
        player.sendMessage(mini.deserialize(getPrefix() + getMessage("party-info-members")
                .replace("{count}", String.valueOf(party.getSize()))
                .replace("{max}", String.valueOf(party.getMaxSize()))));

        for (UUID memberUuid : party.getMembers()) {
            Player memberPlayer = Bukkit.getPlayer(memberUuid);
            boolean online = memberPlayer != null && memberPlayer.isOnline();
            String name = getPlayerName(memberUuid);
            PartyRole role = party.getRole(memberUuid);
            String roleIcon = role.getIcon();

            if (online) {
                player.sendMessage(mini.deserialize(getPrefix() + getMessage("party-info-member")
                        .replace("{player}", name) + " " + roleIcon + " <dark_gray>(" + role.getDisplayName() + ")"));
            } else {
                player.sendMessage(mini.deserialize(getPrefix() + getMessage("party-info-member-offline")
                        .replace("{player}", name) + " " + roleIcon));
            }
        }

        String publicStatus = party.isPublic() ? "<green>Sí" : "<red>No";
        player.sendMessage(mini.deserialize(getPrefix() + getMessage("party-info-public")
                .replace("{status}", publicStatus)));

        // Show friendly fire status
        String ffStatus = party.isFriendlyFireEnabled() ? "<red>Activado" : "<green>Desactivado";
        player.sendMessage(mini.deserialize(getPrefix() + "<gray>Fuego Amigo: " + ffStatus));

        // Show buffs status
        if (plugin.getBuffManager() != null && plugin.getBuffManager().hasActiveBuff(player.getUniqueId())) {
            double xpMult = plugin.getBuffManager().getXPMultiplier(player.getUniqueId());
            player.sendMessage(mini.deserialize(getPrefix() + "<gray>Buff XP: <green>+" + Math.round((xpMult - 1.0) * 100) + "%"));
        }
    }

    private void showHelp(Player player, String label) {
        player.sendMessage(mini.deserialize("<gradient:#00d4ff:#00ff88>═══ EthernovaParty ═══</gradient>"));
        player.sendMessage(mini.deserialize("<gray>/<yellow>" + label + " create</yellow> — Crear un grupo"));
        player.sendMessage(mini.deserialize("<gray>/<yellow>" + label + " invite <jugador></yellow> — Invitar a un jugador"));
        player.sendMessage(mini.deserialize("<gray>/<yellow>" + label + " accept</yellow> — Aceptar invitación"));
        player.sendMessage(mini.deserialize("<gray>/<yellow>" + label + " decline</yellow> — Rechazar invitación"));
        player.sendMessage(mini.deserialize("<gray>/<yellow>" + label + " kick <jugador></yellow> — Expulsar a un jugador"));
        player.sendMessage(mini.deserialize("<gray>/<yellow>" + label + " promote <jugador></yellow> — Promover a líder"));
        player.sendMessage(mini.deserialize("<gray>/<yellow>" + label + " mod <jugador></yellow> — Promover a moderador"));
        player.sendMessage(mini.deserialize("<gray>/<yellow>" + label + " demote <jugador></yellow> — Degradar a miembro"));
        player.sendMessage(mini.deserialize("<gray>/<yellow>" + label + " leave</yellow> — Abandonar el grupo"));
        player.sendMessage(mini.deserialize("<gray>/<yellow>" + label + " disband</yellow> — Disolver el grupo"));
        player.sendMessage(mini.deserialize("<gray>/<yellow>" + label + " chat</yellow> — Activar/desactivar chat de grupo"));
        player.sendMessage(mini.deserialize("<gray>/<yellow>" + label + " list</yellow> — Ver grupos públicos"));
        player.sendMessage(mini.deserialize("<gray>/<yellow>" + label + " info</yellow> — Ver info del grupo"));
        player.sendMessage(mini.deserialize("<gray>/<yellow>" + label + " teleport</yellow> — Teleportar miembros"));
        player.sendMessage(mini.deserialize("<gray>/<yellow>" + label + " gui</yellow> — Abrir menú del grupo"));
        player.sendMessage(mini.deserialize("<gray>/<yellow>" + label + " settings</yellow> — Configuración del grupo"));
        player.sendMessage(mini.deserialize("<gray>/<yellow>" + label + " ready</yellow> — Iniciar ready check"));
        player.sendMessage(mini.deserialize("<gray>/<yellow>" + label + " name <nombre></yellow> — Nombrar el grupo"));
        player.sendMessage(mini.deserialize("<gray>/<yellow>" + label + " public</yellow> — Alternar grupo público/privado"));
    }

    // ═══════════════ Tab Completion ═══════════════

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                 @NotNull String alias, @NotNull String[] args) {
        if (!(sender instanceof Player player)) return List.of();

        List<String> completions = new ArrayList<>();

        if (args.length == 1) {
            completions.addAll(SUBCOMMANDS);
            completions.addAll(List.of("crear", "invitar", "aceptar", "rechazar",
                    "expulsar", "promover", "salir", "disolver", "lista", "tp", "menu",
                    "publico", "configuracion", "listo", "moderador", "degradar", "nombre"));
            return filterCompletions(completions, args[0]);
        }

        if (args.length == 2) {
            String sub = args[0].toLowerCase();
            switch (sub) {
                case "invite", "invitar", "inv" -> {
                    for (Player online : Bukkit.getOnlinePlayers()) {
                        if (online.equals(player)) continue;
                        if (plugin.getPartyManager().isInParty(online.getUniqueId())) continue;
                        completions.add(online.getName());
                    }
                }
                case "kick", "expulsar" -> {
                    Party party = plugin.getPartyManager().getParty(player.getUniqueId());
                    if (party != null) {
                        for (UUID memberUuid : party.getMembers()) {
                            if (memberUuid.equals(player.getUniqueId())) continue;
                            completions.add(getPlayerName(memberUuid));
                        }
                    }
                }
                case "promote", "promover", "mod", "moderador", "demote", "degradar" -> {
                    Party party = plugin.getPartyManager().getParty(player.getUniqueId());
                    if (party != null) {
                        for (UUID memberUuid : party.getMembers()) {
                            if (party.isLeader(memberUuid)) continue;
                            completions.add(getPlayerName(memberUuid));
                        }
                    }
                }
                case "info" -> {
                    for (Player online : Bukkit.getOnlinePlayers()) {
                        completions.add(online.getName());
                    }
                }
                case "ready", "listo" -> {
                    completions.addAll(List.of("accept", "decline", "aceptar", "rechazar"));
                }
            }
            return filterCompletions(completions, args[1]);
        }

        return completions;
    }

    // ═══════════════ Utility ═══════════════

    private UUID resolvePartyMember(Party party, String name) {
        Player target = Bukkit.getPlayer(name);
        if (target != null && party.isMember(target.getUniqueId())) {
            return target.getUniqueId();
        }
        for (UUID memberUuid : party.getMembers()) {
            var offlinePlayer = Bukkit.getOfflinePlayer(memberUuid);
            if (name.equalsIgnoreCase(offlinePlayer.getName())) {
                return memberUuid;
            }
        }
        return null;
    }

    private String getPlayerName(UUID uuid) {
        Player player = Bukkit.getPlayer(uuid);
        if (player != null) return player.getName();
        var offlinePlayer = Bukkit.getOfflinePlayer(uuid);
        String name = offlinePlayer.getName();
        return name != null ? name : uuid.toString().substring(0, 8);
    }

    private void sendPrefixed(Player player, String message) {
        player.sendMessage(mini.deserialize(getPrefix() + message));
    }

    private String getPrefix() {
        return plugin.getConfig().getString("messages.prefix",
                "<gradient:#00d4ff:#00ff88>⚔ Party</gradient> <dark_gray>»</dark_gray> ");
    }

    private String getMessage(String key) {
        return plugin.getConfig().getString("messages." + key, "<red>Mensaje no encontrado: " + key);
    }

    private List<String> filterCompletions(List<String> options, String input) {
        String lower = input.toLowerCase();
        return options.stream()
                .filter(s -> s.toLowerCase().startsWith(lower))
                .sorted()
                .collect(Collectors.toList());
    }
}
