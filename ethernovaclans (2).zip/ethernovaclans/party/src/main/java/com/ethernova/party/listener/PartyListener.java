package com.ethernova.party.listener;

import com.ethernova.party.EthernovaParty;
import com.ethernova.party.model.Party;
import com.ethernova.party.model.PartyChat;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

/**
 * Handles party-related Bukkit events:
 * - PlayerQuit: Transfer leader or handle empty parties
 * - PlayerJoin: Re-notify party members on reconnect
 * - AsyncPlayerChat: Party chat mode and quick prefix
 * - EntityDamageByEntityEvent: Friendly fire prevention
 */
public class PartyListener implements Listener {

    private final EthernovaParty plugin;
    private final MiniMessage mini = MiniMessage.miniMessage();

    public PartyListener(EthernovaParty plugin) {
        this.plugin = plugin;
    }

    /**
     * Handle player disconnection.
     * - Disable their party chat mode
     * - If leader, transfer leadership to an online member
     * - Player remains in the party for rejoin (or auto-removed after timeout)
     */
    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        plugin.getPartyManager().handlePlayerQuit(player.getUniqueId());
    }

    /**
     * Handle player reconnection.
     * - Notify the player their party is still active
     * - Restore party context
     * - Re-apply buffs
     */
    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        // Delay slightly to let the player fully load
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline()) {
                plugin.getPartyManager().handlePlayerJoin(player);
            }
        }, 20L); // 1 second delay
    }

    /**
     * Handle party chat via toggled mode or quick prefix.
     * - If party chat mode is enabled, redirect all messages to party
     * - If message starts with quick prefix (default "!"), redirect to party
     */
    @EventHandler(priority = EventPriority.LOW)
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        PartyChat partyChat = plugin.getPartyChat();
        String message = event.getMessage();

        // Quick prefix check (e.g., "!hello" sends "hello" to party chat)
        String quickPrefix = plugin.getConfig().getString("chat.quick-prefix", "!");
        boolean isQuickChat = !quickPrefix.isEmpty() && message.startsWith(quickPrefix);

        // Toggle mode or quick prefix
        if (partyChat.isChatEnabled(player.getUniqueId()) || isQuickChat) {
            Party party = plugin.getPartyManager().getParty(player.getUniqueId());
            if (party == null) {
                // Not in a party — disable chat mode and let message through normally
                partyChat.disable(player.getUniqueId());
                return;
            }

            event.setCancelled(true);

            String chatMessage = isQuickChat ? message.substring(quickPrefix.length()).trim() : message;
            if (chatMessage.isEmpty()) return;

            // Broadcast on main thread (event is async)
            final String finalMessage = chatMessage;
            Bukkit.getScheduler().runTask(plugin, () ->
                    partyChat.broadcast(party, player, finalMessage));
        }
    }

    // ────────────────── Party Game Death/Respawn ──────────────────

    @EventHandler(priority = EventPriority.HIGH)
    public void onPartyGameDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        if (!plugin.getPartyGamesManager().isInGame(victim.getUniqueId())) return;

        // Prevent drops and death message
        event.getDrops().clear();
        event.setDroppedExp(0);
        event.deathMessage(null);
        event.setKeepInventory(true);
        event.setKeepLevel(true);

        // Heal + re-kit killer
        Player killer = victim.getKiller();
        if (killer != null && plugin.getPartyGamesManager().isInGame(killer.getUniqueId())) {
            killer.setHealth(killer.getMaxHealth());
            killer.setFoodLevel(20);
            killer.setSaturation(20f);
        }

        // Handle death logic (respawn/elimination, stats tracking)
        plugin.getPartyGamesManager().handleDeath(
                victim.getUniqueId(),
                killer != null ? killer.getUniqueId() : null);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPartyGameRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        var session = plugin.getPartyGamesManager().getPlayerSession(player.getUniqueId());
        if (session == null) return;
        if (session.getArena() != null && session.getArena().spawn1() != null) {
            event.setRespawnLocation(session.getArena().spawn1());
        }
    }

    /**
     * Handle friendly fire between party members.
     * If both attacker and victim are in the same party, and friendly fire is disabled
     * in that party's settings, cancel the damage event.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        // Only process player-on-player damage
        Player attacker = resolveAttacker(event);
        if (attacker == null) return;

        if (!(event.getEntity() instanceof Player victim)) return;

        // Don't cancel self-damage
        if (attacker.equals(victim)) return;

        // Check if party manager should cancel this damage
        if (plugin.getPartyManager().shouldCancelDamage(attacker.getUniqueId(), victim.getUniqueId())) {
            event.setCancelled(true);
            // Subtle feedback — only send actionbar so it's not spammy
            attacker.sendActionBar(mini.deserialize(
                    "<red>¡No puedes dañar a un miembro de tu grupo!"));
        }
    }

    /**
     * Resolve the attacking player from a damage event,
     * handling both direct damage and projectile damage.
     */
    private Player resolveAttacker(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player player) {
            return player;
        }
        if (event.getDamager() instanceof Projectile projectile) {
            if (projectile.getShooter() instanceof Player shooter) {
                return shooter;
            }
        }
        return null;
    }
}
