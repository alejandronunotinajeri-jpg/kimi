package com.ethernova.party.api;

import com.ethernova.party.model.Party;

import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Public API interface for EthernovaParty.
 *
 * <p>Provides methods for querying party membership, party info,
 * combat integration (friendly fire), buffs, and ready checks.</p>
 *
 * <p>Obtain an instance via {@code ServiceRegistry.get(PartyAPI.class)}.</p>
 *
 * <p>All methods are thread-safe and may be called from any thread.</p>
 */
public interface PartyAPI {

    // ═══════════════ Queries ═══════════════

    /**
     * Get a player's current party.
     *
     * @param playerUuid the UUID of the player
     * @return the player's {@link Party}, or {@code null} if not in one
     */
    Party getParty(UUID playerUuid);

    /**
     * Get a party by its unique identifier.
     *
     * @param partyId the UUID of the party
     * @return the {@link Party}, or {@code null} if no party with that ID exists
     */
    Party getPartyById(UUID partyId);

    /**
     * Check if a player is currently in any party.
     *
     * @param playerUuid the UUID of the player
     * @return {@code true} if the player is in a party
     */
    boolean isInParty(UUID playerUuid);

    /**
     * Check if two players are in the same party.
     *
     * @param player1 the UUID of the first player
     * @param player2 the UUID of the second player
     * @return {@code true} if both players belong to the same party
     */
    boolean areInSameParty(UUID player1, UUID player2);

    /**
     * Get all currently active parties.
     *
     * @return an unmodifiable collection of all active {@link Party} instances
     */
    Collection<Party> getAllParties();

    /**
     * Get public, non-full parties available for joining.
     *
     * @return a list of joinable public parties
     */
    List<Party> getPublicParties();

    /**
     * Check if a player has a pending party invite.
     *
     * @param playerUuid the UUID of the player
     * @return {@code true} if the player has an outstanding invite
     */
    boolean hasPendingInvite(UUID playerUuid);

    // ═══════════════ Party Info ═══════════════

    /**
     * Get the current size of a player's party.
     *
     * @param playerUuid the UUID of the player
     * @return the number of members in the party, or {@code 0} if not in one
     */
    int getPartySize(UUID playerUuid);

    /**
     * Get the leader UUID of a player's party.
     *
     * @param playerUuid the UUID of the player
     * @return the UUID of the party leader, or {@code null} if the player is not in a party
     */
    UUID getPartyLeader(UUID playerUuid);

    /**
     * Get all member UUIDs in a player's party.
     *
     * @param playerUuid the UUID of the player
     * @return an unmodifiable set of member UUIDs, or an empty set if not in a party
     */
    Set<UUID> getPartyMembers(UUID playerUuid);

    // ═══════════════ Combat Integration ═══════════════

    /**
     * Check if damage between two players should be cancelled due to party friendly fire rules.
     *
     * @param attacker the UUID of the attacking player
     * @param victim   the UUID of the victim player
     * @return {@code true} if the damage should be cancelled
     */
    boolean shouldCancelDamage(UUID attacker, UUID victim);

    // ═══════════════ Buffs ═══════════════

    /**
     * Get the XP multiplier for a player from party buffs.
     *
     * @param uuid the UUID of the player
     * @return the XP multiplier (e.g., {@code 1.5} for 50% bonus), or {@code 1.0} if no buff is active
     */
    double getXPMultiplier(UUID uuid);

    /**
     * Check if a player has an active party buff.
     *
     * @param uuid the UUID of the player
     * @return {@code true} if the player has at least one active party buff
     */
    boolean hasActiveBuff(UUID uuid);

    // ═══════════════ Ready Checks ═══════════════

    /**
     * Check if a party has an active ready check in progress.
     *
     * @param partyId the UUID of the party
     * @return {@code true} if a ready check is currently active
     */
    boolean hasActiveReadyCheck(UUID partyId);
}
