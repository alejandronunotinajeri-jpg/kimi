package com.ethernova.party.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.CoreGui;
import com.ethernova.party.EthernovaParty;
import com.ethernova.party.model.Party;
import com.ethernova.party.model.PartySettings;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.List;

/**
 * Party settings GUI. Allows the leader to configure party options.
 * Settings: friendly fire, public/private, max size, moderator invites, party chat.
 */
public class PartySettingsGui extends CoreGui {

    private final Party party;
    private final EthernovaParty partyPlugin;

    public PartySettingsGui(EthernovaCore core, Player player, Party party, EthernovaParty partyPlugin) {
        super(core, player);
        this.party = party;
        this.partyPlugin = partyPlugin;
    }

    public void open() {
        openInventory("<gradient:#00d4ff:#00ff88>⚙ Configuración del Grupo</gradient>", 45);
    }

    @Override
    protected void populateItems() {
        PartySettings settings = party.getSettings();

        // ═══════════ Friendly Fire ═══════════
        boolean ff = settings.isFriendlyFire();
        setItem(10, createItem(ff ? Material.IRON_SWORD : Material.WOODEN_SWORD,
                ff ? "<red>⚔ Fuego Amigo: Activado" : "<green>⚔ Fuego Amigo: Desactivado",
                List.of(
                        "",
                        "<gray>Cuando está activado, los miembros",
                        "<gray>del grupo pueden dañarse entre sí.",
                        "",
                        "<yellow>▶ Click para " + (ff ? "desactivar" : "activar")
                )));
        slotActions.put(10, "TOGGLE_FF");

        // ═══════════ Public/Private ═══════════
        boolean pub = settings.isPublic();
        setItem(12, createItem(pub ? Material.OAK_DOOR : Material.IRON_DOOR,
                pub ? "<green>🔓 Grupo Público" : "<red>🔒 Grupo Privado",
                List.of(
                        "",
                        "<gray>Los grupos públicos aparecen en la",
                        "<gray>lista y cualquiera puede unirse.",
                        "",
                        "<yellow>▶ Click para " + (pub ? "hacer privado" : "hacer público")
                )));
        slotActions.put(12, "TOGGLE_PUBLIC");

        // ═══════════ Max Size ═══════════
        int maxSize = settings.getMaxSize();
        int globalMax = partyPlugin.getConfig().getInt("party.max-size-limit", 10);
        setItem(14, createItem(Material.COMPARATOR,
                "<aqua>👥 Tamaño Máximo: " + maxSize,
                List.of(
                        "",
                        "<gray>Miembros máximos permitidos.",
                        "<gray>Límite del servidor: <white>" + globalMax + "</white>",
                        "",
                        "<green>▶ Click izquierdo: +1",
                        "<red>▶ Click derecho: -1"
                )));
        slotActions.put(14, "MAX_SIZE");

        // ═══════════ Moderator Invite ═══════════
        boolean modInvite = settings.isAllowModeratorInvite();
        setItem(16, createItem(modInvite ? Material.WRITABLE_BOOK : Material.BOOK,
                modInvite ? "<green>✉ Mods pueden invitar: Sí" : "<red>✉ Mods pueden invitar: No",
                List.of(
                        "",
                        "<gray>Permite que los moderadores del grupo",
                        "<gray>inviten jugadores sin ser líder.",
                        "",
                        "<yellow>▶ Click para " + (modInvite ? "desactivar" : "activar")
                )));
        slotActions.put(16, "TOGGLE_MOD_INVITE");

        // ═══════════ Party Chat ═══════════
        boolean chatEnabled = settings.isPartyChat();
        setItem(28, createItem(chatEnabled ? Material.LIME_DYE : Material.GRAY_DYE,
                chatEnabled ? "<green>✎ Chat de Grupo: Activado" : "<red>✎ Chat de Grupo: Desactivado",
                List.of(
                        "",
                        "<gray>Habilita o deshabilita el chat",
                        "<gray>privado del grupo.",
                        "",
                        "<yellow>▶ Click para " + (chatEnabled ? "desactivar" : "activar")
                )));
        slotActions.put(28, "TOGGLE_CHAT");

        // ═══════════ Back Button ═══════════
        setItem(36, createItem(Material.ARROW, "<yellow>← Volver al grupo"));
        slotActions.put(36, "BACK");

        // ═══════════ Close ═══════════
        setItem(40, createItem(Material.BARRIER, "<red>Cerrar"));
        slotActions.put(40, "CLOSE");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        PartySettings settings = party.getSettings();

        switch (action) {
            case "TOGGLE_FF" -> {
                settings.setFriendlyFire(!settings.isFriendlyFire());
                playSound("click");
                markDirtyAndRefresh();
                return true;
            }
            case "TOGGLE_PUBLIC" -> {
                settings.setPublic(!settings.isPublic());
                party.setPublic(settings.isPublic());
                playSound("click");
                markDirtyAndRefresh();
                return true;
            }
            case "MAX_SIZE" -> {
                int globalMax = partyPlugin.getConfig().getInt("party.max-size-limit", 10);
                int current = settings.getMaxSize();
                if (event.isLeftClick()) {
                    if (current < globalMax) {
                        settings.setMaxSize(current + 1);
                        party.setMaxSize(current + 1);
                    }
                } else if (event.isRightClick()) {
                    if (current > party.getSize() && current > 2) {
                        settings.setMaxSize(current - 1);
                        party.setMaxSize(current - 1);
                    }
                }
                playSound("click");
                markDirtyAndRefresh();
                return true;
            }
            case "TOGGLE_MOD_INVITE" -> {
                settings.setAllowModeratorInvite(!settings.isAllowModeratorInvite());
                playSound("click");
                markDirtyAndRefresh();
                return true;
            }
            case "TOGGLE_CHAT" -> {
                settings.setPartyChat(!settings.isPartyChat());
                playSound("click");
                markDirtyAndRefresh();
                return true;
            }
            case "BACK" -> {
                playSound("click");
                player.closeInventory();
                new PartyGui(core, player, party, partyPlugin).open();
                return true;
            }
            case "CLOSE" -> {
                player.closeInventory();
                return true;
            }
        }
        return false;
    }

    private void markDirtyAndRefresh() {
        party.markDirty();
        // Save async
        if (partyPlugin.getStorageManager() != null) {
            partyPlugin.getStorageManager().saveParty(party);
        }
        open(); // Refresh GUI
    }
}
