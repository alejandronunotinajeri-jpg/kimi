package com.ethernova.party.model;

/**
 * Role within a party. Determines permissions for actions.
 */
public enum PartyRole {
    LEADER("Líder", "<gold>★"),
    MODERATOR("Moderador", "<yellow>◆"),
    MEMBER("Miembro", "<gray>●");

    private final String displayName;
    private final String icon;

    PartyRole(String displayName, String icon) {
        this.displayName = displayName;
        this.icon = icon;
    }

    public String getDisplayName() { return displayName; }
    public String getIcon() { return icon; }

    /**
     * Check if this role can invite players.
     */
    public boolean canInvite() {
        return this == LEADER || this == MODERATOR;
    }

    /**
     * Check if this role can kick players.
     */
    public boolean canKick() {
        return this == LEADER || this == MODERATOR;
    }

    /**
     * Check if this role can change party settings.
     */
    public boolean canManageSettings() {
        return this == LEADER;
    }

    /**
     * Check if this role can teleport all members.
     */
    public boolean canTeleport() {
        return this == LEADER || this == MODERATOR;
    }

    /**
     * Check if this role is higher than another.
     */
    public boolean isHigherThan(PartyRole other) {
        return this.ordinal() < other.ordinal();
    }
}
