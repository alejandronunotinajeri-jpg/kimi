package com.ethernova.party.games;

import com.ethernova.core.api.CombatAPI;
import com.ethernova.core.EthernovaCore;
import com.ethernova.core.service.ServiceRegistry;
import com.ethernova.party.EthernovaParty;
import com.ethernova.party.manager.PartyManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import java.util.stream.Collectors;

/**
 * Manages party games — 7 full game modes matching the original UltimateFFA.
 * 
 * Game Modes:
 * - DUELS: 1v1 round-based with target selection
 * - PARTY_FFA: All vs all with respawns
 * - KOTH: King of the Hill, hold zone 30s to win
 * - SUMO: Push opponent off ring, round-based
 * - PARKOUR: Race through checkpoints
 * - CHALLENGE: 6 challenge types (last_standing, most_kills, no_armor, one_hit, bow_only, axe_only)
 * - PARTY_WARS: Team-based elimination
 */
public class PartyGamesManager {

    private final EthernovaParty plugin;
    private final EthernovaCore core;
    private final MiniMessage mini = MiniMessage.miniMessage();

    // Active sessions
    private final Map<UUID, PartyGameSession> activeSessions = new ConcurrentHashMap<>();

    // Available arenas per type
    private final Map<GameType, List<GameArena>> arenas = new EnumMap<>(GameType.class);

    // ═══════════════════════════════════════
    // Game Type Enum
    // ═══════════════════════════════════════

    public enum GameType {
        DUELS("Duelos", Material.DIAMOND_SWORD, 2, 2, "1v1 entre miembros del party"),
        PARTY_FFA("Party FFA", Material.IRON_SWORD, 2, 16, "Todos contra todos del party"),
        KOTH("Rey de la Colina", Material.BEACON, 2, 16, "Mantente en la cima 30 segundos"),
        SUMO("Sumo", Material.SLIME_BALL, 2, 2, "Empuja al oponente fuera del ring"),
        PARKOUR("Parkour Race", Material.RABBIT_FOOT, 2, 8, "Carrera de parkour por checkpoints"),
        CHALLENGE("Desafío", Material.CLOCK, 2, 16, "Desafíos aleatorios con reglas especiales"),
        PARTY_WARS("Guerra de Parties", Material.SHIELD, 4, 32, "Party vs Party en equipos");

        private final String displayName;
        private final Material icon;
        private final int minPlayers;
        private final int maxPlayers;
        private final String description;

        GameType(String displayName, Material icon, int minPlayers, int maxPlayers, String description) {
            this.displayName = displayName;
            this.icon = icon;
            this.minPlayers = minPlayers;
            this.maxPlayers = maxPlayers;
            this.description = description;
        }

        public String getDisplayName() { return displayName; }
        public Material getIcon() { return icon; }
        public int getMinPlayers() { return minPlayers; }
        public int getMaxPlayers() { return maxPlayers; }
        public String getDescription() { return description; }
    }

    /**
     * Challenge sub-types for CHALLENGE mode.
     */
    public enum ChallengeType {
        LAST_STANDING("Último en Pie", "Sin respawns, el último vivo gana"),
        MOST_KILLS("Más Kills", "El que tenga más kills en 3 minutos gana"),
        NO_ARMOR("Sin Armadura", "Pelea sin armadura"),
        ONE_HIT("Un Golpe", "Todos mueren de un golpe"),
        BOW_ONLY("Solo Arco", "Solo se permite usar arco"),
        AXE_ONLY("Solo Hacha", "Solo se permite usar hacha");

        private final String displayName;
        private final String description;

        ChallengeType(String displayName, String description) {
            this.displayName = displayName;
            this.description = description;
        }

        public String getDisplayName() { return displayName; }
        public String getDescription() { return description; }
    }

    // ═══════════════════════════════════════
    // Arena Definition
    // ═══════════════════════════════════════

    public record GameArena(String id, String name, GameType type,
                            Location spawn1, Location spawn2,
                            Location spectatorSpawn,
                            Location kothZoneMin, Location kothZoneMax,
                            List<Location> parkourCheckpoints,
                            boolean available) {}

    // ═══════════════════════════════════════
    // Game Session
    // ═══════════════════════════════════════

    public static class PartyGameSession {
        private final UUID sessionId;
        private final UUID partyId;
        private final GameType type;
        private final GameArena arena;
        private final Set<UUID> participants;
        private final Set<UUID> alive;
        private final Map<UUID, Location> previousLocations;
        private final Map<UUID, Integer> kills;
        private final Map<UUID, Integer> deaths;
        private final long startTime;
        private BukkitTask gameTask;
        private GamePhase phase;
        private int countdown;

        // Mode-specific fields
        private ChallengeType challengeType;
        private int currentRound;
        private int maxRounds;
        private UUID duelPlayer1, duelPlayer2;
        private final Map<UUID, Integer> roundWins = new HashMap<>();
        private UUID kothHolder;
        private int kothHoldTime;
        private final Map<UUID, Integer> parkourProgress = new HashMap<>(); // checkpoint index
        private int gameTimer; // seconds remaining
        private final Map<UUID, Integer> teamAssignment = new HashMap<>(); // 0 or 1
        private final Map<Integer, Set<UUID>> teams = new HashMap<>();

        public enum GamePhase { COUNTDOWN, ACTIVE, ROUND_END, ENDING }

        public PartyGameSession(UUID partyId, GameType type, GameArena arena, Set<UUID> participants) {
            this.sessionId = UUID.randomUUID();
            this.partyId = partyId;
            this.type = type;
            this.arena = arena;
            this.participants = new LinkedHashSet<>(participants);
            this.alive = new LinkedHashSet<>(participants);
            this.previousLocations = new HashMap<>();
            this.kills = new ConcurrentHashMap<>();
            this.deaths = new ConcurrentHashMap<>();
            this.startTime = System.currentTimeMillis();
            this.phase = GamePhase.COUNTDOWN;
            this.countdown = 5;
            this.currentRound = 1;
            this.maxRounds = 3;
            this.gameTimer = 300; // 5 min default
        }

        // Getters
        public UUID getSessionId() { return sessionId; }
        public UUID getPartyId() { return partyId; }
        public GameType getType() { return type; }
        public GameArena getArena() { return arena; }
        public Set<UUID> getParticipants() { return participants; }
        public Set<UUID> getAlive() { return alive; }
        public Map<UUID, Location> getPreviousLocations() { return previousLocations; }
        public Map<UUID, Integer> getKills() { return kills; }
        public Map<UUID, Integer> getDeaths() { return deaths; }
        public long getStartTime() { return startTime; }
        public GamePhase getPhase() { return phase; }
        public void setPhase(GamePhase phase) { this.phase = phase; }
        public BukkitTask getGameTask() { return gameTask; }
        public void setGameTask(BukkitTask task) { this.gameTask = task; }
        public int getCountdown() { return countdown; }
        public void setCountdown(int c) { this.countdown = c; }
        public ChallengeType getChallengeType() { return challengeType; }
        public void setChallengeType(ChallengeType ct) { this.challengeType = ct; }
        public int getCurrentRound() { return currentRound; }
        public void setCurrentRound(int r) { this.currentRound = r; }
        public int getMaxRounds() { return maxRounds; }
        public Map<UUID, Integer> getRoundWins() { return roundWins; }
        public UUID getDuelPlayer1() { return duelPlayer1; }
        public UUID getDuelPlayer2() { return duelPlayer2; }
        public void setDuelPlayer1(UUID u) { this.duelPlayer1 = u; }
        public void setDuelPlayer2(UUID u) { this.duelPlayer2 = u; }
        public UUID getKothHolder() { return kothHolder; }
        public void setKothHolder(UUID u) { this.kothHolder = u; }
        public int getKothHoldTime() { return kothHoldTime; }
        public void setKothHoldTime(int t) { this.kothHoldTime = t; }
        public Map<UUID, Integer> getParkourProgress() { return parkourProgress; }
        public int getGameTimer() { return gameTimer; }
        public void setGameTimer(int t) { this.gameTimer = t; }
        public Map<UUID, Integer> getTeamAssignment() { return teamAssignment; }
        public Map<Integer, Set<UUID>> getTeams() { return teams; }
    }

    // ═══════════════════════════════════════
    // Constructor / Config
    // ═══════════════════════════════════════

    public PartyGamesManager(EthernovaParty plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
        loadArenas();
    }

    private void loadArenas() {
        var config = plugin.getConfig();
        var section = config.getConfigurationSection("party-games.arenas");
        if (section == null) return;

        for (String arenaId : section.getKeys(false)) {
            var as = section.getConfigurationSection(arenaId);
            if (as == null) continue;
            try {
                GameType type = GameType.valueOf(as.getString("type", "PARTY_FFA").toUpperCase());
                String name = as.getString("name", arenaId);
                Location spawn1 = parseLocation(as.getString("spawn1"));
                Location spawn2 = parseLocation(as.getString("spawn2"));
                Location specSpawn = parseLocation(as.getString("spectator-spawn"));
                Location kothMin = parseLocation(as.getString("koth-zone-min"));
                Location kothMax = parseLocation(as.getString("koth-zone-max"));

                List<Location> checkpoints = new ArrayList<>();
                var cpSection = as.getStringList("parkour-checkpoints");
                for (String cp : cpSection) {
                    Location loc = parseLocation(cp);
                    if (loc != null) checkpoints.add(loc);
                }

                GameArena arena = new GameArena(arenaId, name, type, spawn1, spawn2, specSpawn,
                        kothMin, kothMax, checkpoints, true);
                arenas.computeIfAbsent(type, t -> new ArrayList<>()).add(arena);
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Error loading party game arena: " + arenaId, e);
            }
        }
        plugin.getLogger().info("Cargadas " + arenas.values().stream().mapToInt(List::size).sum() + " arenas de party games");
    }

    // ═══════════════════════════════════════
    // Start Game
    // ═══════════════════════════════════════

    public boolean startGame(Player leader, GameType type) {
        UUID leaderUuid = leader.getUniqueId();
        PartyManager pm = plugin.getPartyManager();
        var party = pm.getParty(leaderUuid);

        if (party == null) {
            leader.sendMessage(mini.deserialize("<red>No estás en un party."));
            return false;
        }
        if (!party.getLeaderUuid().equals(leaderUuid)) {
            leader.sendMessage(mini.deserialize("<red>Solo el líder del party puede iniciar juegos."));
            return false;
        }
        if (activeSessions.containsKey(party.getPartyId())) {
            leader.sendMessage(mini.deserialize("<red>Tu party ya tiene un juego activo."));
            return false;
        }

        List<GameArena> available = arenas.getOrDefault(type, Collections.emptyList())
                .stream().filter(GameArena::available).toList();
        if (available.isEmpty()) {
            leader.sendMessage(mini.deserialize("<red>No hay arenas disponibles para " + type.getDisplayName()));
            return false;
        }

        Set<UUID> members = party.getMembers();
        if (members.size() < type.getMinPlayers()) {
            leader.sendMessage(mini.deserialize("<red>Se necesitan al menos " +
                    type.getMinPlayers() + " jugadores para " + type.getDisplayName()));
            return false;
        }

        // Combat tag check — no member can be in combat
        CombatAPI combatAPI = ServiceRegistry.get(CombatAPI.class);
        if (combatAPI != null) {
            for (UUID uuid : members) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null && combatAPI.isInCombat(p)) {
                    leader.sendMessage(mini.deserialize("<red>" + p.getName() + " está en combate. Espera a que termine."));
                    return false;
                }
            }
        }

        GameArena arena = available.getFirst();
        PartyGameSession session = new PartyGameSession(party.getPartyId(), type, arena, members);

        // Configure based on type
        configureSession(session, type);

        // Save previous locations and teleport
        for (UUID uuid : members) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline()) {
                session.getPreviousLocations().put(uuid, p.getLocation().clone());
                p.sendMessage(mini.deserialize("<gold>⚔ <yellow>¡" + type.getDisplayName() + " iniciado! Preparándose..."));
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 0.7f, 1.5f);
            }
        }

        // Teleport based on game type
        teleportForGameStart(session);

        // Start countdown
        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> tickSession(session), 20L, 20L);
        session.setGameTask(task);
        activeSessions.put(party.getPartyId(), session);

        return true;
    }

    private void configureSession(PartyGameSession session, GameType type) {
        switch (type) {
            case DUELS -> {
                session.setGameTimer(120); // 2 min per round
                session.setCurrentRound(1);
                // Select first two players
                List<UUID> playerList = new ArrayList<>(session.getParticipants());
                if (playerList.size() >= 2) {
                    session.setDuelPlayer1(playerList.get(0));
                    session.setDuelPlayer2(playerList.get(1));
                }
            }
            case PARTY_FFA -> session.setGameTimer(300); // 5 min
            case KOTH -> {
                session.setGameTimer(300);
                session.setKothHoldTime(0);
            }
            case SUMO -> {
                session.setGameTimer(60); // 1 min per round
                session.setCurrentRound(1);
                List<UUID> playerList = new ArrayList<>(session.getParticipants());
                if (playerList.size() >= 2) {
                    session.setDuelPlayer1(playerList.get(0));
                    session.setDuelPlayer2(playerList.get(1));
                }
            }
            case PARKOUR -> {
                session.setGameTimer(180); // 3 min
                for (UUID uuid : session.getParticipants()) {
                    session.getParkourProgress().put(uuid, 0);
                }
            }
            case CHALLENGE -> {
                ChallengeType[] types = ChallengeType.values();
                session.setChallengeType(types[ThreadLocalRandom.current().nextInt(types.length)]);
                session.setGameTimer(180);
            }
            case PARTY_WARS -> {
                session.setGameTimer(300);
                // Divide players into 2 teams
                List<UUID> playerList = new ArrayList<>(session.getParticipants());
                Collections.shuffle(playerList);
                Set<UUID> team0 = new LinkedHashSet<>();
                Set<UUID> team1 = new LinkedHashSet<>();
                for (int i = 0; i < playerList.size(); i++) {
                    if (i % 2 == 0) {
                        team0.add(playerList.get(i));
                        session.getTeamAssignment().put(playerList.get(i), 0);
                    } else {
                        team1.add(playerList.get(i));
                        session.getTeamAssignment().put(playerList.get(i), 1);
                    }
                }
                session.getTeams().put(0, team0);
                session.getTeams().put(1, team1);
            }
        }
    }

    private void teleportForGameStart(PartyGameSession session) {
        GameArena arena = session.getArena();

        switch (session.getType()) {
            case DUELS, SUMO -> {
                // Only teleport the two active duelists
                UUID p1 = session.getDuelPlayer1();
                UUID p2 = session.getDuelPlayer2();
                teleportPlayer(p1, arena.spawn1());
                teleportPlayer(p2, arena.spawn2());
                // Others spectate
                for (UUID uuid : session.getParticipants()) {
                    if (!uuid.equals(p1) && !uuid.equals(p2)) {
                        teleportPlayer(uuid, arena.spectatorSpawn() != null ? arena.spectatorSpawn() : arena.spawn1());
                    }
                }
            }
            case PARTY_WARS -> {
                // Team 0 to spawn1, team 1 to spawn2
                Set<UUID> team0 = session.getTeams().getOrDefault(0, Collections.emptySet());
                Set<UUID> team1 = session.getTeams().getOrDefault(1, Collections.emptySet());
                for (UUID uuid : team0) teleportPlayer(uuid, arena.spawn1());
                for (UUID uuid : team1) teleportPlayer(uuid, arena.spawn2());
            }
            default -> {
                // All to spawn1
                for (UUID uuid : session.getParticipants()) {
                    teleportPlayer(uuid, arena.spawn1());
                }
            }
        }
    }

    private void teleportPlayer(UUID uuid, Location loc) {
        if (loc == null) return;
        Player p = Bukkit.getPlayer(uuid);
        if (p != null && p.isOnline()) {
            p.teleport(loc);
        }
    }

    // ═══════════════════════════════════════
    // Session Tick
    // ═══════════════════════════════════════

    private void tickSession(PartyGameSession session) {
        switch (session.getPhase()) {
            case COUNTDOWN -> tickCountdown(session);
            case ACTIVE -> tickActive(session);
            case ROUND_END -> tickRoundEnd(session);
            case ENDING -> {
                if (session.getGameTask() != null) session.getGameTask().cancel();
            }
        }
    }

    private void tickCountdown(PartyGameSession session) {
        int cd = session.getCountdown();
        if (cd > 0) {
            broadcastSession(session, "<yellow>El juego comienza en <gold>" + cd + "<yellow>...");
            for (UUID uuid : session.getParticipants()) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null) p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.5f, 1f);
            }
            session.setCountdown(cd - 1);
        } else {
            session.setPhase(PartyGameSession.GamePhase.ACTIVE);
            broadcastSession(session, "<green>¡" + session.getType().getDisplayName() + " ha comenzado!");

            for (UUID uuid : session.getParticipants()) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null) {
                    p.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.5f, 1.5f);
                    p.showTitle(Title.title(
                            mini.deserialize("<green><bold>¡PELEA!"),
                            mini.deserialize("<gray>" + session.getType().getDisplayName()),
                            Title.Times.times(Duration.ofMillis(200), Duration.ofSeconds(1), Duration.ofMillis(200))
                    ));
                }
            }

            // Equip players based on game type
            equipPlayers(session);

            if (session.getType() == GameType.CHALLENGE && session.getChallengeType() != null) {
                broadcastSession(session, "<gold>⚡ Desafío: <yellow>" + session.getChallengeType().getDisplayName());
                broadcastSession(session, "<gray>" + session.getChallengeType().getDescription());
            }

            if (session.getType() == GameType.PARTY_WARS) {
                broadcastTeamAssignments(session);
            }
        }
    }

    private void tickActive(PartyGameSession session) {
        // Remove disconnected
        session.getAlive().removeIf(uuid -> {
            Player p = Bukkit.getPlayer(uuid);
            return p == null || !p.isOnline();
        });

        // Decrement timer
        session.setGameTimer(session.getGameTimer() - 1);

        // Time warnings
        int t = session.getGameTimer();
        if (t == 60) broadcastSession(session, "<yellow>⏰ Queda 1 minuto!");
        else if (t == 30) broadcastSession(session, "<yellow>⏰ Quedan 30 segundos!");
        else if (t == 10) broadcastSession(session, "<red>⏰ ¡10 segundos!");

        // Check mode-specific conditions
        switch (session.getType()) {
            case DUELS -> tickDuels(session);
            case PARTY_FFA -> tickPartyFFA(session);
            case KOTH -> tickKOTH(session);
            case SUMO -> tickSumo(session);
            case PARKOUR -> tickParkour(session);
            case CHALLENGE -> tickChallenge(session);
            case PARTY_WARS -> tickPartyWars(session);
        }

        // Time limit check
        if (session.getGameTimer() <= 0) {
            handleTimeUp(session);
        }
    }

    private void tickRoundEnd(PartyGameSession session) {
        // Brief pause between rounds, then setup next round
        session.setCountdown(session.getCountdown() - 1);
        if (session.getCountdown() <= 0) {
            session.setCurrentRound(session.getCurrentRound() + 1);
            if (session.getCurrentRound() > session.getMaxRounds()) {
                endSession(session);
            } else {
                setupNextRound(session);
                session.setPhase(PartyGameSession.GamePhase.COUNTDOWN);
                session.setCountdown(3);
            }
        }
    }

    // ═══════════════════════════════════════
    // Game Mode Ticks
    // ═══════════════════════════════════════

    private void tickDuels(PartyGameSession session) {
        // Check if either duelist is dead/gone
        UUID p1 = session.getDuelPlayer1();
        UUID p2 = session.getDuelPlayer2();
        Player player1 = p1 != null ? Bukkit.getPlayer(p1) : null;
        Player player2 = p2 != null ? Bukkit.getPlayer(p2) : null;

        boolean p1alive = player1 != null && player1.isOnline() && session.getAlive().contains(p1);
        boolean p2alive = player2 != null && player2.isOnline() && session.getAlive().contains(p2);

        if (!p1alive && !p2alive) {
            broadcastSession(session, "<gray>Ronda empatada.");
            startRoundEnd(session);
        } else if (!p1alive) {
            String winner = player2 != null ? player2.getName() : "?";
            broadcastSession(session, "<gold>🏆 <yellow>" + winner + " gana la ronda " + session.getCurrentRound() + "!");
            session.getRoundWins().merge(p2, 1, Integer::sum);
            startRoundEnd(session);
        } else if (!p2alive) {
            String winner = player1 != null ? player1.getName() : "?";
            broadcastSession(session, "<gold>🏆 <yellow>" + winner + " gana la ronda " + session.getCurrentRound() + "!");
            session.getRoundWins().merge(p1, 1, Integer::sum);
            startRoundEnd(session);
        }
    }

    private void tickPartyFFA(PartyGameSession session) {
        if (session.getAlive().size() <= 1) {
            endSession(session);
        }
    }

    private void tickKOTH(PartyGameSession session) {
        GameArena arena = session.getArena();
        if (arena.kothZoneMin() == null || arena.kothZoneMax() == null) return;

        // Check who's in the zone
        UUID inZone = null;
        for (UUID uuid : session.getAlive()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && isInZone(p.getLocation(), arena.kothZoneMin(), arena.kothZoneMax())) {
                inZone = uuid;
                break; // First player found in zone holds it
            }
        }

        if (inZone != null) {
            if (inZone.equals(session.getKothHolder())) {
                session.setKothHoldTime(session.getKothHoldTime() + 1);

                // Periodic updates
                if (session.getKothHoldTime() % 5 == 0) {
                    Player holder = Bukkit.getPlayer(inZone);
                    String name = holder != null ? holder.getName() : "?";
                    broadcastSession(session, "<yellow>⛰ " + name + " lleva <gold>" +
                            session.getKothHoldTime() + "/30<yellow> segundos en la colina!");
                }

                // Win condition: 30 seconds
                if (session.getKothHoldTime() >= 30) {
                    Player winner = Bukkit.getPlayer(inZone);
                    String name = winner != null ? winner.getName() : "?";
                    broadcastSession(session, "<gold>🏆 <yellow>" + name + " ¡ha conquistado la colina!");
                    session.getAlive().clear();
                    if (winner != null) session.getAlive().add(winner.getUniqueId());
                    endSession(session);
                }
            } else {
                // New holder
                session.setKothHolder(inZone);
                session.setKothHoldTime(1);
                Player holder = Bukkit.getPlayer(inZone);
                String name = holder != null ? holder.getName() : "?";
                broadcastSession(session, "<aqua>⛰ " + name + " ha tomado la colina!");
            }
        } else {
            if (session.getKothHolder() != null) {
                session.setKothHolder(null);
                session.setKothHoldTime(0);
                broadcastSession(session, "<gray>⛰ La colina está vacía...");
            }
        }
    }

    private void tickSumo(PartyGameSession session) {
        // Same as duels but void detection handled in handleMove
        UUID p1 = session.getDuelPlayer1();
        UUID p2 = session.getDuelPlayer2();
        boolean p1alive = p1 != null && session.getAlive().contains(p1);
        boolean p2alive = p2 != null && session.getAlive().contains(p2);

        if (!p1alive && p2alive) {
            Player winner = Bukkit.getPlayer(p2);
            broadcastSession(session, "<gold>🏆 <yellow>" + (winner != null ? winner.getName() : "?") +
                    " gana la ronda " + session.getCurrentRound() + " de Sumo!");
            session.getRoundWins().merge(p2, 1, Integer::sum);
            startRoundEnd(session);
        } else if (!p2alive && p1alive) {
            Player winner = Bukkit.getPlayer(p1);
            broadcastSession(session, "<gold>🏆 <yellow>" + (winner != null ? winner.getName() : "?") +
                    " gana la ronda " + session.getCurrentRound() + " de Sumo!");
            session.getRoundWins().merge(p1, 1, Integer::sum);
            startRoundEnd(session);
        } else if (!p1alive && !p2alive) {
            broadcastSession(session, "<gray>Ronda empatada.");
            startRoundEnd(session);
        }
    }

    private void tickParkour(PartyGameSession session) {
        // Check if anyone reached the end
        List<Location> checkpoints = session.getArena().parkourCheckpoints();
        if (checkpoints == null || checkpoints.isEmpty()) return;

        for (UUID uuid : session.getAlive()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p == null) continue;

            int currentCP = session.getParkourProgress().getOrDefault(uuid, 0);
            if (currentCP >= checkpoints.size()) continue; // Already finished

            Location nextCP = checkpoints.get(currentCP);
            if (p.getLocation().distanceSquared(nextCP) < 4) { // Within 2 blocks
                session.getParkourProgress().put(uuid, currentCP + 1);
                p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1.5f);

                if (currentCP + 1 >= checkpoints.size()) {
                    // Finished!
                    broadcastSession(session, "<gold>🏆 <yellow>" + p.getName() + " ¡ha completado el parkour!");
                    session.getAlive().clear();
                    session.getAlive().add(uuid);
                    endSession(session);
                    return;
                } else {
                    p.sendMessage(mini.deserialize("<green>✔ Checkpoint " + (currentCP + 1) + "/" + checkpoints.size()));
                }
            }
        }
    }

    private void tickChallenge(PartyGameSession session) {
        ChallengeType ct = session.getChallengeType();
        if (ct == null) return;

        switch (ct) {
            case LAST_STANDING -> {
                if (session.getAlive().size() <= 1) endSession(session);
            }
            case MOST_KILLS -> {
                // Timer-based, handled by time up
            }
            case NO_ARMOR, ONE_HIT, BOW_ONLY, AXE_ONLY -> {
                if (session.getAlive().size() <= 1) endSession(session);
            }
        }
    }

    private void tickPartyWars(PartyGameSession session) {
        // Check if an entire team is eliminated
        for (var entry : session.getTeams().entrySet()) {
            boolean teamAlive = false;
            for (UUID uuid : entry.getValue()) {
                if (session.getAlive().contains(uuid)) {
                    teamAlive = true;
                    break;
                }
            }
            if (!teamAlive) {
                int winningTeam = entry.getKey() == 0 ? 1 : 0;
                broadcastSession(session, "<gold>🏆 <yellow>¡Equipo " + (winningTeam + 1) + " gana la Guerra de Parties!");
                endSession(session);
                return;
            }
        }
    }

    // ═══════════════════════════════════════
    // Round Management
    // ═══════════════════════════════════════

    private void startRoundEnd(PartyGameSession session) {
        session.setPhase(PartyGameSession.GamePhase.ROUND_END);
        session.setCountdown(3); // 3 second pause

        // Check if someone has won enough rounds
        int requiredWins = (session.getMaxRounds() / 2) + 1;
        for (var entry : session.getRoundWins().entrySet()) {
            if (entry.getValue() >= requiredWins) {
                Player winner = Bukkit.getPlayer(entry.getKey());
                String name = winner != null ? winner.getName() : "?";
                broadcastSession(session, "<gold>🏆 <yellow>" + name + " gana el " +
                        session.getType().getDisplayName() + " con " + entry.getValue() + " rondas!");
                session.getAlive().clear();
                if (winner != null) session.getAlive().add(winner.getUniqueId());
                endSession(session);
                return;
            }
        }
    }

    private void setupNextRound(PartyGameSession session) {
        // Reset alive to original duel participants
        session.getAlive().addAll(session.getParticipants());
        session.setGameTimer(session.getType() == GameType.SUMO ? 60 : 120);

        broadcastSession(session, "<yellow>Ronda " + session.getCurrentRound() + "/" + session.getMaxRounds());

        // Re-teleport duelists
        teleportForGameStart(session);

        // Re-equip
        if (session.getDuelPlayer1() != null) {
            Player p1 = Bukkit.getPlayer(session.getDuelPlayer1());
            if (p1 != null) {
                p1.setHealth(p1.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue());
                p1.setFoodLevel(20);
                p1.setSaturation(20f);
            }
        }
        if (session.getDuelPlayer2() != null) {
            Player p2 = Bukkit.getPlayer(session.getDuelPlayer2());
            if (p2 != null) {
                p2.setHealth(p2.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue());
                p2.setFoodLevel(20);
                p2.setSaturation(20f);
            }
        }
    }

    // ═══════════════════════════════════════
    // Equipment
    // ═══════════════════════════════════════

    private void equipPlayers(PartyGameSession session) {
        switch (session.getType()) {
            case DUELS -> {
                equipDuel(session.getDuelPlayer1());
                equipDuel(session.getDuelPlayer2());
            }
            case PARTY_FFA -> {
                for (UUID uuid : session.getParticipants()) equipFFA(uuid);
            }
            case KOTH -> {
                for (UUID uuid : session.getParticipants()) equipFFA(uuid);
            }
            case SUMO -> {
                equipSumo(session.getDuelPlayer1());
                equipSumo(session.getDuelPlayer2());
            }
            case PARKOUR -> {
                // No equipment needed for parkour
            }
            case CHALLENGE -> equipChallenge(session);
            case PARTY_WARS -> equipPartyWars(session);
        }
    }

    private void equipDuel(UUID uuid) {
        Player p = uuid != null ? Bukkit.getPlayer(uuid) : null;
        if (p == null) return;
        p.getInventory().clear();
        p.setHealth(p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue());
        p.setFoodLevel(20);
        p.setSaturation(20f);

        p.getInventory().setItem(0, new ItemStack(Material.DIAMOND_SWORD));
        p.getInventory().setItem(1, new ItemStack(Material.BOW));
        p.getInventory().setItem(2, new ItemStack(Material.GOLDEN_APPLE, 3));
        p.getInventory().setItem(3, new ItemStack(Material.ENDER_PEARL, 2));
        p.getInventory().setItem(8, new ItemStack(Material.ARROW, 16));

        p.getInventory().setHelmet(new ItemStack(Material.IRON_HELMET));
        p.getInventory().setChestplate(new ItemStack(Material.IRON_CHESTPLATE));
        p.getInventory().setLeggings(new ItemStack(Material.IRON_LEGGINGS));
        p.getInventory().setBoots(new ItemStack(Material.IRON_BOOTS));
    }

    private void equipFFA(UUID uuid) {
        Player p = uuid != null ? Bukkit.getPlayer(uuid) : null;
        if (p == null) return;
        p.getInventory().clear();
        p.setHealth(p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue());
        p.setFoodLevel(20);
        p.setSaturation(20f);

        p.getInventory().setItem(0, new ItemStack(Material.IRON_SWORD));
        p.getInventory().setItem(1, new ItemStack(Material.BOW));
        p.getInventory().setItem(2, new ItemStack(Material.GOLDEN_APPLE, 5));
        p.getInventory().setItem(8, new ItemStack(Material.ARROW, 32));

        p.getInventory().setHelmet(new ItemStack(Material.IRON_HELMET));
        p.getInventory().setChestplate(new ItemStack(Material.IRON_CHESTPLATE));
        p.getInventory().setLeggings(new ItemStack(Material.IRON_LEGGINGS));
        p.getInventory().setBoots(new ItemStack(Material.IRON_BOOTS));
    }

    private void equipSumo(UUID uuid) {
        Player p = uuid != null ? Bukkit.getPlayer(uuid) : null;
        if (p == null) return;
        p.getInventory().clear();
        p.setHealth(p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue());
        p.setFoodLevel(20);
        p.setSaturation(20f);
        // No armor, no weapons — pure knockback
        p.getInventory().setItem(0, new ItemStack(Material.STICK));
    }

    private void equipChallenge(PartyGameSession session) {
        ChallengeType ct = session.getChallengeType();
        if (ct == null) return;

        for (UUID uuid : session.getParticipants()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p == null) continue;
            p.getInventory().clear();
            p.setHealth(p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue());
            p.setFoodLevel(20);
            p.setSaturation(20f);

            switch (ct) {
                case LAST_STANDING, MOST_KILLS -> {
                    p.getInventory().setItem(0, new ItemStack(Material.IRON_SWORD));
                    p.getInventory().setItem(1, new ItemStack(Material.GOLDEN_APPLE, 3));
                    p.getInventory().setHelmet(new ItemStack(Material.IRON_HELMET));
                    p.getInventory().setChestplate(new ItemStack(Material.IRON_CHESTPLATE));
                    p.getInventory().setLeggings(new ItemStack(Material.IRON_LEGGINGS));
                    p.getInventory().setBoots(new ItemStack(Material.IRON_BOOTS));
                }
                case NO_ARMOR -> {
                    p.getInventory().setItem(0, new ItemStack(Material.DIAMOND_SWORD));
                    p.getInventory().setItem(1, new ItemStack(Material.GOLDEN_APPLE, 5));
                    // No armor
                }
                case ONE_HIT -> {
                    p.getInventory().setItem(0, new ItemStack(Material.WOODEN_SWORD));
                    // One hit = give wither effect that reduces to 1hp
                    p.setHealth(1);
                }
                case BOW_ONLY -> {
                    p.getInventory().setItem(0, new ItemStack(Material.BOW));
                    p.getInventory().setItem(1, new ItemStack(Material.ARROW, 64));
                    p.getInventory().setHelmet(new ItemStack(Material.LEATHER_HELMET));
                    p.getInventory().setChestplate(new ItemStack(Material.LEATHER_CHESTPLATE));
                    p.getInventory().setLeggings(new ItemStack(Material.LEATHER_LEGGINGS));
                    p.getInventory().setBoots(new ItemStack(Material.LEATHER_BOOTS));
                }
                case AXE_ONLY -> {
                    p.getInventory().setItem(0, new ItemStack(Material.IRON_AXE));
                    p.getInventory().setItem(1, new ItemStack(Material.SHIELD));
                    p.getInventory().setItem(2, new ItemStack(Material.GOLDEN_APPLE, 3));
                    p.getInventory().setHelmet(new ItemStack(Material.CHAINMAIL_HELMET));
                    p.getInventory().setChestplate(new ItemStack(Material.CHAINMAIL_CHESTPLATE));
                    p.getInventory().setLeggings(new ItemStack(Material.CHAINMAIL_LEGGINGS));
                    p.getInventory().setBoots(new ItemStack(Material.CHAINMAIL_BOOTS));
                }
            }
        }
    }

    private void equipPartyWars(PartyGameSession session) {
        Color[] teamColors = { Color.RED, Color.BLUE };

        for (var entry : session.getTeams().entrySet()) {
            int teamId = entry.getKey();
            Color color = teamColors[teamId % teamColors.length];

            for (UUID uuid : entry.getValue()) {
                Player p = Bukkit.getPlayer(uuid);
                if (p == null) continue;
                p.getInventory().clear();
                p.setHealth(p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue());
                p.setFoodLevel(20);
                p.setSaturation(20f);

                p.getInventory().setItem(0, new ItemStack(Material.IRON_SWORD));
                p.getInventory().setItem(1, new ItemStack(Material.BOW));
                p.getInventory().setItem(2, new ItemStack(Material.GOLDEN_APPLE, 3));
                p.getInventory().setItem(8, new ItemStack(Material.ARROW, 32));

                // Colored leather armor for team identification
                p.getInventory().setHelmet(createColoredArmor(Material.LEATHER_HELMET, color));
                p.getInventory().setChestplate(createColoredArmor(Material.LEATHER_CHESTPLATE, color));
                p.getInventory().setLeggings(createColoredArmor(Material.LEATHER_LEGGINGS, color));
                p.getInventory().setBoots(createColoredArmor(Material.LEATHER_BOOTS, color));
            }
        }
    }

    private ItemStack createColoredArmor(Material material, Color color) {
        ItemStack item = new ItemStack(material);
        LeatherArmorMeta meta = (LeatherArmorMeta) item.getItemMeta();
        meta.setColor(color);
        item.setItemMeta(meta);
        return item;
    }

    private void broadcastTeamAssignments(PartyGameSession session) {
        broadcastSession(session, "<red>═══ Equipo Rojo ═══");
        Set<UUID> team0 = session.getTeams().getOrDefault(0, Collections.emptySet());
        for (UUID uuid : team0) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) broadcastSession(session, "<red>  • " + p.getName());
        }
        broadcastSession(session, "<blue>═══ Equipo Azul ═══");
        Set<UUID> team1 = session.getTeams().getOrDefault(1, Collections.emptySet());
        for (UUID uuid : team1) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) broadcastSession(session, "<blue>  • " + p.getName());
        }
    }

    // ═══════════════════════════════════════
    // Time Up / End Session
    // ═══════════════════════════════════════

    private void handleTimeUp(PartyGameSession session) {
        broadcastSession(session, "<red>⏰ ¡Tiempo agotado!");

        switch (session.getType()) {
            case CHALLENGE -> {
                if (session.getChallengeType() == ChallengeType.MOST_KILLS) {
                    // Winner is the one with most kills
                    UUID topKiller = session.getKills().entrySet().stream()
                            .max(Map.Entry.comparingByValue())
                            .map(Map.Entry::getKey).orElse(null);
                    if (topKiller != null) {
                        session.getAlive().clear();
                        session.getAlive().add(topKiller);
                    }
                }
            }
            case KOTH -> {
                // Winner is whoever held the hill longest (current holder if any)
                if (session.getKothHolder() != null) {
                    session.getAlive().clear();
                    session.getAlive().add(session.getKothHolder());
                }
            }
            default -> {} // Standard elimination applies
        }

        endSession(session);
    }

    public boolean stopGame(Player player) {
        PartyGameSession session = getPlayerSession(player.getUniqueId());
        if (session == null) {
            player.sendMessage(mini.deserialize("<red>No estás en ningún juego activo."));
            return false;
        }
        broadcastSession(session, "<red>⚠ El juego ha sido detenido.");
        endSession(session);
        return true;
    }

    public void endSession(PartyGameSession session) {
        if (session.getPhase() == PartyGameSession.GamePhase.ENDING) return;
        session.setPhase(PartyGameSession.GamePhase.ENDING);

        if (session.getGameTask() != null) {
            session.getGameTask().cancel();
        }

        // Announce winner
        if (!session.getAlive().isEmpty()) {
            UUID winnerId = session.getAlive().iterator().next();
            Player winner = Bukkit.getPlayer(winnerId);
            String winnerName = winner != null ? winner.getName() : "Desconocido";
            broadcastSession(session, "<gold>🏆 <yellow>¡" + winnerName +
                    " ha ganado " + session.getType().getDisplayName() + "!");

            if (winner != null) {
                winner.playSound(winner.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.8f, 1f);
                core.getProfileManager().addCoins(winnerId, 100);

                winner.showTitle(Title.title(
                        mini.deserialize("<gold><bold>🏆 ¡VICTORIA!"),
                        mini.deserialize("<yellow>" + session.getType().getDisplayName()),
                        Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(3), Duration.ofMillis(300))
                ));
            }
        }

        // Show kills/deaths summary
        if (!session.getKills().isEmpty()) {
            broadcastSession(session, "<gray>═══ Resumen ═══");
            session.getKills().entrySet().stream()
                    .sorted(Map.Entry.<UUID, Integer>comparingByValue().reversed())
                    .limit(5)
                    .forEach(entry -> {
                        Player p = Bukkit.getPlayer(entry.getKey());
                        String name = p != null ? p.getName() : "?";
                        int deaths = session.getDeaths().getOrDefault(entry.getKey(), 0);
                        broadcastSession(session, "<yellow>" + name + ": <green>" + entry.getValue() +
                                " kills <gray>/ <red>" + deaths + " deaths");
                    });
        }

        // Cleanup players and teleport back after 3 seconds
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            for (UUID uuid : session.getParticipants()) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null && p.isOnline()) {
                    p.getInventory().clear();
                    p.removePotionEffect(PotionEffectType.SPEED);
                    p.removePotionEffect(PotionEffectType.STRENGTH);
                    p.removePotionEffect(PotionEffectType.REGENERATION);
                    p.removePotionEffect(PotionEffectType.RESISTANCE);
                    p.removePotionEffect(PotionEffectType.GLOWING);
                    p.setHealth(p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue());
                    p.setFoodLevel(20);

                    Location prev = session.getPreviousLocations().get(uuid);
                    if (prev != null) p.teleport(prev);
                }
            }
            activeSessions.remove(session.getPartyId());
        }, 60L);
    }

    // ═══════════════════════════════════════
    // Event Handlers (called from listeners)
    // ═══════════════════════════════════════

    /**
     * Handle a player death in a party game.
     */
    public void handleDeath(UUID victimUuid, UUID killerUuid) {
        for (PartyGameSession session : activeSessions.values()) {
            if (!session.getParticipants().contains(victimUuid)) continue;
            if (session.getPhase() != PartyGameSession.GamePhase.ACTIVE) continue;

            // Track stats
            session.getDeaths().merge(victimUuid, 1, Integer::sum);
            if (killerUuid != null) {
                session.getKills().merge(killerUuid, 1, Integer::sum);
            }

            // Auto-respawn victim immediately
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                Player victim = Bukkit.getPlayer(victimUuid);
                if (victim != null && victim.isDead()) {
                    victim.spigot().respawn();
                }
            }, 1L);

            switch (session.getType()) {
                case PARTY_FFA -> {
                    // Respawn in FFA (don't remove from alive)
                    Bukkit.getScheduler().runTaskLater(plugin, () -> {
                        Player victim = Bukkit.getPlayer(victimUuid);
                        if (victim != null && victim.isOnline()) {
                            victim.teleport(session.getArena().spawn1());
                            victim.setHealth(victim.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue());
                            victim.setFoodLevel(20);
                            equipFFA(victimUuid);
                            victim.sendMessage(mini.deserialize("<yellow>¡Respawneado!"));
                        }
                    }, 20L);
                }
                case CHALLENGE -> {
                    if (session.getChallengeType() == ChallengeType.MOST_KILLS) {
                        // Respawn in most_kills mode
                        Bukkit.getScheduler().runTaskLater(plugin, () -> {
                            Player victim = Bukkit.getPlayer(victimUuid);
                            if (victim != null && victim.isOnline()) {
                                victim.teleport(session.getArena().spawn1());
                                victim.setHealth(victim.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue());
                                equipChallenge(session);
                            }
                        }, 20L);
                    } else {
                        handleElimination(victimUuid, session);
                    }
                }
                default -> handleElimination(victimUuid, session);
            }
            break;
        }
    }

    private void handleElimination(UUID uuid, PartyGameSession session) {
        session.getAlive().remove(uuid);
        Player p = Bukkit.getPlayer(uuid);
        if (p != null) {
            p.sendMessage(mini.deserialize("<red>¡Has sido eliminado!"));
            if (session.getArena().spectatorSpawn() != null) {
                p.teleport(session.getArena().spectatorSpawn());
            }
            p.getInventory().clear();
        }
        int remaining = session.getAlive().size();
        broadcastSession(session, "<gray>" + (p != null ? p.getName() : "?") +
                " ha sido eliminado. Quedan " + remaining + " jugadores.");
    }

    /**
     * Handle player move (for sumo void detection, parkour checkpoints).
     */
    public void handleMove(Player player) {
        UUID uuid = player.getUniqueId();
        PartyGameSession session = getPlayerSession(uuid);
        if (session == null || session.getPhase() != PartyGameSession.GamePhase.ACTIVE) return;

        if (session.getType() == GameType.SUMO) {
            // Void detection: if player falls below Y=0 or into water
            if (player.getLocation().getY() < 0 || player.getLocation().getBlock().getType() == Material.WATER) {
                session.getAlive().remove(uuid);
                player.sendMessage(mini.deserialize("<red>¡Has caído!"));
                if (session.getArena().spectatorSpawn() != null) {
                    player.teleport(session.getArena().spectatorSpawn());
                } else {
                    player.teleport(session.getArena().spawn1());
                }
            }
        }

        // Parkour checkpoint detection is handled in tickParkour
    }

    /**
     * Handle player quit during a game.
     */
    public void handleQuit(UUID uuid) {
        for (PartyGameSession session : activeSessions.values()) {
            if (session.getParticipants().contains(uuid)) {
                session.getAlive().remove(uuid);
                Player p = Bukkit.getPlayer(uuid);
                broadcastSession(session, "<gray>" + (p != null ? p.getName() : "?") + " ha abandonado el juego.");
                break;
            }
        }
    }

    /**
     * Check if damage should be cancelled (friendly fire in team modes).
     */
    public boolean shouldCancelDamage(UUID attacker, UUID victim) {
        PartyGameSession session = getPlayerSession(attacker);
        if (session == null) return false;

        if (session.getType() == GameType.PARTY_WARS) {
            Integer attackerTeam = session.getTeamAssignment().get(attacker);
            Integer victimTeam = session.getTeamAssignment().get(victim);
            return attackerTeam != null && attackerTeam.equals(victimTeam); // Same team = cancel
        }

        if (session.getType() == GameType.PARKOUR) {
            return true; // No PvP in parkour
        }

        if (session.getType() == GameType.SUMO) {
            // Allow knockback but no damage
            return false; // Let the listener handle damage reduction
        }

        return false;
    }

    // ═══════════════════════════════════════
    // Utility Methods
    // ═══════════════════════════════════════

    public boolean isInGame(UUID uuid) {
        return activeSessions.values().stream()
                .anyMatch(s -> s.getParticipants().contains(uuid));
    }

    public PartyGameSession getPlayerSession(UUID uuid) {
        return activeSessions.values().stream()
                .filter(s -> s.getParticipants().contains(uuid))
                .findFirst().orElse(null);
    }

    private void broadcastSession(PartyGameSession session, String message) {
        var comp = mini.deserialize(message);
        for (UUID uuid : session.getParticipants()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline()) {
                p.sendMessage(comp);
            }
        }
    }

    private boolean isInZone(Location loc, Location min, Location max) {
        if (loc == null || min == null || max == null) return false;
        if (!Objects.equals(loc.getWorld(), min.getWorld())) return false;

        double x1 = Math.min(min.getX(), max.getX());
        double x2 = Math.max(min.getX(), max.getX());
        double y1 = Math.min(min.getY(), max.getY());
        double y2 = Math.max(min.getY(), max.getY());
        double z1 = Math.min(min.getZ(), max.getZ());
        double z2 = Math.max(min.getZ(), max.getZ());

        return loc.getX() >= x1 && loc.getX() <= x2
                && loc.getY() >= y1 && loc.getY() <= y2
                && loc.getZ() >= z1 && loc.getZ() <= z2;
    }

    public void cleanup() {
        for (PartyGameSession session : activeSessions.values()) {
            if (session.getGameTask() != null) session.getGameTask().cancel();
            for (var entry : session.getPreviousLocations().entrySet()) {
                Player p = Bukkit.getPlayer(entry.getKey());
                if (p != null && p.isOnline()) {
                    p.teleport(entry.getValue());
                    p.getInventory().clear();
                }
            }
        }
        activeSessions.clear();
    }

    public Map<GameType, List<GameArena>> getArenas() { return Collections.unmodifiableMap(arenas); }
    public Collection<PartyGameSession> getActiveSessions() { return Collections.unmodifiableCollection(activeSessions.values()); }

    private Location parseLocation(String str) {
        if (str == null || str.isEmpty()) return null;
        try {
            String[] parts = str.split(",");
            return new Location(
                    Bukkit.getWorld(parts[0].trim()),
                    Double.parseDouble(parts[1].trim()),
                    Double.parseDouble(parts[2].trim()),
                    Double.parseDouble(parts[3].trim()),
                    parts.length > 4 ? Float.parseFloat(parts[4].trim()) : 0,
                    parts.length > 5 ? Float.parseFloat(parts[5].trim()) : 0
            );
        } catch (Exception e) {
            return null;
        }
    }
}
