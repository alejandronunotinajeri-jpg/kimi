package com.ethernova.party.event;

import java.util.Set;
import java.util.UUID;

/**
 * Published to EventBus when a party is disbanded.
 */
public record PartyDisbandEvent(UUID partyId, UUID leaderUuid, Set<UUID> members) {}
