package com.ethernova.party.event;

import java.util.UUID;

/**
 * Published to EventBus when a new party is created.
 */
public record PartyCreateEvent(UUID partyId, UUID leaderUuid) {}
