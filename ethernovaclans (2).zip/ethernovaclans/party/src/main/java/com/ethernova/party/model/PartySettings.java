package com.ethernova.party.model;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * Configurable per-party settings. Persisted as JSON in the database.
 */
public class PartySettings {

    private static final Gson GSON = new GsonBuilder().create();

    private boolean friendlyFire = false;
    private boolean autoAcceptFriends = false;
    private boolean isPublic = false;
    private int maxSize = 5;
    private boolean allowModeratorInvite = true;
    private boolean partyChat = true;

    // ═══════════════ Getters & Setters ═══════════════

    public boolean isFriendlyFire() { return friendlyFire; }
    public void setFriendlyFire(boolean friendlyFire) { this.friendlyFire = friendlyFire; }

    public boolean isAutoAcceptFriends() { return autoAcceptFriends; }
    public void setAutoAcceptFriends(boolean autoAcceptFriends) { this.autoAcceptFriends = autoAcceptFriends; }

    public boolean isPublic() { return isPublic; }
    public void setPublic(boolean isPublic) { this.isPublic = isPublic; }

    public int getMaxSize() { return maxSize; }
    public void setMaxSize(int maxSize) { this.maxSize = maxSize; }

    public boolean isAllowModeratorInvite() { return allowModeratorInvite; }
    public void setAllowModeratorInvite(boolean allowModeratorInvite) { this.allowModeratorInvite = allowModeratorInvite; }

    public boolean isPartyChat() { return partyChat; }
    public void setPartyChat(boolean partyChat) { this.partyChat = partyChat; }

    // ═══════════════ Serialization ═══════════════

    public String toJson() {
        return GSON.toJson(this);
    }

    public static PartySettings fromJson(String json) {
        if (json == null || json.isEmpty()) return new PartySettings();
        try {
            return GSON.fromJson(json, PartySettings.class);
        } catch (Exception e) {
            return new PartySettings();
        }
    }
}
