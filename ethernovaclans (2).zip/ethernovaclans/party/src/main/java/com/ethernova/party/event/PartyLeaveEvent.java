package com.ethernova.party.event;

import java.util.UUID;

/**
 * Published to EventBus when a player leaves a party.
 */
public record PartyLeaveEvent(UUID partyId, UUID playerUuid, LeaveReason reason) {

    public enum LeaveReason {
        LEFT,
        KICKED,
        DISBANDED,
        DISCONNECTED
    }
}
