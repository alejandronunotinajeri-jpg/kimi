package com.ethernova.party.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.CoreGui;
import com.ethernova.party.EthernovaParty;
import com.ethernova.party.model.Party;
import com.ethernova.party.model.PartyRole;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Party management GUI for the current party.
 * Shows members with role icons, party settings, buff info, and action buttons.
 * Extends CoreGui (not paginated, party sizes are small).
 */
public class PartyGui extends CoreGui {

    private final Party party;
    private final EthernovaParty partyPlugin;

    public PartyGui(EthernovaCore core, Player player, Party party, EthernovaParty partyPlugin) {
        super(core, player);
        this.party = party;
        this.partyPlugin = partyPlugin;
    }

    /**
     * Open the party management GUI.
     */
    public void open() {
        String title = party.getName() != null
                ? "<gradient:#00d4ff:#00ff88>⚔ " + party.getName() + "</gradient>"
                : "<gradient:#00d4ff:#00ff88>⚔ Grupo de " + getLeaderName() + "</gradient>";
        openInventory(title, 54);
    }

    @Override
    protected void populateItems() {
        boolean isLeader = party.isLeader(player.getUniqueId());
        PartyRole myRole = party.getRole(player.getUniqueId());
        boolean canManage = myRole != null && (myRole == PartyRole.LEADER || myRole == PartyRole.MODERATOR);

        // ═══════════ Party Info (top center) ═══════════
        List<String> infoLore = new ArrayList<>();
        infoLore.add("");
        infoLore.add("<gray>Líder: <white>" + getLeaderName() + "</white>");
        infoLore.add("<gray>Miembros: <white>" + party.getSize() + "/" + party.getMaxSize() + "</white>");
        infoLore.add("<gray>Público: " + (party.isPublic() ? "<green>Sí" : "<red>No"));
        infoLore.add("<gray>Fuego Amigo: " + (party.isFriendlyFireEnabled() ? "<red>Activado" : "<green>Desactivado"));

        // Show buff info
        if (partyPlugin.getBuffManager() != null) {
            long onlineCount = party.getMembers().stream()
                    .filter(u -> { Player p = Bukkit.getPlayer(u); return p != null && p.isOnline(); })
                    .count();
            double xpMult = partyPlugin.getBuffManager().getXPMultiplier(player.getUniqueId());
            if (xpMult > 1.0) {
                infoLore.add("<gray>Buff XP: <green>+" + Math.round((xpMult - 1.0) * 100) + "%");
            }
            if (onlineCount >= partyPlugin.getConfig().getInt("buffs.speed-threshold", 3)) {
                infoLore.add("<gray>Buff Speed: <aqua>Activo");
            }
            if (onlineCount >= partyPlugin.getConfig().getInt("buffs.regen-threshold", 5)) {
                infoLore.add("<gray>Buff Regen: <light_purple>Activo");
            }
        }
        infoLore.add("");

        setItem(4, createItem(Material.NETHER_STAR,
                "<gradient:#00d4ff:#00ff88>⚔ Información del Grupo</gradient>", infoLore));

        // ═══════════ Member Heads (center area, two rows) ═══════════
        int[] memberSlots = {19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};
        int slotIdx = 0;
        for (UUID memberUuid : party.getMembers()) {
            if (slotIdx >= memberSlots.length) break;

            Player memberPlayer = Bukkit.getPlayer(memberUuid);
            boolean online = memberPlayer != null && memberPlayer.isOnline();
            String memberName = getPlayerName(memberUuid);
            PartyRole role = party.getRole(memberUuid);
            if (role == null) role = PartyRole.MEMBER;

            // Create player head
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta skullMeta = (SkullMeta) head.getItemMeta();
            if (skullMeta != null) {
                skullMeta.setOwningPlayer(Bukkit.getOfflinePlayer(memberUuid));
                String displayColor = online ? "<green>" : "<gray>";
                String statusDot = online ? " <green>●" : " <red>●";
                String roleIcon = " " + role.getIcon();

                skullMeta.displayName(mini.deserialize(displayColor + memberName + statusDot + roleIcon));

                List<String> loreLines = new ArrayList<>();
                loreLines.add("");
                loreLines.add("<gray>Estado: " + (online ? "<green>En línea" : "<red>Desconectado"));
                loreLines.add("<gray>Rol: " + role.getIcon() + " " + role.getDisplayName());
                loreLines.add("");

                // Action hints based on viewer's role
                if (isLeader && role != PartyRole.LEADER) {
                    if (role == PartyRole.MEMBER) {
                        loreLines.add("<yellow>▶ Click izquierdo: Promover a Moderador");
                        loreLines.add("<gold>▶ Shift+Click: Promover a Líder");
                    } else if (role == PartyRole.MODERATOR) {
                        loreLines.add("<yellow>▶ Click izquierdo: Degradar a Miembro");
                        loreLines.add("<gold>▶ Shift+Click: Promover a Líder");
                    }
                    loreLines.add("<red>▶ Click derecho: Expulsar del grupo");
                } else if (myRole == PartyRole.MODERATOR && role == PartyRole.MEMBER) {
                    loreLines.add("<red>▶ Click derecho: Expulsar del grupo");
                }

                skullMeta.lore(loreLines.stream()
                        .map(l -> mini.deserialize(replacePlaceholders(l)))
                        .toList());
                head.setItemMeta(skullMeta);
            }

            setItem(memberSlots[slotIdx], head);
            // Leaders can act on non-leaders, mods can act on members
            if (isLeader && role != PartyRole.LEADER) {
                slotActions.put(memberSlots[slotIdx], "MEMBER_" + memberUuid + "_" + role.name());
            } else if (myRole == PartyRole.MODERATOR && role == PartyRole.MEMBER) {
                slotActions.put(memberSlots[slotIdx], "MEMBER_" + memberUuid + "_" + role.name());
            }
            slotIdx++;
        }

        // ═══════════ Action Buttons (bottom row) ═══════════

        // Invite button (slot 37) - leader or mod with invite perms
        if (canManage && !party.isFull()) {
            setItem(37, createItem(Material.WRITABLE_BOOK,
                    "<green>✉ Invitar Jugador",
                    List.of("", "<gray>Usa <yellow>/party invite <jugador></yellow>", "<gray>para invitar a alguien.", "")));
            slotActions.put(37, "INVITE_HINT");
        }

        // Chat toggle (slot 38)
        boolean chatEnabled = partyPlugin.getPartyChat().isChatEnabled(player.getUniqueId());
        setItem(38, createItem(chatEnabled ? Material.LIME_DYE : Material.GRAY_DYE,
                chatEnabled ? "<green>✎ Chat de Grupo: Activado" : "<gray>✎ Chat de Grupo: Desactivado",
                List.of("", "<gray>Click para " + (chatEnabled ? "desactivar" : "activar"), "")));
        slotActions.put(38, "TOGGLE_CHAT");

        // Settings button (slot 39) - only if leader
        if (isLeader) {
            setItem(39, createItem(Material.COMPARATOR,
                    "<gold>⚙ Configuración del Grupo",
                    List.of("", "<gray>Fuego Amigo, Público/Privado,",
                            "<gray>Tamaño máximo, y más.", "")));
            slotActions.put(39, "SETTINGS");
        }

        // Ready Check (slot 40)
        if (canManage) {
            setItem(40, createItem(Material.BELL,
                    "<yellow>✔ Ready Check",
                    List.of("", "<gray>Iniciar un conteo de listos", "<gray>para todos los miembros.", "")));
            slotActions.put(40, "READY_CHECK");
        }

        // Teleport (slot 41) - leader or mod with tp perms
        if (canManage) {
            setItem(41, createItem(Material.ENDER_PEARL,
                    "<aqua>⚡ Teleportar Grupo",
                    List.of("", "<gray>Teleporta a todos los miembros", "<gray>a tu ubicación actual.", "")));
            slotActions.put(41, "TELEPORT");
        }

        // Party List (slot 42)
        setItem(42, createItem(Material.BOOK,
                "<yellow>📋 Grupos Públicos",
                List.of("", "<gray>Ver todos los grupos públicos.", "")));
        slotActions.put(42, "PARTY_LIST");

        // Leave / Disband (slot 43)
        if (isLeader) {
            setItem(43, createItem(Material.TNT,
                    "<red>✘ Disolver Grupo",
                    List.of("", "<red>¡Esto eliminará el grupo!", "")));
            slotActions.put(43, "DISBAND");
        } else {
            setItem(43, createItem(Material.BARRIER,
                    "<red>✘ Abandonar Grupo",
                    List.of("", "<gray>Salir del grupo actual.", "")));
            slotActions.put(43, "LEAVE");
        }

        // Back button (slot 45)
        setItem(45, createItem(Material.ARROW, "<red>← Volver", 
                List.of("<gray>Regresa al menú anterior")));
        slotActions.put(45, "BACK");

        // Close button (slot 49)
        setItem(49, createItem(Material.BARRIER, "<red>Cerrar"));
        slotActions.put(49, "CLOSE");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        if (action.startsWith("MEMBER_")) {
            // Format: MEMBER_<uuid>_<ROLE>
            String data = action.substring(7);
            int lastUnderscore = data.lastIndexOf('_');
            if (lastUnderscore == -1) return true;

            String uuidStr = data.substring(0, lastUnderscore);
            String roleName = data.substring(lastUnderscore + 1);

            try {
                UUID targetUuid = UUID.fromString(uuidStr);
                PartyRole targetRole = PartyRole.valueOf(roleName);
                boolean isLeader = party.isLeader(player.getUniqueId());

                if (event.isLeftClick() && isLeader) {
                    if (event.isShiftClick()) {
                        // Shift+Click: Promote to Leader
                        player.closeInventory();
                        partyPlugin.getPartyManager().promoteLeader(player, targetUuid);
                    } else {
                        // Left Click: Mod ↔ Member toggle
                        player.closeInventory();
                        if (targetRole == PartyRole.MEMBER) {
                            partyPlugin.getPartyManager().setModerator(player, targetUuid);
                        } else if (targetRole == PartyRole.MODERATOR) {
                            partyPlugin.getPartyManager().demoteMember(player, targetUuid);
                        }
                    }
                } else if (event.isRightClick()) {
                    // Right Click: Kick
                    player.closeInventory();
                    partyPlugin.getPartyManager().kickPlayer(player, targetUuid);
                }
            } catch (IllegalArgumentException ignored) {}
            return true;
        }

        return switch (action) {
            case "INVITE_HINT" -> {
                playSound("click");
                player.closeInventory();
                player.sendMessage(mini.deserialize(
                        getPrefix() + "<yellow>Usa <white>/party invite <jugador></white> para invitar a alguien."));
                yield true;
            }
            case "TOGGLE_CHAT" -> {
                playSound("click");
                boolean enabled = partyPlugin.getPartyChat().toggle(player.getUniqueId());
                if (enabled) {
                    player.sendMessage(mini.deserialize(getPrefix() + getMessage("chat-enabled")));
                } else {
                    player.sendMessage(mini.deserialize(getPrefix() + getMessage("chat-disabled")));
                }
                core.getSoundManager().play(player, "party-chat-toggle");
                open();
                yield true;
            }
            case "SETTINGS" -> {
                playSound("click");
                new PartySettingsGui(core, player, party, partyPlugin).open();
                yield true;
            }
            case "READY_CHECK" -> {
                player.closeInventory();
                partyPlugin.getReadyCheckManager().startReadyCheck(player, null);
                yield true;
            }
            case "TELEPORT" -> {
                player.closeInventory();
                partyPlugin.getPartyManager().teleportAll(player);
                yield true;
            }
            case "PARTY_LIST" -> {
                playSound("click");
                new PartyListGui(core, player, partyPlugin).open();
                yield true;
            }
            case "DISBAND" -> {
                player.closeInventory();
                partyPlugin.getPartyManager().disbandParty(player);
                yield true;
            }
            case "LEAVE" -> {
                player.closeInventory();
                partyPlugin.getPartyManager().leaveParty(player);
                yield true;
            }
            case "BACK" -> {
                playSound("click");
                player.closeInventory();
                yield true;
            }
            default -> false;
        };
    }

    // ═══════════════ Utility ═══════════════

    private String getLeaderName() {
        return getPlayerName(party.getLeaderUuid());
    }

    private String getPlayerName(UUID uuid) {
        Player p = Bukkit.getPlayer(uuid);
        if (p != null) return p.getName();
        var offlinePlayer = Bukkit.getOfflinePlayer(uuid);
        String name = offlinePlayer.getName();
        return name != null ? name : uuid.toString().substring(0, 8);
    }

    private String getPrefix() {
        return partyPlugin.getConfig().getString("messages.prefix",
                "<gradient:#00d4ff:#00ff88>⚔ Party</gradient> <dark_gray>»</dark_gray> ");
    }

    private String getMessage(String key) {
        return partyPlugin.getConfig().getString("messages." + key, "");
    }
}
