# EthernovaParty

> Sistema de grupos/parties para el ecosistema Ethernova.

## Características

- **Creación de parties** — Crear, invitar, aceptar, rechazar, expulsar
- **Roles** — Líder, Moderador, Miembro
- **Configuración** — Friendly fire, público/privado, tamaño máximo
- **Party Chat** — Chat dedicado con toggle y prefijo rápido
- **Teleport** — Líder/mod puede teleportar a todos los miembros
- **Parties públicas** — Navegación y unión a parties públicas
- **GUI** — Interfaz gráfica de gestión
- **Buffs** — Bonificaciones por tamaño de party (XP, velocidad, regeneración)
- **Ready Check** — Sistema de verificación de preparación
- **Persistencia** — Guardado en base de datos (sobrevive reinicios)
- **Auto-save** — Guardado periódico con dirty tracking

## API

```java
PartyAPI api = ServiceRegistry.get(PartyAPI.class);
api.isInParty(uuid);
api.getParty(uuid);
api.areInSameParty(uuid1, uuid2);
api.shouldCancelDamage(attacker, victim);
api.getXPMultiplier(uuid);
api.getPartyLeader(uuid);
api.getPartyMembers(uuid);
```

## Comandos

| Comando | Descripción |
|---------|-------------|
| `/party create` | Crear party |
| `/party invite <jugador>` | Invitar |
| `/party accept` | Aceptar invitación |
| `/party leave` | Salir de la party |
| `/party chat` | Toggle chat de party |
| `/party tp` | Teleportar miembros |
| `/party ready` | Iniciar ready check |
