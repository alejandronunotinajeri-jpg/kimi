# EthernovaClans Ecosystem — Full Audit Report 2025

> **Platform:** Minecraft Paper 1.21.4 · **Language:** Java 21 · **Build:** Maven multi-module  
> **Total Files:** 329 Java · 140 YAML · 9 Plugins  
> **Text Rendering:** MiniMessage (Adventure API)  
> **Database:** SQLite / MySQL via HikariCP  
> **External Dependencies:** Vault, PlaceholderAPI, ProtocolLib, DecentHolograms, WorldGuard, WorldEdit, dynmap, BlueMap

---

## Table of Contents

1. [EthernovaCore](#1-ethernovacore)
2. [EthernovaCombat](#2-ethernovacombat)
3. [EthernovaClans](#3-ethernovaclans)
4. [EthernovaCosmetics](#4-ethernovacosmetics)
5. [EthernovaParty](#5-ethernovaparty)
6. [EthernovaProgression](#6-ethernovaprogression)
7. [EthernovaRanked](#7-ethernovaranked)
8. [EthernovaDuels](#8-ethernovaduels)
9. [EthernovaFFA](#9-ethernovaffa)
10. [Cross-Plugin Architecture](#10-cross-plugin-architecture)
11. [Competitor Comparison](#11-competitor-comparison)
12. [Global Code Quality Issues](#12-global-code-quality-issues)
13. [i18n Documentation](#13-i18n-documentation)

---

## 1. EthernovaCore

**Package:** `com.ethernova.core` · **~20 Java files** · **API version:** 1.21  
**Authors:** EthernovaDev · **Soft-depends:** Vault, PlaceholderAPI, ProtocolLib, DecentHolograms

### 1.1 Java File Purpose Map

| File | Purpose |
|------|---------|
| `EthernovaCore.java` | Main plugin class. 11-phase startup: Config → Messages → DB → Managers → ServerMode → CrossServer → GUI → Listeners → Commands → PlaceholderAPI → API. Facade for all core services. |
| `CoreCommand.java` | `/ethernova` command handler with 6 subcommands |
| `CorePlayerListener.java` | Handles `PlayerJoinEvent` (LOWEST) and `PlayerQuitEvent` (MONITOR). Creates in-memory profile on join, merges DB data async. Saves profile async on quit. |
| `ConfigManager.java` | YAML configuration loader/reloader |
| `MessageManager.java` | MiniMessage-based message system with locale support |
| `CoreStorageManager.java` | HikariCP connection pool. SQLite/MySQL support. Creates core tables. |
| `ProfileManager.java` | In-memory profile cache keyed by UUID. Async DB merge/save. |
| `ContextManager.java` | Per-player temporary context data (cleared on quit) |
| `EventBus.java` | Custom inter-plugin event system (decoupled from Bukkit) |
| `EconomyHook.java` | Vault economy bridge |
| `VisualManager.java` | Particle/visual effects framework |
| `CooldownManager.java` | Per-player cooldown tracking with named keys |
| `ServerModeManager.java` | Auto-detect or override server mode (SURVIVAL/FFA/SKYBLOCK/etc.) |
| `BoostManager.java` | Server-wide multiplier boosts (XP/money/drops/kills) |
| `CrossServerMessenger.java` | Plugin messaging channel for BungeeCord/Velocity |
| `SoundManager.java` | Named sound presets configurable in config.yml |
| `LocaleManager.java` | Per-player locale selection (auto/en/es) |
| `GuiManager.java` | Base GUI framework with pagination support |
| `EthernovaPlaceholders.java` | PlaceholderAPI expansion registration |
| `PlayerProfile.java` | POJO: uuid, name, kills, deaths, play_time, first_join, last_join, level, prestige, xp, coins |
| `ConfirmationGui.java` | Reusable yes/no confirmation GUI |
| `PaginatedGui.java` | Reusable paginated inventory GUI |
| `CoreGui.java` | Base GUI class with common helper methods |

### 1.2 Commands & Subcommands

| Command | Subcommand | Permission | Description |
|---------|-----------|------------|-------------|
| `/ethernova` | `reload` | `ethernova.admin` | Reload config, messages, sounds |
| `/ethernova` | `status` | `ethernova.admin` | Show version, server mode, registered plugins, profile count, DB type, active boosts |
| `/ethernova` | `debug` | `ethernova.admin` | Toggle debug logging |
| `/ethernova` | `boost <type> <multiplier> <duration>` | `ethernova.admin` | Activate server-wide boost (xp/money/drops/kills) |
| `/ethernova` | `profile <player>` | `ethernova.admin` | Display player profile: level, prestige, xp, coins, kills, deaths, KDR, playtime |
| `/ethernova` | `lang <es\|en\|auto>` | `ethernova.admin` | Per-player language selection |

### 1.3 GUIs / Menus

| GUI | Description |
|-----|-------------|
| `ConfirmationGui` | Generic yes/no confirmation dialog |
| `PaginatedGui` | Paginated item list framework |
| `CoreGui` | Abstract base for all GUI screens |

### 1.4 Configuration Options (config.yml)

| Path | Type | Default | Description |
|------|------|---------|-------------|
| `general.language` | String | `es` | Default language |
| `general.debug` | Boolean | `false` | Debug mode |
| `server.mode` | String | `auto` | Server mode (auto/SURVIVAL/FFA/SKYBLOCK/LOBBY/CREATIVE/PRISON/PRACTICE/CUSTOM) |
| `features.territory-claims` | String | `auto` | Enable territory claims (auto/true/false) |
| `features.pvp-combat-tag` | String | `auto` | Enable combat tagging |
| `features.economy` | String | `auto` | Enable Vault economy |
| `features.kill-rewards` | String | `auto` | Enable kill rewards |
| `features.death-penalties` | String | `auto` | Enable death penalties |
| `features.parties` | String | `auto` | Enable party system |
| `features.ranked` | String | `auto` | Enable ranked system |
| `features.cosmetics` | String | `auto` | Enable cosmetics |
| `database.type` | String | `sqlite` | Database type (sqlite/mysql) |
| `database.sqlite.file` | String | `data/ethernova.db` | SQLite file path |
| `database.mysql.host/port/database/username/password` | Various | — | MySQL connection settings |
| `database.pool.maximum-pool-size` | Integer | `10` | HikariCP pool size |
| `database.pool.minimum-idle` | Integer | `2` | HikariCP minimum idle |
| `database.pool.idle-timeout` | Long | `300000` | HikariCP idle timeout (ms) |
| `database.pool.max-lifetime` | Long | `600000` | HikariCP max lifetime (ms) |
| `database.pool.connection-timeout` | Long | `30000` | Connection timeout (ms) |
| `visual.*` | Various | — | Particle/visual effect settings |
| `profiles.auto-save-interval` | Integer | `300` | Auto-save interval in seconds |
| `sounds.*` | Map | — | Named sound presets (overridable) |

### 1.5 Database Tables

| Table | Columns | Engine |
|-------|---------|--------|
| `ethernova_profiles` | `uuid` (PK), `name`, `kills`, `deaths`, `play_time`, `first_join`, `last_join`, `level`, `prestige`, `xp`, `coins` | SQLite/MySQL |
| `ethernova_profile_data` | `uuid` + `data_key` (composite PK), `data_value` | SQLite/MySQL |

### 1.6 Event Listeners

| Listener | Events | Priority |
|----------|--------|----------|
| `CorePlayerListener` | `PlayerJoinEvent` | LOWEST |
| `CorePlayerListener` | `PlayerQuitEvent` | MONITOR |

### 1.7 Custom Events (EventBus)

| Event | Fired When |
|-------|------------|
| `PrestigeEvent` | Player prestiges |
| `PowerChangeEvent` | Clan power changes |
| `MatchEndEvent` | Match ends (duels/FFA) |
| `LevelUpEvent` | Player levels up |
| `EthernovaPlayerKillEvent` | Player kill registered |
| `DuelEndEvent` | Duel concludes |
| `CoinsChangeEvent` | Player coins change |
| `ClanWarStartEvent` | Clan war begins |
| `ClanWarEndEvent` | Clan war ends |

### 1.8 Placeholders (%ethernova_*%)

| Placeholder | Returns |
|-------------|---------|
| `%ethernova_kills%` | Total kills |
| `%ethernova_deaths%` | Total deaths |
| `%ethernova_kdr%` | Kill/death ratio |
| `%ethernova_level%` | Player level |
| `%ethernova_prestige%` | Prestige tier |
| `%ethernova_coins%` | Coin balance |
| `%ethernova_playtime%` | Play time (raw) |
| `%ethernova_playtime_formatted%` | Play time (human-readable) |
| `%ethernova_name%` | Player name |
| `%ethernova_server_mode%` | Current server mode |
| `%ethernova_online%` | Online player count |
| `%ethernova_boost_<type>%` | Active boost multiplier |
| `%ethernova_boost_<type>_time%` | Remaining boost time |

---

## 2. EthernovaCombat

**Package:** `com.ethernova.combat` · **~47 Java files** · **API version:** 1.21  
**Depends:** EthernovaCore · **Soft-depends:** ProtocolLib, WorldGuard

### 2.1 Java File Purpose Map

| File | Purpose |
|------|---------|
| `EthernovaCombat.java` | Main class. 20+ managers registered. Checks Core hook, registers 8 listeners. |
| `CombatCommand.java` | `/combat` command (status, newbie) |
| `CombatAdminCommand.java` | `/combatadmin` command (reload, tag, untag, gui) |
| `TagManager.java` | Combat tag tracking with BossBar + ActionBar display |
| `KillStreakManager.java` | Killstreak milestones with broadcasts/rewards/effects |
| `NPCManager.java` | Combat NPC spawning on disconnect (via ProtocolLib) |
| `RewardManager.java` | Kill rewards with economy integration |
| `PenaltyManager.java` | Death penalties (XP/money/items loss) |
| `NewbieProtectionManager.java` | 120-minute protection for new players |
| `KDRAbuseManager.java` | Anti-abuse: same-IP, repeat-kill detection, 3-tier sanctions |
| `SafeLogoutManager.java` | 10-second safe logout countdown |
| `LootProtectionManager.java` | Prevents non-killers from looting drops |
| `CheatPreventionManager.java` | Anti-cheat for ender pearls, chorus, elytra, commands in combat |
| `DeathEffectManager.java` | Configurable death effects |
| `ProfileManager.java` | Combat-specific profile extensions |
| `VisualManager.java` | Combat visuals (heartbeat, compass, kill feed) |
| `WorldConfigManager.java` | Per-world combat configuration |
| `ModuleRegistry.java` | Modular enable/disable for combat subsystems |
| `DetectionManager.java` | Admin alerts for suspicious activity |
| `AdminGUIManager.java` | Multi-page admin GUI with player management |
| `RevengeManager.java` | Revenge bonus system for killing your killer |
| `DeathRecapManager.java` | Post-death damage breakdown |
| `BountyManager.java` | Player bounty system |
| `ComboManager.java` | Rapid-kill combo tracking |
| `StreakAbilityManager.java` | Special abilities at killstreak milestones |
| `ClanIntegrationListener.java` | EventBus listener for clan war events |
| `GUIHelper.java` | GUI utility methods |

### 2.2 Commands & Subcommands

| Command | Subcommand | Permission | Description |
|---------|-----------|------------|-------------|
| `/combat` | `status` | `ethernova.combat` | Check combat tag status |
| `/combat` | `newbie` | `ethernova.combat.newbie` | Toggle newbie protection |
| `/combatadmin` | *(none)* | `ethernova.combat.admin` | Open admin GUI |
| `/combatadmin` | `reload` | `ethernova.combat.admin` | Reload combat config |
| `/combatadmin` | `tag <player>` | `ethernova.combat.admin` | Force combat-tag a player |
| `/combatadmin` | `untag <player>` | `ethernova.combat.admin` | Remove combat tag |
| `/combatadmin` | `gui` | `ethernova.combat.admin` | Open admin GUI |
| `/logout` | — | `ethernova.combat.logout` | Safe logout (10s countdown) |
| `/bounty` | `<player> <amount>` | `ethernova.combat.bounty` | Place bounty on player |

### 2.3 GUIs / Menus

| GUI | Description |
|-----|-------------|
| `AdminGUIManager` | Multi-page admin panel: player list, active tags, system settings, sanctions history |
| `AdminGUIListener` | Handles InventoryClickEvent, InventoryCloseEvent, InventoryDragEvent for admin GUI |

### 2.4 Configuration Files

#### config.yml
| Path | Type | Default | Description |
|------|------|---------|-------------|
| `combat-tag.duration` | Integer | `15` | Tag duration in seconds |
| `combat-tag.bossbar.enabled` | Boolean | `true` | BossBar display |
| `combat-tag.bossbar.color` | String | `RED` | BossBar color |
| `combat-tag.actionbar.enabled` | Boolean | `true` | ActionBar display |
| `combat-tag.blocked-commands` | List | `[home, spawn, tpa, ...]` | Commands blocked during combat |
| `npc.enabled` | Boolean | `true` | Spawn NPC on combat disconnect |
| `npc.duration` | Integer | `15` | NPC lifetime in seconds |
| `npc.drop-loot` | Boolean | `true` | NPC drops player loot |
| `penalties.enabled` | Boolean | `true` | Death penalties |
| `penalties.money-loss-percent` | Double | `5.0` | Money lost on death (%) |
| `penalties.xp-loss-percent` | Double | `10.0` | XP lost on death (%) |
| `penalties.drop-inventory` | Boolean | `false` | Drop inventory on death |
| `newbie-protection.enabled` | Boolean | `true` | Newbie protection |
| `newbie-protection.duration-minutes` | Integer | `120` | Protection duration |
| `anti-abuse.enabled` | Boolean | `true` | Anti-abuse system |
| `anti-abuse.same-ip-check` | Boolean | `true` | Block same-IP kills |
| `anti-abuse.repeat-kill.threshold` | Integer | `3` | Repeat kills before sanction |
| `anti-abuse.repeat-kill.window-minutes` | Integer | `10` | Detection window |
| `safe-logout.enabled` | Boolean | `true` | Safe logout system |
| `safe-logout.countdown` | Integer | `10` | Countdown seconds |
| `loot-protection.enabled` | Boolean | `true` | Loot protection |
| `loot-protection.duration` | Integer | `30` | Protection duration |
| `death-effects.enabled` | Boolean | `true` | Death visual effects |
| `visuals.heartbeat`, `compass`, `kill-feed` | Boolean | `true` | Visual indicators |
| `revenge.*` | Various | — | Revenge bonus settings |
| `killstreaks.*` | Various | — | Killstreak config |

#### killstreaks.yml
| Streak | Name | Broadcast | Reward | Effects |
|--------|------|-----------|--------|---------|
| 5 | "On Fire" | Server-wide | $500 + 100xp | Fire particles |
| 10 | "Unstoppable" | Server-wide | $1500 + 300xp | Lightning + title |
| 25 | "Legendary" | Server-wide | $5000 + 1000xp | Totem + fireworks |

#### rewards.yml
- Kill rewards (coins + XP), death penalties, revenge bonus, underdog bonus

#### profiles.yml
- 4 combat profiles: survival, war, arena, ffa — each with different tag durations, loot rules, NPC settings

### 2.5 Event Listeners

| Listener | Events Handled | Priority |
|----------|---------------|----------|
| `CombatDamageListener` | `EntityDamageByEntityEvent` (×2) | HIGH |
| `CombatDeathListener` | `PlayerDeathEvent`, `EntityDeathEvent` | HIGH |
| `CombatDisconnectListener` | `PlayerQuitEvent`, `PlayerJoinEvent` | HIGH |
| `CombatCheatListener` | `PlayerCommandPreprocessEvent`, `PlayerTeleportEvent`, `PlayerInteractEvent`, `EntityDamageEvent`, `PlayerToggleFlightEvent` | HIGHEST |
| `CombatMoveListener` | `PlayerMoveEvent` (×2) | HIGHEST + MONITOR |
| `CombatItemListener` | `PlayerDropItemEvent` | HIGH |
| `CombatNPCListener` | `EntityDamageByEntityEvent` | HIGH |
| `AdminGUIListener` | `InventoryClickEvent`, `InventoryCloseEvent`, `InventoryDragEvent` | NORMAL |
| `ClanIntegrationListener` | Core EventBus events (ClanWarStart/End) | — |

### 2.6 Database Tables

None created directly — uses Core's `ethernova_profile_data` for per-player combat data.

### 2.7 Placeholders

None registered directly. Combat data accessible through Core's profile placeholders.

---

## 3. EthernovaClans

**Package:** `com.ethernova.clans` · **~160 Java files** · **API version:** 1.21  
**Soft-depends:** EthernovaCore, EthernovaCombat, Vault, PlaceholderAPI, DecentHolograms, WorldGuard, WorldEdit, dynmap, BlueMap

### 3.1 Java File Purpose Map (Key Files)

| File / Package | Purpose |
|---------------|---------|
| `EthernovaClans.java` | Main class. 593 lines. 17-phase startup. 50+ managers. Works standalone without Core. |
| `command/ClanCommandExecutor.java` | 1890-line command executor: 40+ subcommands + tab complete |
| `command/ClanAdminCommand.java` | Admin commands (20+ subcommands) |
| `command/WebMapCommand.java` | Web map account management |
| `clan/Clan.java` | Clan model (members, power, home, warps, description, banned, etc.) |
| `clan/ClanMember.java` | Member model (uuid, name, role, joinDate) |
| `clan/ClanRole.java` | Enum: RECRUIT, MEMBER, OFFICER, CO_LEADER, LEADER |
| `clan/ClanManager.java` | Core clan CRUD, chunk claiming, member mapping |
| `power/PowerManager.java` | Power system (regen, loss, max calculations) |
| `territory/TerritoryManager.java` | Chunk-based territory claims |
| `territory/TerritoryFlag.java` | Enum of territory flags (PVP, EXPLOSIONS, etc.) |
| `territory/TerritoryFlagManager.java` | Per-clan flag management |
| `territory/TerritoryHUD.java` | Real-time territory display on ActionBar |
| `war/WarManager.java` | War declaration, acceptance, surrender, scoring |
| `alliance/AllianceManager.java` | Alliance requests, acceptance, breaking, rival system |
| `nation/NationManager.java` | Nations (groups of clans): create, invite, promote, kick |
| `nation/Nation.java` | Nation model with roles (MEMBER, OFFICER, LEADER) |
| `outpost/OutpostManager.java` | Placeable structures: barracks, farm, watchtower, wall |
| `outpost/Outpost.java` | Outpost model with type, level, health |
| `outpost/OutpostType.java` | Enum of outpost types |
| `spy/SpyManager.java` | Social spy, infiltration, intel reports |
| `bank/BankManager.java` | Clan bank with deposit/withdraw |
| `level/LevelManager.java` | Clan leveling system (10 levels with perks) |
| `upgrade/UpgradeManager.java` | Clan upgrades (5 types with levels) |
| `chat/ClanChatManager.java` | Clan/ally/officer/nation chat channels |
| `invitation/InvitationManager.java` | Invite system with expiration |
| `shield/ShieldManager.java` | Post-war shield protection |
| `economy/EconomyManager.java` | Vault wrapper for clan operations |
| `hologram/HologramManager.java` | DecentHolograms integration |
| `discord/DiscordWebhook.java` | Discord notification integration |
| `audit/AuditLogger.java` | Clan action audit logging |
| `audit/AuditManager.java` | Audit data management |
| `audit/AuditAction.java` | Enum of auditable actions |
| `mission/MissionManager.java` | Daily/weekly missions |
| `achievement/AchievementManager.java` | 30+ achievements across categories |
| `event/EventScheduler.java` | Scheduled server events (double power, KOTH, etc.) |
| `fly/FlyManager.java` | Territory fly in claimed chunks |
| `nametag/NametagManager.java` | Clan tag display above player name |
| `skill/ClanSkillManager.java` | Clan-wide passive skills |
| `shop/ClanShopManager.java` | In-game clan shop |
| `siege/SiegeManager.java` | Extended siege warfare |
| `diplomacy/DiplomacyManager.java` | Diplomacy relations |
| `salary/SalaryManager.java` | Periodic salary from clan bank |
| `tax/TaxManager.java` | Automatic territory/member taxes |
| `season/SeasonManager.java` | Seasonal rankings and resets |
| `banner/BannerManager.java` | Custom clan banners |
| `blueprint/BlueprintManager.java` | Structure blueprints (buildable in territory) |
| `webmap/WebMapServer.java` | Embedded HTTP server for web territory map |
| `webmap/WebAuthManager.java` | Web map authentication |
| `chunk/ChunkVisualizer.java` | In-game chunk border visualization |
| `storage/StorageManager.java` | Clans-specific DB operations |
| `storage/SchemaManager.java` | DB migrations (v1–v6) |
| `config/ConfigManager.java` | Clan config management |
| `config/ConfigurableGUI.java` | YAML-driven GUI configuration |
| `message/MessageManager.java` | Multi-language message system |
| `teleport/TeleportManager.java` | Warmup teleportation system |
| `confirmation/ConfirmationManager.java` | Confirmation system for destructive actions |
| `hook/*` | CoreHook, CombatHook, VaultHook, PlaceholderHook, DynmapHook, DecentHologramsHook, WorldGuardHook, TabHook |
| `placeholder/ClanPlaceholderExpansion.java` | 30+ PAPI placeholders |
| `gui/*.java` | 30+ GUI screens (see GUIs section) |
| `listener/*.java` | 10+ listeners (see Listeners section) |
| `util/TextUtil.java` | Progress bars, formatting utilities |
| `metrics/Metrics.java` | bStats metrics integration |

### 3.2 Commands & Subcommands

#### `/clan` (aliases: `c`, `clans`) — Permission: `ethernova.clans.use`

| Subcommand | Role Req. | Description |
|-----------|-----------|-------------|
| `create <name> [tag]` | — | Create clan (costs money) |
| `disband [confirm]` | LEADER | Disband clan (with confirmation) |
| `invite <player>` | OFFICER | Invite player |
| `join <clan>` / `accept` | — | Accept invitation |
| `deny` | — | Deny invitation |
| `leave` | — | Leave clan (leader cannot) |
| `kick <player>` | OFFICER | Kick member (cannot kick higher rank) |
| `promote <player>` | CO_LEADER | Promote member |
| `demote <player>` | CO_LEADER | Demote member |
| `info [clan]` | — | Clan information panel |
| `list [page]` | — | Paginated clan list |
| `chat` | — | Toggle clan chat |
| `allychat` | — | Toggle ally chat |
| `officerchat` | OFFICER | Toggle officer chat |
| `ally <request\|accept\|deny\|break> <clan>` | CO_LEADER | Alliance management |
| `enemy <clan>` | CO_LEADER | Set rival |
| `claim` | OFFICER | Claim current chunk |
| `unclaim` | OFFICER | Unclaim current chunk |
| `autoclaim` | OFFICER | Toggle auto-claim mode |
| `map` | — | ASCII territory map (9×9 grid with compass) |
| `home` | — | Teleport to clan home (warmup + cooldown) |
| `sethome` | OFFICER | Set clan home |
| `warp <name>` | — | Teleport to clan warp |
| `setwarp <name>` | OFFICER | Set clan warp |
| `delwarp <name>` | OFFICER | Delete clan warp |
| `warps` | — | List all clan warps |
| `war <declare\|accept\|surrender> [clan]` | CO_LEADER | War management |
| `upgrade` | CO_LEADER | Open upgrades GUI |
| `top [power\|members\|kills\|territory\|level\|bank] [page]` | — | Leaderboards with 6 sort types |
| `transfer <player>` | LEADER | Transfer leadership |
| `desc <text>` | OFFICER | Set clan description |
| `ban <player>` | LEADER | Ban player from clan |
| `unban <player>` | LEADER | Unban player |
| `bank [deposit\|withdraw\|balance] [amount]` | — (withdraw: OFFICER) | Clan bank |
| `level` | — | View clan level/XP |
| `log` | OFFICER | View audit log (15 recent entries, async DB) |
| `flags [flag]` | LEADER | View/toggle territory flags |
| `confirm` | — | Confirm pending action |
| `menu` / `gui` | — | Open main clan GUI |
| `help` | — | Full help page |
| `nation <sub>` | — | Nation management (13 sub-subcommands) |
| `outpost <sub>` | — | Outpost management (5 sub-subcommands) |
| `spy <sub>` | — | Espionage system (4 sub-subcommands) |

#### `/clan nation` sub-subcommands

| Sub | Role | Description |
|-----|------|-------------|
| `create <name> [tag]` | LEADER | Create nation |
| `disband` | LEADER (nation leader) | Disband nation |
| `invite <clan>` | Nation OFFICER | Invite clan to nation |
| `accept` / `join` | LEADER | Accept nation invite |
| `deny` | LEADER | Deny nation invite |
| `kick <clan>` | Nation OFFICER | Kick clan from nation |
| `leave` | LEADER | Leave nation |
| `promote <clan>` | Nation LEADER | Promote clan in nation |
| `demote <clan>` | Nation LEADER | Demote clan in nation |
| `info [name]` | — | Nation info |
| `list` | — | All nations list |
| `chat` | — | Toggle nation chat |
| `desc <text>` | Nation LEADER | Set nation description |

#### `/clan outpost` sub-subcommands

| Sub | Role | Description |
|-----|------|-------------|
| `place <type>` | OFFICER | Place outpost (types: barracks, farm, watchtower, wall) |
| `remove` | OFFICER | Remove outpost at location |
| `upgrade` | OFFICER | Upgrade outpost at location |
| `list` | — | List all clan outposts |
| `info` | — | Info about outpost at location |

#### `/clan spy` sub-subcommands

| Sub | Permission | Description |
|-----|-----------|-------------|
| `socialspy` | `ethernova.spy.socialspy` | Toggle admin social spy |
| `infiltrate <clan>` | `ethernova.spy.infiltrate` | Begin infiltration (costs money, has cooldown) |
| `stop` | — | Stop infiltration |
| `intel <clan>` | `ethernova.spy.intel` | Generate clan intelligence report |

#### `/clanadmin` (aliases: `cadmin`, `ca`) — Permission: `ethernova.clans.admin`

| Subcommand | Description |
|-----------|-------------|
| `gui` | Open admin GUI |
| `reload` | Reload all configs |
| `disband <clan>` | Force disband |
| `setpower <clan> <amount>` | Set clan power |
| `forcejoin <clan> <player>` | Force player into clan |
| `forceleader <clan> <player>` | Force leadership transfer |
| `spy` | Toggle admin spy mode |
| `blueprint <sub>` | Blueprint admin management |
| `season reset` | Reset season |
| `tax collect` | Force tax collection |
| `setbank <clan> <amount>` | Set bank balance |
| `setlevel <clan> <level>` | Set clan level |
| `info <clan>` | Detailed admin clan info |
| `audit <clan>` | View full audit log |
| `unclaimall <clan>` | Unclaim all territories |
| `resetlevel <clan>` | Reset clan level |
| `resetbank <clan>` | Reset clan bank |
| `tpchunk <world> <x> <z>` | Teleport to chunk |

#### `/webmap` (aliases: `wm`)
- Web map account management

### 3.3 GUIs / Menus (32 total)

| GUI | Description |
|-----|-------------|
| `ClanMainGui` | Main menu: members, territory, bank, upgrades, wars, settings, missions |
| `MembersGui` | Member list with role indicators, promote/kick buttons |
| `UpgradesGui` | 5 upgrade types with costs and level progress |
| `WarsGui` | Active wars, war history, declare war |
| `WarpsGui` | Warp list with teleport buttons |
| `TrophiesGui` | Trophy/achievement showcase |
| `TopsGui` | Leaderboard browser |
| `TerritoryMapGui` | GUI-based territory map |
| `StatsGui` | Clan statistics dashboard |
| `SettingsGui` | Clan settings management |
| `SeasonGui` | Season info and rankings |
| `ProgressGui` | Clan progress overview |
| `PermissionsGui` | Role permissions configuration |
| `MissionsGui` | Daily/weekly mission tracker |
| `InvitePlayersGui` | Player invitations browser |
| `InvitationsGui` | Pending invitation list |
| `IconSelectorGui` | Clan icon chooser |
| `EventCalendarGui` | Scheduled event calendar |
| `DiplomacyGui` | Alliance/rival relationships |
| `ColorPickerGui` | Tag color/gradient selector |
| `ClanSkillsGui` | Passive skill tree |
| `ClanShopGui` | In-game shop |
| `BoostsGui` | Active boosts display |
| `BlueprintMenuGui` | Blueprint catalog |
| `BlueprintAdminGui` | Admin blueprint management |
| `BankGui` | Bank transactions |
| `AuditLogGui` | Paginated audit log |
| `AdminPlayerGui` | Admin player management |
| `AdminMainGui` | Admin main menu |
| `AdminClanListGui` | Admin clan browser |
| `AdminClanGui` | Admin clan details |
| `AchievementsGui` | Achievement progress tracker |

### 3.4 Configuration Options (config.yml — key paths)

| Path | Default | Description |
|------|---------|-------------|
| `general.prefix` | MiniMessage | Chat prefix |
| `general.language` | `es` | Default language |
| `general.debug` | `false` | Debug mode |
| `database.type` | `sqlite` | DB type |
| `clans.max-members` | `20` | Max members per clan |
| `clans.min-name-length` | `3` | Min clan name |
| `clans.max-name-length` | `16` | Max clan name |
| `clans.min-tag-length` | `2` | Min tag length |
| `clans.max-tag-length` | `5` | Max tag length |
| `clans.create-cost` | `5000` | Creation cost |
| `clans.home-cooldown-seconds` | `60` | Home teleport cooldown |
| `clans.desc-max-length` | `100` | Max description |
| `power.starting-power` | `10.0` | Initial power |
| `power.max-power` | `50.0` | Max per-player power |
| `power.regen-rate` | `0.1` | Power regen per minute |
| `power.death-loss` | `4.0` | Power lost on death |
| `power.kill-gain` | `2.0` | Power gained on kill |
| `territory.cost-per-claim` | `0` | Money per chunk claim |
| `territory.max-claims-per-power` | `1` | Claims per power unit |
| `alliance.max-allies` | `3` | Max allies |
| `war.min-power-to-declare` | `20` | Min power for war |
| `war.duration-minutes` | `30` | Max war duration |
| `war.shield-duration-hours` | `24` | Post-war shield |
| `upgrades.*` | Various | 5 upgrade types with levels |
| `chat.clan-format` | MiniMessage | Chat format template |
| `chat.ally-format` | MiniMessage | Ally chat format |
| `discord.enabled` | `false` | Discord webhooks |
| `bank.enabled` | `true` | Clan bank |
| `bank.max-balance` | `1000000` | Max bank |
| `taxes.*` | Various | Auto taxation |
| `levels.*` | — | Leveling XP requirements |
| `scoreboard.*` | — | Scoreboard config |
| `nations.*` | — | Nation settings |
| `outposts.*` | — | Outpost settings |
| `spy.*` | — | Spy system config |
| `webmap.*` | — | Embedded web map server |
| `metrics.enabled` | `true` | bStats metrics |
| `seasons.*` | — | Seasonal resets |
| `borders.*` | — | Chunk border visualization |

### 3.5 Additional YAML Config Files

| File | Content |
|------|---------|
| `achievements.yml` | 30+ achievements in categories (combat, territory, social, economy, progression) |
| `missions.yml` | Daily (3) and weekly (2) missions with XP/money rewards |
| `levels.yml` | 10 clan levels (1=Campamento through 10=Imperio) with perks (extra members, claims, warps, bank limit) and XP boosts |
| `blueprints.yml` | 4+ structure types (barracks, farm, watchtower, wall) with material costs, build times, and effects |
| `scheduled-events.yml` | 4 event types (double_power, double_money, happy_hour, koth) with cron-like scheduling |

### 3.6 Database Tables

| Table | Key Columns | Created In |
|-------|-------------|------------|
| `clans` | total_kills, total_deaths, wars_won, wars_lost, nation_id, icon, tag_color, gradient_start, gradient_end, use_gradient | SchemaManager v1-v6 |
| `clan_members` | rank_id | SchemaManager v3 |
| `clan_nations` | nation_id (PK), name, tag, leader_clan_id, description, created_at | SchemaManager v4 |
| `clan_nation_members` | nation_id + clan_id (PK), role, joined_at | SchemaManager v4 |
| `clan_outposts` | outpost_id (PK), clan_id, type, world, x, y, z, level, health, created_at | SchemaManager v5 |
| `clan_shields` | clan_id (PK), expiry_ms | SchemaManager v2 |
| `clan_blueprints` | id (auto PK), blueprint_id, clan_id, chunk_id, level, built_at | SchemaManager v5 |
| `clan_banners` | clan_id (PK), banner_data | SchemaManager v5 |
| `clan_season_history` | id (auto PK), clan_id, clan_name, season, kills, deaths, power, level, members, wars_won, territories, score, rank, balance | SchemaManager v6 |
| `clan_season_entries` | Similar to history | SchemaManager v6 |
| `schema_version` | version | Migration tracking |
| *Base tables* | territories, alliances, bank_balances, xp, etc. | StorageManager |

### 3.7 Event Listeners

| Listener | Events |
|----------|--------|
| `TerritoryListener` | Block break/place, explosions, interact, piston, fire — territory protection |
| `TerritoryFlyListener` | PlayerMoveEvent — auto-disable fly outside territory |
| `SkillEffectListener` | Various — clan skill passive effects |
| `PlayerListener` | Join/quit — load/save clan data |
| `PlayerDamageListener` | EntityDamageByEntity — friendly fire prevention, war damage |
| `PlayerChatListener` | AsyncChatEvent — clan/ally/officer/nation chat routing |
| `OutpostListener` | Block break — outpost damage from enemies |
| `GUIListener` | InventoryClickEvent — all GUI interactions |
| `CombatListener` | PlayerDeathEvent — power loss, kill logging, bounty collection |
| `ChatListener` | AsyncChatEvent — chat formatting with clan tags |
| `ChatFormatListener` | AsyncChatEvent — MiniMessage chat format |
| `AchievementListener` | Various events — achievement tracking |
| `BlueprintEffectListener` | Various — blueprint passive effects |

### 3.8 Placeholders (%ethernova_clans_*%)

| Placeholder | Returns |
|-------------|---------|
| `has_clan` | true/false |
| `clan_name` | Clan name |
| `clan_display` | Clan display name (formatted) |
| `clan_tag` | Clan tag |
| `clan_desc` | Clan description |
| `clan_members` | Member count |
| `clan_online` | Online member count |
| `clan_power` | Current power |
| `clan_max_power` | Maximum power |
| `player_power` | Individual player power |
| `player_max_power` | Individual max power |
| `clan_claims` | Territory claim count |
| `clan_max_claims` | Max possible claims |
| `clan_bank` | Bank balance |
| `clan_level` | Clan level |
| `clan_xp` | Clan XP |
| `clan_allies` | Ally count |
| `clan_leader` | Leader name |
| `at_war` | true/false |
| `has_shield` | true/false |
| `player_role` | Player's role in clan |
| `total_clans` | Total clans on server |
| `clan_formatted` | Full formatted tag |
| `clan_warps` | Warp count |
| `clan_max_warps` | Max warp count |
| `has_nation` | true/false |
| `nation_name` | Nation name |
| `nation_tag` | Nation tag |
| `nation_role` | Clan's role in nation |
| `nation_clans` | Clans in nation |
| `nation_leader` | Nation leader clan |
| `outpost_count` | Outpost count |

---

## 4. EthernovaCosmetics

**Package:** `com.ethernova.cosmetics` · **~13 Java files** · **API version:** 1.21  
**Depends:** EthernovaCore

### 4.1 Java File Purpose Map

| File | Purpose |
|------|---------|
| `EthernovaCosmetics.java` | Main class. Registers handlers, loads cosmetics from config. |
| `CosmeticsCommand.java` | `/cosmetics` command |
| `CosmeticsMainGui.java` | Main cosmetics menu |
| `CosmeticTypeGui.java` | Per-type cosmetic browser |
| `CosmeticShopGui.java` | Purchase/equip cosmetics |
| `CosmeticListener.java` | Death/kill event handler for effects |
| `KillEffectHandler.java` | Kill particle/sound effects |
| `TrailHandler.java` | Walking trail particles |
| `ProjectileTrailHandler.java` | Arrow/projectile trail effects |
| `WinEffectHandler.java` | Win celebration effects |
| `Cosmetic.java` | Cosmetic model (id, type, rarity, cost, permission) |
| `CosmeticType.java` | Enum: KILL_EFFECT, DEATH_EFFECT, TRAIL, PROJECTILE_TRAIL, KILL_MESSAGE, WIN_EFFECT |
| `CosmeticRarity.java` | Enum: COMMON, RARE, EPIC, LEGENDARY |

### 4.2 Commands & Subcommands

| Command | Subcommand | Permission | Description |
|---------|-----------|------------|-------------|
| `/cosmetics` | *(none)* | `ethernova.cosmetics.use` | Open main cosmetics menu |
| `/cosmetics` | `shop` | `ethernova.cosmetics.use` | Open shop |
| `/cosmetics` | `preview <id>` | `ethernova.cosmetics.use` | Preview cosmetic effect |

Aliases: `cosmeticos`, `cos`

### 4.3 GUIs / Menus

| GUI | Description |
|-----|-------------|
| `CosmeticsMainGui` | Type selector (6 types) |
| `CosmeticTypeGui` | List cosmetics of selected type |
| `CosmeticShopGui` | Purchase/equip interface |

### 4.4 Configuration (config.yml)

| Path | Default | Description |
|------|---------|-------------|
| `enabled-types` | All | Which cosmetic types are active |
| `trail.particle-count` | `3` | Trail particle density |
| `trail.update-ticks` | `5` | Trail update interval |
| `projectile-trail.*` | Various | Projectile trail settings |
| `win-effect.duration` | `5` | Win effect duration (seconds) |
| `sounds.*` | Various | Sound config for cosmetics |
| `messages.*` | Spanish | All UI messages (inline) |

### 4.5 Database Tables

Uses Core's `ethernova_profile_data` (key-value) to store equipped/owned cosmetics per player.

### 4.6 Event Listeners

| Listener | Events |
|----------|--------|
| `CosmeticListener` | `PlayerDeathEvent`, `EthernovaPlayerKillEvent` |
| `ProjectileTrailHandler` | `ProjectileLaunchEvent`, `ProjectileHitEvent` |

---

## 5. EthernovaParty

**Package:** `com.ethernova.party` · **~8 Java files** · **API version:** 1.21  
**Depends:** EthernovaCore

### 5.1 Java File Purpose Map

| File | Purpose |
|------|---------|
| `EthernovaParty.java` | Main class. Registers PartyManager, PartyChat, listener, command. |
| `PartyCommand.java` | `/party` command (14 subcommands) |
| `PartyManager.java` | In-memory party management (creation, invites, membership) |
| `PartyChat.java` | Party chat channel |
| `Party.java` | Party model (leader, members, public/private) |
| `PartyGui.java` | Party member list GUI |
| `PartyListGui.java` | Public party browser |
| `PartyListener.java` | Join/quit events for party cleanup |

### 5.2 Commands & Subcommands

| Command | Subcommand | Permission | Description |
|---------|-----------|------------|-------------|
| `/party` | `create` | `ethernova.party.use` | Create party |
| `/party` | `invite <player>` | `ethernova.party.use` | Invite player |
| `/party` | `accept` | `ethernova.party.use` | Accept invite |
| `/party` | `decline` | `ethernova.party.use` | Decline invite |
| `/party` | `kick <player>` | `ethernova.party.use` | Kick member (leader only) |
| `/party` | `promote <player>` | `ethernova.party.use` | Transfer leadership |
| `/party` | `leave` | `ethernova.party.use` | Leave party |
| `/party` | `disband` | `ethernova.party.use` | Disband party (leader only) |
| `/party` | `chat <message>` | `ethernova.party.use` | Send party message |
| `/party` | `list` | `ethernova.party.use` | List public parties |
| `/party` | `info` | `ethernova.party.use` | Party information |
| `/party` | `teleport` | `ethernova.party.use` | Teleport to leader |
| `/party` | `gui` | `ethernova.party.use` | Open party GUI |
| `/party` | `public` | `ethernova.party.use` | Toggle public party |

Aliases: `p`, `grupo`

### 5.3 GUIs / Menus

| GUI | Description |
|-----|-------------|
| `PartyGui` | Member list with kick/promote buttons |
| `PartyListGui` | Public party browser with join buttons |

### 5.4 Configuration (config.yml)

| Path | Default | Description |
|------|---------|-------------|
| `party.max-size` | `5` | Max party members |
| `party.invite-timeout` | `60` | Invite timeout (seconds) |
| `party.teleport-cooldown` | `30` | Teleport cooldown |
| `party.allow-public` | `true` | Allow public parties |
| `chat.format` | MiniMessage | Chat format template |
| `chat.quick-prefix` | `!` | Quick party chat prefix |
| `sounds.*` | Various | Custom sounds |
| `messages.*` | Spanish | All messages (inline) |

### 5.5 Database Tables

**None.** Parties are entirely in-memory. Lost on server restart.

### 5.6 Event Listeners

| Listener | Events |
|----------|--------|
| `PartyListener` | `PlayerQuitEvent` — removes from party on disconnect |

---

## 6. EthernovaProgression

**Package:** `com.ethernova.progression` · **~18 Java files** · **API version:** 1.21  
**Depends:** EthernovaCore

### 6.1 Java File Purpose Map

| File | Purpose |
|------|---------|
| `EthernovaProgression.java` | Main class. Registers 5 managers + listener + 5 commands. |
| `ProgressionCommand.java` | `/level` command |
| `PrestigeCommand.java` | `/prestige` command |
| `AchievementCommand.java` | `/achievements` command |
| `MissionCommand.java` | `/missions` command |
| `BattlePassCommand.java` | `/battlepass` command |
| `LevelManager.java` | XP/leveling calculations |
| `PrestigeManager.java` | Prestige system (5 tiers with multipliers) |
| `AchievementManager.java` | Achievement tracking and unlocking |
| `MissionManager.java` | Daily/weekly mission system |
| `BattlePassManager.java` | Battle pass tier progression |
| `ProgressionListener.java` | Bukkit + EventBus events for XP/achievement tracking |
| `ProgressionPlaceholders.java` | 14 PAPI placeholders |
| `LevelGui.java` | Level progress GUI |
| `AchievementGui.java` | Achievement browser |
| `MissionGui.java` | Mission tracker |
| `BattlePassGui.java` | Battle pass display |
| `Achievement.java` / `AchievementCategory.java` / `Mission.java` / `MissionType.java` / `BattlePassTier.java` / `XPSource.java` | Models |

### 6.2 Commands & Subcommands

| Command | Subcommand | Permission | Description |
|---------|-----------|------------|-------------|
| `/level` | *(none)* | `ethernova.progression.use` | Show level info |
| `/level` | `top` | `ethernova.progression.use` | Top players by level |
| `/level` | `addxp <player> <amount>` | `ethernova.progression.admin` | Admin: add XP |
| `/prestige` | — | `ethernova.progression.use` | Prestige up |
| `/achievements` | — | `ethernova.progression.use` | Open achievements GUI |
| `/missions` | — | `ethernova.progression.use` | Open missions GUI |
| `/battlepass` | — | `ethernova.progression.use` | Open battle pass GUI |

Aliases: `nivel` (level), `prestigio` (prestige), `logros` (achievements), `misiones` (missions), `pase` (battlepass)

### 6.3 GUIs / Menus

| GUI | Description |
|-----|-------------|
| `LevelGui` | Level progress bar, XP info, next rewards |
| `AchievementGui` | Categorized achievement browser |
| `MissionGui` | Active daily/weekly mission tracker |
| `BattlePassGui` | Season pass tier display with free/premium tracks |

### 6.4 Configuration (config.yml)

| Path | Default | Description |
|------|---------|-------------|
| `leveling.max-level` | `100` | Max level |
| `leveling.broadcast-levelup` | `true` | Broadcast level ups |
| `xp-multipliers.kill` | `10` | XP per kill |
| `xp-multipliers.mine` | `1` | XP per block mined |
| `xp-multipliers.fish` | `5` | XP per fish caught |
| `xp-multipliers.craft` | `2` | XP per craft |
| `prestige.max-prestige` | `5` | Max prestige |
| `prestige.multipliers` | `[1.0, 1.5, 2.0, 2.5, 3.0, 4.0]` | XP multipliers per prestige |
| `missions.daily-count` | `3` | Daily missions |
| `missions.weekly-count` | `2` | Weekly missions |
| `battlepass.season-name` | String | Current season |
| `battlepass.xp-per-tier` | `1000` | XP required per tier |
| `timer.*` | Various | Task scheduling intervals |
| `messages.*` | Spanish | Inline messages |

### 6.5 Database Tables

Created by `AchievementManager`, `MissionManager`, `BattlePassManager` (via `runMigrations()`):
- Player achievement progress
- Mission completion records
- Battle pass tier progress

### 6.6 Placeholders (%progression_*%)

| Placeholder | Returns |
|-------------|---------|
| `level` | Current level |
| `xp` | Current XP |
| `prestige` | Prestige number |
| `prestige_display` | Prestige with formatting |
| `prestige_multiplier` | XP multiplier |
| `next_level_xp` | XP needed for next level |
| `progress` | Progress bar |
| `daily_missions` | Completed daily missions |
| `bp_tier` | Battle pass tier |
| `bp_season` | Current season name |
| `bp_premium` | Has premium pass? |
| `achievements` | Completed achievement count |
| `achievements_total` | Total achievements |
| `max_level` | Max level |

---

## 7. EthernovaRanked

**Package:** `com.ethernova.ranked` · **~10 Java files** · **API version:** 1.21  
**Depends:** EthernovaCore

### 7.1 Java File Purpose Map

| File | Purpose |
|------|---------|
| `EthernovaRanked.java` | Main class. Registers RankedManager, SeasonManager, RankedListener. |
| `RankedCommand.java` | `/ranked` command (5 subcommands) |
| `RankedManager.java` | ELO calculations, profile CRUD, leaderboard caching. Uses `MigrationManager`. |
| `SeasonManager.java` | Season lifecycle (name, reset, archive) |
| `EloCalculator.java` | Variable K-factor ELO: K=40 (<30 games), K=20 (30-100), K=10 (>100). ELO floor at 0. |
| `RankedProfile.java` | Profile model: uuid, elo, wins, losses, winStreak, bestWinStreak, season, placementMatches. Dirty flag for efficient saves. |
| `Rank.java` | 8 ranks: Bronze (0-999), Silver (1000-1499), Gold (1500-1999), Platinum (2000-2499), Diamond (2500-2999), Master (3000-3499), Grandmaster (3500-3999), Challenger (4000+) |
| `RankedGui.java` | Player ranked card |
| `LeaderboardGui.java` | Top players leaderboard |
| `RankedListener.java` | Kill/death/join/quit events |

### 7.2 Commands & Subcommands

| Command | Subcommand | Permission | Description |
|---------|-----------|------------|-------------|
| `/ranked` | *(none)* | `ethernova.ranked.use` | Open ranked card GUI |
| `/ranked` | `top` / `leaderboard` | `ethernova.ranked.use` | Open leaderboard GUI |
| `/ranked` | `stats [player]` | `ethernova.ranked.use` | View stats (async DB lookup if offline) |
| `/ranked` | `season` / `temporada` | `ethernova.ranked.use` | Season info with personal stats |
| `/ranked` | `admin reset <newId> <newName>` | `ethernova.ranked.admin` | Reset season (archive + reset all) |
| `/ranked` | `card` | `ethernova.ranked.use` | Open ranked card |

Aliases: `elo`, `rango`

### 7.3 GUIs / Menus

| GUI | Description |
|-----|-------------|
| `RankedGui` | Personal rank card: ELO, rank icon, win/loss, win rate, best streak |
| `LeaderboardGui` | Top players with rank icons, ELO, win rate |

### 7.4 Configuration (config.yml)

| Path | Default | Description |
|------|---------|-------------|
| `season.id` | `S1` | Current season ID |
| `season.name` | `Season 1` | Season display name |
| `elo.starting-elo` | `1000` | Starting ELO |
| `elo.placement-matches` | `10` | Games before ELO loss |
| `elo.k-factors.low-games` | `40` | K-factor for <30 games |
| `elo.k-factors.low-games-threshold` | `30` | Threshold |
| `elo.k-factors.mid-games` | `20` | K-factor for 30-100 |
| `elo.k-factors.mid-games-threshold` | `100` | Threshold |
| `elo.k-factors.high-games` | `10` | K-factor for >100 |
| `elo.floor` | `0` | Minimum ELO |
| `ranks.<name>.min-elo/max-elo/color/icon` | Various | 8 rank definitions |
| `leaderboard.cache-seconds` | `30` | Leaderboard cache duration |
| `leaderboard.max-entries` | `100` | Max leaderboard size |
| `action-bar.*` | Various | ELO change display |
| `messages.*` | Spanish | Inline messages |

### 7.5 Database Tables

| Table | Columns | Purpose |
|-------|---------|---------|
| `ethernova_ranked` | uuid + season (PK), elo, wins, losses, win_streak, best_win_streak, placement_matches, updated_at | Active ranked profiles |
| `ethernova_ranked_history` | id (PK auto), uuid, season, final_elo, final_rank, wins, losses, best_win_streak, archived_at | Season archives |

Indexes: `idx_ranked_elo` (season, elo DESC), `idx_ranked_uuid` (uuid), `idx_ranked_history_uuid` (uuid)

### 7.6 ELO System Details

- **Placement matches:** 10 games where the loser doesn't lose ELO
- **K-factor scaling:** Aggressive for new players (K=40), moderate (K=20), conservative for veterans (K=10)
- **Notifications:** Action bar ELO change, rank-up/down announcements, win streak celebrations (every 3+, special at 5 milestones)
- **Leaderboard:** Cached with configurable TTL, async DB queries, JOIN with ethernova_profiles for player names

---

## 8. EthernovaDuels

**Package:** `com.ethernova.duels` · **~14 Java files** · **API version:** 1.21  
**Depends:** EthernovaCore · **Soft-depends:** Vault

### 8.1 Java File Purpose Map

| File | Purpose |
|------|---------|
| `EthernovaDuels.java` | Main class. Registers managers, listeners, commands. |
| `DuelCommand.java` | `/duel` command (challenge, accept, deny, stats, spectate) |
| `DuelAdminCommand.java` | `/dueladmin` command (arena, reload, forceend) |
| `DuelManager.java` | Match lifecycle (request → countdown → fight → end) |
| `ArenaManager.java` | Arena CRUD and allocation |
| `KitManager.java` | Kit definitions and application |
| `DuelStatsManager.java` | Stats persistence with migrations |
| `DuelMatch.java` | Match model (players, kit, arena, state, bet amount) |
| `DuelRequest.java` | Request model with expiration |
| `DuelState.java` | Enum: WAITING, COUNTDOWN, FIGHTING, ENDING |
| `DuelKit.java` | Kit model (name, armor, items, effects, rules) |
| `DuelGui.java` | Kit selection GUI |
| `DuelStatsGui.java` | Player stats display |
| `DuelListener.java` | Damage, death, quit handling during duels |
| `DuelSpectatorListener.java` | Spectator restrictions |

### 8.2 Commands & Subcommands

| Command | Subcommand | Permission | Description |
|---------|-----------|------------|-------------|
| `/duel` | `<player> [kit] [bet]` | `ethernova.duels.use` | Challenge a player (opens kit GUI if no kit specified) |
| `/duel` | `accept` | `ethernova.duels.use` | Accept challenge |
| `/duel` | `deny` | `ethernova.duels.use` | Deny challenge |
| `/duel` | `stats [player]` | `ethernova.duels.use` | View duel stats |
| `/duel` | `spectate [player]` | `ethernova.duels.spectate` | Spectate active duel |
| `/dueladmin` | `arena <create\|delete\|list\|setspawn>` | `ethernova.duels.admin` | Arena management |
| `/dueladmin` | `reload` | `ethernova.duels.admin` | Reload config |
| `/dueladmin` | `forceend` | `ethernova.duels.admin` | Force-end active duel |

Aliases: `duelo`, `1v1`

### 8.3 GUIs / Menus

| GUI | Description |
|-----|-------------|
| `DuelGui` | Kit selection menu with kit icons, descriptions, and preview |
| `DuelStatsGui` | Player statistics: wins, losses, win rate, favorite kit |

### 8.4 Configuration (config.yml)

| Path | Default | Description |
|------|---------|-------------|
| `request-timeout` | `60` | Duel request timeout (seconds) |
| `request-cooldown` | `10` | Cooldown between requests |
| `countdown` | `5` | Pre-fight countdown |
| `max-duration` | `300` | Max duel duration (seconds) |
| `betting.enabled` | `true` | Allow money bets |
| `betting.min-bet` | `100` | Minimum bet |
| `betting.max-bet` | `10000` | Maximum bet |
| `kits.classic` | Full inventory | Classic loadout (diamond sword, bow, golden apples, armor) |
| `kits.archer` | Full inventory | Archer loadout (bow-focused, chain armor) |
| `kits.tank` | Full inventory | Tank loadout (netherite, shield, golden apples) |
| `kits.soup` | Full inventory | Soup loadout (instant-heal soups) |
| `kits.uhc` | Full inventory | UHC loadout (no natural regen, fishing rod) |
| `messages.*` | Spanish | Inline messages |

### 8.5 Database Tables

Created by `DuelStatsManager.runMigrations()`:
- Duel win/loss records per player
- Kit preference tracking

### 8.6 Predefined Kits

| Kit | Signature Items | Special Rules |
|-----|----------------|---------------|
| Classic | Diamond sword + bow + 16 arrows + 5 golden apples | None |
| Archer | Power V bow + 64 arrows + chain armor | None |
| Tank | Netherite armor + shield + 10 golden apples | None |
| Soup | Mushroom stew ×32 + diamond sword | None |
| UHC | Diamond armor + fishing rod + bow | No natural regen |

---

## 9. EthernovaFFA

**Package:** `com.ethernova.ffa` · **~17 Java files** · **API version:** 1.21  
**Depends:** EthernovaCore

### 9.1 Java File Purpose Map

| File | Purpose |
|------|---------|
| `EthernovaFFA.java` | Main class. Registers managers, listeners, commands, scoreboards. |
| `FFACommand.java` | `/ffa` command (6 subcommands) |
| `FFAAdminCommand.java` | `/ffaadmin` command (arena, kit, reload) |
| `FFAManager.java` | FFA session management, join/leave, kill handling |
| `FFAArenaManager.java` | Arena CRUD and spawn points |
| `FFAKitManager.java` | Kit system |
| `FFAStatsManager.java` | Stats persistence |
| `FFAScoreboardManager.java` | Per-player scoreboard during FFA |
| `SpawnProtectionManager.java` | Post-respawn invincibility |
| `FFAPlayer.java` | FFA session model (kills, deaths, streak, kit) |
| `FFAKit.java` | Kit model |
| `FFAArena.java` | Arena model with multiple spawn points |
| `FFAKitGui.java` | Kit selection GUI |
| `FFAStatsGui.java` | Stats display GUI |
| `FFALeaderboardGui.java` | Top players GUI |
| `FFAListener.java` | Combat/death/item handling in FFA |
| `FFAItemListener.java` | Item pickup/drop restrictions |

### 9.2 Commands & Subcommands

| Command | Subcommand | Permission | Description |
|---------|-----------|------------|-------------|
| `/ffa` | `join [arena]` | `ethernova.ffa.use` | Join FFA |
| `/ffa` | `leave` | `ethernova.ffa.use` | Leave FFA |
| `/ffa` | `stats [player]` | `ethernova.ffa.use` | View FFA stats |
| `/ffa` | `kits` | `ethernova.ffa.use` | Open kit selection |
| `/ffa` | `top` | `ethernova.ffa.use` | Open leaderboard |
| `/ffa` | `arenas` | `ethernova.ffa.use` | List arenas |
| `/ffaadmin` | `arena <create\|delete\|addspawn\|list>` | `ethernova.ffa.admin` | Arena management |
| `/ffaadmin` | `kit <create\|delete\|list>` | `ethernova.ffa.admin` | Kit management |
| `/ffaadmin` | `reload` | `ethernova.ffa.admin` | Reload config |

Aliases: `ffajoin`

### 9.3 GUIs / Menus

| GUI | Description |
|-----|-------------|
| `FFAKitGui` | Kit selection with previews |
| `FFAStatsGui` | Personal stats: kills, deaths, KDR, best streak |
| `FFALeaderboardGui` | Top players board |

### 9.4 Configuration (config.yml)

| Path | Default | Description |
|------|---------|-------------|
| `general.default-arena` | String | Default FFA arena |
| `general.auto-join` | `false` | Join FFA on server join |
| `general.max-players` | `50` | Max FFA players |
| `respawn.delay` | `3` | Respawn delay (seconds) |
| `respawn.spawn-protection` | `5` | Invincibility after spawn |
| `respawn.glowing` | `true` | Glowing during protection |
| `kits.default` | String | Default kit |
| `kits.allow-change-alive` | `false` | Kit change while alive |
| `rewards.coins-per-kill` | `50` | Coins per kill |
| `rewards.xp-per-kill` | `10` | XP per kill |
| `rewards.coins-per-streak` | `25` | Bonus per streak kill |
| `rewards.xp-per-streak` | `5` | Bonus XP per streak |
| `killstreak.*` | Various | Streak broadcast/reward settings |
| `scoreboard.enabled` | `true` | Enable sidebar scoreboard |
| `scoreboard.title` | MiniMessage | Scoreboard title |
| `scoreboard.lines` | List | Scoreboard lines with placeholders |
| `protection.*` | Various | Spawn protection flags |
| `messages.*` | Spanish | Inline messages |

### 9.5 Database Tables

Created by `FFAStatsManager.runMigrations()`:
- FFA kills, deaths, best streaks per player

---

## 10. Cross-Plugin Architecture

### 10.1 Dependency Graph

```
EthernovaCore (foundation)
├── EthernovaCombat (hard depend)
├── EthernovaCosmetics (hard depend)
├── EthernovaParty (hard depend)
├── EthernovaProgression (hard depend)
├── EthernovaRanked (hard depend)
├── EthernovaDuels (hard depend)
├── EthernovaFFA (hard depend)
└── EthernovaClans (soft depend — works standalone)
```

### 10.2 Shared Services via Core

| Core Service | Used By |
|-------------|---------|
| `StorageManager` (HikariCP) | All plugins share connection pool |
| `ProfileManager` | Combat, Progression, Ranked, Cosmetics |
| `EventBus` | Combat ↔ Clans, Progression ↔ Combat |
| `EconomyHook` (Vault) | Combat, Clans, Duels, Cosmetics |
| `SoundManager` | All plugins |
| `CooldownManager` | Combat, Clans, Duels |
| `BoostManager` | Progression, Combat |
| `GuiManager` | Framework used by all plugins |
| `MigrationManager` | Ranked, Duels, FFA, Progression |

### 10.3 Inter-Plugin Communication

| Communication | Mechanism |
|--------------|-----------|
| Clan war → Combat profile switch | EventBus (`ClanWarStartEvent/EndEvent`) |
| Player kill → Progression XP | EventBus (`EthernovaPlayerKillEvent`) |
| Level up → Title/broadcast | EventBus (`LevelUpEvent`) |
| Duel end → Ranked ELO | EventBus (`DuelEndEvent`) |
| Combat tag → Clans teleport block | `CombatHook.isInCombat()` |
| Prestige → XP multiplier | EventBus (`PrestigeEvent`) |

---

## 11. Competitor Comparison

### 11.1 Core vs CMI / EssentialsX

| Feature | EthernovaCore | CMI | EssentialsX |
|---------|:---:|:---:|:---:|
| Multi-plugin architecture | ✅ | ❌ (monolithic) | ❌ (monolithic) |
| MiniMessage formatting | ✅ | ❌ (legacy) | ❌ (legacy) |
| Built-in boost system | ✅ | ✅ | ❌ |
| Custom EventBus | ✅ | ❌ | ❌ |
| Server mode detection | ✅ | ❌ | ❌ |
| Per-player locale | ✅ | ✅ | ✅ |
| **Missing vs CMI:** Warps, homes, teleport, economy commands, kits, spawn, back, fly, god mode, custom commands |
| **Missing vs EssentialsX:** Chat formatting, nick, mail, broadcast, AFK, MOTD |

> **Assessment:** Core deliberately avoids duplicating Essentials-style utility commands, focusing on being a service layer. This is a *design choice*, not a gap.

### 11.2 Combat vs CombatLogX / PvPManager

| Feature | EthernovaCombat | CombatLogX | PvPManager |
|---------|:---:|:---:|:---:|
| Combat tagging | ✅ | ✅ | ✅ |
| NPC on disconnect | ✅ | ✅ | ✅ |
| Newbie protection | ✅ | ❌ | ✅ |
| Anti-abuse (same IP) | ✅ | ❌ | ❌ |
| 3-tier sanctions | ✅ | ❌ | ❌ |
| Safe logout | ✅ | ❌ | ❌ |
| Loot protection | ✅ | ❌ | ❌ |
| Death recap | ✅ | ❌ | ❌ |
| Bounty system | ✅ | ❌ | ❌ |
| Killstreak abilities | ✅ | ❌ | ❌ |
| Combo system | ✅ | ❌ | ❌ |
| Multiple combat profiles | ✅ | ❌ | ❌ |
| Per-world config | ✅ | ✅ | ✅ |
| Admin GUI | ✅ | ❌ | ❌ |
| **Missing:** Grace period toggle (CombatLogX), force field mode (CombatLogX) |

> **Assessment:** Significantly more feature-rich than both competitors with bounties, combos, killstreaks, death recap, and multi-profile support.

### 11.3 Clans vs SimpleClans / UltimateClans / Towny / Factions

| Feature | EthernovaClans | SimpleClans | UltimateClans | Towny | MassiveCore Factions |
|---------|:---:|:---:|:---:|:---:|:---:|
| Clan creation/management | ✅ | ✅ | ✅ | ✅ | ✅ |
| Territory claiming | ✅ | ✅ | ✅ | ✅ | ✅ |
| Power system | ✅ | ❌ | ✅ | ❌ | ✅ |
| Wars | ✅ | ✅ | ✅ | ✅ | ❌ |
| Alliances | ✅ | ✅ | ✅ | ✅ | ✅ |
| Nations | ✅ | ❌ | ❌ | ✅ | ❌ |
| Bank system | ✅ | ❌ | ✅ | ✅ | ❌ |
| Upgrades | ✅ | ❌ | ✅ | ❌ | ❌ |
| Clan levels | ✅ | ❌ | ❌ | ❌ | ❌ |
| Achievements | ✅ | ❌ | ❌ | ❌ | ❌ |
| Missions | ✅ | ❌ | ❌ | ❌ | ❌ |
| Blueprints/Structures | ✅ | ❌ | ❌ | ❌ | ❌ |
| Outposts | ✅ | ❌ | ❌ | ✅ | ❌ |
| Spy/Infiltration | ✅ | ❌ | ❌ | ❌ | ❌ |
| Seasons | ✅ | ❌ | ❌ | ❌ | ❌ |
| Web map | ✅ | ❌ | ❌ | ✅ (via Dynmap) | ❌ |
| Discord webhooks | ✅ | ❌ | ✅ | ✅ | ❌ |
| Territory flags | ✅ | ❌ | ✅ | ✅ | ✅ |
| Custom banners | ✅ | ❌ | ❌ | ❌ | ❌ |
| Audit logging | ✅ | ❌ | ❌ | ❌ | ❌ |
| Salary system | ✅ | ❌ | ❌ | ✅ | ❌ |
| Tax system | ✅ | ❌ | ❌ | ✅ | ❌ |
| 6-language i18n | ✅ | ✅ | ❌ | ✅ | ✅ |
| 30+ GUIs | ✅ | ❌ | ✅ | ❌ | ❌ |
| Territory fly | ✅ | ❌ | ✅ | ✅ | ❌ |
| Scheduled events | ✅ | ❌ | ❌ | ❌ | ❌ |
| Skills system | ✅ | ❌ | ❌ | ❌ | ❌ |
| Hologram integration | ✅ | ❌ | ❌ | ❌ | ❌ |
| **Missing vs Towny:** Plots/sub-zones, town/nation taxes with jail, mayor elections, town assistants |
| **Missing vs Factions:** Faction relation colors in tab |

> **Assessment:** Best-in-class feature set. Combines the power system of Factions, the nations of Towny, and adds unique features (spy, blueprints, seasons, missions, scheduled events, skills) not found in any competitor.

### 11.4 Progression vs AureliumSkills / mcMMO

| Feature | EthernovaProgression | AureliumSkills | mcMMO |
|---------|:---:|:---:|:---:|
| Leveling system | ✅ | ✅ | ✅ |
| Prestige | ✅ | ❌ | ❌ |
| Achievements | ✅ | ❌ | ❌ |
| Missions | ✅ | ❌ | ❌ |
| Battle pass | ✅ | ❌ | ❌ |
| Multiple skill trees | ❌ | ✅ | ✅ |
| Custom abilities | ❌ | ✅ | ✅ |
| Party XP share | ❌ | ✅ | ✅ |
| **Missing:** Individual skill trees (mining, combat, etc.), custom abilities per skill, party XP sharing |

### 11.5 Ranked vs EloSystem / PvPRank

| Feature | EthernovaRanked | Typical ELO Plugins |
|---------|:---:|:---:|
| Variable K-factor | ✅ | ❌ (fixed K) |
| Placement matches | ✅ | ❌ |
| 8 rank tiers | ✅ | ✅ (typically 5-6) |
| Season system | ✅ | ❌ |
| Season archives | ✅ | ❌ |
| Win streak tracking | ✅ | ❌ |
| Leaderboard caching | ✅ | ❌ |
| GUI displays | ✅ | ❌ |

### 11.6 Duels vs Duels (realized) / PvPManager Duels

| EthernovaDuels feature | Status | Competitors |
|------------------------|--------|-------------|
| Kit system (5 presets) | ✅ | Most have 3-4 |
| Betting system | ✅ | Rare |
| Spectating | ✅ | Some |
| Arena management | ✅ | Most |
| No-natural-regen rule | ✅ | Rare |
| **Missing:** Queue system, ranked duels integration, tournament bracket, custom kit creation by players |

### 11.7 FFA vs FFA plugins

| EthernovaFFA feature | Status | Competitors |
|---------------------|--------|-------------|
| Multi-arena | ✅ | Most |
| Kit system | ✅ | Most |
| Scoreboard | ✅ | Some |
| Spawn protection | ✅ | Some |
| Streak rewards | ✅ | Rare |
| Leaderboard GUI | ✅ | Rare |
| **Missing:** Ability/perk system, map rotation, team FFA mode |

---

## 12. Global Code Quality Issues

### 12.1 No TODOs / FIXMEs Found

A grep for `TODO`, `FIXME`, `HACK`, `TEMP`, `WORKAROUND` across all 329 Java files returned **zero actual markers** — only false positives from variable names (`tempMax`) and English words in messages (`attempt`). The codebase appears clean of technical debt markers.

### 12.2 Identified Code Quality Concerns

#### Architecture Issues

| Issue | Severity | Location | Description |
|-------|----------|----------|-------------|
| **God class** | Medium | `ClanCommandExecutor.java` (1890 lines) | Single class handles 40+ subcommands. Should be split into sub-handlers (e.g., `NationSubcommand`, `OutpostSubcommand`, `SpySubcommand`). |
| **Hardcoded Spanish in Ranked** | High | `RankedManager.java:260-290` | ELO change messages are hardcoded in Spanish (`"¡Racha de"`, `"Ascendiste a"`, `"sin pérdida"`) instead of using MessageManager. |
| **Nation help hardcoded Spanish** | High | `ClanCommandExecutor.java:1470-1483` | Nation and outpost help descriptions are hardcoded in Spanish, not from message files. |
| **Spy help hardcoded Spanish** | High | `ClanCommandExecutor.java:1720-1725` | Spy help descriptions hardcoded in Spanish. |
| **Outpost help hardcoded Spanish** | High | `ClanCommandExecutor.java:1597-1603` | Outpost help descriptions hardcoded in Spanish. |
| **In-memory parties** | Medium | `EthernovaParty` | Parties lost on restart. No persistence option. Acceptable for casual use but problematic for larger servers. |
| **Combat has no own DB tables** | Low | `EthernovaCombat` | Stores all data via Core's `ethernova_profile_data` key-value store. Limits query capabilities (no SQL aggregation for combat stats). |
| **Inline messages** | Medium | Cosmetics, Party, FFA, Duels, Ranked, Progression | Messages defined inline in `config.yml` rather than separate message files. Makes translation harder — admins must edit config to change messages. Only Core, Combat, and Clans have proper separate message files. |

#### Thread Safety

| Issue | Severity | Location | Description |
|-------|----------|----------|-------------|
| **Potential race in profile merge** | Low | `CorePlayerListener.java` | Profile registered sync, DB merge async. If plugin code accesses profile before merge completes, it gets default values. Mitigated by "registerIfAbsent" pattern but not fully safe. |
| **RankedManager concurrent saves** | Low | `RankedManager.java` | `processResult()` modifies profiles and calls `saveProfile()` async. If two kills process simultaneously for the same player, dirty flag could cause lost writes. Mitigated by ConcurrentHashMap but profile mutations aren't atomic. |

#### Input Validation

| Issue | Severity | Location | Description |
|-------|----------|----------|-------------|
| **OfflinePlayerIfCached** | Low | `ClanCommandExecutor.java:687-701` | Ban/unban uses `getOfflinePlayerIfCached()` which returns null if player never joined this session. Could silently fail for never-online players. |
| **No bet validation in duels** | Low | `DuelCommand.java` | Bet amount parsed but no check if target player can afford the bet before sending request. |

#### Missing Error Handling

| Issue | Severity | Description |
|-------|----------|-------------|
| **Silent migration failures** | Medium | Schema migrations log errors but continue. A failed migration could leave tables in inconsistent state. |
| **No connection retry** | Medium | HikariCP configured but no explicit retry logic for transient DB errors. HikariCP handles pool-level retries but app-level queries could fail silently. |

### 12.3 Good Practices Observed

| Practice | Description |
|----------|-------------|
| **Async DB operations** | All plugins use `CompletableFuture` or `runTaskAsynchronously` for DB work |
| **MigrationManager pattern** | Clean versioned migrations for schema evolution |
| **Audit logging** | Clans module logs all significant actions with player, action, and detail |
| **Dirty flag pattern** | RankedProfile uses dirty flag for efficient saves |
| **Leaderboard caching** | Time-based cache to avoid repeated expensive DB queries |
| **EventBus decoupling** | Plugins communicate via events, not direct references |
| **Combat profiles** | Different combat configs per game mode (survival/war/arena/ffa) |
| **Modular design** | Each feature is a separate manager, easily disabled |
| **Tab completion** | Every command has comprehensive tab completion |
| **Permission hierarchy** | Fine-grained permissions per command and feature |
| **Cooldown system** | Named cooldowns prevent abuse |
| **Warmup teleportation** | Teleports have warmup (cancelled on move/combat) |
| **Batch saves** | Periodic auto-save reduces DB writes |

---

## 13. i18n Documentation

### 13.1 Language Support Matrix

| Plugin | Separate Files | Languages | Message Count (approx) |
|--------|:-:|---|---|
| **EthernovaCore** | ✅ | `en`, `es` | ~10 messages |
| **EthernovaCombat** | ✅ | `en`, `es` | ~80 messages (14 sections) |
| **EthernovaClans** | ✅ | `en`, `es`, `de`, `fr`, `pt`, `zh` | ~1183 lines / ~400+ messages |
| **EthernovaCosmetics** | ❌ | Inline (Spanish only) | ~15 messages |
| **EthernovaParty** | ❌ | Inline (Spanish only) | ~25 messages |
| **EthernovaProgression** | ❌ | Inline (Spanish only) | ~30 messages |
| **EthernovaRanked** | ❌ | Inline (Spanish only) + hardcoded Spanish in Java | ~20 messages |
| **EthernovaDuels** | ❌ | Inline (Spanish only) | ~30 messages |
| **EthernovaFFA** | ❌ | Inline (Spanish only) | ~25 messages |

### 13.2 Message Format

All messages use **MiniMessage** format (Adventure API):
```yaml
"<gradient:#A855F7:#6366F1>EthernovaClans</gradient> <dark_gray>»</dark_gray>"
"<red>✘</red> <gray>You don't have permission.</gray>"
"<click:run_command:/clan join {clan}><yellow>[Click]</yellow></click>"
```

Placeholders use `{name}` curly-brace format: `{player}`, `{clan}`, `{amount}`, `{time}`, etc.

### 13.3 Clans Message Sections (messages_en.yml — 1183 lines)

| Section | Key Count | Content |
|---------|-----------|---------|
| `general` | 12 | Prefix, permissions, errors, cooldowns |
| `error` | 10 | Generic error messages |
| `clan` | ~60 | Creation, disband, invite, join, leave, kick, promote, demote, info, list, top, transfer, desc, ban, level, home, warps |
| `chat` | 8 | Clan/ally/officer/nation chat toggles |
| `territory` | 15 | Claim, unclaim, autoclaim, flags, enter/leave messages |
| `alliance` | 10 | Request, accept, deny, break, rival |
| `war` | 15 | Declare, accept, surrender, score, victory/defeat |
| `upgrade` | 8 | Purchase, max level, insufficient funds |
| `bank` | 10 | Deposit, withdraw, balance, insufficient funds |
| `level` | 8 | Info, level up, XP |
| `audit` | 3 | Header, entry, no-records |
| `map` | 4 | Map display elements |
| `warp` | 6 | Set, delete, list, teleport |
| `nation` | 25 | All nation management messages |
| `outpost` | 15 | Place, remove, upgrade, list, info |
| `spy` | 12 | Social spy, infiltrate, intel |
| `admin` | 10 | Admin operation feedback |
| `shield` | 3 | Shield activation/expiry |
| `mission` | 5 | Mission complete, progress |
| `achievement` | 5 | Unlock, progress |
| `season` | 5 | Season start/end, rankings |
| `webmap` | 5 | Account management |
| `help` | 30+ | All help text entries |

### 13.4 i18n Gaps and Recommendations

| Gap | Impact | Recommendation |
|-----|--------|----------------|
| **6 plugins have inline-only messages** | Cannot be translated without editing config.yml | Extract messages to separate `messages_<lang>.yml` files for Cosmetics, Party, Progression, Ranked, Duels, FFA |
| **Hardcoded Spanish in RankedManager** | ELO feedback always in Spanish | Move all strings to message files |
| **Help descriptions hardcoded** | Nation/outpost/spy help always in Spanish | Move to message files |
| **Cosmetics Spanish-only** | No English or other language | Create separate message files |
| **No language auto-detection** | Manual `/lang` command only | Consider client locale detection via `PlayerLocaleChangeEvent` |
| **Combat has full i18n, Duels doesn't** | Inconsistent experience | Standardize approach across all plugins |

---

## Summary Statistics

| Metric | Value |
|--------|-------|
| Total Java files | 329 |
| Total YAML config files | ~70 (unique, excluding target/) |
| Total commands | 15 base commands with ~100+ subcommands |
| Total GUI screens | ~50 |
| Total DB tables | ~15+ |
| Total PAPI placeholders | ~60 |
| Total Bukkit event handlers | ~40 |
| Total custom EventBus events | 9 |
| Languages supported (Clans) | 6 (en, es, de, fr, pt, zh) |
| Languages supported (other) | 1-2 (es, some en) |
| Line count (largest file) | 1890 (ClanCommandExecutor) |
| Line count (Clans messages_en) | 1183 |
