# Comprehensive GUI/Menu Audit Report — EthernovaClans

**Date:** 2025  
**Scope:** All GUI/Menu classes across ALL modules  
**Total GUI files found:** 68+

---

## Table of Contents

1. [GUI Frameworks Overview](#1-gui-frameworks-overview)
2. [Core Module GUIs](#2-core-module-guis)
3. [Cosmetics Module GUIs](#3-cosmetics-module-guis)
4. [FFA Module GUIs](#4-ffa-module-guis)
5. [Duels Module GUIs](#5-duels-module-guis)
6. [Party Module GUIs](#6-party-module-guis)
7. [Ranked Module GUIs](#7-ranked-module-guis)
8. [Progression Module GUIs](#8-progression-module-guis)
9. [Combat Module GUIs](#9-combat-module-guis)
10. [Clans Module GUIs](#10-clans-module-guis)
11. [Issues & Recommendations](#11-issues--recommendations)
12. [Listener Registration Summary](#12-listener-registration-summary)

---

## 1. GUI Frameworks Overview

The project uses **four distinct GUI handling mechanisms**:

### Framework A: CoreGui / PaginatedGui (core module)
- **Base class:** `com.ethernova.core.gui.CoreGui`
- **Paginated extension:** `com.ethernova.core.gui.PaginatedGui extends CoreGui`
- **Router/Listener:** `com.ethernova.core.gui.GuiManager implements Listener`
- **Registration:** `EthernovaCore.onEnable()` line 125 — `getServer().getPluginManager().registerEvents(guiManager, this)`
- **How it works:**
  1. GUI calls `openInventory(title, size)` → creates `Bukkit.createInventory()`, calls `fillBorders()`, `populateItems()`, registers via `core.getGuiManager().registerGui(player, this)`, opens for player
  2. `GuiManager.onInventoryClick()` (`@EventHandler(priority=HIGH)`) → finds registered CoreGui → calls `gui.handleClick(event)`
  3. `CoreGui.handleClick()` → `event.setCancelled(true)` → looks up `slotActions` map → calls `processAction(action, slot, event)` (abstract, implemented by subclass)
- **Event cancellation:** ✅ Always cancelled in `CoreGui.handleClick()`
- **Used by:** core, ffa, duels, party, ranked, progression, cosmetics modules

### Framework B: AbstractGui (clans module)
- **Base class:** `com.ethernova.clans.gui.AbstractGui` (852 lines)
- **Router:** `com.ethernova.clans.gui.GUIManager` (325 lines)
- **Listener:** `com.ethernova.clans.listener.GUIListener`
- **Registration:** `EthernovaClans.onEnable()` line 531 — `pm.registerEvents(new GUIListener(this), this)`
- **How it works:**
  1. `AbstractGui.open()` → loads layout from YAML via `ConfigurableGUI`, builds inventory, calls `fillBackground()`, `placeConfigItems()`, `populateItems()`, registers via `plugin.getGuiManager().registerGui(player, this)`
  2. `GUIListener.onClick(InventoryClickEvent)` → checks `plugin.getGuiManager().isInMenu()` → delegates to `GUIManager.handleClick()`
  3. `GUIManager.handleClick()` → `event.setCancelled(true)` → routes to `AbstractGui.handleClick()`
  4. `AbstractGui.handleClick()` → `event.setCancelled(true)` again → debounce → resolves action → `processAction()` → `handleCommonAction()` → `onClick()`
- **Supports:** Compound actions (`;;`), bracket-style actions (`[open]`, `[close]`, `[command]`, `[message]`, `[sound]`), legacy actions (`CLOSE`, `BACK`, `OPEN_GUI:xxx`)
- **Event cancellation:** ✅ Cancelled in both GUIManager and AbstractGui
- **Used by:** All ~30 clans GUI subclasses

### Framework C: ConfigurableGUI (clans module — pure YAML)
- **Class:** `com.ethernova.clans.gui.ConfigurableGUI` (354 lines)
- **Purpose:** Fully data-driven GUIs loaded entirely from YAML files (no Java subclass needed)
- **How it works:**
  1. `open(player, guiName)` → loads YAML, creates inventory with fill/border, places configured items with conditions, supports dynamic member lists, registers via `GUIManager.registerConfigGUI()`
  2. Click handling via `handleClick(player, guiName, event)` → finds item by slot in YAML → executes action list
- **Actions:** `[close]`, `[open]`, `[command]`, `[console]`, `[message]`, `[sound]`, `[title]`
- **Event cancellation:** ✅ Cancelled by parent GUIManager before routing
- **Used by:** Optional YAML-only GUIs in the clans module

### Framework D: Raw Inventory (combat + cosmetics auras)
- **Combat:** `AdminGUIManager` + `AdminGUIListener` — uses `Bukkit.createInventory()` with `GUIType` enum tracking per player UUID
- **Cosmetics Auras:** `AuraGUIManager` — uses `Bukkit.createInventory()` with `§`-prefixed legacy titles, routed via title-string matching in `CosmeticListener`
- **Event cancellation:** ✅ Cancelled in respective listeners

---

## 2. Core Module GUIs

All extend `CoreGui` or `PaginatedGui`. All handled by `core.gui.GuiManager`.

| # | Class | Path | Base | Size | Purpose | Click Actions | Purchase/Equip | Issues |
|---|-------|------|------|------|---------|---------------|----------------|--------|
| 1 | `MainMenuGui` | `core/src/main/java/com/ethernova/core/gui/MainMenuGui.java` | CoreGui | 45 | Main hub — FFA, Duels, Ranked, Clans, Party, Shop, Cosmetics, Settings, Rankings | Routes via `player.performCommand()` | ❌ N/A | ✅ None |
| 2 | `AdminGui` | `core/src/main/java/com/ethernova/core/gui/AdminGui.java` | CoreGui | 54 | Server admin panel — status, boosts, reload, save, maintenance, debug, module admin launchers | Toggle/action per slot | ❌ N/A | ✅ None |
| 3 | `PlayerSettingsGui` | `core/src/main/java/com/ethernova/core/gui/PlayerSettingsGui.java` | CoreGui | 45 | 20 toggleable settings in 4 categories + 3-state time cycle | Toggle settings, saves to profile | ❌ N/A | ✅ None |
| 4 | `RankingsGui` | `core/src/main/java/com/ethernova/core/gui/RankingsGui.java` | CoreGui | 54 | Top players leaderboard — kills, deaths, kdr, coins, level, wins, killstreak | Category selection + player heads | ❌ N/A | ✅ None |
| 5 | `ConfirmationGui` | `core/src/main/java/com/ethernova/core/gui/ConfirmationGui.java` | CoreGui | 27 | Yes/No confirmation dialog | Runs `onConfirm`/`onDeny` Runnables | ❌ N/A | ✅ None |
| 6 | `KitEditorGui` | `core/src/main/java/com/ethernova/core/gui/KitEditorGui.java` | CoreGui | 45 | Kit slot rearrangement GUI | Swap mechanic, save/reset | ❌ N/A | ✅ None |

---

## 3. Cosmetics Module GUIs

### 3a. CoreGui-based Cosmetics GUIs

All handled by `core.gui.GuiManager`. Listener registered in `EthernovaCosmetics.onEnable()` — but these use the core GuiManager, so they rely on `EthernovaCore`'s listener registration.

| # | Class | Path | Base | Size | Purpose | Click Actions | Purchase/Equip | Issues |
|---|-------|------|------|------|---------|---------------|----------------|--------|
| 7 | `CosmeticsMainGui` | `cosmetics/src/main/java/com/ethernova/cosmetics/gui/CosmeticsMainGui.java` | PaginatedGui | Paginated | Main cosmetics menu — type buttons, shop, mystery boxes, collection, auras | Opens sub-GUIs | ❌ N/A (navigates) | ✅ None |
| 8 | `CosmeticTypeGui` | `cosmetics/src/main/java/com/ethernova/cosmetics/gui/CosmeticTypeGui.java` | PaginatedGui | Paginated | Shows all cosmetics of a given type | Left-click: buy/equip/unequip; Right-click: preview; Pet head/floor toggle; Unequip button at slot 46 | ✅ Full purchase (coin check, permission check, deduction, unlock), equip, unequip, preview | ✅ None |
| 9 | `CosmeticShopGui` | `cosmetics/src/main/java/com/ethernova/cosmetics/gui/CosmeticShopGui.java` | PaginatedGui | Paginated | All purchasable cosmetics sorted by price | `BUY_` action with coin check, permission check, deduction, unlock | ✅ Full purchase logic | ✅ None |
| 10 | `MysteryBoxGui` | `cosmetics/src/main/java/com/ethernova/cosmetics/gui/MysteryBoxGui.java` | PaginatedGui | Paginated | Mystery box display with rarity weights | Delegates to `MysteryBoxManager.openBox()` | ✅ Purchase via MysteryBoxManager | ✅ None |
| 11 | `CollectionGui` | `cosmetics/src/main/java/com/ethernova/cosmetics/gui/CollectionGui.java` | PaginatedGui | Paginated | Collection progress per type/rarity with progress bars | Click navigates to `CosmeticTypeGui` | ❌ N/A (navigates) | ✅ None |
| 12 | `CosmeticsAdminGui` | `cosmetics/src/main/java/com/ethernova/cosmetics/gui/CosmeticsAdminGui.java` | CoreGui | 54 | Admin config — toggle types, adjust trail/projectile/win-effect, cycle sounds, reload | Toggle/adjust/reload | ❌ N/A | ✅ None |

### 3b. AuraGUIManager (Raw Inventory — Framework D)

| # | Class | Path | Base | Lines | Purpose |
|---|-------|------|------|-------|---------|
| 13 | `AuraGUIManager` | `cosmetics/src/main/java/com/ethernova/cosmetics/aura/AuraGUIManager.java` | None (raw) | 1018 | Manages ALL aura GUIs: tiers, tier auras, patterns, fusions, slots, advanced config, per-aura settings |

**Inventory creation:** `Bukkit.createInventory(null, size, "§..." + title)` with legacy `§`-prefixed color codes.

**Click routing:** Via `CosmeticListener.onInventoryClick()` (EventPriority.HIGH) at lines 360-414. Strips color codes from inventory title, matches against known strings:
- `"SELECCIONAR TIER"` → `handleTiersClick()`
- `"BASIC AURAS"`, `"ADVANCED AURAS"`, `"LEGENDARY AURAS"`, `"MYTHIC AURAS"`, `"DIVINE AURAS"` → `handleTierAurasClick()`
- `"PATRONES:"` → `handlePatternsClick()`
- `"FUSIÓN DE AURAS"` → `handleFusionClick()`
- `"GESTIÓN DE SLOTS"` → `handleSlotsClick()`
- `"CONFIGURAR "` → `handleAuraConfigClick()`

**Event cancellation:** ✅ Cancelled in `CosmeticListener` before routing.

**Purchase/Equip logic:** ✅ Full purchase (coin check, deduction, unlock), activate/deactivate, slot management, pattern unlock, fusion.

**Listener registration:** `CosmeticListener` registered in `EthernovaCosmetics.onEnable()` line 108.

**⚠ CRITICAL ISSUE:** Title-based routing is fragile — any title string change would silently break click handling. See [Issues](#11-issues--recommendations).

---

## 4. FFA Module GUIs

All extend `CoreGui` or `PaginatedGui`. Click handling via `core.gui.GuiManager`.

| # | Class | Path | Base | Size | Purpose | Click Actions | Purchase/Equip | Issues |
|---|-------|------|------|------|---------|---------------|----------------|--------|
| 14 | `FFAKitGui` | `ffa/src/main/java/com/ethernova/ffa/gui/FFAKitGui.java` | CoreGui | 45 | Kit selection for FFA | `KIT:` action changes kit via `FFAManager` | ❌ N/A | ⚠ Redundant `registerGui()` call (see Issues) |
| 15 | `FFAStatsGui` | `ffa/src/main/java/com/ethernova/ffa/gui/FFAStatsGui.java` | CoreGui | 45 | Stats display (display-only) | `processAction` returns false (display-only) | ❌ N/A | ⚠ Redundant `registerGui()` call |
| 16 | `FFALeaderboardGui` | `ffa/src/main/java/com/ethernova/ffa/gui/FFALeaderboardGui.java` | PaginatedGui | Paginated | Async leaderboard with player heads | Click opens `FFAStatsGui` for that player | ❌ N/A | ⚠ Redundant `registerGui()` call |
| 17 | `FFAAdminGui` | `ffa/src/main/java/com/ethernova/ffa/gui/FFAAdminGui.java` | CoreGui | 54 | 2-page admin config — toggles, int/double adjustments, reload, cycle lang/kit | Toggle/adjust/reload | ❌ N/A | ✅ None |

---

## 5. Duels Module GUIs

All extend `CoreGui`. Click handling via `core.gui.GuiManager`.

| # | Class | Path | Base | Size | Purpose | Click Actions | Purchase/Equip | Issues |
|---|-------|------|------|------|---------|---------------|----------------|--------|
| 18 | `DuelGui` | `duels/src/main/java/com/ethernova/duels/gui/DuelGui.java` | CoreGui | 36 | Kit selection for duel request | `KIT_` action sends duel request | ❌ N/A | ⚠ Redundant `registerGui()` call |
| 19 | `QueueKitGui` | `duels/src/main/java/com/ethernova/duels/gui/QueueKitGui.java` | CoreGui | 36 | Kit selection for matchmaking queue | `QUEUE_` action joins queue | ❌ N/A | ⚠ Redundant `registerGui()` call |
| 20 | `DuelStatsGui` | `duels/src/main/java/com/ethernova/duels/gui/DuelStatsGui.java` | CoreGui | 45 | Stats display (display-only) | `processAction` returns false | ❌ N/A | ⚠ Redundant `registerGui()` call |
| 21 | `DuelsAdminGui` | `duels/src/main/java/com/ethernova/duels/gui/DuelsAdminGui.java` | CoreGui | 54 | Full admin config — toggle/int/double adjustments | Toggle/adjust/reload | ❌ N/A | ✅ None |

---

## 6. Party Module GUIs

All extend `CoreGui` or `PaginatedGui`. Click handling via `core.gui.GuiManager`.

| # | Class | Path | Base | Size | Purpose | Click Actions | Purchase/Equip | Issues |
|---|-------|------|------|------|---------|---------------|----------------|--------|
| 22 | `PartyGui` | `party/src/main/java/com/ethernova/party/gui/PartyGui.java` | CoreGui | 54 | Party management — member heads with role-based actions (promote, demote, kick), chat toggle, settings, ready check, teleport, party list, leave/disband | Full party management | ❌ N/A | ✅ None |
| 23 | `PartySettingsGui` | `party/src/main/java/com/ethernova/party/gui/PartySettingsGui.java` | CoreGui | 45 | Party settings — friendly fire, public/private, max size, moderator invites, party chat | Toggle settings, saves immediately | ❌ N/A | ⚠ Redundant `registerGui()` call in `open()` before `openInventory()` |
| 24 | `PartyListGui` | `party/src/main/java/com/ethernova/party/gui/PartyListGui.java` | PaginatedGui | Paginated | Public party browser — shows all non-full public parties | Click to join party | ❌ N/A | ⚠ Redundant `registerGui()` call |
| 25 | `PartyAdminGui` | `party/src/main/java/com/ethernova/party/gui/PartyAdminGui.java` | CoreGui | 54 | 2-page admin config — party settings, buffs, rewards, teleport, sounds | Toggle/int adjustments, reload | ❌ N/A | ✅ None |

---

## 7. Ranked Module GUIs

All extend `CoreGui` or `PaginatedGui`. Click handling via `core.gui.GuiManager`.

| # | Class | Path | Base | Size | Purpose | Click Actions | Purchase/Equip | Issues |
|---|-------|------|------|------|---------|---------------|----------------|--------|
| 26 | `RankedGui` | `ranked/src/main/java/com/ethernova/ranked/gui/RankedGui.java` | CoreGui | 45 | Ranked card — rank icon, ELO, stats, streak, season, progress bar | Leaderboard button, close | ❌ N/A | ✅ None |
| 27 | `LeaderboardGui` | `ranked/src/main/java/com/ethernova/ranked/gui/LeaderboardGui.java` | PaginatedGui | Paginated | Ranked leaderboard — async loaded, player heads with rank/ELO/stats | Click on player (no-op, plays sound) | ❌ N/A | ✅ None |
| 28 | `RankedAdminGui` | `ranked/src/main/java/com/ethernova/ranked/gui/RankedAdminGui.java` | CoreGui | 54 | Full admin config — season, Glicko-2 params, streaks, decay, leaderboard | Toggle/int/decimal adjustments, reload | ❌ N/A | ✅ None |

---

## 8. Progression Module GUIs

All extend `CoreGui` or `PaginatedGui`. Click handling via `core.gui.GuiManager`.

| # | Class | Path | Base | Size | Purpose | Click Actions | Purchase/Equip | Issues |
|---|-------|------|------|------|---------|---------------|----------------|--------|
| 29 | `LevelGui` | `progression/src/main/java/com/ethernova/progression/gui/LevelGui.java` | CoreGui | 45 | Level progress, prestige, XP bar, boost info | Navigation to achievements/missions/battlepass | ❌ N/A | ✅ None |
| 30 | `BattlePassGui` | `progression/src/main/java/com/ethernova/progression/gui/BattlePassGui.java` | PaginatedGui | Paginated | Battle pass tiers — free + premium rewards | Click to claim reward (tier validation, inventory check) | ✅ Reward claiming (free + premium) | ✅ None |
| 31 | `MissionGui` | `progression/src/main/java/com/ethernova/progression/gui/MissionGui.java` | CoreGui | 54 | Daily/weekly missions with progress bars, streak info | `processAction` only handles CLOSE | ❌ N/A (display-only) | ✅ None |
| 32 | `AchievementGui` | `progression/src/main/java/com/ethernova/progression/gui/AchievementGui.java` | PaginatedGui | Paginated | Category selection → paginated achievement list with progress | Category nav + achievement display | ❌ N/A (display-only) | ✅ None |
| 33 | `ProgressionAdminGui` | `progression/src/main/java/com/ethernova/progression/gui/ProgressionAdminGui.java` | CoreGui | 54 | 2-page admin config — XP, levels, prestige, missions, battle pass, achievements | Toggle/int/decimal adjustments, reload | ❌ N/A | ✅ None |

---

## 9. Combat Module GUIs

Uses **Framework D** (raw inventories with custom listener).

| # | Class | Path | Lines | Purpose |
|---|-------|------|-------|---------|
| 34 | `AdminGUIManager` | `combat/src/main/java/com/ethernova/combat/gui/AdminGUIManager.java` | 944 | Manages 13 different admin GUI screens via `GUIType` enum |
| 35 | `AdminGUIListener` | `combat/src/main/java/com/ethernova/combat/gui/AdminGUIListener.java` | 557 | Bukkit Listener, routes clicks based on tracked `GUIType` per player UUID |
| 36 | `GUIHelper` | `combat/src/main/java/com/ethernova/combat/gui/GUIHelper.java` | — | Static utility class for item creation |

**GUIType enum screens:** `MAIN`, `COMBAT_SETTINGS`, `KILLSTREAK_SETTINGS`, `BOUNTY_SETTINGS`, `DEATH_SETTINGS`, `COMBAT_TAG_SETTINGS`, `REWARD_SETTINGS`, `TOTEM_SETTINGS`, `SOUND_SETTINGS`, `WORLD_SETTINGS`, `SCOREBOARD_SETTINGS`, `INTEGRATION_SETTINGS`, `PERFORMANCE_SETTINGS`

**Inventory creation:** `Bukkit.createInventory(null, size, MiniMessage.miniMessage().deserialize(title))`

**Click routing:** `AdminGUIListener.onClick(InventoryClickEvent)`:
1. `event.setCancelled(true)`
2. Looks up `GUIType` from `AdminGUIManager.getPlayerGUIType(player.getUniqueId())`
3. Routes to appropriate handler method based on `GUIType`
4. Also handles Bounty GUI via title matching (`"Bounties"`)

**Event cancellation:** ✅ Cancelled in `AdminGUIListener.onClick()`

**Listener registration:** `AdminGUIListener` registered in `EthernovaCombat.registerListeners()` line 187.

---

## 10. Clans Module GUIs

All extend `AbstractGui` (Framework B). Click handling via `GUIListener` → `GUIManager` → `AbstractGui.handleClick()`.

| # | Class | Purpose |
|---|-------|---------|
| 37 | `ClanMainGui` | Main clan menu — info overview, navigation hub |
| 38 | `MembersGui` | Member list with role management |
| 39 | `BankGui` | Clan bank deposits/withdrawals |
| 40 | `TerritoryMapGui` | Territory/chunk map visualization |
| 41 | `WarsGui` | Clan wars display and management |
| 42 | `SettingsGui` | Clan settings configuration |
| 43 | `TopsGui` | Clan rankings/leaderboards |
| 44 | `UpgradesGui` | Clan upgrades with purchase logic |
| 45 | `ProgressGui` | Clan progress/experience display |
| 46 | `DiplomacyGui` | Alliance/rivalry management |
| 47 | `ColorPickerGui` | Clan color selection |
| 48 | `MissionsGui` | Clan missions |
| 49 | `AchievementsGui` | Clan achievements |
| 50 | `BoostsGui` | Active clan boosts |
| 51 | `PermissionsGui` | Role permission management |
| 52 | `AuditLogGui` | Clan action log |
| 53 | `InvitationsGui` | Pending invitations |
| 54 | `InvitePlayersGui` | Invite player search |
| 55 | `AdminMainGui` | Admin main panel |
| 56 | `AdminClanListGui` | Admin clan browser |
| 57 | `AdminClanGui` | Admin single-clan management |
| 58 | `AdminPlayerGui` | Admin player management |
| 59 | `ClanSkillsGui` | Clan skill tree |
| 60 | `ClanShopGui` | Clan shop with purchase logic |
| 61 | `EventCalendarGui` | Clan events calendar |
| 62 | `TrophiesGui` | Clan trophies display |
| 63 | `StatsGui` | Clan statistics |
| 64 | `WarpsGui` | Clan warps management |
| 65 | `IconSelectorGui` | Clan icon selection |
| 66 | `BlueprintMenuGui` | Base blueprints menu |
| 67 | `BlueprintAdminGui` | Admin blueprint management |
| 68 | `SeasonGui` | Season pass/progress |

**All clans GUIs share:**
- ✅ Event cancellation via `AbstractGui.handleClick()` → `event.setCancelled(true)`
- ✅ YAML-configurable layouts via `ConfigurableGUI`
- ✅ Common action handling (close, back, open_gui, command, message, sound)
- ✅ Debounce protection (300ms cooldown between clicks)
- ✅ Properly registered via `GUIManager.registerGui()`

**Purchase/Equip in clans GUIs:**
- `UpgradesGui` — clan upgrade purchases (bank deduction)
- `ClanShopGui` — shop item purchases
- `ClanSkillsGui` — skill point spending

---

## 11. Issues & Recommendations

### 🔴 Critical Issues

#### 1. AuraGUIManager title-based routing is fragile
**Location:** `CosmeticListener.onInventoryClick()` lines 360-414  
**Problem:** Click routing depends on matching hardcoded title strings (e.g., `"SELECCIONAR TIER"`, `"BASIC AURAS"`, `"PATRONES:"`). Any translation, formatting change, or title typo will silently break all click handling for auras.  
**Recommendation:** Migrate `AuraGUIManager` to use the `CoreGui`/`PaginatedGui` framework, or at minimum use `InventoryHolder`-based routing or `NamespacedKey` metadata on inventories instead of title matching.

### 🟡 Minor Issues

#### 2. Redundant `registerGui()` calls
**Locations:** `FFAKitGui`, `FFAStatsGui`, `FFALeaderboardGui`, `DuelGui`, `QueueKitGui`, `DuelStatsGui`, `PartySettingsGui`, `PartyListGui`  
**Problem:** These GUIs call `core.getGuiManager().registerGui(player, this)` explicitly in their `open()` method, but `CoreGui.openInventory()` already calls `registerGui()` internally. This is a double-registration — not a bug (the second call overwrites the first), but redundant code.  
**Recommendation:** Remove the explicit `registerGui()` calls from these `open()` methods.

#### 3. Four separate GUI frameworks
**Problem:** The project has evolved four different GUI handling mechanisms. This increases maintenance burden, inconsistency risk, and makes it harder for new developers to understand the codebase.  
**Recommendation:** Consider a long-term plan to consolidate. At minimum:
- Combat `AdminGUIManager` could be refactored to extend `CoreGui`
- `AuraGUIManager` should move to the `CoreGui` framework (see Issue #1)

#### 4. Mixed formatting systems
**Problem:** `AuraGUIManager` uses legacy `§`-color codes while all other GUIs use MiniMessage. `MissionGui` in progression also uses legacy `§` codes for some internal formatting.  
**Recommendation:** Standardize on MiniMessage throughout.

#### 5. Display-only GUIs with unused processAction
**Locations:** `FFAStatsGui`, `DuelStatsGui`, `MissionGui`  
**Problem:** These GUIs implement `processAction()` that returns `false` for all actions (only the base class `CLOSE` works). Not harmful, but adds dead code.  
**Impact:** Negligible — informational only.

### 🟢 Positive Findings

- ✅ **Every single GUI properly cancels `InventoryClickEvent`** — no item theft/duplication vulnerabilities
- ✅ **All listener registrations are confirmed** in their respective `onEnable()` methods
- ✅ **Purchase flows include proper validation** (balance check before deduction, permission checks, inventory space checks)
- ✅ **Async operations** (leaderboards, stats) properly schedule back to main thread with `Bukkit.getScheduler().runTask()`
- ✅ **Debounce protection** in AbstractGui (300ms) prevents double-click exploits
- ✅ **Clean close handling** — `GuiManager` and `GUIManager` both handle `InventoryCloseEvent` and `PlayerQuitEvent` for cleanup

---

## 12. Listener Registration Summary

| Module | Listener Class | Registered In | Line | Handles |
|--------|---------------|---------------|------|---------|
| **core** | `GuiManager` | `EthernovaCore.onEnable()` | 125 | All CoreGui/PaginatedGui clicks across ALL modules |
| **clans** | `GUIListener` | `EthernovaClans.onEnable()` | 531 | All AbstractGui + ConfigurableGUI clicks |
| **cosmetics** | `CosmeticListener` | `EthernovaCosmetics.onEnable()` | 108 | AuraGUIManager title-based routing |
| **combat** | `AdminGUIListener` | `EthernovaCombat.registerListeners()` | 187 | AdminGUIManager GUIType-based routing |

All other modules (ffa, duels, party, ranked, progression) use CoreGui-based GUIs and rely on the **core** module's `GuiManager` listener — no additional listener registration needed.

---

## Appendix: Complete File List

```
core/src/main/java/com/ethernova/core/gui/CoreGui.java
core/src/main/java/com/ethernova/core/gui/PaginatedGui.java
core/src/main/java/com/ethernova/core/gui/GuiManager.java
core/src/main/java/com/ethernova/core/gui/MainMenuGui.java
core/src/main/java/com/ethernova/core/gui/AdminGui.java
core/src/main/java/com/ethernova/core/gui/PlayerSettingsGui.java
core/src/main/java/com/ethernova/core/gui/RankingsGui.java
core/src/main/java/com/ethernova/core/gui/ConfirmationGui.java
core/src/main/java/com/ethernova/core/gui/KitEditorGui.java
cosmetics/src/main/java/com/ethernova/cosmetics/gui/CosmeticsMainGui.java
cosmetics/src/main/java/com/ethernova/cosmetics/gui/CosmeticTypeGui.java
cosmetics/src/main/java/com/ethernova/cosmetics/gui/CosmeticShopGui.java
cosmetics/src/main/java/com/ethernova/cosmetics/gui/MysteryBoxGui.java
cosmetics/src/main/java/com/ethernova/cosmetics/gui/CollectionGui.java
cosmetics/src/main/java/com/ethernova/cosmetics/gui/CosmeticsAdminGui.java
cosmetics/src/main/java/com/ethernova/cosmetics/aura/AuraGUIManager.java
cosmetics/src/main/java/com/ethernova/cosmetics/listener/CosmeticListener.java
ffa/src/main/java/com/ethernova/ffa/gui/FFAKitGui.java
ffa/src/main/java/com/ethernova/ffa/gui/FFAStatsGui.java
ffa/src/main/java/com/ethernova/ffa/gui/FFALeaderboardGui.java
ffa/src/main/java/com/ethernova/ffa/gui/FFAAdminGui.java
duels/src/main/java/com/ethernova/duels/gui/DuelGui.java
duels/src/main/java/com/ethernova/duels/gui/QueueKitGui.java
duels/src/main/java/com/ethernova/duels/gui/DuelStatsGui.java
duels/src/main/java/com/ethernova/duels/gui/DuelsAdminGui.java
party/src/main/java/com/ethernova/party/gui/PartyGui.java
party/src/main/java/com/ethernova/party/gui/PartySettingsGui.java
party/src/main/java/com/ethernova/party/gui/PartyListGui.java
party/src/main/java/com/ethernova/party/gui/PartyAdminGui.java
ranked/src/main/java/com/ethernova/ranked/gui/RankedGui.java
ranked/src/main/java/com/ethernova/ranked/gui/LeaderboardGui.java
ranked/src/main/java/com/ethernova/ranked/gui/RankedAdminGui.java
progression/src/main/java/com/ethernova/progression/gui/LevelGui.java
progression/src/main/java/com/ethernova/progression/gui/BattlePassGui.java
progression/src/main/java/com/ethernova/progression/gui/MissionGui.java
progression/src/main/java/com/ethernova/progression/gui/AchievementGui.java
progression/src/main/java/com/ethernova/progression/gui/ProgressionAdminGui.java
combat/src/main/java/com/ethernova/combat/gui/AdminGUIManager.java
combat/src/main/java/com/ethernova/combat/gui/AdminGUIListener.java
combat/src/main/java/com/ethernova/combat/gui/GUIHelper.java
src/main/java/com/ethernova/clans/gui/AbstractGui.java
src/main/java/com/ethernova/clans/gui/GUIManager.java
src/main/java/com/ethernova/clans/gui/ConfigurableGUI.java
src/main/java/com/ethernova/clans/listener/GUIListener.java
src/main/java/com/ethernova/clans/gui/ClanMainGui.java
src/main/java/com/ethernova/clans/gui/MembersGui.java
src/main/java/com/ethernova/clans/gui/BankGui.java
src/main/java/com/ethernova/clans/gui/TerritoryMapGui.java
src/main/java/com/ethernova/clans/gui/WarsGui.java
src/main/java/com/ethernova/clans/gui/SettingsGui.java
src/main/java/com/ethernova/clans/gui/TopsGui.java
src/main/java/com/ethernova/clans/gui/UpgradesGui.java
src/main/java/com/ethernova/clans/gui/ProgressGui.java
src/main/java/com/ethernova/clans/gui/DiplomacyGui.java
src/main/java/com/ethernova/clans/gui/ColorPickerGui.java
src/main/java/com/ethernova/clans/gui/MissionsGui.java
src/main/java/com/ethernova/clans/gui/AchievementsGui.java
src/main/java/com/ethernova/clans/gui/BoostsGui.java
src/main/java/com/ethernova/clans/gui/PermissionsGui.java
src/main/java/com/ethernova/clans/gui/AuditLogGui.java
src/main/java/com/ethernova/clans/gui/InvitationsGui.java
src/main/java/com/ethernova/clans/gui/InvitePlayersGui.java
src/main/java/com/ethernova/clans/gui/AdminMainGui.java
src/main/java/com/ethernova/clans/gui/AdminClanListGui.java
src/main/java/com/ethernova/clans/gui/AdminClanGui.java
src/main/java/com/ethernova/clans/gui/AdminPlayerGui.java
src/main/java/com/ethernova/clans/gui/ClanSkillsGui.java
src/main/java/com/ethernova/clans/gui/ClanShopGui.java
src/main/java/com/ethernova/clans/gui/EventCalendarGui.java
src/main/java/com/ethernova/clans/gui/TrophiesGui.java
src/main/java/com/ethernova/clans/gui/StatsGui.java
src/main/java/com/ethernova/clans/gui/WarpsGui.java
src/main/java/com/ethernova/clans/gui/IconSelectorGui.java
src/main/java/com/ethernova/clans/gui/BlueprintMenuGui.java
src/main/java/com/ethernova/clans/gui/BlueprintAdminGui.java
src/main/java/com/ethernova/clans/gui/SeasonGui.java
```
