package com.ethernova.lobby.manager;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.api.CombatAPI;
import com.ethernova.core.api.LobbyAPI;
import com.ethernova.core.service.ServiceRegistry;
import com.ethernova.lobby.EthernovaLobby;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Full lobby implementation — manages spawn location, hotbar items, PvP sword mechanic,
 * double-jump, and player state transitions.
 * <p>
 * This is the real implementation that lives in the EthernovaLobby module.
 * Core's {@code LobbyManager} is a proxy that delegates to this via {@link LobbyAPI}.
 */
public class LobbyManagerImpl implements LobbyAPI {

    /** Special action value for PvP sword hold-to-activate mechanic. */
    public static final String PVP_SWORD_ACTION = "PVP_SWORD";
    /** Ticks the player must hold the sword to activate PvP mode (3 seconds = 60 ticks). */
    private static final int PVP_HOLD_TICKS = 60;
    /** Ticks per second for countdown display. */
    private static final int TICKS_PER_SECOND = 20;

    private final EthernovaLobby plugin;
    private final EthernovaCore core;
    private final MiniMessage mini = MiniMessage.miniMessage();
    private final NamespacedKey lobbyItemKey;
    private final NamespacedKey queueCancelKey;

    private boolean enabled;
    private Location lobbySpawn;
    private GameMode lobbyGameMode;

    /** Tracks how many consecutive ticks each player has held the PvP sword. */
    private final Map<UUID, Integer> pvpSwordHoldTicks = new ConcurrentHashMap<>();
    /** Double-jump cooldown: UUID → timestamp when cooldown expires. */
    private final Map<UUID, Long> doubleJumpCooldowns = new ConcurrentHashMap<>();
    /** Double-jump cooldown duration in milliseconds. */
    private static final long DOUBLE_JUMP_COOLDOWN_MS = 3000; // 3 seconds
    /** Task ID for the PvP sword timer, -1 if not running. */
    private int pvpSwordTaskId = -1;

    public LobbyManagerImpl(EthernovaLobby plugin, EthernovaCore core) {
        this.plugin = plugin;
        this.core = core;
        this.lobbyItemKey = new NamespacedKey(plugin, "lobby_item_action");
        this.queueCancelKey = new NamespacedKey(plugin, "queue_cancel");
        loadConfig();
        startPvpSwordTask();
    }

    // ────────────────── Config ──────────────────

    @Override
    public void loadConfig() {
        enabled = plugin.getConfig().getBoolean("lobby.enabled", false);
        if (!enabled) return;

        // Load spawn
        ConfigurationSection spawnSec = plugin.getConfig().getConfigurationSection("lobby.spawn");
        if (spawnSec != null) {
            String worldName = spawnSec.getString("world", "world");
            World world = Bukkit.getWorld(worldName);
            if (world != null) {
                double x = spawnSec.getDouble("x", 0.5);
                double y = spawnSec.getDouble("y", 100.0);
                double z = spawnSec.getDouble("z", 0.5);
                float yaw = (float) spawnSec.getDouble("yaw", 0.0);
                float pitch = (float) spawnSec.getDouble("pitch", 0.0);
                lobbySpawn = new Location(world, x, y, z, yaw, pitch);
            } else {
                plugin.getLogger().warning("Lobby world '" + worldName + "' not found! Using world spawn.");
            }
        }

        // Load game mode
        String gmStr = plugin.getConfig().getString("lobby.gamemode", "ADVENTURE");
        try {
            lobbyGameMode = GameMode.valueOf(gmStr.toUpperCase());
        } catch (IllegalArgumentException e) {
            lobbyGameMode = GameMode.ADVENTURE;
        }
    }

    // ────────────────── Core API ──────────────────

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    @Override
    public void sendToLobby(Player player) {
        if (!enabled) return;
        if (player == null || !player.isOnline()) return;

        // Teleport to lobby spawn
        Location spawn = getLobbySpawn();
        if (spawn != null) {
            player.teleport(spawn);
        }

        // Clear all state
        player.getInventory().clear();
        player.getActivePotionEffects().forEach(e -> player.removePotionEffect(e.getType()));
        player.setHealth(player.getMaxHealth());
        player.setFoodLevel(20);
        player.setSaturation(20f);
        player.setFireTicks(0);
        player.setExp(0f);
        player.setLevel(0);
        player.setWalkSpeed(0.2f);
        player.setFlySpeed(0.1f);
        player.setAllowFlight(true); // Enable for double-jump mechanic
        player.setFlying(false);
        player.setGameMode(lobbyGameMode);

        // Give lobby items
        giveLobbyItems(player);

        // Set state to lobby
        core.getStateManager().setState(player.getUniqueId(), "lobby");
    }

    @Override
    public void giveLobbyItems(Player player) {
        player.getInventory().clear();

        ConfigurationSection itemsSec = plugin.getConfig().getConfigurationSection("lobby.items");
        if (itemsSec == null) return;

        // Check if player is in a party — shift menu to slot 3, party item at slot 4
        boolean inParty = core.getContextManager().hasContext(player.getUniqueId(), "party");

        for (String slotStr : itemsSec.getKeys(false)) {
            try {
                int slot = Integer.parseInt(slotStr);
                ConfigurationSection itemSec = itemsSec.getConfigurationSection(slotStr);
                if (itemSec == null) continue;

                String materialStr = itemSec.getString("material", "STONE");
                Material material;
                try {
                    material = Material.valueOf(materialStr.toUpperCase());
                } catch (IllegalArgumentException e) {
                    plugin.getLogger().warning("Lobby item slot " + slot + ": material '" + materialStr + "' inválido");
                    continue;
                }

                String name = itemSec.getString("name", "<white>Item");
                String action = itemSec.getString("action", "");

                // If this is the menu item (slot 4) and player is in a party, shift to slot 3
                int targetSlot = slot;
                if (slot == 4 && inParty) {
                    targetSlot = 3;
                }

                ItemStack item = new ItemStack(material);
                ItemMeta meta = item.getItemMeta();
                if (meta != null) {
                    meta.displayName(mini.deserialize(name));

                    // Parse lore if present
                    List<String> loreStrings = itemSec.getStringList("lore");
                    if (!loreStrings.isEmpty()) {
                        List<Component> lore = new ArrayList<>();
                        for (String loreLine : loreStrings) {
                            lore.add(mini.deserialize(loreLine));
                        }
                        meta.lore(lore);
                    }

                    // Tag with action for click detection
                    meta.getPersistentDataContainer().set(lobbyItemKey, PersistentDataType.STRING, action);
                    item.setItemMeta(meta);
                }

                player.getInventory().setItem(targetSlot, item);
            } catch (NumberFormatException e) {
                plugin.getLogger().log(Level.WARNING, "Lobby item slot inválido: " + slotStr, e);
            }
        }

        // Only add party item at slot 4 when player is in a party
        if (inParty) {
            ItemStack partyItem = new ItemStack(Material.CAKE);
            ItemMeta meta = partyItem.getItemMeta();
            if (meta != null) {
                meta.displayName(mini.deserialize("<light_purple><bold>♦ Tu Party"));
                List<Component> lore = new ArrayList<>();
                lore.add(mini.deserialize("<gray>Administra tu party"));
                lore.add(mini.deserialize(""));
                lore.add(mini.deserialize("<yellow>Click derecho para abrir"));
                meta.lore(lore);
                meta.getPersistentDataContainer().set(lobbyItemKey, PersistentDataType.STRING, "party gui");
                partyItem.setItemMeta(meta);
            }
            player.getInventory().setItem(4, partyItem);
        }
    }

    // ────────────────── PvP Sword Hold Timer ──────────────────

    private void startPvpSwordTask() {
        if (!enabled) return;
        pvpSwordTaskId = Bukkit.getScheduler().scheduleSyncRepeatingTask(plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                String state = core.getStateManager().getState(p.getUniqueId());

                // ── PvP Lobby Exit Check ──
                if ("pvp_lobby".equals(state)) {
                    ItemStack mainHand = p.getInventory().getItemInMainHand();
                    if (mainHand.getType() != Material.DIAMOND_SWORD) {
                        CombatAPI combatAPI = ServiceRegistry.get(CombatAPI.class);
                        if (combatAPI != null && combatAPI.isInCombat(p)) {
                            p.sendActionBar(mini.deserialize("<red>⚠ No puedes salir del PvP en combate!"));
                        } else {
                            deactivatePvpMode(p);
                        }
                    }
                    continue;
                }

                // ── Lobby Sword Hold Check ──
                if (!"lobby".equals(state)) {
                    pvpSwordHoldTicks.remove(p.getUniqueId());
                    continue;
                }
                ItemStack mainHand = p.getInventory().getItemInMainHand();
                String action = getLobbyItemAction(mainHand);
                if (PVP_SWORD_ACTION.equals(action)) {
                    int ticks = pvpSwordHoldTicks.getOrDefault(p.getUniqueId(), 0) + 1;
                    pvpSwordHoldTicks.put(p.getUniqueId(), ticks);

                    if (ticks >= PVP_HOLD_TICKS) {
                        activatePvpMode(p);
                        pvpSwordHoldTicks.remove(p.getUniqueId());
                    } else {
                        int secondsRemaining = (PVP_HOLD_TICKS - ticks) / TICKS_PER_SECOND + 1;
                        int progress = (ticks * 10) / PVP_HOLD_TICKS;
                        String filled = "<green>" + "▌".repeat(progress);
                        String empty = "<gray>" + "▌".repeat(10 - progress);
                        p.sendActionBar(mini.deserialize("<yellow>⚔ PvP en <white><bold>" + secondsRemaining + "s " + filled + empty));

                        if (ticks % TICKS_PER_SECOND == 0) {
                            p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1.0f, 1.0f);
                        }
                    }
                } else {
                    if (pvpSwordHoldTicks.remove(p.getUniqueId()) != null) {
                        p.sendActionBar(Component.empty());
                    }
                }
            }
        }, 1L, 1L);
    }

    private void activatePvpMode(Player player) {
        player.getInventory().clear();
        player.setGameMode(GameMode.SURVIVAL);
        player.setAllowFlight(false);
        player.setFlying(false);

        ItemStack sword = new ItemStack(Material.DIAMOND_SWORD);
        player.getInventory().setItem(0, sword);
        player.getInventory().setItem(1, new ItemStack(Material.GOLDEN_APPLE, 8));
        player.getInventory().setHelmet(new ItemStack(Material.DIAMOND_HELMET));
        player.getInventory().setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
        player.getInventory().setLeggings(new ItemStack(Material.DIAMOND_LEGGINGS));
        player.getInventory().setBoots(new ItemStack(Material.DIAMOND_BOOTS));

        player.setHealth(player.getMaxHealth());
        player.setFoodLevel(20);
        player.setSaturation(20f);

        core.getStateManager().setState(player.getUniqueId(), "pvp_lobby");

        Title title = Title.title(
                mini.deserialize("<red><bold>⚔ PvP Mode"),
                mini.deserialize("<gray>Cambia de item para salir"),
                Title.Times.times(Duration.ofMillis(200), Duration.ofSeconds(2), Duration.ofMillis(500))
        );
        player.showTitle(title);
        player.sendActionBar(mini.deserialize("<red><bold>¡PvP Activado!"));
        player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.7f, 1.2f);
        player.getWorld().spawnParticle(Particle.FLAME, player.getLocation().add(0, 1, 0), 30, 0.5, 0.5, 0.5, 0.05);
        player.getWorld().spawnParticle(Particle.CRIT, player.getLocation().add(0, 1, 0), 20, 0.4, 0.4, 0.4, 0.1);
    }

    @Override
    public void deactivatePvpMode(Player player) {
        player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation().add(0, 1, 0), 20, 0.4, 0.4, 0.4, 0.05);

        player.getInventory().clear();
        player.getActivePotionEffects().forEach(e -> player.removePotionEffect(e.getType()));
        player.setHealth(player.getMaxHealth());
        player.setFoodLevel(20);
        player.setSaturation(20f);
        player.setFireTicks(0);
        player.setGameMode(lobbyGameMode);

        giveLobbyItems(player);
        core.getStateManager().setState(player.getUniqueId(), "lobby");

        player.setAllowFlight(true);
        player.setFlying(false);

        Title title = Title.title(
                mini.deserialize("<green><bold>✔ PvP Desactivado"),
                mini.deserialize("<gray>Mantén la espada para volver a activar"),
                Title.Times.times(Duration.ofMillis(200), Duration.ofSeconds(1), Duration.ofMillis(500))
        );
        player.showTitle(title);
        player.sendActionBar(mini.deserialize("<green>¡PvP Desactivado!"));
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 2.0f);
    }

    @Override
    public boolean isInLobbyState(Player player) {
        return enabled && "lobby".equals(core.getStateManager().getState(player.getUniqueId()));
    }

    @Override
    public void cleanupPlayer(UUID uuid) {
        pvpSwordHoldTicks.remove(uuid);
        doubleJumpCooldowns.remove(uuid);
    }

    @Override
    public long getDoubleJumpCooldown(UUID uuid) {
        Long cooldownEnd = doubleJumpCooldowns.get(uuid);
        if (cooldownEnd == null) return 0;
        long remaining = cooldownEnd - System.currentTimeMillis();
        return remaining > 0 ? (remaining / 1000 + 1) : 0;
    }

    @Override
    public void setDoubleJumpCooldown(UUID uuid) {
        doubleJumpCooldowns.put(uuid, System.currentTimeMillis() + DOUBLE_JUMP_COOLDOWN_MS);
    }

    @Override
    public void shutdown() {
        if (pvpSwordTaskId != -1) {
            Bukkit.getScheduler().cancelTask(pvpSwordTaskId);
            pvpSwordTaskId = -1;
        }
        pvpSwordHoldTicks.clear();
    }

    @Override
    public ItemStack createQueueCancelItem() {
        ItemStack item = new ItemStack(Material.RED_DYE);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(mini.deserialize("<red><bold>✖ Cancelar Cola <gray>(Click derecho)"));
            meta.getPersistentDataContainer().set(queueCancelKey, PersistentDataType.BOOLEAN, true);
            item.setItemMeta(meta);
        }
        return item;
    }

    @Override
    public boolean isQueueCancelItem(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(queueCancelKey, PersistentDataType.BOOLEAN);
    }

    @Override
    public String getLobbyItemAction(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(lobbyItemKey, PersistentDataType.STRING);
    }

    // ────────────────── Spawn Management ──────────────────

    @Override
    public Location getLobbySpawn() {
        if (lobbySpawn != null) return lobbySpawn;
        World world = Bukkit.getWorlds().isEmpty() ? null : Bukkit.getWorlds().get(0);
        return world != null ? world.getSpawnLocation() : null;
    }

    @Override
    public void setLobbySpawn(Location location) {
        this.lobbySpawn = location;
        plugin.getConfig().set("lobby.spawn.world", location.getWorld().getName());
        plugin.getConfig().set("lobby.spawn.x", location.getX());
        plugin.getConfig().set("lobby.spawn.y", location.getY());
        plugin.getConfig().set("lobby.spawn.z", location.getZ());
        plugin.getConfig().set("lobby.spawn.yaw", (double) location.getYaw());
        plugin.getConfig().set("lobby.spawn.pitch", (double) location.getPitch());
        plugin.saveConfig();
    }

    // ────────────────── Keys ──────────────────

    @Override
    public NamespacedKey getLobbyItemKey() { return lobbyItemKey; }

    @Override
    public NamespacedKey getQueueCancelKey() { return queueCancelKey; }
}
