package com.ethernova.lobby.command;

import com.ethernova.core.EthernovaCore;
import com.ethernova.lobby.manager.LobbyManagerImpl;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

/**
 * /lobby command — teleports the player to the lobby spawn.
 * Moved from Core to Lobby module.
 */
public class LobbyCommand implements CommandExecutor {

    private final LobbyManagerImpl lobbyManager;
    private final MiniMessage mini = MiniMessage.miniMessage();

    public LobbyCommand(LobbyManagerImpl lobbyManager) {
        this.lobbyManager = lobbyManager;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(mini.deserialize("<red>Este comando solo puede ser usado por jugadores."));
            return true;
        }

        if (!lobbyManager.isEnabled()) {
            player.sendMessage(mini.deserialize("<red>El lobby no está configurado."));
            return true;
        }

        lobbyManager.sendToLobby(player);
        return true;
    }
}
