package com.ethernova.lobby;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.api.LobbyAPI;
import com.ethernova.core.service.ServiceRegistry;
import com.ethernova.lobby.command.LobbyCommand;
import com.ethernova.lobby.command.MenuCommand;
import com.ethernova.lobby.listener.LobbyItemListener;
import com.ethernova.lobby.manager.LobbyManagerImpl;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * EthernovaLobby — manages the practice-server lobby system.
 * <p>
 * Provides: lobby spawn, hotbar items, PvP sword mechanic, double-jump,
 * dynamic main menu GUI, /lobby and /menu commands.
 * <p>
 * Registers {@link LobbyAPI} via {@link ServiceRegistry} so Core's proxy
 * LobbyManager and all other modules can access lobby functionality.
 */
public class EthernovaLobby extends JavaPlugin {

    private EthernovaCore core;
    private LobbyManagerImpl lobbyManager;

    @Override
    public void onEnable() {
        // Load config
        saveDefaultConfig();

        // Get Core reference
        core = (EthernovaCore) Bukkit.getPluginManager().getPlugin("EthernovaCore");
        if (core == null) {
            getLogger().severe("EthernovaCore not found! Disabling EthernovaLobby.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        // Create the real lobby manager implementation
        lobbyManager = new LobbyManagerImpl(this, core);

        // Register as LobbyAPI via ServiceRegistry — Core's proxy LobbyManager will delegate to this
        ServiceRegistry.register(LobbyAPI.class, lobbyManager);

        // Register listeners
        getServer().getPluginManager().registerEvents(new LobbyItemListener(this, core, lobbyManager), this);

        // Register /lobby command
        LobbyCommand lobbyCmd = new LobbyCommand(lobbyManager);
        PluginCommand lobbyCmdHandle = getCommand("lobby");
        if (lobbyCmdHandle != null) {
            lobbyCmdHandle.setExecutor(lobbyCmd);
        }

        // Register /menu command
        MenuCommand menuCmd = new MenuCommand(core, this);
        PluginCommand menuCmdHandle = getCommand("menu");
        if (menuCmdHandle != null) {
            menuCmdHandle.setExecutor(menuCmd);
        }

        // Register with Core
        core.registerPlugin("EthernovaLobby");

        getLogger().info("EthernovaLobby v" + getDescription().getVersion() + " enabled — lobby system active");
    }

    @Override
    public void onDisable() {
        if (lobbyManager != null) {
            lobbyManager.shutdown();
        }
        ServiceRegistry.unregister(LobbyAPI.class);
        if (core != null) {
            core.unregisterPlugin("EthernovaLobby");
        }
        getLogger().info("EthernovaLobby disabled.");
    }

    public EthernovaCore getCore() { return core; }
    public LobbyManagerImpl getLobbyManager() { return lobbyManager; }
}
