package com.ethernova.lobby.gui;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.CoreGui;
import com.ethernova.core.gui.PlayerSettingsGui;
import com.ethernova.core.gui.PlayerStatsGui;
import com.ethernova.core.gui.ProfileGui;
import com.ethernova.core.gui.RankingsGui;
import com.ethernova.core.module.ModuleManager;
import com.ethernova.lobby.EthernovaLobby;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * Dynamic Main Menu GUI — only shows buttons for installed modules.
 * Detects installed Ethernova modules via {@link ModuleManager} and hides
 * options for modules that aren't present on this server.
 */
public class MainMenuGui extends CoreGui {

    private final EthernovaLobby lobbyPlugin;
    private final ModuleManager modules;

    public MainMenuGui(EthernovaCore core, EthernovaLobby lobbyPlugin, Player player) {
        super(core, player);
        this.lobbyPlugin = lobbyPlugin;
        this.modules = core.getModuleManager();
    }

    public void open() {
        openInventory("<gradient:gold:yellow>✦ Menú Principal ✦</gradient>", 45);
    }

    @Override
    protected void populateItems() {
        // ═══════════ Row 0: Player Head ═══════════
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta skullMeta = (SkullMeta) head.getItemMeta();
        if (skullMeta != null) {
            skullMeta.setOwningPlayer(player);
            var profile = core.getProfileManager().getProfile(player.getUniqueId());
            String levelStr = profile != null ? String.valueOf(profile.getLevel()) : "?";
            String coinsStr = profile != null ? String.format("%,.0f", profile.getCoins()) : "?";
            skullMeta.displayName(mini.deserialize("<gradient:gold:yellow><bold>★ " + player.getName() + " ★</bold></gradient>"));
            skullMeta.lore(List.of(
                    mini.deserialize(""),
                    mini.deserialize("<dark_gray>▎ <gray>Nivel: <yellow>" + levelStr),
                    mini.deserialize("<dark_gray>▎ <gray>Monedas: <gold>$" + coinsStr),
                    mini.deserialize(""),
                    mini.deserialize("<yellow>Click para ver tu perfil")
            ));
            head.setItemMeta(skullMeta);
        }
        setItem(4, head);
        slotActions.put(4, "PROFILE");

        // ═══════════ Row 2 (slots 10-16): Combat Modes ═══════════
        // Dynamic: only show if the module is installed

        int combatSlot = 10;

        if (modules.hasFFA()) {
            setItem(combatSlot, createItem(Material.IRON_SWORD, "<red>⚔ FFA Arenas",
                    List.of("<gray>Entra a una arena FFA", "<gray>y combate contra todos", " ", "<yellow>Click para ver arenas")));
            slotActions.put(combatSlot, "FFA");
            combatSlot += 2;
        }

        if (modules.hasDuels()) {
            setItem(combatSlot, createItem(Material.DIAMOND_SWORD, "<gold>⚔ Duelos",
                    List.of("<gray>Reta a otro jugador", "<gray>a un duelo 1v1", " ", "<yellow>Click para abrir")));
            slotActions.put(combatSlot, "DUELS");
            combatSlot += 2;
        }

        if (modules.hasRanked()) {
            setItem(combatSlot, createItem(Material.NETHERITE_SWORD, "<dark_purple>⚔ Ranked",
                    List.of("<gray>Combate competitivo", "<gray>con sistema de ELO", " ", "<yellow>Click para abrir")));
            slotActions.put(combatSlot, "RANKED");
            combatSlot += 2;
        }

        if (modules.hasClans()) {
            setItem(combatSlot <= 16 ? combatSlot : 16, createItem(Material.SHIELD, "<aqua>☠ Clanes",
                    List.of("<gray>Únete o crea un clan", "<gray>para luchar en equipo", " ", "<yellow>Click para abrir")));
            slotActions.put(combatSlot <= 16 ? combatSlot : 16, "CLANS");
        }

        // ═══════════ Row 3 (slots 19-25): Social & Economy ═══════════

        int socialSlot = 19;

        if (modules.hasParty()) {
            setItem(socialSlot, createItem(Material.CAKE, "<light_purple>♦ Party",
                    List.of("<gray>Crea o únete a un party", "<gray>y juega con amigos", " ", "<yellow>Click para abrir")));
            slotActions.put(socialSlot, "PARTY");
            socialSlot += 2;
        }

        if (modules.hasCosmetics()) {
            setItem(socialSlot, createItem(Material.EMERALD, "<green>$ Tienda",
                    List.of("<gray>Compra cosméticos,", "<gray>cajas y más", " ", "<yellow>Click para abrir")));
            slotActions.put(socialSlot, "SHOP");
            socialSlot += 1;
        }

        if (modules.hasProgression()) {
            setItem(socialSlot, createItem(Material.CHEST, "<gradient:gold:yellow>🎁 Recompensas Diarias</gradient>",
                    List.of("<gray>Reclama tu recompensa", "<gray>diaria. ¡Racha de 7 días!", " ", "<yellow>Click para reclamar")));
            slotActions.put(socialSlot, "DAILY");
            socialSlot += 1;
        }

        if (modules.hasCosmetics()) {
            setItem(socialSlot, createItem(Material.ENDER_CHEST, "<light_purple>✦ Cosméticos",
                    List.of("<gray>Equipa y gestiona tus", "<gray>cosméticos desbloqueados", " ", "<yellow>Click para abrir")));
            slotActions.put(socialSlot, "COSMETICS");
            socialSlot += 2;
        }

        if (modules.hasProgression()) {
            setItem(socialSlot <= 25 ? socialSlot : 25, createItem(Material.BOOK, "<gold>✦ Battle Pass",
                    List.of("<gray>Progresa en el pase", "<gray>de batalla por premios", " ", "<yellow>Click para abrir")));
            slotActions.put(socialSlot <= 25 ? socialSlot : 25, "BATTLEPASS");
        }

        // ═══════════ Row 4 (slots 28-34): Utility & Progress ═══════════

        int utilSlot = 28;

        if (modules.hasProgression()) {
            setItem(utilSlot, createItem(Material.COMPASS, "<yellow>★ Misiones",
                    List.of("<gray>Completa misiones diarias", "<gray>y semanales por recompensas", " ", "<yellow>Click para abrir")));
            slotActions.put(utilSlot, "MISSIONS");
            utilSlot += 2;

            setItem(utilSlot, createItem(Material.DIAMOND, "<aqua>✦ Logros",
                    List.of("<gray>Desbloquea logros", "<gray>y gana recompensas", " ", "<yellow>Click para abrir")));
            slotActions.put(utilSlot, "ACHIEVEMENTS");
            utilSlot += 1;
        }

        // Stats — always available (Core)
        setItem(utilSlot, createItem(Material.PAPER, "<white>✎ Estadísticas",
                List.of("<gray>Ve tus estadísticas", "<gray>de combate y más", " ", "<yellow>Click para ver")));
        slotActions.put(utilSlot, "STATS");
        utilSlot += 1;

        // Rankings — always available (Core)
        setItem(utilSlot, createItem(Material.GOLD_BLOCK, "<gold>♛ Rankings",
                List.of("<gray>Ve los mejores jugadores", "<gray>del servidor", " ", "<yellow>Click para ver")));
        slotActions.put(utilSlot, "RANKINGS");
        utilSlot += 2;

        // Settings — always available (Core)
        setItem(utilSlot <= 34 ? utilSlot : 34, createItem(Material.REDSTONE, "<red>⚙ Configuración",
                List.of("<gray>Ajusta tus preferencias", "<gray>de juego", " ", "<yellow>Click para abrir")));
        slotActions.put(utilSlot <= 34 ? utilSlot : 34, "SETTINGS");

        // Bottom center: Close
        setItem(40, createItem(Material.BARRIER, "<red>Cerrar"));
        slotActions.put(40, "CLOSE");
    }

    @Override
    protected boolean processAction(String action, int slot, InventoryClickEvent event) {
        playSound("click");

        switch (action) {
            case "PROFILE" -> {
                player.closeInventory();
                new ProfileGui(core, player).open();
            }
            case "FFA" -> {
                player.closeInventory();
                player.performCommand("ffa join");
            }
            case "DUELS" -> {
                player.closeInventory();
                player.performCommand("duel queue");
            }
            case "RANKED" -> {
                player.closeInventory();
                player.performCommand("ranked stats");
            }
            case "CLANS" -> {
                player.closeInventory();
                player.performCommand("clan");
            }
            case "PARTY" -> {
                player.closeInventory();
                player.performCommand("party gui");
            }
            case "SHOP" -> {
                player.closeInventory();
                player.performCommand("cosmetics shop");
            }
            case "COSMETICS" -> {
                player.closeInventory();
                player.performCommand("cosmetics");
            }
            case "MISSIONS" -> {
                player.closeInventory();
                player.performCommand("missions");
            }
            case "BATTLEPASS" -> {
                player.closeInventory();
                player.performCommand("battlepass");
            }
            case "ACHIEVEMENTS" -> {
                player.closeInventory();
                player.performCommand("achievements");
            }
            case "STATS" -> {
                player.closeInventory();
                new PlayerStatsGui(core, player).open();
            }
            case "SETTINGS" -> {
                player.closeInventory();
                new PlayerSettingsGui(core, player).open();
            }
            case "RANKINGS" -> {
                player.closeInventory();
                new RankingsGui(core, player).open();
            }
            case "DAILY" -> {
                player.closeInventory();
                player.performCommand("daily");
            }
        }
        return true;
    }
}
