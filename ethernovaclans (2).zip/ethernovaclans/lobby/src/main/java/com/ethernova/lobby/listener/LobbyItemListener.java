package com.ethernova.lobby.listener;

import com.ethernova.core.EthernovaCore;
import com.ethernova.core.gui.PlayerSettingsGui;
import com.ethernova.lobby.EthernovaLobby;
import com.ethernova.lobby.gui.MainMenuGui;
import com.ethernova.lobby.manager.LobbyManagerImpl;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

import java.util.UUID;

/**
 * Handles lobby item interactions and lobby protections.
 * Lives in the EthernovaLobby module — only active when lobby is installed.
 */
public class LobbyItemListener implements Listener {

    private final EthernovaLobby plugin;
    private final EthernovaCore core;
    private final LobbyManagerImpl lobbyManager;

    public LobbyItemListener(EthernovaLobby plugin, EthernovaCore core, LobbyManagerImpl lobbyManager) {
        this.plugin = plugin;
        this.core = core;
        this.lobbyManager = lobbyManager;
    }

    private boolean isInLobby(Player player) {
        return lobbyManager.isEnabled()
                && "lobby".equals(core.getStateManager().getState(player.getUniqueId()));
    }

    private boolean isInPvpLobby(Player player) {
        return lobbyManager.isEnabled()
                && "pvp_lobby".equals(core.getStateManager().getState(player.getUniqueId()));
    }

    private boolean isInQueue(Player player) {
        String state = core.getStateManager().getState(player.getUniqueId());
        return lobbyManager.isEnabled() && state != null && state.startsWith("queue");
    }

    private boolean isProtectedState(Player player) {
        return isInLobby(player) || isInQueue(player);
    }

    // ────────────────── Item Click ──────────────────

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent event) {
        if (!lobbyManager.isEnabled()) return;

        Player player = event.getPlayer();
        boolean inLobby = isInLobby(player);
        boolean inQueue = isInQueue(player);
        if (!inLobby && !inQueue) return;

        ItemStack item = event.getItem();
        if (item == null) return;

        // Check for queue cancel item
        if (lobbyManager.isQueueCancelItem(item)) {
            event.setCancelled(true);
            player.performCommand("duel queue cancel");
            return;
        }

        // Lobby-only item actions
        if (!inLobby) return;

        String action = lobbyManager.getLobbyItemAction(item);
        if (action != null && !action.isEmpty()) {
            event.setCancelled(true);
            if (LobbyManagerImpl.PVP_SWORD_ACTION.equals(action)) return;
            if ("settings".equalsIgnoreCase(action)) {
                new PlayerSettingsGui(core, player).open();
                return;
            }
            if ("menu".equalsIgnoreCase(action)) {
                new MainMenuGui(core, plugin, player).open();
                return;
            }
            // Dispatch the command as the player
            player.performCommand(action);
        }
    }

    // ────────────────── Lobby Protections ──────────────────

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        if ((isInLobby(event.getPlayer()) || isInPvpLobby(event.getPlayer())) && !event.getPlayer().hasPermission("ethernova.lobby.bypass")) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        if ((isInLobby(event.getPlayer()) || isInPvpLobby(event.getPlayer())) && !event.getPlayer().hasPermission("ethernova.lobby.bypass")) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (isInLobby(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHunger(FoodLevelChangeEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (isInLobby(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent event) {
        if (isProtectedState(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSwapHand(PlayerSwapHandItemsEvent event) {
        if (isProtectedState(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (isProtectedState(player) && !player.hasPermission("ethernova.lobby.bypass")) {
            event.setCancelled(true);
        }
    }

    // ────────────────── Lobby Double Jump ──────────────────

    @EventHandler(priority = EventPriority.HIGH)
    public void onToggleFlight(PlayerToggleFlightEvent event) {
        Player player = event.getPlayer();
        if (!isInLobby(player)) return;

        event.setCancelled(true);
        player.setFlying(false);

        long remaining = lobbyManager.getDoubleJumpCooldown(player.getUniqueId());
        if (remaining > 0) {
            player.sendActionBar(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                    .deserialize("<red>Doble salto en cooldown! <yellow>" + remaining + "s"));
            return;
        }

        Vector direction = player.getLocation().getDirection();
        player.setVelocity(new Vector(direction.getX() * 0.5, 1.0, direction.getZ() * 0.5));

        player.playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 0.5f, 1.2f);
        player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 15, 0.3, 0.1, 0.3, 0.05);

        lobbyManager.setDoubleJumpCooldown(player.getUniqueId());

        player.setAllowFlight(false);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline() && isInLobby(player)) {
                player.setAllowFlight(true);
            }
        }, 20L);
    }

    // ────────────────── PvP Lobby Death/Respawn ──────────────────

    @EventHandler(priority = EventPriority.HIGH)
    public void onPvpLobbyDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        if (!isInPvpLobby(victim)) return;

        event.getDrops().clear();
        event.setDroppedExp(0);
        event.deathMessage(null);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPvpLobbyRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        if (!isInPvpLobby(player)) return;

        org.bukkit.Location spawn = lobbyManager.getLobbySpawn();
        if (spawn != null) {
            event.setRespawnLocation(spawn);
        }

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline()) {
                lobbyManager.sendToLobby(player);
            }
        }, 1L);
    }
}
