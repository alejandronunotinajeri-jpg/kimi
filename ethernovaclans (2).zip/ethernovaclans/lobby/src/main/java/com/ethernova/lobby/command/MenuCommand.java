package com.ethernova.lobby.command;

import com.ethernova.core.EthernovaCore;
import com.ethernova.lobby.EthernovaLobby;
import com.ethernova.lobby.gui.MainMenuGui;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

/**
 * /menu command — opens the dynamic main menu GUI.
 */
public class MenuCommand implements CommandExecutor {

    private final EthernovaCore core;
    private final EthernovaLobby lobbyPlugin;
    private final MiniMessage mini = MiniMessage.miniMessage();

    public MenuCommand(EthernovaCore core, EthernovaLobby lobbyPlugin) {
        this.core = core;
        this.lobbyPlugin = lobbyPlugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(mini.deserialize("<red>Este comando solo puede ser usado por jugadores."));
            return true;
        }
        new MainMenuGui(core, lobbyPlugin, player).open();
        return true;
    }
}
